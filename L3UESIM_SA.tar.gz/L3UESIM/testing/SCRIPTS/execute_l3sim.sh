#!/bin/sh
#############################################################
### L3sim run script
#############################################################


PWD=`pwd`
ERR_SUCCESS=0


if [[ $# == 0 ]]
    then
    echo -e "########################L3SIM execute for NSA mode#############################"
    EXE=./testTool

else
    if [[ $1 == "sa" ]]
    then
        echo -e "########################L3SIM execute for SA mode#############################"
         EXE="./testTool sa"
    else
        echo -e "Invalid argument"
    fi
fi

ulimit -q unlimited
ulimit -c unlimited
rm -rf *.log* core.*

cd $PWD/../../../../5G_IPR/gNB_SW/
. ./.gnb_settings
cd ../../Testing/L3UESIM/testing/bin/

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../../lib:../../ueSim/lib:../../duSim/lib:../../nrAdaptSim/lib:../../framework/lib:../../common/asn_lib/:../../x2Sim/lib:../../rrmSim/lib:../../common/lib:../../../../5G_IPR/gNB_SW/gNB_CU/cu_cp/common/utils/lib:/usr/local/lib:../../amfSim/lib

$EXE

if [ "$?" -ne $ERR_SUCCESS ]
    then
        exit 1
fi

