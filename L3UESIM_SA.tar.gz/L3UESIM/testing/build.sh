#!/bin/sh
#############################################################
### Platform specific - this is for host intel
#Date            Author         Remarks
#22.03.2018      gur21010      Build script to compile 5G-NR 
#############################################################
export GNB_ROOT=$PWD/../../../5G_IPR/gNB_SW/
export L3SIM_ROOT=$PWD/../

CLEANUP=clean
L3SIM=l3sim
SA=sa

echo $GNB_ROOT
echo $L3SIM_ROOT

function check_failure()
{
    if [ $? -ne 0 ]
        then
            echo "build failed"
            exit 1
    fi
}

function build_usage()
{
    echo "Usage of build.sh ::"
    echo " ./build.sh"
    echo " <build-option>   :-> It is a mandatory parameter. "
    echo "                   -> Following values can be passed for this parameter -" 
    echo "                      For NSA {l3sim/ clean }"
    echo "                      For SA {l3sim sa/ clean }"
}

    if [ $# -lt 1 ]
then
        build_usage
exit 1
fi

if [ $1 == $L3SIM ]; then

    if [ $2 == $SA ]; then
    	PATTERN=UAMF_SIM_TESTING_ENABLE
    	FILE=../make.inc

	VAR1=1
	VAR=`grep "$PATTERN" $FILE -rn | wc -l` 
    	echo "VAR = $VAR"
	
    	if [ $VAR -eq $VAR1 ]; then
                echo " Amf sim disabled "
                
		sed -i 's/\${SIM_ROOT}\/amfSim/\#\${SIM_ROOT}\/amfSim/g' $L3SIM_ROOT/testing/Makefile
    		sed -i 's/\$(SIM_ROOT)\/amfSim/\#\$(SIM_ROOT)\/amfSim/g' $L3SIM_ROOT/Makefile
    		sed -i "s/AMF_SIM_INC/#AMF_SIM_INC/g" $L3SIM_ROOT/testing/core/Makefile
    		sed -i "s/AMFSIM_INC/#AMFSIM_INC/g" $L3SIM_ROOT/testing/Makefile
    		sed -i "s/AMFSIM_LIB/#AMFSIM_LIB/g" $L3SIM_ROOT/testing/Makefile
    		sed -i "s/AMF_SIM_INC/#AMF_SIM_INC/g" $L3SIM_ROOT/testing/suites/dual_connectivity/Makefile
    	else
                echo " Amf sim enabled "
		sed -i 's/\#\${SIM_ROOT}\/amfSim/\${SIM_ROOT}\/amfSim/g' $L3SIM_ROOT/testing/Makefile
    		sed -i 's/\#\$(SIM_ROOT)\/amfSim/\$(SIM_ROOT)\/amfSim/g' $L3SIM_ROOT/Makefile
    		sed -i "s/UAMF_SIM_TESTING_ENABLE/DAMF_SIM_TESTING_ENABLE/g" $L3SIM_ROOT/make.inc
    		sed -i "s/UNR_SA_MODE_ENABLED/DNR_SA_MODE_ENABLED/g" $L3SIM_ROOT/make.inc
    		sed -i "s/#AMF_SIM_INC/AMF_SIM_INC/g" $L3SIM_ROOT/testing/core/Makefile
    		sed -i "s/#AMFSIM_INC/AMFSIM_INC/g" $L3SIM_ROOT/testing/Makefile
    		sed -i "s/#AMFSIM_LIB/AMFSIM_LIB/g" $L3SIM_ROOT/testing/Makefile
    		sed -i "s/#AMF_SIM_INC/AMF_SIM_INC/g" $L3SIM_ROOT/testing/suites/dual_connectivity/Makefile

    	fi
    else
      
    		sed -i "s/DAMF_SIM_TESTING_ENABLE/UAMF_SIM_TESTING_ENABLE/g" $L3SIM_ROOT/make.inc
    		sed -i "s/DNR_SA_MODE_ENABLED/UNR_SA_MODE_ENABLED/g" $L3SIM_ROOT/make.inc
    fi
    
    sed -i "s/DDPDK_NR_INT/UDPDK_NR_INT/g" $GNB_ROOT/make.inc
    echo "********************************* COMPILING INTERFACE LIBRARY ******************************"
    cd $GNB_ROOT/gNB_DU/interfaces/
    make
    check_failure
    echo ""
    echo ""

    echo "********************************* COMPILING cucpcommonutils LIBRARY ******************************"
    cd $GNB_ROOT
    . ./.gnb_settings
    cd gNB_CU/cu_cp/common/utils
    make
    check_failure
    echo ""
    echo ""

    echo "********************************* COMPILING COMMON LIBRARY ******************************"
    cd $GNB_ROOT
    . ./.gnb_settings
    cd common
    make
    check_failure
    echo ""
    echo ""
    echo "********************************* COMPILING SIM TOOL ******************************"
    cp $GNB_ROOT/gNB_DU/common/inc/du_types.h  $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/common/cspl/inc/* $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/common/porting/inc/* $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/common/utility/core/inc/gnb_msg_mgmt.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_mac_intf.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_mac_intf.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_mac_il_composer.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_mac_il_parser.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_mac_il_composer.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_mac_il_parser.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_rlc_il_parser.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/interfaces/inc/l3_pdcp_intf.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_rlc_intf.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_rlc_il_composer.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/dumgr_rlc_intf.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_rlc_il_composer.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/interfaces/inc/duoam_rlc_il_parser.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_DU/common/inc/du_comm_intf_defn.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/rrc/llim/interface/inc/l3_pdcp_il_composer.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/rrc/llim/interface/inc/l3_pdcp_il_parser.h $L3SIM_ROOT/common/inc/
  
    #cp $GNB_ROOT/gNB_DU/interfaces/src/duoam_mac_il_composer.c $L3SIM_ROOT/../ueSim/stackApp/src/                                      

    #Below 2 rules shall be removed later
    #sed -i "s/communication_info_t/comm_info_t/g" $L3SIM_ROOT/../ueSim/common/inc/duoam_rlc_intf.h
    #sed -i "s/rlc_communication_info_t/rlc_comm_info_t/g" $L3SIM_ROOT/../ueSim/cmdInterpreter/inc/cmd_defs.h

    echo "********************************* COPY FILES FOR AMFSIM  ******************************"

if [ $2 == $SA ]; then
    cp $GNB_ROOT/common/porting/inc/gnb_composer_parser.h                   $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/common/porting/inc/gnb_defines.h                           $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/./gNB_CU/cu_cp/common/utils/inc/rrc_protocol_events.h      $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/common/porting/inc/gnb_types.h                             $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/common/loggingFrameWork/in_memory_logging/inc/lteLogger.h  $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/gNB_CU/cu_cp/common/utils/inc/gnb_common_utils.h           $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/rrc/uecc/utils/src/hmac_sha256.c           $L3SIM_ROOT/common/src
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/rrc/uecc/utils/inc/hmac_sha256.h           $L3SIM_ROOT/common/inc
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_asn_common_wrapper.h  $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_asn_dec_wrapper.h     $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/common/asn/inc/ngap_asn_enc_dec_3gpp.h              $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_asn_enc_wrapper.h     $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_intf_mgmnt.h          $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_tracing.h             $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_types.h               $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_utils.h               $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/interfaces/inc/rrc_ngap_cu_common_def.h      $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/common/utils/inc/rrc_ngap_common_def.h $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/common/asn/src/ngap_3gpp.c                          $L3SIM_ROOT/common/src/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/src/ngap_asn_common_wrapper.c  $L3SIM_ROOT/common/src/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/src/ngap_asn_dec_wrapper.c     $L3SIM_ROOT/common/src/
    cp $GNB_ROOT/common/asn/src/ngap_asn_enc_dec_3gpp.c              $L3SIM_ROOT/common/src/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/src/ngap_asn_enc_wrapper.c     $L3SIM_ROOT/common/src/
    cp $GNB_ROOT/gNB_CU/cu_cp/l3/ngap/inc/ngap_global_ctx.h          $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/cu_cp/interfaces/inc/ngap_api.h              $L3SIM_ROOT/common/inc/
    cp $GNB_ROOT/gNB_CU/interfaces/inc/rrc_ngap_oam_intf.h           $L3SIM_ROOT/common/inc/

fi

    cd $L3SIM_ROOT/testing/
    make
    #check_failure
    #cd $GNB_ROOT
    #echo ""
    #echo ""
    cp SCRIPTS/execute_l3sim.sh bin/
    echo "********************************* L3SIM COMPILED ***************************"
fi

if [ $1 == $CLEANUP ]; then
    echo "*************************** CLEANING INTF HDR FILES ************************************"
    rm -f $L3SIM_ROOT/common/inc/gnb_defines.h
    rm -f $L3SIM_ROOT/common/inc/gnb_types.h
    rm -f $L3SIM_ROOT/common/inc/du_types.h
    rm -f $L3SIM_ROOT/common/inc/gnb_msg_mgmt.h
    rm -f $L3SIM_ROOT/common/inc/duoam_mac_intf.h
    rm -f $L3SIM_ROOT/common/inc/dumgr_mac_intf.h
    rm -f $L3SIM_ROOT/common/inc/duoam_mac_il_composer.h
    rm -f $L3SIM_ROOT/common/inc/duoam_mac_il_parser.h
    rm -f $L3SIM_ROOT/common/inc/dumgr_mac_il_composer.h
    rm -f $L3SIM_ROOT/common/inc/dumgr_mac_il_parser.h
    rm -f $L3SIM_ROOT/common/inc/l3_pdcp_intf.h 
    rm -f $L3SIM_ROOT/common/inc/duoam_rlc_intf.h
    rm -f $L3SIM_ROOT/common/inc/dumgr_rlc_intf.h
    rm -f $L3SIM_ROOT/common/inc/duoam_rlc_il_composer.h
    rm -f $L3SIM_ROOT/common/inc/duoam_rlc_il_parser.h
    rm -f $L3SIM_ROOT/common/inc/du_comm_intf_defn.h
    rm -f $L3SIM_ROOT/common/inc/dumgr_rlc_il_composer.h


    echo "*************************** CLEANING AMFSIM FILES ************************************"
    rm -f $L3SIM_ROOT/common/inc/gnb_composer_parser.h
    rm -f $L3SIM_ROOT/common/inc/ngap_asn_common_wrapper.h
    rm -f $L3SIM_ROOT/common/inc/ngap_asn_dec_wrapper.h
    rm -f $L3SIM_ROOT/common/inc/ngap_asn_enc_dec_3gpp.h
    rm -f $L3SIM_ROOT/common/inc/ngap_asn_enc_wrapper.h
    rm -f $L3SIM_ROOT/common/inc/ngap_intf_mgmnt.h
    rm -f $L3SIM_ROOT/common/inc/ngap_tracing.h
    rm -f $L3SIM_ROOT/common/inc/ngap_types.h
    rm -f $L3SIM_ROOT/common/inc/ngap_utils.h
    rm -f $L3SIM_ROOT/common/src/ngap_3gpp.c
    rm -f $L3SIM_ROOT/common/src/ngap_asn_common_wrapper.c
    rm -f $L3SIM_ROOT/common/src/ngap_asn_dec_wrapper.c
    rm -f $L3SIM_ROOT/common/src/ngap_asn_enc_dec_3gpp.c
    rm -f $L3SIM_ROOT/common/src/ngap_asn_enc_wrapper.c 
    rm -f $L3SIM_ROOT/common/inc/ngap_global_ctx.h 
    rm -f $L3SIM_ROOT/common/inc/ngap_api.h             
    rm -f $L3SIM_ROOT/common/inc/rrc_ngap_oam_intf.h     
    rm -f $L3SIM_ROOT/common/inc/gnb_common_utils.h
    rm -f $L3SIM_ROOT/common/inc/lteLogger.h
    rm -f $L3SIM_ROOT/common/inc/rrc_protocol_events.h
    rm -f $L3SIM_ROOT/common/src/hmac_sha256.c  
    rm -f $L3SIM_ROOT/common/inc/hmac_sha256.h   

    echo "*************************** CLEANING SIM ****************************"
    cd $L3SIM_ROOT/testing/
    make clean
fi
