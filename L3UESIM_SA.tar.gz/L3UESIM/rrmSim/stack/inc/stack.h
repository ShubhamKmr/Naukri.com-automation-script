#include "proto_stack.h"


/* This function creates and return protocol stack for RRM Sim */
proto_stack_t* create_rrm_sim_stack();


/* This function initializes the UE simulator */
//void init_x2_sim_stack(void* data);


/* This function processes the message received from eNB */
void process_rrm_sim_peer_msg(void* msg, unsigned int msgLen);


/* This function processes the message received from user */
void process_rrm_sim_user_msg(void* msg, unsigned int msgLen);


/* This function resets the RRM simulator stack */
void reset_rrm_sim_stack();
