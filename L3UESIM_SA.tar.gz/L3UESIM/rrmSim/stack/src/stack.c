/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>

/* Project includes */
#include "stack.h"
#include "proto_sim.h"
#include "proto_stack.h"
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "globalContext.h"


/* This function initializes the RRM simulator */
sim_return_val_et init_rrm_sim_stack(void* data)
{
    LOG_TRACE("RRM SIM stack initialization function invoked \n");
    return SIM_SUCCESS;
}


/* This function will forward the message to stack application */
void forward_msg_to_stack_app(
        void*         msgBuf,
        unsigned int  msgLen)
{
    proto_simulator_t* rrm_sim    = NULL;
    stack_app_t*       stack_app = NULL;

    /* Fetch pointer to object of RRM simulator */
    rrm_sim = get_proto_simulator(RRMSIM_ID);

    /* Fetch peer connection handler */
    stack_app = get_proto_stack_app(rrm_sim);
    if (NULL == stack_app)
    {
        LOG_TRACE("Failed to fetch RRM SIM stack app\n");
        return;
    }

    /* Invoke the send callback registered by 
     * peer connection handler. */
    stack_app->stack_msg_hdlr(msgBuf, msgLen);

    LOG_TRACE("Successfully forwarded msg from stack to stack app, len:%d \n", msgLen);
}


/* This function processes the message received from eNB */
void process_rrm_sim_peer_msg(
        void*         msg, 
        unsigned int  msgLen)
{
    LOG_TRACE("Process message received from protocol peer \n");

    forward_msg_to_stack_app(msg, msgLen);
}

/* This function processes the message received from user */
void process_rrm_sim_user_msg(void* apiBuf, unsigned int apiLen)
{
    LOG_TRACE("API received from stack app for destination\n");
}


/* This function resets the RRM simulator stack */
void reset_rrm_sim_stack()
{
    LOG_TRACE("RRM SIM stack Reset \n");
}


/* This function creates and return protocol stack for RRM Sim */
proto_stack_t* create_rrm_sim_stack()
{
    proto_stack_t*  stack = NULL;

    /* Allocate stack for RRM simulator */
    stack = allocate_new_protocol_stack();
    if (NULL == stack)
    {
        LOG_TRACE("Failed to allocate stack for RRM sim\n");
        return stack;
    }

    memset(stack, 0, sizeof(proto_stack_t));

    /* Initialize the function pointers of stack */
    stack->init          = init_rrm_sim_stack;
    stack->peer_msg_hdlr = process_rrm_sim_peer_msg;
    stack->user_msg_hdlr = process_rrm_sim_user_msg;

    return stack;
}
