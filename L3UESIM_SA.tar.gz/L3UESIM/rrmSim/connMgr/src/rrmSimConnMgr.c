#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "proto_peer_conn_mgr.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "rrmsim_stack_app_cmd_interpreter_intf.h"
#include "rrmConnMgr.h"
#include "rrmsim_peer_conn_hdlr.h"
#include "globalContext.h"
#include "rrmsim_common.h"
//#include "rrc_x2apAdapt_il_composer.h"
/* This function will forward the message to stack application */
void rrmsim_forward_msg_to_stack_app(
        void*         msgBuf,
        unsigned int  msgLen)
{
    proto_simulator_t* rrm_sim    = NULL;
    stack_app_t*       stack_app = NULL;

    /* Fetch pointer to object of RRM simulator */
    rrm_sim = get_proto_simulator(RRMSIM_ID);

    /* Fetch peer connection handler */
    stack_app = get_proto_stack_app(rrm_sim);
    if (NULL == stack_app)
    {
        LOG_TRACE("Failed to fetch RRM SIM stack app\n");
        return;
    }

    stack_app->stack_msg_hdlr(msgBuf, msgLen);

    LOG_TRACE("Successfully forwarded msg from RRMSIM conn Mgr to stack app, len:%d \n", msgLen);
}


/* This function handles control PDU request received from upper
 * layer */
void handle_rrm_control_pdu_req(unsigned short rrm_id, 
                                 unsigned char* p_api,
                                 unsigned int   apiLen)
{
    rrmsim_enb_conn_data_t* rrm_conn_data = NULL;
    peer_conn_hdlr_t*       p_conn_hdlr   = NULL;

    /* Fetch eNB connection data for this RRM ID received */
    rrm_conn_data = &gRRMSimConnMgrContext.rrm_conn_data[rrm_id]; 

    /* Fetch pointer to peer connection handler */
    p_conn_hdlr   = rrm_conn_data->peer_conn_hdlr.conn_hdlr;

    /* Invoke send function of connection handler */
    p_conn_hdlr->send(p_conn_hdlr->user_data, p_api, apiLen); 
}


/* This function builds and sends RRM Addition Reponse */
void build_and_send_rrm_addition_resp(
            unsigned short          rrm_id,
            rrmsim_response_code_et  response)
{
    rrmsim_stack_app_to_cmd_interpreter_ind_t  p_api;
    configure_rrm_resp_t*                    config_rrm_resp;
    unsigned int                               apiLen = 0;
    unsigned int                               msgLen = 0;

    /* Calculate message buffer length */
    msgLen = sizeof(configure_rrm_resp_t);

    /* Calculate API length */
    apiLen = sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t)  
               + msgLen;

    /* Populate header attributes */
    p_api.header.apiId  = CONFIGURE_RRM_RESP;
    p_api.header.length = apiLen;
    p_api.header.rrm_id = rrm_id;

    /* Allocate memory for API body */
    p_api.msgBuf = (unsigned char*)malloc(msgLen);

    if (NULL == p_api.msgBuf)
    {
        LOG_TRACE("Failed to allocate memory\n");
        return;
    }

    /* Get pointer to configure_enb_resp_t */
    config_rrm_resp  = (configure_rrm_resp_t*)p_api.msgBuf;

    /* Populate response */
    config_rrm_resp->response_code = response;

    /* Forward API to stack app */
    rrmsim_forward_msg_to_stack_app(&p_api, apiLen);
}


/* This function process received RRMSIM Addition Request 
 * from upper layer. */
sim_return_val_et
handle_rrm_addition_req(
        unsigned char  rrm_id,
        unsigned char* msgBuf)
{
    configure_rrm_req_t*    add_rrm_req     = NULL;
    rrmsim_comm_info_t*     local_comm_info = NULL;
    rrmsim_comm_info_t*     peer_comm_info  = NULL;
    peer_conn_hdlr_t*       peer_conn_hdlr  = NULL;
    sim_return_val_et       retVal          = SIM_FAILURE;

    /* Get pointer to RRM Addition Request */
    add_rrm_req     = (configure_rrm_req_t*)msgBuf;

    /* Fetch pointer local RRM communication info container */
    local_comm_info = &add_rrm_req->local_rrm_comm_info;

    /* Fetch pointer peer RRM communication info container */
    peer_comm_info  = &add_rrm_req->peer_rrm_comm_info;


  if(local_comm_info->bitmask & RRM_COMM_INFO_UDP_CONFIG_PARAM_PRESENT)
  {
        LOG_TRACE("RRM UDP \n");
    /* Create control plane connection handler for eNB */
    if (NULL == (peer_conn_hdlr = rrmsim_create_control_plane_peer_conn_hdlr(
                                      local_comm_info, 
                                      peer_comm_info)))
    {
        LOG_TRACE("Failed to create peer connection handler for"
                  "new RRMSIM Addition Request \n");
    }

    /* Register connection handler with RRM SIM peer connection 
     * manager. */
    else if (SIM_FAILURE == register_peer_conn_hdlr_with_peer_conn_mgr(
                                        RRMSIM_ID,
                                        peer_conn_hdlr))
    {
        LOG_TRACE("Failed to register peer connection handler with"
                   "peer connection manager \n");
    }
    else
    {
        unsigned int           index            = 0;
        rrmsim_enb_conn_data_t* p_rrm_conn_data = NULL;

        /* Store peer connection data in connection manager */
        for (index = 0; index < MAX_SUPPORTED_RRMSIM; index++)
        {
            p_rrm_conn_data = &gRRMSimConnMgrContext.rrm_conn_data[index];

            if (!p_rrm_conn_data->used)
            {
                p_rrm_conn_data->used   = 1;
                p_rrm_conn_data->rrm_id = rrm_id; 
                p_rrm_conn_data->peer_conn_hdlr.conn_hdlr 
                                        = peer_conn_hdlr; 

                retVal = SIM_SUCCESS;

                LOG_TRACE("Peer RRMSIM successfully added through UDP connection\n");

                break;
            }
        }

    }
  }

    /* Build and send RRM Addition Response based on return value */
    if (SIM_SUCCESS == retVal)
    {
        build_and_send_rrm_addition_resp(rrm_id, SUCCESS_RSP);
    }
    else
    {
        /* TODO: In case of failure, need to free the connection 
         * handler and connection listener. */
        build_and_send_rrm_addition_resp(rrm_id, FAILURE_RSP);
    }

    return retVal;
}


/* This function receives new messages received from 
 * internal modules */
void rrmsim_internal_msg_hdlr(
        void*        msgBuf, 
        unsigned int msgLen)
{
    rrmsim_cmd_interpreter_to_stack_app_req_t* p_api  = NULL;
    unsigned char                             rrm_id = 0;
    unsigned short                            api_id = 0;
    unsigned int                              apiLen = 0;

    /* Ensure that received pointer is valid */
    if (NULL == msgBuf)
    {
        LOG_TRACE("Received invalid message buffer \n");
        return;
    }

    /* Get pointer to the received API buffer */
    p_api = (rrmsim_cmd_interpreter_to_stack_app_req_t*)msgBuf;

    /* Fetch API ID */
    api_id = p_api->header.apiId;

    /* Fetch eNB ID */
    rrm_id = p_api->header.rrm_id;

    /* Calculate API length */
    apiLen = p_api->header.length - sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);

    switch(api_id)
    {
        case RRM_ADDITION_REQ:
        {
            LOG_TRACE("RRM Addition Request received, rrm_id: %d\n", 
                      rrm_id);

            handle_rrm_addition_req(rrm_id, p_api->msgBuf);
            break;
        }

        case RRM_CONTROL_PDU_REQ:
        {
            LOG_TRACE("Control PDU receved from upper layer for RRM ID: %d \n",
                      rrm_id);

            handle_rrm_control_pdu_req(rrm_id, p_api->msgBuf, apiLen);
            break;
        }

        default:
        {
            LOG_TRACE("Unknown internal API received: %d\n", api_id);
            break;
        }
    }

    /* Free memory of message buffer */
    //free(p_api->msgBuf);
}


/* Process received message from peer eNBRRM */
void process_peer_enb_rrm_control_msg(
        unsigned char* msgBuf, 
        unsigned int   msgLen,
        unsigned short rrm_id)
{
    rrmsim_stack_app_to_cmd_interpreter_ind_t p_api;
    unsigned int                             apiLen = 0;

    /* Calculate API length */
    apiLen = msgLen + sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);

    /* Populate header attributes */
    p_api.header.apiId  = RRM_CONTROL_PDU_IND;
    p_api.header.length = apiLen;
    p_api.header.rrm_id = rrm_id;

    /* Allocate memory for API body */
    p_api.msgBuf = (unsigned char*)malloc(msgLen);

    if (NULL == p_api.msgBuf)
    {
        LOG_TRACE("Failed to allocate memory\n");
        return;
    }

    memcpy(p_api.msgBuf, msgBuf, msgLen);

    LOG_TRACE("MSG LEN of RRM CONTROL MSG %d \n", apiLen);

    /* Forward API to stack app */
    rrmsim_forward_msg_to_stack_app(&p_api, apiLen);

    /* Free memory buffer */
    free(msgBuf);
}


/* This function receives new messages received from 
 * peer and process them. */
void rrmsim_conn_mgr_peer_msg_hdlr(
        void* peer_conn_data)
{
    rrmsim_enb_conn_data_t* rrm_conn_data  = NULL;
    peer_conn_hdlr_t*       conn_hdlr      = NULL;
    unsigned char*          msgBuf         = NULL;
    unsigned int            msgLen         = 0;

    /* Get peer connection handler from received pointer */
    rrm_conn_data = (rrmsim_enb_conn_data_t*)peer_conn_data;

    /* Fetch connection handler */
    conn_hdlr = rrm_conn_data->peer_conn_hdlr.conn_hdlr;

    /* Call receive API to read message from socket */
    msgLen = conn_hdlr->receive(conn_hdlr->user_data, 
                                (void*)&msgBuf);
   
    if ((msgLen == 0) || (msgBuf == NULL))
    {
        LOG_TRACE("Invalid message received, msgLen: %d, msgBuf: %p\n", 
                  msgLen, msgBuf);
        return;
    }

    LOG_TRACE("Message received from peer, RRM ID: %d\n", 
              rrm_conn_data->rrm_id);

    /* Process received message from peer eNB */
    process_peer_enb_rrm_control_msg(
                        msgBuf, 
                        msgLen, 
                        rrm_conn_data->rrm_id);
}


/* This function activates the pending connection handlers */
void rrmsim_conn_mgr_activate(void* pData)
{
    rrmsim_conn_mgr_context_t* gContext      = pData;
    rrmsim_enb_conn_data_t*    rrm_conn_data = NULL;
    peer_conn_hdlr_t*         conn_hdlr     = NULL;
    unsigned short            index         = 0;
    int                       sockFd        = -1;

    /* Traverse through the list of all registered eNBs and activate 
     * their peer connection handler and connection listener. */
    for (index = 0; index < MAX_SUPPORTED_RRMSIM; index++)
    {
        /* Fetch pointer to eNB connection data */
        rrm_conn_data = &gContext->rrm_conn_data[index];

        if (rrm_conn_data->used)
        {
            /* Activate peer connection client */
            if (!rrm_conn_data->peer_conn_hdlr.isActivated)
            {
                conn_hdlr = rrm_conn_data->peer_conn_hdlr.conn_hdlr;

                /* Store peer connection data in connection manager */
                gRRMSimConnMgrContext.rrm_conn_data[index].
                    peer_conn_hdlr.conn_hdlr = conn_hdlr;

                LOG_TRACE("RRM Peer conn handler is stored in global context \n");

                if (NULL != conn_hdlr)
                {
                    /* Call open of the connection handler */
                    sockFd = conn_hdlr->open(conn_hdlr->user_data);

                    if (0 > sockFd)
                    {
                        LOG_TRACE("Failed to open connection handler for RRM ID: %d\n",
                                  rrm_conn_data->rrm_id);
                    }

                    /* Register socket FD with epoll FD for receive notifications */
                    else if (SIM_FAILURE == register_peer_conn_fd_for_receive_notifications(
                                                        RRMSIM_ID,
                                                        sockFd,
                                                        PEER_CONNECTION_HDLR,
                                                        rrm_conn_data))
                    {
                        LOG_TRACE("Failed to register socket FD of client with"
                                  " epoll FD for RRMSIM \n");

                        /* Close the connection */
                        conn_hdlr->close(conn_hdlr->user_data);
                    }

                    else
                    {
                        LOG_TRACE("Successfully open connection handler for RRM ID:%d\n", 
                                  rrm_conn_data->rrm_id);

                        /* Set the flag to indicate that this handler is activated */
                        rrm_conn_data->peer_conn_hdlr.isActivated = 1;
                    }
                }
            }
        }
    }

}


/* This function initializes the peer connection mgr */
void 
rrmsim_peer_conn_mgr_accept(void* data)
{
    LOG_TRACE("RRM sim peer connection Accept \n");

    return ;
}

/* This function initializes the peer connection mgr */
sim_return_val_et 
rrmsim_peer_conn_mgr_init(void* data)
{
    LOG_TRACE("RRM sim peer connection manager init \n");

    return SIM_SUCCESS;
}


/* Create RRM SIM peer connection manager */
peer_conn_mgr_t*
create_rrm_sim_peer_conn_mgr()
{
    peer_conn_mgr_t*  peer_conn_mgr = NULL;

    /* Allocate peer connection manager */
    peer_conn_mgr = allocate_new_peer_conn_mgr();
    if (NULL == peer_conn_mgr)
    {
        LOG_TRACE("Failed to create peer connection mgr for RRM sim\n");
        return peer_conn_mgr;
    }

    memset(peer_conn_mgr, 0, sizeof(peer_conn_mgr_t));

    /* Initializes the callbacks of peer connection mgr */
    peer_conn_mgr->init              = rrmsim_peer_conn_mgr_init;
    peer_conn_mgr->connect_req_hdlr  = rrmsim_peer_conn_mgr_accept;
    peer_conn_mgr->peer_msg_hdlr     = rrmsim_conn_mgr_peer_msg_hdlr;
    peer_conn_mgr->internal_msg_hdlr = rrmsim_internal_msg_hdlr;
    peer_conn_mgr->activate          = rrmsim_conn_mgr_activate;
    peer_conn_mgr->user_data         = (void*)&gRRMSimConnMgrContext; 

    return peer_conn_mgr;
}

