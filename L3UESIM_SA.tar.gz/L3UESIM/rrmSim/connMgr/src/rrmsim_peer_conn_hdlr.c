/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/sctp.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/sctp.h>
#include <time.h>
#include <sys/time.h>
/* Project Includes */
#include "rrmsim_peer_conn_hdlr.h"

/* UDP Socket changes */
/* This function initializes the peer connection handler */
sim_return_val_et 
rrm_sim_control_plane_conn_hdlr_udp_init(void* data)
{
    peer_conn_data_t* pData = NULL;
    
    (void)pData; // Unused Arg

    LOG_TRACE("RRM sim peer UDP connection handler init \n");

    return SIM_SUCCESS;
}

/* This function open the peer connection handler */
int 
rrm_sim_control_plane_conn_hdlr_udp_open(void* user_data)
{
    LOG_TRACE("RRM sim peer UDP connection handler open \n");

    int                         sockFd          = -1;
    //int                         return_value    = 0;  
    //int                         addr_len        = 0; 
    peer_conn_data_t*           peer_conn_data  = NULL;
    rrmsim_comm_info_t*         local_comm_info = NULL;
    struct                      sockaddr_in selfAddr;

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    local_comm_info = &peer_conn_data->local_rrm_comm_info;

    memset(&selfAddr, 0, sizeof(selfAddr));

    /* Create a UDP socket FD  */
    if ((sockFd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        LOG_TRACE("Failed to create UDP socket, errno:%d \n", errno);
        return SIM_FAILURE;
    }

    LOG_TRACE("UDP socket created with FD %d for RRMSIM\n", sockFd);

    /* Bind created socket with address */
    {
        selfAddr.sin_family      = AF_INET;
        selfAddr.sin_addr.s_addr = inet_addr((const char*)&local_comm_info->ipv4_addr[0].ip_addr);
        selfAddr.sin_port        = htons(local_comm_info->port);

        if (bind(sockFd, (struct sockaddr *)&selfAddr, sizeof(selfAddr)) < 0) 
        {
            LOG_TRACE("Server bind failure, errno: %d\n", errno);

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("Bind Successfull for SD and port %d %d for RRMSIM\n", sockFd,selfAddr.sin_port);
    }

    /* Store socket FD in peer connection data for further use */
    peer_conn_data->sockFd = sockFd;

    return sockFd;
}


/* This function initiates connection with the peer and register
 * FD with epoll FD for receive notifications. */
sim_return_val_et
rrm_sim_control_plane_conn_hdlr_udp_connect(void* user_data)
{

    LOG_TRACE("Do nothing for UDP Socket \n");

    return SIM_SUCCESS;
}

 
/* This function close the peer connection handler */
void rrm_sim_control_plane_conn_hdlr_udp_close(void* user_data)
{
    peer_conn_data_t*  peer_conn_data = NULL;

    LOG_TRACE("RRM sim UDP peer connection handler close \n");

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Close the socket connection */
    close(peer_conn_data->sockFd);
}


/* This function is used to send the packet to peer */
void rrm_sim_control_plane_conn_hdlr_udp_send(
        void*          user_data, 
        void*          apiBuf,
        unsigned short apiLen)
{
    peer_conn_data_t*           peer_conn_data = NULL;
    struct sockaddr_in          peeraddr;
    rrmsim_comm_info_t*         peer_comm_info = NULL;


    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Fetch pointer to peer communication info */
    peer_comm_info  = &peer_conn_data->peer_rrm_comm_info;

    peeraddr.sin_family  = AF_INET;
    peeraddr.sin_port    = htons(peer_comm_info->port);
    peeraddr.sin_addr.s_addr  = inet_addr((const char*)peer_comm_info->ipv4_addr[0].ip_addr);

    LOG_TRACE("[APIX]:- RRM sim peer UDP connection handler send with port %d....b4htos(%u)\n",
                  peeraddr.sin_port,peer_comm_info->port);

   /* Send message to the Peer */
    if (-1 == sendto(peer_conn_data->sockFd,
                     apiBuf, apiLen, 0,
                     (struct sockaddr*)&peeraddr,
                     sizeof(struct sockaddr_in)))
    {
        fprintf(stderr, "Failed to send API to sim, errno: %d\n",
                errno);
    }
}


/* This function is used to receive packet from peer */
unsigned int 
rrm_sim_control_plane_conn_hdlr_udp_receive(
        void*  user_data,
        void** recvBuf)
{
    peer_conn_data_t*       peer_conn_data = NULL;
    ssize_t                 msgLen         = 0;
    size_t                  buflen         = 0;
    //void*                   retBuf         = NULL; 
    struct                  sockaddr_in  sock_addr;
    //int                     addrLen        = 0; 
    socklen_t                     addrLen        = 0; 

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Allocate memory for recv buffer */
    buflen = 65535;

    if ((*recvBuf = malloc(buflen)) == NULL) 
    {
        LOG_TRACE("out of memory, malloc failed for msg data buffer.\n");
        return msgLen;
    }

    addrLen = sizeof(sock_addr);

    /* Read message from the socket */
    msgLen = recvfrom(peer_conn_data->sockFd, *recvBuf,
                      buflen, 0, (struct sockaddr *)&sock_addr,
                      &addrLen);

    if (-1 == msgLen)
    {
        fprintf(stderr,"Error while reading from socket: %d\n", errno);
        return msgLen;
    }

    /*if (NULL != *recvBuf)
    {
        free(*recvBuf);
        *recvBuf = NULL;
    }*/

    return msgLen;

}


/* Create control plane peer connection handler for eNB */
peer_conn_hdlr_t*
rrmsim_create_control_plane_peer_conn_hdlr(
        rrmsim_comm_info_t* local_comm_info,
        rrmsim_comm_info_t* peer_comm_info)
{
    peer_conn_hdlr_t*  peer_conn_hdlr = NULL;
    peer_conn_data_t*  conn_hdlr_data = NULL;

    /* Allocate peer connection handler */
    peer_conn_hdlr = allocate_new_peer_conn_hdlr();
    if (NULL == peer_conn_hdlr)
    {
        LOG_TRACE("Failed to create peer UDP connection hdlr for RRMsim\n");
        return peer_conn_hdlr;
    }

    memset(peer_conn_hdlr, 0, sizeof(peer_conn_hdlr_t));

    /* Initializes the function pointers of peer connection handler */
    peer_conn_hdlr->init    = rrm_sim_control_plane_conn_hdlr_udp_init;
    peer_conn_hdlr->open    = rrm_sim_control_plane_conn_hdlr_udp_open;
    peer_conn_hdlr->connect = rrm_sim_control_plane_conn_hdlr_udp_connect;
    peer_conn_hdlr->close   = rrm_sim_control_plane_conn_hdlr_udp_close;
    peer_conn_hdlr->send    = rrm_sim_control_plane_conn_hdlr_udp_send;
    peer_conn_hdlr->receive = rrm_sim_control_plane_conn_hdlr_udp_receive;

    /* Store connection data in user data of peer connection handler */
    {
        /* Allocate memory for peer connection data */
        conn_hdlr_data = (peer_conn_data_t*)malloc(
                                     sizeof(peer_conn_data_t));
        if (NULL == conn_hdlr_data)
        {
            LOG_TRACE("Failed to allocate memory for peer connection data \n");
            return peer_conn_hdlr;
        }

        /* Reset memory allocated for peer connection data */
        memset(conn_hdlr_data, 0, sizeof(peer_conn_data_t));

        /* Copy local communication info */
        memcpy(&conn_hdlr_data->local_rrm_comm_info,
               local_comm_info,
               sizeof(rrmsim_comm_info_t));

        /* Copy peer communication info */
        memcpy(&conn_hdlr_data->peer_rrm_comm_info,
               peer_comm_info,
               sizeof(rrmsim_comm_info_t));

        /* Store connection data in peer connection handler */
        peer_conn_hdlr->user_data = conn_hdlr_data;
    }

    return peer_conn_hdlr;
}

/* UDP Socket changes */
