#ifndef __RRMSIM_PEER_CONN_HDLR_H__
#define __RRMSIM_PEER_CONN_HDLR_H__

#include "rrmsim_common.h"
#include "proto_peer_conn_hdlr.h"

/* Structure defining the content of peer connection 
 * handler configuration data */
typedef struct
{
    /* Socket FD */
    unsigned int               sockFd;

    /* UDP Communication information of local eNB */
   rrmsim_comm_info_t          local_rrm_comm_info;

    /* UDP Communication information of Peer eNB */
   rrmsim_comm_info_t          peer_rrm_comm_info;

} peer_conn_data_t;


/* Create control plane peer connection handler for eNB */
peer_conn_hdlr_t*
x2sim_create_control_plane_peer_conn_hdlr(
        rrmsim_comm_info_t* local_comm_info,
        rrmsim_comm_info_t* peer_comm_info);
peer_conn_hdlr_t*
rrmsim_create_control_plane_peer_conn_hdlr(
        rrmsim_comm_info_t* local_comm_info,
        rrmsim_comm_info_t* peer_comm_info);



#endif  // __RRMSIM_PEER_CONN_HDLR_H__
