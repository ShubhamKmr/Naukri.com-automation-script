
#define MAX_SUPPORTED_RRMSIM 8

/* APIs exposed by peer connection manager */
typedef enum
{
    RRM_ADDITION_REQ = 1,
    RRM_ADDITION_RESP,
    RRM_CONTROL_PDU_IND,
    RRM_CONTROL_PDU_REQ
} rrmsim_conn_mgr_api_et;


/* Structure defining the content of API used for 
 * delivering the control plane message received
 * from RRM to upper layers. */
typedef struct
{
    /* Message buffer */
    unsigned char   msgBuf[1];
} rrmsim_enb_control_pdu_ind_t;


/* Structure defining the content of API used for 
 * delivering the control plane message from upper
 * layers to peer RRM */
typedef struct
{
    /* Message buffer */
    unsigned char   msgBuf[1];
} rrmsim_enb_control_pdu_req_t;


/* Structure defining the content of API used for adding 
 * a new ENB at RRMSIM which will be used for testing a 
 * peer eNB. */
typedef struct
{
    /* UDP Communication information of local eNB */
   rrmsim_comm_info_t          local_rrm_comm_info;

    /* UDP Communication information of Peer eNB */
   rrmsim_comm_info_t          peer_rrm_comm_info;

} rrm_addition_req_t;  /* RRM_ADDITION_REQ */


/* Structure defining the content of API used for sending 
 * the response of RRMSIM ADDITION REQ. */
typedef struct
{
    /* Indicates the result of RRM addition Request */
    unsigned char   response_code;

} rrm_addition_resp_t;  /* RRM_ADDITION_RESP */


/* Structure defining the content of peer connection handler */
typedef struct
{
    /* Flag to indicate if this conneciton handler is 
     * already activated */
    unsigned char     isActivated;

    /* Pointer to peer connection handler */
    peer_conn_hdlr_t* conn_hdlr;

} rrmsim_peer_conn_hdlr_data_t;


/* Structure defining the content of connection data for a 
 * particular eNB configured at RRM simulator. */
typedef struct
{
    /* Flag to indicate whether this entry is in use or not */
    unsigned char                   used;

    /* Unique eNB Identifier */ 
    unsigned char                   rrm_id;

    /* Array of peer connection handlers */
    rrmsim_peer_conn_hdlr_data_t     peer_conn_hdlr;

} rrmsim_enb_conn_data_t;


/* Structure used for storing the information used for
 * operation of connection manager. */
typedef struct
{
    /* Map of eNB IDs and their connections data */
    rrmsim_enb_conn_data_t     rrm_conn_data[MAX_SUPPORTED_RRMSIM];

} rrmsim_conn_mgr_context_t;


/* Object of RRM SIM connection manager */
rrmsim_conn_mgr_context_t  gRRMSimConnMgrContext;


/* This function creates and return peer connection manager */
peer_conn_mgr_t* create_rrm_sim_peer_conn_mgr();


