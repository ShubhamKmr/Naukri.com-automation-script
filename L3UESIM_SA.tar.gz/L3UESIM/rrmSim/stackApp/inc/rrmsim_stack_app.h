#ifndef _RRMSIM_STACK_APP_H_ 
#define _RRMSIM_STACK_APP_H_

/* This file contains definitions of X2 SIM stack app functions */
#include "proto_stack_app.h"

#define MAX_SUPPORTED_RRM 8



/* Structure defining the content of RRMSIM context */
typedef struct
{
    /* Flag to indicate if RRM context is in use or not */
    bool                         inUse;

    /* Unique eNB Identifier */
    unsigned int                 rrm_id;

} rrmsim_rrm_context_t;

#if 0
/* Structure defining the global content of X2SIM stack 
 * application */
typedef struct _x2sim_global_context_t
{
    /* Array of UE contexts indexed by their IMSI */
    x2sim_ue_context_t   ue_contexts[MAX_SUPPORTED_UE];

    /* Array of eNB contexts indexed by their ID */
    x2sim_enb_context_t  enb_contexts[MAX_SUPPORTED_ENB];

} x2sim_global_context_t;


/* Object of X2SIM global context */
x2sim_global_context_t  gStackAppContext;



/*****************************************************************
 * PUBLIC FUNCTIONS
 ****************************************************************/

/* This function allocates a new eNB context and return to the
 * caller */
x2sim_enb_context_t* allocate_x2sim_enb_context();


/* This function free the pre-allocated eNB context */
void free_x2sim_enb_context(
        x2sim_enb_context_t*  enb_ctx);


/* This function fetch and return eNB context based on eNB ID 
 * passed by caller */
x2sim_enb_context_t* x2sim_get_enb_context(
        unsigned int          enb_id);


/* This function allocates a new UE context and return to caller */
x2sim_ue_context_t* allocate_x2sim_ue_context(
        unsigned int imsi);


/* This function fetch and return UE context based on MeNB UE X2AP ID 
 * and MeNB UE X2AP ID extension passed by caller */
x2sim_ue_context_t* x2sim_get_ue_context(
                         unsigned short menb_ue_x2ap_id, 
                         unsigned int   menb_ue_x2ap_id_extn);
#endif

/* This function creates and return stackApp for RRM sim */
stack_app_t* create_rrm_sim_stack_app();


/* This function initializes the RRM sim stack app */
sim_return_val_et rrm_sim_stack_app_init();


void rrmsim_forward_msg_to_cmd_interpreter(
        void*         apiBuf,
        unsigned int  apiLen);

void deallocate_rrmsim_ue_context(unsigned int imsi);

void rrmsim_forward_msg_to_conn_mgr(unsigned char* msgBuf,
                                   unsigned int   length);

#endif  // _RRMSIM_STACK_APP_H_
