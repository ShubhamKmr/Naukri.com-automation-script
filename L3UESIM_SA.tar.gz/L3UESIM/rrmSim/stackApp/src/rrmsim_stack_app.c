/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "rrmsim_stack_app.h"
#include "rrmsim_composer.h"
#include "rrmsim_stack_app_cmd_interpreter_intf.h"
#include "typedefs.h"
#include "proto_sim.h"
#include "globalContext.h"

/* This function sends message to connection manager */
void rrmsim_forward_msg_to_conn_mgr(unsigned char* msgBuf,
                                   unsigned int   length)
{
    proto_simulator_t* rrm_sim   = NULL;

    peer_conn_mgr_t*   pConnMgr = NULL;

    /* Fetch pointer to object of RRM simulator */
    rrm_sim = get_proto_simulator(RRMSIM_ID);

    /* Fetch peer connection manager */
    pConnMgr = get_proto_peer_conn_mgr(rrm_sim);

    pConnMgr->internal_msg_hdlr(msgBuf, length);
}


/* This function forwards a message from stack application
 * to command interpreter. */
void rrmsim_forward_msg_to_cmd_interpreter(
        void*         apiBuf, 
        unsigned int  apiLen)
{
    proto_simulator_t* rrm_sim          = NULL;
    cmd_interpreter_t* pCmdInterpreter = NULL;

    /* Fetch pointer to object of RRM simulator */
    rrm_sim = get_proto_simulator(RRMSIM_ID);

    /* Fetch peer connection handler */
    pCmdInterpreter = get_cmd_interpreter(rrm_sim);

    /* Invoke the command interpreter callback registered
     * for processing incoming messages from stack app */
    pCmdInterpreter->stack_app_msg_hdlr(apiBuf, apiLen);
}

/* Function to send PLATFORM IND to stack */


void handle_rrm_platform_ind(
        unsigned char*        msgBuf)
{

	rrmsim_cmd_interpreter_to_stack_app_req_t* request            = NULL;
	platform_load_ind_t*                      platform_load_ind   = NULL;
	platform_rrm_load_ind_t*                  local_rrm_load_ind  = NULL;
	unsigned char*                            pEncodedMsg         = NULL;
    	//unsigned char*                            p_msg               = NULL;
	unsigned char*                            p_rrm_msg           = NULL;
	unsigned short                            msg_length          = 0;
	unsigned short                            msg_api_length      = 0;
	unsigned short                            transaction_id      = 0;
	unsigned short                            cell_index          = 0;

	rrmsim_cmd_interpreter_to_stack_app_req_t  user_req;

	LOG_TRACE("PLATFORM IND received from command interpreter to stack app \n");
	/* Get pointer to request message */
	request = (rrmsim_cmd_interpreter_to_stack_app_req_t*)msgBuf;

	platform_load_ind = (platform_load_ind_t*)request->msgBuf;

	local_rrm_load_ind = &(platform_load_ind->rrm_load_ind);

	/* Get API length */
	msg_length =  gnb_il_get_platform_rrm_load_ind_len(local_rrm_load_ind);

	LOG_TRACE("PLATFORM IND Length %d\n",msg_length);

	/* Allocate buffer */
	msg_api_length = msg_length + RRM_INTERFACE_API_HEADER_SIZE;

	pEncodedMsg = malloc(msg_api_length);
	if(pEncodedMsg == NULL)
	{
		/* Not enough memory */
		LOG_TRACE("Not enough memory for LOAD IND \n");
		return;
	}
	memset(pEncodedMsg,0,msg_api_length);
	p_rrm_msg = pEncodedMsg;

	/* Fill interface header */
	rrm_construct_interface_api_header(p_rrm_msg,
			transaction_id,
			OAM_MODULE_ID,
			RRM_MODULE_ID,
			RRM_PLATFORM_LOAD_IND,
                        msg_length,
			cell_index);

	/* Fill RRM_PLATFORM_LOAD_IND message */
	p_rrm_msg = p_rrm_msg + RRM_INTERFACE_API_HEADER_SIZE;

	if (0 == gnb_il_compose_platform_rrm_load_ind(&p_rrm_msg, local_rrm_load_ind))
	{
		LOG_TRACE("PLATFORM IND Composing Failed \n");

		free(p_rrm_msg);

		return;
	}

	int i = 0;

	for(i=0;i<30;i++)
		fprintf(stderr,"RRM_PLATFORM_LOAD_IND Index %d Value[%d]\n",i,pEncodedMsg[i]);

	memset(&user_req, 0, sizeof(rrmsim_cmd_interpreter_to_stack_app_req_t));

	/* Populate target API to be forwarded to connection manager */
	user_req.header.apiId  = 4;
	user_req.header.length = msg_api_length
		+ sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);
	user_req.header.rrm_id = request->header.rrm_id;
	user_req.msgBuf        = pEncodedMsg;

	/* Forward message to connection manager */
	rrmsim_forward_msg_to_conn_mgr((unsigned char*)&user_req,
			user_req.header.length);

	return;
}


/* This function handles configure RRM request received
 * from command interpreter. */
void handle_configure_rrm_request(unsigned char* msgBuf)
{
    rrmsim_cmd_interpreter_to_stack_app_req_t*  
                          request   = NULL;

    request = (rrmsim_cmd_interpreter_to_stack_app_req_t*)msgBuf;

    /* Update RRM ID in the API header before forwarding
     * to connection manager */
    request->header.rrm_id = 0;

    /* Forward API to connection manager */
    rrmsim_forward_msg_to_conn_mgr(msgBuf, 
                                  request->header.length);
}

/* This function processes the messages received from command interpreter */
void rrm_sim_stack_app_user_msg_hdlr(void* msgBuf) 
{
    /* Fetch API ID from the received message buffer */
    unsigned short                             apiId   = 0;
    //unsigned int                               imsi    = 0;
    rrmsim_cmd_interpreter_to_stack_app_req_t*  request = NULL;


    if (NULL == msgBuf)
    {
        LOG_TRACE("Invalid pointer received \n");
        return;
    }

    /* Get pointer to the received API buffer */
    request = (rrmsim_cmd_interpreter_to_stack_app_req_t*)msgBuf;

    /* Fetch API ID */
    apiId = request->header.apiId;

    /* Fetch IMSI from the request */
   // imsi = request->header.imsi;

    switch(apiId)
    {
        case CONFIGURE_RRM_REQ:
        {
            LOG_TRACE("Configure RRM Request received from cmd interpreter, apiId: %d\n", apiId);
            handle_configure_rrm_request(msgBuf);
            break;
        }

        case PLATFORM_IND:
        {
            LOG_TRACE("PLATFORM IND received from cmd interpreter, apiId: %d\n", apiId);
            handle_rrm_platform_ind(msgBuf);
            break;
        }

        default:
        {
            LOG_TRACE("Unsupported API received from cmd interpreter, apiID: %d\n",
                      apiId);

            /* Free the message buffer memory */
            free(request->msgBuf);

            break;
        }

    }
}

/* This function processes the configure RRM response received
 * from connection manager */
void handle_configure_rrm_response(
                    unsigned short rrm_id,
                    unsigned char* msgBuf,
                    unsigned int   msgLen)
{
    rrmsim_stack_app_to_cmd_interpreter_ind_t  api;
    configure_rrm_resp_t*  config_rrm_resp     = NULL;
    configure_rrm_resp_t*  src_config_rrm_resp = NULL;
    unsigned int           apiLen              = 0;

    /* Fetch pointer to source API buffer */
    src_config_rrm_resp = (configure_rrm_resp_t*)msgBuf;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(rrmsim_stack_app_to_cmd_interpreter_ind_t));

    /* Calculate API length */
    apiLen = sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t) + 
                 sizeof(configure_rrm_resp_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId      = CONFIGURE_RRM_RESP; 
        api.header.length     = apiLen;
        api.header.rrm_id     = rrm_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(configure_rrm_resp_t));
        memset(api.msgBuf, 0, sizeof(configure_rrm_resp_t));
    }

    /* Populate API body */
    {
        config_rrm_resp = (configure_rrm_resp_t*)api.msgBuf;

        config_rrm_resp->response_code 
                    = src_config_rrm_resp->response_code;
    }

    /* Forward API to cmd interpreter */
    rrmsim_forward_msg_to_cmd_interpreter(&api, apiLen);
}

/* This function processes the messages received from RRM sim stack */
void rrm_sim_stack_app_stack_msg_hdlr(
        void*         p_api, 
        unsigned int  apiLen) 
{
    LOG_TRACE("Message received from RRM sim stack, length:%d\n",
              apiLen);

    rrmsim_stack_app_to_cmd_interpreter_ind_t* apiBuf = NULL;
    unsigned int                              bufLen = 0;
    
    apiBuf = (rrmsim_stack_app_to_cmd_interpreter_ind_t*)p_api;

    /* Calculate API buffer length */
    bufLen = apiBuf->header.length - 
                sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);

    switch(apiBuf->header.apiId)
    {
        case CONFIGURE_RRM_RESP:
        {
            LOG_TRACE("CONFIGURE_RRM_RESP received from conn Mgr\n");

            handle_configure_rrm_response(apiBuf->header.rrm_id,
                                          apiBuf->msgBuf,
                                          bufLen);
            break;
        }

        default:
        {
            LOG_TRACE("Unknown API received from conn Mgr\n");
            break;
        }
    }
}

/* This function initializes the RRM sim stack app */
sim_return_val_et rrm_sim_stack_app_init()
{
    LOG_TRACE("Initialization of RRM sim stack app \n");
    return SIM_SUCCESS;
}


/* This function creates and return stackApp for RRM sim */
stack_app_t* create_rrm_sim_stack_app()
{
    stack_app_t* stackApp = NULL;

    /* Allocate stackApp for RRM simulator */
    stackApp = allocate_new_protocol_stack_app();
    if (NULL == stackApp)
    {
        LOG_TRACE("Failed to allocate stack app for RRM sim\n");
        return stackApp;
    }

    /* Initializes the function pointers of stack app */
    stackApp->init           = rrm_sim_stack_app_init;
    stackApp->stack_msg_hdlr = rrm_sim_stack_app_stack_msg_hdlr;
    stackApp->user_msg_hdlr  = rrm_sim_stack_app_user_msg_hdlr;

    return stackApp;
}


