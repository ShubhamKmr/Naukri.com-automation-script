/* Local RRM SIM Composer File */
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <ctype.h>
#include "rrmsim_composer.h"
#include <string.h>

#define ARRSIZE(array_name) (sizeof(array_name) / sizeof(array_name[0]))

void
rrm_construct_interface_api_header
(
 UInt8                  *p_header,      /* RRM interface header */
 UInt16                 transaction_id, /* Interface transaction identifier */
 rrm_module_id_t     src_module_id,  /* Source module identifier */
 rrm_module_id_t     dst_module_id,  /* Destination module identifier */
 UInt16                 api_id,         /* API identifier */
 UInt16                 api_buf_size,   /* API buffer size */
 cell_index_t        cell_index      /* Cell Index */
 )
{
    /* transaction identifier (HI) */
    p_header[0] = (UInt8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (UInt8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (UInt8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (UInt8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (UInt8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (UInt8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (UInt8)((api_id & 0xFF00) >> 8);
    /* api id (LOW) */
    p_header[7] = (UInt8)(api_id & 0x00FF);

    /*size includes length of header*/
    api_buf_size = (UInt16)(api_buf_size + 16);

    /* api size (HI) */
    p_header[8] = (UInt8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (UInt8)(api_buf_size & 0x00FF);

    /* Celll Index (HI) */
    p_header[10] = (UInt8)((cell_index & 0xFF00) >> 8);

    /* Cell Index (LOW) */
    p_header[11] = (UInt8)(cell_index & 0x00FF);
    p_header[12]    = 0x00;
    p_header[13]    = 0x00;
    p_header[14]    = 0x00;
    p_header[15]    = 0x00;

}

bool
gnb_cp_pack_UInt8
(
    void    *p_dest,
    void    *p_src,
    char    *varname
)
{
    fprintf(stderr, "%s = %d", varname, *((UInt8 *)p_src));

    memcpy(p_dest, p_src, sizeof(UInt8));

    return 1;
}

bool
gnb_cp_pack_UInt16
(
    void    *p_dest,
    void    *p_src,
    char    *varname
)
{
    /* Packing UInt16 */

    ((UInt8*)p_dest)[0]    = (UInt8)((*(UInt16 *)p_src) >> 8);
    ((UInt8*)p_dest)[1]    = (UInt8)((*(UInt16 *)p_src));

    fprintf(stderr, "%s = %d", varname, *((UInt16 *)p_src));

    return 1;
}


//rach changes

bool
gnb_cp_unpack_UInt16
(
    void    *p_dest,
    void    *p_src,
    char    *varname
)
{
    /* Unpacking UInt16 */

    *(UInt16 *)p_dest  = 0;

    *(UInt16 *)p_dest  = (UInt16)(*(UInt16 *)p_dest | ((UInt8*)p_src)[0] << 8);
    *(UInt16 *)p_dest  = (UInt16)(*(UInt16 *)p_dest | ((UInt8*)p_src)[1]);

    //GNB_CP_TRACE(GNB_DETAILEDALL, "%s = %d", varname, *((UInt16 *)p_dest));
    //GNB_CP_TRACE(0x40, "%s = %d", varname, *((UInt16 *)p_dest));

    return 1;
}


bool
gnb_cp_pack_UInt32
(
    void    *p_dest,
    void    *p_src,
    char    *varname
)
{
    /* Packing UInt32 */

    ((UInt8*)p_dest)[0]    = (UInt8)((*(UInt32 *)p_src) >> 24);
    ((UInt8*)p_dest)[1]    = (UInt8)((*(UInt32 *)p_src) >> 16);
    ((UInt8*)p_dest)[2]    = (UInt8)((*(UInt32 *)p_src) >> 8);
    ((UInt8*)p_dest)[3]    = (UInt8)((*(UInt32 *)p_src));

    fprintf(stderr, "%s = %u", varname, *((UInt32 *)p_src));

    return 1;
}


static
bool
gnb_il_compose_rrm_oam_nr_global_cell_id
(
    UInt8  **pp_buffer,
    rrm_oam_nr_global_cell_id_t *p_rrm_oam_nr_global_cell_id
);

static
bool
gnb_il_compose_rrm_plat_cell_load
(
    UInt8  **pp_buffer,
    rrm_plat_cell_load_t *p_rrm_plat_cell_load
);

static
UInt16
gnb_il_get_rrm_oam_nr_global_cell_id_len
(
    rrm_oam_nr_global_cell_id_t *p_rrm_oam_nr_global_cell_id
);

static
UInt16
gnb_il_get_rrm_oam_cell_plmn_info_len
(
    rrm_oam_cell_plmn_info_t *p_rrm_oam_cell_plmn_info
);

static
bool
gnb_il_compose_rrm_oam_cell_plmn_info
(
    UInt8  **pp_buffer,
    rrm_oam_cell_plmn_info_t *p_rrm_oam_cell_plmn_info
);

static
UInt16
gnb_il_get_rrm_oam_nr_global_cell_id_len
(
    rrm_oam_nr_global_cell_id_t *p_rrm_oam_nr_global_cell_id
)
{
    UInt16 length = 0;

    //GNB_ASSERT(p_rrm_oam_nr_global_cell_id != GNB_PNULL);

    /* Get length of IE */
    length += gnb_il_get_rrm_oam_cell_plmn_info_len(&p_rrm_oam_nr_global_cell_id->primary_plmn_id);
    /* Get length of OCTET_STRING FIXED of basic type elements */
    length += sizeof(p_rrm_oam_nr_global_cell_id->nr_cell_identity);

    return length;
}

static
UInt16
gnb_il_get_rrm_plat_cell_load_len
(
    rrm_plat_cell_load_t *p_rrm_plat_cell_load
)
{
    UInt16 length = 0;

    //GNB_ASSERT(p_rrm_plat_cell_load != GNB_PNULL);
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_rrm_plat_cell_load->bitmask);

    /* Get length of IE */
    length += gnb_il_get_rrm_oam_nr_global_cell_id_len(&p_rrm_plat_cell_load->global_cell_id);

    /* Optional element */
    if(p_rrm_plat_cell_load->bitmask & RRM_CPU_LOAD_LEVEL_PRESENT)
    {
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_rrm_plat_cell_load->cpu_load_level);
    }

    /* Optional element */
    if(p_rrm_plat_cell_load->bitmask & RRM_MEMORY_LOAD_LEVEL_PRESENT)
    {
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_rrm_plat_cell_load->memory_load_level);
    }

    return length;
}

static
UInt16
gnb_il_get_rrm_oam_cell_plmn_info_len
(
    rrm_oam_cell_plmn_info_t *p_rrm_oam_cell_plmn_info
)
{
    UInt16 length = 0;

    //GNB_ASSERT(p_rrm_oam_cell_plmn_info != GNB_PNULL);
    /* Get length of OCTET_STRING FIXED of basic type elements */
    length += sizeof(p_rrm_oam_cell_plmn_info->mcc);
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_rrm_oam_cell_plmn_info->num_mnc_digit);
    /* Get length of OCTET_STRING VARIABLE of basic type elements */
    length += (p_rrm_oam_cell_plmn_info->num_mnc_digit * sizeof(p_rrm_oam_cell_plmn_info->mnc[0]));

    return length;
}

static
bool
gnb_il_compose_rrm_oam_cell_plmn_info
(
    UInt8  **pp_buffer,
    rrm_oam_cell_plmn_info_t *p_rrm_oam_cell_plmn_info
)
{
    //GNB_ASSERT(pp_buffer != GNB_PNULL);
    //GNB_ASSERT(*pp_buffer != GNB_PNULL);
    //GNB_ASSERT(p_rrm_oam_cell_plmn_info != GNB_PNULL);

    /* This function composes rrm_oam_cell_plmn_info */


    /* Compose OCTET_STRING FIXED of basic type elements */
    {
        UInt16 loop;
        for (loop = 0; loop < ARRSIZE(p_rrm_oam_cell_plmn_info->mcc); loop++)
        {
            gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_oam_cell_plmn_info->mcc[loop], "mcc[]");
            *pp_buffer += sizeof(UInt8);
        }
    }

    /* Check for correct range [B - both higher and lower boundaries] */
    if ((p_rrm_oam_cell_plmn_info->num_mnc_digit < 2) || (p_rrm_oam_cell_plmn_info->num_mnc_digit > 3))
    {
        fprintf(stderr, "Parameter [p_rrm_oam_cell_plmn_info->num_mnc_digit] should be in range "
            "2 to 3. Incorrect value %d received.", p_rrm_oam_cell_plmn_info->num_mnc_digit);
        return 0;
    }

    /* Compose parameter of basic type */
    gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_oam_cell_plmn_info->num_mnc_digit, "num_mnc_digit");
    *pp_buffer += sizeof(p_rrm_oam_cell_plmn_info->num_mnc_digit);
    /* Compose OCTET_STRING VARIABLE of basic type elements */
    {
        UInt16 loop;
        for (loop = 0; loop < p_rrm_oam_cell_plmn_info->num_mnc_digit; loop++)
        {
            gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_oam_cell_plmn_info->mnc[loop], "mnc[]");
            *pp_buffer += sizeof(UInt8);
        }
    }

    return 1;
}

UInt16
gnb_il_get_platform_rrm_load_ind_len
(
    platform_rrm_load_ind_t *p_platform_rrm_load_ind
)
{
    UInt16 length = 0;

    //GNB_ASSERT(p_platform_rrm_load_ind != GNB_PNULL);
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_platform_rrm_load_ind->bitmask);
    /* Get length of parameter of basic type */
    length += (UInt16)sizeof(p_platform_rrm_load_ind->num_of_cell);

    /* Check for correct range [B - both higher and lower boundaries] */
    if ((p_platform_rrm_load_ind->num_of_cell < 1) || (p_platform_rrm_load_ind->num_of_cell > RRM_MAX_NUM_CELLS))
    {
        fprintf(stderr, "Parameter [p_platform_rrm_load_ind->num_of_cell] should be in range "
            "1 to RRM_MAX_NUM_CELLS. Incorrect value %d received.", p_platform_rrm_load_ind->num_of_cell);
        return 0;
    }

    /* Get length of OCTET_STRING VARIABLE of IEs */
    {
        UInt16 loop;
        for (loop = 0; loop < p_platform_rrm_load_ind->num_of_cell; loop++)
        {
            length += gnb_il_get_rrm_plat_cell_load_len(&p_platform_rrm_load_ind->cell_load[loop]);
        }
    }

    return length;
}





static
bool
gnb_il_compose_rrm_oam_nr_global_cell_id
(
    UInt8  **pp_buffer,
    rrm_oam_nr_global_cell_id_t *p_rrm_oam_nr_global_cell_id
)
{
    //GNB_ASSERT(pp_buffer != GNB_PNULL);
    //GNB_ASSERT(*pp_buffer != GNB_PNULL);
    //GNB_ASSERT(p_rrm_oam_nr_global_cell_id != GNB_PNULL);

    /* This function composes rrm_oam_nr_global_cell_id */


    /* Compose IE */
    if (0 == gnb_il_compose_rrm_oam_cell_plmn_info(pp_buffer, &p_rrm_oam_nr_global_cell_id->primary_plmn_id))
    {
        return 0;
    }
    /* Compose OCTET_STRING FIXED of basic type elements */
    {
        UInt16 loop;
        for (loop = 0; loop < ARRSIZE(p_rrm_oam_nr_global_cell_id->nr_cell_identity); loop++)
        {
            gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_oam_nr_global_cell_id->nr_cell_identity[loop], "nr_cell_identity[]");
            *pp_buffer += sizeof(UInt8);
        }
    }

    return 1;
}

static
bool
gnb_il_compose_rrm_plat_cell_load
(
    UInt8  **pp_buffer,
    rrm_plat_cell_load_t *p_rrm_plat_cell_load
)
{
    //GNB_ASSERT(pp_buffer != GNB_PNULL);
    //GNB_ASSERT(*pp_buffer != GNB_PNULL);
    //GNB_ASSERT(p_rrm_plat_cell_load != GNB_PNULL);

    /* This function composes rrm_plat_cell_load */


    /* Compose parameter of basic type */
    gnb_cp_pack_UInt32(*pp_buffer, &p_rrm_plat_cell_load->bitmask, "bitmask");
    *pp_buffer += sizeof(p_rrm_plat_cell_load->bitmask);

    /* Compose IE */
    if (0 == gnb_il_compose_rrm_oam_nr_global_cell_id(pp_buffer, &p_rrm_plat_cell_load->global_cell_id))
    {
        return 0;
    }

    /* Optional element */
    if(p_rrm_plat_cell_load->bitmask & RRM_CPU_LOAD_LEVEL_PRESENT)
    {

    /* Check for correct range [B - both higher and lower boundaries] */
    if ((p_rrm_plat_cell_load->cpu_load_level < 1) || (p_rrm_plat_cell_load->cpu_load_level > 100))
    {
        fprintf(stderr, "Parameter [p_rrm_plat_cell_load->cpu_load_level] should be in range "
            "1 to 100. Incorrect value %d received.", p_rrm_plat_cell_load->cpu_load_level);
        return 0;
    }

    /* Compose parameter of basic type */
    gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_plat_cell_load->cpu_load_level, "cpu_load_level");
    *pp_buffer += sizeof(p_rrm_plat_cell_load->cpu_load_level);
    }

    /* Optional element */
    if(p_rrm_plat_cell_load->bitmask & RRM_MEMORY_LOAD_LEVEL_PRESENT)
    {

    /* Check for correct range [B - both higher and lower boundaries] */
    if ((p_rrm_plat_cell_load->memory_load_level < 1) || (p_rrm_plat_cell_load->memory_load_level > 100))
    {
        fprintf(stderr, "Parameter [p_rrm_plat_cell_load->memory_load_level] should be in range "
            "1 to 100. Incorrect value %d received.", p_rrm_plat_cell_load->memory_load_level);
        return 0;
    }

/* Compose parameter of basic type */
    gnb_cp_pack_UInt8(*pp_buffer, &p_rrm_plat_cell_load->memory_load_level, "memory_load_level");
    *pp_buffer += sizeof(p_rrm_plat_cell_load->memory_load_level);
    }

    return 1;
}

bool
gnb_il_compose_platform_rrm_load_ind
(
    UInt8  **pp_buffer,
    platform_rrm_load_ind_t *p_platform_rrm_load_ind
)
{
    //GNB_ASSERT(pp_buffer != GNB_PNULL);
    //GNB_ASSERT(*pp_buffer != GNB_PNULL);
    //GNB_ASSERT(p_platform_rrm_load_ind != GNB_PNULL);

    /* This function composes platform_rrm_load_ind */


    /* Compose parameter of basic type */
    gnb_cp_pack_UInt32(*pp_buffer, &p_platform_rrm_load_ind->bitmask, "bitmask");
    *pp_buffer += sizeof(p_platform_rrm_load_ind->bitmask);

    /* Check for correct range [B - both higher and lower boundaries] */
    if ((p_platform_rrm_load_ind->num_of_cell < 1) || (p_platform_rrm_load_ind->num_of_cell > RRM_MAX_NUM_CELLS))
    {
        fprintf(stderr, "Parameter [p_platform_rrm_load_ind->num_of_cell] should be in range "
            "1 to RRM_MAX_NUM_CELLS. Incorrect value %d received.", p_platform_rrm_load_ind->num_of_cell);
        return 0;
    }

    /* Compose parameter of basic type */
    gnb_cp_pack_UInt8(*pp_buffer, &p_platform_rrm_load_ind->num_of_cell, "num_of_cell");
    *pp_buffer += sizeof(p_platform_rrm_load_ind->num_of_cell);

    /* Compose OCTET_STRING VARIABLE of IEs */
    {
        UInt16 loop;
        for (loop = 0; loop < p_platform_rrm_load_ind->num_of_cell; loop++)
        {
            if (0 == gnb_il_compose_rrm_plat_cell_load(pp_buffer, &p_platform_rrm_load_ind->cell_load[loop]))
            {
                return 0;
            }
        }
    }

    return 1;
}


