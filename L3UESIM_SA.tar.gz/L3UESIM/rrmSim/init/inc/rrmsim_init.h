#include "typedefs.h"
/* This function registers RRM sim with the framework */
sim_return_val_et register_rrm_sim();
