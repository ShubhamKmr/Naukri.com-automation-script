/* Standard includes */
#include <stdio.h>

/* Project includes */
#include "rrmsim_cmd_interpreter.h"
#include "rrmsim_peer_conn_hdlr.h"
#include "globalContext.h"
#include "stack.h"
#include "rrmsim_stack_app.h"
#include "rrmConnMgr.h"
#include "rrmsim_encoder.h"
#include "rrmsim_decoder.h"
#include "sim_defs.h"
#include "rrmsim_init.h"

/* This function initializes the RRM simulator */
sim_return_val_et init_rrm_sim(void* ptr)
{
    proto_simulator_t* pRRMSim = (proto_simulator_t*)ptr;
    unsigned short     index  = 0;

    /* Ensure that received pointer is valid */
    if (NULL == ptr)
    {
        LOG_TRACE("NULL pointer received in RRM SIM init \n");
        return SIM_FAILURE;
    }

    LOG_TRACE("Initialization RRM SIM \n");

    /* Initialize RRM SIM stack */
    if (SIM_SUCCESS != pRRMSim->stack->init(NULL))
    {
        LOG_TRACE("Failed to initialize RRM SIM stack\n");
        return SIM_FAILURE;
    }

    /* Initialize RRM SIM encoder */
    else if (SIM_SUCCESS != pRRMSim->encoder->init(NULL))
    {
        LOG_TRACE("Failed to initialize RRM SIM encoder\n");
        return SIM_FAILURE;
    }

    /* Initialize RRM SIM decoder */
    else if (SIM_SUCCESS != pRRMSim->decoder->init(NULL))
    {
        LOG_TRACE("Failed to initialize RRM SIM decoder\n");
        return SIM_FAILURE;
    }

    /* Initialize RRM SIM stack app */
    else if (SIM_SUCCESS != pRRMSim->stackApp->init(NULL))
    {
        LOG_TRACE("Failed to initialize RRM SIM stack app\n");
        return SIM_FAILURE;
    }

    /* Initialize RRM SIM command interpreter */
    else if (SIM_SUCCESS != pRRMSim->cmd_interpreter->init(NULL))
    {
        LOG_TRACE("Failed to initialize RRM SIM cmd interpreter\n");
        return SIM_FAILURE;
    }

    /* Initialize RRM SIM connection handlers */
    else 
    {
        for (index = 0; index < pRRMSim->num_peer_conn_hdlr; index++)
        {
            if (SIM_SUCCESS != pRRMSim->peer_conn_hdlr[index]->init(NULL))
            {
                LOG_TRACE("Failed to initialize RRM SIM connection hdlr\n");
                return SIM_FAILURE;
            }
        }
    }

    return SIM_SUCCESS;
}



/* This function creates all the required components of RRM Sim */
sim_return_val_et create_rrm_sim_components(proto_simulator_t* rrm_sim)
{
    /* Ensure that received pointer is valid */
    if (NULL == rrm_sim)
    {
        LOG_TRACE("Invalid pointer received\n");
        return SIM_FAILURE;
    }

    /* Create command interpreter */
    rrm_sim->cmd_interpreter = create_rrm_sim_cmd_intrepreter();
    if (NULL == rrm_sim->cmd_interpreter)
    {
        LOG_TRACE("Failed to create cmd interpreter for rrm sim\n");
        return SIM_FAILURE;
    }

    /* Create encoder */
    rrm_sim->encoder = create_rrm_sim_encoder();
    if (NULL == rrm_sim->encoder)
    {
        LOG_TRACE("Failed to create encoder for rrm sim\n");
        return SIM_FAILURE;
    }

    /* Create decoder */
    rrm_sim->decoder = create_rrm_sim_decoder();
    if (NULL == rrm_sim->decoder)
    {
        LOG_TRACE("Failed to create decoder for rrm sim\n");
        return SIM_FAILURE;
    }

    /* Create stack */
    rrm_sim->stack = create_rrm_sim_stack();
    if (NULL == rrm_sim->stack)
    {
        LOG_TRACE("Failed to create stack for rrm sim\n");
        return SIM_FAILURE;
    }

    /* Create stackApp */
    rrm_sim->stackApp = create_rrm_sim_stack_app();
    if (NULL == rrm_sim->stackApp)
    {
        LOG_TRACE("Failed to create stackApp for rrm sim\n");
        return SIM_FAILURE;
    }

    /* Create peer connection manager */
    rrm_sim->conn_mgr = create_rrm_sim_peer_conn_mgr();
    if (NULL == rrm_sim->conn_mgr)
    {
        LOG_TRACE("Failed to create peer connection manager for rrm sim\n");
        return SIM_FAILURE;
    }

#if 0
    /* Create peer connection handler 
     * (This will be used for receiving messages from RRM SIM) */
    {
        index = rrm_sim->num_peer_conn_hdlr;

        rrm_sim->peer_conn_hdlr[index] 
                   = create_rrm_sim_control_plane_conn_hdlr();
        if (NULL == rrm_sim->peer_conn_hdlr[index])
        {
            LOG_TRACE("Failed to create peer connection hdlr for rrm sim\n");
            return SIM_FAILURE;
        }

        /* Store the pointer of simulator in connection handler */
        rrm_sim->peer_conn_hdlr[index]->proto_sim = rrm_sim;

        /* Increment the number of registered connection 
         * handlers of RRM simulator. */
        rrm_sim->num_peer_conn_hdlr += 1;
    }
#endif
    return SIM_SUCCESS;
}


/* This function registers RRMSIM sim with the framework */
sim_return_val_et register_rrm_sim()
{
    proto_simulator_t*  rrm_sim = NULL;
   
    /* Allocate new protocol simulator */
    rrm_sim = allocate_new_proto_simulator();
    if (NULL == rrm_sim)
    {
        LOG_TRACE("Failed to allocate RRM simulator \n");
        return SIM_FAILURE;
    }

    /* Create all the components of RRM sim */
    if (SIM_FAILURE == create_rrm_sim_components(rrm_sim))
    {
        LOG_TRACE("Failed to create RRM sim components \n");
        return SIM_FAILURE;
    }

    /* Populate initialization function of RRM simulator */
    rrm_sim->init = init_rrm_sim;

    /* Populate simulator identifier */
    rrm_sim->identifier = RRMSIM_ID;

    /* Register RRM simulator with the framework */
    if (SIM_SUCCESS != register_proto_simulator(rrm_sim))
    {
        LOG_TRACE("Failed to register RRM simulator with framework \n");
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}

