
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "rrmsim_decoder.h"
#include "typedefs.h"
#include "rrmsim_stack_app_cmd_interpreter_intf.h"


/* This function decodes the message */
unsigned char rrm_sim_decode(
        void*          msgInBuf,
        long           msgInBufLen,
        void**         msgOutBuf,
        unsigned long* msgOutBufLen)
{

    LOG_TRACE("RRM sim decoder for future use \n");
    return SIM_SUCCESS;
}


/* This function initializes the RRM sim decoder */
sim_return_val_et rrm_sim_decoder_init()
{
    LOG_TRACE("RRM sim decoder initialization \n");
    return SIM_SUCCESS;
}


/* This function creates and return decoder for RRM sim */
decoder_t* create_rrm_sim_decoder()
{
    decoder_t* decoder = NULL;

    /* Allocate decoder for UE simulator */
    decoder  = allocate_new_proto_decoder();
    if (NULL == decoder)
    {
        LOG_TRACE("Failed to allocate decoder for RRM sim \n");
        return decoder;
    }

    /* Initialize the function pointers of decoder */
    decoder->init   = rrm_sim_decoder_init;
    decoder->decode = rrm_sim_decode; 

    return decoder;
}

