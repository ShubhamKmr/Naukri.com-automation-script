#include "proto_enc_dec.h"


/* Function for initializing the rrm sim decoder */
void init_rrm_sim_decoder();

/* Function for decoding messages received by RRM simulator */
unsigned char rrm_sim_decode(
        void*          msgInBuf,
        long           msgInBufLen,
        void**         msgOutBuf,
        unsigned long* msgOutBufLen);


/* This function creates and return decoder for RRM sim */
decoder_t* create_rrm_sim_decoder();


