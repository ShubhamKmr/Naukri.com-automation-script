/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "proto_enc_dec.h"
#include "rrmsim_encoder.h"
#include "typedefs.h"
#include "rrmsim_stack_app_cmd_interpreter_intf.h"

#define __FILENAME__ "rrmsim_encoder.c"



/* Function exposed by RRM sim for encoding messages */
unsigned char rrm_sim_encode(
    unsigned short  apiId,
/* spr 24900 changes start */    
    unsigned char*  apiBuf,
/* spr 24900 changes end */    
    unsigned int    apiBufLen,
    unsigned char** p_p_encodedmsg,
    unsigned long*  p_encodedmsg_len)
{
    unsigned char ret_val    = 0;

    if (0 == apiBufLen || NULL == apiBuf) 
    {   
        printf("[%s:%d] ERROR->>Input buffer length or buffer ptr is ZERO, returning...\n"
                    ,__FILENAME__,__LINE__);

        return SIM_FAILURE;
    }

    switch(apiId)
    {
        default:
        {
            printf("[%s:%d] ERROR->> Incorrect apiId = %d\n"
                    ,__FILENAME__,__LINE__,apiId);

            break;
        }
    }

    return ret_val;
}


/* This function initializes the RRM sim encoder */
sim_return_val_et rrm_sim_encoder_init()
{
    LOG_TRACE("RRM sim encoder initialization \n");
    return SIM_SUCCESS;
}


/* This function creates and return encoder for RRM sim */
encoder_t* create_rrm_sim_encoder()
{
    encoder_t* encoder = NULL;

    /* Allocate encoder for RRM simulator */
    encoder  = allocate_new_proto_encoder();
    if (NULL == encoder)
    {
        LOG_TRACE("Failed to allocate encoder for RRM sim \n");
        return encoder;
    }

    /* Initializes the function pointers of RRM sim encoder */
    encoder->init   = rrm_sim_encoder_init;
    encoder->encode = rrm_sim_encode;

    return encoder;
}

