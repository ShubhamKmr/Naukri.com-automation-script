
/* This function creates and return encoder for RRM sim */
encoder_t* create_rrm_sim_encoder();


/* Function exposed by RRM sim for encoding messages */
unsigned char rrm_sim_encode(
    unsigned short  apiId,
    /* spr 24900 changes start*/
     unsigned char* apiBuf,
    unsigned int    apiBufLen,
    unsigned char** p_p_encodedmsg,
    unsigned long*  p_encodedmsg_len);
   /* spr 24900 changes end */

