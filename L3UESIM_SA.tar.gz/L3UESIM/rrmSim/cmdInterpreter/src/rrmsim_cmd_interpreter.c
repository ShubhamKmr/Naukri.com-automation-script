/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "rrmsim_cmd_interpreter.h"
#include "typedefs.h"
#include "rrmsim_cmd_defs.h"
#include "rrmsim_cmd_structure.h"
#include "rrmsim_stack_app_cmd_interpreter_intf.h"
//#include "uecc_cmd_interpreter.h"

#include "proto_stack_app.h"
#include "proto_sim.h"
#include "globalContext.h"


/* This function will forward the message from RRM SIM to user */
void rrmsim_forward_msg_to_user(
        unsigned char* apiBuf, 
        unsigned int   apiLen)
{
    user_data_ind_t*   user_data_ind;
    ui_conn_hdlr_t*    ui_handler = NULL;
    unsigned char*     msgBuf     = NULL;
    unsigned int       msgLen     = 0;

    /* Calculate final length of message to be sent */
    msgLen = UI_HDR_LEN + apiLen;

    /* Allocate memory for final message buffer */
    msgBuf = malloc(msgLen);
    memset(msgBuf, 0, msgLen);

    /* Create UI packet */
    user_data_ind = (user_data_ind_t*)msgBuf;

    user_data_ind->proto_identifier = RRMSIM_ID;
    user_data_ind->msgLen           = apiLen;
    memcpy(&user_data_ind->msgBuf, apiBuf, apiLen);

    /* Fetch pointer to object of UI handler */
    ui_handler = get_ui_handler(UI_MAIN_ID);

    LOG_TRACE("Sending message to user, length: %d\n", msgLen);

    /* Send API to user */
    ui_handler->send(ui_handler->sockFd, user_data_ind, msgLen);

    /* valgind 7_6_18 fix start*/
    if(msgBuf)
    {
        free(msgBuf);
        msgBuf = NULL;    
    
    }
    if(apiBuf)
    {
        free(apiBuf);
        apiBuf = NULL;    

    } 
    /* valgind 7_6_18 fix end*/
}


/* This function will forward the command received from
 * user to RRM SIM stack application. */
void rrmsim_forward_user_cmd_to_stack_app(
        rrmsim_cmd_interpreter_to_stack_app_req_t*  msgBuf)
{
    proto_simulator_t* rrm_sim    = NULL;
    stack_app_t*       stack_app = NULL;

    /* Fetch pointer to object of RRM SIMulator */
    rrm_sim = get_proto_simulator(RRMSIM_ID);

    /* Fetch pointer to stackApp of RRM SIMulator */
    stack_app = get_proto_stack_app(rrm_sim);

    /* Invoke the stack app callback registered for 
     * processing command received from user. */
    stack_app->user_msg_hdlr((void*)msgBuf);
}


/* This function handles RRMSIM platform indication received
 * from user. */
void handle_rrmsim_platform_ind(
                unsigned int    msgLen,
                unsigned char*  msgBuf)
{
    rrmsim_cmd_interpreter_to_stack_app_req_t  userRequest;
    rrmsim_platform_load_ind_t*                src_ptr    = NULL;
    platform_load_ind_t*                       target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (platform_load_ind_t*)malloc(
                            sizeof(platform_load_ind_t));

    memset(target_ptr, 0, sizeof(platform_load_ind_t));

    /* Fetch pointer to source structure */
    src_ptr    = (rrmsim_platform_load_ind_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->rrm_load_ind,
               &src_ptr->rrm_load_ind,
               sizeof(rrmsim_platform_load_ind_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = PLATFORM_IND;
        userRequest.header.imsi       = 0;
        userRequest.header.rrm_id     = 0; 
        userRequest.header.length     
                = sizeof(rrmsim_platform_load_ind_t) +
                       sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);
    }

    /* Forward the command to stack application */
    rrmsim_forward_user_cmd_to_stack_app(&userRequest);
}

/* This function handles RRMSIM configuration request received
 * from user. */
void handle_configure_rrm_req(
                unsigned int    msgLen,
                unsigned char*  msgBuf)
{
    rrmsim_cmd_interpreter_to_stack_app_req_t  userRequest;
    rrmsim_configure_req_t*                   src_ptr    = NULL;
    configure_rrm_req_t*                      target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (configure_rrm_req_t*)malloc(
                            sizeof(configure_rrm_req_t));
    memset(target_ptr, 0, sizeof(configure_rrm_req_t));

    /* Fetch pointer to source structure */
    src_ptr    = (rrmsim_configure_req_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->local_rrm_comm_info,
               &src_ptr->local_rrm_comm_info,
               sizeof(rrmsim_comm_info_t));

        memcpy(&target_ptr->peer_rrm_comm_info,
               &src_ptr->peer_rrm_comm_info,
               sizeof(rrmsim_comm_info_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = CONFIGURE_RRM_REQ;
        userRequest.header.imsi       = 0;
        userRequest.header.rrm_id     = 0; 
        userRequest.header.length     
                = sizeof(configure_rrm_req_t) +
                       sizeof(rrmsim_cmd_interpreter_stack_app_intf_hdr_t);
    }

    /* Forward the command to stack application */
    rrmsim_forward_user_cmd_to_stack_app(&userRequest);
}




/* This function process the command received from user */ 
void rrmsim_process_user_command(unsigned short apiId,
                                unsigned int   imsi,
                                unsigned short rrm_id,
                                unsigned int   msgLen,
                                unsigned char* msgBuf)
{
    switch(apiId)
    {
        case RRMSIM_CONFIGURE_RRM_REQ:
        {
            LOG_TRACE("Configure RRM Req received in cmd interprester\n");
            handle_configure_rrm_req(msgLen, msgBuf);
            break;
        }

        case RRMSIM_PLATFORM_IND:
        {
            LOG_TRACE("PLATFORM LOAD IND received in cmd interprester\n");
            handle_rrmsim_platform_ind(msgLen, msgBuf);
            break;
        }

        default:
        {
            LOG_TRACE("Received API: %d not supported \n", apiId);
            break;
        }
    }
}


/* This function decodes the command received from user and 
 * invoke API for further processing. */
void rrm_sim_cmd_interpreter_user_cmd_hdlr(
        void*         msgBuf, 
        unsigned int  msgLen)
{
    rrmsim_user_data_req_t*  user_data  = NULL;

    LOG_TRACE("Command received from user in RRM SIM, length: %d \n", msgLen);

    /* TODO: Ensure that length of message is not less than 
     * minumum allowed. 
     * Also, ensure that the received msg length matches the 
     * one present in the message header. */
    user_data  = (rrmsim_user_data_req_t*)msgBuf;

    /* Handle received API */
    rrmsim_process_user_command(user_data->header.apiId,
                               user_data->header.imsi,
                               user_data->header.rrm_id,
                               user_data->header.length,
                               user_data->msgBuf); 
}



/* This function handles configure RRM response received from
 * stack application */
void handle_configure_rrm_resp(unsigned char* msgBuf, 
                               unsigned int  msgLen)
{
    rrmsim_stack_app_to_cmd_interpreter_ind_t*  msg_in     = NULL;
    configure_rrm_resp_t*                      src_ptr    = NULL;
    rrmsim_configure_resp_t*                   target_ptr = NULL;
    rrmsim_user_data_ind_t*                     p_api      = NULL;
    unsigned char*                             apiBuf     = NULL;
    unsigned int                               api_size   = 0;

    msg_in = (rrmsim_stack_app_to_cmd_interpreter_ind_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (configure_rrm_resp_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(rrmsim_user_intf_hdr_t) + 
                          sizeof(rrmsim_configure_resp_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (rrmsim_configure_resp_t*)(apiBuf + 
                                sizeof(rrmsim_user_intf_hdr_t));

    /* Populate API body */
    target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to RRM sim user data indication */
    p_api = (rrmsim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = RRMSIM_CONFIGURE_RRM_RESP;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.rrm_id     = msg_in->header.rrm_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    rrmsim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   

    LOG_TRACE("Sent configure RRM Response to user, length:%d \n", api_size);
}


/* This function processes the message received from RRM SIM stack app */
void rrm_sim_cmd_interpreter_stack_app_msg_hdlr(
        void*         msgBuf, 
        unsigned int  msgLen)
{
    rrmsim_stack_app_to_cmd_interpreter_ind_t*  msg_in = PNULL;

    msg_in = (rrmsim_stack_app_to_cmd_interpreter_ind_t*)msgBuf;

    switch(msg_in->header.apiId)
    {
        case RRMSIM_CONFIGURE_RRM_RESP:
        {
            LOG_TRACE("CONFIGURE RRM RESP Received from StackApp \n");
            handle_configure_rrm_resp(msgBuf, msgLen);
            break;
        }

        default:
        {
            fprintf(stderr, "Unknown API received from stack app : %d\n",
                    msg_in->header.apiId);
            break;
        }
    }
}


/* This function initializes the RRM SIM command interpreter */
sim_return_val_et rrm_sim_cmd_interpreter_init()
{
    LOG_TRACE("Initialization of RRM SIM command interpreter \n");
    return SIM_SUCCESS;
}


/* This function creates and return command interpreter for RRM SIM */
cmd_interpreter_t* create_rrm_sim_cmd_intrepreter()
{
    cmd_interpreter_t*  cmd_interpreter = NULL;

    /* Allocate command interpreter for RRM SIM */
    cmd_interpreter = allocate_command_interpreter();
    if (NULL == cmd_interpreter)
    {
        LOG_TRACE("Failed to allocate cmd interpreter for RRM SIM\n");
        return cmd_interpreter;
    }

    /* Initialize the function pointers of command interpreter */
    cmd_interpreter->init           
                = rrm_sim_cmd_interpreter_init; 
    cmd_interpreter->user_cmd_hdlr  
                = rrm_sim_cmd_interpreter_user_cmd_hdlr;
    cmd_interpreter->stack_app_msg_hdlr 
                = rrm_sim_cmd_interpreter_stack_app_msg_hdlr;

    return cmd_interpreter;
}

