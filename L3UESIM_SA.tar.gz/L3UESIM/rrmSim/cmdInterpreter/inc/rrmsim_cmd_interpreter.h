#include "proto_cmd_interpretor.h"


/* This function creates and return command interpreter 
 * for X2 Sim */
cmd_interpreter_t* create_rrm_sim_cmd_intrepreter();
