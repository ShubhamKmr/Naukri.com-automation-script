#include "rrmsim_common.h"
#include "rrm_oam_platform_intf.h"
/* Enum defining the APIs which can be sent from user 
 * to RRM sim */



typedef enum
{
    RRMSIM_CONFIGURE_RRM_REQ = 1,
    RRMSIM_PLATFORM_IND,
    RRMSIM_LAST_USER_TO_SIM_API,
} user_to_rrmsim_api_et; 


/* Enum defining the APIs which can be sent from RRM
 * sim to user */
typedef enum
{
    RRMSIM_CONFIGURE_RRM_RESP = RRMSIM_LAST_USER_TO_SIM_API,
    RRMSIM_LAST_SIM_TO_USER_API
} rrmsim_to_user_api_et;


/************************************************************* 
 * USER to RRM SIM APIs 
 ************************************************************/


/* Structure defining the content of API used for adding a new
 * instance at RRMSIM which will be used for testing gNB. */


typedef struct
{
    /* UDP Communication information of local */
    rrmsim_comm_info_t         local_rrm_comm_info;

    /* UDP Communication information of Peer */
    rrmsim_comm_info_t         peer_rrm_comm_info;

} rrmsim_configure_req_t;  /* RRMSIM_CONFIGURE_RRM_REQ */



typedef struct _rrmsim_platform_load_ind_t
{

   platform_rrm_load_ind_t    rrm_load_ind; 

} rrmsim_platform_load_ind_t;  /* RRMSIM_PLATFORM_IND */


/*************************************************************** 
 * RRM SIM to USER APIs 
 **************************************************************/

/* Structure defining the content of API used for sending the 
 * response of CONFIGURE ENB REQ to user. */
typedef struct
{
    /* Indicates the result of eNB Configure Request */
    unsigned char response_code;

} rrmsim_configure_resp_t;  /* RRMSIM_CONFIGURE_RRM_RESP */

