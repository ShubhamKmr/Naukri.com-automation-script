
/* Structure defining the header of messages exchanged 
 * between RRM simulator and its user. */
typedef struct
{
    /* API Identifier */
    unsigned short apiId;

    /* eNB identifier. In case of non eNB specific API
     * receiving entity is not supposed to interpret it. */
    unsigned short rrm_id;

    /* Length of the message (including header) */
    unsigned int   length;

    /* Unique UE identifier. In case of non UE specific API
     * receiving entity is not supposed to interpret it. */
    unsigned int   imsi;

    /* Reserved bytes (for 4 bytes alignment) */
    //unsigned char  reserved1;
    //unsigned short reserved2;

} rrmsim_user_intf_hdr_t;


/* Structure defining the content of message from user
 * to RRM simulator. */
typedef struct
{
    /* Message header */
    rrmsim_user_intf_hdr_t  header;

    /* Message body */
    unsigned char          msgBuf[1];

} rrmsim_user_data_req_t;


/* Structure defining the content of message from RRM
 * simulator to its user. */
typedef struct
{
    /* Message header */
    rrmsim_user_intf_hdr_t  header;

    /* Message body */
    unsigned char          msgBuf[1];

} rrmsim_user_data_ind_t;

