/* Standard Includes */
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

/* Project Includes */
#include "../../framework/inc/typedefs.h"

#ifndef _RRMSIM_COMMON_H_
#define _RRMSIM_COMMON_H_

#define MAX_NUM_IP_ADDR         3
#define MAX_IPV4_ADDR_LEN       16

typedef enum
{
    SUCCESS_RSP,
    FAILURE_RSP
} rrmsim_response_code_et;

/* Socket configuration information */
typedef struct SocketConfig1T
{
    /* Listen port */
    unsigned short      port;

    /* IP address */
    char                ipAddr[MAX_IP_ADDRESS_LENGTH];

    /* Socket Address */
    struct sockaddr_in  sockAddr;

}rrmsim_socket_config1_t;

/* Structure for storing socket related information
 * of UE SIM Peers. */
typedef struct
{
    /* Socket configuration for communicating with
     * gNB Adaptation layer. */
    rrmsim_socket_config1_t adapterConfig;

}rrmsim_peer_addr_t;

typedef struct
{
 /* Socket FD */
    //unsigned int        sockFd;

/* Structure for storing socket related information
     * used for communication with stack of RRM SIM. */
    rrmsim_socket_config1_t     self_addr;

    /* Structure for storing socket related information
     * used for communicaton with stack of RRM SIM. */
    rrmsim_peer_addr_t   peer_addr;
 
}rrmsim_udp_config_param_t;

/* Structure defining the content of IPv4 address */
typedef struct
{
    unsigned char  ip_addr[MAX_IPV4_ADDR_LEN];
} rrmsim_ipv4_addr_t;


/* Structure defining the content of eNB communication info */
typedef struct
{
#define RRM_COMM_INFO_NUM_IPV4_ADDR_PRESENT      0x01
#define RRM_COMM_INFO_IPV4_ADDR_PRESENT          0x02
#define RRM_COMM_INFO_UDP_CONFIG_PARAM_PRESENT   0x04

    /* Bitmask indicating the presence of optional IEs */
    unsigned int               bitmask;

    /* Count of IPv4 address 
     * (Bitmask: RRM_COMM_INFO_NUM_IPV4_ADDR_PRESENT) */
    unsigned char              num_ipv4_addr;

    /* List of IPv4 address 
     * (Bitmask: RRM_COMM_INFO_IPV4_ADDR_PRESENT) */
    rrmsim_ipv4_addr_t          ipv4_addr[MAX_NUM_IP_ADDR];

    /* Port number */
    unsigned short             port;

    /* UDP association specific parameters 
     * (Bitmask: RRM_COMM_INFO_UDP_CONFIG_PARAM_PRESENT) */
    rrmsim_udp_config_param_t   udp_config_param;

} rrmsim_comm_info_t;


#endif  // _RRMSIM_COMMON_H_
