/* Local RRMSIM Composer file */
#include "stdbool.h"
#include "rrm_oam_platform_intf.h"

//rach changes
/*
#define GNB_CP_TRACE(log_level,str,...) \
    gnb_cp_trace((char*)__FILE__,(char*)__func__,__LINE__,log_level,\
            (char*)str,##__VA_ARGS__)

extern void gnb_cp_trace(char* fileName,char* funcName,UInt32 lineNo,
        UInt8 logLevel,char* str,...);
*/


bool
gnb_cp_unpack_UInt16
(
    void    *p_dest,
    void    *p_src,
    char    *varname
);

bool
gnb_cp_pack_UInt8
(
    void    *p_dest,
    void    *p_src,
    char    *varname
);

bool
gnb_cp_pack_UInt16
(
    void    *p_dest,
    void    *p_src,
    char    *varname
);

bool
gnb_cp_pack_UInt32
(
    void    *p_dest,
    void    *p_src,
    char    *varname
);

UInt16
gnb_il_get_platform_rrm_load_ind_len
(
     platform_rrm_load_ind_t *p_platform_rrm_load_ind
);

bool
gnb_il_compose_platform_rrm_load_ind
(
    UInt8  **pp_buffer,
    platform_rrm_load_ind_t *p_platform_rrm_load_ind
);

void
rrm_construct_interface_api_header
(
 UInt8                  *p_header,      /* RRM interface header */
 UInt16                 transaction_id, /* Interface transaction identifier */
 rrm_module_id_t     src_module_id,  /* Source module identifier */
 rrm_module_id_t     dst_module_id,  /* Destination module identifier */
 UInt16                 api_id,         /* API identifier */
 UInt16                 api_buf_size,   /* API buffer size */
 cell_index_t        cell_index      /* Cell Index */
 );
