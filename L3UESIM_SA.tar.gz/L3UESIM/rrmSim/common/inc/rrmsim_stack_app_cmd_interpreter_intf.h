#ifndef _RRMSIM_STACK_APP_CMD_INTERPRETER_H_
#define _RRMSIM_STACK_APP_CMD_INTERPRETER_H_

/* This file defines the interfaces exposed by RRM sim 
 * towards command interpreter. */

#include "lteTypes.h"
#include "rrmsim_common.h"
#include "rrm_oam_platform_intf.h"


/* Structure defining the header of messages exchanged
 * between stack app and command interpreter of RRM SIM. */
typedef struct
{
    /* API Identifier */
    unsigned short  apiId;

    /* Unique rrmsim identifier. In case of non eNB specific API
     * receiving entity is not supposed to interpret it. */
    unsigned short  rrm_id;

    /* Length of the message (including header) */
    unsigned int    length;

    /* Unique UE identifier. In case of non UE specific API
     * receiving entity is not supposed to interpret it. */
    unsigned int    imsi;

    /* Reserved bytes (for 4 bytes alignment) */
    //unsigned char   reserved1;
    //unsigned short  reserved2;

} rrmsim_cmd_interpreter_stack_app_intf_hdr_t;


/* Structure defining the content of message from user
 * to RRM simulator. */
typedef struct
{
    /* Message header */
    rrmsim_cmd_interpreter_stack_app_intf_hdr_t  header;

    /* Message body */
    unsigned char*                              msgBuf;

} rrmsim_cmd_interpreter_to_stack_app_req_t;


/* Structure defining the content of message from RRM 
 * simulator to its user. */
typedef struct
{
    /* Message header */
    rrmsim_cmd_interpreter_stack_app_intf_hdr_t  header;

    /* Message body */
    unsigned char*                              msgBuf;

} rrmsim_stack_app_to_cmd_interpreter_ind_t;


/***********************************************************
 * APIs exposed by RRM SIM stackApp towards cmd interpreter
 **********************************************************/

typedef enum
{
    CONFIGURE_RRM_REQ= 1,
    PLATFORM_IND,
    CONFIGURE_RRM_RESP,
    INVALID_API_ID
} rrmsim_stack_app_cmd_interpreter_api_et;


/******************************************************* 
 * RRM SIM Command interpreter to stackApp APIs 
 ******************************************************/

/* Structure defining the content of API used for adding a new
 * ENB at RRMSIM which will be used for testing a peer eNB. */
typedef struct
{
    /* UDP Communication information of local  */
    rrmsim_comm_info_t        local_rrm_comm_info;

    /* UDP Communication information of Peer */
    rrmsim_comm_info_t        peer_rrm_comm_info;

} configure_rrm_req_t;  /* CONFIGURE_RRM_REQ */


typedef struct _platform_load_ind_t
{

   platform_rrm_load_ind_t    rrm_load_ind; 

} platform_load_ind_t;  /* PLATFORM_IND */


/******************************************************* 
 * RRM SIM to USER APIs 
 ******************************************************/

/* Structure defining the content of API used for sending the 
 * response of CONFIGURE RRMSIM REQ to user. */
typedef struct
{
    /* Indicates the result of RRM Configure Request */
    unsigned char   response_code;

} configure_rrm_resp_t;  /* CONFIGURE_RRM_RESP */



#endif  // _RRMSIM_STACK_APP_CMD_INTERPRETER_H_
