/******************************************************************************
 *
 * ARICENT -
 *
 * Copyright (C) 2012 Aricent Inc . All Rights Reserved.
 *
 *******************************************************************************
 *
 * $$Id: rrm_oam_platform_intf.h $
 *
 *******************************************************************************
 *
 * File Description: RRM OAM Platform interface header file RRM OAM platform
 *                   APIs function declaration
 *
 *******************************************************************************
 * Revision Details
 * ----------------
 *
 ******************************************************************************/

#ifndef _RRM_PLATFORM_OAM_INTF_H
#define _RRM_PLATFORM_OAM_INTF_H

#include "rrm_api_types.h"
#include "rrm_api_defines.h"

#define RRM_MAX_SOURCE 3
#define RRM_PERIODIC    0
#define RRM_EVENT       1

#define RRM_PLATFORM_LOAD_IND               6033
#define RRM_INTERFACE_API_HEADER_SIZE       16

typedef enum
{
    SOURCE_TNL,
    SOURCE_MEMORY,
    SOURCE_CPU
}rrm_oam_load_src_et;

typedef struct _rrm_oam_load_status_t
{
    rrm_bitmask_t bitmask; /*^ BITMASK ^*/
    UInt32 load_src;  /*^ M, 0, H, 0, 2 ^*/
    UInt8 load_level;  /*^ M, 0, N, 0, 0 ^*/
}rrm_oam_load_status_t;

#define RRM_CPU_LOAD_LEVEL_PRESENT       0x01
#define RRM_MEMORY_LOAD_LEVEL_PRESENT    0x02
typedef struct _rrm_plat_cell_load_t
{
    rrm_bitmask_t bitmask; /*^ BITMASK ^*/
    rrm_oam_nr_global_cell_id_t global_cell_id;/*^ M, 0, N, 0, 0 ^*/
    UInt8  cpu_load_level; /*^ O,RRM_CPU_LOAD_LEVEL_PRESENT,B,1, 100 ^*/
    UInt8  memory_load_level; /*^ O,RRM_MEMORY_LOAD_LEVEL_PRESENT,B,1, 100 ^*/
}rrm_plat_cell_load_t;

typedef struct _platform_rrm_load_ind_t
{
    rrm_bitmask_t bitmask; /*^ BITMASK ^*/
    UInt8 num_of_cell; /*^ M, 0, B, 1, RRM_MAX_NUM_CELLS ^*/
    rrm_plat_cell_load_t cell_load[RRM_MAX_NUM_CELLS]; /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}platform_rrm_load_ind_t;/*^ API, RRM_PLATFORM_LOAD_IND ^*/

#endif

