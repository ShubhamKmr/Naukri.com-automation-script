/**************************************************************************
                README FOR USING L3SIM TEST TOOL
***************************************************************************/

/*********************COMPILATION STEPS************************************/

1. cd /5G_NR_gNB/Testing/L3UESIM/testing/
2. run ./build.sh clean;./build.sh l3sim


/********************DEPENDENCIES ******************************************/

1. Build.sh contains the following:-

-> It copies the header files from path /5G_NR_gNB/5G_IPR/gNB_SW/ to 
   path L3UESIM/testing/ueSim/common/inc/  requires for compiling the testTool.

-> It compiles the  5G_IPR/gNB_SW/gNB_DU/interfaces/ folder which generates 
   the library i.e. libduintf.so and  5G_IPR/gNB_SW/common/ folder which 
   generates the library i.e libcommon.a 

-> These two libraries are required for compiling the interface files in
   testTool.

/*****************STEPS FOR RUNNING THE SETUP*******************************/

1. Run export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../../lib:../../ueSim/lib:
   ../../framework/lib:../../common/asn_lib/:../../x2Sim/lib:../../duSim/lib:
   ../../s1Sim/lib:../../common/lib:/usr/local/lib:../../nrAdaptSim/lib/

2. cd L3UESIM/testing/bin/

3. Run ./testTool(binary)

/****************FOR SOCKET CONNECTION WITH L2UESIM*************************/

1.Use L3UESIM/testing/cfg/configureUeSim.xml for configuring the port/ip 
  address information of PDCP/MAC/RLC. 

/********************FOR CONFIGURING MESSAGES********************************/

1.Use macOamProvisioning_ueSim0.xml for configuring mac provisioning request
  related params.

2.Use rlcOamProvisioning_ueSim0.xml for configuring rlc provisioning request
  related params.

3.Use pdcpOamProvisioning_ueSim0.xml for configuring pdcp provisioning request
  related params.

4.Use pdcpCellConfigRequest_ueSim0.xml for configuring pdcp cell config request 
  related params.

5.Use rlcCellConfigRequest_ueSim0.xml for configuring rlc cell config request 
  related params.

6.Use cellConfigRequest_ueSim0.xml for configuring mac cell config request related 
  params.

Note:-All the xml files are placed in L3UESIM/testing/cfg folder.

For more information,please refer the 5G UESIM Design document.
