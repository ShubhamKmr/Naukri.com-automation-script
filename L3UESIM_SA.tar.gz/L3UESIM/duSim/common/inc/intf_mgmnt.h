/*******************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2016 Aricent Inc. All Rights Reserved.
 *
 *******************************************************************************
 *
 *  $Id: f1ap_intf_mgmnt.h
 *
 *******************************************************************************
 *
 *  File Description : 
 *
 ******************************************************************************/

#ifndef _F1AP_INTF_MGMNT_H_
#define _F1AP_INTF_MGMNT_H_

/*******************************************************************************
 * Project Includes
 ******************************************************************************/
#include "f1ap_asn_common.h"
#include "f1ap_adpt_intf.h"
/*******************************************************************************
 * Exported Includes
 ******************************************************************************/

typedef struct _f1ap_FiveGS_TAC {
   unsigned int numocts;
   unsigned char  data[3];
} _f1ap_FiveGS_TAC;

typedef struct _f1ap_Configured_EPS_TAC {
   unsigned int numocts;
   unsigned char  data[2];
} _f1ap_Configured_EPS_TAC;

typedef struct _OpenType {                
   unsigned short int   numocts;
   const unsigned char*         data;
} _OpenType;

typedef struct {
    unsigned int numocts;
   unsigned char data[3];
} _ASN1OpenTyp;


typedef struct _OctStr {
   unsigned int numocts;
   const unsigned char* data;
} _OctStr;

/*******************************************************************************
 * Exported Definitions
 ******************************************************************************/

/* Identifiers of the cell to be activated */
typedef struct _f1ap_Cells_to_be_Activated_List_element 
{
#define CELL_TO_BE_ACTIVATED_PCI_PRESENT    0x01

    unsigned char   bitmask;

    /* NCGI */
    _f1ap_NCGI      cgi;

    /* PCI */
    unsigned short  pci;

} _f1ap_Cells_to_be_Activated_List_element;


/* List of cells to be activated */
typedef struct _f1ap_Cells_to_be_Activated_List
{
    /* Count of cells in the list */
    unsigned int    count;

    /* Identifier of the cell to be activated */ 
    _f1ap_Cells_to_be_Activated_List_element  
                    cell_to_activate[MAX_CELL_PER_DU];

} _f1ap_Cells_to_be_Activated_List;


/* List of PLMNs supported by cell */
typedef struct _f1ap_BroadcastPLMNs_Item 
{
    /* Count of PLMNs */
    unsigned char         n;

    /* PLMN Identity */
    _f1ap_PLMN_Identity   elem[6];

} _f1ap_BroadcastPLMNs_Item;


/* Possible value of NR Bandwidth in terms of 
 * sub carrier spacing */
typedef enum
{
    TRANSMISSION_BW_NR_SCS_15,
    TRANSMISSION_BW_NR_SCS_30,
    TRANSMISSION_BW_NR_SCS_60,
    TRANSMISSION_BW_NR_SCS_120,
} transmission_bw_nr_scs_et;


/* Possible value of NR Bandwidth in terms of 
 * number of PRBs */
typedef enum
{
    TRANSMISSION_BW_NR_NRB_11,
    TRANSMISSION_BW_NR_NRB_18,
    TRANSMISSION_BW_NR_NRB_24,
    TRANSMISSION_BW_NR_NRB_25,
    TRANSMISSION_BW_NR_NRB_31,
    TRANSMISSION_BW_NR_NRB_32,
    TRANSMISSION_BW_NR_NRB_38,
    TRANSMISSION_BW_NR_NRB_51,
    TRANSMISSION_BW_NR_NRB_52,
    TRANSMISSION_BW_NR_NRB_65,
    TRANSMISSION_BW_NR_NRB_66,
    TRANSMISSION_BW_NR_NRB_78,
    TRANSMISSION_BW_NR_NRB_79,
    TRANSMISSION_BW_NR_NRB_93,
    TRANSMISSION_BW_NR_NRB_106,
    TRANSMISSION_BW_NR_NRB_107,
    TRANSMISSION_BW_NR_NRB_121,
    TRANSMISSION_BW_NR_NRB_132,
    TRANSMISSION_BW_NR_NRB_133,
    TRANSMISSION_BW_NR_NRB_135,
    TRANSMISSION_BW_NR_NRB_160,
    TRANSMISSION_BW_NR_NRB_162,
    TRANSMISSION_BW_NR_NRB_189,
    TRANSMISSION_BW_NR_NRB_216,
    TRANSMISSION_BW_NR_NRB_217,
    TRANSMISSION_BW_NR_NRB_245,
    TRANSMISSION_BW_NR_NRB_264,
    TRANSMISSION_BW_NR_NRB_270,
    TRANSMISSION_BW_NR_NRB_273
} transmission_bw_nr_nrb_et;


typedef struct f1ap_transmission_bw
{
    /* Transmission bandwidth in terms of sub-carrier
     * spacing (transmission_bw_nr_scs_et) */
    unsigned int  nRSCS;

    /* Transmission bandwidth in terms of number of 
     * resource blocks (transmission_bw_nr_nrb_et) */
    unsigned int  nRNRB;

} f1ap_transmission_bw_t;

typedef struct _f1ap_Transmission_Bandwidth {
    unsigned int nRSCS;
    unsigned int nRNRB;
    //f1ap_Transmission_Bandwidth_iE_Extensions iE_Extensions;
}_f1ap_Transmission_Bandwidth ;

typedef struct _f1ap_SUL_Information {
    unsigned int sUL_NRARFCN;
    _f1ap_Transmission_Bandwidth sUL_transmission_Bandwidth;
}_f1ap_SUL_Information;

typedef struct _f1ap_SupportedSULFreqBandItem {
    unsigned int freqBandIndicatorNr;
}_f1ap_SupportedSULFreqBandItem;

typedef struct _f1ap_FreqBandNrItem_supportedSULBandList {
    unsigned count;
    _f1ap_SupportedSULFreqBandItem item[4];
}_f1ap_FreqBandNrItem_supportedSULBandList ;

typedef struct _f1ap_FreqBandNrItem {
    unsigned int freqBandIndicatorNr;
    _f1ap_FreqBandNrItem_supportedSULBandList supportedSULBandList;
}_f1ap_FreqBandNrItem;

typedef struct _f1ap_NRFreqInfo_freqBandListNr {
    unsigned int count;
    _f1ap_FreqBandNrItem item[4];
}_f1ap_NRFreqInfo_freqBandListNr;



typedef struct _f1ap_NRFreqInfo {
#define F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT 0x01
#define NR_FREQ_INFO_IE_EXTENSIONS_PRESENT 0x02
    unsigned int bitmask;  
    unsigned int nRARFCN;
    _f1ap_SUL_Information sul_Information;
    _f1ap_NRFreqInfo_freqBandListNr freqBandListNr;
}_f1ap_NRFreqInfo;
/* FDD Configuration */
typedef struct _f1ap_FDD_Info 
{
    /* UL Carrier Frequency */
    _f1ap_NRFreqInfo  uL_NARFCN;

    /* DL Carrier Frequency */
    _f1ap_NRFreqInfo  dL_NARFCN;

    /* UL Transmission Bandwidth */
    f1ap_transmission_bw_t  uL_Transmission_Bandwidth;

    /* DL Transmission Bandwidth */
    f1ap_transmission_bw_t  dL_Transmission_Bandwidth;

} _f1ap_FDD_Info;


/* TDD Configuration */
typedef struct _f1ap_TDD_Info 
{
   /* Carrier Frequency */
   _f1ap_NRFreqInfo nRFreqInfo;
  // unsigned short  nARFCN;

   /* Transmission Bandwidth */
   f1ap_transmission_bw_t  transmission_Bandwidth;

} _f1ap_TDD_Info;


/* NR Mode information */
typedef struct _f1ap_NR_Mode_Info_choice_extension_element {
   /* id
    criticality
    _OpenType extensionvalue
    */
}_f1ap_NR_Mode_Info_choice_extension_element;

typedef struct _f1ap_NR_Mode_Info_choice_extension
{
    unsigned int count;
    _f1ap_NR_Mode_Info_choice_extension_element elem[1];

}_f1ap_NR_Mode_Info_choice_extension;

typedef struct _f1ap_NR_Mode_Info 
{
#define NR_MODE_FDD                        1
#define NR_MODE_TDD                        2 
#define NR_MODE_INFO_CHOICE_EXTENSION      3

   /* NR Mode Type */
   unsigned int       nr_mode;

   union 
   {
      /* FDD Configuration */
      _f1ap_FDD_Info  fDD;

      /* TDD Configuration */
      _f1ap_TDD_Info  tDD;

        /*Choice Extension*/
      _f1ap_NR_Mode_Info_choice_extension *choice_extension;
   } u;

} _f1ap_NR_Mode_Info;

#define EXTENDED_TAC_LENGTH    3


typedef struct _f1ap_sul_Information
{
    /* UL Carrier Frequency */
    unsigned short                  uL_NARFCN;

    /* UL Transmission Bandwidth */
    f1ap_transmission_bw_t  uL_Transmission_Bandwidth;

} f1ap_sul_Information_t;


/* TODO : Need to update allowed max length */
#define MEAS_TIMING_CONFIG_LEN  256

//typedef struct f1ap_meas_timing_config
//{
  //  unsigned int          numocts; 
   // unsigned char    buf[MEAS_TIMING_CONFIG_LEN];
    //const unsigned char*    data;
//} f1ap_meas_timing_config_t;

/*typedef struct f1ap_extended_tac
{
    unsigned char  numocts;

    unsigned char  data[EXTENDED_TAC_LENGTH];

} f1ap_extended_tac_t;
*/

typedef struct _f1ap_Served_Cell_Information_iE_Extensions_element 
{
    struct {
        unsigned int t;
        union {
            /*id-RANAC*/
            unsigned char _f1ap_Served_Cell_Information_ExtIEs_1;
        } u;
    } extensionValue;
} _f1ap_Served_Cell_Information_iE_Extensions_element;

typedef struct _f1ap_Served_Cell_Information_iE_Extensions
{
    unsigned int count;
    _f1ap_Served_Cell_Information_iE_Extensions_element elem[1];

} _f1ap_Served_Cell_Information_iE_Extensions;


typedef struct f1ap_nr_rrc_SSB_MTC_duration {
  unsigned int  nr_rrc_SSB_MTC_duration;
}f1ap_nr_rrc_SSB_MTC_duration;

typedef struct f1ap_nr_rrc_SSB_MTC_periodicityAndOffset {
   int t;
   union {
      /* t = 1 */
      unsigned char sf5;
      /* t = 2 */
      unsigned char sf10;
      /* t = 3 */
       unsigned char sf20;
      /* t = 4 */
       unsigned char sf40;
      /* t = 5 */
       unsigned char sf80;
      /* t = 6 */
        unsigned char sf160;
   } u;
} f1ap_nr_rrc_SSB_MTC_periodicityAndOffset;

typedef struct f1ap_nr_rrc_SSB_MTC {
   f1ap_nr_rrc_SSB_MTC_periodicityAndOffset periodicityAndOffset;
  f1ap_nr_rrc_SSB_MTC_duration duration;
} f1ap_nr_rrc_SSB_MTC;

typedef struct f1ap_nr_rrc_ARFCN_ValueNR{
    unsigned int nr_rrc_ARFCN_ValueNR;
}f1ap_nr_rrc_ARFCN_ValueNR;

typedef struct f1ap_nr_rrc_SubcarrierSpacing {
   unsigned int nr_rrc_SubcarrierSpacing;
 }f1ap_nr_rrc_SubcarrierSpacing;

typedef struct f1ap_nr_rrc_SS_RSSI_Measurement_measurementSlots {
   unsigned int numbits;
   unsigned char data[10];
} f1ap_nr_rrc_SS_RSSI_Measurement_measurementSlots;

typedef struct f1ap_nr_rrc_SS_RSSI_Measurement {
   f1ap_nr_rrc_SS_RSSI_Measurement_measurementSlots measurementSlots;
   unsigned char endSymbol;
} f1ap_nr_rrc_SS_RSSI_Measurement;


typedef struct f1ap_nr_rrc_MeasTiming_frequencyAndTiming {
	struct {
		unsigned ss_RSSI_MeasurementPresent : 1;
	} m;
	f1ap_nr_rrc_ARFCN_ValueNR carrierFreq;
   f1ap_nr_rrc_SSB_MTC ssb_MeasurementTimingConfiguration;
   f1ap_nr_rrc_SubcarrierSpacing ssbSubcarrierSpacing;
   f1ap_nr_rrc_SS_RSSI_Measurement ss_RSSI_Measurement;   
} f1ap_nr_rrc_MeasTiming_frequencyAndTiming;

typedef struct f1ap_nr_rrc_MeasTiming {
   struct {
      unsigned frequencyAndTimingPresent : 1;
   } m;
  f1ap_nr_rrc_MeasTiming_frequencyAndTiming frequencyAndTiming;
  // OSRTDList extElem1;
} f1ap_nr_rrc_MeasTiming;

typedef struct f1ap_nr_rrc_MeasTimingList{
   unsigned int count;
   f1ap_nr_rrc_MeasTiming _nr_rrc_MeasTiming[10];
 }f1ap_nr_rrc_MeasTimingList;

typedef struct f1ap_nr_rrc_MeasurementTimingConfiguration_IEs {
   struct {
      unsigned measTimingPresent : 1;
      unsigned nonCriticalExtensionPresent : 1;
   } m;
   f1ap_nr_rrc_MeasTimingList measTiming;
   //_nr_rrc_MeasurementTimingConfiguration_IEs_nonCriticalExtension nonCriticalExtension;
} f1ap_nr_rrc_MeasurementTimingConfiguration_IEs;


typedef struct f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1 {
   unsigned int t;
   union {
      /* t = 1 */
      f1ap_nr_rrc_MeasurementTimingConfiguration_IEs measTimingConf;
      /* t = 2 */
      /* t = 3 */
      /* t = 4 */
   } u;
} f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1;

typedef struct f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions {
   unsigned int t;
   union {
      /* t = 1 */
      f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1 c1;
      /* t = 2 */
     // _nr_rrc_MeasurementTimingConfiguration_criticalExtensions_criticalExtensionsFuture criticalExtensionsFuture;
   } u;
} f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions;


typedef struct f1ap_nr_rrc_MeasurementTimingConfiguration {
   f1ap_nr_rrc_MeasurementTimingConfiguration_criticalExtensions criticalExtensions;
} f1ap_nr_rrc_MeasurementTimingConfiguration;



/* Served Cell Information */
typedef struct _f1ap_Served_Cell_Information 
{
    #define F1AP_SERVED_CELL_INFO_CONFIGURED_EPS_TAC_PRESENT 0x01;
    #define F1AP_SERVED_CELL_INFO_IE_EXTENSION_PRESENT       0x02;
    unsigned char                bitmask;

    /* CGI of the served cell */
    _f1ap_NCGI                   nRCGI;

    /* PCI of the served cell */
    unsigned short               nRPCI;

    /* Extended TAC */
    //f1ap_extended_tac_t          extended_tac;

    _f1ap_FiveGS_TAC             fiveGS_TAC;
    
    /* Configure EPS TAC */
    _f1ap_Configured_EPS_TAC     configured_EPS_TAC;

    /* PLMNs of the served cell */
    _f1ap_BroadcastPLMNs_Item  broadcastPLMNs;

    /* NR mode(FDD/TDD) configuration */
    _f1ap_NR_Mode_Info         nR_Mode_Info;

        /* Contains the MeasurementTimingConfiguration IE 
     * defined in TS 38.331 [8]. */
    f1ap_nr_rrc_MeasurementTimingConfiguration   meas_timing_config;

    /* Secondary UL information 
     * (Bitmask : F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT) */
    //f1ap_sul_Information_t       sUL_Information;
    _f1ap_Served_Cell_Information_iE_Extensions iE_Extensions; 
} _f1ap_Served_Cell_Information;


/* System Information to be broadcasted by DU */
typedef struct _f1ap_GNB_DU_System_Information 
{
#if 1

   /* Length of MIB buffer */
   unsigned int   mib_length;

   /* MIB byte stream */
   unsigned char  mIB_message[MAX_MIB_LEN];

   /* Length of SIB1 buffer */
   unsigned int   sib1_length;

   /* SIB1 byte stream */
   unsigned char  sIB1_message[MAX_SIB1_LEN];

#else

    /* Master Information Block */
    //rrc_f1ap_mib_config_t   mib;

    /* System Information Block */
    //rrc_f1ap_sib1_config_t  sib1; 
//    _OctStr mib_msg;
//    _OctStr sib1_msg;
#endif

} _f1ap_GNB_DU_System_Information;


/*********************************************************************
 * F1 SETUP REQUEST
 ********************************************************************/

/* Configuration of served cells */
typedef struct _f1ap_GNB_DU_Served_Cells_List_element 
{
#define F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT   0x01
#define F1AP_GNB_DU_SERVED_CELL_IE_EXTENSION_PRESENT  0x02
    /* Bitmask */
    unsigned char                     bitmask;

     /* Served Cell Information */
     _f1ap_Served_Cell_Information    served_cell_info;

    /* System Information 
     * (Bitmask: F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT) */
     _f1ap_GNB_DU_System_Information  system_info;

     /* Bitmask : F1AP_GNB_DU_SERVED_CELL_IE_EXTENSION_PRESENT */
     //_f1ap_GNB_DU_Served_Cells_Item_iE_Extensions iE_Extensions;

} _f1ap_GNB_DU_Served_Cells_List_element;


/* Served cells list */
typedef struct  _f1ap_GNB_DU_Served_Cells_List
{
    /* Count of served cells */
    unsigned int   count;

    /* Configuration of served cells */
    _f1ap_GNB_DU_Served_Cells_List_element  
                   served_cell[MAX_CELL_PER_DU];

} _f1ap_GNB_DU_Served_Cells_List;


/*new ASN Changes*/

typedef struct _f1ap_Latest_RRC_Version{
   unsigned int   numbits;
   unsigned char  data[4];
}_f1ap_Latest_RRC_Version;


typedef struct _f1ap_RRC_Version{
    struct {
      unsigned iE_ExtensionsPresent : 1;
   }m;

   _f1ap_Latest_RRC_Version latest_rrc_version;
    
}_f1ap_RRC_Version;

typedef struct _f1ap_rrc_MeasId{
 unsigned char f1ap_rrc_MeasId;
}_f1ap_rrc_MeasId;



typedef struct _f1ap_rrc_PhysCellId{
    unsigned short f1ap_rrc_PhysCellId;
}_f1ap_rrc_PhysCellId;


typedef struct _f1ap_rrc_SINR_Range{
    unsigned char f1ap_rrc_SINR_Range;
}_f1ap_rrc_SINR_Range;

typedef struct _f1ap_rrc_RSRQ_Range{
    unsigned char f1ap_rrc_RSRQ_Range;
}_f1ap_rrc_RSRQ_Range;

typedef struct _f1ap_rrc_RSRP_Range{
    unsigned char f1ap_rrc_RSRP_Range;
}_f1ap_rrc_RSRP_Range;

typedef struct _f1ap_rrc_SSB_Index{
    unsigned short f1ap_rrc_SSB_Index;
}_f1ap_rrc_SSB_Index;

typedef struct _f1ap_rrc_MeasQuantityResults{
   struct {
      unsigned char rsrpPresent;
      unsigned char rsrqPresent;
      unsigned char sinrPresent;
   } m;
   _f1ap_rrc_RSRP_Range rsrp;
   _f1ap_rrc_RSRQ_Range rsrq;
   _f1ap_rrc_SINR_Range sinr;
}_f1ap_rrc_MeasQuantityResults;


typedef struct _f1ap_rrc_ResultsPerSSB_Index {
   struct {
      unsigned ssb_ResultsPresent : 1;
   } m;
   _f1ap_rrc_SSB_Index ssb_Index;
   _f1ap_rrc_MeasQuantityResults ssb_Results;
} _f1ap_rrc_ResultsPerSSB_Index;



typedef struct _f1ap_rrc_CSI_RS_Index{
    unsigned char f1ap_rrc_CSI_RS_Index;
}_f1ap_rrc_CSI_RS_Index;

typedef struct _f1ap_rrc_ResultsPerCSI_RS_Index {
   struct {
      unsigned csi_RS_ResultsPresent : 1;
   } m;
   _f1ap_rrc_CSI_RS_Index csi_RS_Index;
   _f1ap_rrc_MeasQuantityResults csi_RS_Results;
} _f1ap_rrc_ResultsPerCSI_RS_Index;


typedef struct _f1ap_rrc_ResultsPerCSI_RS_IndexList{
    unsigned int count;
    _f1ap_rrc_ResultsPerCSI_RS_Index f1ap_rrc_ResultsPerCSI_RS_Index[4];
}_f1ap_rrc_ResultsPerCSI_RS_IndexList;



typedef struct _f1ap_rrc_ResultsPerSSB_IndexList{
    unsigned int count;
    _f1ap_rrc_ResultsPerSSB_Index f1ap_rrc_ResultsPerSSB_Index[4];
}_f1ap_rrc_ResultsPerSSB_IndexList;


typedef struct _f1ap_rrc_MeasResultNR_measResult_rsIndexResults {
   struct {
      unsigned resultsSSB_IndexesPresent : 1;
      unsigned resultsCSI_RS_IndexesPresent : 1;
   } m;
   _f1ap_rrc_ResultsPerSSB_IndexList resultsSSB_Indexes;
   _f1ap_rrc_ResultsPerCSI_RS_IndexList resultsCSI_RS_Indexes;
} _f1ap_rrc_MeasResultNR_measResult_rsIndexResults;



typedef struct _f1ap_rrc_MeasResultNR_measResult_cellResults {
   struct {
      unsigned resultsSSB_CellPresent : 1;
      unsigned resultsCSI_RS_CellPresent : 1;
   } m;
   _f1ap_rrc_MeasQuantityResults resultsSSB_Cell;
   _f1ap_rrc_MeasQuantityResults resultsCSI_RS_Cell;
} _f1ap_rrc_MeasResultNR_measResult_cellResults;


typedef struct _f1ap_rrc_MeasResultNR_measResult {
   struct {
      unsigned rsIndexResultsPresent : 1;
   } m;
   _f1ap_rrc_MeasResultNR_measResult_cellResults cellResults;
   _f1ap_rrc_MeasResultNR_measResult_rsIndexResults rsIndexResults;
} _f1ap_rrc_MeasResultNR_measResult;



typedef struct _f1ap_rrc_MeasResultNR {
   struct {
      unsigned physCellIdPresent : 1;
      //unsigned cgi_InfoPresent : 1;
         } m;
            _f1ap_rrc_PhysCellId physCellId;
            //_f1ap_rrc_MeasResultNR_cgi_Info cgi_Info;
            _f1ap_rrc_MeasResultNR_measResult measResult;
            //OSRTDList extElem1;
} _f1ap_rrc_MeasResultNR;


typedef struct _f1ap_rrc_MeasResultListNR{
    unsigned int count;
    _f1ap_rrc_MeasResultNR f1ap_rrc_MeasResulNR[4];
}_f1ap_rrc_MeasResultListNR;

typedef struct _f1ap_rrc_ServCellIndex{
    unsigned char f1ap_rrc_ServCellIndex;
}_f1ap_rrc_ServCellIndex;

typedef struct _f1ap_rrc_MeasResultServMO {
   struct {
      unsigned measResultBestNeighCellPresent : 1;
   } m;
   _f1ap_rrc_ServCellIndex servCellId;
   _f1ap_rrc_MeasResultNR measResultServingCell;
   _f1ap_rrc_MeasResultNR measResultBestNeighCell;
   //OSRTDList extElem1;
} _f1ap_rrc_MeasResultServMO;


typedef struct _f1ap_rrc_MeasResultServMOList {
 int count ;
 _f1ap_rrc_MeasResultServMO _f1ap_rrc_MeasResultServMO[6];
}_f1ap_rrc_MeasResultServMOList;



typedef struct _f1ap_rrc_MeasResults_measResultNeighCells {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_MeasResultListNR measResultListNR;
      /* t = 2 */
      //ASN1OpenType *extElem1;
         } u;
} _f1ap_rrc_MeasResults_measResultNeighCells;



typedef struct _f1ap_rrc_MeasResults {
   struct {
      unsigned measResultNeighCellsPresent : 1;
   } m;
   _f1ap_rrc_MeasId measId;
   _f1ap_rrc_MeasResultServMOList measResultServingMOList;
   _f1ap_rrc_MeasResults_measResultNeighCells measResultNeighCells;
   //OSRTDList extElem1;
}_f1ap_rrc_MeasResults;


typedef struct _f1ap_rrc_MeasurementReport_IEs {
   struct {
      unsigned lateNonCriticalExtensionPresent : 1;
      unsigned nonCriticalExtensionPresent : 1;
   } m;
   _f1ap_rrc_MeasResults measResults;
   _ASN1OpenTyp lateNonCriticalExtension;
   //nr_rrc_MeasurementReport_IEs_nonCriticalExtension nonCriticalExtension;
} _f1ap_rrc_MeasurementReport_IEs;


typedef struct _f1ap_rrc_MeasurementReport_criticalExtensions {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_MeasurementReport_IEs measurementReport;
      /* t = 2 */
      //_f1ap_rrc_MeasurementReport_criticalExtensions_criticalExtensionsFuture *criticalExtensionsFuture;
         } u;
} _f1ap_rrc_MeasurementReport_criticalExtensions;


typedef struct _f1ap_rrc_MeasurementReport {
   _f1ap_rrc_MeasurementReport_criticalExtensions criticalExtensions;
} _f1ap_rrc_MeasurementReport;




typedef struct _f1ap_rrc_RRC_TransactionIdentifier{
   unsigned short f1ap_rrc_RRC_TransactionIdentifier;
}_f1ap_rrc_RRC_TransactionIdentifier;


typedef struct _f1ap_rrc_RRCReconfigurationComplete_IEs {
   struct {
      unsigned lateNonCriticalExtensionPresent : 1;
      unsigned nonCriticalExtensionPresent : 1;
   } m;
   _ASN1OpenTyp lateNonCriticalExtension;
   //_f1ap_rrc_RRCReconfigurationComplete_IEs_nonCriticalExtension nonCriticalExtension;
} _f1ap_rrc_RRCReconfigurationComplete_IEs;

typedef struct _f1ap_rrc_RRCReconfigurationComplete_criticalExtensions {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_RRCReconfigurationComplete_IEs rrcReconfigurationComplete;
      /* t = 2 */
      //_f1ap_rrc_RRCReconfigurationComplete_criticalExtensions_criticalExtensionsFuture criticalExtensionsFuture;
         } u;
} _f1ap_rrc_RRCReconfigurationComplete_criticalExtensions;
      
      
typedef struct _f1ap_rrc_RRCReconfigurationComplete{
       _f1ap_rrc_RRC_TransactionIdentifier rrc_TransactionIdentifier;
       _f1ap_rrc_RRCReconfigurationComplete_criticalExtensions criticalExtensions;
}_f1ap_rrc_RRCReconfigurationComplete;
             


typedef struct _f1ap_rrc_UL_DCCH_MessageType_c1 {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_MeasurementReport measurementReport;
      /* t = 2 */
      _f1ap_rrc_RRCReconfigurationComplete rrcReconfigurationComplete;
   } u;
} _f1ap_rrc_UL_DCCH_MessageType_c1;




typedef struct _f1ap_rrc_UL_DCCH_MessageType {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_UL_DCCH_MessageType_c1 c1;
      /* t = 2 */
      //_f1ap_rrc_UL_DCCH_MessageType_messageClassExtension *messageClassExtension;
         } u;
} _f1ap_rrc_UL_DCCH_MessageType;
      
typedef struct _f1ap_gNB_CU_F1AP_ID{

 unsigned int cu_f1ap_id; 
}_f1ap_gNB_CU_F1AP_ID;
         
typedef struct _f1ap_gNB_DU_F1AP_ID{

 unsigned int du_f1ap_id; 
}_f1ap_gNB_DU_F1AP_ID;

typedef struct _f1ap_SRB_ID{

 unsigned int srb_id; 
}_f1ap_SRB_ID;

typedef struct _f1ap_ULRRCMessageTransfer_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * ULRRCMessageTransferIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_gNB_CU_F1AP_ID _f1ap_ULRRCMessageTransferIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_gNB_DU_F1AP_ID _f1ap_ULRRCMessageTransferIEs_2;
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_SRB_ID _f1ap_ULRRCMessageTransferIEs_3;

         //unsigned int msg_type;
         /**
          * id: id-RRCContainer
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_rrc_UL_DCCH_MessageType  _f1ap_ULRRCMessageTransferIEs_4;
      } u;
   } value;
} _f1ap_ULRRCMessageTransfer_protocolIEs_element;


typedef struct _f1ap_ULRRCMessageTransfer_protocolIEs
{
    unsigned int  count;
    _f1ap_ULRRCMessageTransfer_protocolIEs_element
                  _f1ap_ULRRCMessageTransfer_protocolIEs_element[5];
} _f1ap_ULRRCMessageTransfer_protocolIEs;


typedef struct _f1ap_ULRRCMessageTransfer {
   _f1ap_ULRRCMessageTransfer_protocolIEs  protocolIEs;
} _f1ap_ULRRCMessageTransfer;

//DL RRC TRANSFER MESSAGE
typedef struct _f1ap_GNB_CU_UE_F1AP_ID {
   unsigned int f1ap_GNB_CU_UE_F1AP_ID;
} _f1ap_GNB_CU_UE_F1AP_ID;

typedef struct _f1ap_ExecuteDuplication {
   unsigned int f1ap_ExecuteDuplication;
} _f1ap_ExecuteDuplication;


typedef struct _f1ap_GNB_DU_UE_F1AP_ID {
   unsigned int f1ap_GNB_DU_UE_F1AP_ID;
} _f1ap_GNB_DU_UE_F1AP_ID;

typedef struct _f1ap_SubscriberProfileIDforRFP {
   unsigned int f1ap_SubscriberProfileIDforRFP;
} _f1ap_SubscriberProfileIDforRFP;

typedef struct _f1ap_RAT_FrequencySelectionPriority {
   unsigned int f1ap_RAT_FrequencySelectionPriority;
} _f1ap_RAT_FrequencySelectionPriority;


typedef struct _f1ap_RAT_FrequencyPriorityInformation {
   int t;
   union {
      /* t = 1 */
      _f1ap_SubscriberProfileIDforRFP subscriberProfileIDforRFP;
      /* t = 2 */
      _f1ap_RAT_FrequencySelectionPriority rAT_FrequencySelectionPriority;
      /* t = 3 */
     // _f1ap_RAT_FrequencyPriorityInformation_choice_extension choice_extension;
   } u;
} _f1ap_RAT_FrequencyPriorityInformation;


typedef struct _f1ap_rrc_RRCReconfiguration {
   _f1ap_rrc_RRC_TransactionIdentifier rrc_TransactionIdentifier;
   //_f1ap_rrc_RRCReconfiguration_criticalExtensions criticalExtensions;
} _f1ap_rrc_RRCReconfiguration;


typedef struct _f1ap_rrc_DL_DCCH_MessageType_c1 {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_RRCReconfiguration rrcReconfiguration;
   }u;
}_f1ap_rrc_DL_DCCH_MessageType_c1;
 
typedef struct _f1ap_rrc_DL_DCCH_MessageType {
   int t;
   union {
      /* t = 1 */
      _f1ap_rrc_DL_DCCH_MessageType_c1 c1;
      /* t = 2 */
      //_f1ap_rrc_DL_DCCH_MessageType_messageClassExtension messageClassExtension;
   } u;
} _f1ap_rrc_DL_DCCH_MessageType;



typedef struct _f1ap_DLRRCMessageTransfer_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      int t;
      union {
         _f1ap_GNB_CU_UE_F1AP_ID _f1ap_DLRRCMessageTransferIEs_1;
         _f1ap_GNB_DU_UE_F1AP_ID _f1ap_DLRRCMessageTransferIEs_2;
         _f1ap_GNB_DU_UE_F1AP_ID _f1ap_DLRRCMessageTransferIEs_3;
         _f1ap_SRB_ID  _f1ap_DLRRCMessageTransferIEs_4;
         _f1ap_ExecuteDuplication _f1ap_DLRRCMessageTransferIEs_5;
         _f1ap_rrc_DL_DCCH_MessageType _f1ap_DLRRCMessageTransferIEs_6;
         _f1ap_RAT_FrequencyPriorityInformation _f1ap_DLRRCMessageTransferIEs_7;
      } u;
   } value;
} _f1ap_DLRRCMessageTransfer_protocolIEs_element;


typedef struct _f1ap_DLRRCMessageTransfer_protocolIEs
{
    unsigned int  count;
    _f1ap_DLRRCMessageTransfer_protocolIEs_element
                  _f1ap_DLRRCMessageTransfer_protocolIEs_element[5];
} _f1ap_DLRRCMessageTransfer_protocolIEs;


typedef struct _f1ap_DLRRCMessageTransfer {
   _f1ap_DLRRCMessageTransfer_protocolIEs  protocolIEs;
} _f1ap_DLRRCMessageTransfer;


typedef struct _f1ap_F1SetupRequest 
{
   // #define F1_SETUP_REQ_DU_NAME_PRESENT     0x01

//    unsigned int                    bitmask;

    /* TransactionID */
    unsigned int                    transaction_id;

    /* gNB-DU-ID */
    unsigned long                   du_id;

    /* gNB-DU Name */
    unsigned char                   du_name[MAX_DU_NAME_LENGTH];

    /* gNB-DU Served Cells List */
    _f1ap_GNB_DU_Served_Cells_List  served_cells_list;

    _f1ap_RRC_Version  rrc_version;   /*new ASN Changes*/
} _f1ap_F1SetupRequest;


/****************************************************************************
 * F1 SETUP RESPONSE
 ***************************************************************************/

typedef struct _f1ap_F1SetupResponse
{
#define F1_SETUP_RESP_GNB_CU_NAME_PRESENT                 0x01
#define F1_SETUP_RESP_CELLS_TO_BE_ACTIVATED_LIST_PRESENT  0x02

    unsigned int                      bitmask;

    /* TransactionID */
    unsigned int                      transaction_id;
   
    /* gNB-CU Name */
    unsigned char                     cu_name[MAX_DU_NAME_LENGTH];

    /* List of cells to be activated */
    _f1ap_Cells_to_be_Activated_List  cellsToBeActivated;

} _f1ap_F1SetupResponse;


/****************************************************************************
 * F1 SETUP FAILURE
 ***************************************************************************/

typedef enum 
{
   F1AP_V1S  = 0,
   F1AP_V2S  = 1,
   F1AP_V5S  = 2,
   F1AP_V10S = 3,
   F1AP_V20S = 4,
   F1AP_V60S = 5
} f1ap_TimeToWait_Root_et;


typedef struct _f1ap_F1SetupFailure 
{
#define F1_SETUP_FAILURE_TIME_TO_WAIT_PRESENT       0x01
#define F1_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT   0x02

    unsigned int                  bitmask;

    /* Transaction ID */
    unsigned int                  transaction_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* TimeToWait (f1ap_TimeToWait_Root_et) */
    unsigned int                  timeToWait;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_F1SetupFailure;


/********************************************************************
 *  gNB CU CONFIGURATION UPDATE
 *******************************************************************/

typedef struct _f1ap_Cells_to_be_Deactivated_List_element 
{
    /* NCGI */
    _f1ap_NCGI      cgi;

} _f1ap_Cells_to_be_Deactivated_List_element;


/* List of cells to be de-activated */
typedef struct _f1ap_Cells_to_be_Deactivated_List
{
    /* Count of cells to be de-activated */
    unsigned int    count;

    /* Identifier of each cell to be de-activated */
    _f1ap_Cells_to_be_Deactivated_List_element  
                    cell_to_deactivate[MAX_CELL_PER_DU];

} _f1ap_Cells_to_be_Deactivated_List;


typedef struct _f1ap_GNBCUConfigurationUpdate 
{
#define F1AP_CELLS_TO_BE_ACTIVATED_LIST_PRESENT    0x01
#define F1AP_CELLS_TO_BE_DEACTIVATED_LIST_PRESENT  0x02

    unsigned char   bitmask;

    /* Unique transaction identifier */
    unsigned int    transaction_id;

    /* Cells to be Activated List */
    _f1ap_Cells_to_be_Activated_List    
                    cellsToBeActivatedList;
    
    /* Cells to be Deactivated List */
    _f1ap_Cells_to_be_Deactivated_List  
                    cellsToBeDeactivatedList;

} _f1ap_GNBCUConfigurationUpdate;



/**********************************************************************
 * gNB CU CONFIGURATION UPDATE ACKNOWLEDGE
 *********************************************************************/

typedef struct _f1ap_Cells_Failed_to_be_Activated_List_element 
{
    /* NCGI */
    _f1ap_NCGI   cgi;

    /* Cause */
    _f1ap_Cause  cause;

} _f1ap_Cells_Failed_to_be_Activated_List_element;


/* List of cells which failed to be activated */
typedef struct  _f1ap_Cells_Failed_to_be_Activated_List
{
    /* Count of cells present in the list */
    unsigned int   count;

    /* Identifier of each cell present in the list */
    _f1ap_Cells_Failed_to_be_Activated_List_element
                   cellFailedToBeActivated[MAX_CELL_PER_DU];

} _f1ap_Cells_Failed_to_be_Activated_List;


typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge 
{
#define F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT     0x02
#define F1AP_CU_CONFIG_UPDATE_CELLS_FAILED_TO_BE_ACTIVATED_LIST_PRESENT  0x01

    unsigned int       bitmask;

    /* Unique transaction identifier */
    unsigned int             transaction_id;

    /* Cells Failed to be Activated List 
     * (Bitmask:
     * F1AP_CU_CONFIG_UPDATE_CELLS_FAILED_TO_BE_ACTIVATED_LIST_PRESENT) */
    _f1ap_Cells_Failed_to_be_Activated_List   
                       cellsFailedToBeActivatedList;
    
    /* Criticality Diagnostics 
     * (Bitmask: F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT) */
    _f1ap_CriticalityDiagnostics              
                       criticality_diagnostics;

} _f1ap_GNBCUConfigurationUpdateAcknowledge;



/**********************************************************************
 *  gNB CU CONFIGURATION UPDATE FAILURE
 *********************************************************************/

typedef struct _f1ap_GNBCUConfigurationUpdateFailure 
{
#define F1AP_CU_CFG_UPDATE_TIME_TO_WAIT_PRESENT         0x01
#define F1AP_CU_CFG_UPDATE_CRIT_DIAGNOSTICS_PRESENT     0x02

    unsigned int                   bitmask;

    f1ap_adpt_response_et          response;
    /* Unique transaction identifier */
    unsigned int                          transaction_id;

    /* Cause */
    _f1ap_Cause                    cause;

    /* TimeToWait (f1ap_TimeToWait_Root_et) */
    unsigned int                   timeToWait;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics   criticality_diagnostics;

} _f1ap_GNBCUConfigurationUpdateFailure;


/**********************************************************************
 *  gNB DU CONFIGURATION UPDATE
 *********************************************************************/

typedef struct _f1ap_Served_Cells_To_Add_List_element 
{

#define F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT   0x01
#define F1AP_GNB_DU_SERVED_CELL_IE_EXTENSION_PRESENT  0x02

    unsigned char  bitmask;
    /* Served Cell Information */
    _f1ap_Served_Cell_Information    served_cell_info;

    /* gNB-DU System Information */
    _f1ap_GNB_DU_System_Information  system_info;

} _f1ap_Served_Cells_To_Add_List_element;


/* List of cells to be added */
typedef struct  _f1ap_Served_Cells_To_Add_List
{
    /* Count of cells to be added */
    unsigned int  count;

    /* Configuration of the cells to be added */
    _f1ap_Served_Cells_To_Add_List_element  
                  cell_to_add[MAX_CELL_PER_DU];

} _f1ap_Served_Cells_To_Add_List;


typedef struct _f1ap_Served_Cells_To_Modify_List_element 
{
#define DU_CONFIG_UPDATE_CELL_TO_MODIFY_SYSTEM_INFO_PRESENT  0x01

    unsigned int                     bitmask;

    /* Old NCGI */
    _f1ap_NCGI                       old_ncgi;

    /* Served Cell Information */
    _f1ap_Served_Cell_Information    served_cell_info;

    /* gNB-DU System Information */
    _f1ap_GNB_DU_System_Information  du_system_info;

} _f1ap_Served_Cells_To_Modify_List_element;


/* List of cells to be modified */
typedef struct _f1ap_Served_Cells_To_Modify_List
{
    /* Count of cells to be modified */
    unsigned int  count;

    /* Identifier of the cells to be modified */
    _f1ap_Served_Cells_To_Modify_List_element  
                  cell_to_modify[MAX_CELL_PER_DU];

}_f1ap_Served_Cells_To_Modify_List;


typedef struct _f1ap_Served_Cells_To_Active_List_element 
{
    /* Old NCGI */
    _f1ap_NCGI   ncgi;

} _f1ap_Served_Cells_To_Active_List_element;


typedef struct _f1ap_Served_Cells_To_Active_List
{
    /* Count of cells to be deleted */
    unsigned int  count;

    /* Identifier of the cells to be deleted */
    _f1ap_Served_Cells_To_Active_List_element  
                  cell_to_Active[MAX_CELL_PER_DU];

} _f1ap_Served_Cells_To_Active_List;



typedef struct _f1ap_Served_Cells_To_Delete_List_element 
{
    /* Old NCGI */
    _f1ap_NCGI   ncgi;

} _f1ap_Served_Cells_To_Delete_List_element;


/* List of cells to be deleted */
typedef struct _f1ap_Served_Cells_To_Delete_List
{
    /* Count of cells to be deleted */
    unsigned int  count;

    /* Identifier of the cells to be deleted */
    _f1ap_Served_Cells_To_Delete_List_element  
                  cell_to_delete[MAX_CELL_PER_DU];

} _f1ap_Served_Cells_To_Delete_List;


typedef struct  _f1ap_GNBDUConfigurationUpdate 
{
#define DU_CONFIG_UPDATE_CELLS_TO_ADD_LIST_PRESENT    0x01
#define DU_CONFIG_UPDATE_CELLS_TO_MOD_LIST_PRESENT    0x02
#define DU_CONFIG_UPDATE_CELLS_TO_DEL_LIST_PRESENT    0x04
#define DU_CONFIG_UPDATE_CELLS_TO_ACTIVE_LIST_PRESENT 0x08

    unsigned int                        bitmask;

    unsigned int                        TransactionID; 
    /* Served Cells to Add List */
    _f1ap_Served_Cells_To_Add_List      cellsToAddList;

    /* Served Cells to Modify List */
    _f1ap_Served_Cells_To_Modify_List   cellsToModifyList;

    /* Served Cells to Delete List */
    _f1ap_Served_Cells_To_Delete_List   cellsToDeleteList;

    _f1ap_Served_Cells_To_Active_List   cellsToActiveList;
   

} _f1ap_GNBDUConfigurationUpdate;



/**********************************************************************
 * GNB DU CONFIGURATION UPDATE ACK
 *********************************************************************/

typedef struct _f1ap_GNBDUConfigurationUpdateAcknowledge 
{
#define F1AP_DU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT    0x01

    unsigned int                      bitmask;

    unsigned int                      trans_id;
    /* Cells to be Activated List */
    _f1ap_Cells_to_be_Activated_List  cells_to_be_activated_list;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics      criticality_diagnostics;

} _f1ap_GNBDUConfigurationUpdateAcknowledge;



/**********************************************************************
 * GNB DU CONFIGURATION UPDATE FAILURE
 *********************************************************************/

typedef struct _f1ap_GNBDUConfigurationUpdateFailure 
{
#define DU_CONFIG_UPDATE_FAILURE_TIME_TO_WAIT_PRESENT   0x01
#define DU_CONFIG_UPDATE_FAILURE_CRIT_DIAG_PRESENT      0x02

    unsigned int                  bitmask;
    unsigned int                  response; 
    unsigned int                  transaction_id ;
 
    /* Cause */
    _f1ap_Cause                   cause;

    /* TimeToWait */
    unsigned int                  timeToWait;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_GNBDUConfigurationUpdateFailure;



/***************************************************************************
 *  RESET REQUEST
 **************************************************************************/

typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListRes_element 
{
#define UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT    0x01
#define UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT    0x02

    unsigned int bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int gNB_CU_F1AP_ID;

    /* gNB-DU UE F1AP ID */
    unsigned int gNB_DU_F1AP_ID;

} _f1ap_UE_associatedLogicalF1_ConnectionListRes_element;


/* Logical F1 connections list in case of partial RESET */
typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListRes
{
    /* Count of Logical F1 connections */
    unsigned int  count;

    /* List of Logical F1 connections */
    _f1ap_UE_associatedLogicalF1_ConnectionListRes_element  
                  ue_associated_connection[MAX_F1_CONN_RESET];

} _f1ap_UE_associatedLogicalF1_ConnectionListRes;


typedef struct _f1ap_ResetType 
{
#define F1AP_RESET_TYPE_COMPLETE    0x01
#define F1AP_RESET_TYPE_PARTIAL     0x02

    unsigned int     type;

    union 
    {
        /* Complete Reset */
        unsigned int  f1_Interface;

        /* Logical F1 connection list in case of partial Reset */
        _f1ap_UE_associatedLogicalF1_ConnectionListRes  
                      partOfF1_Interface;
    } u;

} _f1ap_ResetType;


typedef struct  _f1ap_Reset 
{
    /* TransactionID */
    unsigned int     transactionId;

    /* Cause */
    _f1ap_Cause      cause;

    /* ResetType */
    _f1ap_ResetType  resetType;

} _f1ap_Reset;


/***************************************************************************
 *  RESET ACKNOWLEDGE
 **************************************************************************/

typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element 
{
#define UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT    0x01
#define UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT    0x02

    unsigned int bitmask;

    /* gNB CU UE F1AP ID */
    unsigned int gnb_cu_f1ap_id;

    /* gNB DU UE F1AP ID */
    unsigned int gnb_du_f1ap_id;

} _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element;


/* Logical F1 connections list present in the Reset ACK */
typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListResAck
{
    /* Count of the connections in the list */
    unsigned int  count;

    /* Logical F1 Connection information */
    _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element
                  ue_associated_connection[MAX_F1_CONN_RESET];

} _f1ap_UE_associatedLogicalF1_ConnectionListResAck;


typedef struct _f1ap_ResetAcknowledge 
{

#define F1AP_RESET_ACK_ASS0CIATE_PRESENT   0x01
#define F1AP_RESET_ACK_CRIT_DIAG_PRESENT   0x02

    unsigned int    bitmask;

    /* Transaction ID */
    unsigned int    transactionId;

    /* UE associated Logical F1 Connections List */
    _f1ap_UE_associatedLogicalF1_ConnectionListResAck  
                    ue_associated_connection_list;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics   
                    criticality_diagnostics;

} _f1ap_ResetAcknowledge;


/**********************************************************************
 * F1 INITIAL UL RRC MESSAGE TRANSFER
 **********************************************************************/


typedef struct _f1ap_SULAccessIndication{

        unsigned int sul_access_indication;

}_f1ap_SULAccessIndication;

typedef struct _f1ap_DUtoCURRCContainer
{
        unsigned int numocts;
        unsigned char  data[500];

}_f1ap_DUtoCURRCContainer;

typedef struct _f1ap_C_RNTI{

        unsigned int c_rnti;

}_f1ap_C_RNTI;


typedef struct _f1ap_GNB_DU_UE_F1AP_ID_t{

        unsigned int gnb_du_ue_f1ap_id;

}_f1ap_GNB_DU_UE_F1AP_ID_t;

typedef struct _f1ap_InitialULRRCMessageTransfer_protocolIEs_element {

   unsigned short id;
   unsigned int criticality;

   struct {
      unsigned int t;

      union {
          _f1ap_GNB_DU_UE_F1AP_ID_t     _f1ap_InitialULRRCMessageTransferIEs_1;
         _f1ap_NCGI                     _f1ap_InitialULRRCMessageTransferIEs_2;
         _f1ap_C_RNTI                   _f1ap_InitialULRRCMessageTransferIEs_3;
         _f1ap_rrc_UL_DCCH_MessageType  _f1ap_InitialULRRCMessageTransferIEs_4;
         _f1ap_DUtoCURRCContainer       _f1ap_InitialULRRCMessageTransferIEs_5;
         _f1ap_SULAccessIndication      _f1ap_InitialULRRCMessageTransferIEs_6;

      } u;
   } value;
} _f1ap_InitialULRRCMessageTransfer_protocolIEs_element;

typedef struct _f1ap_InitialULRRCMessageTransfer_protocolIEs
{
    unsigned int  count;

    _f1ap_InitialULRRCMessageTransfer_protocolIEs_element
                  f1ap_InitialULRRCMessageTransfer_protocolIEs_element[6];

}_f1ap_InitialULRRCMessageTransfer_protocolIEs;


typedef struct _f1ap_InitialULRRCMessageTransfer {

   _f1ap_InitialULRRCMessageTransfer_protocolIEs  protocolIEs;

}_f1ap_InitialULRRCMessageTransfer;



/***************************************************************************
 *  ERROR INDICATION 
 **************************************************************************/

typedef struct _f1ap_ErrorIndication 
{
#define F1AP_ERROR_INDICATION_CU_UE_F1AP_ID_PRESENT   0x01
#define F1AP_ERROR_INDICATION_DU_UE_F1AP_ID_PRESENT   0x02
#define F1AP_ERROR_INDICATION_CAUSE_PRESENT           0x04
#define F1AP_ERROR_INDICATION_CRIT_DIAG_PRESENT       0x08

    unsigned int                  bitmask;

    /* TransactionID */
    unsigned int                  transactionId;

    /* gNB-CU UE F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU UE F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_ErrorIndication;


#endif // _F1AP_INTF_MGMNT_H_
