#ifndef _F1AP_ADPT_INTF_H_
#define _F1AP_ADPT_INTF_H_

#include "cg_config_info.h"
#include "cell_group_config.h"
#include "f1ap_asn_common.h"
#define MAX_DRB_PER_UE      32
#define MAX_SRB_PER_UE      32
#define MAX_NO_OF_SCELLS    64
//#define MAX_NUM_CELL_PER_DU     2
#define MAX_GNB_CU_NAME_LENGTH  50
#define CELL_GROUP_CONFIG_BUF_LEN  60000
#define DU_F1AP_MAX_ASN1_BUF_LEN   8192


/* Enum defining the APIs used between F1AP and
 * ADPT modules. */
typedef enum
{
    F1AP_ADPT_UE_CONTEXT_SETUP_REQ    = 0x000080A0,
    F1AP_ADPT_UE_CONTEXT_SETUP_RESP   = 0x000080A1,
    F1AP_ADPT_UE_CONTEXT_MOD_REQ      = 0x000080B0,
    F1AP_ADPT_UE_CONTEXT_MOD_RESP     = 0x000080B1,
    F1AP_ADPT_UE_CONTEXT_REL_COMMAND  = 0x000080C0,
    F1AP_ADPT_UE_CONTEXT_REL_COMPLETE = 0x000080C1,
    F1AP_ADPT_F1_SETUP_REQ            = 0x000080D0,
    F1AP_ADPT_F1_SETUP_CNF            = 0x000080D1,
    F1AP_ADPT_CU_CONFIG_UPDATE_REQ    = 0x000080E0,
    F1AP_ADPT_CU_CONFIG_UPDATE_RESP   = 0x000080E1,
    F1AP_ADPT_DU_CONFIG_UPDATE_REQ    = 0x000080F0,
    F1AP_ADPT_DU_CONFIG_UPDATE_RESP   = 0x000080F1

} f1ap_adpt_api_et;


typedef enum 
{
    F1AP_ADPT_RESP_FAILURE  = 0,
    F1AP_ADPT_RESP_SUCCESS  = 1,
} f1ap_adpt_response_et;


/***************************************************************************
 * IE DEFINITIONS
 **************************************************************************/

/* Cause */
typedef struct _f1ap_adpt_cause_t 
{
#define F1_CAUSE_RADIO_NETWORK    1
#define F1_CAUSE_TRANSPORT        2 
#define F1_CAUSE_PROTOCOL         3
#define F1_CAUSE_MISC             4

   /* Cause type */
   UInt32     cause_type;

   union 
   {
      /* t = 0 */
      UInt32  radio_network;

      /* t = 1 */
      UInt32  transport;

      /* t = 2 */
      UInt32  protocol;

      /* t = 3 */
      UInt32  misc;
   } u;

} f1ap_adpt_cause_t;

typedef struct _f1ap_adpt_coordination_info_t 
{
    UInt32   num_bits;
    UInt8    data[550]; 
} f1ap_adpt_coordination_info_t;


/* NR Cell Identitiy */
typedef struct _f1ap_adpt_nr_cell_identity_t 
{
    UInt32   num_bits;
    UInt8    data[5]; 
} f1ap_adpt_nr_cell_identity_t;


/* PLMN Identity */
typedef struct _f1ap_adpt_plmn_identity_t 
{
    UInt32   	numocts; 
    UInt8       data[3];  
} f1ap_adpt_plmn_identity_t;


/* CGI for Served cell */
typedef struct _f1ap_adpt_ncgi_t 
{
    f1ap_adpt_plmn_identity_t     plmn_identity;
    f1ap_adpt_nr_cell_identity_t  nr_cellidentity;
} f1ap_adpt_ncgi_t;

typedef struct _f1ap_adpt_ecgi_t 
{
    f1ap_adpt_plmn_identity_t   plmn_identity;
    UInt8                       cellidentity[4];
/*^ M, 0, OCTET_STRING, FIXED ^*/
} f1ap_adpt_ecgi_t;


typedef struct _f1ap_adpt_scell_to_be_setup_list_element_t 
{
    /* SCell-ID */
    f1ap_adpt_ncgi_t     cgi;

    /* Scell Index */
    UInt16               scell_index; 
    UInt32               sCellULConfigured;   


} f1ap_adpt_scell_to_be_setup_list_element_t;


#define F1AP_ADPT_UE_CTX_SETUP_REQ_duplicationIndication_PRESENT                        0x01
typedef struct _f1ap_adpt_srb_to_be_setup_list_element_t 
{
    UInt16               sRBID;
    UInt32               duplicationIndication;   
} f1ap_adpt_srb_to_be_setup_list_element_t;



typedef struct _f1ap_adpt_spcell_to_be_setup_list_element_t 
{
    /* SCell-ID */
    f1ap_adpt_ncgi_t     cgi;



} f1ap_adpt_spcell_to_be_setup_list_element_t;


typedef struct _f1ap_adpt_spcell_tobesetup_list_t
{
    UInt32   count;

    f1ap_adpt_spcell_to_be_setup_list_element_t  
             scell_to_be_setup[MAX_NO_OF_SCELLS];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_spcell_to_be_setup_list_t;


typedef struct _f1ap_adpt_scell_tobesetup_list_t
{
    UInt32   count;

    f1ap_adpt_scell_to_be_setup_list_element_t  
             scell_to_be_setup[MAX_NO_OF_SCELLS];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_scell_to_be_setup_list_t;

typedef struct _f1ap_adpt_srb_tobesetup_list_t
{
    UInt32   count;

    f1ap_adpt_srb_to_be_setup_list_element_t  
             srb_to_be_setup[MAX_NO_OF_SCELLS];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_srb_to_be_setup_list_t;


typedef struct _f1ap_adpt_gtp_teid_t 
{
   UInt32   num_octs;
   UInt8    data[4];
/*^ M, 0, OCTET_STRING, FIXED ^*/
} f1ap_adpt_gtp_teid_t;


typedef struct _f1ap_adpt_gtp_tunnel_endpoint_t 
{
   UInt8                 transport_address_length;
   UInt8                 transport_layer_address[20];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/
   f1ap_adpt_gtp_teid_t  gtp_teid;
} f1ap_adpt_gtp_tunnel_endpoint_t;


typedef struct _f1ap_adpt_ul_tunnels_to_be_setup_list_element_t 
{
    
    UInt32     type;
    /* UL-GTP-Tunnel-EndPoint */
    union{
    f1ap_adpt_gtp_tunnel_endpoint_t  tunnelep;
    }u;

} f1ap_adpt_ul_tunnels_to_be_setup_list_element_t;


typedef struct _f1ap_adpt_ul_tunnels_to_be_setup_list_t
{
    UInt32    count;

    f1ap_adpt_ul_tunnels_to_be_setup_list_element_t  
              ul_tunnel_tobe_setup[2];

} f1ap_adpt_ul_tunnels_to_be_setup_list_t;


typedef struct _f1ap_adpt_allocation_and_retention_priority_t 
{
    UInt8     priority_level;
    UInt32    pre_emption_capability;
    UInt32    pre_emption_vulnerability;
} f1ap_adpt_allocation_and_retention_priority_t;


typedef struct _f1ap_adpt_gbr_qos_information_t 
{
   UInt64    e_rab_maximum_bitrate_dl;
   UInt64    e_rab_maximum_bitrate_ul;
   UInt64    e_rab_guaranteed_bitrate_dl;
   UInt64    e_rab_guaranteed_bitrate_ul;
} f1ap_adpt_gbr_qos_information_t;



#define F1AP_ADPT_QOSPRIORITY_LEVEL_PRESENT   0x01
#define F1AP_ADPT_AVRGWINDOW_PRESENT   0x02
#define F1AP_ADPT_MAXDATABRUST_PRESENT   0x03


typedef struct _f1ap_NonDynamic5QIDescriptor_t 
{
   UInt8    fiveQI;
   UInt8    qoSPriorityLevel;
   UInt8    averagingWindow;
   UInt8    maxDataBurstVolume;

} f1ap_NonDynamic5QIDescriptor_t;


#define F1AP_ADPT_DELEYCRITICAL_PRESENT   0x01
#define F1AP_ADPT_AVRGWINDOW_PRESENT   0x02
#define F1AP_ADPT_MAXDATABRUST_PRESENT   0x03


typedef struct _f1ap_Dynamic5QIDescriptor_t 
{
   UInt8    qoSPriorityLevel;
   UInt8    packetDelayBudget;
   UInt8    packetErrorRate;
   UInt32   delayCritical;
   UInt8    averagingWindow;
   UInt8    maxDataBurstVolume;

} f1ap_Dynamic5QIDescriptor_t;


typedef struct _f1ap_adpt_QoS_Characteristics_t 
{
    UInt32     type;

    union {

    f1ap_NonDynamic5QIDescriptor_t  non_Dynamic_5QI;
    f1ap_Dynamic5QIDescriptor_t dynamic_5QI;
    
    }u;

} f1ap_adpt_QoS_Characteristics_t;



typedef struct _f1ap_NGRANAllocationAndRetentionPriority_t 
{

   UInt8    PriorityLevel;
   UInt8    pre_emptionCapability;
   UInt8    pre_emptionVulnerability;
   UInt8    qoSPriorityLevel;

}f1ap_NGRANAllocationAndRetentionPriority_t   ;

typedef struct _f1_QoS_Flow_Informationn_t 
{

#define F1AP_ADPT_GBR_QOS_FLOW_MAXPACKETLOSSRATEDL_PRESENT   0x01
#define F1AP_ADPT_GBR_QOS_FLOW_MAXPACKETLOSSRATEUL_PRESENT   0x01
   UInt32    bitmask;
   UInt64    maxFlowBitRateDownlink;
   UInt64    maxFlowBitRateUplink;
   UInt64    guaranteedFlowBitRateDownlink;
   UInt64    guaranteedFlowBitRateUplink;
   UInt16    maxPacketLossRateDownlink;
   UInt16    maxPacketLossRateUplink;

}f1_QoS_Flow_Informationn_t   ;


typedef struct _f1ap_gbr_qos_information_t 
{
   UInt64    maximum_bitrate_dl;
   UInt64    maximum_bitrate_ul;
   UInt64    guaranteed_bitrate_dl;
   UInt64    guaranteed_bitrate_ul;
   UInt16    maxPacketLossRateDownlink;
   UInt16    maxPacketLossRateUplink;

} f1ap_gbr_qos_information_t;


typedef struct _f1ap_QoSFlowLevelQoSParameters_t 
{
#define F1AP_ADPT_GBR_QOS_FLOW_PRESENT   0x01
#define F1AP_ADPT_GBR_REFLECTIVE_QOS_INFO_PRESENT   0x02


    UInt32    bitmask;

    f1ap_adpt_QoS_Characteristics_t     qoS_Characteristics;

    f1ap_NGRANAllocationAndRetentionPriority_t nGRANallocationRetentionPriority;


    f1_QoS_Flow_Informationn_t              
              gbr_qos_information;
   /*^ O,F1AP_ADPT_GBR_QOS_INFO_PRESENT , N , 0, 0 ^*/

    UInt32 reflective_QoS_Attribute;


} f1ap_QoSFlowLevelQoSParameters_t;

typedef struct _f1ap_SNSSAI_sST_t 
{
    UInt32   	numocts; 
    UInt8       data[3];  
} f1ap_SNSSAI_sST_t;


typedef struct _f1ap_SNSSAI_sD_t 
{
    UInt32   	numocts; 
    UInt8       data[3];  
} f1ap_SNSSAI_sD_t;


typedef struct _f1ap_SNSSAI_t 
{
#define F1AP_ADPT_SD_INFO_PRESENT   0x01
    UInt32    bitmask;
    f1ap_SNSSAI_sST_t sST;
    f1ap_SNSSAI_sD_t  sD;


}f1ap_SNSSAI_t;


typedef struct _f1ap_Flows_Mapped_To_DRB_Item_t
{
    UInt8 qoSFlowIndicator;
    f1ap_QoSFlowLevelQoSParameters_t  qoSFlowLevelQoSParameters;
}f1ap_Flows_Mapped_To_DRB_Item_t;

typedef struct _f1ap_Flows_Mapped_To_DRB_List_t
{
    /* Count of DRBs present in the list */
    UInt32                                count;

    /* Information of each DRB present in the list */
    f1ap_Flows_Mapped_To_DRB_Item_t     drb_to_setup_elem[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_Flows_Mapped_To_DRB_List_t;




typedef struct _f1ap_adpt_dRB_Information_t 
{
#define F1AP_ADPT_NOTIFICATION_INFO_PRESENT   0x01


    UInt32    bitmask;

    f1ap_QoSFlowLevelQoSParameters_t     dRB_QoS;
    
    f1ap_SNSSAI_t     sNSSAI;

    UInt32        notificationControl;
    
    f1ap_Flows_Mapped_To_DRB_List_t flows_Mapped_To_DRB_List;    

} f1ap_adpt_dRB_Information_t;







typedef struct _f1ap_adpt_eutran_qos_t 
{
#define F1AP_ADPT_GBR_QOS_INFO_PRESENT   0X01

    UInt32    bitmask;

    UInt8     qci;

    f1ap_adpt_allocation_and_retention_priority_t  
              allocation_and_retention_priority;

    f1ap_adpt_gbr_qos_information_t              
              gbr_qos_information;
   /*^ O,F1AP_ADPT_GBR_QOS_INFO_PRESENT , N , 0, 0 ^*/

} f1ap_adpt_eutran_qos_t;


typedef enum
{
    RLC_MODE_AM,
    RLC_MODE_UM,
    RLC_MODE_UM_UNIDIR_UL,
    RLC_MODE_UM_UNIDIR_DL

} f1ap_adpt_rlc_mode_et;


typedef enum
{
    F1AP_ADPT_NO_DATA = 0,
    F1AP_ADPT_SHARED  = 1,
    F1AP_ADPT_ONLY    = 2
}f1ap_adpt_ul_configuration_et;


typedef struct _f1ap_QoSInformation_t 
{

     UInt32 type;

    union{ 
    f1ap_adpt_eutran_qos_t      qos;

    f1ap_adpt_dRB_Information_t  *dRB_Information;

   }u;

}f1ap_QoSInformation_t;

typedef struct _f1ap_adpt_drbs_to_be_setup_list_element_t 
{
#define F1AP_UE_UL_CONFIGURATION_PRESENT    0x01
    UInt32                      bitmask;

    /* DRB ID */
    UInt32                      drb_id;

        /* EUTRAN QoS */
    f1ap_QoSInformation_t       qoSInformation;    
    //f1ap_adpt_eutran_qos_t      qos;
    
    //f1ap_adpt_dRB_Information_t  dRB_Information;

    /* List of UL Tunnels to be setup */
    f1ap_adpt_ul_tunnels_to_be_setup_list_t    
        ul_tunnel_list;

    /* RLC Mode */ /* f1ap_adpt_rlc_mode_et */
    UInt32                      rlc_mode;

    /* UL Configuration */  /* f1ap_adpt_ul_configuration_et */
    UInt32                      uLConfiguration;
     /*^ O, F1AP_UE_UL_CONFIGURATION_PRESENT , N , 0, 0 ^*/


    UInt32                      duplicationActivation;

    } f1ap_adpt_drbs_to_be_setup_list_element_t;


/* List of DRBs to be setup */
typedef struct _f1ap_adpt_drbs_to_be_setup_list_t
{
    /* Count of DRBs present in the list */
    UInt32                                count;

    /* Information of each DRB present in the list */
    f1ap_adpt_drbs_to_be_setup_list_element_t     drb_to_setup_elem[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_drbs_to_be_setup_list_t;


typedef struct _f1ap_adpt_dl_tunnels_to_be_setup_list_element_t 
{

    UInt32 type;
    union{ 
    /* DL GTP Tunnel EndPoint */
    f1ap_adpt_gtp_tunnel_endpoint_t        gtp_tunnelep;

    }u;
} f1ap_adpt_dl_tunnels_to_be_setup_list_element_t;


/* List of DL tunnels */
typedef struct _f1ap_adpt_dltunnels_tobesetup_list_t
{
    /* Count of DL tunnels present in the list */
    UInt32                                    count;

    /* Information of each tunnel present in the list */
    f1ap_adpt_dl_tunnels_to_be_setup_list_element_t   dl_tunnel_to_setup[2];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_dl_tunnels_to_be_setup_list_t;


typedef struct  _f1ap_adpt_drbs_setup_list_element_t 
{
    /* DRB ID */
    UInt32                                drb_id;

    UInt32                                lCID; 
    /* List of DL tunnels for this DRB */
    f1ap_adpt_dl_tunnels_to_be_setup_list_t    dl_tunnels_list;

} f1ap_adpt_drbs_setup_list_element_t;


/* List of DRBs which failed to setup */
typedef struct _f1ap_adpt_drbs_setup_list_t
{
    /* Count of DRBs present in the list */
    UInt32                            count;

    /* Information of each DRB present in the list */
    f1ap_adpt_drbs_setup_list_element_t     drb_to_setup[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_drbs_setup_list_t;


typedef struct _f1ap_adpt_drbs_failed_to_be_setup_list_element_t 
{
#define F1AP_ADPT_UE_CTX_RESP_DRB_FAILED_TO_SETUP_CAUSE_PRESENT   0x01

    UInt8               bitmask; 
    /*^ BITMASK ^*/

    /* DRB ID */
    UInt32        drb_id;

    /* Cause */
    f1ap_adpt_cause_t   cause;

} f1ap_adpt_drbs_failed_to_be_setup_list_element_t;


/* List of DRBs which failed to setup */
typedef struct _f1ap_adpt_drbs_failed_to_be_setup_list_t
{
    /* Count of DRBs present in the list */
    UInt32                                    count;

    /* Identifier of the DRB which failed to setup */
    f1ap_adpt_drbs_failed_to_be_setup_list_element_t   drb_failed_to_setup[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_drbs_failed_to_be_setup_list_t;


typedef struct _f1ap_adpt_menb_resrc_coordination_info_t
{
    f1ap_adpt_ecgi_t              ecgi;
    f1ap_adpt_coordination_info_t ul_coordination_info;
    f1ap_adpt_coordination_info_t dl_coordination_info;

}f1ap_adpt_menb_resrc_coordination_info_t;


typedef struct _f1ap_adpt_sgnb_resrc_coordination_info_t
{
    f1ap_adpt_ncgi_t               ncgi;
    f1ap_adpt_coordination_info_t  ul_coordination_info;
    f1ap_adpt_coordination_info_t  dl_coordination_info;
} f1ap_adpt_sgnb_resrc_coordination_info_t;


/* Identifiers of the cell to be activated */
typedef struct _f1ap_adpt_cells_to_be_activated_list_element_t 
{
#define F1AP_ADPT_CELL_TO_BE_ACTIVATED_PCI_PRESENT  0x01

    UInt8             bitmask; /*^ BITMASK ^*/

    /* NCGI */
    f1ap_adpt_ncgi_t  cgi;

    /* PCI */
    UInt16            pci;
   /*^ O, F1AP_ADPT_CELL_TO_BE_ACTIVATED_PCI_PRESENT , N , 0, 0 ^*/

} f1ap_adpt_cells_to_be_activated_list_element_t;


/* List of cells to be activated */
typedef struct f1ap_adpt_cells_to_be_activated_list
{
    /* Count of cells in the list */
    UInt32          count;

    /* Identifier of the cell to be activated */ 
    f1ap_adpt_cells_to_be_activated_list_element_t  
                    cell_to_activate[MAX_NUM_CELL_PER_DU];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/


} f1ap_adpt_cells_to_be_activated_list_t;


typedef enum 
{
   F1AP_TIME_TO_WAIT_V1S  = 0,
   TIME_TO_WAIT_F1AP_V2S  = 1,
   TIME_TO_WAIT_F1AP_V5S  = 2,
   TIME_TO_WAIT_F1AP_V10S = 3,
   TIME_TO_WAIT_F1AP_V20S = 4,
   TIME_TO_WAIT_F1AP_V60S = 5
} f1ap_time_to_wait_et;


typedef struct _f1ap_adpt_cells_to_be_deactivated_list_element_t 
{
    /* NCGI */
    f1ap_adpt_ncgi_t      cgi;

} f1ap_adpt_cells_to_be_deactivated_list_element_t;


/* List of cells to be de-activated */
typedef struct _f1ap_adpt_cells_to_be_deactivated_list_t
{
    /* Count of cells to be de-activated */
    UInt32    count;

    /* Identifier of each cell to be de-activated */
    f1ap_adpt_cells_to_be_deactivated_list_element_t  
              cell_to_deactivate[MAX_NUM_CELL_PER_DU];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
} f1ap_adpt_cells_to_be_deactivated_list_t;


typedef struct f1ap_adpt_cells_failed_to_be_activated_list_element 
{
    /* NCGI */
    f1ap_adpt_ncgi_t  cgi;

    /* Cause */
    f1ap_adpt_cause_t cause;

} f1ap_adpt_cells_failed_to_be_activated_list_element_t;


/* List of cells which failed to be activated */
typedef struct  f1ap_adpt_cells_failed_to_be_activated_list
{
    /* Count of cells present in the list */
    UInt32         count;

    /* Identifier of each cell present in the list */
    f1ap_adpt_cells_failed_to_be_activated_list_element_t
                   cellFailedToBeActivated[MAX_NUM_CELL_PER_DU];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_cells_failed_to_be_activated_list_t;


/***************************************************************************
 * API DEFINITIONS
 **************************************************************************/

/*****************************************************************************
 * F1AP_ADPT_F1_SETUP_CNF
 ****************************************************************************/

typedef struct 
{
#define F1AP_ADPT_F1_SETUP_CNF_GNB_CU_NAME_PRESENT                0x01
#define F1AP_ADPT_F1_SETUP_CNF_CELLS_TO_BE_ACTIVATED_LIST_PRESENT 0x02

    UInt32                 bitmask; /*^ BITMASK ^*/

    /* Response (f1ap_adpt_response_et) */
    f1ap_adpt_response_et  response;

    unsigned int                      transaction_id;
    /* gNB-CU Name */
    UInt8                  cu_name[MAX_GNB_CU_NAME_LENGTH];
    /*^ O,F1AP_ADPT_F1_SETUP_CNF_GNB_CU_NAME_PRESENT, OCTET_STRING, FIXED  ^*/


    /* Cells to be Activated List */
    f1ap_adpt_cells_to_be_activated_list_t 
                           cellsToBeActivatedList;
    /*^ O,F1AP_ADPT_F1_SETUP_CNF_CELLS_TO_BE_ACTIVATED_LIST_PRESENT , N , 0, 0 ^*/
    
} f1ap_adpt_f1_setup_cnf_t; /*^ API, F1AP_ADPT_F1_SETUP_CNF ^*/



/*****************************************************************************
 * F1AP_ADPT_CU_CONFIG_UPDATE_REQ 
 ****************************************************************************/

typedef struct 
{
#define F1AP_ADPT_CU_CONFIG_UPDATE_REQ_CELLS_TO_BE_ACTIVATED_LIST_PRESENT   0x01
#define F1AP_ADPT_CU_CONFIG_UPDATE_REQ_CELLS_TO_BE_DEACTIVATED_LIST_PRESENT 0x02

    UInt32                 bitmask; /*^ BITMASK ^*/

    UInt32                 trans_id; 
    /* Cells to be Activated List */
    f1ap_adpt_cells_to_be_activated_list_t 
                           cellsToBeActivatedList;
    /*^ O,F1AP_ADPT_CU_CONFIG_UPDATE_REQ_CELLS_TO_BE_ACTIVATED_LIST_PRESENT, N , 0, 0 ^*/
    
    /* Cells to be Deactivated List */
    f1ap_adpt_cells_to_be_deactivated_list_t   
                           cellsToBeDeactivatedList;
    /*^ O,F1AP_ADPT_CU_CONFIG_UPDATE_REQ_CELLS_TO_BE_DEACTIVATED_LIST_PRESENT, N , 0, 0 ^*/

} f1ap_adpt_cu_config_update_req_t; /*^ API, F1AP_ADPT_CU_CONFIG_UPDATE_REQ ^*/


/*****************************************************************************
 * F1AP_ADPT_CU_CONFIG_UPDATE_RESP 
 ****************************************************************************/

typedef struct 
{
#define F1AP_ADPT_CU_CONFIG_UPDATE_RESP_TRANSE_ID_PRESENT   0x01
#define F1AP_ADPT_CU_CONFIG_UPDATE_RESP_TIME_TO_WAIT_PRESENT   0x02
#define F1AP_ADPT_CU_CONFIG_UPDATE_RESP_CELLS_FAILED_TO_BE_ACTIVATED_LIST_PRESENT  0x03 

    UInt32                bitmask; /*^ BITMASK ^*/

    /* Response (f1ap_adpt_response_et) */
    f1ap_adpt_response_et response;

    /* TimeToWait (f1ap_time_to_wait_et) */
    UInt32                trans_id;
    /*^ O,F1AP_ADPT_CU_CONFIG_UPDATE_RESP_TIME_TO_WAIT_PRESENT, N , 0, 0 ^*/

    /* Cells Failed to be Activated List */
    f1ap_adpt_cells_failed_to_be_activated_list_t   
                          cellsFailedToBeActivatedList;
    /*^ O,F1AP_ADPT_CU_CONFIG_UPDATE_RESP_CELLS_FAILED_TO_BE_ACTIVATED_LIST_PRESENT , N , 0, 0 ^*/

    _f1ap_CriticalityDiagnostics 
                               criticality_diagnostics; 
} f1ap_adpt_cu_config_update_resp_t;  /*^ API, F1AP_ADPT_CU_CONFIG_UPDATE_RESP ^*/


/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_SETUP_REQ
 ****************************************************************************/

typedef struct  _f1ap_DRXCycle {

#define F1AP_ADPT_UE_CTX_SETUP_REQ_shortDRXCycleLength_PRESENT                        0x01
#define F1AP_ADPT_UE_CTX_SETUP_REQ_shortDRXCycleTimer_PRESENT                        0x02


   UInt32 bitmask;
  
   UInt32 longDRXCycleLength;
   UInt32 shortDRXCycleLength;
   UInt32 shortDRXCycleTimer;

} _f1ap_DRXCycle;



typedef struct  _f1ap_RAT_FrequencyPriorityInformation_t {

#define T_f1ap_RAT_FrequencyPriorityInformation_subscriberProfileIDforRFP      1
#define T_f1ap_RAT_FrequencyPriorityInformation_rAT_FrequencySelectionPriority 2
        
        UInt32 type;

       union
       {
       /* t = 1 */ 
       UInt32   subscriberProfileIDforRFP;

       /* t = 2 */
       UInt32    rAT_FrequencySelectionPriority;
        
        }u;
    
    }f1ap_RAT_FrequencyPriorityInformation_t; 

typedef struct _f1ap_adpt_rrc_t 
{
    UInt32   	numocts; 
    UInt8       data[3]; 

} f1ap_adpt_rrc_t;

typedef struct _f1ap_adpt_MaskedIMEIS_t 
{
    UInt32   	numocts; 
    UInt8       data[3]; 

} f1ap_adpt_MaskedIMEIS_t;


typedef struct _f1ap_ResourceCoordinationTransferContainer_t 
{
    UInt32   	numocts; 
    UInt8       data[550]; 

} f1ap_ResourceCoordinationTransferContainer_t;
/*
//#define F1AP_ADPT_UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                        0x01
//#define F1AP_ADPT_UE_CTX_SETUP_REQ_SCELL_TO_SETUP_LIST_PRESENT              0x02

#define F1AP_ADPT_UE_CTX_SETUP_REQ_GNB_DU_UE_F1AP_ID_ID_PRESENT             0x001
#define F1AP_ADPT_UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                        0x002
#define F1AP_ADPT_UE_CTX_SETUP_REQ_SpCellULConfigured_ID_PRESENT            0x004
#define F1AP_ADPT_UE_CTX_SETUP_REQ_DRX_ID_PRESENT                           0x008
#define F1AP_ADPT_UE_CTX_SETUP_REQ_RESOURECE_ID_PRESENT                     0x010
#define F1AP_ADPT_UE_CTX_SETUP_REQ_SCELL_TO_SETUP_LIST_PRESENT              0x020
#define F1AP_ADPT_UE_CTX_SETUP_REQ_SRB_TO_SETUP_LIST_PRESENT                0x040
#define F1AP_ADPT_UE_CTX_SETUP_REQ_DRB_TO_SETUP_LIST_PRESENT                0x080
#define F1AP_ADPT_UE_CTX_SETUP_REQ_INACTIVITYMONITORING_PRESENT             0x100
#define F1AP_ADPT_UE_CTX_SETUP_REQ_RAT_PRESENT                              0x200
#define F1AP_ADPT_UE_CTX_SETUP_REQ_RRCCONTAINER_PRESENT                     0x400
#define F1AP_ADPT_UE_CTX_SETUP_REQ_IMEISV_PRESENT                           0x800
*/
typedef struct _f1ap_adpt_ue_context_setup_req_t 
{
#define F1AP_ADPT_UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                        0x01
#define F1AP_ADPT_UE_CTX_SETUP_REQ_SCELL_TO_SETUP_LIST_PRESENT              0x02
#define F1AP_ADPT_UE_CTX_SETUP_REQ_MENB_RESOURCE_COORDINATION_INFO_PRESENT  0x04

    UInt32                                      bitmask;  /*^ BITMASK ^*/

    /* UE Identifier */
    UInt32                                      ue_index;

    UInt32                     gNBCUUEF1APID;

    UInt32                     gNBDUUEF1APID;
    /* PSCell ID */
    f1ap_adpt_ncgi_t                            pscell_id;

    UInt32                     ServCellndex;

   // UInt32                     SpCellULConfigured;


    /* CU to DU RRC Information Container */
    cg_configinfo_t                             cu_to_du_container; 


  //  f1ap_adpt_spcell_to_be_setup_list_t         spcells_to_be_setup_list;

    
   // _f1ap_DRXCycle                               DRXCycle;  


    //f1ap_ResourceCoordinationTransferContainer_t  ResourceCoordinationTransferContainer;

    /* List of SCells to be setup */
    f1ap_adpt_scell_to_be_setup_list_t          scells_to_be_setup_list;
    /*^ O, F1AP_ADPT_UE_CTX_SETUP_REQ_SCELL_TO_SETUP_LIST_PRESENT , N , 0, 0 ^*/

    //f1ap_adpt_srb_to_be_setup_list_t            srb_to_be_setup_list;
    /* List of DRBs to be setup */
    f1ap_adpt_drbs_to_be_setup_list_t           drbs_to_be_setup_list;


    //UInt32      InactivityMonitoringRequest;

    //f1ap_RAT_FrequencyPriorityInformation_t FrequencyPriorityInformation;

    //f1ap_adpt_rrc_t RRCContainer; 

    //f1ap_adpt_MaskedIMEIS_t MaskedIMEISV;

} f1ap_adpt_ue_context_setup_req_t; /*^ API, F1AP_ADPT_UE_CONTEXT_SETUP_REQ ^*/



/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_SETUP_RESP
 ****************************************************************************/

typedef struct 
{
#define F1AP_ADPT_UE_CTX_SETUP_RESP_DU_TO_CU_CONTAINER_PRESENT                  0x01
#define F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_SETUP_LIST_PRESENT                     0x02
#define F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_FAILED_TO_SETUP_LIST_PRESENT           0x04
#define F1AP_ADPT_UE_CTX_SETUP_RESP_CAUSE_PRESENT                               0x08
#define F1AP_ADPT_UE_CTX_SETUP_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT     0x10

    UInt32                                    bitmask; /*^ BITMASK ^*/

    /* UE Identifier */
    //UInt32                                    ue_index;
    UInt32                 gNBCUUEF1APID;
    UInt32                 gNBDUUEF1APID;

    /* Response (f1ap_adpt_response_et) */
    f1ap_adpt_response_et                     response;

    /* DU to CU RRC Information Container */
    cell_group_config_t                       du_to_cu_container; 
    /*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_DU_TO_CU_CONTAINER_PRESENT, N , 0, 0 ^*/

    /* List of DRBs to be Setup */
    f1ap_adpt_drbs_setup_list_t               drbs_setup_list;
    /*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_SETUP_LIST_PRESENT, N , 0, 0 ^*/

    /* List of DRBs which failed to setup */
    f1ap_adpt_drbs_failed_to_be_setup_list_t  drbs_failed_to_setup_list;
    /*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_FAILED_TO_SETUP_LIST_PRESENT, N , 0, 0 ^*/

    /* Cause */
    f1ap_adpt_cause_t                         cause;
    /*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_CAUSE_PRESENT, N , 0, 0 ^*/

    /* SgNB Resource Coordination Info */
    f1ap_adpt_sgnb_resrc_coordination_info_t  sgnb_resrc_cord_info;
    /*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT, N , 0, 0 ^*/

} f1ap_adpt_ue_context_setup_resp_t; /*^ API, F1AP_ADPT_UE_CONTEXT_SETUP_RESP ^*/



typedef struct _f1ap_Potential_SpCell_List_element
{

   _f1ap_NCGI  potential_SpCell_ID;

} _f1ap_Potential_SpCell_List_element;



typedef struct _f1ap_Potential_SpCell_List
{
    unsigned int                            count;

   _f1ap_Potential_SpCell_List_element  element[2];

} _f1ap_Potential_SpCell_List;



typedef struct _f1ap_adpt_ue_context_setup_fail_t  
{
#define UE_CTX_SETUP_FAILURE_DU_F1AP_ID_PRESENT          0x01
#define UE_CTX_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT    0x02
#define UE_CTX_SETUP_FAILURE_POTENTIAL_SPCELL_PRESENT    0x03

    unsigned int                  bitmask;

    f1ap_adpt_response_et         response;
    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

    _f1ap_Potential_SpCell_List  Potential_SpCell_List;    


} f1ap_adpt_ue_context_setup_fail_t;

/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_MOD_RESP
 ****************************************************************************/
typedef struct _f1ap_adpt_ue_context_mod_fail_t 
{

#define F1AP_ADPT_UE_CTX_MOD_FAILURE_CRIT_DIAGNOSTICS_PRESENT      0x01

	UInt32                         bitmask;   /*^ BITMASK ^*/
	
	UInt32                         ue_index;
	
        f1ap_adpt_response_et         response;

	/* gNB-CU-F1AP-ID*/
	UInt32                         gNBCUUEF1APID;

	/* gNB-DU-F1AP-ID */
	UInt32                         gNBDUUEF1APID;

	/* Cause */
	_f1ap_Cause                    cause;

	/* CriticalityDiagnostics */
	_f1ap_CriticalityDiagnostics   criticality_diagnostics;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_FAILURE_CRIT_DIAGNOSTICS_PRESENT, N , 0, 0 ^*/

}f1ap_adpt_ue_context_mod_fail_t;

/* F1 UE CTXT MOD REQ : SCell_ToBeSetupMod_List structure : Vikash */

typedef struct _f1ap_adpt_scell_to_be_setup_mod_list_element_t
{
 #define    F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_UL_CONFIGURED_PRESENT   0x01
	
    UInt32               bitmask;
    /* SCell-ID */
    f1ap_adpt_ncgi_t     cgi;

    /* Scell Index */
    UInt16               scell_index; 
    UInt32               sCellULConfigured;   


}f1ap_adpt_scell_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_scell_to_be_setup_mod_list_t
{
	UInt32   count;

	f1ap_adpt_scell_to_be_setup_mod_list_element_t  
	 				scell_to_be_setup_mod[MAX_NO_OF_SCELLS];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_scell_to_be_setup_mod_list_t;

/* F1 UE CTXT MOD REQ : SCell_ToBeRemoved_List structure : Vikash */

typedef struct _f1ap_adpt_scell_to_be_removed_list_element_t
{

    /* SCell-ID */
    f1ap_adpt_ncgi_t     cgi;

}f1ap_adpt_scell_to_be_removed_list_element_t;

typedef struct _f1ap_adpt_scell_to_be_removed_list_t
{
	UInt32   count;

	f1ap_adpt_scell_to_be_removed_list_element_t  
	 				scell_to_be_removed[MAX_NO_OF_SCELLS];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_scell_to_be_removed_list_t;

/* F1 UE CTXT MOD REQ : SRBs- To-Be- Setup-Mod-List structure: Vikash */

typedef struct _f1ap_adpt_srb_to_be_setup_mod_list_element_t 
{
#define F1AP_ADPT_UE_CTX_MOD_REQ_DUPLICATION_INDICATION_PRESENT          0x01

	UInt32               bitmask;       /*^ BITMASK ^*/

	UInt16               sRBID;

	UInt32               duplicationIndication;   

}f1ap_adpt_srb_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_srb_to_be_setup_mod_list_t
{
	UInt32   count;

	f1ap_adpt_srb_to_be_setup_mod_list_element_t  
		srb_to_be_setup_mod[MAX_NO_OF_SCELLS];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_srb_to_be_setup_mod_list_t;

/* F1 UE CTXT MOD REQ : DRBs Setup Mod List Structur : Vikash */

typedef struct _f1ap_adpt_ul_tunnels_to_be_setup_mod_list_element_t 
{

	UInt32     type;

	union {

		/* UL-GTP-Tunnel-EndPoint */
		f1ap_adpt_gtp_tunnel_endpoint_t  tunnelep;
	}u;

}f1ap_adpt_ul_tunnels_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_ul_tunnels_to_be_setup_mod_list_t
{
	UInt32    count;

	f1ap_adpt_ul_tunnels_to_be_setup_mod_list_element_t  
							ul_tunnel_tobe_setup_mod[2];

}f1ap_adpt_ul_tunnels_to_be_setup_mod_list_t;


typedef struct _f1ap_adpt_drbs_to_be_setup_mod_list_element_t
{

   #define F1AP_UE_CTXT_MOD_REQ_UL_CONFIGURATION_PRESENT    		0x01
   #define F1AP_UE_CTXT_MOD_REQ_DUPLICATION_ACTIVATION_PRESENT    	0x02

	UInt32                      bitmask;

	/* DRB ID */
	UInt32                      drb_id;

	/* EUTRAN QoS */
	f1ap_QoSInformation_t       qoSInformation;    
	//f1ap_adpt_eutran_qos_t      qos;

	//f1ap_adpt_dRB_Information_t  dRB_Information;

	/* List of UL Tunnels to be setup */
	f1ap_adpt_ul_tunnels_to_be_setup_mod_list_t    
				     			ul_tunnel_setup_mod_list;
	/* RLC Mode */ /* f1ap_adpt_rlc_mode_et */
	//UInt32                      rlc_mode;
	f1ap_adpt_rlc_mode_et         rlc_mode;

	/* UL Configuration */  /* f1ap_adpt_ul_configuration_et */
	//UInt32                      uLConfiguration;
	f1ap_adpt_ul_configuration_et   uLConfiguration;
	/*^ O, F1AP_UE_CTXT_MOD_REQ_UL_CONFIGURATION_PRESENT , N , 0, 0 ^*/

	UInt32                      duplicationActivation;
	/*^ O, F1AP_UE_CTXT_MOD_REQ_DUPLICATION_ACTIVATION_PRESENT, N, 0, 0^*/

}f1ap_adpt_drbs_to_be_setup_mod_list_element_t;



typedef struct _f1ap_adpt_drbs_to_be_setup_mod_list_t
{
	/* Count of DRBs present in the list */
	UInt32                                count;

	/* Information of each DRB present in the list */
	f1ap_adpt_drbs_to_be_setup_mod_list_element_t     
				drb_to_setup_mod_elem[MAX_DRB_PER_UE];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_drbs_to_be_setup_mod_list_t;

/* F1 UE CTXT MOD REQ : DRBs-Modified-List stucture : Vikash */

typedef struct _f1ap_adpt_ul_tunnels_to_be_mod_list_element_t 
{

	UInt32     type;

	union{

		/* UL-GTP-Tunnel-EndPoint */
		f1ap_adpt_gtp_tunnel_endpoint_t  tunnelep;
	}u;

}f1ap_adpt_ul_tunnels_to_be_mod_list_element_t;

typedef struct _f1ap_adpt_ul_tunnels_to_be_mod_list_t
{
	UInt32    count;

	f1ap_adpt_ul_tunnels_to_be_mod_list_element_t  
							ul_tunnel_tobe_mod[2];

}f1ap_adpt_ul_tunnels_to_be_mod_list_t;

typedef struct _f1ap_adpt_drbs_to_be_mod_list_element_t 
{

    #define F1AP_UE_CTXT_MODIFIED_REQ_UL_CONFIGURATION_PRESENT    		0x01
    #define F1AP_UE_CTXT_MODIFIED_REQ_DUPLICATION_ACTIVATION_PRESENT    	0x02

	UInt32                      bitmask;

	/* DRB ID */
	UInt32                      drb_id;

	/* EUTRAN QoS */
	f1ap_QoSInformation_t       qoSInformation;    
	//f1ap_adpt_eutran_qos_t      qos;

	//f1ap_adpt_dRB_Information_t  dRB_Information;

	/* List of UL Tunnels to be setup */
	f1ap_adpt_ul_tunnels_to_be_mod_list_t    
						ul_tunnel_mod_list;

	/* UL Configuration */  /* f1ap_adpt_ul_configuration_et */
	//UInt32                      uLConfiguration;
	f1ap_adpt_ul_configuration_et    uLConfiguration;
	/*^ O, F1AP_UE_CTXT_MOD_REQ_UL_CONFIGURATION_PRESENT , N , 0, 0 ^*/

	UInt32                      duplicationActivation;
	/*^ O, F1AP_UE_CTXT_MOD_REQ_DUPLICATION_ACTIVATION_PRESENT, N, 0, 0^*/

}f1ap_adpt_drbs_to_be_mod_list_element_t;

typedef struct _f1ap_adpt_drbs_to_be_mod_list_t
{
    /* Count of DRBs present in the list */
    UInt32                                count;

    /* Information of each DRB present in the list */
    f1ap_adpt_drbs_to_be_mod_list_element_t     drb_to_mod_elem[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_drbs_to_be_mod_list_t;

/* F1 UE CTXT MOD REQ : SRBS To Be Released List : vikash */

typedef struct _f1ap_adpt_srb_to_be_released_list_element_t 
{

	UInt16               sRBID;

}f1ap_adpt_srb_to_be_released_list_element_t;

typedef struct _f1ap_adpt_srbs_to_be_released_list_t
{
	UInt32   count;

	f1ap_adpt_srb_to_be_released_list_element_t  
					srb_to_be_released[MAX_SRB_PER_UE];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_srbs_to_be_released_list_t;

/* F1 UE CTXT MOD REQ : DRBs To Be Released List : Vikash */

typedef struct _f1ap_adpt_drb_to_be_released_list_element_t 
{

    UInt16               dRBID;

}f1ap_adpt_drb_to_be_released_list_element_t;



typedef struct _f1ap_adpt_drbs_to_be_released_list_t
{
    UInt32   count;

    f1ap_adpt_drb_to_be_released_list_element_t  
             				drb_to_be_released[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_drbs_to_be_released_list_t;


typedef struct _f1ap_adpt_rlc_failure_ind_t
{
		
	UInt32           assocatedLCID;

}f1ap_adpt_rlc_failure_ind_t;


typedef struct _f1ap_UplinkTxDirectCurrentListInformation_t 
{
	UInt32      numocts; 
	UInt8       data[550]; 

}f1ap_UplinkTxDirectCurrentListInformation_t;

/* F1 UE CTXT MOD REQ : CU-DU-RRC-INFO */
typedef struct _f1ap_CG_ConfigInfo_t 
{
    UInt32   	numocts; 
    UInt8       data[550]; 

}f1ap_CG_ConfigInfo_t;

typedef struct _f1ap_UE_CapabilityRAT_ContainerList_t 
{
    UInt32   	numocts; 
    UInt8       data[550]; 

}f1ap_UE_CapabilityRAT_ContainerList_t;

typedef struct _f1ap_MeasConfig_t
{
    UInt32   	numocts; 
    UInt8       data[550]; 

}f1ap_MeasConfig_t;

typedef struct _f1ap_CUtoDURRCInformation_t
{

#define F1AP_UE_CTXT_MODIFIED_REQ_CG_CONFIG_INFO_PRESENT     			0x01
#define F1AP_UE_CTXT_MODIFIED_REQ_EE_CAPABILITYRAT_CONTAINER_LIST_PRESENT	0x02
#define F1AP_UE_CTXT_MODIFIED_REQ_MEASCONFIG_PRESENT				0x04

	UInt32                 	 			bitmask;          /*^ BITMASK ^*/

	/* cG_ConfigInfo */
	f1ap_CG_ConfigInfo_t 				cG_config_info;

	/* UE_CapabilityRAT_ContainerList */
	f1ap_UE_CapabilityRAT_ContainerList_t 		uE_capability_rat_cont_list;

	/* MeasConfig */
	f1ap_MeasConfig_t				meas_config;
 	

}f1ap_CUtoDURRCInformation_t;





/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_MOD_REQ
 ****************************************************************************/

typedef struct {

#define F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_NRCGI_PRESENT					0x000001
#define F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_UL_CONFIGURED_PRESENT				0x000002
#define F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CYCLE_PRESENT					0x000004
#define F1AP_ADPT_UE_CTXT_MOD_REQ_CU_DU_RRC_INFORMATION_CONTAINER_PRESENT		0x000008
#define F1AP_ADPT_UE_CTXT_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT			0x000010 
#define F1AP_ADPT_UE_CTXT_MOD_REQ_MENB_RESOURCE_COORDINATION_INFO_PRESENT  		0x000020
#define F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_RCONFIGURATION_COMPLETE_INDICATOR_PRESENT		0x000040
#define F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_CONTAINER_PRESENT					0x000080
#define F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_SETUP_MOD_LIST_PRESENT				0x000100
#define F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_REMOVED_LIST_PRESENT				0x000200
#define F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_SETUP_MOD_LIST_PRESENT				0x000400
#define F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_SETUP_MOD_LIST_PRESENT				0x000800
#define F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_MODIFIED_LIST_PRESENT				0x001000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_RELEASED_LIST_PRESENT				0x002000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_RELEASED_LIST_PRESENT				0x004000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_INACTIVE_MONITOR_REQUEST_PRESENT			0x008000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_RAT_FREQUENCY_PRIORITY_INFO_PRESENT			0x010000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CONFIGURATION_INDICATOR_PRESENT			0x020000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_RLC_FAILURE_INDICATION_PRESENT			0x040000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_UPLINK_TX_DIRECT_CURRENT_LIST_INFO_PRESENT		0x080000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_GNU_DU_CONFIGURATION_QUERY_PRESENT			0x100000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_BIT_RATE_PRESENT					0x200000
#define F1AP_ADPT_UE_CTXT_MOD_REQ_EXECUTE_DUPLICATION_PRESENT				0x400000

	UInt32                               		bitmask; /*^ BITMASK ^*/


	/* UE Identifier */
	UInt32                               		ue_index;

	/* gNB-CU-UE-F1AP-ID */
	UInt32                               		gNBCUUEF1APID;

	/* gNB-DU-UE-F1AP-ID */
	UInt32                               		gNBDUUEF1APID;

	/* PSCell ID */
	f1ap_adpt_ncgi_t                     		pscell_id;
	/*^ O,F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_NRCGI_PRESENT, N , 0, 0 ^*/

	/* Serv-Cell-Index */
	UInt32                               		servCellndex;

	/* SpCell-UL-Configured */ 
	UInt32                               		spCellULConfigured;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_UL_CONFIGURED_PRESENT, N, 0, 0 ^*/

	/* DRXCycle */
	_f1ap_DRXCycle                       		dRXCycle;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CYCLE_PRESENT, N, 0, 0 ^*/

	/* CU to DU RRC Information Container */
	f1ap_CUtoDURRCInformation_t			cu_du_rrc_info;	
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_CU_DU_RRC_INFORMATION_CONTAINER_PRESENT, N, 0, 0 ^*/

	/* Transmission-Stop-Indicator */
	UInt32                               		trans_stop_indicator;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT, N, 0, 0 ^*/

	/* Resource-Coordination-Transfer-Container */
	f1ap_ResourceCoordinationTransferContainer_t    resrc_coord_trans_contnr;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_MENB_RESOURCE_COORDINATION_INFO_PRESENT, N, 0, 0 ^*/

	/* RRC-Rconfiguration-Complete-Indicator */
	UInt32                               		RRCRconfigurationCompleteIndicator;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_RCONFIGURATION_COMPLETE_INDICATOR_PRESENT, N, 0, 0 ^*/

	/* RRC-Container */
	f1ap_adpt_rrc_t                      		rrc_container;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_CONTAINER_PRESENT, N, 0, 0 ^*/

	/* SCell-To-Be-Setup-Mod-List */
	f1ap_adpt_scell_to_be_setup_mod_list_t   	scells_to_be_setup_mod_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_SETUP_MOD_LIST_PRESENT, N, 0, 0 ^*/

	/* SCell-To-Be-Removed-List */
	f1ap_adpt_scell_to_be_removed_list_t     	scells_to_be_removed_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_REMOVED_LIST_PRESENT, N, 0, 0 ^*/

	/* SRBs-To-Be-Setup-Mod-List */
	f1ap_adpt_srb_to_be_setup_mod_list_t     	srb_to_be_setup_mod_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_SETUP_MOD_LIST_PRESENT, N, 0, 0 ^*/

	/* DRBs-To-Be-Setup-Mod */
	f1ap_adpt_drbs_to_be_setup_mod_list_t    	drbs_to_be_setup_mod_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_SETUP_MOD_LIST_PRESENT, N, 0, 0 ^*/

	/* DRBs-To-Be-Modified-List */
	f1ap_adpt_drbs_to_be_mod_list_t		 	drbs_to_be_mod_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_MODIFIED_LIST_PRESENT, N, 0, 0 ^*/

	/* SRBs-To-Be-Released-List */
	f1ap_adpt_srbs_to_be_released_list_t     	srbs_to_be_released_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_RELEASED_LIST_PRESENT, N, 0, 0 ^*/

	/* DRBs-To-Be-Released-List*/
	f1ap_adpt_drbs_to_be_released_list_t		drbs_to_be_released_list;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_RELEASED_LIST_PRESENT, N, 0, 0 ^*/

	/* Inactivity-Monitoring-Request */
	UInt32                                  	inact_monitor_req;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_INACTIVE_MONITOR_REQUEST_PRESENT, N, 0, 0 ^*/

	/* RAT_Frequency-Priority-Information */
	f1ap_RAT_FrequencyPriorityInformation_t      	frequencyPriorityInformation;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_RAT_FREQUENCY_PRIORITY_INFO_PRESENT, N, 0, 0 ^*/

	/* DRX-Configuration-Indicator */
	UInt32                                  	drx_config_indicator;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CONFIGURATION_INDICATOR_PRESENT, N, 0, 0 ^*/

	/* RLC-Failure-Indication */
	f1ap_adpt_rlc_failure_ind_t	        	rlc_failure_ind;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_RLC_FAILURE_INDICATION_PRESENT, N, 0, 0 ^*/

	/* Uplink-Tx-Direct-Current-List-Information */
	f1ap_UplinkTxDirectCurrentListInformation_t     upLinkTxDirectCurrentListInfo;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_UPLINK_TX_DIRECT_CURRENT_LIST_INFO_PRESENT, N, 0, 0 ^*/

	/* GNB-DU-Configuration-Query */
	UInt32						gNBDuConfigQuery;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_GNU_DU_CONFIGURATION_QUERY_PRESENT, N, 0, 0 ^*/

	/* Bit-Rate */
	UInt64 						bitRate;
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_BIT_RATE_PRESENT, N, 0, 0 ^*/

	/* Execute-Duplication */
	UInt32 						executeDuplication;		
	/*^ O, F1AP_ADPT_UE_CTXT_MOD_REQ_EXECUTE_DUPLICATION_PRESENT, N, 0, 0 ^*/


} f1ap_adpt_ue_context_mod_req_t; /*^ API, F1AP_ADPT_UE_CONTEXT_MOD_REQ ^*/


/* Structure defining the content of Resource coordination
 * transfer container */
typedef struct _f1ap_ResourceCoordinationTransferContainer
{
    /* Length of container */
    unsigned int   containerLength;

    /* Data buffer of container */
    unsigned char  containerData;

} _f1ap_ResourceCoordinationTransferContainer;


/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_MOD_RESP
 ****************************************************************************/

typedef struct _f1ap_adpt_dl_tunnels_to_be_modified_list_element_t 
{

    UInt32 type;
    union{ 
    /* DL GTP Tunnel EndPoint */
    f1ap_adpt_gtp_tunnel_endpoint_t        gtp_tunnelep;

    }u;
} f1ap_adpt_dl_tunnels_to_be_modified_list_element_t;

/* List of DL tunnels */
typedef struct f1ap_adpt_dl_tunnels_to_be_modified_list_t
{
    /* Count of DL tunnels present in the list */
    UInt32                                    count;

    /* Information of each tunnel present in the list */
    f1ap_adpt_dl_tunnels_to_be_modified_list_element_t   dl_tunnel_to_setup[2];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_dl_tunnels_to_be_modified_list_t;

typedef struct  _f1ap_adpt_drbs_modified_list_element_t 
{
    /* DRB ID */
    UInt32                                drb_id;

    UInt32                                lCID; 
    /* List of DL tunnels for this DRB */
    f1ap_adpt_dl_tunnels_to_be_modified_list_t  dl_tunnels_list;

} f1ap_adpt_drbs_modified_list_element_t;



typedef struct _f1ap_adpt_drbs_modified_list_t
{
    /* Count of DRBs present in the list */
    UInt32                            count;

    /* Information of each DRB present in the list */
    f1ap_adpt_drbs_modified_list_element_t     drb_to_modified[MAX_DRB_PER_UE];
/*^ M, 0, OCTET_STRING, VARIABLE ^*/

} f1ap_adpt_drbs_modified_list_t;



/* F1_UE_CTXT_MOD_RESP: DRBs Setup Modified List Structure START */
typedef struct _f1ap_adpt_dl_tunnels_to_be_setup_mod_list_element_t
{
	UInt32                 type;
	union{
	// DL GTP Tunnel EndPoint 
	f1ap_adpt_gtp_tunnel_endpoint_t        gtp_tunnelep;

	}u;
}f1ap_adpt_dl_tunnels_to_be_setup_mod_list_element_t;

typedef struct f1ap_adpt_dl_tunnels_to_be_setup_mod_list_t
{
	/* Count of DL tunnels present in the list */
	UInt32                                    count;
	
	/* Information of each tunnel present in the list */
	f1ap_adpt_dl_tunnels_to_be_setup_mod_list_element_t   dl_tunnel_to_setup_mod[2];	
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_dl_tunnels_to_be_setup_mod_list_t;

typedef struct _f1ap_adpt_drbs_setup_modified_list_element_t
{
	/* DRB ID */
	UInt32                                drb_id;

	/* lCID */
	UInt32                                lCID;

	/* List of DL tunnels for this DRB */
	f1ap_adpt_dl_tunnels_to_be_setup_mod_list_t    dl_tunnels_setup_mod_list;


}f1ap_adpt_drbs_setup_modified_list_element_t;

typedef struct _f1ap_adpt_drbs_setup_modified_list_t
{
	/* Count of DRBs present in the list */
	UInt32                            count;

        /* Information of each DRB present in the list */
  	f1ap_adpt_drbs_setup_modified_list_element_t     drb_to_setup_modified[MAX_DRB_PER_UE];
	/*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_drbs_setup_modified_list_t; 
/* F1_UE_CTXT_MOD_RESP: DRBs Setup Modified List Structure STOP */



/* F1_UE_CTXT_MOD_RESP: SRBs Failed Setup Modified List Structure START */

typedef struct _f1ap_adpt_srbs_failed_to_be_setup_mod_list_element_t
{
	#define F1AP_ADPT_UE_CTX_MOD_RESP_SRB_FAILED_TO_SETUP_MOD_CAUSE_PRESENT   0x01

	UInt8               bitmask;          /*^ BITMASK ^*/
	
	/* SRB ID */
	UInt32        srb_id;

	/* Cause */
	f1ap_adpt_cause_t   cause;

}f1ap_adpt_srbs_failed_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_srbs_failed_to_be_setup_mod_list_t
{
	/* Count of SRBs present in the list */
	UInt32                                    count;

	/* Identifier of the SRB which failed to setup modified  */
	f1ap_adpt_srbs_failed_to_be_setup_mod_list_element_t   srb_failed_to_setup_mod[MAX_SRB_PER_UE];

}f1ap_adpt_srbs_failed_to_be_setup_mod_list_t;

/* F1_UE_CTXT_MOD_RESP: SRBs Failed Setup Modified List Structure STOP */

/* F1_UE_CTXT_MOD_RESP: DRBs Failed Setup Modified List Structure START */

typedef struct _f1ap_adpt_drbs_failed_to_be_setup_mod_list_element_t
{
	#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_TO_SETUP_MOD_CAUSE_PRESENT      0x02
	
	UInt8               bitmask;          /*^ BITMASK ^*/
	
	/* DRB ID */
	UInt32        drb_id;
	
	/* Cause */
	f1ap_adpt_cause_t   cause;

}f1ap_adpt_drbs_failed_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_drbs_failed_to_be_setup_mod_list_t
{
	/* Count of DRBs present in the list */
	UInt32                                    count;

	/* Identifier of the DRB which failed to setup modified  */
	f1ap_adpt_drbs_failed_to_be_setup_mod_list_element_t drb_failed_to_setup_mod[MAX_DRB_PER_UE];

}f1ap_adpt_drbs_failed_to_be_setup_mod_list_t;

/* F1_UE_CTXT_MOD_RESP: DRBs Failed Setup Modified List Structure STOP */



/* F1_UE_CTXT_MOD_RESP: sCell Failed Setup Modified List Structure START */

typedef struct _f1ap_adpt_scell_failed_to_be_setup_mod_list_element_t
{
	#define F1AP_ADPT_UE_CTX_MOD_RESP_SCELL_FAILED_TO_SETUP_MOD_CAUSE_PRESENT         0x10 

	UInt8               bitmask;          /*^ BITMASK ^*/	

	/* SCell-ID */
	f1ap_adpt_ncgi_t     scell_id;

	/* Cause */
	f1ap_adpt_cause_t   cause;

}f1ap_adpt_scell_failed_to_be_setup_mod_list_element_t;

typedef struct _f1ap_adpt_scell_failed_to_be_setup_mod_list_t	
{
	UInt32   count;

	f1ap_adpt_scell_failed_to_be_setup_mod_list_element_t      scell_failed_to_setup_mod[MAX_NO_OF_SCELLS];

}f1ap_adpt_scell_failed_to_be_setup_mod_list_t;

/* F1_UE_CTXT_MOD_RESP: sCell Failed Setup Modified List Structure STOP */

/* F1_UE_CTXT_MOD_RESP: DRBs Failed Modified List Structure START */
typedef struct _f1ap_adpt_drbs_failed_to_be_mod_list_element_t
{
	#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_TO_MOD_CAUSE_PRESENT      0x04

	UInt8               bitmask;          /*^ BITMASK ^*/
	
	/* DRB ID */
	 UInt32        drb_id;

	/* Cause */
	f1ap_adpt_cause_t   cause;
	
}f1ap_adpt_drbs_failed_to_be_mod_list_element_t;

typedef struct _f1ap_adpt_drbs_failed_to_be_mod_list_t
{
	/* Count of DRBs present in the list */ 
	 UInt32                                    count; 

	/* Identifier of the DRB which failed to modified  */
	f1ap_adpt_drbs_failed_to_be_mod_list_element_t   drb_failed_to_mod[MAX_DRB_PER_UE];
}f1ap_adpt_drbs_failed_to_be_mod_list_t;
/* F1_UE_CTXT_MOD_RESP: DRBs Failed Modified List Structure STOP */

/************************************************************************************
 * F1AP_ADPT_UE_CONTEXT_MODIFICATION_RESP
 ***********************************************************************************/
typedef struct {


#define F1AP_ADPT_UE_CTX_MOD_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT         0x001
#define F1AP_ADPT_UE_CTX_MOD_RESP_DU_TO_CU_CONTAINER_PRESENT			  0x002
#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_SETUP_MODIFIED_PRESENT                      0x004
#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_MODIFIED_PRESENT                            0x008
#define F1AP_ADPT_UE_CTX_MOD_RESP_SRB_FAILED_SETUP_MODIFIED_PRESENT               0x010
#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_SETUP_MODIFIED_PRESENT               0x020
#define F1AP_ADPT_UE_CTX_MOD_RESP_SCELL_FAILED_SETUP_MODIFIED_PRESENT             0x040
#define F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_MODIFIED_PRESENT                     0x080
#define F1AP_ADPT_UE_CTX_MOD_RESP_INACTIVE_MONITOR_RESPONSE_PRESENT               0x100
#define F1AP_ADPT_UE_CTX_MOD_RESP_CRITICALITY_DIAGNOSTICS_PRESENT                 0x200
#define F1AP_ADPT_UE_CTX_MOD_RESP_C_RNTI_PRESENT				  0x400

	UInt32                 bitmask;         /*^ BITMASK  ^*/

	/* UE Identifier */
	UInt32                 gNBCUUEF1APID;
	UInt32                 gNBDUUEF1APID;
	UInt32                 ue_index;

	
	/* Resource Coordination Info */
	 f1ap_adpt_sgnb_resrc_coordination_info_t         sgnb_resrc_cord_info;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT, N , 0, 0 ^*/

	/* DU to CU RRC Information Container */
	cell_group_config_t                          du_to_cu_container;
	/*^ O,F1AP_ADPT_UE_CTX_SETUP_RESP_DU_TO_CU_CONTAINER_PRESENT, N , 0, 0 ^*/

	/*^ List of DRBs Setup Modified List ^*/
        f1ap_adpt_drbs_setup_modified_list_t        drbs_setup_modified_list;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_DRB_SETUP_MODIFIED_PRESENT, N , 0, 0 ^*/

	/*^ List of DRBs Modified List ^*/
	f1ap_adpt_drbs_modified_list_t               drbs_modified_list;
        /*^ O, F1AP_ADPT_UE_CTX_MOD_RESP_DRB_MODIFIED_PRESENT, N , 0, 0 ^*/	

	/*^ List of SRBs Failed Setup Modified List ^*/
	f1ap_adpt_srbs_failed_to_be_setup_mod_list_t  srbs_failed_to_setup_mod_list;
	/*^ O, F1AP_ADPT_UE_CTX_MOD_RESP_SRB_FAILED_SETUP__MODIFIED_PRESENT, N , 0, 0 ^*/

	/*^ List of DRBs Failed Setup Modified List ^*/
	f1ap_adpt_drbs_failed_to_be_setup_mod_list_t  drbs_failed_to_setup_mod_list;
	/*^ O, F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_SETUP_MODIFIED_PRESENT, N , 0, 0^*/

	/*^ List of sCell Failed Setup Modified List ^*/
	f1ap_adpt_scell_failed_to_be_setup_mod_list_t scell_failed_to_setup_mod_list;
 	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_SCELL_FAILED_SETUP_MODIFIED_PRESENT, N , 0, 0^*/

	/*^ List of DRBs Failed Modified List ^*/
	f1ap_adpt_drbs_failed_to_be_mod_list_t    drbs_failed_to_mod_list;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_MODIFIED_PRESENT, N , 0, 0^*/

	/*^ List of Inactive Monitoring Response List ^*/
	UInt32                                   inactive_monitor_resp;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_INACTIVE_MONITOR_RESPONSE_PRESENT, N , 0, 0^*/

	/*^ List of Criticality Diagnostics List ^*/
	_f1ap_CriticalityDiagnostics             criticality_diagnostics;
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_CRITICALITY_DIAGNOSTICS_PRESENT, N , 0, 0^*/

	/* c-RNTI */	
	UInt32                                   c_rnti;	
	/*^ O,F1AP_ADPT_UE_CTX_MOD_RESP_CAUSE_PRESENT, N , 0,0 ^*/   
                            
} f1ap_adpt_ue_context_mod_resp_t; /*^ API, F1AP_ADPT_UE_CONTEXT_MOD_RESP ^*/


/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_REL_REQ
 ****************************************************************************/

typedef struct
{
    /* UE Identifier */
    UInt32                  ue_index;
    UInt32                  gNBCUUEF1APID;
    UInt32                  gNBDUUEF1APID;
    /* Cause */
    f1ap_adpt_cause_t       cause;

} f1ap_adpt_ue_context_rel_req_t; /*^ API, F1AP_ADPT_UE_CONTEXT_REL_REQ ^*/


/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_REL_COMMAND
 ****************************************************************************/

typedef struct 
{
#define F1AP_ADPT_UE_CTX_REL_COMMAND_RRC_CONTAINER_PRESENT                    0x01
#define F1AP_ADPT_UE_CTX_REL_COMMAND_SRBID_PRESENT                            0x02
#define F1AP_ADPT_UE_CTX_REL_COMMAND_OLD_gNBDUUEF1APID_PRESENT                0x04
#define F1AP_ADPT_UE_CTX_REL_COMMAND_EXECUTE_DUPLICATION_PRESENT              0x08

        UInt32                  bitmask;            /*^ BITMASK ^*/

	/* UE Identifier */
	UInt32                  ue_index;
	UInt32                  gNBCUUEF1APID;
	UInt32                  gNBDUUEF1APID;
	/* Cause */
	f1ap_adpt_cause_t       cause;

	/*RRC Container*/
	f1ap_adpt_rrc_t         RRC_Container;

	/*SRBID*/
	UInt32                  SRBID;

	/* Old gNB_DU_UE_F1AP_ID*/
	UInt32                  oldgNBDUUEF1APID;

	/*ExecuteDuplication*/
	UInt32                  exe_duplication;


} f1ap_adpt_ue_context_rel_command_t; /*^ API, F1AP_ADPT_UE_CONTEXT_REL_COMMAND ^*/


/* F1_UE_CTXT_MOD_REQUIRED: DRBs Required Modified List Structure START */

typedef struct _f1ap_adpt_dl_tunnels_to_be_required_mod_list_element_t
{
        UInt32                 type;

        union {

                /* DL GTP Tunnel EndPoint */
                f1ap_adpt_gtp_tunnel_endpoint_t             gtp_tunnelep;

        }u;

}f1ap_adpt_dl_tunnels_to_be_required_mod_list_element_t;

typedef struct _f1ap_adpt_dl_tunnels_to_be_required_mod_list_t
{

        /* Count of DL tunnels present in the list */
        UInt32                                   count;

        /* Information of each tunnel present in the list */
        f1ap_adpt_dl_tunnels_to_be_required_mod_list_element_t        dl_tunnel_to_required_mod[2];
        /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_dl_tunnels_to_be_required_mod_list_t;

typedef struct _f1ap_adpt_drbs_required_modified_list_element_t
{

        /* DRB ID */
        UInt32                               drb_id;

        /* List of DL tunnels for this DRB */
        f1ap_adpt_dl_tunnels_to_be_required_mod_list_t          dl_tunnels_required_mod_list;

}f1ap_adpt_drbs_required_modified_list_element_t;

typedef struct _f1ap_adpt_drbs_required_mod_list_t
{
        /* Count of DRBs present in the list */
        UInt32                                count;

        /* Information of each DRB present in the list */
        f1ap_adpt_drbs_required_modified_list_element_t         drb_to_required_modified[MAX_DRB_PER_UE];
        /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}f1ap_adpt_drbs_required_mod_list_t;
/* F1_UE_CTXT_MOD_REQUIRED: DRBs Required Modified List Structure STOP */


/* F1_UE_CTXT_MOD_REQUIRED: SRBs Required Release List Structure START */
typedef struct _f1ap_adpt_srbs_required_release_list_element_t
{

        /* SRB ID */
        UInt32                 srb_id;

}f1ap_adpt_srbs_required_release_list_element_t;

typedef struct _f1ap_adpt_srbs_required_to_be_release_list_t
{
        /* Count of SRBs present in the list */
        UInt32                              count;

        /* Identifier of the SRB which Required to be released */
        f1ap_adpt_srbs_required_release_list_element_t     srb_required_to_release[MAX_SRB_PER_UE];

}f1ap_adpt_srbs_required_to_be_release_list_t;
/* F1_UE_CTXT_MOD_REQUIRED: SRBs Required Release List Structure STOP */

/* F1_UE_CTXT_MOD_REQUIRED: DRBs Required Release List Structure START */
typedef struct _f1ap_adpt_drbs_required_release_list_element_t
{
        /* DRB ID */
        UInt32                         drb_id;

}f1ap_adpt_drbs_required_release_list_element_t;

typedef struct _f1ap_adpt_drbs_required_to_be_release_list_t
{
         /* Count of DRBs present in the list */
         UInt32                             count;

        /* Identifier of the DRB which Required to Release */
        f1ap_adpt_drbs_required_release_list_element_t     drb_required_to_release[MAX_DRB_PER_UE];

}f1ap_adpt_drbs_required_to_be_release_list_t;
/* F1_UE_CTXT_MOD_REQUIRED: DRBs Required Release List Structure STOP */


/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_MODIFICATION_REQUIRED
 ****************************************************************************/

typedef struct {

#define F1AP_ADPT_UE_CTX_MOD_REQUIRED_RESOURCE_COORDINATION_INFO_PRESENT         0x001
#define F1AP_ADPT_UE_CTX_MOD_REQUIRED_DU_TO_CU_CONTAINER_PRESENT                 0x002
#define F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_MODIFIED_PRESENT              0x004
#define F1AP_ADPT_UE_CTX_MOD_REQUIRED_SRB_REQUIRED_RELEASE_PRESENT               0x008
#define F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_RELEASE_PRESENT               0x010


        UInt32                       bitmask;         /*^ BITMASK ^*/

        /* UE Identifier */
        UInt32                      gNBCUUEF1APID;
        UInt32                      gNBDUUEF1APID;
        UInt32                      ue_index;

        /* Response (f1ap_adpt_response_et) */
        f1ap_adpt_response_et       response;

        /* Resource Coordination Info */
         f1ap_ResourceCoordinationTransferContainer_t     resrc_cord_container;
        /*^ O,F1AP_ADPT_UE_CTX_MOD_REQUIRED_RESOURCE_COORDINATION_INFO_PRESENT, N , 0, 0 ^*/

        /* DU to CU RRC Information Container */
        cell_group_config_t                              du_to_cu_container;
        /*^ O,F1AP_ADPT_UE_CTX_MOD_REQUIRED_DU_TO_CU_CONTAINER_PRESENT, N , 0, 0 ^*/

        /*^ List of DRBs Required Modified List ^*/
        f1ap_adpt_drbs_required_mod_list_t               drbs_required_mod_list;
        /*^ O, F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_MODIFIED_PRESENT, N , 0, 0 ^*/

        /*^ List of SRBs Required Release List ^*/
        f1ap_adpt_srbs_required_to_be_release_list_t     srbs_required_to_release_list;
        /*^ O, F1AP_ADPT_UE_CTX_MOD_REQUIRED_SRB_REQUIRED_RELEASE_PRESENT, N , 0, 0 ^*/

        /*^ List of DRBs Required Release List ^*/
        f1ap_adpt_drbs_required_to_be_release_list_t     drbs_required_to_release_list;
        /*^ O, F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_RELEASE_PRESENT, N , 0, 0^*/

	/* Cause */
        f1ap_adpt_cause_t           cause;

}f1ap_adpt_ue_context_mod_required_t;




/*****************************************************************************
 * F1AP_ADPT_UE_CONTEXT_REL_COMPLETE
 ****************************************************************************/

typedef struct 
{

    #define F1AP_ADPT_UE_CTX_REL_COMP_CRITICALITY_DIAGNOSTICS_PRESENT         0x01
 
    UInt32                  bitmask;            /*^ BITMASK ^*/     

    /* UE Identifier */
    UInt32  ue_index;
    UInt32                  gNBCUUEF1APID;
    UInt32                  gNBDUUEF1APID;

    /*^ List of Criticality Diagnostics List ^*/
    _f1ap_CriticalityDiagnostics             criticality_diagnostics;
    /*^ O,F1AP_ADPT_UE_CTX_REL_COMP_CRITICALITY_DIAGNOSTICS_PRESENT, N , 0, 0^*/
 
} f1ap_adpt_ue_context_rel_complete_t; /*^ API, F1AP_ADPT_UE_CONTEXT_REL_COMPLETE ^*/

/*****************************************************************************
 *  * F1AP_ADPT_UE_CONTEXT_MODIFICATION_CONFIRM
 ****************************************************************************/

typedef struct _f1ap_adpt_gtp_teid
{
   UInt32   num_octs;
   UInt8    data[4];
/*^ M, 0, OCTET_STRING, FIXED ^*/
} f1ap_adpt_gtp_teid;

typedef struct _f1ap_adpt_gtp_tunnel_info
{
    UInt8                                      transport_address_length;
    UInt8                                      transport_layer_address[20];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
    f1ap_adpt_gtp_teid                         gtp_teid;

}f1ap_adpt_gtp_tunnel_info;

typedef struct _f1ap_adpt_dl_tunnels_mod_confirm_element_t
{
    UInt32                                        type;

    union {
        /* DL GTP Tunnel */
        f1ap_adpt_gtp_tunnel_info              gtp_tunnel;
    }u;

}f1ap_adpt_dl_tunnels_mod_confirm_element_t;

typedef struct _f1ap_adpt_mod_conf_ULUPTNLInformation_list_t
{
    /* Count of DL tunnels present in the list */
    UInt32                                        count;

    /* Information of each tunnel present in the list */
    f1ap_adpt_dl_tunnels_mod_confirm_element_t    dl_tunnel_mod_conf[2];

}f1ap_adpt_mod_conf_ULUPTNLInformation_list_t;

typedef struct _f1ap_adpt_drbs__mod_conf_list_element_t
{
    /* DRB ID */
    UInt32                                        dRBID;

    /* List of DL tunnels for this DRB */
    f1ap_adpt_mod_conf_ULUPTNLInformation_list_t  uLUPTNLInformation_mod_conf_list;

}f1ap_adpt_drbs__mod_conf_list_element_t;

typedef struct _f1ap_adpt_drb_mod_conf_list_t
{
    /* Count of DRBs present in the list */
    UInt32                                        count;

    /* Information of each DRB present in the list */
    f1ap_adpt_drbs__mod_conf_list_element_t       drb_mod_conf_elem[MAX_DRB_PER_UE];

}f1ap_adpt_drb_mod_conf_list_t;

typedef struct
{

#define F1AP_ADPT_UE_CTX_MOD_CONFIRM_RESOURCE_COORDINATION_INFO_PRESENT       0x01
#define F1AP_ADPT_UE_CTX_MOD_CONFIRM_DRB_MODIFIED_PRESENT                     0x02
#define F1AP_ADPT_UE_CTX_MOD_CONFIRM_RRC_CONTAINER_PRESENT                    0x04
#define F1AP_ADPT_UE_CTX_MOD_CONFIRM_CRITICALITY_DIAGNOSTICS_PRESENT          0x08
#define F1AP_ADPT_UE_CTX_MOD_CONFIRM_EXECUTE_DUPLICATION_PRESENT              0x10

    UInt32                  bitmask;            /*^ BITMASK ^*/
    /* UE Identifier */
    UInt32                                         ue_index;

    /*gNB-CU-UE-F1AP-ID */
    UInt32                                         gNBCUUEF1APID;

    /*gNB-DU-UE-F1AP-ID */
    UInt32                                         gNBDUUEF1APID;

    /*ResourceCoordinationTransferContainer*/
    f1ap_ResourceCoordinationTransferContainer_t   resource_Coord_container;

    /*DRBs-ModifiedConf-Lis */
    f1ap_adpt_drb_mod_conf_list_t                   drbs_mod_conf_list;

    /* RRCContainer */
    f1ap_adpt_rrc_t                                RRCContainer;

    /*CriticalityDiagnostics  */
    _f1ap_CriticalityDiagnostics                   criticality_diagnostics;

    /* ExecuteDuplication */
    UInt32                                         execute_duplication;

} f1ap_adpt_ue_context_mod_confirm_t; /*^ API, F1AP_ADPT_UE_CONTEXT_MOD_CONF ^*/


#endif  // _F1AP_ADPT_INTF_H_
