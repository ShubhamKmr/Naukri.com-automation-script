#ifndef _DUSIM_COMMON_H_
#define _DUSIM_COMMON_H_

#define F1AP_MAX_ASN1_BUF_LEN   8192
#define MAX_NUM_IP_ADDR         3
#define MAX_IPV4_ADDR_LEN       16


#define F1AP_NULL     0
#define F1AP_P_NULL   ((void*)0)
#define F1AP_ONE      1

typedef enum
{
    F1AP_LINK_STATUS_UP,
    F1AP_LINK_STATUS_DOWN,
    F1AP_LINK_STATUS_UNKNOWN
} f1_sctp_link_status_et;


typedef enum
{
    DU_SUCCESS_RESP,
    DU_FAILURE_RESP
} dusim_response_code_et;


/* SCTP association specific parameters */
typedef struct
{
    unsigned int     hbinterval;
    unsigned short   pathmaxrxt;
    unsigned short   init_num_ostreams;
    unsigned short   init_max_instreams;
    unsigned short   init_max_attempts;
    unsigned short   init_max_init_timeo;
    unsigned int     rto_initial;
    unsigned int     rto_max;
    unsigned int     rto_min;
    unsigned short   assoc_max_retrans;
    unsigned int     valid_cookie_life;
    unsigned char    dscp_value;
} dusim_sctp_config_param_t;


/* Structure defining the content of IPv4 address */
typedef struct
{
    unsigned char  ip_addr[MAX_IPV4_ADDR_LEN];
} dusim_ipv4_addr_t;


/* Structure defining the content of DU communication info */
typedef struct
{
#define DU_COMM_INFO_NUM_IPV4_ADDR_PRESENT      0x01
#define DU_COMM_INFO_IPV4_ADDR_PRESENT          0x02
#define DU_COMM_INFO_SCTP_CONFIG_PARAM_PRESENT  0x04
/*DU Changes*/
#define DU_COMM_INFO_UDP_CONFIG_PARAM_PRESENT   0x08
/*DU Changes*/

    /* Bitmask indicating the presence of optional IEs */
    unsigned int               bitmask;

    /* Count of IPv4 address 
     * (Bitmask: DU_COMM_INFO_NUM_IPV4_ADDR_PRESENT) */
    unsigned char              num_ipv4_addr;

    /* List of IPv4 address 
     * (Bitmask: DU_COMM_INFO_IPV4_ADDR_PRESENT) */
    dusim_ipv4_addr_t          ipv4_addr[MAX_NUM_IP_ADDR];

    /* Port number */
    unsigned short             port;

    /* SCTP association specific parameters 
     * (Bitmask: DU_COMM_INFO_SCTP_CONFIG_PARAM_PRESENT) */
    dusim_sctp_config_param_t  config_param;

} dusim_sctp_comm_info_t;


#endif  // _DUSIM_COMMON_H_
