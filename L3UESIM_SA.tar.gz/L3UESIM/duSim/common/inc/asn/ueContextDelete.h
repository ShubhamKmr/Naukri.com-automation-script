

/***********************************************************************
 * UE Context Release Command
 **********************************************************************/

typedef struct _f1ap_UEContextReleaseCommand 
{
    /* gNB-CU-F1AP-ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int  du_f1ap_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_UEContextReleaseCommand;


/**********************************************************************/



/**********************************************************************
 *  UE Context Release Complete
 *********************************************************************/


typedef struct _f1ap_UEContextReleaseComplete 
{
#define UE_CTX_REL_CMD_CRIT_DIAGNOSTICS_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextReleaseComplete;


/*********************************************************************/
