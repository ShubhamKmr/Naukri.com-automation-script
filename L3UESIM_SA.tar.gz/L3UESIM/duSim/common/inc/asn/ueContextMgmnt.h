
#define MAX_SRB_PER_UE                  8
#define MAX_UE_CAPABILITY_BUFFER_LEN    2048
#define MAX_SCG_CONFIG_INFO_BUFFER_LEN  4096


/****************************************************************************
 *  UE Context setup Request
 ***************************************************************************/

/* Structure defining the content of Resource coordination 
 * transfer container */
typedef struct _f1ap_ResourceCoordinationTransferContainer
{
    /* Length of container */
    unsigned int   containerLength;

    /* Data buffer of container */
    unsigned char  containerData;

} _f1ap_ResourceCoordinationTransferContainer;


/* Structure defining the content of CU to DU RRC container */ 
typedef struct _f1ap_CUtoDURRCInformation
{
#define CU_TO_DU_CONTAINER_SCG_CONFIG_INFO_PRESENT   0x01

    unsigned int  bitmask;

    /* UE Radio capability buffer length */
    unsigned int  ueCapabilityBufferLen;

    /* UE Radio capability buffer */
    unsigned char ueCapabilityBuffer[MAX_UE_CAPABILITY_BUFFER_LEN];

    /* SCG Config Info container length */
    unsigned int  scgConfigInfoBufferLen;

    /* SCG Config Info container buffer */
    unsigned char scgConfigInfoBuffer[MAX_SCG_CONFIG_INFO_BUFFER_LEN];

} _f1ap_CUtoDURRCInformation;


/* Structure defining the content of DU to CU container */
typedef struct _f1ap_DUtoCURRCInformation
{
    /* Cell Group Config buffer length */
    unsigned int  cellGroupConfigBufLen;

    /* Cell Group Config buffer */
    unsigned char cellGroupConfigBuf;

} _f1ap_DUtoCURRCInformation;


typedef struct _f1ap_DRXCycle 
{
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_LEN_PRESENT    0x01
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_TIMER_PRESENT  0x02

    unsigned int   bitmask;

    unsigned int   longDRXCycleLength;
    unsigned int   shortDRXCycleLength;
    unsigned char  shortDRXCycleTimer;

} _f1ap_DRXCycle;


typedef struct _f1ap_SCell_ToBeSetup_List_element 
{
    /* SCell-ID */
    _f1ap_NCGI     cgi;

} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int   count;
    _f1ap_SCell_ToBeSetup_List_element  
                   scell_toBe_setup[MAX_CELL_PER_DU];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element 
{
    /* SRBID */
    unsigned int     srb_id;

} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int     count;

    _f1ap_SRBs_ToBeSetup_List_element  
                     srb_toBe_setup[MAX_SRB_PER_UE];

} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_GTP_TEID 
{
   unsigned int   numocts;
   unsigned char  data[4];
} _f1ap_GTP_TEID;


typedef struct _f1ap_GTPTunnelEndpoint 
{
   unsigned char    transportAddressLength;
   unsigned char    transportLayerAddress[20];
   _f1ap_GTP_TEID   gTP_TEID;
} _f1ap_GTPTunnelEndpoint;


typedef struct _f1ap_ULTunnels_ToBeSetup_list_element 
{
    /* UL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint  tunnelEP;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    unsigned int    count;

    _f1ap_ULTunnels_ToBeSetup_list_element  
                    ul_tunnel_toBe_setup[2];

} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_AllocationAndRetentionPriority 
{
   unsigned char priorityLevel;
   unsigned int  pre_emptionCapability;
   unsigned int  pre_emptionVulnerability;
} _f1ap_AllocationAndRetentionPriority;


typedef struct _f1ap_GBR_QosInformation 
{
   unsigned long e_RAB_MaximumBitrateDL;
   unsigned long e_RAB_MaximumBitrateUL;
   unsigned long e_RAB_GuaranteedBitrateDL;
   unsigned long e_RAB_GuaranteedBitrateUL;
} _f1ap_GBR_QosInformation;


typedef struct _f1ap_EUTRANQoS 
{
#define GBR_QOS_INFO_PRESENT   0x01

   unsigned int                          bitmask;

   unsigned char                         qCI;
   _f1ap_AllocationAndRetentionPriority  allocationAndRetentionPriority;
   _f1ap_GBR_QosInformation              gbrQosInformation;
} _f1ap_EUTRANQoS;


typedef struct _f1ap_DRBs_ToBeSetup_List_element 
{
    /* DRBID */
    unsigned int                    drbId;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelList;

} _f1ap_DRBs_ToBeSetup_List_element;


typedef struct _f1ap_DRBs_ToBeSetup_List
{
    unsigned int                       count;
    _f1ap_DRBs_ToBeSetup_List_element  drb_to_setup_elem[32];

} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_UEContextSetupRequest 
{
#define UE_CTX_SETUP_REQ_DU_F1AP_ID_PRESENT                             0x01
#define UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                              0x02
#define UE_CTX_SETUP_REQ_DRX_CYCLE_PRESENT                              0x04
#define UE_CTX_SETUP_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT    0x08

    unsigned int                bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                du_f1ap_id;

    /* PSCell-ID */
    _f1ap_NCGI                  pscell_id;

    /* CUtoDURRCInformation */
    _f1ap_CUtoDURRCInformation  cuToDuContainer;

    /* DRXCycle */
    _f1ap_DRXCycle              drx_cycle;

    /* ResourceCoordinationTransferContainer */
    _f1ap_ResourceCoordinationTransferContainer
                                resCoordinationTransferContainer;

    /* SCell-ToBeSetup-List */
    _f1ap_SCell_ToBeSetup_List  scellsToBeSetupList;

    /* SRBs-ToBeSetup-List */
    _f1ap_SRBs_ToBeSetup_List   srbsToBeSetupList;

    /* DRBs-ToBeSetup-List */
    _f1ap_DRBs_ToBeSetup_List   drbsToBeSetupList;

} _f1ap_UEContextSetupRequest;



/****************************************************************************
 *   UE Context Setup Response 
 ***************************************************************************/

typedef struct _f1ap_SRBs_Setup_List_element 
{
    /* SRBID */
    unsigned int  srb_id;

} _f1ap_SRBs_Setup_List_element;


/* List of f1ap_SRBs_Setup_List_element */
typedef struct  _f1ap_SRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_SRBs_Setup_List_element  srbToSetup[1];
} _f1ap_SRBs_Setup_List;


typedef struct _f1ap_DLTunnels_ToBeSetup_list_element 
{
    /* DL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint   gtpTunnelEP;

} _f1ap_DLTunnels_ToBeSetup_list_element;


typedef struct _f1ap_DLTunnels_ToBeSetup_list
{
    unsigned int                            count;
    _f1ap_DLTunnels_ToBeSetup_list_element  dlTunnelToSetup;
}_f1ap_DLTunnels_ToBeSetup_list;


typedef struct  _f1ap_DRBs_Setup_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* DLTunnels-ToBeSetup-list */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsList[2];

} _f1ap_DRBs_Setup_List_element;


/* List of f1ap_DRBs_Setup_List_element */
typedef struct _f1ap_DRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_DRBs_Setup_List_element  drbToSetup[32];
}_f1ap_DRBs_Setup_List;


typedef struct _f1ap_SRBs_FailedToBeSetup_List_element 
{
    /* SRBID */
    unsigned int  srb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_SRBs_FailedToBeSetup_List_element;


typedef struct  _f1ap_SRBs_FailedToBeSetup_List
{
    unsigned int                             count;
    _f1ap_SRBs_FailedToBeSetup_List_element  srbsFailedToSetup[32];
} _f1ap_SRBs_FailedToBeSetup_List;


typedef struct _f1ap_DRBs_FailedToBeSetup_List_element 
{
    /* DRBID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeSetup_List_element;


/* List of f1ap_DRBs_FailedToBeSetup_List_element */
typedef struct _f1ap_DRBs_FailedToBeSetup_List
{
    unsigned int                             count;
    _f1ap_DRBs_FailedToBeSetup_List_element  drbFailedToSetup[32];
} _f1ap_DRBs_FailedToBeSetup_List;


typedef struct _f1ap_UEContextSetupResponse 
{
#define UE_CTX_SETUP_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT   0x01
#define UE_CTX_SETUP_RESP_CRIT_DIAGNOSTICS_PRESENT                      0x02

    unsigned int                     bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                     cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                     du_f1ap_id;

    /* DUtoCURRCInformation */
    _f1ap_DUtoCURRCInformation       duToCuContainer;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                     resCoordinationContainer;

    /* SRBs-Setup-List */
    _f1ap_SRBs_Setup_List            srbsSetupList;

    /* DRBs-Setup-List */
    _f1ap_DRBs_Setup_List            drbsSetupList;

    /* SRBs-FailedToBeSetup-List */
    _f1ap_SRBs_FailedToBeSetup_List  srbsFailedToSetupList;

    /* DRBs-FailedToBeSetup-List */
    _f1ap_DRBs_FailedToBeSetup_List  drbsFailedToSetupList;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics     criticalityDiagnostics;

} _f1ap_UEContextSetupResponse;


/*******************************************************************************
 * UE Context Setup Failure
 ******************************************************************************/

/* NR Cell Identitiy */
typedef struct _f1ap_NRCellIdentity {
   unsigned int   numbits;
   unsigned char  data[5];
} _f1ap_NRCellIdentity;


/* PLMN Identity */
typedef struct _f1ap_PLMN_

Identity {
   unsigned int   numocts;
   unsigned char  data[3];
} _f1ap_PLMN_Identity;


/* CGI for Served cell */
typedef struct _f1ap_NCGI 
{
    _f1ap_PLMN_Identity   pLMN_Identity;
    _f1ap_NRCellIdentity  nRCellIdentity;
} _f1ap_NCGI;




typedef struct _f1ap_Potential_SpCell_List_element
{

   _f1ap_NCGI  potential_SpCell_ID;

} _f1ap_Potential_SpCell_List_element;



typedef struct _f1ap_Potential_SpCell_List
{
    unsigned int                            count;

   _f1ap_Potential_SpCell_List_element  element[2];

} _f1ap_Potential_SpCell_List;



typedef struct _f1ap_UEContextSetupFailure 
{
#define UE_CTX_SETUP_FAILURE_DU_F1AP_ID_PRESENT          0x01
#define UE_CTX_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT    0x02

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

    _f1ap_Potential_SpCell_List  Potential_SpCell_List    


} _f1ap_UEContextSetupFailure;


/**************************************************************************
 * UE Context Modification Request 
 *************************************************************************/

typedef struct _f1ap_ULTunnels_ToBeSetup_list_element 
{
    /* UL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint          tunnelEP;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    /* Tunnels count */
    unsigned int                            count;

    /* Tunnels list */
    _f1ap_ULTunnels_ToBeSetup_list_element  ulTunnelsToSetupList[2];

} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_DRBs_ToBeModified_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelsList;

} _f1ap_DRBs_ToBeModified_List_element;


typedef struct _f1ap_DRBs_ToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_ToBeModified_List_element
                  drbToBeModifiedList[32];
}_f1ap_DRBs_ToBeModified_List;


typedef struct _f1ap_DRBs_ToBeSetup_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelsToBeSetupList;

} _f1ap_DRBs_ToBeSetup_List_element;


typedef struct _f1ap_DRBs_ToBeSetup_List
{
    unsigned int                        count;
    _f1ap_DRBs_ToBeSetup_List_element   drbToBeSetup[32];
} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element 
{
    /* SRBID */
    unsigned int  srb_id;
} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int                       count;
    _f1ap_SRBs_ToBeSetup_List_element  srbToBeSetup[1];
} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeReleased_List_element 
{
    /* SRBID  */
    unsigned int   srb_id;

} _f1ap_SRBs_ToBeReleased_List_element;


typedef struct _f1ap_SRBs_ToBeReleased_List
{
    unsigned int                            count;
    _f1ap_SRBs_ToBeReleased_List_element    srbToRelease[1];
}_f1ap_SRBs_ToBeReleased_List;


typedef struct _f1ap_DRBs_ToBeReleased_List_element 
{
    /* DRBID */
    unsigned int   drb_id;

} _f1ap_DRBs_ToBeReleased_List_element;

typedef struct _f1ap_DRBs_ToBeReleased_List
{
    unsigned int                          count;
    _f1ap_DRBs_ToBeReleased_List_element  drbToBeReleased[32];
} _f1ap_DRBs_ToBeReleased_List;


typedef struct _f1ap_SCell_ToBeSetup_List_element 
{
    /* SCell-ID */
    _f1ap_NCGI       scell_id;

} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int                        count;
    _f1ap_SCell_ToBeSetup_List_element  scellToBeSetup[32];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_UEContextModificationRequest 
{
#define UE_CTX_MOD_REQ_PSCELL_ID_PRESENT                            0x01
#define UE_CTX_MOD_REQ_DRX_CONFIG_PRESENT                           0x02
#define UE_CTX_MOD_REQ_CU_TO_DU_CONTAINER_PRESENT                   0x04
#define UE_CTX_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT          0x08
#define UE_CTX_MOD_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x10
#define UE_CTX_MOD_REQ_RRC_CONTAINER_PRESENT                        0x20

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* PSCell-ID */
    _f1ap_NCGI                    pscell_ncgi;

    /* DRXCycle */
    _f1ap_DRXCycle                drx_cycle;

    /* CUtoDURRCInformation */
    _f1ap_CUtoDURRCInformation    cuToDuContainer;

    /* TransmissionStopIndicator */
    unsigned int                  transmissionStopIndicator;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                  resCoordinationTransferContainer;

    /* RRCContainer */
    _OSDynOctStr                  rrcContainer;

    /* SCell-ToBeSetup-List */
    _f1ap_SCell_ToBeSetup_List    scellToBeSetupList;

    /* SRBs-ToBeSetup-List */
    _f1ap_SRBs_ToBeSetup_List     srbsToBeSetupList;

    /* SRBs-ToBeReleased-List */
    _f1ap_SRBs_ToBeReleased_List  srbsToBeReleasedList;

    /* DRBs-ToBeSetup-List */
    _f1ap_DRBs_ToBeSetup_List     drbsToBeSetupList;

    /* DRBs-ToBeModified-List */
    _f1ap_DRBs_ToBeModified_List  drbsToBeModifiedList;

    /* DRBs-ToBeReleased-List */
    _f1ap_DRBs_ToBeReleased_List  drbsToBeReleasedList;

} _f1ap_UEContextModificationRequest;


/**************************************************************************
 * UE Context Modification Response
 *************************************************************************/

typedef struct _f1ap_DRBs_Modified_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* DLTunnels-ToBeSetup-list */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsToBeSetupList;

} _f1ap_DRBs_Modified_List_element;


/* List of f1ap_DRBs_Modified_List_element */
typedef struct _f1ap_DRBs_Modified_List
{
    unsigned int                      count;
    _f1ap_DRBs_Modified_List_element  drbModified[32];
} _f1ap_DRBs_Modified_List;


typedef struct _f1ap_DRBs_FailedToBeModified_List_element 
{
    /* DRBID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeModified_List_element;


/* List of f1ap_DRBs_FailedToBeModified_List_element */
typedef struct _f1ap_DRBs_FailedToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_FailedToBeModified_List_element  
                  drbFailedToBeModifiedList[32];
} _f1ap_DRBs_FailedToBeModified_List;


typedef struct _f1ap_UEContextModificationResponse 
{
#define UE_CTX_MOD_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x01 
#define UE_CTX_MOD_RESP_DU_TO_CU_CONTAINER_PRESENT                   0x02
#define UE_CTX_MOD_RESP_CRIT_DIAG_PRESENT                            0x04

    unsigned int                       bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                       cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                       du_f1ap_id;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                       resCoordinationTransferContainer;

    /* DUtoCURRCInformation */
    _f1ap_DUtoCURRCInformation         duToCuContainer;

    /* DRBs-Setup-List */
    _f1ap_DRBs_Setup_List              drbSetupList;

    /* DRBs-Modified-List */
    _f1ap_DRBs_Modified_List           drbModifiedList;

    /* SRBs-FailedToBeSetup-List */
    _f1ap_SRBs_FailedToBeSetup_List    srbsFailedToSetupList;

    /* DRBs-FailedToBeSetup-List */
    _f1ap_DRBs_FailedToBeSetup_List    drbsFailedToSetupList;

    /* DRBs-FailedToBeModified-List */
    _f1ap_DRBs_FailedToBeModified_List drbsFailedToModifiedList;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics       criticality_diagnostics;

} _f1ap_UEContextModificationResponse;


/**************************************************************************
 * UE Context Modification Failure 
 *************************************************************************/

typedef struct _f1ap_UEContextModificationFailure 
{
#define UE_CTX_MOD_FAILURE_CRIT_DIAG_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextModificationFailure;



/***********************************************************************
 * UE Context Release Command
 **********************************************************************/

typedef struct _f1ap_UEContextReleaseCommand 
{
    /* gNB-CU-F1AP-ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int  du_f1ap_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_UEContextReleaseCommand;


/**********************************************************************
 *  UE Context Release Complete
 *********************************************************************/

typedef struct _f1ap_UEContextReleaseComplete 
{
#define F1AP_UE_CTX_REL_CMD_CRIT_DIAGNOSTICS_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextReleaseComplete;


/***********************************************************************
 * UE Context Release Request 
 **********************************************************************/

typedef struct _f1ap_UEContextReleaseRequest
{
    /* gNB-CU-F1AP-ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int  du_f1ap_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_UEContextReleaseRequest;


/*********************************************************************/



