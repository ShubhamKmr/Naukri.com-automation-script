#define MAX_SRB_PER_UE  8

/****************************************************************************
 *  UE Context setup Request
 ***************************************************************************/

typedef struct _f1ap_DRXCycle 
{
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_LEN_PRESENT    0x01
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_TIMER_PRESENT  0x02

    unsigned int   bitmask;

    unsigned int   longDRXCycleLength;
    unsigned int   shortDRXCycleLength;
    unsigned char  shortDRXCycleTimer;

} _f1ap_DRXCycle;


typedef struct _f1ap_SCell_ToBeSetup_List_element 
{
    /* SCell-ID */
    _f1ap_NCGI     cgi;

} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int   count;
    _f1ap_SCell_ToBeSetup_List_element  
                   scell_toBe_setup[MAX_CELL_PER_DU];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element 
{
    /* SRBID */
    unsigned int     srb_id;

} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int     count;

    _f1ap_SRBs_ToBeSetup_List_element  
                     srb_toBe_setup[MAX_SRB_PER_UE];

} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_GTP_TEID 
{
   unsigned int   numocts;
   unsigned char  data[4];
} _f1ap_GTP_TEID;


typedef struct _f1ap_GTPTunnelEndpoint 
{
   unsigned char    transportAddressLength;
   unsigned char    transportLayerAddress[20];
   _f1ap_GTP_TEID   gTP_TEID;
} _f1ap_GTPTunnelEndpoint;


typedef struct _f1ap_ULTunnels_ToBeSetup_list_element 
{
    /* UL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint  tunnelEP;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    unsigned int    count;

    _f1ap_ULTunnels_ToBeSetup_list_element  
                    ul_tunnel_toBe_setup[2];

} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_AllocationAndRetentionPriority 
{
   unsigned char priorityLevel;
   unsigned int  pre_emptionCapability;
   unsigned int  pre_emptionVulnerability;
} _f1ap_AllocationAndRetentionPriority;


typedef struct _f1ap_GBR_QosInformation 
{
   unsigned long e_RAB_MaximumBitrateDL;
   unsigned long e_RAB_MaximumBitrateUL;
   unsigned long e_RAB_GuaranteedBitrateDL;
   unsigned long e_RAB_GuaranteedBitrateUL;
} _f1ap_GBR_QosInformation;


typedef struct _f1ap_EUTRANQoS 
{
#define GBR_QOS_INFO_PRESENT   0x01

   unsigned int                          bitmask;

   unsigned char                         qCI;
   _f1ap_AllocationAndRetentionPriority  allocationAndRetentionPriority;
   _f1ap_GBR_QosInformation              gbrQosInformation;
} _f1ap_EUTRANQoS;


typedef struct _f1ap_DRBs_ToBeSetup_List_element 
{
    /* DRBID */
    unsigned int                    drbId;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelList;

} _f1ap_DRBs_ToBeSetup_List_element;


typedef struct _f1ap_DRBs_ToBeSetup_List
{
    unsigned int                       count;
    _f1ap_DRBs_ToBeSetup_List_element  drb_to_setup_elem[8];

} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_UEContextSetupRequest 
{
#define UE_CTX_SETUP_REQ_DU_F1AP_ID_PRESENT                             0x01
#define UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                              0x02
#define UE_CTX_SETUP_REQ_DRX_CYCLE_PRESENT                              0x04
#define UE_CTX_SETUP_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT    0x08

    unsigned int                bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                du_f1ap_id;

    /* PSCell-ID */
    _f1ap_NCGI                  pscell_id;

    /* CUtoDURRCInformation */
    _f1ap_CUtoDURRCInformation  cuToDuContainer;

    /* DRXCycle */
    _f1ap_DRXCycle              drx_cycle;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                resCoordinationTransferContainer;

    /* SCell-ToBeSetup-List */
    _f1ap_SCell_ToBeSetup_List  scellsToBeSetupList;

    /* SRBs-ToBeSetup-List */
    _f1ap_SRBs_ToBeSetup_List   srbsToBeSetupList;

    /* DRBs-ToBeSetup-List */
    _f1ap_DRBs_ToBeSetup_List   drbsToBeSetupList;

} _f1ap_UEContextSetupRequest;



/***************************************************************************/


/****************************************************************************
 *   UE Context Setup Response 
 ***************************************************************************/


typedef struct _f1ap_SRBs_Setup_List_element 
{
    /* SRBID */
    unsigned int  srbId;

} _f1ap_SRBs_Setup_List_element;


/* List of f1ap_SRBs_Setup_List_element */
typedef struct  _f1ap_SRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_SRBs_Setup_List_element  srbToSetup[1];
} _f1ap_SRBs_Setup_List;


typedef struct _f1ap_DLTunnels_ToBeSetup_list_element 
{
    /* DL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint   gtpTunnelEP;

} _f1ap_DLTunnels_ToBeSetup_list_element;


typedef struct _f1ap_DLTunnels_ToBeSetup_list
{
    unsigned int                            count;
    _f1ap_DLTunnels_ToBeSetup_list_element  dlTunnelToSetup;
}_f1ap_DLTunnels_ToBeSetup_list;


typedef struct  _f1ap_DRBs_Setup_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* DLTunnels-ToBeSetup-list */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsList[2];

} _f1ap_DRBs_Setup_List_element;


/* List of f1ap_DRBs_Setup_List_element */
typedef struct _f1ap_DRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_DRBs_Setup_List_element  drbToSetup[32];
}_f1ap_DRBs_Setup_List;


typedef struct _f1ap_SRBs_FailedToBeSetup_List_element 
{
    /* SRBID */
    unsigned int  srb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_SRBs_FailedToBeSetup_List_element;


typedef struct  _f1ap_SRBs_FailedToBeSetup_List
{
    unsigned int                             count;
    _f1ap_SRBs_FailedToBeSetup_List_element  srbsFailedToSetup[32];
} _f1ap_SRBs_FailedToBeSetup_List;


typedef struct _f1ap_DRBs_FailedToBeSetup_List_element 
{
    /* DRBID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeSetup_List_element;


/* List of f1ap_DRBs_FailedToBeSetup_List_element */
typedef struct _f1ap_DRBs_FailedToBeSetup_List
{
    unsigned int                             count;
    _f1ap_DRBs_FailedToBeSetup_List_element  drbFailedToSetup[32];
} _f1ap_DRBs_FailedToBeSetup_List;


typedef struct _f1ap_UEContextSetupResponse 
{
#define UE_CTX_SETUP_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT   0x01
#define UE_CTX_SETUP_RESP_CRIT_DIAGNOSTICS_PRESENT                      0x02

    unsigned int                     bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                     cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                     du_f1ap_id;

    /* DUtoCURRCInformation */
    _f1ap_DUtoCURRCInformation       duToCuContainer;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                     resCoordinationContainer;

    /* SRBs-Setup-List */
    _f1ap_SRBs_Setup_List            srbsSetupList;

    /* DRBs-Setup-List */
    _f1ap_DRBs_Setup_List            drbsSetupList;

    /* SRBs-FailedToBeSetup-List */
    _f1ap_SRBs_FailedToBeSetup_List  srbsFailedToSetupList;

    /* DRBs-FailedToBeSetup-List */
    _f1ap_DRBs_FailedToBeSetup_List  drbsFailedToSetupList;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics     criticalityDiagnostics;

} _f1ap_UEContextSetupResponse;


/******************************************************************************/



/*******************************************************************************
 * UE Context Setup Failure
 ******************************************************************************/


typedef struct _f1ap_UEContextSetupFailure 
{
#define UE_CTX_SETUP_FAILURE_DU_F1AP_ID_PRESENT          0x01
#define UE_CTX_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT    0x02

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextSetupFailure;


/*****************************************************************************/
