
#define MAX_CELL_PER_DU              8
#define MAX_MIB_LEN                  50
#define MAX_SIB1_LEN                 100
#define MAX_IE_IN_CRIT_DIAG_IE_LIST  8
#define MAX_DU_NAME_LENGTH           150


typedef struct _f1ap_Cells_to_be_Activated_List_element 
{
    /* NCGI */
    _f1ap_NCGI      cgi;

    /* PCI */
    unsigned short  pci;

} _f1ap_Cells_to_be_Activated_List_element;


typedef struct _f1ap_Cells_to_be_Activated_List
{
    unsigned int    count;
    _f1ap_Cells_to_be_Activated_List_element  
                    cell_to_activate[MAX_CELL_PER_DU];
} _f1ap_Cells_to_be_Activated_List;


typedef struct _f1ap_CriticalityDiagnostics_IE_Item 
{
    /* IE Criticality */
    unsigned int    iECriticality;

    /* IE ID */
    unsigned short  iE_ID;

    /* Type of Error */
    unsigned int    typeOfError;

} _f1ap_CriticalityDiagnostics_IE_Item;


/* Criticality Diagnostics IE List */
typedef struct _f1ap_CriticalityDiagnostics_IE_List
{
    /* IE count */
    unsigned int    ie_count;

    /* IE info */
    _f1ap_CriticalityDiagnostics_IE_Item
                    ie_info[MAX_IE_IN_CRIT_DIAG_IE_LIST];

} _f1ap_CriticalityDiagnostics_IE_List;


/* Criticality Diagnostics IE content */
typedef struct _f1ap_CriticalityDiagnostics
{
#define CRIT_DIAG_PROC_CODE_PRESENT        0x01
#define CRIT_DIAG_TRIGGERING_MSG_PRESENT   0x02
#define CRIT_DIAG_PROC_CRIT_PRESENT        0x04
#define CRIT_DIAG_IE_LIST_PRESENT          0x08

    unsigned int   bitmask;

    /* Procedure code */
    unsigned char  procedureCode;

    /* Triggering message */
    unsigned int   triggeringMessage;

    /* Procedure criticality */
    unsigned int   procedureCriticality;

    /* IEs list */
    _f1ap_CriticalityDiagnostics_IE_List 
                   iEsList;

} _f1ap_CriticalityDiagnostics;


/* Cause */
typedef struct _f1ap_Cause 
{
#define F1_CAUSE_RADIO_NETWORK    0
#define F1_CAUSE_TRANSPORT        1 
#define F1_CAUSE_PROTOCOL         2
#define F1_CAUSE_MISC             3

   /* Cause type */
   unsigned int     cause_type;

   union 
   {
      /* t = 0 */
      unsigned int  radioNetwork;

      /* t = 1 */
      unsigned int  transport;

      /* t = 2 */
      unsigned int  protocol;

      /* t = 3 */
      unsigned int  misc;
   } u;

} _f1ap_Cause;


/* NR Cell Identitiy */
typedef struct _f1ap_NRCellIdentity {
   unsigned int   numbits;
   unsigned char  data[5];
} _f1ap_NRCellIdentity;


/* PLMN Identity */
typedef struct _f1ap_PLMN_Identity {
   unsigned int   numocts;
   unsigned char  data[3];
} _f1ap_PLMN_Identity;


/* CGI for Served cell */
typedef struct _f1ap_NCGI 
{
    _f1ap_PLMN_Identity   pLMN_Identity;
    _f1ap_NRCellIdentity  nRCellIdentity;
} _f1ap_NCGI;


/* List of PLMNs supported by cell */
typedef struct _f1ap_BroadcastPLMNs_Item {
   unsigned char         n;
   _f1ap_PLMN_Identity   elem[6];
} _f1ap_BroadcastPLMNs_Item;


/* FDD Configuration */
typedef struct _f1ap_FDD_Info 
{
   unsigned short  uL_NARFCN;
   unsigned short  dL_NARFCN;
   unsigned short  uL_Transmission_Bandwidth;
   unsigned short  dL_Transmission_Bandwidth;
} _f1ap_FDD_Info;


/* TDD Configuration */
typedef struct _f1ap_TDD_Info 
{
   unsigned short  nARFCN;
   unsigned short  transmission_Bandwidth;
} _f1ap_TDD_Info;


/* NR Mode information */
typedef struct _f1ap_NR_Mode_Info 
{
#define NR_MODE_FDD      0
#define NR_MODE_TDD      1 

   /* NR Mode Type */
   unsigned int       nr_mode;

   union 
   {
      /* FDD Configuration */
      _f1ap_FDD_Info  fDD;

      /* TDD Configuration */
      _f1ap_TDD_Info  tDD;

   } u;

} _f1ap_NR_Mode_Info;


/* Served Cell Information */
typedef struct _f1ap_Served_Cell_Information 
{
    /* CGI of the served cell */
    _f1ap_NCGI                 nCGI;

    /* PCI of the served cell */
    unsigned short             pCI;

    /* PLMNs of the served cell */
    _f1ap_BroadcastPLMNs_Item  broadcastPLMNs;

    /* NR mode(FDD/TDD) configuration */
    _f1ap_NR_Mode_Info         nR_Mode_Info;

} _f1ap_Served_Cell_Information;


typedef struct _f1ap_GNB_DU_System_Information 
{
   /* Length of MIB buffer */
   unsigned int   mib_length;

   /* MIB byte stream */
   unsigned char  mIB_message[MAX_MIB_LEN];

   /* Length of SIB1 buffer */
   unsigned int   sib1_length;

   /* SIB1 byte stream */
   unsigned char  sIB1_message[MAX_SIB1_LEN];

} _f1ap_GNB_DU_System_Information;


/*********************************************************************
 * F1 SETUP REQUEST
 ********************************************************************/

/* Configuration of served cells */
typedef struct _f1ap_GNB_DU_Served_Cells_List_element 
{
     /* Served-Cell-Information */
     _f1ap_Served_Cell_Information    served_cell_info;

     /* System-Information */
     _f1ap_GNB_DU_System_Information  system_info;

} _f1ap_GNB_DU_Served_Cells_List_element;


/* Served cells list */
typedef struct  _f1ap_GNB_DU_Served_Cells_List
{
    /* Count of served cells */
    unsigned int   count;

    /* Configuration of served cells */
    _f1ap_GNB_DU_Served_Cells_List_element  
                   served_cell[MAX_CELL_PER_DU];

} _f1ap_GNB_DU_Served_Cells_List;


typedef struct _f1ap_F1SetupRequest 
{
#define F1_SETUP_REQ_DU_NAME_PRESENT     0x01

    unsigned int                    bitmask;

    /* TransactionID */
    unsigned int                    transaction_id;

    /* gNB-DU-ID */
    unsigned long                   du_id;

    /* gNB-Name */
    unsigned char                   du_name[MAX_DU_NAME_LENGTH];

    /* gNB-DU-Served-Cells-List */
    _f1ap_GNB_DU_Served_Cells_List  served_cells_list;

} _f1ap_F1SetupRequest;


/***************************************************************************/


/****************************************************************************
 * F1 Setup Response
 ***************************************************************************/

typedef struct _f1ap_F1SetupResponse
{
    /* TransactionID */
    unsigned int                      transaction_id;
   
    /* List of cells to be activated */
    _f1ap_Cells_to_be_Activated_List  cellsToBeActivated;

} _f1ap_F1SetupResponse;


/***************************************************************************/


/****************************************************************************
 * F1 Setup Failure 
 ***************************************************************************/

typedef enum 
{
   f1ap_v1s  = 0,
   f1ap_v2s  = 1,
   f1ap_v5s  = 2,
   f1ap_v10s = 3,
   f1ap_v20s = 4,
   f1ap_v60s = 5
} f1ap_TimeToWait_Root_et;


typedef struct _f1ap_F1SetupFailure 
{
#define F1_SETUP_FAILURE_TIME_TO_WAIT_PRESENT       0x01
#define F1_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT   0x02

    unsigned int                  bitmask;

    /* TransactionID */
    unsigned int                  transaction_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* TimeToWait (f1ap_TimeToWait_Root_et) */
    unsigned int                  timeToWait;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_F1SetupFailure;


/****************************************************************************/

/********************************************************************
 *  CU Configuration Update
 *******************************************************************/

typedef struct _f1ap_Cells_to_be_Deactivated_List_element 
{
    /* NCGI */
    _f1ap_NCGI      cgi;

} _f1ap_Cells_to_be_Deactivated_List_element;


typedef struct _f1ap_Cells_to_be_Deactivated_List
{
    unsigned int    count;

    _f1ap_Cells_to_be_Deactivated_List_element  
                    cell_to_deactivate[MAX_CELL_PER_DU];

} _f1ap_Cells_to_be_Deactivated_List;


typedef struct _f1ap_GNBCUConfigurationUpdate 
{
    /* Cells-to-be-Activated-List */
    _f1ap_Cells_to_be_Activated_List    
                    cellsToBeActivatedList;
    
    /* Cells-to-be-Deactivated-List */
    _f1ap_Cells_to_be_Deactivated_List  
                    cellsToBeDeactivatedList;

} _f1ap_GNBCUConfigurationUpdate;

/*********************************************************************/



/**********************************************************************
 * CU Configuration Update Acknowledge
 *********************************************************************/

typedef struct _f1ap_Cells_Failed_to_be_Activated_List_element 
{
    /* NCGI */
    _f1ap_NCGI   cgi;

    /* Cause */
    _f1ap_Cause  cause;

} _f1ap_Cells_Failed_to_be_Activated_List_element;


/* List of cells which failed to be activated */
typedef struct  _f1ap_Cells_Failed_to_be_Activated_List
{
    unsigned int   count;

    _f1ap_Cells_Failed_to_be_Activated_List_element
                   cellFailedToBeActivated[MAX_CELL_PER_DU];
} _f1ap_Cells_Failed_to_be_Activated_List;


typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge 
{
#define F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT     0x01

    unsigned int       bitmask;

    /* Cells-Failed-to-be-Activated-List */
    _f1ap_Cells_Failed_to_be_Activated_List   
                       cellsFailedToBeActivatedList;
    
    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics              
                       criticality_diagnostics;

} _f1ap_GNBCUConfigurationUpdateAcknowledge;


/**********************************************************************
 *  CU Configuration Update Failure
 *********************************************************************/

typedef struct _f1ap_GNBCUConfigurationUpdateFailure 
{
#define F1AP_CU_CFG_UPDATE_TIME_TO_WAIT_PRESENT         0x01
#define F1AP_CU_CFG_UPDATE_CRIT_DIAGNOSTICS_PRESENT     0x02

    unsigned int                   bitmask;

    /* Cause */
    _f1ap_Cause                    cause;

    /* TimeToWait (f1ap_TimeToWait_Root_et) */
    unsigned int                   timeToWait;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics   criticalityDiagnostics;

} _f1ap_GNBCUConfigurationUpdateFailure;


/**********************************************************************
 *  gNB DU CONFIG UPDATE
 *********************************************************************/

typedef struct _f1ap_Served_Cells_To_Add_List_element 
{
    /* Served-Cell-Information */
    _f1ap_Served_Cell_Information    served_cell_info;

    /* gNB-DU-System-Information */
    _f1ap_GNB_DU_System_Information  system_info;

} _f1ap_Served_Cells_To_Add_List_element;


typedef struct  _f1ap_Served_Cells_To_Add_List
{
    unsigned int  count;

    _f1ap_Served_Cells_To_Add_List_element  
                  cell_to_add[MAX_CELL_PER_DU];

} _f1ap_Served_Cells_To_Add_List;


typedef struct _f1ap_Served_Cells_To_Modify_List_element 
{
#define DU_CONFIG_UPDATE_CELL_TO_MODIFY_SYSTEM_INFO_PRESENT  0x01

    unsigned int                     bitmask;

    /* OldNCGI */
    _f1ap_NCGI                       old_ncgi;

    /* Served-Cell-Information */
    _f1ap_Served_Cell_Information    served_cell_info;

    /* gNB-DU-System-Information */
    _f1ap_GNB_DU_System_Information  du_system_info;

} _f1ap_Served_Cells_To_Modify_List_element;


typedef struct _f1ap_Served_Cells_To_Modify_List
{
    unsigned int  count;

    _f1ap_Served_Cells_To_Modify_List_element  
                  cell_to_modify[MAX_CELL_PER_DU];

}_f1ap_Served_Cells_To_Modify_List;


typedef struct _f1ap_Served_Cells_To_Delete_List_element 
{
    /* OldNCGI */
    _f1ap_NCGI  ncgi;

} _f1ap_Served_Cells_To_Delete_List_element;


typedef struct _f1ap_Served_Cells_To_Delete_List
{
    unsigned int  count;

    _f1ap_Served_Cells_To_Delete_List_element  
                  cell_to_delete[MAX_CELL_PER_DU];

} _f1ap_Served_Cells_To_Delete_List;


typedef struct  _f1ap_GNBDUConfigurationUpdate 
{
#define DU_CONFIG_UPDATE_CELLS_TO_ADD_LIST_PRESENT   0x01
#define DU_CONFIG_UPDATE_CELLS_TO_MOD_LIST_PRESENT   0x02
#define DU_CONFIG_UPDATE_CELLS_TO_DEL_LIST_PRESENT   0x04

    unsigned int                        bitmask;

    /* Served-Cells-To-Add-List */
    _f1ap_Served_Cells_To_Add_List      cellsToAddList;

    /* Served-Cells-To-Modify-List */
    _f1ap_Served_Cells_To_Modify_List   cellsToModifyList;

    /* Served-Cells-To-Delete-List */
    _f1ap_Served_Cells_To_Delete_List   cellsToDeleteList;

} _f1ap_GNBDUConfigurationUpdate;


/**********************************************************************
 * GNB DU CONFIG UPDATE ACK
 *********************************************************************/

typedef struct _f1ap_GNBDUConfigurationUpdateAcknowledge 
{
#define DU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT    0x01

    unsigned int                      bitmask;

    /* Cells-to-be-Activated-List */
    _f1ap_Cells_to_be_Activated_List  cells_to_be_activated_list;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics      criticality_diagnostics;

} _f1ap_GNBDUConfigurationUpdateAcknowledge;


/**********************************************************************
 * GNB DU CONFIG UPDATE FAILURE
 *********************************************************************/

typedef struct _f1ap_GNBDUConfigurationUpdateFailure 
{
#define DU_CONFIG_UPDATE_FAILURE_TIME_TO_WAIT_PRESENT   0x01
#define DU_CONFIG_UPDATE_FAILURE_CRIT_DIAG_PRESENT      0x02

    unsigned int                  bitmask;
    unsigned int                  response; 
    unsigned int                  transaction_id ;

    /* Cause */
    _f1ap_Cause                   cause;

    /* TimeToWait */
    unsigned int                  timeToWait;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_GNBDUConfigurationUpdateFailure;


/*********************************************************************/

