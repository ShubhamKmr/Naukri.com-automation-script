
/**************************************************************************
 * UE Context Modification Request 
 *************************************************************************/

typedef struct _f1ap_ULTunnels_ToBeSetup_list_element 
{
    /* UL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint          tunnelEP;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    /* Tunnels count */
    unsigned int                            count;

    /* Tunnels list */
    _f1ap_ULTunnels_ToBeSetup_list_element  ulTunnelsToSetupList[2];

} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_DRBs_ToBeModified_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelsList;

} _f1ap_DRBs_ToBeModified_List_element;


typedef struct _f1ap_DRBs_ToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_ToBeModified_List_element
                  drbToBeModifiedList[32];
}_f1ap_DRBs_ToBeModified_List;


typedef struct _f1ap_DRBs_ToBeSetup_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* EUTRANQoS */
    _f1ap_EUTRANQoS                 qos;

    /* ULTunnels-ToBeSetup-list */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelsToBeSetupList;

} _f1ap_DRBs_ToBeSetup_List_element;


typedef struct _f1ap_DRBs_ToBeSetup_List
{
    unsigned int                        count;
    _f1ap_DRBs_ToBeSetup_List_element   drbToBeSetup[32];
} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element 
{
    /* SRBID */
    unsigned int  srb_id;
} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int                       count;
    _f1ap_SRBs_ToBeSetup_List_element  srbToBeSetup[1];
} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeReleased_List_element 
{
    /* SRBID  */
    unsigned int   srb_id;

} _f1ap_SRBs_ToBeReleased_List_element;


typedef struct _f1ap_SRBs_ToBeReleased_List
{
    unsigned int                            count;
    _f1ap_SRBs_ToBeReleased_List_element    srbToRelease[1];
}_f1ap_SRBs_ToBeReleased_List;


typedef struct _f1ap_DRBs_ToBeReleased_List_element 
{
    /* DRBID */
    unsigned int   drb_id;

} _f1ap_DRBs_ToBeReleased_List_element;

typedef struct _f1ap_DRBs_ToBeReleased_List
{
    unsigned int                          count;
    _f1ap_DRBs_ToBeReleased_List_element  drbToBeReleased[32];
} _f1ap_DRBs_ToBeReleased_List;


typedef struct _f1ap_SCell_ToBeSetup_List_element 
{
    /* SCell-ID */
    _f1ap_NCGI       scell_id;

} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int                        count;
    _f1ap_SCell_ToBeSetup_List_element  scellToBeSetup[32];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_UEContextModificationRequest 
{
#define UE_CTX_MOD_REQ_PSCELL_ID_PRESENT                            0x01
#define UE_CTX_MOD_REQ_DRX_CONFIG_PRESENT                           0x02
#define UE_CTX_MOD_REQ_CU_TO_DU_CONTAINER_PRESENT                   0x04
#define UE_CTX_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT          0x08
#define UE_CTX_MOD_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x10
#define UE_CTX_MOD_REQ_RRC_CONTAINER_PRESENT                        0x20

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* PSCell-ID */
    _f1ap_NCGI                    pscell_ncgi;

    /* DRXCycle */
    _f1ap_DRXCycle                drx_config;

    /* CUtoDURRCInformation */
    _f1ap_CUtoDURRCInformation    cuToDuContainer;

    /* TransmissionStopIndicator */
    unsigned int                  transmissionStopIndicator;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                  resCoordinationTransferContainer;

    /* RRCContainer */
    _OSDynOctStr                  rrcContainer;

    /* SCell-ToBeSetup-List */
    _f1ap_SCell_ToBeSetup_List    scellToBeSetupList;

    /* SRBs-ToBeSetup-List */
    _f1ap_SRBs_ToBeSetup_List     srbsToBeSetupList;

    /* SRBs-ToBeReleased-List */
    _f1ap_SRBs_ToBeReleased_List  srbsToBeReleasedList;

    /* DRBs-ToBeSetup-List */
    _f1ap_DRBs_ToBeSetup_List     drbsToBeSetupList;

    /* DRBs-ToBeModified-List */
    _f1ap_DRBs_ToBeModified_List  drbsToBeModifiedList;

    /* DRBs-ToBeReleased-List */
    _f1ap_DRBs_ToBeReleased_List  drbsToBeReleasedList;

} _f1ap_UEContextModificationRequest;


/*************************************************************************/


/**************************************************************************
 * UE Context Modification Response
 *************************************************************************/

typedef struct _f1ap_DRBs_Modified_List_element 
{
    /* DRBID */
    unsigned int                    drb_id;

    /* DLTunnels-ToBeSetup-list */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsToBeSetupList;

} _f1ap_DRBs_Modified_List_element;


/* List of f1ap_DRBs_Modified_List_element */
typedef struct _f1ap_DRBs_Modified_List
{
    unsigned int                      count;
    _f1ap_DRBs_Modified_List_element  drbModified[32];
} _f1ap_DRBs_Modified_List;


typedef struct _f1ap_DRBs_FailedToBeModified_List_element 
{
    /* DRBID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeModified_List_element;


/* List of f1ap_DRBs_FailedToBeModified_List_element */
typedef struct _f1ap_DRBs_FailedToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_FailedToBeModified_List_element  
                  drbFailedToBeModifiedList[32];
} _f1ap_DRBs_FailedToBeModified_List;


typedef struct _f1ap_UEContextModificationResponse 
{
#define UE_CTX_MOD_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x01 
#define UE_CTX_MOD_RESP_DU_TO_CU_CONTAINER_PRESENT                   0x02
#define UE_CTX_MOD_RESP_CRIT_DIAG_PRESENT                            0x04

    unsigned int                       bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                       cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                       du_f1ap_id;

    /* ResourceCoordinationTransferContainer */
    _OSDynOctStr                       resCoordinationTransferContainer;

    /* DUtoCURRCInformation */
    _f1ap_DUtoCURRCInformation         duToCuContainer;

    /* DRBs-Setup-List */
    _f1ap_DRBs_Setup_List              drbSetupList;

    /* DRBs-Modified-List */
    _f1ap_DRBs_Modified_List           drbModifiedList;

    /* SRBs-FailedToBeSetup-List */
    _f1ap_SRBs_FailedToBeSetup_List    srbsFailedToSetupList;

    /* DRBs-FailedToBeSetup-List */
    _f1ap_DRBs_FailedToBeSetup_List    drbsFailedToSetupList;

    /* DRBs-FailedToBeModified-List */
    _f1ap_DRBs_FailedToBeModified_List drbsFailedToModifiedList;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics       criticality_diagnostics;

} _f1ap_UEContextModificationResponse;


/*************************************************************************/


/**************************************************************************
 * UE Context Modification Failure 
 *************************************************************************/

typedef struct _f1ap_UEContextModificationFailure 
{
#define UE_CTX_MOD_FAILURE_CRIT_DIAG_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU-F1AP-ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU-F1AP-ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextModificationFailure;


/*************************************************************************/
