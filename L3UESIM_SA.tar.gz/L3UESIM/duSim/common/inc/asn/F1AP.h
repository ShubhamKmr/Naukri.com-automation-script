#ifndef _F1AP_H_
#define _F1AP_H_

#include "asn_common_types.h"


typedef struct _f1ap_PrivateIE_ID {
   unsigned int   t;
   union {
      /* t = 1 */
      unsigned short  local;
      /* t = 2 */
      //_ASN1OBJID      global;
   } u;
} _f1ap_PrivateIE_ID;


typedef struct _f1ap_Cause {
   unsigned int  t;
   union {
      /* t = 1 */
      unsigned int  radioNetwork;
      /* t = 2 */
      unsigned int  transport;
      /* t = 3 */
      unsigned int  protocol;
      /* t = 4 */
      unsigned int  misc;
   } u;
} _f1ap_Cause;


typedef struct _f1ap_UE_associatedLogicalF1_ConnectionItem {
   struct {
      unsigned gNB_CU_F1AP_IDPresent : 1;
      unsigned gNB_DU_F1AP_IDPresent : 1;
      unsigned iE_ExtensionsPresent : 1;
   } m15;
   unsigned int gNB_CU_F1AP_ID;
   unsigned int gNB_DU_F1AP_ID;
} _f1ap_UE_associatedLogicalF1_ConnectionItem;

typedef struct _f1ap_PLMN_Identity {
   unsigned int  numocts;
   unsigned char data[3];
} _f1ap_PLMN_Identity;

typedef struct _f1ap_NRCellIdentity {
   unsigned int   numbits;
   unsigned char  data[5];
} _f1ap_NRCellIdentity;


typedef struct _f1ap_NCGI {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m14;
   _f1ap_PLMN_Identity   pLMN_Identity;
   _f1ap_NRCellIdentity  nRCellIdentity;
} _f1ap_NCGI;


typedef struct _f1ap_BroadcastPLMNs_Item {
   unsigned char        n;
   _f1ap_PLMN_Identity  elem[6];
} _f1ap_BroadcastPLMNs_Item;


typedef struct _f1ap_FDD_Info {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m13;
   unsigned short uL_NARFCN;
   unsigned short dL_NARFCN;
   unsigned short uL_Transmission_Bandwidth;
   unsigned short dL_Transmission_Bandwidth;
} _f1ap_FDD_Info;


typedef struct _f1ap_TDD_Info {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m12;
   unsigned short nARFCN;
   unsigned short transmission_Bandwidth;
} _f1ap_TDD_Info;


typedef struct _f1ap_GNB_DU_System_Information {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m10;
   _OSDynOctStr  mIB_message;
   _OSDynOctStr  sIB1_message;
} _f1ap_GNB_DU_System_Information;


typedef struct _f1ap_CUtoDURRCInformation {
   struct {
      unsigned sCG_Config_InfoPresent : 1;
      unsigned iE_ExtensionsPresent : 1;
   } m9;
   _OSDynOctStr   sCG_Config_Info;
   _OSDynOctStr   uERadiocapabilities;
} _f1ap_CUtoDURRCInformation;


typedef struct _f1ap_DRXCycle {
   struct {
      unsigned shortDRXCycleLengthPresent : 1;
      unsigned shortDRXCycleTimerPresent : 1;
      unsigned iE_ExtensionsPresent : 1;
   } m8;
   unsigned int   longDRXCycleLength;
   unsigned int   shortDRXCycleLength;
   unsigned char  shortDRXCycleTimer;
} _f1ap_DRXCycle;


typedef struct _f1ap_AllocationAndRetentionPriority {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m7;
   unsigned char priorityLevel;
   unsigned int  pre_emptionCapability;
   unsigned int  pre_emptionVulnerability;
} _f1ap_AllocationAndRetentionPriority;


typedef struct _f1ap_GBR_QosInformation {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m6;
   unsigned long e_RAB_MaximumBitrateDL;
   unsigned long e_RAB_MaximumBitrateUL;
   unsigned long e_RAB_GuaranteedBitrateDL;
   unsigned long e_RAB_GuaranteedBitrateUL;
} _f1ap_GBR_QosInformation;


typedef struct _f1ap_EUTRANQoS {
   struct {
      unsigned gbrQosInformationPresent : 1;
      unsigned iE_ExtensionsPresent : 1;
   } m5;
   unsigned char  qCI;
   _f1ap_AllocationAndRetentionPriority allocationAndRetentionPriority;
   _f1ap_GBR_QosInformation gbrQosInformation;
} _f1ap_EUTRANQoS;


typedef struct _f1ap_GTP_TEID {
   unsigned int   numocts;
   unsigned char  data[4];
} _f1ap_GTP_TEID;


typedef struct _f1ap_GTPTunnelEndpoint {
   struct {
      unsigned iE_ExtensionsPresent : 1;
   } m4;
   _ASN1DynBitStr   transportLayerAddress;
   _f1ap_GTP_TEID   gTP_TEID;
} _f1ap_GTPTunnelEndpoint;


typedef struct _f1ap_DUtoCURRCInformation {
    _OSDynOctStr   cellGroupConfig;
} _f1ap_DUtoCURRCInformation;


typedef struct _f1ap_CriticalityDiagnostics_IE_Item 
{
    unsigned int   iECriticality;
    unsigned short iE_ID;
    unsigned int   typeOfError;
} _f1ap_CriticalityDiagnostics_IE_Item;


typedef struct _f1ap_CriticalityDiagnostics_IE_List
{
    unsigned int  count;
    _f1ap_CriticalityDiagnostics_IE_Item  _f1ap_CriticalityDiagnostics_IE_Item[6];
} _f1ap_CriticalityDiagnostics_IE_List;


typedef struct _f1ap_CriticalityDiagnostics {
   struct {
      unsigned procedureCodePresent : 1;
      unsigned triggeringMessagePresent : 1;
      unsigned procedureCriticalityPresent : 1;
      unsigned iEsCriticalityDiagnosticsPresent : 1;
      unsigned iE_ExtensionsPresent : 1;
   } m1;
   unsigned char procedureCode;
   unsigned int  triggeringMessage;
   unsigned int  procedureCriticality;
   _f1ap_CriticalityDiagnostics_IE_List iEsCriticalityDiagnostics;
} _f1ap_CriticalityDiagnostics;


typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListRes_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * UE-associatedLogicalF1-ConnectionItemRes information objects
       */
      union {
         /**
          * id: id-UE-associatedLogicalF1-ConnectionItem
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_UE_associatedLogicalF1_ConnectionItem  _f1ap_UE_associatedLogicalF1_ConnectionItemRes_1;

      } u;
   } value_f1ap_UE_associatedLogicalF1_ConnectionListRes_element;
} _f1ap_UE_associatedLogicalF1_ConnectionListRes_element;


typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListRes
{
    unsigned int  count;
    _f1ap_UE_associatedLogicalF1_ConnectionListRes_element  
                  _f1ap_UE_associatedLogicalF1_ConnectionListRes_element[1];
} _f1ap_UE_associatedLogicalF1_ConnectionListRes;


typedef struct _f1ap_ResetType {
   unsigned int  t;
   union {
      /* t = 1 */
      unsigned int  f1_Interface;
      /* t = 2 */
      _f1ap_UE_associatedLogicalF1_ConnectionListRes  partOfF1_Interface;
   } u;
} _f1ap_ResetType;


typedef struct  _f1ap_Reset_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * ResetIEs information objects
       */
      union {
         /**
          * id: id-TransactionID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ResetIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause _f1ap_ResetIEs_2;
         /**
          * id: id-ResetType
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_ResetType  _f1ap_ResetIEs_3;

      } u;
   } value_f1ap_Reset_protocolIEs_element;
} _f1ap_Reset_protocolIEs_element;


typedef struct  _f1ap_Reset_protocolIEs
{
    unsigned int count;
    _f1ap_Reset_protocolIEs_element  _f1ap_Reset_protocolIEs_element[3];
} _f1ap_Reset_protocolIEs;


typedef struct  _f1ap_Reset {
   _f1ap_Reset_protocolIEs  protocolIEs;
} _f1ap_Reset;


typedef struct _f1ap_F1SetupRequest_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * F1SetupRequestIEs information objects
       */
      union {

      } u;
   } value_f1ap_F1SetupRequest_protocolIEs_element;
} _f1ap_F1SetupRequest_protocolIEs_element;


typedef struct _f1ap_Served_Cells_To_Add_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * Served-Cells-To-Add-ItemIEs information objects
       */
      union {
         /**
          * id: id-Served-Cell-Information
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_Served_Cell_Information  _f1ap_Served_Cells_To_Add_ItemIEs_1;
         /**
          * id: id-gNB-DU-System-Information
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_GNB_DU_System_Information  _f1ap_Served_Cells_To_Add_ItemIEs_2;

      } u;
   } value_f1ap_Served_Cells_To_Add_List_element;
} _f1ap_Served_Cells_To_Add_List_element;


typedef struct  _f1ap_Served_Cells_To_Add_List
{
    unsigned int count;
    _f1ap_Served_Cells_To_Add_List_element  _f1ap_Served_Cells_To_Add_List_element[2];
} _f1ap_Served_Cells_To_Add_List;


typedef struct _f1ap_Served_Cells_To_Modify_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * Served-Cells-To-Modify-ItemIEs information objects
       */
      union {
         /**
          * id: id-OldNCGI
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_NCGI    _f1ap_Served_Cells_To_Modify_ItemIEs_1;
         /**
          * id: id-Served-Cell-Information
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_Served_Cell_Information _f1ap_Served_Cells_To_Modify_ItemIEs_2;
         /**
          * id: id-gNB-DU-System-Information
          * criticality: reject
          * presence: optional
          */
         _f1ap_GNB_DU_System_Information _f1ap_Served_Cells_To_Modify_ItemIEs_3;

      } u;
   } value_f1ap_Served_Cells_To_Modify_List_element;
} _f1ap_Served_Cells_To_Modify_List_element;

typedef struct _f1ap_Served_Cells_To_Modify_List
{
    unsigned int  count;
    _f1ap_Served_Cells_To_Modify_List_element  _f1ap_Served_Cells_To_Modify_List_element[3];
}_f1ap_Served_Cells_To_Modify_List;

typedef struct _f1ap_Served_Cells_To_Delete_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * Served-Cells-To-Delete-ItemIEs information objects
       */
      union {
         /**
          * id: id-OldNCGI
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_NCGI _f1ap_Served_Cells_To_Delete_ItemIEs_1;

      } u;
   } value_f1ap_Served_Cells_To_Delete_List_element;
} _f1ap_Served_Cells_To_Delete_List_element;


typedef struct _f1ap_Served_Cells_To_Delete_List
{
    unsigned int  count;
    _f1ap_Served_Cells_To_Delete_List_element  _f1ap_Served_Cells_To_Delete_List_element[1];
} _f1ap_Served_Cells_To_Delete_List;


typedef struct _f1ap_GNBDUConfigurationUpdate_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * GNBDUConfigurationUpdateIEs information objects
       */
      union {
         /**
          * id: id-Served-Cells-To-Add-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Served_Cells_To_Add_List      _f1ap_GNBDUConfigurationUpdateIEs_1;
         /**
          * id: id-Served-Cells-To-Modify-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Served_Cells_To_Modify_List  _f1ap_GNBDUConfigurationUpdateIEs_2;
         /**
          * id: id-Served-Cells-To-Delete-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Served_Cells_To_Delete_List  _f1ap_GNBDUConfigurationUpdateIEs_3;

      } u;
   } value_f1ap_GNBDUConfigurationUpdate_protocolIEs_element;
} _f1ap_GNBDUConfigurationUpdate_protocolIEs_element;

typedef struct _f1ap_GNBDUConfigurationUpdate_protocolIEs
{
    unsigned int count;
    _f1ap_GNBDUConfigurationUpdate_protocolIEs_element  
                 _f1ap_GNBDUConfigurationUpdate_protocolIEs_element[3];
}_f1ap_GNBDUConfigurationUpdate_protocolIEs;

typedef struct  _f1ap_GNBDUConfigurationUpdate {
   _f1ap_GNBDUConfigurationUpdate_protocolIEs protocolIEs;
} _f1ap_GNBDUConfigurationUpdate;


typedef struct _f1ap_Cells_to_be_Activated_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * Cells-to-be-Activated-List-ItemIEs information objects
       */
      union {
         /**
          * id: id-NCGI
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_NCGI  _f1ap_Cells_to_be_Activated_List_ItemIEs_1;
         /**
          * id: id-PCI
          * criticality: reject
          * presence: optional
          */
         unsigned short _f1ap_Cells_to_be_Activated_List_ItemIEs_2;

      } u;
   } value_f1ap_Cells_to_be_Activated_List_element;
} _f1ap_Cells_to_be_Activated_List_element;

typedef struct _f1ap_Cells_to_be_Activated_List
{
    unsigned int count;
    _f1ap_Cells_to_be_Activated_List_element  _f1ap_Cells_to_be_Activated_List_element[2];
} _f1ap_Cells_to_be_Activated_List;


typedef struct _f1ap_Cells_to_be_Deactivated_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * Cells-to-be-Deactivated-List-ItemIEs information objects
       */
      union {
         /**
          * id: id-NCGI
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_NCGI  _f1ap_Cells_to_be_Deactivated_List_ItemIEs_1;

      } u;
   } value_f1ap_Cells_to_be_Deactivated_List_element;
} _f1ap_Cells_to_be_Deactivated_List_element;


typedef struct _f1ap_Cells_to_be_Deactivated_List
{
    unsigned int   count;
    _f1ap_Cells_to_be_Deactivated_List_element  _f1ap_Cells_to_be_Deactivated_List_element[1];
} _f1ap_Cells_to_be_Deactivated_List;


typedef struct _f1ap_GNBCUConfigurationUpdate_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * GNBCUConfigurationUpdateIEs information objects
       */
      union {
         /**
          * id: id-Cells-to-be-Activated-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Cells_to_be_Activated_List    _f1ap_GNBCUConfigurationUpdateIEs_1;
         /**
          * id: id-Cells-to-be-Deactivated-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Cells_to_be_Deactivated_List  _f1ap_GNBCUConfigurationUpdateIEs_2;

      } u;
   } value_f1ap_GNBCUConfigurationUpdate_protocolIEs_element;
} _f1ap_GNBCUConfigurationUpdate_protocolIEs_element;

typedef struct _f1ap_GNBCUConfigurationUpdate_protocolIEs
{
    unsigned int   count;
    _f1ap_GNBCUConfigurationUpdate_protocolIEs_element  
                   _f1ap_GNBCUConfigurationUpdate_protocolIEs_element[2];
} _f1ap_GNBCUConfigurationUpdate_protocolIEs;


typedef struct _f1ap_GNBCUConfigurationUpdate {
   _f1ap_GNBCUConfigurationUpdate_protocolIEs  protocolIEs;
} _f1ap_GNBCUConfigurationUpdate;


typedef struct _f1ap_SCell_ToBeSetup_List_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * SCell-ToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-SCell-ID
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_NCGI  _f1ap_SCell_ToBeSetup_ItemIEs_1;

      } u;
   } value_f1ap_SCell_ToBeSetup_List_element;
} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int count;
    _f1ap_SCell_ToBeSetup_List_element  _f1ap_SCell_ToBeSetup_List_element[1];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * SRBs-ToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_SRBs_ToBeSetup_ItemIEs_1;

      } u;
   } value_f1ap_SRBs_ToBeSetup_List_element;
} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int                       count;
    _f1ap_SRBs_ToBeSetup_List_element  _f1ap_SRBs_ToBeSetup_List_element[1];
} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_ULTunnels_ToBeSetup_list_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * ULTunnels-ToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-UL-GTP-Tunnel-EndPoint
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_GTPTunnelEndpoint  _f1ap_ULTunnels_ToBeSetup_ItemIEs_1;

      } u;
   } value_f1ap_ULTunnels_ToBeSetup_list_element;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    unsigned int    count;
    _f1ap_ULTunnels_ToBeSetup_list_element  _f1ap_ULTunnels_ToBeSetup_list_element[1];
} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_DRBs_ToBeSetup_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-ToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_ToBeSetup_ItemIEs_1;
         /**
          * id: id-EUTRANQoS
          * criticality: reject
          * presence: optional
          */
         _f1ap_EUTRANQoS  _f1ap_DRBs_ToBeSetup_ItemIEs_2;
         /**
          * id: id-ULTunnels-ToBeSetup-list
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_ULTunnels_ToBeSetup_list  _f1ap_DRBs_ToBeSetup_ItemIEs_3;

      } u;
   } value_f1ap_DRBs_ToBeSetup_List_element;
} _f1ap_DRBs_ToBeSetup_List_element;


typedef struct _f1ap_DRBs_ToBeSetup_List
{
    unsigned int count;
    _f1ap_DRBs_ToBeSetup_List_element
                 _f1ap_DRBs_ToBeSetup_List_element[3];
} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_UEContextSetupRequest_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * UEContextSetupRequestIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextSetupRequestIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: ignore
          * presence: optional
          */
         unsigned int _f1ap_UEContextSetupRequestIEs_2;
         /**
          * id: id-PSCell-ID
          * criticality: ignore
          * presence: optional
          */
         _f1ap_NCGI  _f1ap_UEContextSetupRequestIEs_3;
         /**
          * id: id-CUtoDURRCInformation
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_CUtoDURRCInformation _f1ap_UEContextSetupRequestIEs_4;
         /**
          * id: id-DRXCycle
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRXCycle _f1ap_UEContextSetupRequestIEs_5;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr  _f1ap_UEContextSetupRequestIEs_6;
         /**
          * id: id-SCell-ToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_SCell_ToBeSetup_List _f1ap_UEContextSetupRequestIEs_7;
         /**
          * id: id-SRBs-ToBeSetup-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_SRBs_ToBeSetup_List  _f1ap_UEContextSetupRequestIEs_8;
         /**
          * id: id-DRBs-ToBeSetup-List
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_DRBs_ToBeSetup_List _f1ap_UEContextSetupRequestIEs_9;

      } u;
   } value_f1ap_UEContextSetupRequest_protocolIEs_element;
} _f1ap_UEContextSetupRequest_protocolIEs_element;


/* List of f1ap_UEContextSetupRequest_protocolIEs_element */
typedef struct _f1ap_UEContextSetupRequest_protocolIEs
{
    unsigned int count;
    _f1ap_UEContextSetupRequest_protocolIEs_element
                 _f1ap_UEContextSetupRequest_protocolIEs_element[9];
} _f1ap_UEContextSetupRequest_protocolIEs;


typedef struct _f1ap_UEContextSetupRequest {
   _f1ap_UEContextSetupRequest_protocolIEs protocolIEs;
} _f1ap_UEContextSetupRequest;


typedef struct _f1ap_UEContextReleaseCommand_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * UEContextReleaseCommandIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseCommandIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseCommandIEs_2;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause _f1ap_UEContextReleaseCommandIEs_3;

      } u;
   } value_f1ap_UEContextReleaseCommand_protocolIEs_element;
} _f1ap_UEContextReleaseCommand_protocolIEs_element;


/* List of f1ap_UEContextReleaseCommand_protocolIEs_element */
typedef struct _f1ap_UEContextReleaseCommand_protocolIEs
{
    unsigned int count;
    _f1ap_UEContextReleaseCommand_protocolIEs_element
                 _f1ap_UEContextReleaseCommand_protocolIEs_element[3];
}_f1ap_UEContextReleaseCommand_protocolIEs;


typedef struct _f1ap_UEContextReleaseCommand {
   _f1ap_UEContextReleaseCommand_protocolIEs protocolIEs;
} _f1ap_UEContextReleaseCommand;


typedef struct _f1ap_DRBs_ToBeModified_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-ToBeModified-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_ToBeModified_ItemIEs_1;
         /**
          * id: id-EUTRANQoS
          * criticality: reject
          * presence: optional
          */
         _f1ap_EUTRANQoS  _f1ap_DRBs_ToBeModified_ItemIEs_2;
         /**
          * id: id-ULTunnels-ToBeSetup-list
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_ULTunnels_ToBeSetup_list  _f1ap_DRBs_ToBeModified_ItemIEs_3;

      } u;
   } value_f1ap_DRBs_ToBeModified_List_element;
} _f1ap_DRBs_ToBeModified_List_element;


typedef struct _f1ap_DRBs_ToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_ToBeModified_List_element
                  _f1ap_DRBs_ToBeModified_List_element[3];
}_f1ap_DRBs_ToBeModified_List;


typedef struct _f1ap_SRBs_ToBeReleased_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * SRBs-ToBeReleased-ItemIEs information objects
       */
      union {
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_SRBs_ToBeReleased_ItemIEs_1;

      } u;
   } value_f1ap_SRBs_ToBeReleased_List_element;
} _f1ap_SRBs_ToBeReleased_List_element;


typedef struct _f1ap_SRBs_ToBeReleased_List
{
    unsigned int  count;
    _f1ap_SRBs_ToBeReleased_List_element
                  _f1ap_SRBs_ToBeReleased_List_element[1];
}_f1ap_SRBs_ToBeReleased_List;


typedef struct _f1ap_DRBs_ToBeReleased_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * DRBs-ToBeReleased-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_ToBeReleased_ItemIEs_1;

      } u;
   } value_f1ap_DRBs_ToBeReleased_List_element;
} _f1ap_DRBs_ToBeReleased_List_element;

typedef struct _f1ap_DRBs_ToBeReleased_List
{
    unsigned int count;
    _f1ap_DRBs_ToBeReleased_List_element 
                 _f1ap_DRBs_ToBeReleased_List_element[1];
} _f1ap_DRBs_ToBeReleased_List;

typedef struct _f1ap_UEContextModificationRequest_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * UEContextModificationRequestIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationRequestIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationRequestIEs_2;
         /**
          * id: id-PSCell-ID
          * criticality: ignore
          * presence: optional
          */
         _f1ap_NCGI  _f1ap_UEContextModificationRequestIEs_3;
         /**
          * id: id-DRXCycle
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRXCycle _f1ap_UEContextModificationRequestIEs_4;
         /**
          * id: id-CUtoDURRCInformation
          * criticality: reject
          * presence: optional
          */
         _f1ap_CUtoDURRCInformation _f1ap_UEContextModificationRequestIEs_5;
         /**
          * id: id-TransmissionStopIndicator
          * criticality: ignore
          * presence: optional
          */
         unsigned int  _f1ap_UEContextModificationRequestIEs_6;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr _f1ap_UEContextModificationRequestIEs_7;
         /**
          * id: id-RRCContainer
          * criticality: ignore
          * presence: optional
          */
         _OSDynOctStr  _f1ap_UEContextModificationRequestIEs_8;
         /**
          * id: id-SCell-ToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_SCell_ToBeSetup_List _f1ap_UEContextModificationRequestIEs_9;
         /**
          * id: id-SRBs-ToBeSetup-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_SRBs_ToBeSetup_List  _f1ap_UEContextModificationRequestIEs_10;
         /**
          * id: id-DRBs-ToBeSetup-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_DRBs_ToBeSetup_List  _f1ap_UEContextModificationRequestIEs_11;
         /**
          * id: id-DRBs-ToBeModified-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_DRBs_ToBeModified_List  _f1ap_UEContextModificationRequestIEs_12;
         /**
          * id: id-SRBs-ToBeReleased-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_SRBs_ToBeReleased_List  _f1ap_UEContextModificationRequestIEs_13;
         /**
          * id: id-DRBs-ToBeReleased-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_DRBs_ToBeReleased_List  _f1ap_UEContextModificationRequestIEs_14;

      } u;
   } value_f1ap_UEContextModificationRequest_protocolIEs_element;
} _f1ap_UEContextModificationRequest_protocolIEs_element;


typedef struct _f1ap_UEContextModificationRequest_protocolIEs
{
    unsigned int  count;
    _f1ap_UEContextModificationRequest_protocolIEs_element 
                 _f1ap_UEContextModificationRequest_protocolIEs_element[14];
} _f1ap_UEContextModificationRequest_protocolIEs;


typedef struct _f1ap_UEContextModificationRequest {
   _f1ap_UEContextModificationRequest_protocolIEs  protocolIEs;
} _f1ap_UEContextModificationRequest;


typedef struct _f1ap_DLTunnels_ToBeSetup_list_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DLTunnels-ToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-DL-GTP-Tunnel-EndPoint
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_GTPTunnelEndpoint _f1ap_DLTunnels_ToBeSetup_ItemIEs_1;

      } u;
   } value_f1ap_DLTunnels_ToBeSetup_list_element;
} _f1ap_DLTunnels_ToBeSetup_list_element;


typedef struct _f1ap_DLTunnels_ToBeSetup_list
{
    unsigned int  count;
    _f1ap_DLTunnels_ToBeSetup_list_element
                  _f1ap_DLTunnels_ToBeSetup_list_element[];
}_f1ap_DLTunnels_ToBeSetup_list;


typedef struct _f1ap_DRBs_Required_ToBeModified_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-Required-ToBeModified-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_Required_ToBeModified_ItemIEs_1;
         /**
          * id: id-DLTunnels-ToBeSetup-list
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_DLTunnels_ToBeSetup_list  _f1ap_DRBs_Required_ToBeModified_ItemIEs_2;

      } u;
   } value_f1ap_DRBs_Required_ToBeModified_List_element;
} _f1ap_DRBs_Required_ToBeModified_List_element;


typedef struct _f1ap_DRBs_Required_ToBeModified_List
{
    unsigned int count;
    _f1ap_DRBs_Required_ToBeModified_List_element
                 _f1ap_DRBs_Required_ToBeModified_List_element[2];
}_f1ap_DRBs_Required_ToBeModified_List;


typedef struct _f1ap_SRBs_Required_ToBeReleased_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int    t;

      /**
       * SRBs-Required-ToBeReleased-ItemIEs information objects
       */
      union {
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_SRBs_Required_ToBeReleased_ItemIEs_1;

      } u;
   } value_f1ap_SRBs_Required_ToBeReleased_List_element;
} _f1ap_SRBs_Required_ToBeReleased_List_element;


typedef struct  _f1ap_SRBs_Required_ToBeReleased_List
{
    unsigned int  count;
    _f1ap_SRBs_Required_ToBeReleased_List_element 
                  _f1ap_SRBs_Required_ToBeReleased_List_element[1];
}_f1ap_SRBs_Required_ToBeReleased_List;


typedef struct _f1ap_DRBs_Required_ToBeReleased_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * DRBs-Required-ToBeReleased-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_Required_ToBeReleased_ItemIEs_1;

      } u;
   } value_f1ap_DRBs_Required_ToBeReleased_List_element;
} _f1ap_DRBs_Required_ToBeReleased_List_element;


typedef struct _f1ap_DRBs_Required_ToBeReleased_List
{
    unsigned int  count;
    _f1ap_DRBs_Required_ToBeReleased_List_element
                  _f1ap_DRBs_Required_ToBeReleased_List_element[];
} _f1ap_DRBs_Required_ToBeReleased_List;


typedef struct _f1ap_UEContextModificationRequired_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * UEContextModificationRequiredIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationRequiredIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationRequiredIEs_2;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr _f1ap_UEContextModificationRequiredIEs_3;
         /**
          * id: id-DUtoCURRCInformation
          * criticality: reject
          * presence: optional
          */
         _f1ap_DUtoCURRCInformation  _f1ap_UEContextModificationRequiredIEs_4;
         /**
          * id: id-DRBs-Required-ToBeModified-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_DRBs_Required_ToBeModified_List _f1ap_UEContextModificationRequiredIEs_5;
         /**
          * id: id-SRBs-Required-ToBeReleased-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_SRBs_Required_ToBeReleased_List  _f1ap_UEContextModificationRequiredIEs_6;
         /**
          * id: id-DRBs-Required-ToBeReleased-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_DRBs_Required_ToBeReleased_List  _f1ap_UEContextModificationRequiredIEs_7;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause  _f1ap_UEContextModificationRequiredIEs_8;

      } u;
   } value_f1ap_UEContextModificationRequired_protocolIEs_element;
} _f1ap_UEContextModificationRequired_protocolIEs_element;


typedef struct  _f1ap_UEContextModificationRequired_protocolIEs
{
    unsigned int  count;
    _f1ap_UEContextModificationRequired_protocolIEs_element
                  _f1ap_UEContextModificationRequired_protocolIEs_element[8];
}_f1ap_UEContextModificationRequired_protocolIEs;


typedef struct _f1ap_UEContextModificationRequired {
   _f1ap_UEContextModificationRequired_protocolIEs protocolIEs;
} _f1ap_UEContextModificationRequired;


typedef struct _f1ap_ErrorIndication_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int    t;

      /**
       * ErrorIndicationIEs information objects
       */
      union {
         /**
          * id: id-TransactionID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ErrorIndicationIEs_1;
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: ignore
          * presence: optional
          */
         unsigned int _f1ap_ErrorIndicationIEs_2;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: ignore
          * presence: optional
          */
         unsigned int _f1ap_ErrorIndicationIEs_3;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: optional
          */
         _f1ap_Cause _f1ap_ErrorIndicationIEs_4;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics _f1ap_ErrorIndicationIEs_5;

      } u;
   } value_f1ap_ErrorIndication_protocolIEs_element;
} _f1ap_ErrorIndication_protocolIEs_element;

typedef struct  _f1ap_ErrorIndication_protocolIEs
{
    unsigned int  count;
    _f1ap_ErrorIndication_protocolIEs_element
                  _f1ap_ErrorIndication_protocolIEs_element[5];
} _f1ap_ErrorIndication_protocolIEs;


typedef struct _f1ap_ErrorIndication {
   _f1ap_ErrorIndication_protocolIEs  protocolIEs;
} _f1ap_ErrorIndication;


typedef struct _f1ap_UEContextReleaseRequest_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * UEContextReleaseRequestIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseRequestIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseRequestIEs_2;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause _f1ap_UEContextReleaseRequestIEs_3;

      } u;
   } value_f1ap_UEContextReleaseRequest_protocolIEs_element;
} _f1ap_UEContextReleaseRequest_protocolIEs_element;


typedef struct _f1ap_UEContextReleaseRequest_protocolIEs
{
    unsigned int  count;
    _f1ap_UEContextReleaseRequest_protocolIEs_element
                  _f1ap_UEContextReleaseRequest_protocolIEs_element[3];
} _f1ap_UEContextReleaseRequest_protocolIEs;


typedef struct _f1ap_UEContextReleaseRequest {
   _f1ap_UEContextReleaseRequest_protocolIEs protocolIEs;
} _f1ap_UEContextReleaseRequest;


typedef struct _f1ap_DLRRCMessageTransfer_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * DLRRCMessageTransferIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DLRRCMessageTransferIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DLRRCMessageTransferIEs_2;
         /**
          * id: id-oldgNB-DU-F1AP-ID
          * criticality: reject
          * presence: optional
          */
         unsigned int _f1ap_DLRRCMessageTransferIEs_3;
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_DLRRCMessageTransferIEs_4;
         /**
          * id: id-RRCContainer
          * criticality: reject
          * presence: mandatory
          */
         _OSDynOctStr _f1ap_DLRRCMessageTransferIEs_5;

      } u;
   } value_f1ap_DLRRCMessageTransfer_protocolIEs_element;
} _f1ap_DLRRCMessageTransfer_protocolIEs_element;


typedef struct _f1ap_DLRRCMessageTransfer_protocolIEs
{
    unsigned int  count;
    _f1ap_DLRRCMessageTransfer_protocolIEs_element
                  _f1ap_DLRRCMessageTransfer_protocolIEs_element[5];
} _f1ap_DLRRCMessageTransfer_protocolIEs;


typedef struct _f1ap_dLRRCMessageTransfer {
   _f1ap_DLRRCMessageTransfer_protocolIEs protocolIEs;
} _f1ap_dLRRCMessageTransfer;


typedef struct _f1ap_ULRRCMessageTransfer_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * ULRRCMessageTransferIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ULRRCMessageTransferIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ULRRCMessageTransferIEs_2;
         /**
          * id: id-SRBID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ULRRCMessageTransferIEs_3;
         /**
          * id: id-RRCContainer
          * criticality: reject
          * presence: mandatory
          */
         _OSDynOctStr  _f1ap_ULRRCMessageTransferIEs_4;

      } u;
   } value_f1ap_ULRRCMessageTransfer_protocolIEs_element;
} _f1ap_ULRRCMessageTransfer_protocolIEs_element;


typedef struct _f1ap_ULRRCMessageTransfer_protocolIEs
{
    unsigned int  count;
    _f1ap_ULRRCMessageTransfer_protocolIEs_element
                  _f1ap_ULRRCMessageTransfer_protocolIEs_element[4];
} _f1ap_ULRRCMessageTransfer_protocolIEs;


typedef struct _f1ap_ULRRCMessageTransfer {
   _f1ap_ULRRCMessageTransfer_protocolIEs  protocolIEs;
} _f1ap_ULRRCMessageTransfer;


typedef struct _f1ap_PrivateMessage_privateIEs_element {
   _f1ap_PrivateIE_ID id;
   unsigned int       criticality;
} _f1ap_PrivateMessage_privateIEs_element;


typedef struct _f1ap_PrivateMessage_privateIEs
{
    unsigned int  count;
    _f1ap_PrivateMessage_privateIEs_element
                  _f1ap_PrivateMessage_privateIEs_element[1];
} _f1ap_PrivateMessage_privateIEs;


typedef struct _f1ap_PrivateMessage {
   _f1ap_PrivateMessage_privateIEs privateIEs;
} _f1ap_PrivateMessage;


typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * UE-associatedLogicalF1-ConnectionItemResAck information objects
       */
      union {
         /**
          * id: id-UE-associatedLogicalF1-ConnectionItem
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_UE_associatedLogicalF1_ConnectionItem  _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1;

      } u;
   } value_f1ap_UE_associatedLogicalF1_ConnectionListResAck_element;
} _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element;


typedef struct _f1ap_UE_associatedLogicalF1_ConnectionListResAck
{
    unsigned int  count;
    _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element
                  _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element[1];
} _f1ap_UE_associatedLogicalF1_ConnectionListResAck;


typedef struct _f1ap_ResetAcknowledge_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * ResetAcknowledgeIEs information objects
       */
      union {
         /**
          * id: id-TransactionID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_ResetAcknowledgeIEs_1;
         /**
          * id: id-UE-associatedLogicalF1-ConnectionListResAck
          * criticality: ignore
          * presence: optional
          */
         _f1ap_UE_associatedLogicalF1_ConnectionListResAck  _f1ap_ResetAcknowledgeIEs_2;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics _f1ap_ResetAcknowledgeIEs_3;

      } u;
   } value_f1ap_ResetAcknowledge_protocolIEs_element;
} _f1ap_ResetAcknowledge_protocolIEs_element;


/* List of f1ap_ResetAcknowledge_protocolIEs_element */
typedef struct  _f1ap_ResetAcknowledge_protocolIEs
{
    unsigned int count;
    _f1ap_ResetAcknowledge_protocolIEs_element
                 _f1ap_ResetAcknowledge_protocolIEs_element[3];
} _f1ap_ResetAcknowledge_protocolIEs;


typedef struct _f1ap_ResetAcknowledge {
   _f1ap_ResetAcknowledge_protocolIEs protocolIEs;
} _f1ap_ResetAcknowledge;


typedef struct _f1ap_F1SetupResponse_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * F1SetupResponseIEs information objects
       */
      union {
         /**
          * id: id-TransactionID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_F1SetupResponseIEs_1;
         /**
          * id: id-Cells-to-be-Activated-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Cells_to_be_Activated_List  _f1ap_F1SetupResponseIEs_2;

      } u;
   } value_f1ap_F1SetupResponse_protocolIEs_element;
} _f1ap_F1SetupResponse_protocolIEs_element;


typedef struct  _f1ap_F1SetupResponse_protocolIEs
{
    unsigned int  count;
    _f1ap_F1SetupResponse_protocolIEs_element
                  _f1ap_F1SetupResponse_protocolIEs_element[];
} _f1ap_F1SetupResponse_protocolIEs;


typedef struct _f1ap_F1SetupResponse {
   _f1ap_F1SetupResponse_protocolIEs  protocolIEs;
} _f1ap_F1SetupResponse;


typedef struct _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * GNBDUConfigurationUpdateAcknowledgeIEs information objects
       */
      union {
         /**
          * id: id-Cells-to-be-Activated-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Cells_to_be_Activated_List _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_1;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics     _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2;

      } u;
   } value_f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element;
} _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element;


typedef struct _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs
{
    unsigned int  count;
    _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element
                  _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element[];
} _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs;


typedef struct _f1ap_GNBDUConfigurationUpdateAcknowledge {
   _f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs  protocolIEs;
} _f1ap_GNBDUConfigurationUpdateAcknowledge;


typedef struct _f1ap_Cells_Failed_to_be_Activated_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * Cells-Failed-to-be-Activated-List-ItemIEs information objects
       */
      union {
         /**
          * id: id-NCGI
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_NCGI  _f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause _f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_2;

      } u;
   } value_f1ap_Cells_Failed_to_be_Activated_List_element;
} _f1ap_Cells_Failed_to_be_Activated_List_element;


/* List of f1ap_Cells_Failed_to_be_Activated_List_element */
typedef struct  _f1ap_Cells_Failed_to_be_Activated_List
{
    unsigned int  count;
    _f1ap_Cells_Failed_to_be_Activated_List_element
                  _f1ap_Cells_Failed_to_be_Activated_List_element[];
} _f1ap_Cells_Failed_to_be_Activated_List;


typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * GNBCUConfigurationUpdateAcknowledgeIEs information objects
       */
      union {
         /**
          * id: id-Cells-Failed-to-be-Activated-List
          * criticality: reject
          * presence: optional
          */
         _f1ap_Cells_Failed_to_be_Activated_List  _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_1;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2;

      } u;
   } value_f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element;
} _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element;


/* List of f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element */
typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs
{
    unsigned int  count;
    _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element
                  _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element[2];
} _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs;


typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge {
    _f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs  protocolIEs;
} _f1ap_GNBCUConfigurationUpdateAcknowledge;


typedef struct _f1ap_SRBs_Setup_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * SRBs-Setup-ItemIEs information objects
       */
      union {
         /**
          * id: id-SRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int _f1ap_SRBs_Setup_ItemIEs_1;

      } u;
   } value_f1ap_SRBs_Setup_List_element;
} _f1ap_SRBs_Setup_List_element;


/* List of f1ap_SRBs_Setup_List_element */
typedef struct  _f1ap_SRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_SRBs_Setup_List_element  _f1ap_SRBs_Setup_List_element[1];
} _f1ap_SRBs_Setup_List;


typedef struct  _f1ap_DRBs_Setup_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-Setup-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int  _f1ap_DRBs_Setup_ItemIEs_1;
         /**
          * id: id-DLTunnels-ToBeSetup-list
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_DLTunnels_ToBeSetup_list  _f1ap_DRBs_Setup_ItemIEs_2;

      } u;
   } value_f1ap_DRBs_Setup_List_element;
} _f1ap_DRBs_Setup_List_element;


/* List of f1ap_DRBs_Setup_List_element */
typedef struct _f1ap_DRBs_Setup_List
{
    unsigned int                   count;
    _f1ap_DRBs_Setup_List_element  _f1ap_DRBs_Setup_List_element[2];
}_f1ap_DRBs_Setup_List;


typedef struct _f1ap_SRBs_FailedToBeSetup_List_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * SRBs-FailedToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-SRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int  _f1ap_SRBs_FailedToBeSetup_ItemIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: optional
          */
         _f1ap_Cause   _f1ap_SRBs_FailedToBeSetup_ItemIEs_2;

      } u;
   } value_f1ap_SRBs_FailedToBeSetup_List_element;
} _f1ap_SRBs_FailedToBeSetup_List_element;


typedef struct  _f1ap_SRBs_FailedToBeSetup_List
{
    unsigned int  count;
    _f1ap_SRBs_FailedToBeSetup_List_element
                  _f1ap_SRBs_FailedToBeSetup_List_element[2];
} _f1ap_SRBs_FailedToBeSetup_List;


typedef struct _f1ap_DRBs_FailedToBeSetup_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * DRBs-FailedToBeSetup-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int _f1ap_DRBs_FailedToBeSetup_ItemIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: optional
          */
         _f1ap_Cause  _f1ap_DRBs_FailedToBeSetup_ItemIEs_2;
      } u;
   } value_f1ap_DRBs_FailedToBeSetup_List_element;
} _f1ap_DRBs_FailedToBeSetup_List_element;


/* List of f1ap_DRBs_FailedToBeSetup_List_element */
typedef struct _f1ap_DRBs_FailedToBeSetup_List
{
    unsigned int  count;
    _f1ap_DRBs_FailedToBeSetup_List_element 
                  _f1ap_DRBs_FailedToBeSetup_List_element[2];
} _f1ap_DRBs_FailedToBeSetup_List;


typedef struct _f1ap_UEContextSetupResponse_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * UEContextSetupResponseIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextSetupResponseIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextSetupResponseIEs_2;
         /**
          * id: id-DUtoCURRCInformation
          * criticality: reject
          * presence: mandatory
          */
         _f1ap_DUtoCURRCInformation  _f1ap_UEContextSetupResponseIEs_3;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr  _f1ap_UEContextSetupResponseIEs_4;
         /**
          * id: id-SRBs-Setup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_SRBs_Setup_List            _f1ap_UEContextSetupResponseIEs_5;
         /**
          * id: id-DRBs-Setup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_Setup_List            _f1ap_UEContextSetupResponseIEs_6;
         /**
          * id: id-SRBs-FailedToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_SRBs_FailedToBeSetup_List  _f1ap_UEContextSetupResponseIEs_7;
         /**
          * id: id-DRBs-FailedToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_FailedToBeSetup_List  _f1ap_UEContextSetupResponseIEs_8;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics     _f1ap_UEContextSetupResponseIEs_9;

      } u;
   } value_f1ap_UEContextSetupResponse_protocolIEs_element;
} _f1ap_UEContextSetupResponse_protocolIEs_element;


/* List of f1ap_UEContextSetupResponse_protocolIEs_element */
typedef struct _f1ap_UEContextSetupResponse_protocolIEs
{
    unsigned int count;
    _f1ap_UEContextSetupResponse_protocolIEs_element
                 _f1ap_UEContextSetupResponse_protocolIEs_element[9];
} _f1ap_UEContextSetupResponse_protocolIEs;


typedef struct _f1ap_UEContextSetupResponse {
   _f1ap_UEContextSetupResponse_protocolIEs  protocolIEs;
} _f1ap_UEContextSetupResponse;


typedef struct _f1ap_UEContextReleaseComplete_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * UEContextReleaseCompleteIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseCompleteIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextReleaseCompleteIEs_2;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_UEContextReleaseCompleteIEs_3;

      } u;
   } value_f1ap_UEContextReleaseComplete_protocolIEs_element;
} _f1ap_UEContextReleaseComplete_protocolIEs_element;


/* List of f1ap_UEContextReleaseComplete_protocolIEs_element */
typedef struct _f1ap_UEContextReleaseComplete_protocolIEs
{
    unsigned int  count;
    _f1ap_UEContextReleaseComplete_protocolIEs_element 
                  _f1ap_UEContextReleaseComplete_protocolIEs_element[3];
} _f1ap_UEContextReleaseComplete_protocolIEs;


typedef struct _f1ap_UEContextReleaseComplete {
   _f1ap_UEContextReleaseComplete_protocolIEs  protocolIEs;
} _f1ap_UEContextReleaseComplete;


typedef struct _f1ap_DRBs_Modified_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-Modified-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int                    _f1ap_DRBs_Modified_ItemIEs_1;
         /**
          * id: id-DLTunnels-ToBeSetup-list
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_DLTunnels_ToBeSetup_list  _f1ap_DRBs_Modified_ItemIEs_2;

      } u;
   } value_f1ap_DRBs_Modified_List_element;
} _f1ap_DRBs_Modified_List_element;


/* List of f1ap_DRBs_Modified_List_element */
typedef struct _f1ap_DRBs_Modified_List
{
    unsigned int  count;
    _f1ap_DRBs_Modified_List_element  
                  _f1ap_DRBs_Modified_List_element[2];
} _f1ap_DRBs_Modified_List;


typedef struct _f1ap_DRBs_FailedToBeModified_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-FailedToBeModified-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int  _f1ap_DRBs_FailedToBeModified_ItemIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: optional
          */
         _f1ap_Cause   _f1ap_DRBs_FailedToBeModified_ItemIEs_2;

      } u;
   } value_f1ap_DRBs_FailedToBeModified_List_element;
} _f1ap_DRBs_FailedToBeModified_List_element;


/* List of f1ap_DRBs_FailedToBeModified_List_element */
typedef struct _f1ap_DRBs_FailedToBeModified_List
{
    unsigned int  count;
    _f1ap_DRBs_FailedToBeModified_List_element  
                  _f1ap_DRBs_FailedToBeModified_List_element[2];
} _f1ap_DRBs_FailedToBeModified_List;


typedef struct _f1ap_UEContextModificationResponse_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * UEContextModificationResponseIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationResponseIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationResponseIEs_2;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr  _f1ap_UEContextModificationResponseIEs_3;
         /**
          * id: id-DUtoCURRCInformation
          * criticality: reject
          * presence: optional
          */
         _f1ap_DUtoCURRCInformation  _f1ap_UEContextModificationResponseIEs_4;
         /**
          * id: id-DRBs-Setup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_Setup_List  _f1ap_UEContextModificationResponseIEs_5;
         /**
          * id: id-DRBs-Modified-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_Modified_List  _f1ap_UEContextModificationResponseIEs_6;
         /**
          * id: id-SRBs-FailedToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_SRBs_FailedToBeSetup_List _f1ap_UEContextModificationResponseIEs_7;
         /**
          * id: id-DRBs-FailedToBeSetup-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_FailedToBeSetup_List _f1ap_UEContextModificationResponseIEs_8;
         /**
          * id: id-DRBs-FailedToBeModified-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_FailedToBeModified_List _f1ap_UEContextModificationResponseIEs_9;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_UEContextModificationResponseIEs_10;

      } u;
   } value_f1ap_UEContextModificationResponse_protocolIEs_element;
} _f1ap_UEContextModificationResponse_protocolIEs_element;


typedef struct _f1ap_UEContextModificationResponse_protocolIEs
{
    unsigned int count;
    _f1ap_UEContextModificationResponse_protocolIEs_element
                 _f1ap_UEContextModificationResponse_protocolIEs_element[10];
} _f1ap_UEContextModificationResponse_protocolIEs;


typedef struct _f1ap_UEContextModificationResponse {
   _f1ap_UEContextModificationResponse_protocolIEs  protocolIEs;
} _f1ap_UEContextModificationResponse;


typedef struct _f1ap_DRBs_ModifiedConf_List_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * DRBs-ModifiedConf-ItemIEs information objects
       */
      union {
         /**
          * id: id-DRBID
          * criticality: ignore
          * presence: mandatory
          */
         unsigned int  _f1ap_DRBs_ModifiedConf_ItemIEs_1;
         /**
          * id: id-ULTunnels-ToBeSetup-list
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_ULTunnels_ToBeSetup_list  _f1ap_DRBs_ModifiedConf_ItemIEs_2;

      } u;
   } value_f1ap_DRBs_ModifiedConf_List_element;
} _f1ap_DRBs_ModifiedConf_List_element;


typedef struct _f1ap_DRBs_ModifiedConf_List
{
    unsigned int                          count;
    _f1ap_DRBs_ModifiedConf_List_element  _f1ap_DRBs_ModifiedConf_List_element[2];
} _f1ap_DRBs_ModifiedConf_List;


typedef struct _f1ap_UEContextModificationConfirm_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * UEContextModificationConfirmIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationConfirmIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextModificationConfirmIEs_2;
         /**
          * id: id-ResourceCoordinationTransferContainer
          * criticality: reject
          * presence: optional
          */
         _OSDynOctStr  _f1ap_UEContextModificationConfirmIEs_3;
         /**
          * id: id-DRBs-ModifiedConf-List
          * criticality: ignore
          * presence: optional
          */
         _f1ap_DRBs_ModifiedConf_List        _f1ap_UEContextModificationConfirmIEs_4;
         /**
          * id: id-DRBs-FailedToBeModified-List
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_DRBs_FailedToBeModified_List  _f1ap_UEContextModificationConfirmIEs_5;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics        _f1ap_UEContextModificationConfirmIEs_6;

      } u;
   } value_f1ap_UEContextModificationConfirm_protocolIEs_element;
} _f1ap_UEContextModificationConfirm_protocolIEs_element;


typedef struct _f1ap_UEContextModificationConfirm_protocolIEs
{
    unsigned int count;
    _f1ap_UEContextModificationConfirm_protocolIEs_element
                 _f1ap_UEContextModificationConfirm_protocolIEs_element[6];
} _f1ap_UEContextModificationConfirm_protocolIEs;


typedef struct _f1ap_UEContextModificationConfirm {
   _f1ap_UEContextModificationConfirm_protocolIEs  protocolIEs;
} _f1ap_UEContextModificationConfirm;


typedef struct _f1ap_F1SetupFailure_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int    t;

      /**
       * F1SetupFailureIEs information objects
       */
      union {
         /**
          * id: id-TransactionID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int                  _f1ap_F1SetupFailureIEs_1;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause                   _f1ap_F1SetupFailureIEs_2;
         /**
          * id: id-TimeToWait
          * criticality: ignore
          * presence: optional
          */
         unsigned int                  _f1ap_F1SetupFailureIEs_3;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_F1SetupFailureIEs_4;

      } u;
   } value_f1ap_F1SetupFailure_protocolIEs_element;
} _f1ap_F1SetupFailure_protocolIEs_element;

typedef struct _f1ap_F1SetupFailure_protocolIEs
{
    unsigned int count;
    _f1ap_F1SetupFailure_protocolIEs_element 
                 _f1ap_F1SetupFailure_protocolIEs_element[4];
}_f1ap_F1SetupFailure_protocolIEs;


typedef struct _f1ap_F1SetupFailure {
   _f1ap_F1SetupFailure_protocolIEs protocolIEs;
} _f1ap_F1SetupFailure;


typedef struct _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int   t;

      /**
       * GNBDUConfigurationUpdateFailureIEs information objects
       */
      union {
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause                   _f1ap_GNBDUConfigurationUpdateFailureIEs_1;
         /**
          * id: id-TimeToWait
          * criticality: ignore
          * presence: optional
          */
         unsigned int                  _f1ap_GNBDUConfigurationUpdateFailureIEs_2;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_GNBDUConfigurationUpdateFailureIEs_3;

      } u;
   } value_f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element;
} _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element;

typedef struct _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs
{
    unsigned int count;
    _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element
                 _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element[3];
} _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs;


typedef struct _f1ap_GNBDUConfigurationUpdateFailure {
   _f1ap_GNBDUConfigurationUpdateFailure_protocolIEs  protocolIEs;
} _f1ap_GNBDUConfigurationUpdateFailure;


typedef struct _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int  t;

      /**
       * GNBCUConfigurationUpdateFailureIEs information objects
       */
      union {
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause                   _f1ap_GNBCUConfigurationUpdateFailureIEs_1;
         /**
          * id: id-TimeToWait
          * criticality: ignore
          * presence: optional
          */
         unsigned int              _f1ap_GNBCUConfigurationUpdateFailureIEs_2;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_GNBCUConfigurationUpdateFailureIEs_3;

      } u;
   } value_f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element;
} _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element;


typedef struct _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs
{
    unsigned int  count;
    _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element 
                  _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element[3];
} _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs;


typedef struct _f1ap_GNBCUConfigurationUpdateFailure {
   _f1ap_GNBCUConfigurationUpdateFailure_protocolIEs  protocolIEs;
} _f1ap_GNBCUConfigurationUpdateFailure;


/**************************************************************/
/*                                                            */
/*  UEContextSetupFailure_protocolIEs_element                 */
/*                                                            */
/**************************************************************/
/*
Type was extracted from 'UEContextSetupFailure'
*/
typedef struct _f1ap_UEContextSetupFailure_protocolIEs_element {
   unsigned short id;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * UEContextSetupFailureIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int _f1ap_UEContextSetupFailureIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: ignore
          * presence: optional
          */
         unsigned int _f1ap_UEContextSetupFailureIEs_2;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause _f1ap_UEContextSetupFailureIEs_3;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_UEContextSetupFailureIEs_4;

      } u;
   } value_f1ap_UEContextSetupFailure_protocolIEs_element;
} _f1ap_UEContextSetupFailure_protocolIEs_element;


typedef struct _f1ap_UEContextSetupFailure_protocolIEs {
    unsigned int  count;
    _f1ap_UEContextSetupFailure_protocolIEs_element 
                  _f1ap_UEContextSetupFailure_protocolIEs_element[4]; 
} _f1ap_UEContextSetupFailure_protocolIEs;


typedef struct _f1ap_UEContextSetupFailure {
   _f1ap_UEContextSetupFailure_protocolIEs  protocolIEs;
} _f1ap_UEContextSetupFailure;


typedef struct _f1ap_UEContextModificationFailure_protocolIEs_element {
   unsigned short id;
   unsigned int   criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * UEContextModificationFailureIEs information objects
       */
      union {
         /**
          * id: id-gNB-CU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int                  _f1ap_UEContextModificationFailureIEs_1;
         /**
          * id: id-gNB-DU-F1AP-ID
          * criticality: reject
          * presence: mandatory
          */
         unsigned int                  _f1ap_UEContextModificationFailureIEs_2;
         /**
          * id: id-Cause
          * criticality: ignore
          * presence: mandatory
          */
         _f1ap_Cause                   _f1ap_UEContextModificationFailureIEs_3;
         /**
          * id: id-CriticalityDiagnostics
          * criticality: ignore
          * presence: optional
          */
         _f1ap_CriticalityDiagnostics  _f1ap_UEContextModificationFailureIEs_4;

      } u;
   } value_f1ap_UEContextModificationFailure_protocolIEs_element;
} _f1ap_UEContextModificationFailure_protocolIEs_element;


typedef struct _f1ap_UEContextModificationFailure_protocolIEs {
    unsigned int  count;
    _f1ap_UEContextModificationFailure_protocolIEs_element 
                  _f1ap_UEContextModificationFailure_protocolIEs_element[5]; 
} _f1ap_UEContextModificationFailure_protocolIEs;


typedef struct _f1ap_UEContextModificationFailure {
   _f1ap_UEContextModificationFailure_protocolIEs  protocolIEs;
} _f1ap_UEContextModificationFailure;


typedef struct _f1ap_InitiatingMessage {
   unsigned char procedureCode;
   unsigned int  criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * F1AP-ELEMENTARY-PROCEDURES information objects
       */
      union {
         /**
          * procedureCode: id-Reset
          * criticality: f1ap_reject
          */
         _f1ap_Reset                          reset;
         /**
          * procedureCode: id-F1Setup
          * criticality: f1ap_reject
          */
         _f1ap_F1SetupRequest                 f1Setup;
         /**
          * procedureCode: id-gNBDUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBDUConfigurationUpdate       gNBDUConfigurationUpdate;
         /**
          * procedureCode: id-gNBCUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBCUConfigurationUpdate       gNBCUConfigurationUpdate;
         /**
          * procedureCode: id-UEContextSetup
          * criticality: f1ap_reject
          */
         _f1ap_UEContextSetupRequest          uEContextSetup;
         /**
          * procedureCode: id-UEContextRelease
          * criticality: f1ap_reject
          */
         _f1ap_UEContextReleaseCommand        uEContextRelease;
         /**
          * procedureCode: id-UEContextModification
          * criticality: f1ap_reject
          */
         _f1ap_UEContextModificationRequest   uEContextModification;
         /**
          * procedureCode: id-UEContextModificationRequired
          * criticality: f1ap_reject
          */
         _f1ap_UEContextModificationRequired  uEContextModificationRequired;
         /**
          * procedureCode: id-ErrorIndication
          * criticality: f1ap_ignore
          */
         _f1ap_ErrorIndication                errorIndication;
         /**
          * procedureCode: id-UEContextReleaseRequest
          * criticality: f1ap_ignore
          */
         _f1ap_UEContextReleaseRequest        uEContextReleaseRequest;
         /**
          * procedureCode: id-DLRRCMessageTransfer
          * criticality: f1ap_ignore
          */
         _f1ap_DLRRCMessageTransfer           dLRRCMessageTransfer;
         /**
          * procedureCode: id-ULRRCMessageTransfer
          * criticality: f1ap_ignore
          */
         _f1ap_ULRRCMessageTransfer           uLRRCMessageTransfer;
         /**
          * procedureCode: id-privateMessage
          * criticality: f1ap_ignore
          */
         _f1ap_PrivateMessage                 privateMessage;

      } u;
   } value_f1ap_InitiatingMessage;
} _f1ap_InitiatingMessage;


typedef struct _f1ap_SuccessfulOutcome {
   unsigned char procedureCode;
   unsigned int criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * F1AP-ELEMENTARY-PROCEDURES information objects
       */
      union {
         /**
          * procedureCode: id-Reset
          * criticality: f1ap_reject
          */
         _f1ap_ResetAcknowledge reset;
         /**
          * procedureCode: id-F1Setup
          * criticality: f1ap_reject
          */
         _f1ap_F1SetupResponse  f1Setup;
         /**
          * procedureCode: id-gNBDUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBDUConfigurationUpdateAcknowledge  gNBDUConfigurationUpdate;
         /**
          * procedureCode: id-gNBCUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBCUConfigurationUpdateAcknowledge  gNBCUConfigurationUpdate;
         /**
          * procedureCode: id-UEContextSetup
          * criticality: f1ap_reject
          */
         _f1ap_UEContextSetupResponse        uEContextSetup;
         /**
          * procedureCode: id-UEContextRelease
          * criticality: f1ap_reject
          */
         _f1ap_UEContextReleaseComplete      uEContextRelease;
         /**
          * procedureCode: id-UEContextModification
          * criticality: f1ap_reject
          */
         _f1ap_UEContextModificationResponse uEContextModification;
         /**
          * procedureCode: id-UEContextModificationRequired
          * criticality: f1ap_reject
          */
         _f1ap_UEContextModificationConfirm  uEContextModificationRequired;

      } u;
   } value_f1ap_SuccessfulOutcome;
} _f1ap_SuccessfulOutcome;


typedef struct _f1ap_UnsuccessfulOutcome {
   unsigned char procedureCode;
   unsigned int  criticality;
   struct {
      /**
       * information object selector
       */
      unsigned int t;

      /**
       * F1AP-ELEMENTARY-PROCEDURES information objects
       */
      union {
         /**
          * procedureCode: id-F1Setup
          * criticality: f1ap_reject
          */
         _f1ap_F1SetupFailure                  f1Setup;
         /**
          * procedureCode: id-gNBDUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBDUConfigurationUpdateFailure gNBDUConfigurationUpdate;
         /**
          * procedureCode: id-gNBCUConfigurationUpdate
          * criticality: f1ap_reject
          */
         _f1ap_GNBCUConfigurationUpdateFailure gNBCUConfigurationUpdate;
         /**
          * procedureCode: id-UEContextSetup
          * criticality: f1ap_reject
          */
         _f1ap_UEContextSetupFailure           uEContextSetup;
         /**
          * procedureCode: id-UEContextModification
          * criticality: f1ap_reject
          */
         _f1ap_UEContextModificationFailure    uEContextModification;

      } u;
   } value_f1ap_UnsuccessfulOutcome;
} _f1ap_UnsuccessfulOutcome;


#endif  // _F1AP_H_
