
/********************************************************************
 *  CU Configuration Update
 *******************************************************************/

typedef struct _f1ap_Cells_to_be_Activated_List_element 
{
    /* NCGI */
    _f1ap_NCGI      cgi;

    /* PCI */
    unsigned short  pci;

} _f1ap_Cells_to_be_Activated_List_element;


typedef struct _f1ap_Cells_to_be_Activated_List
{
    unsigned int    count;
    _f1ap_Cells_to_be_Activated_List_element  
                    cell_to_activate[MAX_CELL_PER_DU];
} _f1ap_Cells_to_be_Activated_List;


typedef struct _f1ap_Cells_to_be_Deactivated_List_element 
{
    /* NCGI */
    _f1ap_NCGI      cgi;

} _f1ap_Cells_to_be_Deactivated_List_element;


typedef struct _f1ap_Cells_to_be_Deactivated_List
{
    unsigned int    count;

    _f1ap_Cells_to_be_Deactivated_List_element  
                    cell_to_deactivate[MAX_CELL_PER_DU];

} _f1ap_Cells_to_be_Deactivated_List;


typedef struct _f1ap_GNBCUConfigurationUpdate 
{
    /* Cells-to-be-Activated-List */
    _f1ap_Cells_to_be_Activated_List    
                    cellsToBeActivatedList;
    
    /* Cells-to-be-Deactivated-List */
    _f1ap_Cells_to_be_Deactivated_List  
                    cellsToBeDeactivatedList;

} _f1ap_GNBCUConfigurationUpdate;

/*********************************************************************/



/**********************************************************************
 * CU Configuration Update Acknowledge
 *********************************************************************/

typedef struct _f1ap_Cells_Failed_to_be_Activated_List_element 
{
    /* NCGI */
    _f1ap_NCGI   cgi;

    /* Cause */
    _f1ap_Cause  cause;

} _f1ap_Cells_Failed_to_be_Activated_List_element;


/* List of cells which failed to be activated */
typedef struct  _f1ap_Cells_Failed_to_be_Activated_List
{
    unsigned int   count;

    _f1ap_Cells_Failed_to_be_Activated_List_element
                   cellFailedToBeActivated[MAX_CELL_PER_DU];
} _f1ap_Cells_Failed_to_be_Activated_List;


typedef struct _f1ap_GNBCUConfigurationUpdateAcknowledge 
{
#define F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT     0x01

    unsigned int       bitmask;

    /* Cells-Failed-to-be-Activated-List */
    _f1ap_Cells_Failed_to_be_Activated_List   
                       cellsFailedToBeActivatedList;
    
    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics              
                       criticality_diagnostics;

} _f1ap_GNBCUConfigurationUpdateAcknowledge;


/*********************************************************************/



/**********************************************************************
 *  CU Configuration Update Failure
 *********************************************************************/
typedef struct _f1ap_GNBCUConfigurationUpdateFailure 
{
#define F1AP_CU_CFG_UPDATE_TIME_TO_WAIT_PRESENT         0x01
#define F1AP_CU_CFG_UPDATE_CRIT_DIAGNOSTICS_PRESENT     0x02

    unsigned int                   bitmask;

    /* Cause */
    _f1ap_Cause                    cause;

    /* TimeToWait (f1ap_TimeToWait_Root_et) */
    unsigned int                   timeToWait;

    /* CriticalityDiagnostics */
    _f1ap_CriticalityDiagnostics   criticalityDiagnostics;

} _f1ap_GNBCUConfigurationUpdateFailure;


/*********************************************************************/
