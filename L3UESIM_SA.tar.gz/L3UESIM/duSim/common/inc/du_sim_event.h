#ifndef _DU_SIM_EVENT_H_
#define _DU_SIM_EVENT_H_

/* This file defines the interfaces exposed by DU SIM 
 * towards command interpreter. */

#include "lteTypes.h"
#include "du_sim_common.h"


/* Structure defining the header of messages exchanged
 * between various modules of DU simulator */
typedef struct
{
    /* API Identifier */
    unsigned short  apiId;

    /* Unique DU identifier. In case of non DU specific API
     * receiving entity is not supposed to interpret it. */
    unsigned short  du_id;

    /* Length of the message (including header) */
    unsigned int    length;

    /* Unique UE identifier. In case of non UE specific API
     * receiving entity is not supposed to interpret it. */
    unsigned int    imsi;

} du_sim_event_hdr_t;


/* Structure defining the content of message exchanged between
 * various modules of DU simulator. */
typedef struct
{
    /* Message header */
    du_sim_event_hdr_t  header;

    /* Message body */
    unsigned char*      msgBuf;

} du_sim_event_t;


#endif  // _DU_SIM_EVENT_H_

