#ifndef _UE_CTX_MGMNT_H_
#define _UE_CTX_MGMNT_H_

#if 0

#define MAX_SRB_PER_UE                      8
#define MAX_UE_CAPABILITY_BUFFER_LEN        2048
#define MAX_SCG_CONFIG_INFO_BUFFER_LEN      4096
#define RES_COORDINATION_CONTAINER_BUF_LEN  512
#define DU_TO_CU_CONTAINER_LENGTH           4096
#define MAX_LOGICAL_CHANNEL                 8
#define MAX_SR_CONFIG_PER_CELL_GROUP        8
#define MAX_NUM_TAG                         4
#define MAX_SCELL_PER_UE                    32

/****************************************************************************
 *  UE CONTEXT SETUP REQUEST 
 ***************************************************************************/

/* Enum defining the possible values of RLC SN field 
 * length for AM mode. */
typedef enum
{
    RLC_AM_SN_FIELD_LEN_12,
    RLC_AM_SN_FIELD_LEN_18
} rlc_am_sn_field_length_et;


/* Enum defining the possible values of RLC SN field 
 * length for UM mode. */
typedef enum
{
    RLC_UM_SN_FIELD_LEN_6,
    RLC_UM_SN_FIELD_LEN_12
} rlc_um_sn_field_length_et;


/* Enum defining the possible value of re-assembly timer */ 
typedef enum
{
    RLC_T_REASSEMBLY_MS_0,
    RLC_T_REASSEMBLY_MS_5,
    RLC_T_REASSEMBLY_MS_10,
    RLC_T_REASSEMBLY_MS_15,
    RLC_T_REASSEMBLY_MS_20,
    RLC_T_REASSEMBLY_MS_25,
    RLC_T_REASSEMBLY_MS_30,
    RLC_T_REASSEMBLY_MS_35,
    RLC_T_REASSEMBLY_MS_40,
    RLC_T_REASSEMBLY_MS_45,
    RLC_T_REASSEMBLY_MS_50,
    RLC_T_REASSEMBLY_MS_55,
    RLC_T_REASSEMBLY_MS_60,
    RLC_T_REASSEMBLY_MS_65,
    RLC_T_REASSEMBLY_MS_70,
    RLC_T_REASSEMBLY_MS_75,
    RLC_T_REASSEMBLY_MS_80,
    RLC_T_REASSEMBLY_MS_85,
    RLC_T_REASSEMBLY_MS_90,
    RLC_T_REASSEMBLY_MS_95,
    RLC_T_REASSEMBLY_MS_100,
    RLC_T_REASSEMBLY_MS_110,
    RLC_T_REASSEMBLY_MS_120,
    RLC_T_REASSEMBLY_MS_130,
    RLC_T_REASSEMBLY_MS_140,
    RLC_T_REASSEMBLY_MS_150,
    RLC_T_REASSEMBLY_MS_160,
    RLC_T_REASSEMBLY_MS_170,
    RLC_T_REASSEMBLY_MS_180,
    RLC_T_REASSEMBLY_MS_190,
    RLC_T_REASSEMBLY_MS_200
} rlc_t_reassembly_et;


/* Enum defining the possible value of Status
 * prohibit timer */
typedef enum
{
    RLC_T_STATUS_PROHB_MS_0,
    RLC_T_STATUS_PROHB_MS_5,
    RLC_T_STATUS_PROHB_MS_10,
    RLC_T_STATUS_PROHB_MS_15,
    RLC_T_STATUS_PROHB_MS_20,
    RLC_T_STATUS_PROHB_MS_25,
    RLC_T_STATUS_PROHB_MS_30,
    RLC_T_STATUS_PROHB_MS_35,
    RLC_T_STATUS_PROHB_MS_40,
    RLC_T_STATUS_PROHB_MS_45,
    RLC_T_STATUS_PROHB_MS_50,
    RLC_T_STATUS_PROHB_MS_55,
    RLC_T_STATUS_PROHB_MS_60,
    RLC_T_STATUS_PROHB_MS_65,
    RLC_T_STATUS_PROHB_MS_70,
    RLC_T_STATUS_PROHB_MS_75,
    RLC_T_STATUS_PROHB_MS_80,
    RLC_T_STATUS_PROHB_MS_85,
    RLC_T_STATUS_PROHB_MS_90,
    RLC_T_STATUS_PROHB_MS_95,
    RLC_T_STATUS_PROHB_MS_100,
    RLC_T_STATUS_PROHB_MS_105,
    RLC_T_STATUS_PROHB_MS_110,
    RLC_T_STATUS_PROHB_MS_115,
    RLC_T_STATUS_PROHB_MS_120,
    RLC_T_STATUS_PROHB_MS_125,
    RLC_T_STATUS_PROHB_MS_130,
    RLC_T_STATUS_PROHB_MS_135,
    RLC_T_STATUS_PROHB_MS_140,
    RLC_T_STATUS_PROHB_MS_145,
    RLC_T_STATUS_PROHB_MS_150,
    RLC_T_STATUS_PROHB_MS_155,
    RLC_T_STATUS_PROHB_MS_160,
    RLC_T_STATUS_PROHB_MS_165,
    RLC_T_STATUS_PROHB_MS_170,
    RLC_T_STATUS_PROHB_MS_175,
    RLC_T_STATUS_PROHB_MS_180,
    RLC_T_STATUS_PROHB_MS_185,
    RLC_T_STATUS_PROHB_MS_190,
    RLC_T_STATUS_PROHB_MS_195,
    RLC_T_STATUS_PROHB_MS_200,
    RLC_T_STATUS_PROHB_MS_205,
    RLC_T_STATUS_PROHB_MS_210,
    RLC_T_STATUS_PROHB_MS_215,
    RLC_T_STATUS_PROHB_MS_220,
    RLC_T_STATUS_PROHB_MS_225,
    RLC_T_STATUS_PROHB_MS_230,
    RLC_T_STATUS_PROHB_MS_235,
    RLC_T_STATUS_PROHB_MS_240,
    RLC_T_STATUS_PROHB_MS_245,
    RLC_T_STATUS_PROHB_MS_250,
    RLC_T_STATUS_PROHB_MS_300,
    RLC_T_STATUS_PROHB_MS_350,
    RLC_T_STATUS_PROHB_MS_400,
    RLC_T_STATUS_PROHB_MS_450,
    RLC_T_STATUS_PROHB_MS_500,
    RLC_T_STATUS_PROHB_MS_800,
    RLC_T_STATUS_PROHB_MS_1000,
    RLC_T_STATUS_PROHB_MS_1200,
    RLC_T_STATUS_PROHB_MS_1600,
    RLC_T_STATUS_PROHB_MS_2000,
    RLC_T_STATUS_PROHB_MS_2400
} rlc_t_status_prohibit_et;


/* Enum defining the possible value of Poll 
 * re-transmit timer */
typedef enum
{
    RLC_POLL_RETRAS_MS_5,
    RLC_POLL_RETRAS_MS_10,
    RLC_POLL_RETRAS_MS_15,
    RLC_POLL_RETRAS_MS_20,
    RLC_POLL_RETRAS_MS_25,
    RLC_POLL_RETRAS_MS_30,
    RLC_POLL_RETRAS_MS_35,
    RLC_POLL_RETRAS_MS_40,
    RLC_POLL_RETRAS_MS_45,
    RLC_POLL_RETRAS_MS_50,
    RLC_POLL_RETRAS_MS_55,
    RLC_POLL_RETRAS_MS_60,
    RLC_POLL_RETRAS_MS_65,
    RLC_POLL_RETRAS_MS_70,
    RLC_POLL_RETRAS_MS_75,
    RLC_POLL_RETRAS_MS_80,
    RLC_POLL_RETRAS_MS_85,
    RLC_POLL_RETRAS_MS_90,
    RLC_POLL_RETRAS_MS_95,
    RLC_POLL_RETRAS_MS_100,
    RLC_POLL_RETRAS_MS_105,
    RLC_POLL_RETRAS_MS_110,
    RLC_POLL_RETRAS_MS_115,
    RLC_POLL_RETRAS_MS_120,
    RLC_POLL_RETRAS_MS_125,
    RLC_POLL_RETRAS_MS_130,
    RLC_POLL_RETRAS_MS_135,
    RLC_POLL_RETRAS_MS_140,
    RLC_POLL_RETRAS_MS_145,
    RLC_POLL_RETRAS_MS_150,
    RLC_POLL_RETRAS_MS_155,
    RLC_POLL_RETRAS_MS_160,
    RLC_POLL_RETRAS_MS_165,
    RLC_POLL_RETRAS_MS_170,
    RLC_POLL_RETRAS_MS_175,
    RLC_POLL_RETRAS_MS_180,
    RLC_POLL_RETRAS_MS_185,
    RLC_POLL_RETRAS_MS_190,
    RLC_POLL_RETRAS_MS_195,
    RLC_POLL_RETRAS_MS_200,
    RLC_POLL_RETRAS_MS_205,
    RLC_POLL_RETRAS_MS_210,
    RLC_POLL_RETRAS_MS_215,
    RLC_POLL_RETRAS_MS_220,
    RLC_POLL_RETRAS_MS_225,
    RLC_POLL_RETRAS_MS_230,
    RLC_POLL_RETRAS_MS_235,
    RLC_POLL_RETRAS_MS_240,
    RLC_POLL_RETRAS_MS_245,
    RLC_POLL_RETRAS_MS_250,
    RLC_POLL_RETRAS_MS_300,
    RLC_POLL_RETRAS_MS_350,
    RLC_POLL_RETRAS_MS_400,
    RLC_POLL_RETRAS_MS_450,
    RLC_POLL_RETRAS_MS_500,
    RLC_POLL_RETRAS_MS_800,
    RLC_POLL_RETRAS_MS_1000,
    RLC_POLL_RETRAS_MS_2000,
    RLC_POLL_RETRAS_MS_4000
} rlc_t_poll_retransmit_et;


/* Enum defining the possible value of Poll PDU */
typedef enum
{
    RLC_POLL_PDU_4,
    RLC_POLL_PDU_8,
    RLC_POLL_PDU_16,
    RLC_POLL_PDU_32,
    RLC_POLL_PDU_64,
    RLC_POLL_PDU_128,
    RLC_POLL_PDU_256,
    RLC_POLL_PDU_512,
    RLC_POLL_PDU_1024,
    RLC_POLL_PDU_2048,
    RLC_POLL_PDU_4096,
    RLC_POLL_PDU_6144,
    RLC_POLL_PDU_8192,
    RLC_POLL_PDU_12288,
    RLC_POLL_PDU_16384,
    RLC_POLL_PDU_20480,
    RLC_POLL_PDU_24576,
    RLC_POLL_PDU_28672,
    RLC_POLL_PDU_32768,
    RLC_POLL_PDU_40960,
    RLC_POLL_PDU_49152,
    RLC_POLL_PDU_57344,
    RLC_POLL_PDU_65536,
    RLC_POLL_PDU_INFINITY
} rlc_poll_pdu_et;


/* Enum defining the possible value of Max allowed
 * Re-transmissions for a PDU */ 
typedef enum
{
    RLC_MAX_RETRANS_THRESH_1,
    RLC_MAX_RETRANS_THRESH_2,
    RLC_MAX_RETRANS_THRESH_3,
    RLC_MAX_RETRANS_THRESH_4,
    RLC_MAX_RETRANS_THRESH_6,
    RLC_MAX_RETRANS_THRESH_8,
    RLC_MAX_RETRANS_THRESH_16,
    RLC_MAX_RETRANS_THRESH_32
} rlc_max_retx_threshold_et;


/* Enum defining the possible value of Max allowed
 * Re-transmissions for a PDU */ 
typedef enum
{
    RLC_POLL_BYTE_KB_1,
    RLC_POLL_BYTE_KB_2,
    RLC_POLL_BYTE_KB_5,
    RLC_POLL_BYTE_KB_8,
    RLC_POLL_BYTE_KB_10,
    RLC_POLL_BYTE_KB_15,
    RLC_POLL_BYTE_KB_25,
    RLC_POLL_BYTE_KB_50,
    RLC_POLL_BYTE_KB_75,
    RLC_POLL_BYTE_KB_100,
    RLC_POLL_BYTE_KB_125,
    RLC_POLL_BYTE_KB_250,
    RLC_POLL_BYTE_KB_375,
    RLC_POLL_BYTE_KB_500,
    RLC_POLL_BYTE_KB_750,
    RLC_POLL_BYTE_KB_1000,
    RLC_POLL_BYTE_KB_1250,
    RLC_POLL_BYTE_KB_1500,
    RLC_POLL_BYTE_KB_2000,
    RLC_POLL_BYTE_KB_3000,
    RLC_POLL_BYTE_KB_4000,
    RLC_POLL_BYTE_KB_4500,
    RLC_POLL_BYTE_KB_5000,
    RLC_POLL_BYTE_KB_5500,
    RLC_POLL_BYTE_KB_6000,
    RLC_POLL_BYTE_KB_6500,
    RLC_POLL_BYTE_KB_7000,
    RLC_POLL_BYTE_KB_7500,
    RLC_POLL_BYTE_MB_8,
    RLC_POLL_BYTE_MB_9,
    RLC_POLL_BYTE_MB_10,
    RLC_POLL_BYTE_MB_11,
    RLC_POLL_BYTE_MB_12,
    RLC_POLL_BYTE_MB_13,
    RLC_POLL_BYTE_MB_14,
    RLC_POLL_BYTE_MB_15,
    RLC_POLL_BYTE_MB_16,
    RLC_POLL_BYTE_MB_17,
    RLC_POLL_BYTE_MB_18,
    RLC_POLL_BYTE_MB_20,
    RLC_POLL_BYTE_MB_25,
    RLC_POLL_BYTE_MB_30,
    RLC_POLL_BYTE_MB_40,
    RLC_POLL_BYTE_INFINITY
} rlc_poll_byte_et;


/* RLC UL Configuration for AM logical channel */
typedef struct 
{
    /* RLC Sequence number length (rlc_am_sn_field_length_et) */
    unsigned char   sn_field_length;

    /* Re-transmit timer (rlc_t_poll_retransmit_et) */
    unsigned char   t_poll_retransmit;

    /* Number of PDUs after which peer entity has to 
     * set poll bit in AMD PDU (rlc_poll_pdu_et) */
    unsigned char   poll_pdu;

    /* Number of bytes after which peer entity has to 
     * set poll bit in AMD PDU (rlc_poll_byte_et) */
    unsigned char   poll_byte;

    /* Max number of times peer RLC entity shall 
     * re-transmit a RLC PDU before indicating failure 
     * to higher layer (rlc_max_retx_threshold_et) */
    unsigned char   max_retx_threshold;

} rlc_am_ul_config_t;


/* RLC DL Configuration for AM logical channel */
typedef struct 
{
    /* RLC Sequence number length (rlc_um_sn_field_length_et) */
    unsigned char   sn_field_length;

    /* Re-assembly timer (rlc_t_reassembly_et) */
    unsigned char   t_re_assembly;

    /* Status prohibit timer (rlc_t_status_prohibit_et) */
    unsigned char   t_status_prohibit;

} rlc_am_dl_config_t;


/* RLC Configurations(DL/UL) for AM logical channel */
typedef struct rlc_am_config_t
{
    /* RLC UL Configuration */
    rlc_am_ul_config_t   ul_config;

    /* RLC DL Configuration */
    rlc_am_dl_config_t   dl_config;

} rlc_am_config_t;


/* DL Configuration for uni-directional UM logical channel */
typedef struct rlc_um_dl_config_t
{
    /* RLC Sequence number length (rlc_um_sn_field_length_et) */
    unsigned char   sn_field_length;

    /* Re-assembly timer (rlc_t_reassembly_et) */
    unsigned char   t_re_assembly;

} rlc_um_dl_config_t;


/* UL Configuration for uni-directional UM logical channel */
typedef struct rlc_um_ul_config_t
{
    /* RLC Sequence number length (rlc_um_sn_field_length_et) */
    unsigned char   sn_field_length;

} rlc_um_ul_config_t;


/* DL Configuration for uni-directional UM Logical channel */
typedef struct rlc_um_uni_directional_dl_config_t
{
    /* RLC UM DL Configuration */
    rlc_um_dl_config_t   dl_config;

} rlc_um_uni_directional_dl_config_t;


/* UL Configuration for uni-directional UM Logical channel */
typedef struct rlc_um_uni_directional_ul_config_t
{
    /* RLC UM UL Configuration */
    rlc_um_ul_config_t   ul_config;

} rlc_um_uni_directional_ul_config_t;


/* DL/UL Configurations for bi-directional UM Logical channel */
typedef struct rlc_um_bi_directional_config_t
{
    /* RLC UL Configuration for UM logical channel */
    rlc_um_ul_config_t   ul_config;

    /* RLC DL Configuration for UM logical channel */
    rlc_um_dl_config_t   dl_config;

} rlc_um_bi_directional_config_t;


/* RLC configuration for a logical channel */
typedef struct rlc_lc_config_t
{
#define RLC_LC_CONFIG_AM_CONFIG_PRESENT                0x01
#define RLC_LC_CONFIG_UM_BIDIRECTIONAL_CONFIG_PRESENT  0x02
#define RLC_LC_CONFIG_UM_DL_CONFIG_PRESENT             0x04
#define RLC_LC_CONFIG_UM_UL_CONFIG_PRESENT             0x08

    unsigned int                        bitmask;

    /* RLC AM Configuration */
    rlc_am_config_t                     am_config;

    /* RLC UM Bi-directional Configuration */
    rlc_um_bi_directional_config_t      um_dl_ul_config;

    /* RLC UM DL Configuration */
    rlc_um_uni_directional_dl_config_t  um_dl_config;

    /* RLC UM UL Configuration */
    rlc_um_uni_directional_ul_config_t  um_ul_config;

} rlc_lc_config_t;


typedef struct 
{
} sub_carrier_spacing_t;


typedef struct 
{
} allowed_timing_t;


typedef struct 
{
#define MAC_UL_CONFIG_SUB_CARRIER_SPACING_PRESENT         0x01
#define MAC_UL_CONFIG_ALLOWED_TIMING_PRESENT              0x02
#define MAC_UL_CONFIG_LC_GROUP_PRESENT                    0x04
#define MAC_UL_CONFIG_LC_SR_DELAYED_TIMER_APPLIED_PRESENT 0x08

    unsigned int           bitmask;

    unsigned char          priority;
    unsigned int           prioritisedBitRate;
    unsigned int           bucketSizeDuration;
    sub_carrier_spacing_t  allowedSubCarrierSpacing;
    allowed_timing_t       allowedTiming;
    unsigned short         lcGroup;
    bool                   logicalChannelSRMask;
    bool                   logicalChannelSRDelayTimerApplied;
} mac_lc_ul_config_t;


/* MAC configuration for a logical channel */
typedef struct mac_lc_config_t
{
    /* MAC UL configuration */
    mac_lc_ul_config_t     ulConfig;

} mac_lc_config_t;


/* Configuration of logical channel */
typedef struct rlc_bearer_to_add_mod_t
{
#define BEARER_TO_ADD_MOD_DRBID_PRESENT            0x01
#define BEARER_TO_ADD_MOD_RE_ESTABLISH_RLC_PRESENT 0x02
#define BEARER_TO_ADD_MOD_RLC_CONFIG_PRESENT       0x04
#define BEARER_TO_ADD_MOD_MAC_CONFIG_PRESENT       0x08

    unsigned int     bitmask;

    /* Logical Channel Identifier */
    unsigned int     lcId;

    /* Radio bearer Identifier */
    unsigned int     drbId;

    /* Flag to indicate if RLC need to be 
     * re-established */
    bool             reestablishRLC;

    /* RLC Configuration */
    rlc_lc_config_t  rlcConfig;

    /* MAC Configuration */
    mac_lc_config_t  macConfig;

} rlc_bearer_to_add_mod_t;


typedef struct rlc_bearer_to_addMod_list_t
{
    /* Count of logical channels present in the list */
    unsigned int             count;

    /* Configuration of each logical channel */
    rlc_bearer_to_add_mod_t  lchConfig[MAX_LOGICAL_CHANNEL];

} rlc_bearer_to_addMod_list_t;


typedef struct
{
    /* Logical Channel Identifier */
    unsigned int   lcId;
} rlc_bearer_to_release_t;


typedef struct 
{
    /* Count of logical channels present in the list */
    unsigned int             count;

    /* Identifier of each logical channel */
    rlc_bearer_to_release_t  lchID[MAX_LOGICAL_CHANNEL];

} rlc_bearer_to_release_list_t;


/* Structure defining the content of RLF timers and 
 * constants */
typedef struct 
{
} rlf_timers_and_constants_t;


/* Structure defining the content of PHY Cell 
 * Group Config. */
typedef struct 
{
#define PHY_CELL_GROUP_CONFIG_HARQ_ACK_SPATIAL_BUNDLING_PRESENT 0x01

    unsigned int  bitmask;

    /* Flag to indicate if spatial bundling of HARQ ACKs
     * is enabled or not. */
    bool          harq_ack_spatial_bundling;

} phy_cell_group_config_t;


typedef struct
{
     
} spCell_config_t;


typedef enum
{
    LC_PERIODIC_BSR_TIMER_SF_1,
    LC_PERIODIC_BSR_TIMER_SF_5,
    LC_PERIODIC_BSR_TIMER_SF_10,
    LC_PERIODIC_BSR_TIMER_SF_16,
    LC_PERIODIC_BSR_TIMER_SF_20,
    LC_PERIODIC_BSR_TIMER_SF_32,
    LC_PERIODIC_BSR_TIMER_SF_40,
    LC_PERIODIC_BSR_TIMER_SF_64,
    LC_PERIODIC_BSR_TIMER_SF_80,
    LC_PERIODIC_BSR_TIMER_SF_128,
    LC_PERIODIC_BSR_TIMER_SF_160,
    LC_PERIODIC_BSR_TIMER_SF_320,
    LC_PERIODIC_BSR_TIMER_SF_640,
    LC_PERIODIC_BSR_TIMER_SF_1280,
    LC_PERIODIC_BSR_TIMER_SF_2560,
    LC_PERIODIC_BSR_TIMER_INFINITY,
} periodic_bsr_timer_et;


typedef enum
{
    LC_RETX_BSR_TIMER_SF_10,
    LC_RETX_BSR_TIMER_SF_20,
    LC_RETX_BSR_TIMER_SF_40,
    LC_RETX_BSR_TIMER_SF_80,
    LC_RETX_BSR_TIMER_SF_160,
    LC_RETX_BSR_TIMER_SF_320,
    LC_RETX_BSR_TIMER_SF_640,
    LC_RETX_BSR_TIMER_SF_1280,
    LC_RETX_BSR_TIMER_SF_2560,
    LC_RETX_BSR_TIMER_SF_5120,
    LC_RETX_BSR_TIMER_SF_10240,
} retx_bsr_timer_et;


typedef enum
{
    LC_SR_DELAY_TIMER_SF_20,
    LC_SR_DELAY_TIMER_SF_40,
    LC_SR_DELAY_TIMER_SF_64,
    LC_SR_DELAY_TIMER_SF_128,
    LC_SR_DELAY_TIMER_SF_512,
    LC_SR_DELAY_TIMER_SF_1024,
    LC_SR_DELAY_TIMER_SF_2560,
} logical_channel_sr_delay_timer_et;


typedef struct
{
    /* Periodic BSR timer (periodic_bsr_timer_et) */
    unsigned int  periodicBSRTimer;

    /* Re-transmit BSR timer (retx_bsr_timer_et) */
    unsigned int  retxBSRTimer;

    /* Logical Channel SR Delay timer 
     * (logical_channel_sr_delay_timer_et) */
    unsigned int  logicalChannelSRDelayTimer;

} bsr_config_t;


typedef enum
{
    PHR_PERIODIC_TIMER_SF_10,
    PHR_PERIODIC_TIMER_SF_20,
    PHR_PERIODIC_TIMER_SF_50,
    PHR_PERIODIC_TIMER_SF_100,
    PHR_PERIODIC_TIMER_SF_200,
    PHR_PERIODIC_TIMER_SF_500,
    PHR_PERIODIC_TIMER_SF_1000,
    PHR_PERIODIC_TIMER_INFINITY,
} phr_periodic_timer_et;


typedef enum
{
    PHR_PROHIBIT_TIMER_SF_0,
    PHR_PROHIBIT_TIMER_SF_10,
    PHR_PROHIBIT_TIMER_SF_20,
    PHR_PROHIBIT_TIMER_SF_50,
    PHR_PROHIBIT_TIMER_SF_100,
    PHR_PROHIBIT_TIMER_SF_200,
    PHR_PROHIBIT_TIMER_SF_500,
    PHR_PROHIBIT_TIMER_SF_1000
} phr_prohibit_timer_et;


typedef enum
{
    PHR_TX_POWER_FACTOR_DB_1,
    PHR_TX_POWER_FACTOR_DB_3,
    PHR_TX_POWER_FACTOR_DB_6,
    PHR_TX_POWER_FACTOR_INFINITY,
} phr_tx_power_factor_change_et;


typedef enum
{
    PHR_MODE_REAL,
    PHR_MODE_VIRTUAL
} phr_mode_otherCG_et;


typedef struct
{
    /* Periodic PHR timer (phr_periodic_timer_et) */
    unsigned int  phr_periodic_timer;

    /* PHR Prohibit timer (phr_prohibit_timer_et) */
    unsigned int  phr_prohibit_timer;

    /* PHR Tx Power change factor (phr_tx_power_factor_change_et) */
    unsigned int  phr_tx_power_factor_change;

    /* Flag to indicate if power headroom shall be reported using
     * multiple PHR MAC control element */
    unsigned char multiple_phr_enabled;

    /* Flag to indicate whether to report PHR type2 for PCell */
    unsigned char phr_type2_pcell;

    /* Flag to indicate whether to report PHR type2 for PSCell 
     * and PUCCH sCells */
    unsigned char phr_type2_other_cell;

    /* PHR Mode for other CG (phr_mode_otherCG_et) */
    unsigned int  phr_mode_otherCG;

} phr_config_setup_t;


typedef struct
{
#define PHR_CONFIG_SETUP_PRESENT     0x01
#define PHR_CONFIG_RELEASE_PRESENT   0x02

    unsigned int        bitmask;

    /* PHR Configuration to be Setup */
    phr_config_setup_t  phr_setup;

} phr_config_t;


/* Enum defining the possible values of sCells deactivation timer */
typedef enum
{
    SCELL_DEACTIVATION_TIMER_MS_20,
    SCELL_DEACTIVATION_TIMER_MS_40,
    SCELL_DEACTIVATION_TIMER_MS_80,
    SCELL_DEACTIVATION_TIMER_MS_160,
    SCELL_DEACTIVATION_TIMER_MS_200,
    SCELL_DEACTIVATION_TIMER_MS_240,
    SCELL_DEACTIVATION_TIMER_MS_320,
    SCELL_DEACTIVATION_TIMER_MS_400,
    SCELL_DEACTIVATION_TIMER_MS_480,
    SCELL_DEACTIVATION_TIMER_MS_520,
    SCELL_DEACTIVATION_TIMER_MS_640,
    SCELL_DEACTIVATION_TIMER_MS_720,
    SCELL_DEACTIVATION_TIMER_MS_840,
    SCELL_DEACTIVATION_TIMER_MS_1280,
} scell_deactivation_timer_et;


/* Enum defining the possible values of time alignment timer */
typedef enum
{
    TIME_ALIGNMENT_TIMER_MS_500,
    TIME_ALIGNMENT_TIMER_MS_750,
    TIME_ALIGNMENT_TIMER_MS_1280,
    TIME_ALIGNMENT_TIMER_MS_1920,
    TIME_ALIGNMENT_TIMER_MS_2560,
    TIME_ALIGNMENT_TIMER_MS_5120,
    TIME_ALIGNMENT_TIMER_MS_10240,
    TIME_ALIGNMENT_TIMER_INFINITY,
} ta_time_alignment_timer_et;


/* Structure defining content of Timing Advance Group */
typedef struct
{
    /* Timing Advance Group ID */
    unsigned int  tagId;

    /* Time alignment timer (ta_time_alignment_timer_et) */
    unsigned int  timeAlignmentTimer;

} tag_to_add_mod_t;


/* List of TAGs to be added/modified */
typedef struct
{
    /* Count of elements in the list */
    unsigned int      count;

    /* TAG configuration of each TAG */
    tag_to_add_mod_t  tagToAddMod[MAX_NUM_TAG];

} tag_to_add_mod_list_t;


typedef struct
{
    /* Timing Advance Group ID */
    unsigned int  tagId;

} tag_to_release_t;


/* List of TAGs to be released */
typedef struct 
{
    /* Count of elements in the list */
    unsigned int      count;

    /* TAG Identifier of each TAG */
    tag_to_release_t  tagToRelease[MAX_NUM_TAG];

} tag_to_release_list_t;


/* Structure defining the content of Timing Advance Group 
 * configuration */
typedef struct 
{
    /* Timing Advance Group to add/mod list */
    tag_to_add_mod_list_t   tagToAddModList;

    /* Timing Advance Group to release list */
    tag_to_release_list_t   tagToReleaseList;

} tag_config_t;


/* Enum defining the possible values of SR 
 * Prohibit timer */
typedef enum
{
    SR_PROHIBIT_TIMER_MS_1,
    SR_PROHIBIT_TIMER_MS_2,
    SR_PROHIBIT_TIMER_MS_4,
    SR_PROHIBIT_TIMER_MS_8,
    SR_PROHIBIT_TIMER_MS_16,
    SR_PROHIBIT_TIMER_MS_32,
    SR_PROHIBIT_TIMER_MS_64,
    SR_PROHIBIT_TIMER_MS_128,
} sr_prohibit_timer_et;


/* Enum defining the possible values of SR max 
 * transmissions counter */
typedef enum
{
    SR_TRANS_MAX_N4,
    SR_TRANS_MAX_N8,
    SR_TRANS_MAX_N16,
    SR_TRANS_MAX_N32,
    SR_TRANS_MAX_N64
} sr_trans_max_et;


typedef struct
{
    /* Scheduling Request Identifier */
    /* TODO: Data type is not defined in the specs */
    unsigned int  schedReqId;

    /* Timer for SR transmission on PUCCH (sr_prohibit_timer_et) */
    unsigned int  srProhibitTimer;

    /* Max SR transmission (sr_trans_max_et) */ 
    unsigned int  srTransMax;

} scheduling_req_to_add_mod_t;


/* Scheduling Request to add/mod list */
typedef struct
{
    /* Count of elements in the list */
    unsigned int   count;

    /* Scheduling request configuration */
    scheduling_req_to_add_mod_t  
                   schedReqToAddMod[MAX_SR_CONFIG_PER_CELL_GROUP];

} scheduling_req_to_addMod_list_t;


typedef struct 
{
    /* Scheduling Request Identifier */
    /* TODO: Data type not defined in specs */
    unsigned int  schedReqId;

} scheduling_req_to_release_t;


/* Scheduling Request to Release List */
typedef struct
{
    /* Count of elements in the list */
    unsigned int   count;

    /* Scheduling request identifier */
    scheduling_req_to_release_t  
                   schedReqToRelease[MAX_SR_CONFIG_PER_CELL_GROUP];

} scheduling_req_to_release_list_t;


/* Structure defining the content of scheduling request configuration */
typedef struct
{
    /* Scheduling Request to add/mod list */
    scheduling_req_to_addMod_list_t   schedReqToAddModList;

    /* Scheduling Request to release list */
    scheduling_req_to_release_list_t  schedReqToReleaseList;

} scheduling_request_config_t;


/* Structure defining the content of MAC Cell Group Config */
typedef struct 
{
#define MAC_CELL_GROUP_CONFIG_SCHED_REQ_CONFIG_PRESENT          0x01
#define MAC_CELL_GROUP_CONFIG_BSR_CONFIG_PRESENT                0x02
#define MAC_CELL_GROUP_CONFIG_TAG_CONFIG_PRESENT                0x04
#define MAC_CELL_GROUP_CONFIG_PHR_CONFIG_PRESENT                0x08
#define MAC_CELL_GROUP_CONFIG_SCELL_DEACTIVATION_TIMER_PRESENT  0x10

    unsigned int                  bitmask;

    /* Scheduling Request Configuration */
    scheduling_request_config_t   schedulingRequestConfig;

    /* Buffer Status Reporting configuration */
    bsr_config_t                  bsrConfig;

    /* Timing Advanced Group Configuration */
    tag_config_t                  tagConfig;

    /* Power Headroom Reporting configuration */
    phr_config_t                  phrConfig;

    /* SCell De-activation timer (scell_deactivation_timer_et) */
    unsigned int                  scellDeactivationTimer;

    /* Indicates whether if configured, the UE skips UL transmissions 
     * for an uplink grant other than a configured uplink grant if no 
     * data is available for transmission in the UE buffer */
    unsigned char                 skipULTxDynamic;

} mac_cell_group_config_t;


typedef struct
{
    unsigned char    scell_index;
} scell_to_release_t;


/* List of scells to be released */
typedef struct 
{
    /* Count of cells present in the list */
    unsigned int        count;

    /* Identifier of each cell */
    scell_to_release_t  scellToRelease;

} scell_to_release_list_t;


/* Configuration of a sCell */
typedef struct 
{
    unsigned char             scell_index;

    //scell_config_common_t     scellConfigCommon;

    //scell_config_dedicated_t  scellConfigDedicated;

} scell_to_add_mod_t;


/* Structure defining the content of scell to add/mod list */
typedef struct 
{
    /* Count of cells present in the list */
    unsigned int        count;

    /* Configuration of each sCell */
    scell_to_add_mod_t  scellToAddMod[MAX_SCELL_PER_UE];

} scell_to_add_mod_list_t;


/* Structure defining the content of CellGroupConfig */
typedef struct _f1ap_CellGroupConfig 
{
#define CELL_GROUP_CONFIG_BEARER_ADD_MOD_LIST_PRESENT       0x01
#define CELL_GROUP_CONFIG_BEARER_RELEASE_LIST_PRESENT       0x02
#define CELL_GROUP_CONFIG_MAC_CELL_GROUP_CONFIG_PRESENT     0x04
#define CELL_GROUP_CONFIG_RLF_TIMERS_AND_CONSTANTS_PRESENT  0x08
#define CELL_GROUP_CONFIG_PHY_CELL_GROUP_CONFIG_PRESENT     0x10
#define CELL_GROUP_CONFIG_SPCELL_CONFIG_PRESENT             0x20
#define CELL_GROUP_CONFIG_SCELL_TO_ADD_MOD_LIST_PRESENT     0x40
#define CELL_GROUP_CONFIG_SCELL_TO_RELEASE_LIST_PRESENT     0x80

    unsigned int                  bitmask;

    /* Cell Group ID */
    unsigned int                  cellGroupId;

    /* Bearer to add/mod list */
    rlc_bearer_to_addMod_list_t   bearerAddModList;

    /* Bearer to release list */
    rlc_bearer_to_release_list_t  bearerReleaseList;

    /* MAC Cell Group Config */
    mac_cell_group_config_t       macCellGroupConfig;

    /* RLF Timers and Constants */
    rlf_timers_and_constants_t    rlfTimersAndConstants;

    /* PHY Cell Group Config */
    phy_cell_group_config_t       phyCellGroupConfig;

    /* Special Cell Config */
    spCell_config_t               spCellConfig;

    /* sCells to add/mod list */
    scell_to_add_mod_list_t       sCellToAddModList;

    /* sCell to release list */
    scell_to_release_list_t       sCellToReleaseList;

} _f1ap_CellGroupConfig;


/* Structure defining the content of Resource coordination 
 * transfer container */
typedef struct _f1ap_ResourceCoordinationTransferContainer
{
    /* Length of container */
    unsigned int   containerLength;

    /* Data buffer of container */
    unsigned char  containerData[RES_COORDINATION_CONTAINER_BUF_LEN];

} _f1ap_ResourceCoordinationTransferContainer;


/* Structure defining the content of CU to DU RRC container */ 
typedef struct _f1ap_CUtoDURRCInformation
{
#define CU_TO_DU_CONTAINER_SCG_CONFIG_INFO_PRESENT   0x01

    unsigned int  bitmask;

    /* UE Radio capability buffer length */
    unsigned int  ueCapabilityBufferLen;

    /* UE Radio capability buffer */
    unsigned char ueCapabilityBuffer[MAX_UE_CAPABILITY_BUFFER_LEN];

    /* SCG Config Info container length */
    unsigned int  scgConfigInfoBufferLen;

    /* SCG Config Info container buffer */
    unsigned char scgConfigInfoBuffer[MAX_SCG_CONFIG_INFO_BUFFER_LEN];

} _f1ap_CUtoDURRCInformation;


/* Structure defining the content of DU to CU container */
typedef struct _f1ap_DUtoCURRCInformation
{
    /* Cell Group Config buffer length */
    unsigned int  cellGroupConfigBufLen;

    /* Cell Group Config buffer */
    unsigned char cellGroupConfigBuf[DU_TO_CU_CONTAINER_LENGTH];

} _f1ap_DUtoCURRCInformation;


typedef struct _f1ap_DRXCycle 
{
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_LEN_PRESENT    0x01
#define F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_TIMER_PRESENT  0x02

    unsigned int   bitmask;

    unsigned int   longDRXCycleLength;
    unsigned int   shortDRXCycleLength;
    unsigned char  shortDRXCycleTimer;

} _f1ap_DRXCycle;


typedef struct _f1ap_SCell_ToBeSetup_List_element 
{
    /* SCell-ID */
    _f1ap_NCGI     cgi;

} _f1ap_SCell_ToBeSetup_List_element;


typedef struct _f1ap_SCell_ToBeSetup_List
{
    unsigned int   count;
    _f1ap_SCell_ToBeSetup_List_element  
                   scell_toBe_setup[MAX_CELL_PER_DU];
} _f1ap_SCell_ToBeSetup_List;


typedef struct _f1ap_SRBs_ToBeSetup_List_element 
{
    /* SRBID */
    unsigned int     srb_id;

} _f1ap_SRBs_ToBeSetup_List_element;


typedef struct _f1ap_SRBs_ToBeSetup_List
{
    unsigned int     count;

    _f1ap_SRBs_ToBeSetup_List_element  
                     srb_toBe_setup[MAX_SRB_PER_UE];

} _f1ap_SRBs_ToBeSetup_List;


typedef struct _f1ap_GTP_TEID 
{
   unsigned int   numocts;
   unsigned char  data[4];
} _f1ap_GTP_TEID;


typedef struct _f1ap_GTPTunnelEndpoint 
{
   unsigned char    transportAddressLength;
   unsigned char    transportLayerAddress[20];
   _f1ap_GTP_TEID   gTP_TEID;
} _f1ap_GTPTunnelEndpoint;


typedef struct _f1ap_ULTunnels_ToBeSetup_list_element 
{
    /* UL-GTP-Tunnel-EndPoint */
    _f1ap_GTPTunnelEndpoint  tunnelEP;

} _f1ap_ULTunnels_ToBeSetup_list_element;


typedef struct _f1ap_ULTunnels_ToBeSetup_list
{
    unsigned int    count;

    _f1ap_ULTunnels_ToBeSetup_list_element  
                    ul_tunnel_toBe_setup[2];

} _f1ap_ULTunnels_ToBeSetup_list;


typedef struct _f1ap_AllocationAndRetentionPriority 
{
   unsigned char priorityLevel;
   unsigned int  pre_emptionCapability;
   unsigned int  pre_emptionVulnerability;
} _f1ap_AllocationAndRetentionPriority;


typedef struct _f1ap_GBR_QosInformation 
{
   unsigned long e_RAB_MaximumBitrateDL;
   unsigned long e_RAB_MaximumBitrateUL;
   unsigned long e_RAB_GuaranteedBitrateDL;
   unsigned long e_RAB_GuaranteedBitrateUL;
} _f1ap_GBR_QosInformation;


typedef struct _f1ap_EUTRANQoS 
{
#define GBR_QOS_INFO_PRESENT   0x01

   unsigned int                          bitmask;

   unsigned char                         qCI;
   _f1ap_AllocationAndRetentionPriority  allocationAndRetentionPriority;
   _f1ap_GBR_QosInformation              gbrQosInformation;
} _f1ap_EUTRANQoS;


typedef struct _f1ap_DRBs_ToBeSetup_List_element 
{
    /* DRB ID */
    unsigned int                    drbId;

    /* EUTRAN QoS */
    _f1ap_EUTRANQoS                 qos;

    /* List of UL Tunnels to be setup */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelList;

} _f1ap_DRBs_ToBeSetup_List_element;


/* List of DRBs to be setup */
typedef struct _f1ap_DRBs_ToBeSetup_List
{
    /* Count of DRBs present in the list */
    unsigned int                       count;

    /* Information of each DRB present in the list */
    _f1ap_DRBs_ToBeSetup_List_element  drb_to_setup_elem[32];

} _f1ap_DRBs_ToBeSetup_List;


typedef struct _f1ap_UEContextSetupRequest 
{
#define UE_CTX_SETUP_REQ_DU_F1AP_ID_PRESENT                             0x01
#define UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT                              0x02
#define UE_CTX_SETUP_REQ_DRX_CYCLE_PRESENT                              0x04
#define UE_CTX_SETUP_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT    0x08

    unsigned int                bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                du_f1ap_id;

    /* PSCell ID */
    _f1ap_NCGI                  pscell_id;

    /* CU to DU RRC Information Container */
    _f1ap_CUtoDURRCInformation  cuToDuContainer;

    /* DRX Configuration */
    _f1ap_DRXCycle              drx_cycle;

    /* Resource Coordination Transfer Container */
    _f1ap_ResourceCoordinationTransferContainer
                                resCoordinationTransferContainer;

    /* List of SCells to be setup */
    _f1ap_SCell_ToBeSetup_List  scellsToBeSetupList;

    /* List of SRBs to be setup */
    _f1ap_SRBs_ToBeSetup_List   srbsToBeSetupList;

    /* List of DRBs to be setup */
    _f1ap_DRBs_ToBeSetup_List   drbsToBeSetupList;

} _f1ap_UEContextSetupRequest;



/****************************************************************************
 *   UE CONTEXT SETUP RESPONSE 
 ***************************************************************************/

typedef struct _f1ap_SRBs_Setup_List_element 
{
    /* SRB ID */
    unsigned int  srb_id;

} _f1ap_SRBs_Setup_List_element;


/* List of SRBs to be setup */
typedef struct  _f1ap_SRBs_Setup_List
{
    /* Count of SRBs present in the list */
    unsigned int                   count;

    /* Identifier of each SRB */
    _f1ap_SRBs_Setup_List_element  srbToSetup[1];

} _f1ap_SRBs_Setup_List;


typedef struct _f1ap_DLTunnels_ToBeSetup_list_element 
{
    /* DL GTP Tunnel EndPoint */
    _f1ap_GTPTunnelEndpoint        gtpTunnelEP;

} _f1ap_DLTunnels_ToBeSetup_list_element;


/* List of DL tunnels */
typedef struct _f1ap_DLTunnels_ToBeSetup_list
{
    /* Count of DL tunnels present in the list */
    unsigned int                            count;

    /* Information of each tunnel present in the list */
    _f1ap_DLTunnels_ToBeSetup_list_element  dlTunnelToSetup[2];

}_f1ap_DLTunnels_ToBeSetup_list;


typedef struct  _f1ap_DRBs_Setup_List_element 
{
    /* DRB ID */
    unsigned int                    drb_id;

    /* List of DL tunnels for this DRB */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsList;

} _f1ap_DRBs_Setup_List_element;


/* List of DRBs which failed to setup */
typedef struct _f1ap_DRBs_Setup_List
{
    /* Count of DRBs present in the list */
    unsigned int                   count;

    /* Information of each DRB present in the list */
    _f1ap_DRBs_Setup_List_element  drbToSetup[32];

}_f1ap_DRBs_Setup_List;


typedef struct _f1ap_SRBs_FailedToBeSetup_List_element 
{
    /* SRB ID */
    unsigned int  srb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_SRBs_FailedToBeSetup_List_element;


/* List of SRBs which failed to setup */
typedef struct  _f1ap_SRBs_FailedToBeSetup_List
{
    /* Count of SRBs present in the list */
    unsigned int     count;

    /* Identifier of the SRB which failed to setup */
    _f1ap_SRBs_FailedToBeSetup_List_element  
                     srbsFailedToSetup[32];

} _f1ap_SRBs_FailedToBeSetup_List;


typedef struct _f1ap_DRBs_FailedToBeSetup_List_element 
{
    /* DRB ID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeSetup_List_element;


/* List of DRBs which failed to setup */
typedef struct _f1ap_DRBs_FailedToBeSetup_List
{
    /* Count of DRBs present in the list */
    unsigned int                             count;

    /* Identifier of the DRB which failed to setup */
    _f1ap_DRBs_FailedToBeSetup_List_element  drbFailedToSetup[32];

} _f1ap_DRBs_FailedToBeSetup_List;


typedef struct _f1ap_UEContextSetupResponse 
{
#define UE_CTX_SETUP_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT   0x01
#define UE_CTX_SETUP_RESP_CRIT_DIAGNOSTICS_PRESENT                      0x02

    unsigned int                     bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                     cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                     du_f1ap_id;

    /* DU to CU RRC Information Container */
    _f1ap_DUtoCURRCInformation       duToCuContainer;

    /* Resource Coordination Transfer Container */
    _f1ap_ResourceCoordinationTransferContainer
                                     resCoordinationContainer;

    /* List of SRBs to be Setup */
    _f1ap_SRBs_Setup_List            srbsSetupList;

    /* List of DRBs to be Setup */
    _f1ap_DRBs_Setup_List            drbsSetupList;

    /* List of SRBs which failed to setup */
    _f1ap_SRBs_FailedToBeSetup_List  srbsFailedToSetupList;

    /* List of DRBs which failed to setup */
    _f1ap_DRBs_FailedToBeSetup_List  drbsFailedToSetupList;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics     criticality_diagnostics;

} _f1ap_UEContextSetupResponse;


/*******************************************************************************
 * UE CONTEXT SETUP FAILURE
 ******************************************************************************/

typedef struct _f1ap_UEContextSetupFailure 
{
#define UE_CTX_SETUP_FAILURE_DU_F1AP_ID_PRESENT          0x01
#define UE_CTX_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT    0x02

    unsigned int                  bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextSetupFailure;



/**************************************************************************
 * UE CONTEXT MODIFICATION REQUEST 
 *************************************************************************/

typedef struct _f1ap_DRBs_ToBeModified_List_element 
{
    /* DRB ID */
    unsigned int                    drb_id;

    /* EUTRAN QoS */
    _f1ap_EUTRANQoS                 qos;

    /* List of UL Tunnels to be setup for this DRB */
    _f1ap_ULTunnels_ToBeSetup_list  ulTunnelsList;

} _f1ap_DRBs_ToBeModified_List_element;


/* List of DRBs to be modified */
typedef struct _f1ap_DRBs_ToBeModified_List
{
    /* Count of DRBs present in the list */
    unsigned int  count;

    /* Configuration of each DRB present in the list */
    _f1ap_DRBs_ToBeModified_List_element
                  drbToBeModifiedList[32];

}_f1ap_DRBs_ToBeModified_List;


typedef struct _f1ap_SRBs_ToBeReleased_List_element 
{
    /* SRB ID  */
    unsigned int   srb_id;

} _f1ap_SRBs_ToBeReleased_List_element;


/* List of SRBs to be released */
typedef struct _f1ap_SRBs_ToBeReleased_List
{
    /* Count of SRBs present in the list */
    unsigned int                            count;

    /* Identifier of the SRBs present in the list */
    _f1ap_SRBs_ToBeReleased_List_element    srbToRelease[1];

}_f1ap_SRBs_ToBeReleased_List;


typedef struct _f1ap_DRBs_ToBeReleased_List_element 
{
    /* DRB ID */
    unsigned int   drb_id;

} _f1ap_DRBs_ToBeReleased_List_element;


/* List of DRBs to be released */
typedef struct _f1ap_DRBs_ToBeReleased_List
{
    /* Count of DRBs present in the list */
    unsigned int                          count;

    /* Identifier of each DRB present in the list */
    _f1ap_DRBs_ToBeReleased_List_element  drbToBeReleased[32];

} _f1ap_DRBs_ToBeReleased_List;


typedef struct _f1ap_UEContextModificationRequest 
{
#define UE_CTX_MOD_REQ_PSCELL_ID_PRESENT                            0x01
#define UE_CTX_MOD_REQ_DRX_CONFIG_PRESENT                           0x02
#define UE_CTX_MOD_REQ_CU_TO_DU_CONTAINER_PRESENT                   0x04
#define UE_CTX_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT          0x08
#define UE_CTX_MOD_REQ_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x10
#define UE_CTX_MOD_REQ_RRC_CONTAINER_PRESENT                        0x20

    unsigned int                  bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                  du_f1ap_id;

    /* PSCell ID */
    _f1ap_NCGI                    pscell_ncgi;

    /* DRX configuration */
    _f1ap_DRXCycle                drx_cycle;

    /* CU to DU RRC Information Container */
    _f1ap_CUtoDURRCInformation    cuToDuContainer;

    /* Transmission Stop Indicator */
    unsigned int                  transmissionStopIndicator;

    /* Resource Coordination Transfer Container */
    _f1ap_ResourceCoordinationTransferContainer
                                  resCoordinationTransferContainer;

    /* RRC Container */
    _f1ap_RRCContainer            rrcContainer;

    /* List of SCells to be setup */
    _f1ap_SCell_ToBeSetup_List    scellToBeSetupList;

    /* List of SRBs to be setup */
    _f1ap_SRBs_ToBeSetup_List     srbsToBeSetupList;

    /* List of SRBs to be released */
    _f1ap_SRBs_ToBeReleased_List  srbsToBeReleasedList;

    /* List of DRBs to be setup */
    _f1ap_DRBs_ToBeSetup_List     drbsToBeSetupList;

    /* List of DRBs to be modified */
    _f1ap_DRBs_ToBeModified_List  drbsToBeModifiedList;

    /* List of DRBs to be released */
    _f1ap_DRBs_ToBeReleased_List  drbsToBeReleasedList;

} _f1ap_UEContextModificationRequest;



/**************************************************************************
 * UE CONTEXT MODIFICATION RESPONSE
 *************************************************************************/

typedef struct _f1ap_DRBs_Modified_List_element 
{
    /* DRB ID */
    unsigned int                    drb_id;

    /* List of DL tunnels to be setup for this DRB */
    _f1ap_DLTunnels_ToBeSetup_list  dlTunnelsToBeSetupList;

} _f1ap_DRBs_Modified_List_element;


/* List of DRBs which are to be modified */
typedef struct _f1ap_DRBs_Modified_List
{
    /* Count of DRBs present in the list */
    unsigned int                      count;

    /* Configuration of DRBs present in the list */
    _f1ap_DRBs_Modified_List_element  drbModified[32];

} _f1ap_DRBs_Modified_List;


typedef struct _f1ap_DRBs_FailedToBeModified_List_element 
{
    /* DRBID */
    unsigned int  drb_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_DRBs_FailedToBeModified_List_element;


/* List of DRBs which failed to modified */
typedef struct _f1ap_DRBs_FailedToBeModified_List
{
    /* Count of DRBs present in the list */
    unsigned int  count;

    /* Result of DRBs present in the list */
    _f1ap_DRBs_FailedToBeModified_List_element  
                  drbFailedToBeModifiedList[32];

} _f1ap_DRBs_FailedToBeModified_List;


typedef struct _f1ap_UEContextModificationResponse 
{
#define UE_CTX_MOD_RESP_RES_COORDINATION_TRANSFER_CONTAINER_PRESENT  0x01 
#define UE_CTX_MOD_RESP_DU_TO_CU_CONTAINER_PRESENT                   0x02
#define UE_CTX_MOD_RESP_CRIT_DIAG_PRESENT                            0x04

    unsigned int                       bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                       cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                       du_f1ap_id;

    /* Resource Coordination Transfer Container */
    _f1ap_ResourceCoordinationTransferContainer
                                       resCoordinationTransferContainer;

    /* DU to CU RRC Information Container */
    _f1ap_DUtoCURRCInformation         duToCuContainer;

    /* List of DRBs for which setup is successful */
    _f1ap_DRBs_Setup_List              drbSetupList;

    /* List of DRBs for which modification is successful */
    _f1ap_DRBs_Modified_List           drbModifiedList;

    /* List of SRBs for which setup failed */
    _f1ap_SRBs_FailedToBeSetup_List    srbsFailedToSetupList;

    /* List of DRBs for which setup failed */
    _f1ap_DRBs_FailedToBeSetup_List    drbsFailedToSetupList;

    /* List of DRBs for which modification failed */
    _f1ap_DRBs_FailedToBeModified_List drbsFailedToModifiedList;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics       criticality_diagnostics;

} _f1ap_UEContextModificationResponse;



/**************************************************************************
 * UE CONTEXT MODIFICATION FAILURE
 *************************************************************************/

typedef struct _f1ap_UEContextModificationFailure 
{
#define UE_CTX_MOD_FAILURE_CRIT_DIAG_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                  du_f1ap_id;

    /* Cause */
    _f1ap_Cause                   cause;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextModificationFailure;



/***********************************************************************
 * UE CONTEXT RELEASE COMMAND
 **********************************************************************/

typedef struct _f1ap_UEContextReleaseCommand 
{
    /* gNB-CU UE F1AP ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int  du_f1ap_id;

    /* Cause */
    _f1ap_Cause   cause;

} _f1ap_UEContextReleaseCommand;



/**********************************************************************
 *  UE CONTEXT RELEASE COMPLETE
 *********************************************************************/

typedef struct _f1ap_UEContextReleaseComplete 
{
#define F1AP_UE_CTX_REL_CMD_CRIT_DIAGNOSTICS_PRESENT   0x01

    unsigned int                  bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int                  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int                  du_f1ap_id;

    /* Criticality Diagnostics */
    _f1ap_CriticalityDiagnostics  criticality_diagnostics;

} _f1ap_UEContextReleaseComplete;



/***********************************************************************
 * UE CONTEXT RELEASE REQUEST 
 **********************************************************************/

typedef struct _f1ap_UEContextReleaseRequest
{
    /* gNB-CU UE F1AP ID */
    unsigned int   cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int   du_f1ap_id;

    /* Cause */
    _f1ap_Cause    cause;

} _f1ap_UEContextReleaseRequest;


/*********************************************************************/

#endif
#endif  // _UE_CTX_MGMNT_H_
