#ifndef _F1AP_RRC_MSG_TRANSFER_H_
#define _F1AP_RRC_MSG_TRANSFER_H_

#if 0
/***************************************************************************
 * DL RRC Message Transfer 
 **************************************************************************/

typedef struct _f1ap_DLRRCMessageTransfer 
{
#define F1AP_DL_RRC_MSG_TRANSFER_OLD_DU_UE_F1AP_ID_PRESENT  0x01

    unsigned int  bitmask;

    /* gNB-CU UE F1AP ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int  du_f1ap_id;

    /* oldgNB-DU UE F1AP ID */
    unsigned int  old_du_f1ap_id;

    /* SRBID */
    unsigned int  srb_id;

    /* RRC Container length */
    unsigned int  rrcContainerLength;

    /* RRCContainer */
    unsigned char rrcContainer[MAX_RRC_CONTAINER_SIZE];

} _f1ap_DLRRCMessageTransfer;


/**************************************************************************/


/***************************************************************************
 * UL RRC Message Transfer
 **************************************************************************/
typedef struct _f1ap_ULRRCMessageTransfer 
{
    /* gNB-CU UE F1AP ID */
    unsigned int  cu_f1ap_id;

    /* gNB-DU UE F1AP ID */
    unsigned int  du_f1ap_id;

    /* SRBID */
    unsigned int  srb_id;

    /* RRC Container length */
    //unsigned int  rrcContainerLength;
    unsigned int  msg_type;

    /* RRC Container */
    unsigned char rrcContainer[MAX_RRC_CONTAINER_SIZE];

} _f1ap_ULRRCMessageTransfer;
#endif

/**************************************************************************/

#endif  // _F1AP_RRC_MSG_TRANSFER_H_
