/******************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ******************************************************************************
 *
 *  $Id: cg_config_info.h 
 *
 ******************************************************************************
 *
 *  File Description : This file contains the structure defining the content 
 *                     of Cg Config Info container.
 *****************************************************************************/
#ifndef _CG_CONFIG_INFO_H_
#define _CG_CONFIG_INFO_H_


/******************************************************************************
 * Project Includes
 *****************************************************************************/
#include "gnb_defines.h"
#include "ue_capability.h"


/******************************************************************************
 * Private Constants
 *****************************************************************************/

#if 0
#define MAX_NR_OFINDEXESTOREPORT   32
#define MAXNR_OF_SCELLS            32
#define MAX_CELL_SFTD              3
#define MAX_NUM_DRB                29
#define MAX_MEASFREQSMN            32
#else
#define MAX_NR_OFINDEXESTOREPORT   8
#define MAXNR_OF_SCELLS            8
#define MAX_CELL_SFTD              3
#define MAX_NUM_DRB                16
#define MAX_MEASFREQSMN            32
#endif


/******************************************************************************
 * Exported Variables
 *****************************************************************************/

typedef struct  drx_info_shortdrx_t{
    UInt32 drx_shortcycle;
    UInt16 drx_shortcycletimer;
}drx_info_shortdrx_t;

typedef struct  drx_info_t{
#define DRX_INFO_SHORTDRX_PRESENT   0x01
    UInt32 bitmask;
    UInt32 drx_longcyclestartoffset;
    drx_info_shortdrx_t shortdrx;
}drx_info_t;

typedef struct bpc_indexlist_t{
    UInt32 count;
    UInt32 bpc_index[MAX_BASEBANDPROCCOMB];
}bpc_indexlist_t;


typedef struct measquantityresults_t{
#define MEASQUANTITY_RESULTS_RSRP_PRESENT   0x01
#define MEASQUANTITY_RESULTS_RSRQ_PRESENT   0x02
#define MEASQUANTITY_RESULTS_SINR_PRESENT   0x04
    UInt32 bitmask;
    UInt16 nr_rsrp;
    UInt16 nr_rsrq;
    UInt32 nr_sinr;
}measquantityresults_t;

typedef struct  candidaters_indexinfocsi_rs_t{
#define CANDIDATERS_INDEXINFOCSI_RS_MEASRESULT_CSI_RSPRESENT    0x01
    UInt32 bitmask;
    UInt16 csi_rs_index;
    measquantityresults_t measresultcsi_rs;
}candidaters_indexinfocsi_rs_t;

typedef struct candidaters_indexinfolistcsi_rs_t{
    UInt32 count;
    candidaters_indexinfocsi_rs_t nr_rrc_candidaters_indexinfocsi_rs[MAX_NR_OFINDEXESTOREPORT];
}candidaters_indexinfolistcsi_rs_t;

typedef struct  candidaters_indexinfossb_t{
#define CANDIDATERS_INDEXINFOSSB_MEASRESULTSS_BPRESENT  0x01
    UInt32 bitmask;
    UInt16 ssb_index;
    measquantityresults_t measresultssb;
}candidaters_indexinfossb_t;

typedef struct candidaters_indexinfolistssb_t{
    UInt32 count;
    candidaters_indexinfossb_t nr_rrc_candidaters_indexinfossb[MAX_NR_OFINDEXESTOREPORT];
}candidaters_indexinfolistssb_t;

typedef struct  _candidatecellinfo_cellidentification_t{
    UInt32 nr_rrc_physcellid;
    UInt32 dl_carrierfreq;
}candidatecellinfo_cellidentification_t;

typedef struct  _candidatecellinfo_t 
{
#define CANDIDATECELLINFO_MEASRESULTCELL_PRESENT                0x01
#define CANDIDATECELLINFO_CANDIDATERS_INDEXLIST_SSB_PRESENT     0x02
#define CANDIDATECELLINFO_CANDIDATERS_INDEXLIST_CSI_RS_PRESENT  0x04
    UInt32 bitmask;
    candidatecellinfo_cellidentification_t cellidentification;
    measquantityresults_t measresultcell;
    candidaters_indexinfolistssb_t candidaters_indexlistssb;
    candidaters_indexinfolistcsi_rs_t candidaters_indexlistcsi_rs;
} candidatecellinfo_t;

typedef struct _candidatecellinfolist_t 
{
    UInt32 count;
    candidatecellinfo_t nr_rrc_candidatecellinfo[MAXNR_OF_SCELLS];
} candidatecellinfolist_t;

typedef struct  configrestrictmodreqscg_t{
#define CONFIG_RESTRICT_MOD_REQ_SCG_REQUESTED_BC_MRDC_PRESENT           0x01
#define CONFIG_RESTRICT_MOD_REQ_SCG_REQUESTED_BPC_LIST_MRDC_PRESENT     0x02
#define CONFIG_RESTRICT_MOD_REQ_SCG_REQUESTEDP_MAXFR1_PRESENT           0x04
    UInt32 bitmask;
    UInt32 requestedbc_mrdc;
    UInt16 requestedp_maxfr1;
    bpc_indexlist_t requestedbpc_listmrdc;
} configrestrictmodreqscg_t;

typedef struct measconfigsn_measuredfrequenciesfr1_t{
    UInt32 count;
    UInt32  freqinfo[MAX_MEASFREQSMN];
} measconfigsn_measuredfrequenciesfr1_t;

typedef struct  measconfigsn_t{
#define MEASCONFIG_SN_MEASURED_FREQUENCIES_FR1P_RESENT      0x01
    UInt32 bitmask;
    measconfigsn_measuredfrequenciesfr1_t measuredfrequenciesfr1;
} measconfigsn_t;

typedef struct  pdcp_config_drb_headercompression_rohc_profiles_t{
    UInt8 profile0x0001;
    UInt8 profile0x0002;
    UInt8 profile0x0003;
    UInt8 profile0x0004;
    UInt8 profile0x0006;
    UInt8 profile0x0101;
    UInt8 profile0x0102;
    UInt8 profile0x0103;
    UInt8 profile0x0104;
} pdcp_config_drb_headercompression_rohc_profiles_t;

typedef struct  pdcp_config_drb_headercompression_rohc_t{
    UInt32 maxcid;
    pdcp_config_drb_headercompression_rohc_profiles_t profiles;
    UInt8 drb_continuerohc;
} pdcp_config_drb_headercompression_rohc_t;


typedef struct  pdcp_config_drb_headercompression_uplinkonlyrohc_t {
    UInt32 maxcid;
    UInt8 profile0x0006;
    UInt8 drb_continuerohc;
} pdcp_config_drb_headercompression_uplinkonlyrohc_t;



typedef struct  pdcp_config_drb_headercompression_t {
#define PDCP_CONFIG_DRB_HEADERCOMPRESSION_ROHC_PRESENT              0x01
#define PDCP_CONFIG_DRB_HEADERCOMPRESSION_UPLINKONLYROHC_PRESENT    0x02
    UInt32 bitmask;
    pdcp_config_drb_headercompression_rohc_t rohc;
    pdcp_config_drb_headercompression_uplinkonlyrohc_t uplinkonlyrohc;
} pdcp_config_drb_headercompression_t;

typedef struct  pdcp_config_drb_t {
#define PDCP_DISCARDTIMER_PRESENT           0x01
#define PDCP_PDCP_SN_SIZEUL_PRESENT         0x02
#define PDCP_PDCP_SN_SIZEDL_PRESENT         0x04
#define PDCP_INTEGRITYP_ROTECTION_PRESENT   0x08
#define PDCP_STATUS_REPORT_REQUIRED_PRESENT 0x10
    UInt32 bitmask;
    UInt32 discardtimer;
    UInt32 drb_pdcp_sn_sizeul;
    UInt32 drb_pdcp_sn_sizedl;
    pdcp_config_drb_headercompression_t headercompression;
    UInt32 drb_integrityprotection;
    UInt32 drb_statusreportrequired;
    UInt8 outoforderdelivery;
} pdcp_config_drb_t;


typedef struct  pdcp_config_morethanonerlc_primarypath_t {
#define PDCP_CONFIG_MORETHANONERLC_PRIMARYPATH_CELLGROUP_PRESENT        0x01
#define PDCP_CONFIG_MORETHANONERLC_PRIMARYPATH_LOGICALCHANNEL_PRESENT   0x02
    UInt32 bitmask;
    UInt16 cellgroupid;
    UInt16 logicalchannelidentity;
}pdcp_config_morethanonerlc_primarypath_t;

typedef struct  pdcp_config_morethanonerlc_t {
#define PDCP_CONFIG_MORETHANONERL_DATA_SPLIT_THRESHOLD_PRESENT      0x01
#define PDCP_CONFIG_MORETHANONERLC_PDCP_DUPLICATION_PRESENT         0x02
    UInt32 bitmask;
    pdcp_config_morethanonerlc_primarypath_t primarypath;
    UInt32 ul_datasplitthreshold;
    UInt32 pdcp_duplication;
} pdcp_config_morethanonerlc_t;


typedef struct  pdcp_config_t {
#define PDCP_CONFIG_DRB_PRESENT                 0x01
#define PDCP_CONFIG_MORETHANONERLC_PRESENT      0x02
#define PDCP_CONFIG_REORDERING_PRESENT          0x04
    UInt32 bitmask;
    pdcp_config_drb_t               drb;
    pdcp_config_morethanonerlc_t    morethanonerlc;
    UInt8                            reordering;
} pdcp_config_t;


typedef struct  srb_toaddmod_t {
#define SRB_TOADDMOD_REESTABLISHPDC_PPRESENT    0x01
#define SRB_TOADDMOD_DISCARDONPDCP_PRESENT      0x02
#define SRB_TOADDMOD_PDCP_CONFIG_PRESENT        0x04
    UInt32 bitmask;
    UInt8            srb_identity;
    UInt8            reestablishpdcp;
    UInt8            discardonpdcp;
    pdcp_config_t   pdcp_config;
}srb_toaddmod_t;

typedef struct srb_toaddmodlist_t{
    UInt32 count;
    srb_toaddmod_t nr_rrc_srb_toaddmod[2];
}srb_toaddmodlist_t;


typedef struct drb_toaddmod_cnassociation_t {
#define DRB_TOADDMOD_CNASSOCIATION_EPS_BEARERIDENTITY_PRESENT   0x01
    UInt32 bitmask;
    UInt8 eps_beareridentity;
}drb_toaddmod_cnassociation_t;


typedef struct  drb_toaddmod_t {
#define DRB_TOADDMOD_CNASSOCIATION_PRESENT      0x01
#define DRB_TOADDMOD_REESTABLISHPDCP_PRESENT    0x02
#define DRB_TOADDMOD_RECOVERPDC_PPRESENT        0x04
#define DRB_TOADDMOD_PDCP_CONFIG_PRESENT        0x08
    UInt32 bitmask;
    drb_toaddmod_cnassociation_t cnassociation;
    UInt8 drb_identity;
    UInt8 reestablishpdcp;
    UInt8 recoverpdcp;
    pdcp_config_t pdcp_config;
}drb_toaddmod_t;



typedef struct drb_toaddmodlist_t{
    UInt32 count;
    drb_toaddmod_t nr_rrc_drb_toaddmod[MAX_NUM_DRB];
}drb_toaddmodlist_t;

typedef struct drb_toreleaselist_t {
    UInt32 n;
    UInt16 drb_identity[MAX_NUM_DRB];
}drb_toreleaselist_t;

typedef struct securityalgorithmconfig_t {
#define SECURITYALGORITHMCONFIG_INTEGRITY_PROT_ALGORITHM_PRESENT    0x01
    UInt32 bitmask;
    UInt8 cipheringalgorithm;
    UInt8 integrityprotalgorithm;
}securityalgorithmconfig_t;


typedef struct securityconfig_t {
#define SECURITYCONFIG_SECURITY_ALGORITHM_CONFIG_PRESENT    0x01
#define SECURITYCONFIG_KEY_TO_USE_PRESENT                   0x02
    UInt32 bitmask;
    UInt8 keytouse;
    securityalgorithmconfig_t securityalgorithmconfig;
}securityconfig_t;



typedef struct  radiobearerconfig_t {
#define RADIOBEARERCONFIG_SRB_TO_ADDMOD_LIST_PRESENT    0x01
#define RADIOBEARERCONFIG_SRB3_TO_RELEASE_PRESENT       0x02
#define RADIOBEARERCONFIG_DRB_TO_ADDMOD_LIST_PRESENT    0x04
#define RADIOBEARERCONFIG_DRB_TO_RELEASELIST_PRESENT    0x08
#define RADIOBEARERCONFIG_SECURITYCONFIG_PRESENT        0x10
    UInt32 bitmask;
    UInt8                srb3_torelease;
    srb_toaddmodlist_t  srb_toaddmodlist;
    drb_toaddmodlist_t  drb_toaddmodlist;
    drb_toreleaselist_t drb_toreleaselist;
    securityconfig_t    securityconfig;
}radiobearerconfig_t;


typedef struct  _measresultcellsftd_t{
#define MEASRESULTCELLSFTD_RSRP_RESULT_PRESENT  0x01
    UInt32 bitmask;
   UInt32 physcellid;
   UInt32 sfn_offsetresult;
   SInt32 frameboundaryoffsetresult;
   UInt16 rsrp_result;
}measresultcellsftd_t;

typedef struct _measresultcelllistsftd_t{
    UInt32 count;
    measresultcellsftd_t nr_rrc_measresultcellsftd[MAX_CELL_SFTD]; /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}measresultcelllistsftd_t;


typedef struct  _cg_configinfo_ies_scgfailureinfo_t{
   UInt32 failuretype;
   //_osdynoctstr measresultscg;
}cg_configinfo_ies_scgfailureinfo_t;







typedef struct  _configrestrictinfoscg_powercoordination_fr1_t{
#define CONFIG_RESTRICT_INFOSCG_POWER_COORDINATION_FR1_P_MAX_NR_PRESENT         0x01
#define CONFIG_RESTRICT_INFOSCG_POWER_COORDINATION_FR1_P_MAX_EUTRA_PRESENT      0x02
    UInt32 bitmask;
   UInt16 p_maxnr;
   UInt16 p_maxeutra;
}configrestrictinfoscg_powercoordination_fr1_t;


typedef struct  _configrestrictinfoscg_servcellindexrangescg_t{
   UInt16 lowbound;
   UInt16 upbound;
}configrestrictinfoscg_servcellindexrangescg_t;


typedef struct _bandcombinationindexlist_t{
    UInt32 count;
    UInt32 bandcombinationindex[MAX_BANDCOMB];
}bandcombinationindexlist_t;


typedef struct  _configrestrictinfoscg_t{
#define CONFIG_RESTRICTINFOSCG_ALLOWEDBC_LISTMRDC_PRESENT           0x01
#define CONFIG_RESTRICTINFOSCG_ALLOWEDBPC_LISTMRDC_PRESENT          0x02
#define CONFIG_RESTRICTINFOSCG_POWERCOORDINATION_FR1_PRESENT        0x04
#define CONFIG_RESTRICTINFOSCG_SERVCELLINDEX_RANGE_SCG_PRESENT      0x08
#define CONFIG_RESTRICTINFOSCG_MAX_MEAS_FREQSSCG_NR_PRESENT         0x10
   UInt32 bitmask; /*^ BITMASK ^*/
   bandcombinationindexlist_t allowedbc_listmrdc; /*^ O, CONFIG_RESTRICTINFOSCG_ALLOWEDBC_LISTMRDC_PRESENT , N , 0, 0 ^*/
   bpc_indexlist_t allowedbpc_listmrdc; /*^ O, CONFIG_RESTRICTINFOSCG_ALLOWEDBPC_LISTMRDC_PRESENT , N , 0, 0 ^*/
   configrestrictinfoscg_powercoordination_fr1_t powercoordination_fr1; /*^ O, CONFIG_RESTRICTINFOSCG_POWERCOORDINATION_FR1_PRESENT , N , 0, 0 ^*/
   configrestrictinfoscg_servcellindexrangescg_t servcellindexrangescg; /*^ O, CONFIG_RESTRICTINFOSCG_SERVCELLINDEX_RANGE_SCG_PRESENT , N , 0, 0 ^*/
   UInt16 maxmeasfreqsscg_nr; /*^ O,CONFIG_RESTRICTINFOSCG_MAX_MEAS_FREQSSCG_NR_PRESENT , N , 0, 0 ^*/
}configrestrictinfoscg_t;



typedef struct _measconfigmn_measuredfrequenciesmn_t{
    UInt32  count;
    UInt32 measuredfrequency[MAX_MEASFREQSMN];
}measconfigmn_measuredfrequenciesmn_t;

typedef struct  _gapconfig_t{
   UInt16 gapoffset;
   UInt32 mgl;
   UInt32 mgrp;
   UInt32 mgta;
}gapconfig_t;

typedef struct  _measconfigmn_t{
#define MEASCONFIGMN_MEASURED_FREQUENCIESMN_PRESENT     0x01
#define MEASCONFIGMN_MEASGAPCONFIG_FR1_PRESENT          0x02
#define MEASCONFIGMN_GAP_PURPOSE_PRESENT                0x04
    UInt32 bitmask; /*^ BITMASK ^*/
   UInt32 gappurpose; /*^ O, MEASCONFIGMN_GAP_PURPOSE_PRESENT , N , 0, 0 ^*/
   measconfigmn_measuredfrequenciesmn_t measuredfrequenciesmn; /*^ O, MEASCONFIGMN_MEASURED_FREQUENCIESMN_PRESENT , N , 0, 0 ^*/
   gapconfig_t measgapconfigfr1; /*^ O, MEASCONFIGMN_MEASGAPCONFIG_FR1_PRESENT , N , 0, 0 ^*/ 
}measconfigmn_t;


typedef struct _cg_configinfo_t 
{
#define CG_CONFIGINFO_UE_CAPABILITYINFO_PRESENT             0x01
#define CG_CONFIGINFO_CANDIDATECELLINFOLISTMN_PRESENT       0x02
#define CG_CONFIGINFO_CANDIDATECELLINFOLISTSN_PRESENT       0x04
#define CG_CONFIGINFO_MEASRESULT_CELLLISTSFTD_PRESENT       0x08
#define CG_CONFIGINFO_SCGFAILUREINFO_PRESENT                0x10
#define CG_CONFIGINFO_CONFIGRESTRICTINFO_PRESENT            0x20
#define CG_CONFIGINFO_DRX_INFOMCG_PRESENT                   0x40
#define CG_CONFIGINFO_MEASCONFIGMN_PRESENT                  0x80
#define CG_CONFIGINFO_SOURCECONFIGSCG_PRESENT               0x100
#define CG_CONFIGINFO_SCG_RB_CONFIG_PRESENT                 0x200
#define CG_CONFIGINFO_MCG_RB_CONFIG_PRESENT                 0x400
#define CG_CONFIGINFO_NONCRITICALEXTENSION_PRESENT          0x800
    UInt32 bitmask; /*^ BITMASK ^*/
    ue_capabilityrat_container_t        ue_capabilityinfo; /*^ O, CG_CONFIGINFO_UE_CAPABILITYINFO_PRESENT , N , 0, 0 ^*/
    candidatecellinfolist_t             candidatecellinfolistmn; /*^ O, CG_CONFIGINFO_CANDIDATECELLINFOLISTMN_PRESENT , N , 0, 0 ^*/
    candidatecellinfolist_t             candidatecellinfolistsn; /*^ O, CG_CONFIGINFO_CANDIDATECELLINFOLISTSN_PRESENT , N , 0, 0 ^*/
    measresultcelllistsftd_t            measresultcelllistsftd;  /*^ O, CG_CONFIGINFO_MEASRESULT_CELLLISTSFTD_PRESENT , N , 0, 0 ^*/
    cg_configinfo_ies_scgfailureinfo_t  scgfailureinfo;  /*^ O, CG_CONFIGINFO_SCGFAILUREINFO_PRESENT , N , 0, 0 ^*/
    configrestrictinfoscg_t             configrestrictinfo; /*^ O, CG_CONFIGINFO_CONFIGRESTRICTINFO_PRESENT , N , 0, 0 ^*/
    drx_info_t                          drx_infomcg; /*^ O, CG_CONFIGINFO_DRX_INFOMCG_PRESENT , N , 0, 0 ^*/
    measconfigmn_t                      measconfigmn; /*^ O, CG_CONFIGINFO_MEASCONFIGMN_PRESENT , N , 0, 0 ^*/
    radiobearerconfig_t                 scg_rb_config; /*^ O, CG_CONFIGINFO_SCG_RB_CONFIG_PRESENT , N , 0, 0 ^*/
    radiobearerconfig_t                 mcg_rb_config; /*^ O, CG_CONFIGINFO_MCG_RB_CONFIG_PRESENT , N , 0, 0 ^*/
} cg_configinfo_t;


#endif
