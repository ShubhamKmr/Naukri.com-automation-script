/******************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ******************************************************************************
 *
 *  $Id: ue_capability.h 
 *
 ******************************************************************************
 *
 *  File Description : This file contains the structures defning the content
 *                     of UE Capability container.
 *****************************************************************************/
#ifndef _UE_CAPABILITY_H_
#define _UE_CAPABILITY_H_


/******************************************************************************
 * Private Constants 
 *****************************************************************************/
#define MAX_BANDS                  6
#define MAX_BANDCOMB               6
#define MAX_BASEBANDPROCCOMB       6
#define MAXNR_OFSERVINGCELLSEUTRA  6
#define MAX_NROFSERVINGCELLS       6
#define MAX_SIMULTANEOUSBANDS      6
#define MAX_BASEBANDPROCCOMB_SUL  ((MAX_BASEBANDPROCCOMB/8 + 1))
#define MAX_BANDCOMB_SUL          ((MAX_BANDCOMB/8) + 1)

/*  CAPABILITY */
/* The presence of bitmask of a parameter means ENUMERATED {supported},
 * ENUMERATED {true} or ENUMERATED {notSupported}. */
typedef UInt8 scs_15khz_t;
typedef UInt8 scs_30khz_t;
typedef UInt8 scs_60khz_t;
typedef UInt8 scs_120khz_t;
typedef UInt8 scs_240khz_t;
typedef UInt8 sch_120khz_t;
typedef UInt8 ca_bandwidthclassnr_t;
typedef UInt8 ca_bandwidthclasseutra_t;
typedef UInt8 mimo_layersul_t;
typedef UInt8 mimo_layersdl_t;



typedef struct _meas_parameters_tmrdc_xdd_diff_t {
#define MEAS_PARAMETERS_TMRDC_XDD_DIFF_SFTD_MEASPSCELL_PRESENT       0x01
#define MEAS_PARAMETERS_TMRDC_XDD_DIFF_SFTD_MEASNR_CELL_PRESENT      0x02
    UInt8  bitmask;  /*^ BITMASK ^*/
}meas_parameters_tmrdc_xdd_diff_t;


typedef struct _meas_parameters_tmrdc_common_t {
#define MEAS_PARAMETERS_TMRDC_COMMON_INDEPENDENTGAPCONFIG_PRESENT    0x01
    UInt8  bitmask;  /*^ BITMASK ^*/
}meas_parameters_tmrdc_common_t;


typedef struct _meas_parameters_tmrdc_frx_diff_t {
#define MEAS_PARAMETERS_TMRDC_FRX_DIFF_SIMULTANEOUSRXDATASSB_DIFFNUMEROLOGY_PRESENT  0x01
    UInt8  bitmask;  /*^ BITMASK ^*/
}meas_parameters_tmrdc_frx_diff_t;


typedef struct _meas_parameters_tmrdc_t {
#define MEAS_PARAMETERS_TMRDC_MEASPARAMETERSMRDC_XDD_DIFF_PRESENT   0x01
    UInt8  bitmask;  /*^ BITMASK ^*/
    meas_parameters_tmrdc_common_t measparametersmrdc_common;
    meas_parameters_tmrdc_xdd_diff_t measparametersmrdc_xdd_diff; /*^ O, MEAS_PARAMETERS_TMRDC_MEASPARAMETERSMRDC_XDD_DIFF_PRESENT , N , 0, 0 ^*/
    meas_parameters_tmrdc_frx_diff_t measparametersmrdc_frx_diff;
} meas_parameters_tmrdc_t;


typedef struct _intrabandcontiguouscc_infodl_eutra_t {
#define INTRABANDCONTIGUOUSCC_INFODL_EUTRA_MIMO_CAPABILITYDL_PRESENT    0x01
    UInt8  bitmask; /*^ BITMASK ^*/
    UInt8   mimo_capabilitydl; /*^ O, INTRABANDCONTIGUOUSCC_INFODL_EUTRA_MIMO_CAPABILITYDL_PRESENT , N , 0, 0 ^*/
}intrabandcontiguouscc_infodl_eutra_t;


typedef struct _bandanddl_parameterseutra_intrabandcontiguouscc_infodl_eutra_list_t{
    UInt8 count;
    intrabandcontiguouscc_infodl_eutra_t intrabandcontiguouscc_infodl_eutra[MAXNR_OFSERVINGCELLSEUTRA];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandanddl_parameterseutra_intrabandcontiguouscc_infodl_eutra_list_t;


typedef struct _bandanddl_parameterseutra_t {
#define BANDANDDL_PARAMETERSEUTRA_CA_BANDWIDTHCLASSDL_EUTRA_PRESENT                 0x01
#define BANDANDDL_PARAMETERSEUTRA_INTRABANDCONTIGUOUSCC_INFODL_EUTRA_LIST_PRESENT   0x02
    UInt8  bitmask; /*^ BITMASK ^*/
    UInt16 freqbandindicatoreutra; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    bandanddl_parameterseutra_intrabandcontiguouscc_infodl_eutra_list_t intrabandcontiguouscc_infodl_eutra_list; /*^ O,BANDANDDL_PARAMETERSEUTRA_CA_BANDWIDTHCLASSDL_EUTRA_PRESENT, N , 0, 0 ^*/
    ca_bandwidthclasseutra_t ca_bandwidthclasseutra; /*^ O, BANDANDDL_PARAMETERSEUTRA_INTRABANDCONTIGUOUSCC_INFODL_EUTRA_LIST_PRESENT , N , 0, 0 ^*/
}bandanddl_parameterseutra_t;

typedef struct _intrabandcontiguouscc_infodl_t {
#define INTRABANDCONTIGUOUSCC_INFODL_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT      0x01
    UInt8 bitmask; /*^ BITMASK ^*/
    mimo_layersdl_t maxnumbermimo_layerspdsch; /*^ O, INTRABANDCONTIGUOUSCC_INFODL_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT , N , 0, 0 ^*/
}intrabandcontiguouscc_infodl_t;


typedef struct _bandanddl_parametersnr_intrabandcontiguouscc_infodl_list_t{
    UInt8 count;
    intrabandcontiguouscc_infodl_t intrabandcontiguouscc_infodl[MAX_NROFSERVINGCELLS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandanddl_parametersnr_intrabandcontiguouscc_infodl_list_t;

typedef struct _bandanddl_parametersnr_t {
#define BANDANDDL_PARAMETERSNR_CA_BANDWIDTHCLASSDL_PRESENT               0x01
#define BANDANDDL_PARAMETERSNR_INTRABANDFREQSEPARATIONDL_PRESENT         0x02
#define BANDANDDL_PARAMETERSNR_INTRABANDCONTIGUOUSCC_INFODL_LIST_PRESENT 0x04
    UInt8  bitmask; /*^ BITMASK ^*/
    UInt16  bandnr;
    bandanddl_parametersnr_intrabandcontiguouscc_infodl_list_t intrabandcontiguouscc_infodl_list; /*^ O, BANDANDDL_PARAMETERSNR_INTRABANDCONTIGUOUSCC_INFODL_LIST_PRESENT , N , 0, 0 ^*/
    ca_bandwidthclassnr_t  ca_bandwidthclassdl; /*^ O, BANDANDDL_PARAMETERSNR_CA_BANDWIDTHCLASSDL_PRESENT , N , 0, 0 ^*/
    UInt8  intrabandfreqseparationdl; /*^ O, BANDANDDL_PARAMETERSNR_INTRABANDFREQSEPARATIONDL_PRESENT , N , 0, 0 ^*/
}bandanddl_parametersnr_t;



typedef struct _bandanddl_parameters_t {
#define BANDANDDL_PARAMETERS_BANDANDDL_PARAMETERSEUTRA_PRESENT      0x01
#define BANDANDDL_PARAMETERS_BANDANDDL_PARAMETERSNR_PRESENT         0x02
    UInt8 bitmask; /* Bitmask can have only one value */  /*^ BITMASK ^*/
    bandanddl_parameterseutra_t bandanddl_parameterseutra; /*^ O, BANDANDDL_PARAMETERS_BANDANDDL_PARAMETERSEUTRA_PRESENT , N , 0, 0 ^*/
    bandanddl_parametersnr_t    bandanddl_parametersnr; /*^ O, BANDANDDL_PARAMETERS_BANDANDDL_PARAMETERSNR_PRESENT , N , 0, 0 ^*/
}bandanddl_parameters_t;



typedef struct _bandanddl_parameterslist_t{
    UInt8 count;
    bandanddl_parameters_t bandanddl_parameters[MAX_SIMULTANEOUSBANDS];
}bandanddl_parameterslist_t;


typedef struct _bandcombination_bandcombinationsul_t {
    UInt32 numbits;
    UInt8 data[MAX_BANDCOMB_SUL];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandcombination_bandcombinationsul_t;

typedef struct _ca_parametersnr_t {
#define CA_PARAMETERSNR_MULTIPLETIMINGADVANCES_PRESENT           0x01
#define CA_PARAMETERSNR_SIMULTANEOUSRXTXINTERBANDCA_PRESENT      0x02
#define CA_PARAMETERSNR_SUPPORTEDBANDWIDTHCOMBINATIONSET_PRESENT 0x04
    UInt8  bitmask; /*^ BITMASK ^*/
    UInt32 supportedbandwidthcombinationset; /*^ O, CA_PARAMETERSNR_SUPPORTEDBANDWIDTHCOMBINATIONSET_PRESENT , N , 0, 0 ^*/ 
}ca_parametersnr_t;

typedef struct _basebandprocessingcombinationlink_basebandprocessingcombinationlinkedindexsn_t{
    UInt32 count;
    UInt32 basebandprocessingcombinationindex[MAX_BASEBANDPROCCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}basebandprocessingcombinationlink_basebandprocessingcombinationlinkedindexsn_t;

typedef struct _basebandprocessingcombinationlink_t {
    UInt32 basebandprocessingcombinationindexmn;
    basebandprocessingcombinationlink_basebandprocessingcombinationlinkedindexsn_t basebandprocessingcombinationlinkedindexsn;
}basebandprocessingcombinationlink_t;


typedef struct  _basebandprocessingcombinationmrdc_t{
    UInt32 count;
    basebandprocessingcombinationlink_t basebandprocessingcombinationlink[MAX_BASEBANDPROCCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}basebandprocessingcombinationmrdc_t;

typedef struct _mrdc_parameters_t {
#define MRDC_PARAMETERS_SINGLEUL_TRANSMISSION_PRESENT               0x01
#define MRDC_PARAMETERS_UL_SHARINGEUTRA_NR_PRESENT                  0x02
#define MRDC_PARAMETERS_UL_SWITCHINGTIMEEUTRA_NR_PRESENT            0x04
#define MRDC_PARAMETERS_SIMULTANEOUSRXTXINTERBANDENDC_PRESENT       0x08
#define MRDC_PARAMETERS_ASYNCINTRABANDENDC_PRESENT                  0x10
    basebandprocessingcombinationmrdc_t basebandprocesingcombinationmrdc;
    UInt8  bitmask; /*^ BITMASK ^*/
    UInt8 ul_switchingtimeeutra_nr; /*^ O, MRDC_PARAMETERS_UL_SWITCHINGTIMEEUTRA_NR_PRESENT , N , 0, 0 ^*/ 
}mrdc_parameters_t;


typedef struct _bandcombinationparameters_t {
#define BANDCOMBINATIONPARAMETERS_CA_PARAMETERSNR_PRESENT    0x01
#define BANDCOMBINATIONPARAMETERS_MRDC_PARAMETERS_PRESENT    0x02
    UInt8  bitmask;  /*^ BITMASK ^*/
    mrdc_parameters_t mrdc_parameters; /*^ O, BANDCOMBINATIONPARAMETERS_CA_PARAMETERSNR_PRESENT , N , 0, 0 ^*/
    ca_parametersnr_t ca_parametersnr; /*^ O, BANDCOMBINATIONPARAMETERS_MRDC_PARAMETERS_PRESENT , N , 0, 0 ^*/ 
}bandcombinationparameters_t;



typedef struct _bandcombination_bandcombinationparameterslist_t{
    UInt32 count;
    bandcombinationparameters_t bandcombinationparameters[MAX_BANDCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandcombination_bandcombinationparameterslist_t;

typedef struct _bandcombination_t {
#define BANDCOMBINATION_BANDCOMBINATIONPARAMETERSLIST_PRESENT   0x01
    UInt8  bitmask;   /*^ BITMASK ^*/
    bandanddl_parameterslist_t bandanddl_parameterslist;
    bandcombination_bandcombinationsul_t bandcombinationsul;
    bandcombination_bandcombinationparameterslist_t bandcombinationparameterslist; /*^ O, BANDCOMBINATION_BANDCOMBINATIONPARAMETERSLIST_PRESENT , N , 0, 0 ^*/
}bandcombination_t;



typedef struct _bandcombinationlist_t{
    UInt16 count;
    bandcombination_t bandcombination[MAX_BANDCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandcombinationlist_t;


typedef struct _intrabandcontiguouscc_infoul_eutra_t {
#define INTRABANDCONTIGUOUSCC_INFOUL_EUTRA_MIMO_CAPABILITYUL_PRESENT     0x01
    UInt8 mimo_capabilityul; /* {twoLayers, fourLayers} */
    UInt8  bitmask;  /*^ BITMASK ^*/
}intrabandcontiguouscc_infoul_eutra_t;



typedef struct _bandparametersul_eutra_intrabandcontiguouscc_infoul_eutra_list_t{
    UInt32 count;
    intrabandcontiguouscc_infoul_eutra_t intrabandcontiguouscc_infoul_eutra[MAXNR_OFSERVINGCELLSEUTRA];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandparametersul_eutra_intrabandcontiguouscc_infoul_eutra_list_t;

typedef struct _bandparametersul_eutra_t {
#define BANDPARAMETERSUL_EUTRA_CA_BANDWIDTHCLASSUL_EUTRA_PRESENT                    0x01
#define BANDPARAMETERSUL_EUTRA_INTRABANDCONTIGUOUSCC_INFOUL_EUTRA_LIST_PRESENT      0x02
    UInt8 bitmask;  /*^ BITMASK ^*/
    ca_bandwidthclasseutra_t ca_bandwidthclasseutra; /*^ O,BANDPARAMETERSUL_EUTRA_CA_BANDWIDTHCLASSUL_EUTRA_PRESENT , N , 0, 0 ^*/
    bandparametersul_eutra_intrabandcontiguouscc_infoul_eutra_list_t intrabandcontiguouscc_infoul_eutra_list; /*^ O,BANDPARAMETERSUL_EUTRA_INTRABANDCONTIGUOUSCC_INFOUL_EUTRA_LIST_PRESENT , N , 0, 0 ^*/ 
}bandparametersul_eutra_t;


typedef struct _intrabandcontiguouscc_infoul_t {
#define INTRABANDCONTIGUOUSCC_INFOUL_MAXNUMBERMIMO_LAYERSCB_PUSCH_PRESENT       0x01
#define INTRABANDCONTIGUOUSCC_INFOUL_MAXNUMBERMIMO_LAYERSNONCB_PUSCH_PRESENT    0x02
    UInt8 bitmask;  /*^ BITMASK ^*/
    mimo_layersul_t maxnumbermimo_layerscb_pusch; /*^ O,INTRABANDCONTIGUOUSCC_INFOUL_MAXNUMBERMIMO_LAYERSCB_PUSCH_PRESENT,  N , 0, 0 ^*/
    mimo_layersul_t maxnumbermimo_layersnoncb_pusch; /*^ O, INTRABANDCONTIGUOUSCC_INFOUL_MAXNUMBERMIMO_LAYERSNONCB_PUSCH_PRESENT , N , 0, 0 ^*/ 
}intrabandcontiguouscc_infoul_t;


typedef struct _bandparametersul_nr_intrabandcontiguouscc_infoul_list_t{
    UInt8 count;
    intrabandcontiguouscc_infoul_t intrabandcontiguouscc_infoul[MAX_NROFSERVINGCELLS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandparametersul_nr_intrabandcontiguouscc_infoul_list_t;

typedef struct _bandparametersul_nr_t {
#define BANDPARAMETERSUL_NR_CA_BANDWIDTHCLASSUL_PRESENT                 0x01
#define BANDPARAMETERSUL_NR_INTRABANDFREQSEPARATIONUL_PRESENT           0x02
#define BANDPARAMETERSUL_NR_INTRABANDCONTIGUOUSCC_INFOUL_LIST_PRESENT   0x04
    UInt8 bitmask; /*^ BITMASK ^*/
    bandparametersul_nr_intrabandcontiguouscc_infoul_list_t intrabandcontiguouscc_infoul_list;
    /*^ O,BANDPARAMETERSUL_NR_INTRABANDCONTIGUOUSCC_INFOUL_LIST_PRESENT , N , 0, 0 ^*/
    UInt8 intrabandfreqseparationul; /* {c1, c2, c3, ...} */ /*^ O, BANDPARAMETERSUL_NR_INTRABANDFREQSEPARATIONUL_PRESENT , N , 0, 0 ^*/
    ca_bandwidthclassnr_t  ca_bandwidthclassul; /*^ O, BANDPARAMETERSUL_NR_CA_BANDWIDTHCLASSUL_PRESENT , N , 0, 0 ^*/
}bandparametersul_nr_t;



typedef struct _bandparametersul_t {
#define BANDPARAMETERSUL_BANDPARAMETERSUL_EUTRA_PRESENT     0x01
#define BANDPARAMETERSUL_BANDPARAMETERSUL_NR_PRESENT        0x02
    bandparametersul_eutra_t bandparametersul_eutra;
    bandparametersul_nr_t bandparametersul_nr;
    UInt8 bitmask; /* Only one bitmask can be set */
}bandparametersul_t;



typedef struct _bandcombinationparametersul_t{
    UInt8 count;
    bandparametersul_t bandparametersul[MAX_SIMULTANEOUSBANDS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandcombinationparametersul_t;

typedef struct _bandcombinationparametersul_list_t{
    UInt32 count;
    bandcombinationparametersul_t bandcombinationparametersul[MAX_BANDCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}bandcombinationparametersul_list_t;

typedef struct _rf_parameters_tmrdc_t {
    bandcombinationlist_t supportedbandcombination;
    bandcombinationparametersul_list_t bandcombinationparametersul_list;
} rf_parameters_tmrdc_t;



typedef struct _phy_parameters_tmrdc_xdd_diff_t {
#define PHY_PARAMETERS_TMRDC_XDD_DIFF_DYNAMICPOWERSHARING_PRESENT    0x01
#define PHY_PARAMETERS_TMRDC_XDD_DIFF_TDM_PATTERN_PRESENT            0x02
    UInt8  bitmask; /*^ BITMASK ^*/
}phy_parameters_tmrdc_xdd_diff_t;



typedef struct _phy_parameters_tmrdc_frx_diff_t {
#define PHY_PARAMETERS_TMRDC_FRX_DIFF_DYNAMICPOWERSHARING_PRESENT    0x01
#define PHY_PARAMETERS_TMRDC_FRX_DIFF_TDM_PATTERN_PRESENT            0x02
    UInt8  bitmask; /*^ BITMASK ^*/
}phy_parameters_tmrdc_frx_diff_t;



typedef struct _phy_parameters_tmrdc_t {
#define PHY_PARAMETERS_TMRDC_PHY_PARAMETERSMRDC_XDD_DIFF_PRESENT 0x01
#define PHY_PARAMETERS_TMRDC_PHY_PARAMETERSMRDC_FRX_DIFF_PRESENT 0x02
    UInt8  bitmask; /*^ BITMASK ^*/
    phy_parameters_tmrdc_xdd_diff_t phy_parametersmrdc_xdd_diff; /*^ O, PHY_PARAMETERS_TMRDC_PHY_PARAMETERSMRDC_XDD_DIFF_PRESENT , N , 0, 0 ^*/
    phy_parameters_tmrdc_frx_diff_t phy_parametersmrdc_frx_diff; /*^ O, PHY_PARAMETERS_TMRDC_PHY_PARAMETERSMRDC_FRX_DIFF_PRESENT , N , 0, 0 ^*/
}phy_parameters_tmrdc_t;


typedef struct _generalparametersmrdc_xdd_diff_t {
#define GENERALPARAMETERSMRDC_XDD_DIFF_SPLITSRB_WITHONEUL_PATH_PRESENT           0x01
#define GENERALPARAMETERSMRDC_XDD_DIFF_SPLITDRB_WITHUL_BOTH_MCG_SCG_PRESENT      0x02
#define GENERALPARAMETERSMRDC_XDD_DIFF_SRB3_PRESENT                              0x04
    UInt8  bitmask;  /*^ BITMASK ^*/
}generalparametersmrdc_xdd_diff_t;



typedef struct _ue_mrdc_capability_taddxdd_mode_t {
#define UE_MRDC_CAPABILITY_TADDXDD_MODE_PHY_PARAMETERSMRDC_XDD_DIFF_PRESENT      0x01
#define UE_MRDC_CAPABILITY_TADDXDD_MODE_MEASPARAMETERSMRDC_XDD_DIFF_PRESENT      0x02
#define UE_MRDC_CAPABILITY_TADDXDD_MODE_GENERALPARAMETERSMRDC_XDD_DIFF_PRESENT   0x04
    UInt8 bitmask;  /*^ BITMASK ^*/
    phy_parameters_tmrdc_xdd_diff_t phy_parametersmrdc_xdd_diff;  /*^ O, UE_MRDC_CAPABILITY_TADDXDD_MODE_PHY_PARAMETERSMRDC_XDD_DIFF_PRESENT , N , 0, 0 ^*/
    meas_parameters_tmrdc_xdd_diff_t measparametersmrdc_xdd_diff; /*^ O, UE_MRDC_CAPABILITY_TADDXDD_MODE_MEASPARAMETERSMRDC_XDD_DIFF_PRESENT , N , 0, 0 ^*/
    generalparametersmrdc_xdd_diff_t generalparametersmrdc_xdd_diff; /*^ O, UE_MRDC_CAPABILITY_TADDXDD_MODE_GENERALPARAMETERSMRDC_XDD_DIFF_PRESENT , N , 0, 0 ^*/ 
}ue_mrdc_capability_taddxdd_mode_t;

typedef struct _ue_mrdc_capability_taddfrx_mode_t {
#define UE_MRDC_CAPABILITY_TADDFRX_MODE_PHY_PARAMETERSMRDC_FRX_DIFF_PRESENT  0x01
    UInt8 bitmask;   /*^ BITMASK ^*/
    phy_parameters_tmrdc_frx_diff_t phy_parametersmrdc_frx_diff; /*^ O, UE_MRDC_CAPABILITY_TADDFRX_MODE_PHY_PARAMETERSMRDC_FRX_DIFF_PRESENT , N , 0, 0 ^*/
    meas_parameters_tmrdc_frx_diff_t measparametersmrdc_frx_diff;
}ue_mrdc_capability_taddfrx_mode_t;



typedef struct _ue_mrdc_capability_t {
#define UE_MRDC_CAPABILITY_MEASPARAMETERSMRDC_PRESENT               0x01
#define UE_MRDC_CAPABILITY_PHY_PARAMETERSMRDC_PRESENT               0x02
#define UE_MRDC_CAPABILITY_GENERALPARAMETERSMRDC_PRESENT            0x04
#define UE_MRDC_CAPABILITY_FDD_ADD_UE_MRDC_CAPABILITIES_PRESENT     0x08
#define UE_MRDC_CAPABILITY_TDD_ADD_UE_MRDC_CAPABILITIES_PRESENT     0x10
#define UE_MRDC_CAPABILITY_FR1_ADD_UE_MRDC_CAPABILITIES_PRESENT     0x20
#define UE_MRDC_CAPABILITY_FR2_ADD_UE_MRDC_CAPABILITIES_PRESENT     0x40
#define UE_MRDC_CAPABILITY_LATENONCRITICALEXTENSION_PRESENT         0x80
    UInt8  bitmask; /*^ BITMASK ^*/
    meas_parameters_tmrdc_t measparametersmrdc; /*^ O, UE_MRDC_CAPABILITY_MEASPARAMETERSMRDC_PRESENT , N , 0, 0 ^*/
    rf_parameters_tmrdc_t rf_parametersmrdc; 
    phy_parameters_tmrdc_t phy_parametersmrdc; /*^ O, UE_MRDC_CAPABILITY_PHY_PARAMETERSMRDC_PRESENT , N , 0, 0 ^*/
    generalparametersmrdc_xdd_diff_t generalparametersmrdc; /*^ O, UE_MRDC_CAPABILITY_GENERALPARAMETERSMRDC_PRESENT , N , 0, 0 ^*/
    ue_mrdc_capability_taddxdd_mode_t fdd_add_ue_mrdc_capabilities; /*^ O, UE_MRDC_CAPABILITY_FDD_ADD_UE_MRDC_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_mrdc_capability_taddxdd_mode_t tdd_add_ue_mrdc_capabilities; /*^ O, UE_MRDC_CAPABILITY_TDD_ADD_UE_MRDC_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_mrdc_capability_taddfrx_mode_t fr1_add_ue_mrdc_capabilities; /*^ O, UE_MRDC_CAPABILITY_FR1_ADD_UE_MRDC_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_mrdc_capability_taddfrx_mode_t fr2_add_ue_mrdc_capabilities; /*^ O, UE_MRDC_CAPABILITY_FR2_ADD_UE_MRDC_CAPABILITIES_PRESENT , N , 0, 0 ^*/
}ue_mrdc_capability_t;

typedef struct _pdcp_parameters_supportedrohc_profiles_t {
    UInt8 profile0x0000;
    UInt8 profile0x0001;
    UInt8 profile0x0002;
    UInt8 profile0x0003;
    UInt8 profile0x0004;
    UInt8 profile0x0006;
    UInt8 profile0x0101;
    UInt8 profile0x0102;
    UInt8 profile0x0103;
    UInt8 profile0x0104;
}pdcp_parameters_supportedrohc_profiles_t;

typedef struct _pdcp_capability_parameters_t {
#define PDCP_PARAMETERS_UPLINKONLYROHC_PROFILES_PRESENT     0x01
#define PDCP_PARAMETERS_CONTINUEROHC_CONTEXT_PRESENT        0x02
#define PDCP_PARAMETERS_OUTOFORDERDELIVERY_PRESENT          0x04
#define PDCP_PARAMETERS_SHORTSN_PRESENT                     0x08
    UInt8 bitmask;  /*^ BITMASK ^*/
    pdcp_parameters_supportedrohc_profiles_t supportedrohc_profiles; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumberrohc_contextsessions; 
    UInt32 uplink_only_rohc_profiles; /*^ O, PDCP_PARAMETERS_UPLINKONLYROHC_PROFILES_PRESENT , N , 0, 0 ^*/
    UInt32 continue_rohc_context; /*^ O, PDCP_PARAMETERS_CONTINUEROHC_CONTEXT_PRESENT  , N , 0, 0 ^*/
    UInt32 out_of_order_delivery; /*^ O, PDCP_PARAMETERS_OUTOFORDERDELIVERY_PRESENT , N , 0, 0 ^*/
    UInt32 short_sn; /*^ O, PDCP_PARAMETERS_SHORTSN_PRESENT , N , 0, 0 ^*/
}pdcp_capability_parameters_t;

typedef struct _rlc_parameters_t {
#define RLC_PARAMETERS_AM_WITHSHORTSN_PRESENT   0x01
#define RLC_PARAMETERS_UM_WITHSHORTSN_PRESENT   0x02
#define RLC_PARAMETERS_UM_WITHLONGSN_PRESENT    0x04
    UInt8 bitmask; /*^ BITMASK ^*/
}rlc_parameters_t;

typedef struct _mac_parameterscommon_t {
#define MAC_PARAMETERSCOMMON_LCP_RESTRICTION_PRESENT                 0x01
#define MAC_PARAMETERSCOMMON_PUCCH_SPATIALRELINFOMAC_CE_PRESENT      0x02
    UInt8 bitmask; /*^ BITMASK ^*/
}mac_parameterscommon_t;

typedef struct _mac_parametersxdd_diff_t {
#define MAC_PARAMETERSXDD_DIFF_SKIPUPLINKTXDYNAMIC_PRESENT                      0x01
#define MAC_PARAMETERSXDD_DIFF_LOGICALCHANNELSR_DELAYTIMER_PRESENT              0x02
#define MAC_PARAMETERSXDD_DIFF_LONGDRX_CYCLE_PRESENT                            0x04
#define MAC_PARAMETERSXDD_DIFF_SHORTDRX_CYCLE_PRESENT                           0x08
#define MAC_PARAMETERSXDD_DIFF_MULTIPLESR_CONFIGURATIONS_PRESENT                0x10
#define MAC_PARAMETERSXDD_DIFF_MULTIPLECONFIGUREDGRANTCONFIGURATIONS_PRESENT    0x20
    UInt8 bitmask; /*^ BITMASK ^*/
}mac_parametersxdd_diff_t;

typedef struct _mac_parameters_t {
#define MAC_PARAMETERS_MAC_PARAMETERSCOMMON_PRESENT         0x01
#define MAC_PARAMETERS_MAC_PARAMETERSXDD_DIFF_PRESENT       0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    mac_parameterscommon_t mac_parameterscommon; /*^ O, MAC_PARAMETERS_MAC_PARAMETERSCOMMON_PRESENT , N , 0, 0 ^*/
    mac_parametersxdd_diff_t mac_parametersxdd_diff; /*^ O, MAC_PARAMETERS_MAC_PARAMETERSXDD_DIFF_PRESENT , N , 0, 0 ^*/ 
}mac_parameters_t;

typedef struct _phy_parameterscommon_t {
#define PHY_PARAMETERSCOMMON_CSI_RS_CFRA_FORHO_PRESENT                      0x01
#define PHY_PARAMETERSCOMMON_DYNAMICPRB_BUNDLINGDL_PRESENT                  0x02
#define PHY_PARAMETERSCOMMON_SP_CSI_REPORTPUCCH_PRESENT                     0x04
#define PHY_PARAMETERSCOMMON_SP_CSI_REPORTPUSCH_PRESENT                     0x08
#define PHY_PARAMETERSCOMMON_NZP_CSI_RS_INTEFMGMT_PRESENT                   0x10
#define PHY_PARAMETERSCOMMON_TYPE2_SP_CSI_FEEDBACK_LONGPUCCH_PRESENT        0x20
#define PHY_PARAMETERSCOMMON_MULTIPLECORESET_PRESENT                        0x40
#define PHY_PARAMETERSCOMMON_DYNAMICSFI_PRESENT                             0x80
#define PHY_PARAMETERSCOMMON_PRECODERGRANULARITYCORESET_PRESENT             0x100
#define PHY_PARAMETERSCOMMON_DYNAMIUINT8Q_ACK_CODEBOOK_PRESENT              0x200
#define PHY_PARAMETERSCOMMON_SEMISTATIUINT8Q_ACK_CODEBOOK_PRESENT           0x400
#define PHY_PARAMETERSCOMMON_SPATIALBUNDLINGHARQ_ACK_PRESENT                0x800
#define PHY_PARAMETERSCOMMON_DYNAMICBETAOFFSETIND_HARQ_ACK_CSI_PRESENT      0x1000
#define PHY_PARAMETERSCOMMON_PUCCH_REPETITION_F1_3_4_PRESENT                0x2000
#define PHY_PARAMETERSCOMMON_RA_TYPE0_PUSCH_PRESENT                         0x4000
#define PHY_PARAMETERSCOMMON_DYNAMICSWITCHRA_TYPE0_1_PDSCH_PRESENT          0x8000
#define PHY_PARAMETERSCOMMON_DYNAMICSWITCHRA_TYPE0_1_PUSCH_PRESENT          0x10000
#define PHY_PARAMETERSCOMMON_PDSCH_MAPPINGTYPEA_PRESENT                     0x20000
#define PHY_PARAMETERSCOMMON_PDSCH_MAPPINGTYPEB_PRESENT                     0x40000
#define PHY_PARAMETERSCOMMON_INTERLEAVINGVRB_TOPRB_PDSCH_PRESENT            0x80000
#define PHY_PARAMETERSCOMMON_INTERLEAVINGVRB_TOPRB_PUSCH_PRESENT            0x100000
#define PHY_PARAMETERSCOMMON_INTERSLOTFREQHOPPING_PUSCH_PRESENT             0x200000
#define PHY_PARAMETERSCOMMON_TYPE1_PUSCH_REPETITIONONESLOT_PRESENT          0x400000
#define PHY_PARAMETERSCOMMON_TYPE1_PUSCH_REPETITIONMULTISLOTS_PRESENT       0x800000
#define PHY_PARAMETERSCOMMON_TYPE2_PUSCH_REPETITIONONESLOT_PRESENT          0x1000000
#define PHY_PARAMETERSCOMMON_TYPE2_PUSCH_REPETITIONMULTISLOTS_PRESENT       0x2000000
#define PHY_PARAMETERSCOMMON_PUSCH_REPETITIONMULTISLOTS_PRESENT             0x4000000
#define PHY_PARAMETERSCOMMON_PDSCH_REPETITIONMULTISLOTS_PRESENT             0x8000000
#define PHY_PARAMETERSCOMMON_DOWNLINKSPS_PRESENT                            0x10000000
#define PHY_PARAMETERSCOMMON_CONFIGUREDUL_GRANTTYPE1_PRESENT                0x20000000
#define PHY_PARAMETERSCOMMON_CONFIGUREDUL_GRANTTYPE2_PRESENT                0x40000000
#define PHY_PARAMETERSCOMMON_PRE_EMPTINDICATION_DL_PRESENT                  0x80000000
#define PHY_PARAMETERSCOMMON_CBG_TRANSINDICATION_PRESENT                    0x100000000
#define PHY_PARAMETERSCOMMON_CBG_FLUSHINDICATION_DL_PRESENT                 0x200000000
#define PHY_PARAMETERSCOMMON_DYNAMIUINT8Q_ACK_CODEB_CBG_RETX_DL_PRESENT     0x400000000
#define PHY_PARAMETERSCOMMON_RATEMATCHINGRESRCSETSEMI_STATIC_PRESENT        0x800000000
#define PHY_PARAMETERSCOMMON_RATEMATCHINGRESRCSETDYNAMIC_PRESENT            0x1000000000
#define PHY_PARAMETERSCOMMON_RATEMATCHINGLTE_CRS_PRESENT                    0x2000000000
#define PHY_PARAMETERSCOMMON_BWP_SWITCHINGDELAY_PRESENT                     0x4000000000
    UInt64 bitmask;  /*^ BITMASK ^*/
    UInt8 cbg_transindication; /*^ O, PHY_PARAMETERSCOMMON_CBG_TRANSINDICATION_PRESENT , N , 0, 0 ^*/ 
    UInt8 bwp_switchingdelay; /*^ O, PHY_PARAMETERSCOMMON_BWP_SWITCHINGDELAY_PRESENT , N , 0, 0 ^*/
}phy_parameterscommon_t;

typedef struct _phy_parametersxdd_diff_t {
#define PHY_PARAMETERSXDD_DIFF_TWOPUCCH_F0_2_CONSECSYMBOLS_PRESENT  0x01
#define PHY_PARAMETERSXDD_DIFF_TWODIFFERENTTPC_LOOP_PUSCH_PRESENT   0x02
#define PHY_PARAMETERSXDD_DIFF_TWODIFFERENTTPC_LOOP_PUCCH_PRESENT   0x04
    UInt8 bitmask;  /*^ BITMASK ^*/
}phy_parametersxdd_diff_t;

typedef struct _phy_parametersfr1_t {
#define PHY_PARAMETERSFR1_PDCCHMONITORINGSINGLEOCCASION_PRESENT     0x01
#define PHY_PARAMETERSFR1_SCS_60KHZ_PRESENT                         0x02
#define PHY_PARAMETERSFR1_PDSCH_256QAM_FR1_PRESENT                  0x04
    UInt8 bitmask;  /*^ BITMASK ^*/
}phy_parametersfr1_t;

typedef struct _phy_parametersfr2_t {
#define PHY_PARAMETERSFR2_CALIBRATIONGAPPA_PRESENT      0x01
    UInt8 bitmask; /*^ BITMASK ^*/ 
    UInt8 calibrationgappa; /*^ O, PHY_PARAMETERSFR2_CALIBRATIONGAPPA_PRESENT , N , 0, 0 ^*/
}phy_parametersfr2_t;

typedef struct _basebandparameterspercc_dl_supportedbandwidthdl_t {
#define BASEBANDPARAMETERSPERCC_DL_SUPPORTEDBANDWIDTHDL_FR1_PRESENT 0x01
#define BASEBANDPARAMETERSPERCC_DL_SUPPORTEDBANDWIDTHDL_FR2_PRESENT 0x02
    UInt8 bitmask; /* Only one bitmask can be set */ /*^ BITMASK ^*/
    UInt8 fr1; /* {mhz5, mhz10, mhz15, mhz20, mhz25, mhz30, mhz40, mhz50, mhz60, mhz80, mhz100} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_SUPPORTEDBANDWIDTHDL_FR1_PRESENT , N , 0, 0 ^*/
    UInt8 fr2; /* {mhz50, mhz100, mhz200, mhz400} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_SUPPORTEDBANDWIDTHDL_FR2_PRESENT , N , 0, 0 ^*/
}basebandparameterspercc_dl_supportedbandwidthdl_t;

typedef struct _basebandparameterspercc_dl_timedurationforqcl_t {
#define BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_SCS_60KHZ_PRESENT     0x01
#define BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_SCH_120KHZ_PRESENT    0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_60khz_t scs_60khz; /* {s7, s14, s28} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    sch_120khz_t sch_120khz; /* {s14, s28} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_SCH_120KHZ_PRESENT , N , 0, 0 ^*/
}basebandparameterspercc_dl_timedurationforqcl_t;

typedef struct _basebandparameterspercc_dl_pdsch_differenttb_perslot_t {
#define BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT      0x01
#define BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT      0x02
#define BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT      0x04
#define BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT     0x08
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_15khz_t      scs_15khz; /* {upto2, upto7} */ /*^ O,BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT , N , 0, 0 ^*/
    scs_30khz_t      scs_30khz; /* {upto2, upto7} */ /*^ O,BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT, N , 0, 0 ^*/
    scs_60khz_t      scs_60khz; /* {upto2, upto7} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT, N , 0, 0 ^*/
    scs_120khz_t     scs_120khz; /* {upto2, upto7} */ /*^ O,BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT , N , 0, 0 ^*/
}basebandparameterspercc_dl_pdsch_differenttb_perslot_t;

typedef struct _basebandparameterspercc_dl_t {
#define BASEBANDPARAMETERSPERCC_DL_SCALINGFACTOR0DOT75_PRESENT              0x01
#define BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_PRESENT               0x02
#define BASEBANDPARAMETERSPERCC_DL_SCELLWITHOUTSSB_PRESENT                  0x04
#define BASEBANDPARAMETERSPERCC_DL_CSI_RS_MEASSCELLWITHOUTSSB_PRESENT       0x08
#define BASEBANDPARAMETERSPERCC_DL_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT        0x10
#define BASEBANDPARAMETERSPERCC_DL_SUPPORTEDMODULATIONORDERDL_PRESENT       0x20
#define BASEBANDPARAMETERSPERCC_DL_SRS_ASSOCCSI_RS_PRESENT                  0x40
#define BASEBANDPARAMETERSPERCC_DL_TYPE1_3_CSS_PRESENT                      0x80
#define BASEBANDPARAMETERSPERCC_DL_PDCCHMONITORINGANYOCCASIONS_PRESENT      0x100
#define BASEBANDPARAMETERSPERCC_DL_UE_SPECIFICUL_DL_ASSIGNMENT_PRESENT      0x200
#define BASEBANDPARAMETERSPERCC_DL_PDSCH_DIFFERENTTB_PERSLOT_PRESENT        0x400
#define BASEBANDPARAMETERSPERCC_DL_CROSSCARRIERSCHEDULING_PRESENT           0x800
#define BASEBANDPARAMETERSPERCC_DL_SEARCHSPACESHARINGCA_DL_PRESENT          0x1000
    UInt16 bitmask; /*^ BITMASK ^*/
    basebandparameterspercc_dl_pdsch_differenttb_perslot_t pdsch_differenttb_perslot; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    basebandparameterspercc_dl_supportedbandwidthdl_t supportedbandwidthdl; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    basebandparameterspercc_dl_timedurationforqcl_t timedurationforqcl; /*^ O,BASEBANDPARAMETERSPERCC_DL_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    mimo_layersdl_t maxnumbermimo_layerspdsch;  /* {twoLayers, fourLayers, eightLayers} */ /*^ O,BASEBANDPARAMETERSPERCC_DL_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT , N , 0, 0 ^*/
    UInt8 supportedsubcarrierspacingdl; /* {kHz15, kHz30, kHz60, kHz120, kHz240, spare3, spare2, spare1} */ /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    UInt8 supportedmodulationorderdl; /* {bpsk-halfpi, bpsk, qpsk, qam16, qam64, qam256} */ /*^ O,BASEBANDPARAMETERSPERCC_DL_SUPPORTEDMODULATIONORDERDL_PRESENT , N , 0, 0 ^*/
    UInt8 pdcchmonitoringanyoccasions; /* {withoutDCI-gap, withDCI-gap} */ /*^ O, BASEBANDPARAMETERSPERCC_DL_PDCCHMONITORINGANYOCCASIONS_PRESENT , N , 0, 0 ^*/ 
}basebandparameterspercc_dl_t;

typedef struct _basebandparametersperbanddl_basebandparameterspercc_dl_t{
    UInt8 count;
    basebandparameterspercc_dl_t nr_rrc_basebandparameterspercc_dl[MAX_NROFSERVINGCELLS];
}basebandparametersperbanddl_basebandparameterspercc_dl_t;

typedef struct _basebandparametersperbanddl_t {
    basebandparametersperbanddl_basebandparameterspercc_dl_t nr_rrc_basebandparametersperbanddl_basebandparameterspercc_dl;
    UInt8 freqrange; /* {fr1, fr2} */
    ca_bandwidthclassnr_t ca_bandwidthclassdl;
}basebandparametersperbanddl_t;

typedef struct _basebandprocessingcombination_basebandparametersdl_t{
    UInt8 count;
    basebandparametersperbanddl_t nr_rrc_basebandparametersperbanddl[MAX_SIMULTANEOUSBANDS];
}basebandprocessingcombination_basebandparametersdl_t;

typedef struct _basebandprocessingcombination_basebandparametersul_t {
    UInt32 numbits;
    UInt8 data[MAX_BASEBANDPROCCOMB_SUL];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}basebandprocessingcombination_basebandparametersul_t;

typedef struct _basebandprocessingcombination_t {
    basebandprocessingcombination_basebandparametersdl_t basebandparametersdl;
    basebandprocessingcombination_basebandparametersul_t basebandparametersul;
} basebandprocessingcombination_t;

typedef struct _supportedbasebandprocessingcombination_t{
    UInt32 count;
    basebandprocessingcombination_t nr_rrc_basebandprocessingcombination[MAX_BASEBANDPROCCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}supportedbasebandprocessingcombination_t;

typedef struct _basebandparameterspercc_ul_supportedbandwidthul_t {
#define BASEBANDPARAMETERSPERCC_UL_SUPPORTEDBANDWIDTHUL_FR1_PRESENT     0x01
#define BASEBANDPARAMETERSPERCC_UL_SUPPORTEDBANDWIDTHUL_FR2_PRESENT     0x02
    UInt8 bitmask; /* Only one bitmask can be set */  /*^ BITMASK ^*/
    UInt8 fr1; /*^ O, BASEBANDPARAMETERSPERCC_UL_SUPPORTEDBANDWIDTHUL_FR1_PRESENT , N , 0, 0 ^*/
    UInt8 fr2; /*^ O, BASEBANDPARAMETERSPERCC_UL_SUPPORTEDBANDWIDTHUL_FR2_PRESENT , N , 0, 0 ^*/ 
}basebandparameterspercc_ul_supportedbandwidthul_t;

typedef struct _srs_resources_t {
    UInt8 maxnumberaperiodicsrs_perbwp;
    UInt8 maxnumberperiodicsrs_perbwp;
    UInt8 maxnumbersemipersitentsrs_perbwp;
    UInt8 maxnumberperiodicsrs_perbwp_perslot;
    UInt8 maxnumbersp_srs_perbwp_perslot;
    UInt8 maxnumberaperiodicsrs_perbwp_perslot;
    UInt8 maxnumbersrs_ports_perresource;
}srs_resources_t;

typedef struct _srs_txswitch_t {
#define SRS_TXSWITCH_TXSWITCHIMPACTTORX_PRESENT     0x01
    UInt8 bitmask; /*^ BITMASK ^*/
    UInt8 supportedsrs_txportswitch; /* {t1r2, t1r4, t2r4, t1r4-t2r4} */ /*^ O, SRS_TXSWITCH_TXSWITCHIMPACTTORX_PRESENT , N , 0, 0 ^*/
}srs_txswitch_t;

typedef struct _basebandparameterspercc_ul_pusch_differenttb_perslot_t {
#define BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT      0x01
#define BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT      0x02
#define BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT      0x04
#define BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT     0x08
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_15khz_t      scs_15khz; /*^ O, BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT , N , 0, 0 ^*/
    scs_30khz_t      scs_30khz; /*^ O, BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT , N , 0, 0 ^*/
    scs_60khz_t      scs_60khz; /*^ O, BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    scs_120khz_t     scs_120khz; /*^ O, BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT , N , 0, 0 ^*/
}basebandparameterspercc_ul_pusch_differenttb_perslot_t;

typedef struct _basebandparameterspercc_ul_t {
#define BASEBANDPARAMETERSPERCC_UL_SCALINGFACTOR0DOT75_PRESENT                  0x01
#define BASEBANDPARAMETERSPERCC_UL_MAXNUMBERMIMO_LAYERSCB_PUSCH_PRESENT         0x02
#define BASEBANDPARAMETERSPERCC_UL_MAXNUMBERMIMO_LAYERSNONCB_PUSCH_PRESENT      0x04
#define BASEBANDPARAMETERSPERCC_UL_SUPPORTEDMODULATIONORDERUL_PRESENT           0x08
#define BASEBANDPARAMETERSPERCC_UL_SUPPORTEDSRS_RESOURCES_PRESENT               0x10
#define BASEBANDPARAMETERSPERCC_UL_SRS_TXSWITCH_PRESENT                         0x20
#define BASEBANDPARAMETERSPERCC_UL_LOWLATENCYCSI_FEEDBACK_PRESENT               0x40
#define BASEBANDPARAMETERSPERCC_UL_PUSCH_DIFFERENTTB_PERSLOT_PRESENT            0x80
#define BASEBANDPARAMETERSPERCC_UL_TWOPUCCH_GROUP_PRESENT                       0x100
#define BASEBANDPARAMETERSPERCC_UL_DIFFNUMEROLOGYACROSSPUCCH_GROUP_PRESENT      0x200
#define BASEBANDPARAMETERSPERCC_UL_DIFFNUMEROLOGYWITHINPUCCH_GROUP_PRESENT      0x400
#define BASEBANDPARAMETERSPERCC_UL_CROSSCARRIERSCHEDULING_PRESENT               0x800
#define BASEBANDPARAMETERSPERCC_UL_SUPPORTEDNUMBERTAG_PRESENT                   0x1000
#define BASEBANDPARAMETERSPERCC_UL_DYNAMICSWITCHSUL_PRESENT                     0x2000
#define BASEBANDPARAMETERSPERCC_UL_SIMULTANEOUSTXSUL_NONSUL_PRESENT             0x4000
#define BASEBANDPARAMETERSPERCC_UL_SEARCHSPACESHARINGCA_UL_PRESENT              0x8000
    UInt16 bitmask;
    basebandparameterspercc_ul_supportedbandwidthul_t supportedbandwidthul;
    mimo_layersul_t maxnumbermimo_layerscb_pusch;
    mimo_layersul_t maxnumbermimo_layersnoncb_pusch;
    srs_resources_t supportedsrs_resources;
    srs_txswitch_t srs_txswitch;
    basebandparameterspercc_ul_pusch_differenttb_perslot_t pusch_differenttb_perslot;
    UInt8 supportedmodulationorderul; /* {bpsk-halfpi, bpsk, qpsk, qam16, qam64, qam256} */
    UInt8 supportedsubcarrierspacingul; /* {kHz15, kHz30, kHz60, kHz120, kHz240, spare3, spare2, spare1} */
    UInt8 supportednumbertag; /* {n2, n3, n4} */
}basebandparameterspercc_ul_t;

typedef struct _basebandparametersperbandul_basebandparameterspercc_ul_t{
    UInt8 count; 
    basebandparameterspercc_ul_t nr_rrc_basebandparameterspercc_ul[MAX_NROFSERVINGCELLS];
}basebandparametersperbandul_basebandparameterspercc_ul_t;

typedef struct _basebandparametersperbandul_t {
    ca_bandwidthclassnr_t ca_bandwidthclassul;
    UInt8 freqrange; /* {fr1, fr2} */
    basebandparametersperbandul_basebandparameterspercc_ul_t basebandparameterspercc_ul;
}basebandparametersperbandul_t;

typedef struct _basebandcombinationparametersul_t{
    UInt8 count;
    basebandparametersperbandul_t nr_rrc_basebandparametersperbandul[MAX_SIMULTANEOUSBANDS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}basebandcombinationparametersul_t;

typedef struct _basebandcombinationparametersul_list_t{
    UInt32 count;
    basebandcombinationparametersul_t nr_rrc_basebandcombinationparametersul[MAX_BASEBANDPROCCOMB];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}basebandcombinationparametersul_list_t;

typedef struct _phy_parametersfrx_diff_t {
#define PHY_PARAMETERSFRX_DIFF_ONEFL_DMRS_TWOADDITIONALDMRS_PRESENT     0x01
#define PHY_PARAMETERSFRX_DIFF_TWOFL_DMRS_PRESENT                       0x02
#define PHY_PARAMETERSFRX_DIFF_TWOFL_DMRS_TWOADDITIONALDMRS_PRESENT     0x04
#define PHY_PARAMETERSFRX_DIFF_ONEFL_DMRS_THREEADDITIONALDMRS_PRESENT   0x08
#define PHY_PARAMETERSFRX_DIFF_SUPPORTEDDMRS_TYPEDL_PRESENT             0x10
#define PHY_PARAMETERSFRX_DIFF_SUPPORTEDDMRS_TYPEUL_PRESENT             0x20
#define PHY_PARAMETERSFRX_DIFF_SEMIOPENLOOPCSI_PRESENT                  0x40
#define PHY_PARAMETERSFRX_DIFF_CSI_REPORTWITHOUTPMI_PRESENT             0x80
#define PHY_PARAMETERSFRX_DIFF_CSI_REPORTWITHCRI_PRESENT                0x100
#define PHY_PARAMETERSFRX_DIFF_CSI_REPORTWITHOUTCQI_PRESENT             0x200
#define PHY_PARAMETERSFRX_DIFF_ONEPORTSPTRS_PRESENT                     0x400
#define PHY_PARAMETERSFRX_DIFF_TWOPUCCH_F0_2_CONSECSYMBOLS_PRESENT      0x800
#define PHY_PARAMETERSFRX_DIFF_PUCCH_F2_WITHFH_PRESENT                  0x1000
#define PHY_PARAMETERSFRX_DIFF_PUCCH_F3_WITHFH_PRESENT                  0x2000
#define PHY_PARAMETERSFRX_DIFF_PUCCH_F4_WITHFH_PRESENT                  0x4000
#define PHY_PARAMETERSFRX_DIFF_FREQHOPPINGPUCCH_F0_2_PRESENT            0x8000
#define PHY_PARAMETERSFRX_DIFF_FREQHOPPINGPUCCH_F1_3_4_PRESENT          0x10000
#define PHY_PARAMETERSFRX_DIFF_MUX_SR_HARQ_ACK_CSI_PUCCH_PRESENT        0x20000
#define PHY_PARAMETERSFRX_DIFF_UCI_CODEBLOCKSEGMENTATION_PRESENT        0x40000
#define PHY_PARAMETERSFRX_DIFF_ONEPUCCH_LONGANDSHORTFORMAT_PRESENT      0x80000
#define PHY_PARAMETERSFRX_DIFF_TWOPUCCH_ANYOTHERSINSLOT_PRESENT         0x100000
#define PHY_PARAMETERSFRX_DIFF_INTRASLOTFREQHOPPING_PUSCH_PRESENT       0x200000
#define PHY_PARAMETERSFRX_DIFF_PUSCH_LBRM_PRESENT                       0x400000
#define PHY_PARAMETERSFRX_DIFF_PDCCH_BLINDDETECTIONCA_PRESENT           0x800000
#define PHY_PARAMETERSFRX_DIFF_TPC_PUSCH_RNTI_PRESENT                   0x1000000
#define PHY_PARAMETERSFRX_DIFF_TPC_PUCCH_RNTI_PRESENT                   0x2000000
#define PHY_PARAMETERSFRX_DIFF_TPC_SRS_RNTI_PRESENT                     0x4000000
#define PHY_PARAMETERSFRX_DIFF_ABSOLUTETPC_COMMAND_PRESENT              0x8000000
#define PHY_PARAMETERSFRX_DIFF_TWODIFFERENTTPC_LOOP_PUSCH_PRESENT       0x10000000
#define PHY_PARAMETERSFRX_DIFF_TWODIFFERENTTPC_LOOP_PUCCH_PRESENT       0x20000000
#define PHY_PARAMETERSFRX_DIFF_PUSCH_HALFPI_BPSK_PRESENT                0x40000000
#define PHY_PARAMETERSFRX_DIFF_PUCCH_F3_4_HALFPI_BPSK_PRESENT           0x80000000
#define PHY_PARAMETERSFRX_DIFF_ONESYMBOLGP_TDD_PRESENT                  0x100000000
#define PHY_PARAMETERSFRX_DIFF_ALMOSTCONTIGUOUSCP_OFDM_UL_PRESENT       0x200000000
    UInt64 bitmask;
    UInt8    onefl_dmrs_twoadditionaldmrs;
    UInt8    twofl_dmrs;
    UInt8    twofl_dmrs_twoadditionaldmrs;
    UInt8    onefl_dmrs_threeadditionaldmrs;
    UInt8    supporteddmrs_typedl;
    UInt8    supporteddmrs_typeul;
    UInt8    oneportsptrs;
}phy_parametersfrx_diff_t;

typedef struct _phy_parameters_t {
#define PHY_PARAMETERS_PHY_PARAMETERSCOMMON_PRESENT         0x01
#define PHY_PARAMETERS_PHY_PARAMETERSXDD_DIFF_PRESENT       0x02
#define PHY_PARAMETERS_PHY_PARAMETERSFRX_DIFF_PRESENT       0x04
#define PHY_PARAMETERS_PHY_PARAMETERSFR1_PRESENT            0x08
#define PHY_PARAMETERS_PHY_PARAMETERSFR2_PRESENT            0x10
    UInt8 bitmask; /*^ BITMASK ^*/
    phy_parameterscommon_t phy_parameterscommon; 
    phy_parametersxdd_diff_t phy_parametersxdd_diff;
    phy_parametersfrx_diff_t phy_parametersfrx_diff;
    phy_parametersfr1_t phy_parametersfr1;
    phy_parametersfr2_t phy_parametersfr2;
    supportedbasebandprocessingcombination_t supportedbasebandprocessingcombination;
    basebandcombinationparametersul_list_t basebandcombinationparametersul_list;
}phy_parameters_t;

typedef struct _mimo_parametersperband_timedurationforqcl_t {
#define MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_SCS_60KHZ_PRESENT     0x01
#define MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_SCH_120KHZ_PRESENT    0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_60khz_t  scs_60khz; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    sch_120khz_t sch_120khz; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_SCH_120KHZ_PRESENT , N , 0, 0 ^*/
}mimo_parametersperband_timedurationforqcl_t;

typedef struct _beammanagementssb_csi_rs_t {
    UInt8 maxnumberssb_csi_rs_resourceonetx;
    UInt8 maxnumberssb_csi_rs_resourcetwotx;
    UInt8 supportedcsi_rs_density;
}beammanagementssb_csi_rs_t;

typedef struct _mimo_parametersperband_maxnumberrxtxbeamswitchdl_t {
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_15KHZ_PRESENT      0x01
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_30KHZ_PRESENT      0x02
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_60KHZ_PRESENT      0x04
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_120KHZ_PRESENT     0x08
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_240KHZ_PRESENT     0x10
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_15khz_t      scs_15khz;  /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_15KHZ_PRESENT, N , 0, 0 ^*/
    scs_30khz_t      scs_30khz; /*^ O,  MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_30KHZ_PRESENT , N , 0, 0 ^*/
    scs_60khz_t      scs_60khz; /*^ O,  MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    scs_120khz_t     scs_120khz; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_120KHZ_PRESENT , N , 0, 0 ^*/
    scs_240khz_t     scs_240khz; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_SCS_240KHZ_PRESENT , N , 0, 0 ^*/ 
}mimo_parametersperband_maxnumberrxtxbeamswitchdl_t;

typedef struct _mimo_parametersperband_uplinkbeammanagement_t {
    UInt8 maxnumbersrs_resourceperset;
    UInt8 maxnumbersrs_resourceset;
}mimo_parametersperband_uplinkbeammanagement_t;

typedef struct _mimo_parametersperband_t {
#define MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT                   0x01
#define MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT            0x02
#define MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSCB_PUSCH_PRESENT         0x04
#define MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSNONCB_PUSCH_PRESENT      0x08
#define MIMO_PARAMETERSPERBAND_MAXNUMBERCONFIGUREDTCISTATES_PRESENT         0x10
#define MIMO_PARAMETERSPERBAND_MAXNUMBERACTIVETCI_PERCC_PRESENT             0x20
#define MIMO_PARAMETERSPERBAND_PUSCH_TRANSCOHERENCE_PRESENT                 0x40
#define MIMO_PARAMETERSPERBAND_BEAMCORRESPONDENCE_PRESENT                   0x80
#define MIMO_PARAMETERSPERBAND_PERIODICBEAMREPORT_PRESENT                   0x100
#define MIMO_PARAMETERSPERBAND_APERIODICBEAMREPORT_PRESENT                  0x200
#define MIMO_PARAMETERSPERBAND_SP_BEAMREPORTPUCCH_PRESENT                   0x400
#define MIMO_PARAMETERSPERBAND_SP_BEAMREPORTPUSCH_PRESENT                   0x800
#define MIMO_PARAMETERSPERBAND_BEAMMANAGEMENTSSB_CSI_RS_PRESENT             0x1000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXBEAM_PRESENT                      0x2000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_PRESENT            0x4000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERNONGROUPBEAMREPORTING_PRESENT       0x8000
#define MIMO_PARAMETERSPERBAND_GROUPBEAMREPORTING_PRESENT                   0x10000
#define MIMO_PARAMETERSPERBAND_UPLINKBEAMMANAGEMENT_PRESENT                 0x20000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERCSI_RS_BFR_PRESENT                   0x40000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERSSB_BFR_PRESENT                     0x80000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERCSI_RS_SSB_BFR_PRESENT              0x100000
#define MIMO_PARAMETERSPERBAND_TWOPORTSPTRS_PRESENT                         0x200000
#define MIMO_PARAMETERSPERBAND_SUPPORTEDSRS_RESOURCES_PRESENT               0x400000
#define MIMO_PARAMETERSPERBAND_SRS_TXSWITCH_PRESENT                         0x800000
#define MIMO_PARAMETERSPERBAND_MAXNUMBERSIMULTANEOUSSRS_PERCC_PRESENT       0x1000000
#define MIMO_PARAMETERSPERBAND_LOWLATENCYCSI_FEEDBACK_PRESENT               0x2000000
    UInt32 bitmask; /*^ BITMASK ^*/
    mimo_parametersperband_timedurationforqcl_t timedurationforqcl; /*^ O, MIMO_PARAMETERSPERBAND_TIMEDURATIONFORQCL_PRESENT , N , 0, 0 ^*/
    mimo_layersdl_t maxnumbermimo_layerspdsch; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSPDSCH_PRESENT , N , 0, 0 ^*/
    mimo_layersul_t maxnumbermimo_layerscb_pusch; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSCB_PUSCH_PRESENT , N , 0, 0 ^*/
    mimo_layersul_t maxnumbermimo_layersnoncb_pusch; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERMIMO_LAYERSNONCB_PUSCH_PRESENT , N , 0, 0 ^*/
    beammanagementssb_csi_rs_t beammanagementssb_csi_rs; /*^ O,MIMO_PARAMETERSPERBAND_BEAMMANAGEMENTSSB_CSI_RS_PRESENT , N , 0, 0 ^*/
    mimo_parametersperband_maxnumberrxtxbeamswitchdl_t maxnumberrxtxbeamswitchdl; /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERRXTXBEAMSWITCHDL_PRESENT , N , 0, 0 ^*/
    mimo_parametersperband_uplinkbeammanagement_t uplinkbeammanagement; /*^ O,MIMO_PARAMETERSPERBAND_UPLINKBEAMMANAGEMENT_PRESENT , N , 0, 0 ^*/
    srs_resources_t supportedsrs_resources; /*^ O, MIMO_PARAMETERSPERBAND_SUPPORTEDSRS_RESOURCES_PRESENT , N , 0, 0 ^*/
    srs_txswitch_t srs_txswitch; /*^ O, MIMO_PARAMETERSPERBAND_SRS_TXSWITCH_PRESENT , N , 0, 0 ^*/
    UInt16 maxnumbercsi_rs_ssb_bfr; /* (1..256) */ /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERCSI_RS_SSB_BFR_PRESENT , N , 0, 0 ^*/
    UInt8           maxnumberconfiguredtcistates; /* {n4, n8, n16, n32, n64} */ /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERCONFIGUREDTCISTATES_PRESENT , N , 0, 0 ^*/
    UInt8           maxnumberactivetci_percc; /* {n1, n2, n4, n8} */ /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERACTIVETCI_PERCC_PRESENT , N , 0, 0 ^*/
    UInt8           pusch_transcoherence; /* {nonCoherent, partialNonCoherent, fullCoherent} */ /*^ O,MIMO_PARAMETERSPERBAND_PUSCH_TRANSCOHERENCE_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumbernongroupbeamreporting; /* {n1, n2, n4}	*/ /*^ O,MIMO_PARAMETERSPERBAND_MAXNUMBERNONGROUPBEAMREPORTING_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumbercsi_rs_bfr; /* (1..64) */ /*^ O, MIMO_PARAMETERSPERBAND_BEAMMANAGEMENTSSB_CSI_RS_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumberssb_bfr; /* (1..64) */ /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERSSB_BFR_PRESENT , N , 0, 0 ^*/
    UInt8 twoportsptrs; /*^ O,MIMO_PARAMETERSPERBAND_TWOPORTSPTRS_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumbersimultaneoussrs_percc; /* (1..4)	*/ /*^ O,MIMO_PARAMETERSPERBAND_MAXNUMBERSIMULTANEOUSSRS_PERCC_PRESENT , N , 0, 0 ^*/
    UInt8 maxnumberrxbeam; /* (2..8) */ /*^ O, MIMO_PARAMETERSPERBAND_MAXNUMBERRXBEAM_PRESENT , N , 0, 0 ^*/
}mimo_parametersperband_t;

typedef struct _bandnr_pdsch_differenttb_perslot_t {
#define BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT      0x01
#define BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT      0x02
#define BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT      0x04
#define BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT     0x08
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_15khz_t      scs_15khz; /*^ O, BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT , N , 0, 0 ^*/
    scs_30khz_t      scs_30khz; /*^ O, BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT , N , 0, 0 ^*/
    scs_60khz_t      scs_60khz; /*^ O, BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    scs_120khz_t     scs_120khz; /*^ O, BANDNR_PDSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT , N , 0, 0 ^*/ 
}bandnr_pdsch_differenttb_perslot_t;

typedef struct _bandnr_pusch_differenttb_perslot_t {
#define BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT  0x01
#define BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT  0x02
#define BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT  0x04
#define BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT 0x08
    UInt8 bitmask; /*^ BITMASK ^*/
    scs_15khz_t      scs_15khz; /*^ O, BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_15KHZ_PRESENT , N , 0, 0 ^*/
    scs_30khz_t      scs_30khz; /*^ O, BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_30KHZ_PRESENT , N , 0, 0 ^*/
    scs_60khz_t      scs_60khz; /*^ O, BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_60KHZ_PRESENT , N , 0, 0 ^*/
    scs_120khz_t     scs_120khz;/*^ O, BANDNR_PUSCH_DIFFERENTTB_PERSLOT_SCS_120KHZ_PRESENT , N , 0, 0 ^*/
}bandnr_pusch_differenttb_perslot_t;

typedef struct _bandnr_t {
#define BANDNR_MODIFIEDMPR_BEHAVIOUR_PRESENT            0x01
#define BANDNR_MAXCHANNELBW_PERCC_PRESENT               0x02
#define BANDNR_MIMO_PARAMETERSPERBAND_PRESENT           0x04
#define BANDNR_EXTENDEDCP_PRESENT                       0x08
#define BANDNR_PHASECOHERENCEUL_PRESENT                 0x10
#define BANDNR_SCELLWITHOUTSSB_PRESENT                  0x20
#define BANDNR_CSI_RS_MEASSCELLWITHOUTSSB_PRESENT       0x40
#define BANDNR_SRS_ASSOCCSI_RS_PRESENT                  0x80
#define BANDNR_TYPE1_3_CSS_PRESENT                      0x100
#define BANDNR_MULTIPLETCI_PRESENT                      0x200
#define BANDNR_PDCCHMONITORINGANYOCCASIONS_PRESENT      0x400
#define BANDNR_UE_SPECIFICUL_DL_ASSIGNMENT_PRESENT      0x800
#define BANDNR_PDSCH_DIFFERENTTB_PERSLOT_PRESENT        0x1000
#define BANDNR_PUSCH_DIFFERENTTB_PERSLOT_PRESENT        0x2000
#define BANDNR_BWP_SAMENUMEROLOGY_PRESENT               0x4000
#define BANDNR_BWP_DIFFNUMEROLOGY_PRESENT               0x8000
#define BANDNR_TWOPUCCH_GROUP_PRESENT                   0x10000
#define BANDNR_DIFFNUMEROLOGYACROSSPUCCH_GROUP_PRESENT  0x20000
#define BANDNR_DIFFNUMEROLOGYWITHINPUCCH_GROUP_PRESENT  0x40000
#define BANDNR_CROSSCARRIERSCHEDULING_PRESENT           0x80000
#define BANDNR_SUPPORTEDNUMBERTAG_PRESENT               0x100000
#define BANDNR_SIMULTANEOUSTXSUL_NONSUL_PRESENT         0x200000
#define BANDNR_SEARCHSPACESHARINGCA_DL_PRESENT          0x400000
#define BANDNR_SEARCHSPACESHARINGCA_UL_PRESENT          0x800000
#define BANDNR_PDSCH_256QAM_FR2_PRESENT                 0x1000000
#define BANDNR_PUSCH_256QAM_PRESENT                     0x2000000
    UInt32 bitmask;  /*^ BITMASK ^*/
    mimo_parametersperband_t mimo_parametersperband; /*^ O, BANDNR_MIMO_PARAMETERSPERBAND_PRESENT , N , 0, 0 ^*/
    bandnr_pdsch_differenttb_perslot_t pdsch_differenttb_perslot; /*^ O, BANDNR_PDSCH_DIFFERENTTB_PERSLOT_PRESENT , N , 0, 0 ^*/
    bandnr_pusch_differenttb_perslot_t pusch_differenttb_perslot; /*^ O, BANDNR_PUSCH_DIFFERENTTB_PERSLOT_PRESENT , N , 0, 0 ^*/
    UInt16 bandnr; /*^ O,BANDNR_PUSCH_DIFFERENTTB_PERSLOT_PRESENT , N , 0, 0 ^*/
    UInt8 modifiedmpr_behaviour; /*^ O, BANDNR_MODIFIEDMPR_BEHAVIOUR_PRESENT , N , 0, 0 ^*/
    UInt8 maxchannelbw_percc; /*^ O, BANDNR_MAXCHANNELBW_PERCC_PRESENT , N , 0, 0 ^*/
    UInt8 pdcchmonitoringanyoccasions; /*^ O, BANDNR_PDCCHMONITORINGANYOCCASIONS_PRESENT , N , 0, 0 ^*/
    UInt8 bwp_samenumerology; /*^ O, BANDNR_BWP_SAMENUMEROLOGY_PRESENT , N , 0, 0 ^*/
    UInt8 bwp_diffnumerology; /*^ O, BANDNR_BWP_DIFFNUMEROLOGY_PRESENT , N , 0, 0 ^*/
    UInt8 supportednumbertag; /*^ O, BANDNR_SUPPORTEDNUMBERTAG_PRESENT , N , 0, 0 ^*/
}bandnr_t;

typedef struct _supportedbandlistnr_t{
    UInt16 count;
    bandnr_t nr_rrc_bandnr[MAX_BANDS];
}supportedbandlistnr_t;

typedef struct _rf_parameters_capability_t {
    supportedbandlistnr_t supportedbandlistnr;
    bandcombinationlist_t supportedbandcombination;
    bandcombinationparametersul_list_t bandcombinationparametersul_list;
}rf_parameters_capability_t;

typedef struct _measparametersxdd_diff_t {
#define MEASPARAMETERSXDD_DIFF_INTRAANDINTERF_MEASANDREPORT_PRESENT     0x01
#define MEASPARAMETERSXDD_DIFF_EVENTA_MEASANDREPORT_PRESENT             0x02
    UInt8 bitmask; /*^ BITMASK ^*/
}measparametersxdd_diff_t;  

typedef struct _measparametersfrx_diff_t {
#define MEASPARAMETERSFRX_DIFF_SS_SINR_MEAS_PRESENT                     0x01
#define MEASPARAMETERSFRX_DIFF_CSI_RSRP_ANDRSRQ_MEASWITHSSB_PRESENT     0x02
#define MEASPARAMETERSFRX_DIFF_CSI_RSRP_ANDRSRQ_MEASWITHOUTSSB_PRESENT   0x04
#define MEASPARAMETERSFRX_DIFF_CSI_SINR_MEAS_PRESENT                    0x08
#define MEASPARAMETERSFRX_DIFF_CSI_RS_RLM_PRESENT                       0x10
    UInt8 bitmask;  /*^ BITMASK ^*/
}measparametersfrx_diff_t;

typedef struct _measparameters_t {
#define MEASPARAMETERS_MEASPARAMETERSXDD_DIFF_PRESENT       0x01
#define MEASPARAMETERS_MEASPARAMETERSFRX_DIFF_PRESENT       0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    measparametersxdd_diff_t measparametersxdd_diff; /*^ O, MEASPARAMETERS_MEASPARAMETERSXDD_DIFF_PRESENT , N , 0, 0 ^*/
    measparametersfrx_diff_t measparametersfrx_diff; /*^ O, MEASPARAMETERS_MEASPARAMETERSFRX_DIFF_PRESENT , N , 0, 0 ^*/
}measparameters_t;

typedef struct _ue_nr_capabilityaddxdd_mode_t {
#define UE_NR_CAPABILITYADDXDD_MODE_PHY_PARAMETERSXDD_DIFF_PRESENT      0x01
#define UE_NR_CAPABILITYADDXDD_MODE_MAC_PARAMETERSXDD_DIFF_PRESENT      0x02
#define UE_NR_CAPABILITYADDXDD_MODE_MEASPARAMETERSXDD_DIFF_PRESENT      0x04
    UInt8 bitmask; /*^ BITMASK ^*/
    phy_parametersxdd_diff_t phy_parametersxdd_diff; /*^ O, UE_NR_CAPABILITYADDXDD_MODE_PHY_PARAMETERSXDD_DIFF_PRESENT , N , 0, 0 ^*/
    mac_parametersxdd_diff_t mac_parametersxdd_diff; /*^ O, UE_NR_CAPABILITYADDXDD_MODE_MAC_PARAMETERSXDD_DIFF_PRESENT , N , 0, 0 ^*/
    measparametersxdd_diff_t measparametersxdd_diff; /*^ O, UE_NR_CAPABILITYADDXDD_MODE_MEASPARAMETERSXDD_DIFF_PRESENT , N , 0, 0 ^*/ 
}ue_nr_capabilityaddxdd_mode_t;

typedef struct _ue_nr_capabilityaddfrx_mode_t {
#define UE_NR_CAPABILITYADDFRX_MODE_PHY_PARAMETERSFRX_DIFF_PRESENT      0x01
#define UE_NR_CAPABILITYADDFRX_MODE_MEASPARAMETERSFRX_DIFF_PRESENT      0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    phy_parametersfrx_diff_t phy_parametersfrx_diff; /*^ O, UE_NR_CAPABILITYADDFRX_MODE_PHY_PARAMETERSFRX_DIFF_PRESENT , N , 0, 0 ^*/
    measparametersfrx_diff_t measparametersfrx_diff; /*^ O, UE_NR_CAPABILITYADDFRX_MODE_PHY_PARAMETERSFRX_DIFF_PRESENT , N , 0, 0 ^*/
}ue_nr_capabilityaddfrx_mode_t;

typedef struct _ue_nr_capability_t {
#define UE_NR_CAPABILITY_RLC_PARAMETERS_PRESENT                     0x01
#define UE_NR_CAPABILITY_MAC_PARAMETERS_PRESENT                     0x02
#define UE_NR_CAPABILITY_MEASPARAMETERS_PRESENT                     0x04
#define UE_NR_CAPABILITY_FDD_ADD_UE_NR_CAPABILITIES_PRESENT         0x08
#define UE_NR_CAPABILITY_TDD_ADD_UE_NR_CAPABILITIES_PRESENT         0x10
#define UE_NR_CAPABILITY_FR1_ADD_UE_NR_CAPABILITIES_PRESENT         0x20
#define UE_NR_CAPABILITY_FR2_ADD_UE_NR_CAPABILITIES_PRESENT         0x40
    UInt8 bitmask; /*^ BITMASK ^*/
    pdcp_capability_parameters_t pdcp_parameters;
    rlc_parameters_t rlc_parameters; /*^ O, UE_CAPABILITYRAT_CONTAINER_UE_MRDC_PRESENT , N , 0, 0 ^*/
    mac_parameters_t mac_parameters; /*^ O, UE_CAPABILITYRAT_CONTAINER_UE_MRDC_PRESENT , N , 0, 0 ^*/
    phy_parameters_t phy_parameters;
    rf_parameters_capability_t rf_parameters;
    measparameters_t measparameters; /*^ O, UE_CAPABILITYRAT_CONTAINER_UE_MRDC_PRESENT , N , 0, 0 ^*/
    ue_nr_capabilityaddxdd_mode_t fdd_add_ue_nr_capabilities; /*^ O, UE_NR_CAPABILITY_FDD_ADD_UE_NR_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_nr_capabilityaddxdd_mode_t tdd_add_ue_nr_capabilities; /*^ O, UE_NR_CAPABILITY_TDD_ADD_UE_NR_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_nr_capabilityaddfrx_mode_t fr1_add_ue_nr_capabilities; /*^ O, UE_NR_CAPABILITY_FR1_ADD_UE_NR_CAPABILITIES_PRESENT , N , 0, 0 ^*/
    ue_nr_capabilityaddfrx_mode_t fr2_add_ue_nr_capabilities; /*^ O, UE_NR_CAPABILITY_FR2_ADD_UE_NR_CAPABILITIES_PRESENT  , N , 0, 0 ^*/
}ue_nr_capability_t;

typedef struct _ue_capabilityrat_container_t{
#define UE_CAPABILITYRAT_CONTAINER_UE_MRDC_PRESENT      0x01
#define UE_CAPABILITYRAT_CONTAINER_UE_NR_PRESENT        0x02
    UInt8 bitmask; /*^ BITMASK ^*/
    ue_mrdc_capability_t ue_mrdc; /*^ O, UE_CAPABILITYRAT_CONTAINER_UE_MRDC_PRESENT , N , 0, 0 ^*/
    ue_nr_capability_t   ue_nr; /*^ O, UE_CAPABILITYRAT_CONTAINER_UE_NR_PRESENT , N , 0, 0 ^*/
}ue_capabilityrat_container_t;
#endif
