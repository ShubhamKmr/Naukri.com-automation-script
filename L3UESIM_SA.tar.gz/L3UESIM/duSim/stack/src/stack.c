/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>

/* Project includes */
#include "stack.h"
#include "proto_sim.h"
#include "proto_stack.h"
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "globalContext.h"


/* This function initializes the DU simulator */
sim_return_val_et init_du_sim_stack(void* data)
{
    LOG_TRACE("DU SIM stack initialization function invoked \n");
    return SIM_SUCCESS;
}


/* This function will forward the message to stack application */
void forward_msg_to_stack_app(
        void*         msgBuf,
        unsigned int  msgLen)
{
    proto_simulator_t* du_sim    = NULL;
    stack_app_t*       stack_app = NULL;

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch peer connection handler */
    stack_app = get_proto_stack_app(du_sim);
    if (NULL == stack_app)
    {
        LOG_TRACE("Failed to fetch DU SIM stack app\n");
        return;
    }

    /* Invoke the send callback registered by 
     * peer connection handler. */
    stack_app->stack_msg_hdlr(msgBuf, msgLen);

    LOG_TRACE("Successfully forwarded msg from stack to stack app, len:%d \n", msgLen);
}


/* This function processes the message received from eNB */
void process_du_sim_peer_msg(
        void*         msg, 
        unsigned int  msgLen)
{
    LOG_TRACE("Process message received from protocol peer \n");

    forward_msg_to_stack_app(msg, msgLen);
}

#if 0
/* This function will send message to Peer */
void forward_msg_to_peer(
        socket_config_t*  sockConfig,
        void*             apiBuf,
        unsigned short    apiLen)
{
    proto_simulator_t* du_sim    = NULL;
    peer_conn_hdlr_t*  conn_hdlr = NULL;

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

#if 0
    /* TODO : Need to FIX this */
    /* Fetch peer connection handler */
    conn_hdlr = get_proto_peer_conn_hdlr(
                            du_sim,
                            sockConfig->sockFd);
#endif
    if (NULL == conn_hdlr)
    {
        LOG_TRACE("Failed to fetch connection handler for FD: %d\n", 
                  sockConfig->sockFd);
        return;
    }

    /* Invoke the send callback registered by 
     * peer connection handler. */
    conn_hdlr->send(sockConfig, apiBuf, apiLen);
}

#endif

/* This function processes the message received from user */
void process_du_sim_user_msg(void* apiBuf, unsigned int apiLen)
{
    LOG_TRACE("API received from stack app for destination\n");
}


/* This function resets the DU simulator stack */
void reset_du_sim_stack()
{
    LOG_TRACE("DU SIM stack Reset \n");
}


/* This function creates and return protocol stack for DU Sim */
proto_stack_t* create_du_sim_stack()
{
    proto_stack_t*  stack = NULL;

    /* Allocate stack for DU simulator */
    stack = allocate_new_protocol_stack();
    if (NULL == stack)
    {
        LOG_TRACE("Failed to allocate stack for DU sim\n");
        return stack;
    }

    memset(stack, 0, sizeof(proto_stack_t));

    /* Initialize the function pointers of stack */
    stack->init          = init_du_sim_stack;
    stack->peer_msg_hdlr = process_du_sim_peer_msg;
    stack->user_msg_hdlr = process_du_sim_user_msg;

    return stack;
}
