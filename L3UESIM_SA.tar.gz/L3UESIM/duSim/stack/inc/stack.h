#include "proto_stack.h"


/* This function creates and return protocol stack for DU Sim */
proto_stack_t* create_du_sim_stack();


/* This function initializes the DU simulator */
//void init_du_sim_stack(void* data);


/* This function processes the message received from eNB */
void process_du_sim_peer_msg(void* msg, unsigned int msgLen);


/* This function processes the message received from user */
void process_du_sim_user_msg(void* msg, unsigned int msgLen);


/* This function resets the UE simulator stack */
void reset_du_sim_stack();
