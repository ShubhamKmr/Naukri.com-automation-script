#ifndef _DUSIM_CMD_STRUCTURE_H_
#define _DUSIM_CMD_STRUCTURE_H_

/* Structure defining the header of messages exchanged 
 * between DU simulator and its user. */
typedef struct
{
    /* API Identifier */
    unsigned short apiId;

    /* DU identifier. In case of non DU specific API
     * receiving entity is not supposed to interpret it. */
    unsigned short du_id;

    /* Length of the message (including header) */
    unsigned int   length;

    /* Unique UE identifier. In case of non UE specific API
     * receiving entity is not supposed to interpret it. */
    unsigned int   imsi;

} dusim_user_intf_hdr_t;


/* Structure defining the content of message from user
 * to DU simulator. */
typedef struct
{
    /* Message header */
    dusim_user_intf_hdr_t  header;

    /* Message body */
    unsigned char          msgBuf[1];

} dusim_user_data_req_t;


/* Structure defining the content of message from DU  
 * simulator to its user. */
typedef struct
{
    /* Message header */
    dusim_user_intf_hdr_t  header;

    /* Message body */
    unsigned char          msgBuf[1];

} dusim_user_data_ind_t;


#endif   // _DUSIM_CMD_STRUCTURE_H_
