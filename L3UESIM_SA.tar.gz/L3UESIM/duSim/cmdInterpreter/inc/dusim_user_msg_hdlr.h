

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "lteTypes.h"
//#include "sim_defs.h"
#include "dusim_cmd_interpreter.h"
#include "typedefs.h"
#include "dusim_cmd_defs.h"
#include "dusim_cmd_structure.h"
#include "du_sim_event.h"

#include "proto_stack_app.h"
#include "proto_sim.h"
#include "globalContext.h"


/* This function handle DU Reset Response received 
 * from user. */
void handle_outgoing_du_reset_resp(
        unsigned short du_id, 
        unsigned int   msgLen, 
        unsigned char* msgBuf);


/* This function handle Error Indication received 
 * from user. */
void handle_outgoing_error_indication(
    unsigned int   imsi, 
    unsigned short du_id, 
    unsigned int   msgLen, 
    unsigned char* msgBuf);


/* This function handle DU Reset Request received 
 * from user. */
void handle_outgoing_du_reset_req(
        unsigned short du_id,
        unsigned int   msgLen, 
        unsigned char* msgBuf);


/* This function handle DU Setup Response received 
 * from user. */
void handle_outgoing_f1setup_resp(
                unsigned int   msgLen, 
                unsigned char* msgBuf,
                unsigned short du_id);


/* This function handles eNB configuration request received
 * from user. */
void handle_configure_du_req(
                unsigned int    msgLen,
                unsigned char*  msgBuf);


/* This function handles connection initiation request
 * received from user. */
void duSim_handle_conn_initiation_req(
                unsigned short  du_id);


/* This function handles connection reset request
 * received from user. */
void handle_conn_reset_req(
                unsigned short du_id);


/* This function process the command received from user */ 
void dusim_process_user_command(
                unsigned short apiId,
                unsigned int   imsi,
                unsigned short du_id,
                unsigned int   msgLen,
                unsigned char* msgBuf);

