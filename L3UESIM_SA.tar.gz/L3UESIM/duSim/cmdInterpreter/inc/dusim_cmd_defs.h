#ifndef _DUSIM_CMD_DEFS_H_
#define _DUSIM_CMD_DEFS_H_
#define MAX_SUPPORTED_DU_SCTP 32 //SCTP Changes
//#include "F1AP.h"
#include "du_sim_common.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"
/* Enum defining the APIs which can be sent from user 
 * to DU sim */
typedef enum
{
    DUSIM_CONFIGURE_DU_REQ = 1,
    DUSIM_CONN_INITIATION_REQ,
    DUSIM_CONN_RESET_REQ,
    DUSIM_F1SETUP_REQ,
    DUSIM_GNB_DU_CONFIG_UPDATE,
    DUSIM_GNB_CU_CONFIG_UPDATE_ACK,
    DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE,
    DUSIM_UL_RRC_MSG_REQ,
    DUSIM_UE_CTX_SETUP_RESP,
    DUSIM_UE_CTX_SETUP_FAILURE,
    DUSIM_DU_INIT_UE_CTX_REL_REQ,
    DUSIM_CU_INIT_UE_CTX_REL_COMPLETE,
    DUSIM_UE_CTX_MOD_REQUIRED,
    DUSIM_UE_CTX_MOD_RESP,
    DUSIM_UE_CTX_MOD_FAILURE,
    DUSIM_F1_UL_RRC_MSG_TRANSFER,    //UL RRC TRANSFER change
   // DUSIM_F1_DL_RRC_MSG_TRANSFER,     //DL RRC TRANSFER change
    DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER, /* INIT UL RRC MSG TRANS */
    DUSIM_UE_CTX_REL_REQ,
    DUSIM_LAST_USER_TO_SIM_API
} user_to_dusim_api_et; 


/* Enum defining the APIs which can be sent from DU 
 * sim to user */
typedef enum
{
    DUSIM_CONFIGURE_DU_RESP = DUSIM_LAST_USER_TO_SIM_API,
    DUSIM_SCTP_LINK_STATUS_IND,
    DUSIM_F1SETUP_RESP,
    DUSIM_F1SETUP_FAILURE,
    DUSIM_GNB_DU_CONFIG_UPDATE_ACK,
    DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE,
    DUSIM_GNB_CU_CONFIG_UPDATE,
    DUSIM_DL_RRC_MSG_IND,
    DUSIM_UE_CTX_SETUP_REQ,
    DUSIM_CU_INIT_UE_CTX_REL_CMD,
    DUSIM_UE_CTX_MOD_CONFIRM,
    DUSIM_UE_CTX_MOD_REQUEST,
    DUSIM_F1_RESET_REQ,
    DUSIM_DL_RRC_MSG_TRANSFER,/*DL RRC Transfer Changes*/
    DUSIM_F1_DL_RRC_MSG_TRANSFER,
    DUSIM_LAST_SIM_TO_USER_API
} dusim_to_user_api_et;


/* Enum defining the APIs which can be sent from DU sim 
 * to user and vice versa. */
typedef enum
{
    DUSIM_RESET_REQ = DUSIM_LAST_SIM_TO_USER_API,
    DUSIM_RESET_RESP,
    DUSIM_ERROR_INDICATION,
    DUSIM_INVALID_API_ID
} dusim_user_bidirectional_api_et;


/************************************************************* 
 * USER to DU SIM APIs 
 ************************************************************/


/* Structure defining the content of API used for adding a new
 * DU at DUSIM which will be used for testing a gNB-CU. */
typedef struct
{
    /* SCTP Communication information of local DU */
    dusim_sctp_comm_info_t      du_comm_info;

    /* SCTP Communication information of gNB-CU */
    dusim_sctp_comm_info_t      cu_comm_info;

    /* Flag to indicate whether explicit start is required
     * or not. If flag is set to true, explicit APIs are
     * needed to trigger connection initiation or connection
     * listening. */
    bool                        explicit_start_required;

} dusim_configure_du_req_t;  /* DUSIM_CONFIGURE_DU_REQ */

//SCTP Changes
/* Structure defining the Global Multiple DU Configuration */
typedef struct
{
    /* Number of DU's configured with CU */
    unsigned short              numConn;

    /* List containing the DU(s) Configuration */
    dusim_configure_du_req_t du_configuration[MAX_SUPPORTED_DU_SCTP];

} dusim_du_config_t;


/* Structure defining the content of F1 Setup Request */
typedef struct 
{
    _f1ap_F1SetupRequest  message;

} dusim_f1_setup_req_t;   /* DUSIM_F1SETUP_REQ */

//UL RRC TRANSFER change
/* Structure defining the content of F1 UL RRC Message Transfer */
typedef struct 
{
    _f1ap_ULRRCMessageTransfer  message;

} dusim_f1_ul_rrc_msg_transfer_t;   /* DUSIM_F1_UL_RRC_MSG_TRANSFER */

typedef struct 
{
    _f1ap_DLRRCMessageTransfer  message;

} dusim_f1_dl_rrc_msg_transfer_t;   /* DUSIM_F1_DL_RRC_MSG_TRANSFER */


/* Structure defining the content of DU Configuration update */
typedef struct 
{
    _f1ap_GNBDUConfigurationUpdate  message;

} dusim_du_config_update_t;  /* DUSIM_GNB_DU_CONFIG_UPDATE */

typedef struct 
{
    _f1ap_Reset  message;

} dusim_du_reset_req_t;  /* DUSIM_F1_RESET_REQ */





/* Structure defining the content of CU configuration update */
typedef struct 
{
    f1ap_adpt_cu_config_update_resp_t  message;

} dusim_cu_config_update_ack_t;  /* DUSIM_GNB_CU_CONFIG_UPDATE_ACK */


/* Structure defining the content of CU configuration 
 * update failure */
typedef struct 
{
    _f1ap_GNBCUConfigurationUpdateFailure  message;

} dusim_cu_config_update_failure_t;  /* DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE */


/* Structure defining the content of UL RRC message request */
typedef struct 
{
    _f1ap_ULRRCMessageTransfer  message;

} dusim_ul_rrc_msg_req_t;  /* DUSIM_UL_RRC_MSG_REQ */


/* Structure defining the content of UE context setup response */
typedef struct 
{
    f1ap_adpt_ue_context_setup_resp_t  message;

} dusim_ue_ctx_setup_resp_t; /* DUSIM_UE_CTX_SETUP_RESP */


/* Structure defining the content of UE context setup failure */
typedef struct 
{
    f1ap_adpt_ue_context_setup_fail_t  message;

} dusim_ue_ctx_setup_failure_t; /* DUSIM_UE_CTX_SETUP_FAILURE */


/* Structure defining the content of UE context modification failure */
typedef struct
{
	f1ap_adpt_ue_context_mod_fail_t    message;

}dusim_ue_ctx_mod_failure_t;  /* DUSIM_UE_CTX_MOD_FAILURE */


/* Structure defining the contet of DU initiated UE context
 * release request API */
typedef struct 
{
  //  _f1ap_UEContextReleaseRequest  message;

} dusim_du_init_ue_ctx_rel_req_t;  /* DUSIM_DU_INIT_UE_CTX_REL_REQ */


/* Structure defining the contet of CU initiated UE context
 * release complete API */
typedef struct 
{
    f1ap_adpt_ue_context_rel_complete_t  message;

} dusim_cu_init_ue_ctx_rel_comp_t;  /* DUSIM_CU_INIT_UE_CTX_REL_COMPLETE */

#if 0
/* Structure defining the contet of UE context modification 
 * required API */
typedef struct 
{
    _f1ap_UEContextModificationRequired  message;

} dusim_du_init_ue_ctx_mod_required_t;  /* DUSIM_UE_CTX_MOD_REQUIRED */

#endif

/* Structure defining the contet of UE context modification 
 * response API */
typedef struct 
{
    f1ap_adpt_ue_context_mod_resp_t   message;

} dusim_cu_init_ue_ctx_mod_resp_t;  /* DUSIM_UE_CTX_MOD_RESP */

/* Structure defining the content of UE context Release
 * request API */
typedef struct
{
   f1ap_adpt_ue_context_rel_req_t     message;

} dusim_cu_init_ue_ctx_rel_req_t; /* DUSIM_UE_CTX_REL_REQ */


/* Structure defining the contet of UE context modification 
 * failure API */
typedef struct 
{
    //_f1ap_UEContextModificationFailure  message;

} dusim_du_init_ue_ctx_mod_failure_t;  /* DUSIM_UE_CTX_MOD_FAILURE */

/* Structure defining the content of F1 Initial Ul RRC Message Transfer */
typedef struct
{
        _f1ap_InitialULRRCMessageTransfer          message;

}dusim_f1_init_ul_rrc_msg_transfer_t;  /* DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER */

/* Structure defining the content of UE context modification Required */
typedef struct
{
        f1ap_adpt_ue_context_mod_required_t   message;

}dusim_ue_ctx_mod_required_t;   /* DUSIM_UE_CTX_MOD_REQUIRED */



/*************************************************************** 
 * DU SIM to USER APIs 
 **************************************************************/

/* Structure defining the content of API used for sending the 
 * response of CONFIGURE DU REQ to user. */
typedef struct
{
    /* Indicates unique DU identifier */
    unsigned char du_id;

    /* Indicates the result of DU Configure Request */
    unsigned char response_code;

} dusim_configure_du_resp_t;  /* DUSIM_CONFIGURE_DU_RESP */


/* Structure defining the content of API used for sending the
 * connection status of F1 sctp link. */
typedef struct
{
    /* SCTP link status (f1_sctp_link_status_et) */
    unsigned char  link_status;

} dusim_sctp_link_status_ind_t;  /* DUSIM_SCTP_LINK_STATUS_IND */


/* Structure defining the content of F1 Setup Response */
typedef struct 
{
   f1ap_adpt_f1_setup_cnf_t  message;

} dusim_f1_setup_resp_t;   /* DUSIM_F1SETUP_RESP */


/* Structure defining the content of F1 Setup Failure */
typedef struct 
{
    _f1ap_F1SetupFailure   message;

} dusim_f1_setup_failure_t;   /* DUSIM_F1SETUP_FAILURE */


/* Structure defining the content of DU Configuration update
 * ACK API */
typedef struct 
{
    _f1ap_GNBDUConfigurationUpdateAcknowledge   message;

} dusim_du_config_update_ack_t;   /* DUSIM_CONFIG UPDATE ACK */


/* Structure defining the content of DU Configuration update
 * Failure API */
typedef struct 
{
    _f1ap_GNBDUConfigurationUpdateFailure  message;

} dusim_du_config_update_failure_t;   /* DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE */


/* Structure defining the content of CU Configuration update API */
typedef struct 
{
    f1ap_adpt_cu_config_update_req_t  message;

} dusim_cu_config_update_t;  /* DUSIM_GNB_CU_CONFIG_UPDATE */


/* Structure defining the content of UE context Setup Request API */
typedef struct
{
    f1ap_adpt_ue_context_setup_req_t  message;

} dusim_ue_ctx_setup_req_t;  /* DUSIM_UE_CTX_SETUP_REQ */


/* Structure defining the content of CU initiated UE context release
 * command API */
typedef struct 
{
    f1ap_adpt_ue_context_rel_command_t   message;

} dusim_cu_init_ue_ctx_rel_cmd_t;  /* DUSIM_CU_INIT_UE_CTX_REL_CMD */


/*DL RRC Transfer Changes*/

#if 0
/* Structure defining the content of CU initiated DL RRC Message Transfer 
 * API */
typedef struct 
{
    f1ap_adpt_dl_rrc_message_transfer_t   message;

} dusim_cu_init_dl_rrc_msg_trnsfr_cmd_t;  /* DUSIM_DL_RRC_MSG_TRANSFER */

/* Structure defining the content of UE context modification confirm */ 
typedef struct 
{
    _f1ap_UEContextModificationConfirm  message;

} dusim_ue_ctx_mod_cnf_t;  /* DUSIM_UE_CTX_MOD_CONFIRM */

#endif

/* Structure defining the content of UE context modification request */ 
typedef struct 
{
	f1ap_adpt_ue_context_mod_req_t    message;

} dusim_ue_ctx_mod_req_t;  /* DUSIM_UE_CTX_MOD_REQUEST */


/* Structure defining the content of DL RRC message indication */
//typedef struct 
//{
  //  _f1ap_DLRRCMessageTransfer  message;

//} dusim_dl_rrc_msg_ind_t;  /* DUSIM_DL_RRC_MSG_IND */


/******************************************************* 
 * BI-DIRECTIONAL APIs 
 ******************************************************/

/* Structure defining the content of F1 Reset Request */
typedef struct
{
    _f1ap_Reset  message;

} dusim_f1_reset_req_t;  /* DUSIM_RESET_REQ */


/* Structure defining the content of F1 Reset Response */
typedef struct
{
    _f1ap_ResetAcknowledge  message;

} dusim_f1_reset_resp_t;  /* DUSIM_RESET_RESP */


/* Structure defining the content of Error Indication */
typedef struct
{
    _f1ap_ErrorIndication  message;

} dusim_error_indication_t;  /* DUSIM_ERROR_INDICATION */

/* Structure defining the content of UE Context Modification Confirm API */
typedef struct
{
	f1ap_adpt_ue_context_mod_confirm_t  message;

} dusim_ue_ctx_mod_confirm_t;  /* DUSIM_UE_CTX_MOD_CONFIRM */



#endif   // _DUSIM_CMD_DEFS_H_
