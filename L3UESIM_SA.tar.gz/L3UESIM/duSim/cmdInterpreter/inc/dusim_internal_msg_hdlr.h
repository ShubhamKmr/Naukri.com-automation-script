#ifndef _DUSIM_INTERNAL_MSG_HDLR_H_
#define _DUSIM_INTERNAL_MSG_HDLR_H_

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "lteTypes.h"
//#include "sim_defs.h"
#include "dusim_cmd_interpreter.h"
#include "typedefs.h"
#include "dusim_cmd_defs.h"
#include "dusim_cmd_structure.h"
#include "du_sim_event.h"


/* This function handle DU Setup Response received
 * from DU SIM stack app. */
void handle_incoming_f1setup_resp(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handle Reset Request received from 
 * DU SIM stack app. */
void handle_incoming_reset_req(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handle Reset Response received from 
 * DU SIM stack app. */
void handle_incoming_reset_resp(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handle Error Indication received
 * from DU SIM stack app. */
void handle_incoming_error_indication(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handle F1 Setup Request received
 * from DU SIM stack app. */
void handle_incoming_f1setup_req(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handles configure eNB response received from
 * stack application */
void handle_configure_du_resp(
        unsigned char* msgBuf, 
        unsigned int   msgLen);


/* This function handles SCTP link status indication received 
 * from stack application */
void handle_sctp_link_status_ind(
        unsigned char* msgBuf, 
        unsigned int   msgLen);

/*SPR24420 Fix start*/
/* This function handle DU Setup Response Failure received
 *  *  *  * from DU SIM stack app. */
void handle_incoming_f1setup_resp_failure(
        unsigned char* msgBuf,
        unsigned int   msgLen);
/*SPR24420 Fix stop*/


#endif     // _DUSIM_INTERNAL_MSG_HDLR_H_
