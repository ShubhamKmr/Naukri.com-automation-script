#include "proto_cmd_interpretor.h"
#include "du_sim_event.h"


/* This function creates and return command interpreter 
 * for DU Sim */
cmd_interpreter_t* create_du_sim_cmd_intrepreter();


/* This function will forward the message from DU SIM 
 * to user */
void dusim_forward_msg_to_user(
        unsigned char* apiBuf, 
        unsigned int   apiLen);


/* This function will forward the command received from
 * user to DU SIM stack application. */
void dusim_forward_user_cmd_to_stack_app(
        du_sim_event_t*  msgBuf);

void handle_incoming_f1_context_setup_request (
        unsigned char* msgBuf,
        unsigned int msgLen);

void handle_incoming_f1_ue_context_rel_cmd(
        unsigned char* msgBuf,
        unsigned int   msgLen);

void handle_incoming_f1_ue_context_mod_request(
        unsigned char* msgBuf,
        unsigned int   msgLen);

void handle_cu_config_update_request (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen);

void handle_du_config_update_ack1 (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen);

void handle_du_config_update_failure (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen);

void handle_incoming_dl_rrc_transfer (
        unsigned char* msgBuf,
        unsigned int msgLen);

/* Function prototype of f1 ue ctxt mod confirm */
void dusim_handle_incoming_f1_context_mod_confirm (
        unsigned char* msgBuf,
        unsigned int msgLen);



