
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "dusim_cmd_interpreter.h"
#include "typedefs.h"
#include "dusim_cmd_defs.h"
#include "dusim_cmd_structure.h"
#include "du_sim_event.h"

void handle_incoming_f1_ue_context_rel_cmd(
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t*                         msg_in     = NULL;
    dusim_cu_init_ue_ctx_rel_cmd_t*         src_ptr    = NULL;
    dusim_cu_init_ue_ctx_rel_cmd_t*         target_ptr = NULL;
    dusim_user_data_ind_t*                  p_api      = NULL;
    unsigned char*                          apiBuf     = NULL;
    unsigned int                            api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_cu_init_ue_ctx_rel_cmd_t*)msg_in->msgBuf;

    /* Calulate the size of API buffer */
    api_size = sizeof(du_sim_event_hdr_t) + 
                    sizeof(dusim_cu_init_ue_ctx_rel_cmd_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_cu_init_ue_ctx_rel_cmd_t*)(apiBuf + 
                sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
                sizeof(dusim_cu_init_ue_ctx_rel_cmd_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_CU_INIT_UE_CTX_REL_CMD;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    LOG_TRACE("Forwarding f1 context release request to the user\n");
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
}


void handle_incoming_f1_ue_context_mod_request(
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_ue_ctx_mod_req_t*         src_ptr    = NULL;
    dusim_ue_ctx_mod_req_t*         target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_ue_ctx_mod_req_t*)msg_in->msgBuf;

    /* Calulate the size of API buffer */
    api_size = sizeof(du_sim_event_hdr_t) + 
                    sizeof(dusim_ue_ctx_mod_req_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_ue_ctx_mod_req_t*)(apiBuf + 
                sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
                sizeof(dusim_ue_ctx_mod_req_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_UE_CTX_MOD_REQUEST;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    LOG_TRACE("Forwarding f1 context modification request to the user\n");
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
}

void handle_incoming_dl_rrc_transfer (
        unsigned char* msgBuf,
        unsigned int msgLen)
{
    du_sim_event_t*                         msg_in     = NULL;
    dusim_f1_dl_rrc_msg_transfer_t*            src_ptr    = NULL;
    dusim_f1_dl_rrc_msg_transfer_t*            target_ptr = NULL;
    dusim_user_data_ind_t*                  p_api      = NULL;
    unsigned char*                          apiBuf     = NULL;
    unsigned int                            api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_f1_dl_rrc_msg_transfer_t*)msg_in->msgBuf;

    /* Calulate the size of API buffer */
    api_size = sizeof(du_sim_event_hdr_t) + sizeof(dusim_f1_dl_rrc_msg_transfer_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_f1_dl_rrc_msg_transfer_t*)(apiBuf + 
                sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
                sizeof(dusim_f1_dl_rrc_msg_transfer_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_F1_DL_RRC_MSG_TRANSFER;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }
    LOG_TRACE("Forwarding f1 dl rrc transfer to the user\n");
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
}


/* F1 CONTEXT SETUP START */
/* This function handles f1 context setup request
 * received from stack app */
void handle_incoming_f1_context_setup_request (
        unsigned char* msgBuf,
        unsigned int msgLen)
{
    du_sim_event_t*                         msg_in     = NULL;
    dusim_ue_ctx_setup_req_t*            src_ptr    = NULL;
    dusim_ue_ctx_setup_req_t*            target_ptr = NULL;
    dusim_user_data_ind_t*                  p_api      = NULL;
    unsigned char*                          apiBuf     = NULL;
    unsigned int                            api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_ue_ctx_setup_req_t*)msg_in->msgBuf;

    /* Calulate the size of API buffer */
    api_size = sizeof(du_sim_event_hdr_t) + sizeof(dusim_ue_ctx_setup_req_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_ue_ctx_setup_req_t*)(apiBuf + 
                sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
                sizeof(dusim_ue_ctx_setup_req_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_UE_CTX_SETUP_REQ;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }
    LOG_TRACE("Forwarding f1 context setup request to the user\n");
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
}
/* F1 CONTEXT SETUP STOP */

/* This function handle DU Setup Response received
 * from DU SIM stack app. */
void handle_incoming_f1setup_resp(
        unsigned char* msgBuf, 
        unsigned int   msgLen)
{
    du_sim_event_t*  msg_in     = NULL;
    dusim_f1_setup_resp_t*          src_ptr    = NULL;
    dusim_f1_setup_resp_t*          target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    LOG_TRACE("Received DUSIM F1 SETUP RESP\n");

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_f1_setup_resp_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                  sizeof(dusim_f1_setup_resp_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_f1_setup_resp_t*)(apiBuf + 
                            sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_f1_setup_resp_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_F1SETUP_RESP;
        //p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id     = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   

        LOG_TRACE("Sent F1 Setup Resp to user, length:%d \n", api_size);
}


/* This function handle Reset Request received from 
 * DU SIM stack app. */
void handle_incoming_reset_req(
        unsigned char* msgBuf, 
        unsigned int   msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_f1_reset_req_t*       src_ptr    = NULL;
    dusim_f1_reset_req_t*       target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    /* Fetch pointer to source msg structure */
    msg_in = (du_sim_event_t*)msgBuf;
    src_ptr = (dusim_f1_reset_req_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                          sizeof(dusim_f1_reset_req_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_f1_reset_req_t*)(apiBuf + 
                                sizeof(dusim_user_intf_hdr_t));
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_f1_reset_req_t));


    /* Populate API body */
    //target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to DU sim user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_F1_RESET_REQ;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
    LOG_TRACE("Sent F1 reset request to user, length:%d \n", api_size);

return;
}


/* This function handle Reset Response received from 
 * DU SIM stack app. */
void handle_incoming_reset_resp(
        unsigned char* msgBuf, 
        unsigned int   msgLen)
{
}


/* This function handle Error Indication received
 * from DU SIM stack app. */
void handle_incoming_error_indication(
        unsigned char* msgBuf, 
        unsigned int   msgLen)
{
	
    du_sim_event_t*  msg_in     = NULL;
    dusim_error_indication_t*          src_ptr    = NULL;
    dusim_error_indication_t*          target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    LOG_TRACE("Received DUSIM F1 SETUP RESP\n");

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_error_indication_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                  sizeof(dusim_error_indication_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_error_indication_t*)(apiBuf + 
                            sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_error_indication_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_ERROR_INDICATION;
        //p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id     = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   

    LOG_TRACE("Sent F1 ERROR INDICATION to user, length:%d \n", api_size);

}



/* This function handle F1 Setup Request received
 * from DU SIM stack app. */
void handle_incoming_f1setup_req(
        unsigned char* msgBuf, 
        unsigned int   msgLen)
{
}


/* This function handles configure eNB response received from
 * stack application */
void handle_configure_du_resp(unsigned char* msgBuf, 
                               unsigned int  msgLen)
{
    du_sim_event_t*  msg_in     = NULL;
    dusim_configure_du_resp_t*                src_ptr    = NULL;
    dusim_configure_du_resp_t*                target_ptr = NULL;
    dusim_user_data_ind_t*                     p_api      = NULL;
    unsigned char*                             apiBuf     = NULL;
    unsigned int                               api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_configure_du_resp_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                          sizeof(dusim_configure_du_resp_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_configure_du_resp_t*)(apiBuf + 
                                sizeof(dusim_user_intf_hdr_t));

    /* Populate API body */
    target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to DU sim user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_CONFIGURE_DU_RESP;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id     = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   

    LOG_TRACE("Sent configure eNB Response to user, length:%d \n", api_size);
}

/*GNB CU CODE START*/
/*This function handles the gNB CU config update request received from stack app*/
void handle_cu_config_update_request (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_cu_config_update_t*       src_ptr    = NULL;
    dusim_cu_config_update_t*       target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    /* Fetch pointer to source msg structure */
    msg_in = (du_sim_event_t*)msgBuf;
    src_ptr = (dusim_cu_config_update_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                          sizeof(dusim_cu_config_update_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_cu_config_update_t*)(apiBuf + 
                                sizeof(dusim_user_intf_hdr_t));
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_cu_config_update_t));


    /* Populate API body */
    //target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to DU sim user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_GNB_CU_CONFIG_UPDATE;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
    LOG_TRACE("Sent configuration update gNB Request to user, length:%d \n", api_size);

}
void handle_du_config_update_ack1 (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_du_config_update_ack_t*       src_ptr    = NULL;
    dusim_du_config_update_ack_t*       target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    /* Fetch pointer to source msg structure */
    msg_in = (du_sim_event_t*)msgBuf;
    src_ptr = (dusim_du_config_update_ack_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                          sizeof(dusim_du_config_update_ack_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_du_config_update_ack_t*)(apiBuf + 
                                sizeof(dusim_user_intf_hdr_t));
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_du_config_update_ack_t));


    /* Populate API body */
    //target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to DU sim user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_GNB_DU_CONFIG_UPDATE_ACK;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
    LOG_TRACE("Sent configuration update gNB Request to user, length:%d \n", api_size);

}
void handle_du_config_update_failure (
                        unsigned char*  msgBuf,
                        unsigned int    msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_du_config_update_failure_t*       src_ptr    = NULL;
    dusim_du_config_update_failure_t*       target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    /* Fetch pointer to source msg structure */
    msg_in = (du_sim_event_t*)msgBuf;
    src_ptr = (dusim_du_config_update_failure_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                          sizeof(dusim_du_config_update_failure_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_du_config_update_failure_t*)(apiBuf + 
                                sizeof(dusim_user_intf_hdr_t));
    memcpy(target_ptr, src_ptr, 
            sizeof(dusim_du_config_update_failure_t));


    /* Populate API body */
    //target_ptr->response_code = src_ptr->response_code;

    /* Get pointer to DU sim user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_GNB_DU_CONFIG_UPDATE_ACK;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
    LOG_TRACE("Sent configuration update gNB Request to user, length:%d \n", api_size);

}

/*GNB CU CODE STOP*/

/* This function handles SCTP link status indication received 
 * from stack application */
void handle_sctp_link_status_ind(unsigned char* msgBuf, 
                                 unsigned int   msgLen)
{
    du_sim_event_t*  
                                   msg_in     = NULL;
    dusim_sctp_link_status_ind_t*        src_ptr    = NULL;
    dusim_sctp_link_status_ind_t*  target_ptr = NULL;
    dusim_user_data_ind_t*         p_api      = NULL;
    unsigned char*                 apiBuf     = NULL;
    unsigned int                   api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_sctp_link_status_ind_t*)msg_in->msgBuf;

    /* Calculate size of target API buffer */
    api_size = sizeof(dusim_user_intf_hdr_t) + 
                  sizeof(dusim_sctp_link_status_ind_t);

    /* Allocate memory for target API buffer */
    apiBuf = (unsigned char*)malloc(api_size);;
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_sctp_link_status_ind_t*)(apiBuf + 
                            sizeof(dusim_user_intf_hdr_t));

    /* Populate API body */
    target_ptr->link_status = src_ptr->link_status;

    /* Get pointer to DU SIM user data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_SCTP_LINK_STATUS_IND;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id     = msg_in->header.du_id;
        p_api->header.length     = api_size;
    }

    /* Send API to user */
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);    

    LOG_TRACE("Successfully sent SCTP Link status indication to user, length:%d \n", api_size);
}

/* F1 UE Ctxt Mod Confirm Code changes start */
void dusim_handle_incoming_f1_context_mod_confirm(
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t*                 msg_in     = NULL;
    dusim_ue_ctx_mod_confirm_t*     src_ptr    = NULL;
    dusim_ue_ctx_mod_confirm_t*     target_ptr = NULL;
    dusim_user_data_ind_t*          p_api      = NULL;
    unsigned char*                  apiBuf     = NULL;
    unsigned int                    api_size   = 0;

    msg_in = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source msg structure */
    src_ptr = (dusim_ue_ctx_mod_confirm_t*)msg_in->msgBuf;

    /* Calulate the size of API buffer */
    api_size = sizeof(du_sim_event_hdr_t) + 
                    sizeof(dusim_ue_ctx_mod_confirm_t);

    /* Allocate memory for target API buffer */
    apiBuf = malloc(api_size);
    memset(apiBuf, 0, api_size);

    /* Fetch pointer to target API msg buffer */
    target_ptr = (dusim_ue_ctx_mod_confirm_t*)(apiBuf + 
                sizeof(dusim_user_intf_hdr_t));

    /* Copy API body from source container to target container */
    memcpy(target_ptr, src_ptr, 
                sizeof(dusim_ue_ctx_mod_confirm_t));

    /* Get pointer to X2SIM User data indication */
    p_api = (dusim_user_data_ind_t*)apiBuf;

    /* Populate target API header */
    {
        p_api->header.apiId      = DUSIM_UE_CTX_MOD_CONFIRM;
        p_api->header.imsi       = msg_in->header.imsi;
        p_api->header.du_id      = msg_in->header.du_id;
        p_api->header.length     = msg_in->header.length;
    }

    LOG_TRACE("Forwarding f1 context modification confirm to the user\n");
    dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);   
}
/* F1 UE Ctxt Mod Confirm Code changes stop */

/*SPR24420 Fix start*/
/* This function handle DU Setup Response Failure received
 *  * from DU SIM stack app. */
void handle_incoming_f1setup_resp_failure(
		unsigned char* msgBuf,
		unsigned int   msgLen)
{
	du_sim_event_t*                 msg_in     = NULL;
	dusim_f1_setup_failure_t*       src_ptr    = NULL;
	dusim_f1_setup_failure_t*       target_ptr = NULL;
	dusim_user_data_ind_t*          p_api      = NULL;
	unsigned char*                  apiBuf     = NULL;
	unsigned int                    api_size   = 0;

	msg_in = (du_sim_event_t*)msgBuf;

	LOG_TRACE("Received DUSIM F1 SETUP RESP FAILURE\n");

	/* Fetch pointer to source msg structure */
	src_ptr = (dusim_f1_setup_failure_t*)msg_in->msgBuf;

	/* Calculate size of target API buffer */
	api_size = sizeof(dusim_user_intf_hdr_t) +
		sizeof(dusim_f1_setup_failure_t);

	/* Allocate memory for target API buffer */
	apiBuf = malloc(api_size);
	memset(apiBuf, 0, api_size);

	/* Fetch pointer to target API msg buffer */
	target_ptr = (dusim_f1_setup_failure_t*)(apiBuf +
			sizeof(dusim_user_intf_hdr_t));

	/* Copy API body from source container to target container */
	memcpy(target_ptr, src_ptr,
			sizeof(dusim_f1_setup_failure_t));

	/* Get pointer to X2SIM User data indication */
	p_api = (dusim_user_data_ind_t*)apiBuf;

	/* Populate target API header */
	{
		p_api->header.apiId      = DUSIM_F1SETUP_FAILURE;
		p_api->header.imsi       = msg_in->header.imsi;
		p_api->header.du_id     = msg_in->header.du_id;
		p_api->header.length     = msg_in->header.length;
	}
	dusim_forward_msg_to_user((unsigned char*)apiBuf, api_size);

	LOG_TRACE("Sent F1 Setup Resp Failure to user, length:%d \n", api_size);
}
/*SPR24420 Fix stop */


