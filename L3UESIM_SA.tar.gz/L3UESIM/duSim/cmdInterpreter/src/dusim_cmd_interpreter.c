/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "dusim_cmd_interpreter.h"
#include "typedefs.h"
#include "dusim_cmd_defs.h"
#include "dusim_cmd_structure.h"
#include "du_sim_event.h"
#include "dusim_internal_msg_hdlr.h"
#include "dusim_user_msg_hdlr.h"

#include "proto_stack_app.h"
#include "proto_sim.h"
#include "globalContext.h"


/* This function will forward the message from DU SIM to user */
void dusim_forward_msg_to_user(
        unsigned char* apiBuf, 
        unsigned int   apiLen)
{
    user_data_ind_t*   user_data_ind;
    ui_conn_hdlr_t*    ui_handler = NULL;
    unsigned char*     msgBuf     = NULL;
    unsigned int       msgLen     = 0;

    /* Calculate final length of message to be sent */
    msgLen = UI_HDR_LEN + apiLen;

    /* Allocate memory for final message buffer */
    msgBuf = malloc(msgLen);
    memset(msgBuf, 0, msgLen);

    /* Create UI packet */
    user_data_ind = (user_data_ind_t*)msgBuf;

    user_data_ind->proto_identifier = DUSIM_ID;
    user_data_ind->msgLen           = apiLen;
    memcpy(&user_data_ind->msgBuf, apiBuf, apiLen);

    /* Fetch pointer to object of UI handler */
    ui_handler = get_ui_handler(0);

    LOG_TRACE("Sending message to user, length: %d\n", msgLen);

    /* Send API to user */
    ui_handler->send(ui_handler->sockFd, user_data_ind, msgLen);

}


/* This function will forward the command received from
 * user to DU SIM stack application. */
void dusim_forward_user_cmd_to_stack_app(
        du_sim_event_t*  msgBuf)
{
    proto_simulator_t* du_sim    = NULL;
    stack_app_t*       stack_app = NULL;
    
    /* Fetch pointer to object of DU SIMulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to stackApp of DU SIMulator */
    stack_app = get_proto_stack_app(du_sim);

    /* Invoke the stack app callback registered for 
     * processing command received from user. */
    stack_app->user_msg_hdlr((void*)msgBuf);
}


/* This function decodes the command received from user and 
 * invoke API for further processing. */
void du_sim_cmd_interpreter_user_cmd_hdlr(
        void*         msgBuf, 
        unsigned int  msgLen)
{
    dusim_user_data_req_t*  user_data  = NULL;

    //LOG_TRACE("Command received from user in DU SIM, length: %d \n", msgLen);

    /* TODO: Ensure that length of message is not less than 
     * minumum allowed. 
     * Also, ensure that the received msg length matches the 
     * one present in the message header. */
    user_data  = (dusim_user_data_req_t*)msgBuf;

    /* Handle received API */
    dusim_process_user_command(user_data->header.apiId,
                               user_data->header.imsi,
                               user_data->header.du_id,
                               user_data->header.length,
                               user_data->msgBuf); 
}


/* This function processes the message received from DU SIM stack app */
void du_sim_cmd_interpreter_stack_app_msg_hdlr(
        void*         msgBuf, 
        unsigned int  msgLen)
{
    du_sim_event_t*  msg_in = PNULL;

    msg_in = (du_sim_event_t*)msgBuf;

    switch(msg_in->header.apiId)
    {
        case DUSIM_CONFIGURE_DU_RESP:
        {
            handle_configure_du_resp(msgBuf, msgLen);
            break;
        }

        case DUSIM_SCTP_LINK_STATUS_IND:
        {
            handle_sctp_link_status_ind(msgBuf, msgLen);
            break;
        }

        case DUSIM_F1SETUP_RESP:
        {
            handle_incoming_f1setup_resp(msgBuf, msgLen);
            break;
        }

        case DUSIM_F1_DL_RRC_MSG_TRANSFER:
        {
            handle_incoming_dl_rrc_transfer(msgBuf,msgLen);
            break;
        }
        
        /* F1 CONTEXT SETUP START */
        case DUSIM_UE_CTX_SETUP_REQ:
        {
            handle_incoming_f1_context_setup_request(msgBuf,msgLen);
            break;
        }
        /* F1 CONTEXT SETUP RESPONSE */

        case DUSIM_CU_INIT_UE_CTX_REL_CMD:
        {
            handle_incoming_f1_ue_context_rel_cmd(msgBuf,msgLen);
            break;
        }

        case DUSIM_UE_CTX_MOD_REQUEST:
        {
            handle_incoming_f1_ue_context_mod_request(msgBuf,msgLen);
            break;
        }

	case DUSIM_ERROR_INDICATION:
	{
		handle_incoming_error_indication(msgBuf, msgLen);
		break;
	}
        case DUSIM_RESET_REQ:
        {
            handle_incoming_reset_req(msgBuf, msgLen);
            break;
        }

        case DUSIM_RESET_RESP:
        {
            handle_incoming_reset_resp(msgBuf, msgLen);
            break;
        }
        /*GNB CU CODE START*/ 
        case DUSIM_GNB_CU_CONFIG_UPDATE:
        {
            handle_cu_config_update_request(msgBuf, msgLen);
            break;
        }
        /*GNB CU CODE STOP*/
        case DUSIM_GNB_DU_CONFIG_UPDATE_ACK:
        {
            handle_du_config_update_ack1(msgBuf, msgLen);
            break;
        }
        case DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE:
        {
            handle_du_config_update_failure(msgBuf, msgLen);
            break;
        }
        /*GNB CU CODE STOP*/

	/* UE CONTEXT MODIFICATION CONFIRM start */
	case DUSIM_UE_CTX_MOD_CONFIRM:
	{
		dusim_handle_incoming_f1_context_mod_confirm(msgBuf,msgLen);
		break;
	}
	/* UE CONTEXT MODIFICATION CONFIRM stop */
       
	/*SPR24420 Fix start*/
        case DUSIM_F1SETUP_FAILURE:
        {
            handle_incoming_f1setup_resp_failure(msgBuf, msgLen);
            break;
        }
        /*SPR24420 Fix stop*/

        default:
        {
            fprintf(stderr, "Unknown API received from stack app : %d\n",
                    msg_in->header.apiId);
            break;
        }
    }
}


/* This function initializes the DU SIM command interpreter */
sim_return_val_et du_sim_cmd_interpreter_init()
{
    LOG_TRACE("Initialization of DU SIM command interpreter \n");
    return SIM_SUCCESS;
}


/* This function creates and return command interpreter for DU SIM */
cmd_interpreter_t* create_du_sim_cmd_intrepreter()
{
    cmd_interpreter_t*  cmd_interpreter = NULL;

    /* Allocate command interpreter for DU SIM */
    cmd_interpreter = allocate_command_interpreter();
    if (NULL == cmd_interpreter)
    {
        LOG_TRACE("Failed to allocate cmd interpreter for DU SIM\n");
        return cmd_interpreter;
    }

    /* Initialize the function pointers of command interpreter */
    cmd_interpreter->init           
                = du_sim_cmd_interpreter_init; 
    cmd_interpreter->user_cmd_hdlr  
                = du_sim_cmd_interpreter_user_cmd_hdlr;
    cmd_interpreter->stack_app_msg_hdlr 
                = du_sim_cmd_interpreter_stack_app_msg_hdlr;

    return cmd_interpreter;
}

