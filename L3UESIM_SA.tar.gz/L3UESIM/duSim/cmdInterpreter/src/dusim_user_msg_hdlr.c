/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the API for handle DU Reset Response received
 * *                     from user.
 * *
 * ***************************************************************************/

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "dusim_cmd_interpreter.h"
#include "typedefs.h"
#include "dusim_cmd_defs.h"
#include "dusim_cmd_structure.h"
#include "du_sim_event.h"

#include "proto_stack_app.h"
#include "proto_sim.h"
#include "globalContext.h"


/* This function handle DU Reset Response received 
 * from user. */
void handle_outgoing_du_reset_resp(
        unsigned short du_id, 
        unsigned int   msgLen, 
        unsigned char* msgBuf)

{
    du_sim_event_t  userRequest;
    dusim_f1_reset_resp_t * src_ptr    = NULL;
    dusim_f1_reset_resp_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_f1_reset_resp_t*)malloc(
                            sizeof(dusim_f1_reset_resp_t));
    memset(target_ptr, 0, sizeof(dusim_f1_reset_resp_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_f1_reset_resp_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(dusim_f1_reset_resp_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_RESET_RESP;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_f1_reset_resp_t) +
                       sizeof(du_sim_event_t);
    }

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);

    LOG_TRACE("F1 Setup Request sent to Stack App \n");
}


/* This function handle Error Indication received 
 * from user. */
void handle_outgoing_f1_error_ind(
        unsigned short du_id,
        unsigned int   msgLen, 
        unsigned char* msgBuf)

{
    du_sim_event_t  userRequest;
    dusim_error_indication_t * src_ptr    = NULL;
    dusim_error_indication_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_error_indication_t*)malloc(
                            sizeof(dusim_error_indication_t));
    memset(target_ptr, 0, sizeof(dusim_error_indication_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_error_indication_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(dusim_error_indication_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_ERROR_INDICATION;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_error_indication_t) +
                       sizeof(du_sim_event_t);
    }

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);

    LOG_TRACE("F1 error indication  sent to Stack App \n");
}



/* This function handle DU Reset Request received 
 * from user. */
void handle_outgoing_du_reset_req(
        unsigned short du_id,
        unsigned int   msgLen, 
        unsigned char* msgBuf)
{
}

/*******************************************************************************
 * Function Name  : handle_outgoing_f1setup_req
 * Description    : This function handles F1 Setup Request 
 *                   received from user.
 *
 * Inputs         : unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

/* This function handle F1 Setup Request received 
 * from user. */
void handle_outgoing_f1setup_req(
    unsigned int   msgLen, 
    unsigned char* msgBuf,
    unsigned short du_id)
{
    du_sim_event_t  userRequest;
    dusim_f1_setup_req_t * src_ptr    = NULL;
    dusim_f1_setup_req_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_f1_setup_req_t*)malloc(
                            sizeof(dusim_f1_setup_req_t));
    memset(target_ptr, 0, sizeof(dusim_f1_setup_req_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_f1_setup_req_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(dusim_f1_setup_req_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_F1SETUP_REQ;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_f1_setup_req_t) +
                       sizeof(du_sim_event_t);
    }

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);

    LOG_TRACE("F1 Setup Request sent to Stack App \n");
}

/*******************************************************************************
 * Function Name  : handle_incoming_f1_ue_context_rel_comp
 * Description    : This function handles f1_ue_context_release_complete
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_ue_context_rel_comp(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)  
{
    du_sim_event_t                    userRequest;
    dusim_cu_init_ue_ctx_rel_comp_t*  src_ptr    = NULL;
    dusim_cu_init_ue_ctx_rel_comp_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_cu_init_ue_ctx_rel_comp_t* )malloc(
                      sizeof(dusim_cu_init_ue_ctx_rel_comp_t));
    memset(target_ptr, 0, sizeof(dusim_cu_init_ue_ctx_rel_comp_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_cu_init_ue_ctx_rel_comp_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(f1ap_adpt_ue_context_rel_complete_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_CU_INIT_UE_CTX_REL_COMPLETE;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_cu_init_ue_ctx_rel_comp_t) 
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UE Context Release Complete to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/*******************************************************************************
 * Function Name  : handle_incoming_f1_ue_context_rel_req
 * Description    : This function handles f1_ue_context_rel_req
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_ue_context_rel_req(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t                    userRequest;
    dusim_cu_init_ue_ctx_rel_req_t*  src_ptr    = NULL;
    dusim_cu_init_ue_ctx_rel_req_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_cu_init_ue_ctx_rel_req_t* )malloc(
                      sizeof(dusim_cu_init_ue_ctx_rel_req_t));
    memset(target_ptr, 0, sizeof(dusim_cu_init_ue_ctx_rel_req_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_cu_init_ue_ctx_rel_req_t*)msgBuf;

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(f1ap_adpt_ue_context_rel_req_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }
    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_REL_REQ;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id;
        userRequest.header.length     = sizeof(dusim_cu_init_ue_ctx_rel_req_t)
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UE Context Release request to stack App \n");
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}







/*******************************************************************************
 * Function Name  : handle_incoming_f1_ue_context_mod_resp
 * Description    : This function handles f1_ue_context_mod_resp
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_ue_context_mod_resp(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)  
{
    du_sim_event_t                    userRequest;
    dusim_cu_init_ue_ctx_mod_resp_t*  src_ptr    = NULL;
    dusim_cu_init_ue_ctx_mod_resp_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_cu_init_ue_ctx_mod_resp_t* )malloc(
                      sizeof(dusim_cu_init_ue_ctx_mod_resp_t));
    memset(target_ptr, 0, sizeof(dusim_cu_init_ue_ctx_mod_resp_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_cu_init_ue_ctx_mod_resp_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(f1ap_adpt_ue_context_mod_resp_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_MOD_RESP;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_cu_init_ue_ctx_mod_resp_t) 
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UE Context Modification respone to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/* F1 UE CTXT MOD FAIlURE Changes: Vikash */
/*******************************************************************************
 * Function Name  : handle_incoming_f1_context_mod_fail
 * Description    : This function handles f1_ue_context_mod_fail
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_context_mod_fail(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)  
{
    du_sim_event_t                    userRequest;
    dusim_ue_ctx_mod_failure_t*  src_ptr    = NULL;
    dusim_ue_ctx_mod_failure_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_ue_ctx_mod_failure_t* )malloc(
                      sizeof(dusim_ue_ctx_mod_failure_t));
    memset(target_ptr, 0, sizeof(dusim_ue_ctx_mod_failure_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_ue_ctx_mod_failure_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(f1ap_adpt_ue_context_mod_fail_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_MOD_FAILURE;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_ue_ctx_mod_failure_t) 
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UE Context Modification Failure to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/* F1 INIT UL RRC MSG TRANS Code Changes Start */

/*******************************************************************************
 * Function Name  : handle_incoming_f1_init_ul_rrc_msg_transfer
 * Description    : This function handles f1_init_ul_rrc_msg_transfer
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_init_ul_rrc_msg_transfer(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t                        userRequest;
    dusim_f1_init_ul_rrc_msg_transfer_t*  src_ptr    = NULL;
    dusim_f1_init_ul_rrc_msg_transfer_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_f1_init_ul_rrc_msg_transfer_t* )malloc(
                      sizeof(dusim_f1_init_ul_rrc_msg_transfer_t));

    memset(target_ptr, 0, sizeof(dusim_f1_init_ul_rrc_msg_transfer_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_f1_init_ul_rrc_msg_transfer_t*)msgBuf;

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(dusim_f1_init_ul_rrc_msg_transfer_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id;
        userRequest.header.length     = sizeof(dusim_f1_init_ul_rrc_msg_transfer_t)
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 Init UL RRC MSG Transfer to stack App \n");
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}
/* F1 INIT UL RRC MSG TRANS Code Changes Stop */

/* F1 UE CTXT MOD REQUIRED Changes start */
/*******************************************************************************
 * Function Name  : handle_incoming_f1_ue_context_mod_required
 * Description    : This function handles f1_ue_context_mod_required
 *                  request received from user.
 *  
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 *******************************************************************************/
void handle_incoming_f1_ue_context_mod_required(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)
{
    du_sim_event_t                    userRequest;
    dusim_ue_ctx_mod_required_t*  src_ptr    = NULL;
    dusim_ue_ctx_mod_required_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_ue_ctx_mod_required_t* )malloc(
                      sizeof(dusim_ue_ctx_mod_required_t));
    memset(target_ptr, 0, sizeof(dusim_ue_ctx_mod_required_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_ue_ctx_mod_required_t*)msgBuf;

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(f1ap_adpt_ue_context_mod_required_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_MOD_REQUIRED;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id;
        userRequest.header.length     = sizeof(dusim_ue_ctx_mod_required_t)
						+ sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UE Context Modification required to stack App \n");
    dusim_forward_user_cmd_to_stack_app(&userRequest);

}
/* F1 UE CTXT MOD REQUIRED Changes stop */



/* F1 CONTEXT SETUP START */
/* This function handle F1 Context Setup Response received
 * from user
 */
void handle_incoming_f1_context_setup_resp(
        unsigned int imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen) 
{ 

    du_sim_event_t  userRequest;
    dusim_ue_ctx_setup_resp_t* src_ptr    = NULL;
    dusim_ue_ctx_setup_resp_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_ue_ctx_setup_resp_t* )malloc(sizeof(dusim_ue_ctx_setup_resp_t));
    memset(target_ptr, 0, sizeof(dusim_ue_ctx_setup_resp_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_ue_ctx_setup_resp_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
                &src_ptr->message,
                sizeof(f1ap_adpt_ue_context_setup_resp_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_SETUP_RESP;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_ue_ctx_setup_resp_t) + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 Context Setup request ack to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}
//UL RRC TRANSFER changes


/*******************************************************************************
 * Function Name  : handle_incoming_f1_ul_rrc_msg_transfer
 * Description    : This function handles f1_ul_rrc_msg_transfer 
 *                  request received from user.
 *
 * Inputs         : unsigned int   imsi
 *                  unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_incoming_f1_ul_rrc_msg_transfer(
        unsigned int   imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen)  
{
    du_sim_event_t                    userRequest;
    dusim_f1_ul_rrc_msg_transfer_t*  src_ptr    = NULL;
    dusim_f1_ul_rrc_msg_transfer_t*  target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_f1_ul_rrc_msg_transfer_t* )malloc(
                      sizeof(dusim_f1_ul_rrc_msg_transfer_t));
    memset(target_ptr, 0, sizeof(dusim_f1_ul_rrc_msg_transfer_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_f1_ul_rrc_msg_transfer_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
               &src_ptr->message,
               sizeof(dusim_f1_ul_rrc_msg_transfer_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_F1_UL_RRC_MSG_TRANSFER;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_f1_ul_rrc_msg_transfer_t) 
                                          + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 UL RRC Message Transfer to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/* F1 CONTEXT SETUP STOP */
void handle_incoming_f1_context_setup_fail(
        unsigned int imsi,
        unsigned short du_id,
        unsigned char* msgBuf,
        unsigned int   msgLen) { 

    du_sim_event_t  userRequest;
    dusim_ue_ctx_setup_failure_t* src_ptr    = NULL;
    dusim_ue_ctx_setup_failure_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_ue_ctx_setup_failure_t* )malloc(sizeof(dusim_ue_ctx_setup_failure_t));
    memset(target_ptr, 0, sizeof(dusim_ue_ctx_setup_failure_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_ue_ctx_setup_failure_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->message,
                &src_ptr->message,
                sizeof(dusim_ue_ctx_setup_failure_t)); 

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_UE_CTX_SETUP_FAILURE;
        userRequest.header.imsi       = imsi;
        userRequest.header.du_id      = du_id; 
        userRequest.header.length     = sizeof(dusim_ue_ctx_setup_failure_t) + sizeof(du_sim_event_hdr_t);
    }

    /* Forward the command to stack application */
    LOG_TRACE("Sending F1 Context Setup request ack to stack App \n"); 
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}
/* This function handles eNB configuration request received
 * from user. */
void handle_configure_du_req(
                unsigned int    msgLen,
                unsigned char*  msgBuf,
                unsigned short du_id)
{
    du_sim_event_t  userRequest;
    dusim_configure_du_req_t* src_ptr    = NULL;
    dusim_configure_du_req_t* target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_configure_du_req_t*)malloc(
                            sizeof(dusim_configure_du_req_t));
    memset(target_ptr, 0, sizeof(dusim_configure_du_req_t));

    /* Fetch pointer to source structure */
    src_ptr    = (dusim_configure_du_req_t*)msgBuf; 

    /* Populate request body */
    {
        memcpy(&target_ptr->du_comm_info,
               &src_ptr->du_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        memcpy(&target_ptr->cu_comm_info,
               &src_ptr->cu_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        userRequest.msgBuf = (unsigned char*)target_ptr;
    }

    /* Populate request header */
    {
        userRequest.header.apiId      = DUSIM_CONFIGURE_DU_REQ;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = du_id; //SCTP Changes
        userRequest.header.length     
                = sizeof(dusim_configure_du_req_t) +
                       sizeof(du_sim_event_t);
    }

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/*GNB CU CODE START*/
/*******************************************************************************
 * Function Name  : handle_cu_config_update_failure_req
 * Description    : This function handles GNB CU configuration update ack 
 *                  request received from user.
 * Inputs         : unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_cu_config_update_ack_req (
                unsigned short  du_id, 
                unsigned int    msgLen,
                unsigned char*  msgBuf)
{
    du_sim_event_t                  userRequest;
    dusim_cu_config_update_ack_t*   src_ptr    = NULL;
    dusim_cu_config_update_ack_t*   target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_cu_config_update_ack_t*)malloc(
                            sizeof(dusim_cu_config_update_ack_t));
    memset(target_ptr, 0, sizeof(dusim_cu_config_update_ack_t));

    /* Fetch pointer to source structure */
    src_ptr = (dusim_cu_config_update_ack_t*)msgBuf; 
    
    /*Populate request body*/
    {
    /*Fill target API buffer*/   
    memcpy( &target_ptr->message,
                &src_ptr->message,
                  sizeof(dusim_cu_config_update_ack_t));
        
        userRequest.msgBuf = (unsigned char*)target_ptr;
    }
    /*Populate request header*/
    {
        userRequest.header.apiId      = DUSIM_GNB_CU_CONFIG_UPDATE_ACK;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_cu_config_update_ack_t) +
                       sizeof(du_sim_event_t);
    }

    LOG_TRACE("Sent configure update gNB ACK Request to stack app, length:%d \n", userRequest.header.length);
    
    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}
/*******************************************************************************
 * Function Name  : handle_cu_config_update_failure_req
 * Description    : This function handles GNB CU configuration update failure 
 *                  request received from user.
 * Inputs         : unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_cu_config_update_failure_req (
                unsigned short  du_id, 
                unsigned int    msgLen,
                unsigned char*  msgBuf)
{
    du_sim_event_t                  userRequest;
    dusim_cu_config_update_failure_t*   src_ptr    = NULL;
    dusim_cu_config_update_failure_t*   target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_cu_config_update_failure_t*)malloc(
                            sizeof(dusim_cu_config_update_failure_t));
    memset(target_ptr, 0, sizeof(dusim_cu_config_update_failure_t));

    /* Fetch pointer to source structure */
    src_ptr = (dusim_cu_config_update_failure_t*)msgBuf; 
    
    /*Populate request body*/
    {
    /*Fill target API buffer*/   
    memcpy( &target_ptr->message,
                &src_ptr->message,
                  sizeof(dusim_cu_config_update_failure_t));
        
        userRequest.msgBuf = (unsigned char*)target_ptr;
    }
    /*Populate request header*/
    {
        userRequest.header.apiId      = DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_cu_config_update_failure_t) +
                       sizeof(du_sim_event_t);
    }

    LOG_TRACE("Sent configure update gNB ACK Request to stack app, length:%d \n", userRequest.header.length);
    
    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}


/*GNB CU CODE STOP*/
/*GNB DU CODE START*/
/*******************************************************************************
 * Function Name  : handle_du_config_update_request
 * Description    : This function handles GNB DU configuration update  
 *                  request received from user.
 * Inputs         : unsigned short  du_id
 *                  unsigned int    msgLen
 *                  unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_du_config_update_request (
                unsigned short  du_id, 
                unsigned int    msgLen,
                unsigned char*  msgBuf)
{
    du_sim_event_t                  userRequest;
    dusim_du_config_update_t*   src_ptr    = NULL;
    dusim_du_config_update_t*   target_ptr = NULL;

    /* Allocate memory for target message buffer */
    target_ptr = (dusim_du_config_update_t*)malloc(
                            sizeof(dusim_du_config_update_t));
    memset(target_ptr, 0, sizeof(dusim_du_config_update_t));

    /* Fetch pointer to source structure */
    src_ptr = (dusim_du_config_update_t*)msgBuf; 
    
    /*Populate request body*/
    {
    /*Fill target API buffer*/   
    memcpy( &target_ptr->message,
                &src_ptr->message,
                  sizeof(dusim_du_config_update_t));
        
        userRequest.msgBuf = (unsigned char*)target_ptr;
    }
    /*Populate request header*/
    {
        userRequest.header.apiId      = DUSIM_GNB_DU_CONFIG_UPDATE;
        userRequest.header.imsi       = 0;
        userRequest.header.du_id      = 0; 
        userRequest.header.length     
                = sizeof(dusim_du_config_update_t) +
                       sizeof(du_sim_event_t);
    }

    LOG_TRACE("Sent configure update gNB Request to stack app, length:%d \n", userRequest.header.length);
    
    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}

/* This function handles connection initiation request
 * received from user. */
void duSim_handle_conn_initiation_req(
        unsigned short  du_id)
{
    du_sim_event_t  userRequest;

    /* Populate request header */
    userRequest.header.apiId      = DUSIM_CONN_INITIATION_REQ;
    userRequest.header.imsi       = 0;
    userRequest.header.du_id      = du_id; 
    //userRequest.header.length     = sizeof(du_sim_event_t);
    userRequest.header.length     = sizeof(du_sim_event_hdr_t);  //SCTP Changes
  
    userRequest.msgBuf = (unsigned char*)malloc(sizeof(char));

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}


/* This function handles connection reset request
 * received from user. */
void handle_conn_reset_req(
        unsigned short du_id)
{
    du_sim_event_t  userRequest;

    /* Populate request header */
    userRequest.header.apiId      = DUSIM_CONN_RESET_REQ;
    userRequest.header.imsi       = 0;
    userRequest.header.du_id      = du_id; 
    userRequest.header.length     =  
                   sizeof(du_sim_event_t);

    /* Forward the command to stack application */
    dusim_forward_user_cmd_to_stack_app(&userRequest);
}


/* This function process the command received from user */ 
void dusim_process_user_command(unsigned short apiId,
                                unsigned int   imsi,
                                unsigned short du_id,
                                unsigned int   msgLen,
                                unsigned char* msgBuf)
{
    switch(apiId)
    {
        case DUSIM_CONFIGURE_DU_REQ:
        {
            handle_configure_du_req(msgLen, msgBuf,du_id);  //SCTP Changes
            break;
        }

        case DUSIM_CONN_INITIATION_REQ:
        {
            duSim_handle_conn_initiation_req(du_id);
            break;
        }

        case DUSIM_CONN_RESET_REQ:
        {
            handle_conn_reset_req(du_id);
            break;
        }

        case DUSIM_F1SETUP_REQ:
        {
            LOG_TRACE("F1 Setup Request received from user \n");
            handle_outgoing_f1setup_req(msgLen, msgBuf, du_id);
            break;
        }

        case DUSIM_RESET_REQ:
        {
            handle_outgoing_du_reset_req(du_id, msgLen, msgBuf);
            break;
        }

        case DUSIM_ERROR_INDICATION:
        {
            handle_outgoing_f1_error_ind(du_id, msgLen, msgBuf);
            break;
        }

        case DUSIM_RESET_RESP:
        {
            handle_outgoing_du_reset_resp(du_id, msgLen, msgBuf);
            break;
        }

        /* GNB CU CODE START */
        case DUSIM_GNB_CU_CONFIG_UPDATE_ACK:
        {
            handle_cu_config_update_ack_req(du_id, msgLen, msgBuf);
            break;
        }
        case DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE:
        {
            handle_cu_config_update_failure_req(du_id, msgLen, msgBuf);
            break;
        }

        /* GNB CU CODE STOP */

        /* GNB CU CODE START */
        case DUSIM_GNB_DU_CONFIG_UPDATE:
        {
            handle_du_config_update_request(du_id, msgLen, msgBuf);
            break;
        }
        /* GNB CU CODE STOP */

        /* F1 CONTEXT SETUP START */
        case DUSIM_UE_CTX_SETUP_RESP:
        {
            LOG_TRACE("Received f1 context setup response from user \n");
            handle_incoming_f1_context_setup_resp(imsi,du_id,msgBuf, msgLen);
            break;
        }

        case DUSIM_UE_CTX_SETUP_FAILURE:
        {
            LOG_TRACE("Received f1 context setup fail from user \n");
            handle_incoming_f1_context_setup_fail(imsi,du_id,msgBuf, msgLen);
            break;
        }

        /* F1 CONTEXT SETUP STOP */

        case DUSIM_CU_INIT_UE_CTX_REL_COMPLETE:
        {
            LOG_TRACE("Received f1 UE context release complete from user \n");
            handle_incoming_f1_ue_context_rel_comp(imsi,du_id,msgBuf, msgLen);
            break;
        }

        case DUSIM_UE_CTX_MOD_RESP:
        {
            LOG_TRACE("Received f1 UE context modification response from user \n");
            handle_incoming_f1_ue_context_mod_resp(imsi,du_id,msgBuf, msgLen);
            break;
        }
	case DUSIM_F1_UL_RRC_MSG_TRANSFER:      //UL RRC TRANSFER changes
	{
		LOG_TRACE("Received f1 UL RRC Message Transfer from user \n");
		handle_incoming_f1_ul_rrc_msg_transfer(imsi,du_id,msgBuf, msgLen);
		break;
	}


	 case DUSIM_UE_CTX_REL_REQ:
        {
            LOG_TRACE("Received f1 UE context release request from user \n");
            handle_incoming_f1_ue_context_rel_req(imsi,du_id,msgBuf, msgLen);
            break;
        }


	case DUSIM_UE_CTX_MOD_FAILURE:
	{
		LOG_TRACE("Received f1 context modification failure from user \n");
		handle_incoming_f1_context_mod_fail(imsi,du_id,msgBuf, msgLen);
		break;
	}
	
	case DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER:
        {
                LOG_TRACE("Received F1 Init UL RRC Msg Transfer from user \n");
                handle_incoming_f1_init_ul_rrc_msg_transfer(imsi,du_id,msgBuf, msgLen);
                break;
        }
	
	case DUSIM_UE_CTX_MOD_REQUIRED:
        {
                LOG_TRACE("Received f1 UE context modification required from user \n");
                handle_incoming_f1_ue_context_mod_required(imsi,du_id,msgBuf, msgLen);
                break;
        }

        default:
        {
            LOG_TRACE("Received API: %d not supported \n", apiId);
            break;
        }
    }
}

