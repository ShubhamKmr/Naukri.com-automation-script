/* Standard includes */
#include <stdio.h>

/* Project includes */
#include "dusim_cmd_interpreter.h"
#include "peer_conn_hdlr.h"
#include "globalContext.h"
#include "stack.h"
#include "dusim_stack_app.h"
#include "duConnMgr.h"
#include "dusimEncoder.h"
#include "decoder.h"
//#include "dusim_context.h"
#include "sim_defs.h"
#include "dusim_init.h"


/* This function initializes the DU simulator */
sim_return_val_et init_du_sim(void* ptr)
{
    proto_simulator_t* pDUSim = (proto_simulator_t*)ptr;
    unsigned short     index  = 0;

    /* Ensure that received pointer is valid */
    if (NULL == ptr)
    {
        LOG_TRACE("NULL pointer received in DU SIM init \n");
        return SIM_FAILURE;
    }

    LOG_TRACE("Initialization DU SIM \n");

    /* Initialize DU SIM stack */
    if (SIM_SUCCESS != pDUSim->stack->init(NULL))
    {
        LOG_TRACE("Failed to initialize DU SIM stack\n");
        return SIM_FAILURE;
    }

    /* Initialize DU SIM encoder */
    else if (SIM_SUCCESS != pDUSim->encoder->init(NULL))
    {
        LOG_TRACE("Failed to initialize DU SIM encoder\n");
        return SIM_FAILURE;
    }

    /* Initialize DU SIM decoder */
    else if (SIM_SUCCESS != pDUSim->decoder->init(NULL))
    {
        LOG_TRACE("Failed to initialize DU SIM decoder\n");
        return SIM_FAILURE;
    }

    /* Initialize DU SIM stack app */
    else if (SIM_SUCCESS != pDUSim->stackApp->init(NULL))
    {
        LOG_TRACE("Failed to initialize DU SIM stack app\n");
        return SIM_FAILURE;
    }

    /* Initialize DU SIM command interpreter */
    else if (SIM_SUCCESS != pDUSim->cmd_interpreter->init(NULL))
    {
        LOG_TRACE("Failed to initialize DU SIM cmd interpreter\n");
        return SIM_FAILURE;
    }

    /* Initialize DU SIM connection handlers */
    else 
    {
        for (index = 0; index < pDUSim->num_peer_conn_hdlr; index++)
        {
            if (SIM_SUCCESS != pDUSim->peer_conn_hdlr[index]->init(NULL))
            {
                LOG_TRACE("Failed to initialize DU SIM connection hdlr\n");
                return SIM_FAILURE;
            }
        }
    }

    return SIM_SUCCESS;
}


/* This function wil read and store DU sim configuration file */
void read_du_sim_config()
{
}


/* This function creates all the required components of DU Sim */
sim_return_val_et create_du_sim_components(proto_simulator_t* du_sim)
{
    /* Ensure that received pointer is valid */
    if (NULL == du_sim)
    {
        LOG_TRACE("Invalid pointer received\n");
        return SIM_FAILURE;
    }

    /* Create command interpreter */
    du_sim->cmd_interpreter = create_du_sim_cmd_intrepreter();
    if (NULL == du_sim->cmd_interpreter)
    {
        LOG_TRACE("Failed to create cmd interpreter for DU sim\n");
        return SIM_FAILURE;
    }

    /* Create encoder */
    du_sim->encoder = create_du_sim_encoder();
    if (NULL == du_sim->encoder)
    {
        LOG_TRACE("Failed to create encoder for DU sim\n");
        return SIM_FAILURE;
    }

    /* Create decoder */
    du_sim->decoder = create_du_sim_decoder();
    if (NULL == du_sim->decoder)
    {
        LOG_TRACE("Failed to create decoder for DU sim\n");
        return SIM_FAILURE;
    }

    /* Create stack */
    du_sim->stack = create_du_sim_stack();
    if (NULL == du_sim->stack)
    {
        LOG_TRACE("Failed to create stack for DU sim\n");
        return SIM_FAILURE;
    }

    /* Create stackApp */
    du_sim->stackApp = create_du_sim_stack_app();
    if (NULL == du_sim->stackApp)
    {
        LOG_TRACE("Failed to create stackApp for DU sim\n");
        return SIM_FAILURE;
    }

    /* Create peer connection manager */
    du_sim->conn_mgr = create_du_sim_peer_conn_mgr();
    if (NULL == du_sim->conn_mgr)
    {
        LOG_TRACE("Failed to create peer connection manager for DU sim\n");
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}


/* This function registers DU sim with the framework */
sim_return_val_et register_du_sim()
{
    proto_simulator_t*  du_sim = NULL;
   
    /* Read DU sim configuration */
    read_du_sim_config();

    /* Allocate new protocol simulator */
    du_sim = allocate_new_proto_simulator();
    if (NULL == du_sim)
    {
        LOG_TRACE("Failed to allocate DU simulator \n");
        return SIM_FAILURE;
    }

    /* Create all the components of DU sim */
    if (SIM_FAILURE == create_du_sim_components(du_sim))
    {
        LOG_TRACE("Failed to create DU sim components \n");
        return SIM_FAILURE;
    }

    /* Populate initialization function of DU simulator */
    du_sim->init = init_du_sim;

    /* Populate simulator identifier */
    du_sim->identifier = DUSIM_ID;

    /* Register DU simulator with the framework */
    if (SIM_SUCCESS != register_proto_simulator(du_sim))
    {
        LOG_TRACE("Failed to register DU simulator with framework \n");
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}

