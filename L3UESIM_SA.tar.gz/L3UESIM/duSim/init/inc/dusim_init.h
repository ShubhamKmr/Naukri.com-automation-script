#include "typedefs.h"
/* This function registers DU sim with the framework */
sim_return_val_et register_du_sim();
sim_return_val_et register_rrm_sim();
