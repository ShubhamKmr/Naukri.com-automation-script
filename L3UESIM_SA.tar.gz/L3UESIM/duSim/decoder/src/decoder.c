    /***************************************************************************
     * *
     * *  ARICENT -
     * *
     * *  Copyright (c) 2018 Aricent.
     * *
     * ****************************************************************************
     * *
     * *  File Description : This file contains the encoder calling  functions
     * *                     exposed by DU sim for encoding messages.
     * *
     * ***************************************************************************/
    /* Standard includes */
    #include <stddef.h>
    #include <stdio.h>
    #include <stdlib.h>

    /* Project includes */
    #include "lteTypes.h"
    #include "decoder.h"
    #include "typedefs.h"
    //#include "stack_app_cmd_interpreter_intf.h"
    #include "intf_mgmnt.h"
    #include "ueContextMgmnt.h"
    #include "rrcMsgTransfer.h"
    #include "f1ap_asn_enc_dec_3gpp.h"


    /* This function decodes the initiating ASN message 
     * and returns to caller */
    sim_return_val_et
    decode_f1_initiating_msg(
                      OSCTXT*         asn1_ctx, 
                      f1ap_F1AP_PDU*  asnMsg, 
                      void**          msgOutBuf, 
                      unsigned long*  msgOutBufLen)
    {
        switch(asnMsg->u.initiatingMessage->value.t)
        {
            case T2f1ap__f1Setup:
            {
                LOG_TRACE("Decode F1Setup Request\n");
                return decode_f1Setup_response(
                                       asn1_ctx,
                                       asnMsg,
                                       msgOutBuf,
                                       msgOutBufLen);
            }

            case T2f1ap__reset:
            {
                LOG_TRACE("Decode Reset Request\n");
                return decode_reset_request(
                                       asn1_ctx,
                                       asnMsg,
                                       msgOutBuf,
                                       msgOutBufLen);
            }

            case T2f1ap__errorIndication:
            {
                LOG_TRACE("Decode Error Indication\n");
                return decode_error_indication(
                                       asn1_ctx,
                                       asnMsg,
                                       msgOutBuf,
                                       msgOutBufLen);
            }

            case T2f1ap__gNBCUConfigurationUpdate:
            {
                LOG_TRACE("Decode CU Configuration Update\n");
                return decode_cu_config_update(
                                       asn1_ctx,
                                       asnMsg,
                                       msgOutBuf,
                                       msgOutBufLen);
            }
            case T3f1ap__gNBDUConfigurationUpdate:
            {
                LOG_TRACE("Decode CU Configuration Update\n");
                return decode_du_config_update_ack(
                    asn1_ctx,
                    asnMsg,
                    msgOutBuf,
                    msgOutBufLen);
        }

        case T2f1ap__uEContextSetup:
        {
            LOG_TRACE("Decode CU initiated UE Context Setup Request\n");
            return decode_ue_ctx_setup_request(
                                   //asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }
        case T2f1ap__uEContextModification:
        {
            LOG_TRACE("Decode CU initiated UE Context Modification Request \n");
            return decode_ue_ctx_mod_request(
                    asn1_ctx,
                    asnMsg,
                    msgOutBuf,
                    msgOutBufLen);
        }
        case T2f1ap__uEContextRelease:
        {
            LOG_TRACE("Decode CU initiated UE Context Release Command \n");
            return decode_ue_ctx_release_command(
                    asn1_ctx,
                    asnMsg,
                    msgOutBuf,
                    msgOutBufLen);
        }


                
        case T2f1ap__dLRRCMessageTransfer:
        {
            LOG_TRACE("Decode DL RRC Message Transfer \n");
            return decode_dl_rrc_msg_transfer(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

#if 0
        case T1f1ap__uLRRCMessageTransfer:
        {
            LOG_TRACE("Decode UL RRC Message Transfer \n");
            return decode_ul_rrc_msg_transfer(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }
#endif
        default:
        {
            LOG_TRACE("Unsupported initiating message: %d\n",
                      asnMsg->u.initiatingMessage->value.t);
            break;
        }
    }

    return SIM_SUCCESS;
}


/* This function decodes the successful ASN message 
 * and returns to caller */
sim_return_val_et
decode_f1_successful_outcome(
              OSCTXT*         asn1_ctx, 
              f1ap_F1AP_PDU*  asnMsg, 
              void**          msgOutBuf, 
              unsigned long*  msgOutBufLen)
{
    switch(asnMsg->u.successfulOutcome->value.t)
    {
        case T2f1ap__f1Setup:
        {
            LOG_TRACE("Decode F1Setup Response \n");
            return decode_f1Setup_response(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

        case T2f1ap__reset:
        {
            LOG_TRACE("Decode Reset Response \n");
            return decode_reset_ack(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

        case T2f1ap__gNBCUConfigurationUpdate:
        {
            LOG_TRACE("Decode CU Configuration Update ACK \n");
            return decode_cu_config_update_ack(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

	case T3f1ap__gNBDUConfigurationUpdate:
	{
		LOG_TRACE("Decode CU Configuration Update\n");
		return decode_du_config_update_ack(
				asn1_ctx,
				asnMsg,
				msgOutBuf,
				msgOutBufLen);
	}
   
	/* UE CONTEXT MODIFICATION CONFIRM start */
	case T2f1ap__uEContextModificationRequired:
	{
		LOG_TRACE("Decode UE CTX MOD CONFIRM Message \n");
		return decode_ue_ctx_modification_confirm(
				asn1_ctx,
				asnMsg,
				msgOutBuf,
				msgOutBufLen);
	}
	/* UE CONTEXT MODIFICATION CONFIRM stop */


#if 0
        case T1f1ap__uEContextSetup:
        {
            LOG_TRACE("Decode UE Context Setup Response \n");
            return decode_ue_ctx_setup_response(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }
        case T1f1ap__uEContextRelease:
        {
            LOG_TRACE("Decode UE Context Release Complete \n");
            return decode_ue_ctx_release_complete(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

        case T1f1ap__uEContextModification:
        {
            LOG_TRACE("Decode UE Context Modification Response \n");
            return decode_ue_ctx_mod_response(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }
#endif
        default:
        {
            LOG_TRACE("Unsupported successful outcome message: %d\n",
                      asnMsg->u.successfulOutcome->value.t);
        }
    }

    return SIM_FAILURE;
}


/* This function decodes the unsuccessful ASN message 
 * and returns to caller */
sim_return_val_et
decode_f1_unsuccessful_outcome(
                      OSCTXT*         asn1_ctx, 
                      f1ap_F1AP_PDU*  asnMsg, 
                      void**          msgOutBuf, 
                      unsigned long*  msgOutBufLen)
{
    switch(asnMsg->u.unsuccessfulOutcome->value.t)
    {
        case T3f1ap__gNBDUConfigurationUpdate:
        {
            LOG_TRACE("Decode CU Configuration Update\n");
            return decode_du_config_update_fail(
                    asn1_ctx,
                    asnMsg,
                    msgOutBuf,
                    msgOutBufLen);
        }

        case T2f1ap__f1Setup:
        {
            LOG_TRACE("Decode F1Setup failure\n");
            return decode_f1Setup_failure(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

    #if 0
        case T1f1ap__gNBCUConfigurationUpdate:
        {
            LOG_TRACE("Decode CU Configuration Update Failure\n");
            return decode_cu_config_update_failure(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
        }

        case T1f1ap__uEContextSetup:
        {
            LOG_TRACE("Decode UE Context Setup Failure \n");
            return decode_ue_ctx_setup_failure(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
            break;
        }

        case T1f1ap__uEContextModification:
        {
            LOG_TRACE("Decode UE Context Modification Failure\n");
            return decode_ue_ctx_mod_failure(
                                   asn1_ctx,
                                   asnMsg,
                                   msgOutBuf,
                                   msgOutBufLen);
            break;
        }
#endif
        default:
        {
            LOG_TRACE("Unsupported unsuccessful message: %d\n",
                      asnMsg->u.unsuccessfulOutcome->value.t);

            return SIM_FAILURE;
        }
    }

    return SIM_SUCCESS;
}


/* This function decodes the message */
unsigned char du_sim_decode(
        void*          msgInBuf,
        long           msgInBufLen,
        void**         msgOutBuf,
        unsigned long* msgOutBufLen)
{
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          asnMsg;
    int                    result     = !RT_OK;
    sim_return_val_et      retVal     = SIM_FAILURE;

    result = rtInitContext(&asn1_ctx);
    if (RT_OK != result)
    {
        LOG_TRACE("Failed to initialize ASN context \n");
        return 0;
    }

    pu_setBuffer(&asn1_ctx, msgInBuf, msgInBufLen,
                 TRUE);

    if (RT_OK != asn1PD_f1ap_F1AP_PDU(&asn1_ctx, &asnMsg))
    {
        LOG_TRACE("Failed to decode F1AP PDU\n");
        return retVal;
    }

    if (T_f1ap_F1AP_PDU_initiatingMessage == asnMsg.t)
    {
        retVal = decode_f1_initiating_msg(&asn1_ctx, &asnMsg, 
                       msgOutBuf, msgOutBufLen);
    }
    else if (T_f1ap_F1AP_PDU_successfulOutcome == asnMsg.t)
    {
        retVal = decode_f1_successful_outcome(&asn1_ctx, &asnMsg, 
                       msgOutBuf, msgOutBufLen);
    }
    else if (T_f1ap_F1AP_PDU_unsuccessfulOutcome == asnMsg.t)
    {
        retVal = decode_f1_unsuccessful_outcome(&asn1_ctx, &asnMsg, 
                       msgOutBuf, msgOutBufLen);
    }
    else
    {
        LOG_TRACE("Unknown message type: %d\n", asnMsg.t);
        return retVal;
    }

    /* Free the ASN context */
    //rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


/* This function initializes the DU sim decoder */
sim_return_val_et du_sim_decoder_init()
{
    LOG_TRACE("DU sim decoder initialization \n");
    return SIM_SUCCESS;
}


/* This function creates and return decoder for DU sim */
decoder_t* create_du_sim_decoder()
{
    decoder_t* decoder = NULL;

    /* Allocate decoder for DU simulator */
    decoder  = allocate_new_proto_decoder();
    if (NULL == decoder)
    {
        LOG_TRACE("Failed to allocate decoder for DU sim \n");
        return decoder;
    }

    /* Initialize the function pointers of decoder */
    decoder->init   = du_sim_decoder_init;
    decoder->decode = du_sim_decode; 

    return decoder;
}

