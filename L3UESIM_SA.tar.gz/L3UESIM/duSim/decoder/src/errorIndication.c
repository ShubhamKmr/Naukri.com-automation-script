
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"


sim_return_val_et
decode_error_indication(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_ErrorIndication* p_trg_msg          = NULL;
    f1ap_ErrorIndication*  p_src_msg          = NULL;
    f1ap_ErrorIndication_protocolIEs_element*
                           p_protocolIE_elem  = NULL;
    OSRTDListNode*         p_node             = NULL;
    U8                     ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_ErrorIndication);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target Error Indication container */
    p_trg_msg = (_f1ap_ErrorIndication*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                             u.errorIndication;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source Error Indication 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = (f1ap_ErrorIndication_protocolIEs_element*)
                                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transactionId = p_protocolIE_elem->value.
                    u._f1ap_ErrorIndicationIEs_1;

                break;
            }

            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                /* Set the flag to indicate that gNB CU F1AP ID 
                 * is present in the Error Indication */
                p_trg_msg->bitmask 
                     |= F1AP_ERROR_INDICATION_CU_UE_F1AP_ID_PRESENT;

                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_ErrorIndicationIEs_2; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                /* Set the flag to indicate that gNB DU F1AP ID 
                 * is present in the Error Indication */
                p_trg_msg->bitmask 
                     |= F1AP_ERROR_INDICATION_DU_UE_F1AP_ID_PRESENT;

                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_ErrorIndicationIEs_3;

                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = NULL;
                _f1ap_Cause* p_trg_cause = NULL;

                /* Fetch pointer to source container */
                p_src_cause = p_protocolIE_elem->value.u.
                                    _f1ap_ErrorIndicationIEs_4; 

                /* Set the flag to indicate that Cause IE
                 * is present in the Error Indication */
                p_trg_msg->bitmask 
                     |= F1AP_ERROR_INDICATION_CRIT_DIAG_PRESENT;

                /* Fetch pointer to target container */
                p_trg_cause = &p_trg_msg->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                     = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                        p_trg_cause->u.transport 
                                     = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                        p_trg_cause->u.protocol 
                                     = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_MISC;

                        p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid cause type received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                                      u._f1ap_ErrorIndicationIEs_5;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the Error Indication */
                p_trg_msg->bitmask |= F1AP_ERROR_INDICATION_CRIT_DIAG_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}


