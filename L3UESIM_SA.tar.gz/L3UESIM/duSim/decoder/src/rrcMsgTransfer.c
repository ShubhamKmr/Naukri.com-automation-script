
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"

sim_return_val_et
decode_dl_rrc_msg_transfer(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_DLRRCMessageTransfer* p_trg_msg          = NULL;
    f1ap_DLRRCMessageTransfer*  p_src_msg          = NULL;
    f1ap_DLRRCMessageTransfer_protocolIEs_element*
                                p_protocolIE_elem  = NULL;
    _f1ap_DLRRCMessageTransfer_protocolIEs_element *
                                 p_trg_protocolIE_elem  = NULL;
    OSRTDListNode*              p_node             = NULL;
    U8                          ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_DLRRCMessageTransfer);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target DL RRC Message Transfer container */
    p_trg_msg = (_f1ap_DLRRCMessageTransfer*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                                    u.dLRRCMessageTransfer;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source DL RRC Message Transfer 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_DLRRCMessageTransfer_protocolIEs_element*)
                   p_node->data;
  
          p_trg_protocolIE_elem = &p_trg_msg->protocolIEs.
                    _f1ap_DLRRCMessageTransfer_protocolIEs_element[ie_count];

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_1.
                f1ap_GNB_CU_UE_F1AP_ID = p_protocolIE_elem->value.
                    u._f1ap_DLRRCMessageTransferIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                 p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_2.
                 f1ap_GNB_DU_UE_F1AP_ID = p_protocolIE_elem->value.
                    u._f1ap_DLRRCMessageTransferIEs_2;

                break;
            }

            case ASN1V_f1ap_id_oldgNB_DU_UE_F1AP_ID:
            {
                p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_3.
                f1ap_GNB_DU_UE_F1AP_ID = p_protocolIE_elem->value.
                    u._f1ap_DLRRCMessageTransferIEs_3;
                break;
            }

            case ASN1V_f1ap_id_SRBID:
            {
                 p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_4.
                     srb_id = p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_4;

                break;
            }

            case ASN1V_f1ap_id_RRCContainer:
            {
               // p_trg_msg->rrcContainerLength = p_protocolIE_elem->value.
               //     u._f1ap_DLRRCMessageTransferIEs_5.numocts;

               // memcpy(p_trg_msg->rrcContainer,
                 //      p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_5.data,
                   //    p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_5.numocts);

                break;
            }
            case ASN1V_f1ap_id_ExecuteDuplication:
            {
               p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_5.
                   f1ap_ExecuteDuplication = p_protocolIE_elem->value.
                   u._f1ap_DLRRCMessageTransferIEs_5;

                break;
            }
            case ASN1V_f1ap_id_RAT_FrequencyPriorityInformation:
            {
               p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7.
               t = p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7->t;
           
                if (1 == p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7->t)
                {
                     p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7.
                    u.subscriberProfileIDforRFP.f1ap_SubscriberProfileIDforRFP
                      = p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7->
                        u.subscriberProfileIDforRFP;
                 }
                 else if(2 == p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7->t)
                {

                     p_trg_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_7.
                    u.rAT_FrequencySelectionPriority.f1ap_RAT_FrequencySelectionPriority
                       = p_protocolIE_elem->value.
                     u._f1ap_DLRRCMessageTransferIEs_7->u.rAT_FrequencySelectionPriority;
                }
                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}

#if 0
sim_return_val_et
decode_ul_rrc_msg_transfer(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_ULRRCMessageTransfer* p_trg_msg          = NULL;
    f1ap_ULRRCMessageTransfer*  p_src_msg          = NULL;
    f1ap_ULRRCMessageTransfer_protocolIEs_element*
                                p_protocolIE_elem  = NULL;
    OSRTDListNode*              p_node             = NULL;
    U8                          ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_ULRRCMessageTransfer);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UL RRC Message Transfer container */
    p_trg_msg = (_f1ap_ULRRCMessageTransfer*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                                    u.uLRRCMessageTransfer;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UL RRC Message Transfer 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_ULRRCMessageTransfer_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_ULRRCMessageTransferIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_ULRRCMessageTransferIEs_2;

                break;
            }

            case ASN1V_f1ap_id_SRBID:
            {
                p_trg_msg->srb_id = p_protocolIE_elem->value.
                    u._f1ap_ULRRCMessageTransferIEs_3;

                break;
            }

            case ASN1V_f1ap_id_RRCContainer:
            {
                p_trg_msg->rrcContainerLength = p_protocolIE_elem->value.
                    u._f1ap_ULRRCMessageTransferIEs_4->numocts;

                memcpy(p_trg_msg->rrcContainer,
                       p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4->data,
                       p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4->numocts);

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}
#endif

