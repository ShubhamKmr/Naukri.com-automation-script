/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for decoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"


/*******************************************************************************
 * Function Name  : populate_scell_remove_nr_cgi_info
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : None
 ******************************************************************************/
void populate_scell_remove_nr_cgi_info
(
   f1ap_NRCGI*          p_src_ncgi,
   f1ap_adpt_ncgi_t*    p_trg_ncgi
)
{
    p_trg_ncgi->plmn_identity.numocts
        = p_src_ncgi->pLMN_Identity.numocts;

    memcpy(p_trg_ncgi->plmn_identity.data,
            p_src_ncgi->pLMN_Identity.data,
            p_src_ncgi->pLMN_Identity.numocts);

    p_trg_ncgi->nr_cellidentity.num_bits
        = p_src_ncgi->nRCellIdentity.numbits;

    memcpy(p_trg_ncgi->nr_cellidentity.data,
           p_src_ncgi->nRCellIdentity.data,
           5);
}

/*******************************************************************************
 * Function Name  : populate_spcell_nr_cgi_info
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : None
 ******************************************************************************/
void populate_spcell_nr_cgi_info
(
   f1ap_NRCGI*          p_src_ncgi,
   f1ap_adpt_ncgi_t*    p_trg_ncgi
)
{
    p_trg_ncgi->plmn_identity.numocts
        = p_src_ncgi->pLMN_Identity.numocts;

    memcpy(p_trg_ncgi->plmn_identity.data,
            p_src_ncgi->pLMN_Identity.data,
            p_src_ncgi->pLMN_Identity.numocts);

    p_trg_ncgi->nr_cellidentity.num_bits
        = p_src_ncgi->nRCellIdentity.numbits;

    memcpy(p_trg_ncgi->nr_cellidentity.data,
           p_src_ncgi->nRCellIdentity.data,
           5);
}

/*******************************************************************************
 * Function Name  : populate_scell_nr_cgi_info
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : None
 ******************************************************************************/
void populate_scell_nr_cgi_info
(
   f1ap_NRCGI*          p_src_ncgi,
   f1ap_adpt_ncgi_t*    p_trg_ncgi
)
{
    p_trg_ncgi->plmn_identity.numocts
        = p_src_ncgi->pLMN_Identity.numocts;

    memcpy(p_trg_ncgi->plmn_identity.data,
            p_src_ncgi->pLMN_Identity.data,
            p_src_ncgi->pLMN_Identity.numocts);

    p_trg_ncgi->nr_cellidentity.num_bits
        = p_src_ncgi->nRCellIdentity.numbits;

    memcpy(p_trg_ncgi->nr_cellidentity.data,
           p_src_ncgi->nRCellIdentity.data,
           5);
}

/*******************************************************************************
 * Function Name  : populate_ul_tx_dir_current_list_info
 * Description    : This function decodes ul tx dir current info of UE ctxt mod request 
 *                  received from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
void populate_ul_tx_dir_current_list_info
(
    OSDynOctStr*			                 p_src_ul_tx_info,
    f1ap_UplinkTxDirectCurrentListInformation_t*         p_trg_ul_tx_info
)
{

	p_trg_ul_tx_info->numocts 
		= p_src_ul_tx_info->numocts;

	memcpy(p_trg_ul_tx_info->data,
			p_src_ul_tx_info->data,
			p_src_ul_tx_info->numocts);

}

/*******************************************************************************
 * Function Name  : populate_adpt_rat_freq_info
 * Description    : This function encodes the rat freq info  received from adaptation
 *                  layer to ASN encoded format.
 * Inputs         : f1ap_adpt_ue_context_mod_req_t* : p_src_adpt_cause
 *                  Pointer to F1AP Cause received from adaptation layer
 *                  f1ap_RAT_FrequencyPriorityInformation* : p_encoded_msg
 *                  Pointer to receive ASN encoded RAt Freq Info.
 * Outputs        : ASN Encoded F1AP rAT Freq Info.
 * Returns        : None
 ******************************************************************************/
void populate_adpt_rat_freq_info
(   
    f1ap_RAT_FrequencyPriorityInformation*         p_src_rat_freq_info,
    f1ap_RAT_FrequencyPriorityInformation_t*       p_trg_rat_freq_info
)
{
    switch(p_src_rat_freq_info->t)
    {
        case T_f1ap_RAT_FrequencyPriorityInformation_subscriberProfileIDforRFP: 
        {
            p_trg_rat_freq_info->type = 
			T_f1ap_RAT_FrequencyPriorityInformation_subscriberProfileIDforRFP;

            p_trg_rat_freq_info->u.subscriberProfileIDforRFP = 
			p_src_rat_freq_info->u.subscriberProfileIDforRFP;

            break;
        }

        case T_f1ap_RAT_FrequencyPriorityInformation_rAT_FrequencySelectionPriority: 
        {

            p_trg_rat_freq_info->type = 
			T_f1ap_RAT_FrequencyPriorityInformation_rAT_FrequencySelectionPriority;
	
            p_trg_rat_freq_info->u.rAT_FrequencySelectionPriority = 
			p_src_rat_freq_info->u.rAT_FrequencySelectionPriority;

            break;
        }

        default:
        {
            LOG_TRACE("Invalid rAT Freq Info type received \n");
            break;
        }
    }
}

/*******************************************************************************
 * Function Name  : populate_drb_modified_ul_tunnel_info_list
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context mod buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : 
 ******************************************************************************/

void populate_drb_modified_ul_tunnel_info_list
(
    f1ap_DRBs_ToBeModified_Item*                    p_src_item,
    f1ap_adpt_drbs_to_be_mod_list_element_t*        p_trg_item
)
{
    OSRTDListNode*     				    p_tunnel_node     = PNULL;
    UInt16             				    tunnel_index      = 0;
    f1ap_ULUPTNLInformation_ToBeSetup_List*         p_src_tunnel_list = NULL;
    f1ap_ULUPTNLInformation_ToBeSetup_Item*         p_src_tunnel_elem = NULL;

    f1ap_adpt_ul_tunnels_to_be_mod_list_element_t*          
						    p_trg_tunnel_item   = NULL;

    p_src_tunnel_list = &p_src_item->uLUPTNLInformation_ToBeSetup_List;
    p_tunnel_node = p_src_tunnel_list->head;

    p_trg_item->ul_tunnel_mod_list.count = 
                    		p_src_tunnel_list->count;

    for (tunnel_index = 0;
         tunnel_index < p_src_tunnel_list->count;
         tunnel_index++)
    {
        p_src_tunnel_elem 
            = (f1ap_ULUPTNLInformation_ToBeSetup_Item*)p_tunnel_node->data;

        p_trg_tunnel_item = &p_trg_item->ul_tunnel_mod_list.
                                 ul_tunnel_tobe_mod[tunnel_index];

        p_trg_tunnel_item->type = p_src_tunnel_elem->uLUPTNLInformation.t;                         

        if ( p_trg_tunnel_item->type == 1)
        {
        p_trg_tunnel_item->u.tunnelep.transport_address_length =
            (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->
                                 transportLayerAddress.numbits/8);

        memcpy(p_trg_tunnel_item->u.tunnelep.transport_layer_address,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits/8));

        p_trg_tunnel_item->u.tunnelep.gtp_teid.num_octs =
            p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts;

        memcpy(p_trg_tunnel_item->u.tunnelep.gtp_teid.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts);

       }         

        p_tunnel_node = p_tunnel_node->next;
    }
}


/*******************************************************************************
 * Function Name  : populate_drbs_to_be_modified_list
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context mod buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : 
 ******************************************************************************/

void populate_drbs_to_be_modified_list
(
    f1ap_DRBs_ToBeModified_Item*                    p_src_item,
    f1ap_adpt_drbs_to_be_mod_list_element_t*        p_trg_item
)
{

    p_trg_item->drb_id = p_src_item->dRBID;

    p_trg_item->qoSInformation.type =  
			p_src_item->qoSInformation.t;

    if (p_trg_item->qoSInformation.type == 1)
    {
        p_trg_item->qoSInformation.u.qos.qci = 
			p_src_item->qoSInformation.u.eUTRANQoS->qCI;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			priority_level = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.priorityLevel;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			pre_emption_capability = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.pre_emptionCapability;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			pre_emption_vulnerability = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.pre_emptionVulnerability;

        if (p_src_item->qoSInformation.u.eUTRANQoS->m.gbrQosInformationPresent)
        {
            p_trg_item->qoSInformation.u.qos.bitmask |= 
			F1AP_ADPT_GBR_QOS_INFO_PRESENT;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_maximum_bitrate_dl = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_MaximumBitrateDL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.e_rab_maximum_bitrate_ul =
                p_src_item->qoSInformation.u.eUTRANQoS->gbrQosInformation.e_RAB_MaximumBitrateUL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_guaranteed_bitrate_dl = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_GuaranteedBitrateDL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_guaranteed_bitrate_ul = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_GuaranteedBitrateUL;
        }
    }    
}


/*******************************************************************************
 * Function Name  : populate_ul_tunnel_info_list
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context mod buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : 
 ******************************************************************************/

void populate_ul_tunnel_info_list
(
    f1ap_DRBs_ToBeSetupMod_Item*                    p_src_item,
    f1ap_adpt_drbs_to_be_setup_mod_list_element_t*  p_trg_item
)
{
    OSRTDListNode*     				    p_tunnel_node     = PNULL;
    UInt16             				    tunnel_index      = 0;
    f1ap_ULUPTNLInformation_ToBeSetup_List*         p_src_tunnel_list = NULL;
    f1ap_ULUPTNLInformation_ToBeSetup_Item*         p_src_tunnel_elem = NULL;

    f1ap_adpt_ul_tunnels_to_be_setup_mod_list_element_t*   
        				          p_trg_tunnel_item   = NULL;

    p_src_tunnel_list = &p_src_item->uLUPTNLInformation_ToBeSetup_List;
    p_tunnel_node = p_src_tunnel_list->head;

    p_trg_item->ul_tunnel_setup_mod_list.count = 
                    		p_src_tunnel_list->count;

    for (tunnel_index = 0;
         tunnel_index < p_src_tunnel_list->count;
         tunnel_index++)
    {
        p_src_tunnel_elem 
            = (f1ap_ULUPTNLInformation_ToBeSetup_Item*)p_tunnel_node->data;

        p_trg_tunnel_item = &p_trg_item->ul_tunnel_setup_mod_list.
                                 ul_tunnel_tobe_setup_mod[tunnel_index];

        p_trg_tunnel_item->type = p_src_tunnel_elem->uLUPTNLInformation.t;                         

        if ( p_trg_tunnel_item->type == 1)
        {
        p_trg_tunnel_item->u.tunnelep.transport_address_length =
            (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->
                                 transportLayerAddress.numbits/8);

        memcpy(p_trg_tunnel_item->u.tunnelep.transport_layer_address,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits/8));

        p_trg_tunnel_item->u.tunnelep.gtp_teid.num_octs =
            p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts;

        memcpy(p_trg_tunnel_item->u.tunnelep.gtp_teid.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts);

       }         

        p_tunnel_node = p_tunnel_node->next;
    }
}


/*******************************************************************************
 * Function Name  : populate_drbs_to_be_setup_mod_list
 * Description    : This function decodes UE Context mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context mod buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : 
 ******************************************************************************/

void populate_drbs_to_be_setup_mod_list
(
    f1ap_DRBs_ToBeSetupMod_Item*                    p_src_item,
    f1ap_adpt_drbs_to_be_setup_mod_list_element_t*  p_trg_item
)
{

    p_trg_item->drb_id = p_src_item->dRBID;

    p_trg_item->qoSInformation.type =  
			p_src_item->qoSInformation.t;

    if (p_trg_item->qoSInformation.type == 1)
    {
        p_trg_item->qoSInformation.u.qos.qci = 
			p_src_item->qoSInformation.u.eUTRANQoS->qCI;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			priority_level = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.priorityLevel;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			pre_emption_capability = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.pre_emptionCapability;

        p_trg_item->qoSInformation.u.qos.allocation_and_retention_priority.
			pre_emption_vulnerability = p_src_item->qoSInformation.u.
				eUTRANQoS->allocationAndRetentionPriority.pre_emptionVulnerability;

        if (p_src_item->qoSInformation.u.eUTRANQoS->m.gbrQosInformationPresent)
        {
            p_trg_item->qoSInformation.u.qos.bitmask |= 
			F1AP_ADPT_GBR_QOS_INFO_PRESENT;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_maximum_bitrate_dl = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_MaximumBitrateDL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.e_rab_maximum_bitrate_ul =
                p_src_item->qoSInformation.u.eUTRANQoS->gbrQosInformation.e_RAB_MaximumBitrateUL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_guaranteed_bitrate_dl = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_GuaranteedBitrateDL;

            p_trg_item->qoSInformation.u.qos.gbr_qos_information.
			e_rab_guaranteed_bitrate_ul = p_src_item->qoSInformation.u.
				eUTRANQoS->gbrQosInformation.e_RAB_GuaranteedBitrateUL;
        }
   }    
}

/*******************************************************************************
 * Function Name  : populate_rrc_container_info
 * Description    : This function decodes rrc container info of UE ctxt mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : 
 ******************************************************************************/
void populate_rrc_container_info
(
    OSDynOctStr*                         p_src_rrc_contnr_info,
    f1ap_adpt_rrc_t*	   	         p_trg_rrc_contbr_info
)
{

	p_trg_rrc_contbr_info->numocts 
		= p_src_rrc_contnr_info->numocts;

	memcpy(p_trg_rrc_contbr_info->data,
			p_src_rrc_contnr_info->data,
			p_src_rrc_contnr_info->numocts);

}

/*******************************************************************************
 * Function Name  : populate_resource_coord_info
 * Description    : This function decodes RESOURCE COORD INFO of UE ctxt mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
void populate_resource_coord_info
(
    OSDynOctStr*			                 p_src_resrc_coord_info,
    f1ap_ResourceCoordinationTransferContainer_t*        p_trg_resrc_coord_info
)
{

	p_trg_resrc_coord_info->numocts 
		= p_src_resrc_coord_info->numocts;

	memcpy(p_trg_resrc_coord_info->data,
			p_src_resrc_coord_info->data,
			p_src_resrc_coord_info->numocts);

}


/*******************************************************************************
 * Function Name  : populate_cu_du_rrc_info
 * Description    : This function decodes CU-DU-RRC Info of UE ctxt mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
void populate_cu_du_rrc_info
(
    f1ap_CUtoDURRCInformation*          p_src_cudurrc_info_msg,
    f1ap_CUtoDURRCInformation_t*        p_trg_cudurrc_info_msg
)
{

	if(p_src_cudurrc_info_msg->m.cG_ConfigInfoPresent)
	{
		p_trg_cudurrc_info_msg->bitmask |= 
			F1AP_UE_CTXT_MODIFIED_REQ_CG_CONFIG_INFO_PRESENT;

		p_trg_cudurrc_info_msg->cG_config_info.numocts 
			= p_src_cudurrc_info_msg->cG_ConfigInfo.numocts;
		
		memcpy(p_trg_cudurrc_info_msg->cG_config_info.data,
			p_src_cudurrc_info_msg->cG_ConfigInfo.data,
			p_src_cudurrc_info_msg->cG_ConfigInfo.numocts);
	}
	if(p_src_cudurrc_info_msg->m.uE_CapabilityRAT_ContainerListPresent)
	{
		p_trg_cudurrc_info_msg->bitmask |= 
			F1AP_UE_CTXT_MODIFIED_REQ_EE_CAPABILITYRAT_CONTAINER_LIST_PRESENT;

		p_trg_cudurrc_info_msg->uE_capability_rat_cont_list.numocts 
			= p_src_cudurrc_info_msg->uE_CapabilityRAT_ContainerList.numocts;
		
		memcpy(p_trg_cudurrc_info_msg->uE_capability_rat_cont_list.data,
			p_src_cudurrc_info_msg->uE_CapabilityRAT_ContainerList.data,
			p_src_cudurrc_info_msg->uE_CapabilityRAT_ContainerList.numocts);
	}

	if(p_src_cudurrc_info_msg->m.measConfigPresent)
	{
		p_trg_cudurrc_info_msg->bitmask |= 
			F1AP_UE_CTXT_MODIFIED_REQ_MEASCONFIG_PRESENT;

		p_trg_cudurrc_info_msg->meas_config.numocts 
			= p_src_cudurrc_info_msg->measConfig.numocts;

		memcpy(p_trg_cudurrc_info_msg->meas_config.data,
				p_src_cudurrc_info_msg->measConfig.data,
				p_src_cudurrc_info_msg->measConfig.numocts);
	}
}


/*******************************************************************************
 * Function Name  : populate_drx_cycle_info
 * Description    : This function decodes drx cycle of UE ctxt mod request received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context setup buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_req_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod request from ASN Format.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
void populate_drx_cycle_info 
(
    f1ap_DRXCycle*          p_src_drx_msg,
    _f1ap_DRXCycle*         p_trg_drx_msg
)
{

	p_trg_drx_msg->longDRXCycleLength = p_src_drx_msg->longDRXCycleLength;

	if(p_src_drx_msg->m.shortDRXCycleLengthPresent)
	{
		p_trg_drx_msg->bitmask |= 
			F1AP_ADPT_UE_CTX_SETUP_REQ_shortDRXCycleLength_PRESENT;

		p_trg_drx_msg->shortDRXCycleLength = p_src_drx_msg->shortDRXCycleLength;
	}
	if(p_src_drx_msg->m.shortDRXCycleTimerPresent)
	{
		p_trg_drx_msg->bitmask |= 
			F1AP_ADPT_UE_CTX_SETUP_REQ_shortDRXCycleTimer_PRESENT;

		p_trg_drx_msg->shortDRXCycleTimer = p_src_drx_msg->shortDRXCycleTimer;
	}
}

/*******************************************************************************
 * Function Name  : decode_ue_ctx_mod_request
 * Description    : This function decodes ue ctx modification  request and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLien
 * Outputs        : Decoded ue context modification  msg
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 *
 ******************************************************************************/

sim_return_val_et
decode_ue_ctx_mod_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    f1ap_UEContextModificationRequest*  p_src_msg          = NULL;
    f1ap_UEContextModificationRequest_protocolIEs_element*
                                        p_protocolIE_elem  = NULL;
    f1ap_adpt_ue_context_mod_req_t*   p_trg_msg            = NULL;
    OSRTDListNode*                      p_node             = NULL;
    UInt8                               ie_count           = 0;


    *p_msgOutBufLen = sizeof(f1ap_adpt_ue_context_mod_req_t);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }
 
    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);
    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Modification Request container */
    p_trg_msg = (f1ap_adpt_ue_context_mod_req_t*)(*p_msgOutBuf);

    //asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &asnMsg);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                        u.uEContextModification;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Modification Request 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            rtFreeContext(asn1_ctx);
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextModificationRequest_protocolIEs_element*)
            p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->gNBCUUEF1APID = p_protocolIE_elem->value.
                    u._f1ap_UEContextModificationRequestIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->gNBDUUEF1APID = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationRequestIEs_2;

                break;
            }
	    case ASN1V_f1ap_id_SpCell_ID: 
	    {
		/* Populate NR CGI info */
		populate_spcell_nr_cgi_info(
			p_protocolIE_elem->value.u.
			_f1ap_UEContextModificationRequestIEs_3,
			&p_trg_msg->pscell_id);

		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_NRCGI_PRESENT;

		    break;
	    }

	    case ASN1V_f1ap_id_ServCellndex:
            {

                p_trg_msg->servCellndex 
                    = p_protocolIE_elem->value. 
                    u._f1ap_UEContextModificationRequestIEs_4;

                break;
            }

	    case ASN1V_f1ap_id_SpCellULConfigured:
	    {
		p_trg_msg->bitmask |= 
		    F1AP_ADPT_UE_CTXT_MOD_REQ_SPCELL_UL_CONFIGURED_PRESENT;


		p_trg_msg->spCellULConfigured 
		    = p_protocolIE_elem->value. 
		         u._f1ap_UEContextModificationRequestIEs_5;

		    break;
	    }
	    case ASN1V_f1ap_id_DRXCycle:
	    {

		populate_drx_cycle_info(
			p_protocolIE_elem->value.u.
			_f1ap_UEContextModificationRequestIEs_6,
			&p_trg_msg->dRXCycle);

		p_trg_msg->bitmask |= 
		    F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CYCLE_PRESENT;


		    break;
	    }

	    case ASN1V_f1ap_id_CUtoDURRCInformation:
	    {

		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_CU_DU_RRC_INFORMATION_CONTAINER_PRESENT;

		    populate_cu_du_rrc_info(
				    p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_7,
				    &p_trg_msg->cu_du_rrc_info);

		    break;
	    }

	    case ASN1V_f1ap_id_TransmissionStopIndicator:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_TRANSMISSION_STOP_INDICATOR_PRESENT;

		    p_trg_msg->trans_stop_indicator 
			    = p_protocolIE_elem->value. 
			    u._f1ap_UEContextModificationRequestIEs_8;

		    break;
	    }

	    case ASN1V_f1ap_id_ResourceCoordinationTransferContainer:
	    {

		    p_trg_msg->bitmask |= 
			   F1AP_ADPT_UE_CTXT_MOD_REQ_MENB_RESOURCE_COORDINATION_INFO_PRESENT;

		    populate_resource_coord_info(
				    p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_9,
				    &p_trg_msg->resrc_coord_trans_contnr);

		    break;
	    }

	    case ASN1V_f1ap_id_RRCRconfigurationCompleteIndicator:
	    {
		    p_trg_msg->bitmask |= 
			F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_RCONFIGURATION_COMPLETE_INDICATOR_PRESENT;

		    p_trg_msg->RRCRconfigurationCompleteIndicator 
			    = p_protocolIE_elem->value. 
			    u._f1ap_UEContextModificationRequestIEs_10;

		    break;
	    }

	    case ASN1V_f1ap_id_RRCContainer:
	    {

		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_RRC_CONTAINER_PRESENT;

		    populate_rrc_container_info(
				    p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_11,
				    &p_trg_msg->rrc_container);

		    break;
	    }
	   
	    case ASN1V_f1ap_id_SCell_ToBeSetupMod_List:
	    {

		    f1ap_SCell_ToBeSetupMod_List_element*   p_src_scell_elem   = NULL;
		    OSRTDListNode*                          p_cell_node        = NULL;
		    f1ap_NRCGI*                             p_src_scell_ncgi   = NULL;
		    f1ap_adpt_ncgi_t*                       p_trg_scell_ncgi   = NULL;
		    UInt32                                  index              = 0;

		    /* Populate count of scells in target list */
		    p_trg_msg->scells_to_be_setup_mod_list.count
			    = p_protocolIE_elem->value.u.
			    _f1ap_UEContextModificationRequestIEs_12->count;

		    /* Fetch pointer to the first node in the list */
		    p_cell_node = p_protocolIE_elem->value.
			    u._f1ap_UEContextModificationRequestIEs_12->head;

		    for (index = 0; index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_12->count; 
				    index++)
		    {
			    p_src_scell_elem = (f1ap_SCell_ToBeSetupMod_List_element*)
				    p_cell_node->data;

			    /* Get pointer to source NCGI container */
			    p_src_scell_ncgi  = &p_src_scell_elem->value.u.
				    _f1ap_SCell_ToBeSetupMod_ItemIEs_1->sCell_ID;

			    /* Get pointer to target NCGI container */
			    p_trg_scell_ncgi = &p_trg_msg->scells_to_be_setup_mod_list.
				    scell_to_be_setup_mod[index].cgi;

			    /* Populate NR CGI info */
			    populate_scell_nr_cgi_info(p_src_scell_ncgi,p_trg_scell_ncgi);

			    /* Scell Index */
			    p_trg_msg->scells_to_be_setup_mod_list.
				    scell_to_be_setup_mod[index].scell_index = 
				    p_src_scell_elem->value.u._f1ap_SCell_ToBeSetupMod_ItemIEs_1->sCellIndex;

			    /* SCell-UL-Configured */
			    if (p_src_scell_elem->value.u._f1ap_SCell_ToBeSetupMod_ItemIEs_1->m.sCellULConfiguredPresent == 1)
			    {
				    p_trg_msg->scells_to_be_setup_mod_list.
			 	    scell_to_be_setup_mod[index].bitmask |=
				    F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_UL_CONFIGURED_PRESENT;

				    p_trg_msg->scells_to_be_setup_mod_list.
				    scell_to_be_setup_mod[index].sCellULConfigured = 
				    p_src_scell_elem->value.u._f1ap_SCell_ToBeSetupMod_ItemIEs_1->sCellULConfigured;

			    }
			    /* Get pointer to the next node in the list */
			    p_cell_node = p_cell_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_SETUP_MOD_LIST_PRESENT;
		    break;
	    }

	    case ASN1V_f1ap_id_SCell_ToBeRemoved_List:
	    {

		    f1ap_SCell_ToBeRemoved_List_element*    src_scell_remove_elem   = NULL;
		    OSRTDListNode*                          p_cell_node        	    = NULL;
		    f1ap_NRCGI*                             src_scell_remove_ncgi   = NULL;
		    f1ap_adpt_ncgi_t*                       trg_scell_remove_ncgi   = NULL;
		    UInt32                                  index                   = 0;

		    /* Populate count of scells in target list */
		    p_trg_msg->scells_to_be_removed_list.count
			    = p_protocolIE_elem->value.u.
			    _f1ap_UEContextModificationRequestIEs_13->count;

		    /* Fetch pointer to the first node in the list */
		    p_cell_node = p_protocolIE_elem->value.
			    u._f1ap_UEContextModificationRequestIEs_13->head;

		    for (index = 0; index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_13->count; 
				    index++)
		    {
			    src_scell_remove_elem = (f1ap_SCell_ToBeRemoved_List_element*)
				    			p_cell_node->data;

			    /* Get pointer to source NCGI container */
			    src_scell_remove_ncgi = &src_scell_remove_elem->value.u.
				    		     _f1ap_SCell_ToBeRemoved_ItemIEs_1->sCell_ID;

			    /* Get pointer to target NCGI container */
			    trg_scell_remove_ncgi = &p_trg_msg->scells_to_be_removed_list.
				    			scell_to_be_removed[index].cgi;

			    /* Populate NR CGI info */
			    populate_scell_remove_nr_cgi_info(src_scell_remove_ncgi,trg_scell_remove_ncgi);

			    /* Get pointer to the next node in the list */
			    p_cell_node = p_cell_node->next;
		    }

		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_SCELL_REMOVED_LIST_PRESENT;
		    break;
	    }

	    case ASN1V_f1ap_id_SRBs_ToBeSetupMod_List:
	    {

		    f1ap_SRBs_ToBeSetupMod_List_element*    p_src_srb_elem   = NULL;
		    OSRTDListNode*                          p_cell_node      = NULL;
		    UInt32                                  index            = 0;

		    /* Populate count of scells in target list */
		    p_trg_msg->srb_to_be_setup_mod_list.count
			    = p_protocolIE_elem->value.u.
			      _f1ap_UEContextModificationRequestIEs_14->count;

		    /* Fetch pointer to the first node in the list */
		    p_cell_node = p_protocolIE_elem->value.
			    u._f1ap_UEContextModificationRequestIEs_14->head;

		    for (index = 0; index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_14->count; 
				    index++)
		    {
			    p_src_srb_elem = (f1ap_SRBs_ToBeSetupMod_List_element*)
				    		p_cell_node->data;

			    /* sRB-ID */
			    p_trg_msg->srb_to_be_setup_mod_list.
				    srb_to_be_setup_mod[index].sRBID = 
				    p_src_srb_elem->value.u._f1ap_SRBs_ToBeSetupMod_ItemIEs_1->sRBID;

			    /* Duplication-Indication */
			    if (p_src_srb_elem->value.u._f1ap_SRBs_ToBeSetupMod_ItemIEs_1->m.duplicationIndicationPresent == 1)
			    {
				    p_trg_msg->srb_to_be_setup_mod_list.
					 srb_to_be_setup_mod[index].bitmask |=
					 F1AP_ADPT_UE_CTX_MOD_REQ_DUPLICATION_INDICATION_PRESENT;

				    p_trg_msg->srb_to_be_setup_mod_list.
					    srb_to_be_setup_mod[index].duplicationIndication = 
					    p_src_srb_elem->value.u._f1ap_SRBs_ToBeSetupMod_ItemIEs_1->duplicationIndication;

			    }
			    /* Get pointer to the next node in the list */
			    p_cell_node = p_cell_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_SETUP_MOD_LIST_PRESENT;
		    break;
	    }

	    case ASN1V_f1ap_id_DRBs_ToBeSetupMod_List:
	    {
		    f1ap_DRBs_ToBeSetupMod_Item*          	p_src_item       = NULL;
		    f1ap_DRBs_ToBeSetupMod_List_element*  	p_src_elem       = NULL;

		    f1ap_adpt_drbs_to_be_setup_mod_list_element_t*
			    				  	p_trg_item       = NULL;

		    OSRTDListNode*                        	p_drb_setup_node = NULL;
		    UInt32                                	index            = 0;

		    p_trg_msg->drbs_to_be_setup_mod_list.count = 
			    p_protocolIE_elem->value.u.
			    _f1ap_UEContextModificationRequestIEs_15->count;

		    /* Fetch pointer to the first node in the list */
		    p_drb_setup_node = p_protocolIE_elem->value.
			    		u._f1ap_UEContextModificationRequestIEs_15->head;

		    for (index = 0; 
				    index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_15->count; 
				    index++)
		    {
			    p_src_elem = (f1ap_DRBs_ToBeSetupMod_List_element*)
				    		p_drb_setup_node->data;

			    p_src_item = p_src_elem->value.u._f1ap_DRBs_ToBeSetupMod_ItemIEs_1;
			    p_trg_item = &p_trg_msg->drbs_to_be_setup_mod_list.drb_to_setup_mod_elem[index];
			    /* QoS-Information */
			    populate_drbs_to_be_setup_mod_list(p_src_item,p_trg_item);
		
			    /* UL-UP-TNL-Information-ToBe-Setup */
			    populate_ul_tunnel_info_list(p_src_item, p_trg_item);
	
			    /* rLC-Mode */
			    switch (p_src_item->rLCMode)
			    {
				    case f1ap_rlc_am:
					    {
						    p_trg_item->rlc_mode = RLC_MODE_AM;
						    break; 
					    }

				    case f1ap_rlc_um_bidirectional:
					    {
						    p_trg_item->rlc_mode = RLC_MODE_UM;
						    break;
					    }

				    case f1ap_rlc_um_unidirectional_ul:
					    {
						    p_trg_item->rlc_mode = RLC_MODE_UM_UNIDIR_UL;
						    break;
					    }

				    case f1ap_rlc_um_unidirectional_dl:
					    {
						    p_trg_item->rlc_mode = RLC_MODE_UM_UNIDIR_DL;
						    break;
					    }

				    default:
					    {
						    LOG_TRACE("Invalid rlc mode received \n");
						    break;
					    }
			    }

			    /* UL-Configuration */	
			    if (p_src_item->m.uLConfigurationPresent == 1)
			    {
				p_trg_item->bitmask |=
					F1AP_UE_CTXT_MOD_REQ_UL_CONFIGURATION_PRESENT;

				switch (p_src_item->uLConfiguration.uLUEConfiguration)
				{
					case f1ap_no_data:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_NO_DATA;
							break; 
						}

					case f1ap_shared:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_SHARED;
							break;
						}

					case f1ap_only:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_ONLY;
							break;
						}

					default:
						{
							LOG_TRACE("Invalid uL Configuration received \n");
							break;
						}
				}

			    }

			    /* Duplication-Activation */	
			    if (p_src_item->m.duplicationActivationPresent == 1)
			    {
				p_trg_item->bitmask |=
					F1AP_UE_CTXT_MOD_REQ_DUPLICATION_ACTIVATION_PRESENT;

				p_trg_item->duplicationActivation = p_src_item->duplicationActivation;
			    }
			    /* Get pointer to the next node in the list */
			    p_drb_setup_node = p_drb_setup_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_SETUP_MOD_LIST_PRESENT;

		    break;
	    }

	    case ASN1V_f1ap_id_DRBs_ToBeModified_List:
	    {
		    f1ap_DRBs_ToBeModified_Item*          	p_src_item       = NULL;
		    f1ap_DRBs_ToBeModified_List_element*  	p_src_elem       = NULL;

		    f1ap_adpt_drbs_to_be_mod_list_element_t*
			    				  	p_trg_item       = NULL;

		    OSRTDListNode*                        	p_drb_modified_node = NULL;
		    UInt32                                	index            = 0;

		    p_trg_msg->drbs_to_be_mod_list.count = 
			    p_protocolIE_elem->value.u.
			    _f1ap_UEContextModificationRequestIEs_16->count;

		    /* Fetch pointer to the first node in the list */
		    p_drb_modified_node = p_protocolIE_elem->value.
			    		u._f1ap_UEContextModificationRequestIEs_16->head;

		    for (index = 0; 
				    index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_16->count; 
				    index++)
		    {
			    p_src_elem = (f1ap_DRBs_ToBeModified_List_element*)
				    		p_drb_modified_node->data;

			    p_src_item = p_src_elem->value.u._f1ap_DRBs_ToBeModified_ItemIEs_1;
			    p_trg_item = &p_trg_msg->drbs_to_be_mod_list.drb_to_mod_elem[index];

			    /* QoS-Information */
			    populate_drbs_to_be_modified_list(p_src_item,p_trg_item);
		
			    /* UL-UP-TNL-Information-ToBe-Setup */
			    populate_drb_modified_ul_tunnel_info_list(p_src_item, p_trg_item);
	
			    /* UL-Configuration */	
			    if (p_src_item->m.uLConfigurationPresent == 1)
			    {
				p_trg_item->bitmask |=
					F1AP_UE_CTXT_MODIFIED_REQ_UL_CONFIGURATION_PRESENT;

				switch (p_src_item->uLConfiguration.uLUEConfiguration)
				{
					case f1ap_no_data:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_NO_DATA;
							break; 
						}

					case f1ap_shared:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_SHARED;
							break;
						}

					case f1ap_only:
						{
							p_trg_item->uLConfiguration = 
									F1AP_ADPT_ONLY;
							break;
						}

					default:
						{
							LOG_TRACE("Invalid uL Configuration received \n");
							break;
						}
				}

			    }
			    /* Get pointer to the next node in the list */
			    p_drb_modified_node = p_drb_modified_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_MODIFIED_LIST_PRESENT;

		    break;
	    }

	    case ASN1V_f1ap_id_SRBs_ToBeReleased_List:
	    {

		    f1ap_SRBs_ToBeReleased_List_element*    p_src_srb_rel_elem   = NULL;
		    OSRTDListNode*                          p_cell_node      = NULL;
		    UInt32                                  index            = 0;

		    /* Populate count of scells in target list */
		    p_trg_msg->srbs_to_be_released_list.count
			    = p_protocolIE_elem->value.u.
			      _f1ap_UEContextModificationRequestIEs_17->count;

		    /* Fetch pointer to the first node in the list */
		    p_cell_node = p_protocolIE_elem->value.
			    u._f1ap_UEContextModificationRequestIEs_17->head;

		    for (index = 0; index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_17->count; 
				    index++)
		    {
			    p_src_srb_rel_elem = (f1ap_SRBs_ToBeReleased_List_element*)
				    		p_cell_node->data;

			    /* sRB-ID */
			    p_trg_msg->srbs_to_be_released_list.
				    srb_to_be_released[index].sRBID = 
				    p_src_srb_rel_elem->value.u._f1ap_SRBs_ToBeReleased_ItemIEs_1->sRBID;

			    /* Get pointer to the next node in the list */
			    p_cell_node = p_cell_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_SRBS_RELEASED_LIST_PRESENT;
		    break;
	    }

	    case ASN1V_f1ap_id_DRBs_ToBeReleased_List:
	    {

		    f1ap_DRBs_ToBeReleased_List_element*    p_src_drb_rel_elem   = NULL;
		    OSRTDListNode*                          p_cell_node      = NULL;
		    UInt32                                  index            = 0;

		    /* Populate count of scells in target list */
		    p_trg_msg->drbs_to_be_released_list.count
			    = p_protocolIE_elem->value.u.
			      _f1ap_UEContextModificationRequestIEs_18->count;

		    /* Fetch pointer to the first node in the list */
		    p_cell_node = p_protocolIE_elem->value.
			    u._f1ap_UEContextModificationRequestIEs_18->head;

		    for (index = 0; index < p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_18->count; 
				    index++)
		    {
			    p_src_drb_rel_elem = (f1ap_DRBs_ToBeReleased_List_element*)
				    			p_cell_node->data;

			    /* dRB-ID */
			    p_trg_msg->drbs_to_be_released_list.
				    drb_to_be_released[index].dRBID = 
				    p_src_drb_rel_elem->value.u._f1ap_DRBs_ToBeReleased_ItemIEs_1->dRBID;

			    /* Get pointer to the next node in the list */
			    p_cell_node = p_cell_node->next;
		    }
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_DRBS_RELEASED_LIST_PRESENT;
		    break;
	    }

	    case ASN1V_f1ap_id_InactivityMonitoringRequest:
	    {
		    p_trg_msg->bitmask |= 
			F1AP_ADPT_UE_CTXT_MOD_REQ_INACTIVE_MONITOR_REQUEST_PRESENT;

		    p_trg_msg->inact_monitor_req 
			    = p_protocolIE_elem->value. 
			    u._f1ap_UEContextModificationRequestIEs_19;

		    break;
	    }
	    case ASN1V_f1ap_id_RAT_FrequencyPriorityInformation:
	    {
		/* Populate RAT_FrequencyPriorityInformation */
		populate_adpt_rat_freq_info(
			p_protocolIE_elem->value.u.
			_f1ap_UEContextModificationRequestIEs_20,
			&p_trg_msg->frequencyPriorityInformation);

		p_trg_msg->bitmask |= 
			F1AP_ADPT_UE_CTXT_MOD_REQ_RAT_FREQUENCY_PRIORITY_INFO_PRESENT;
	
	    } 

	    case ASN1V_f1ap_id_DRXConfigurationIndicator:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_DRX_CONFIGURATION_INDICATOR_PRESENT;

		    p_trg_msg->drx_config_indicator 
			    = p_protocolIE_elem->value. 
			    u._f1ap_UEContextModificationRequestIEs_21;

		    break;
	    }

	    case ASN1V_f1ap_id_RLCFailureIndication:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_RLC_FAILURE_INDICATION_PRESENT;

		    p_trg_msg->rlc_failure_ind.assocatedLCID 
			    	= p_protocolIE_elem->value. 
			    	u._f1ap_UEContextModificationRequestIEs_21;

		    break;
	    }

	    case ASN1V_f1ap_id_UplinkTxDirectCurrentListInformation:
	    {

		    p_trg_msg->bitmask |= 
			   F1AP_ADPT_UE_CTXT_MOD_REQ_UPLINK_TX_DIRECT_CURRENT_LIST_INFO_PRESENT;

		    populate_ul_tx_dir_current_list_info(
				    p_protocolIE_elem->value.u.
				    _f1ap_UEContextModificationRequestIEs_23,
				    &p_trg_msg->upLinkTxDirectCurrentListInfo);

		    break;
	    }

	    case ASN1V_f1ap_id_GNB_DUConfigurationQuery:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_GNU_DU_CONFIGURATION_QUERY_PRESENT;

		    p_trg_msg->gNBDuConfigQuery 
			    	= p_protocolIE_elem->value. 
			    	u._f1ap_UEContextModificationRequestIEs_24;

		    break;
	    }

            case ASN1V_f1ap_id_GNB_DU_UE_AMBR_UL:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_BIT_RATE_PRESENT;

		    p_trg_msg->bitRate 
			    	= p_protocolIE_elem->value. 
			    	u._f1ap_UEContextModificationRequestIEs_25;

		    break;
	    }

            case ASN1V_f1ap_id_ExecuteDuplication:
	    {
		    p_trg_msg->bitmask |= 
			    F1AP_ADPT_UE_CTXT_MOD_REQ_EXECUTE_DUPLICATION_PRESENT;

		    p_trg_msg->executeDuplication 
			    	= p_protocolIE_elem->value. 
			    	u._f1ap_UEContextModificationRequestIEs_26;

		    break;
	    }
            
            default:
            {

                LOG_TRACE("Unsupported Protocol IE Received: %d",p_protocolIE_elem->id);

                rtFreeContext(asn1_ctx);
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    rtFreeContext(asn1_ctx);
    return SIM_SUCCESS;
}

/* UE CONTEXT MODIFICATION CONFIRM start */

/*******************************************************************************
 * Function Name  : populate_mod_confirm_ul_tunnel_info_list
 * Description    : This function decodes UE Context mod confirm received 
 *                  from DU.
 *
 * Inputs         : void*   : p_asnMsg: Pointer to ASN F1AP UE context mod buffer
 *                  UInt16* : asn_msg_len: ASN Msg length 
 *                  f1ap_adpt_ue_context_mod_confirm_t*: p_trg_msg:
 *                  Pointer to receive decoded UE context mod request.
 *
 * Outputs        : Decoded UE Context mod confirm from ASN Format.
 * Returns        : 
 ******************************************************************************/

void populate_mod_confirm_ul_tunnel_info_list
(
    f1ap_DRBs_ModifiedConf_Item*                    p_src_item,
    f1ap_adpt_drbs__mod_conf_list_element_t*   	    p_trg_item
)
{
    OSRTDListNode*     				    p_tunnel_node     = PNULL;
    UInt16             				    tunnel_index      = 0;
    f1ap_ULUPTNLInformation_ToBeSetup_List*         p_src_tunnel_list = NULL;
    f1ap_ULUPTNLInformation_ToBeSetup_Item*         p_src_tunnel_elem = NULL;

    f1ap_adpt_dl_tunnels_mod_confirm_element_t*   
        				          p_trg_tunnel_item   = NULL;

    p_src_tunnel_list = &p_src_item->uLUPTNLInformation_ToBeSetup_List;
    p_tunnel_node = p_src_tunnel_list->head;

    p_trg_item->uLUPTNLInformation_mod_conf_list.count = 
                    		p_src_tunnel_list->count;

    for (tunnel_index = 0;
         tunnel_index < p_src_tunnel_list->count;
         tunnel_index++)
    {
        p_src_tunnel_elem 
            = (f1ap_ULUPTNLInformation_ToBeSetup_Item*)p_tunnel_node->data;

        p_trg_tunnel_item = &p_trg_item->uLUPTNLInformation_mod_conf_list.
                                 dl_tunnel_mod_conf[tunnel_index];

        p_trg_tunnel_item->type = p_src_tunnel_elem->uLUPTNLInformation.t;                         

        if ( p_trg_tunnel_item->type == 1)
        {
        p_trg_tunnel_item->u.gtp_tunnel.transport_address_length =
            (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->
                                 transportLayerAddress.numbits/8);

        memcpy(p_trg_tunnel_item->u.gtp_tunnel.transport_layer_address,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                (p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits/8));

        p_trg_tunnel_item->u.gtp_tunnel.gtp_teid.num_octs =
            p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts;

        memcpy(p_trg_tunnel_item->u.gtp_tunnel.gtp_teid.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                p_src_tunnel_elem->uLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts);

       }         

        p_tunnel_node = p_tunnel_node->next;
    }
}


/*******************************************************************************
 * Function Name  : decode_ue_ctx_modification_confirm
 * Description    : This function decodes ue ctx modification confirm  and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLien
 * Outputs        : Decoded ue context modification confirm  msg
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 *
 ******************************************************************************/


sim_return_val_et
decode_ue_ctx_modification_confirm(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{

    f1ap_UEContextModificationConfirm*  p_src_msg          = NULL;
    f1ap_UEContextModificationConfirm_protocolIEs_element*
                                        p_protocolIE_elem  = NULL;
    f1ap_adpt_ue_context_mod_confirm_t* p_trg_msg          = NULL;
    OSRTDListNode*                      p_node             = NULL;
    UInt8                               ie_count           = 0;


    *p_msgOutBufLen = sizeof(f1ap_adpt_ue_context_mod_confirm_t);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);

    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }
 
    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);
    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Modification Confirm container */
    p_trg_msg = (f1ap_adpt_ue_context_mod_confirm_t*)(*p_msgOutBuf);


    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.
                        u.uEContextModificationRequired;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Modification Confirm 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            rtFreeContext(asn1_ctx);
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextModificationConfirm_protocolIEs_element*)
            p_node->data;

        switch(p_protocolIE_elem->id)
        {

            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->gNBCUUEF1APID = p_protocolIE_elem->value.
                    u._f1ap_UEContextModificationConfirmIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->gNBDUUEF1APID = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationConfirmIEs_2;

                break;
            }
	    case ASN1V_f1ap_id_ResourceCoordinationTransferContainer:
	    {

                p_trg_msg->resource_Coord_container.numocts = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationConfirmIEs_3->numocts;

                memcpy(p_trg_msg->resource_Coord_container.data,
                       p_protocolIE_elem->value.u._f1ap_UEContextModificationConfirmIEs_3->data,
                       p_protocolIE_elem->value.u._f1ap_UEContextModificationConfirmIEs_3->numocts);
                
		       p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_MOD_CONFIRM_RESOURCE_COORDINATION_INFO_PRESENT;
                break;
  	    }

	    case ASN1V_f1ap_id_DRBs_ModifiedConf_List:
	    {
                    f1ap_DRBs_ModifiedConf_Item*                p_src_item       = NULL;
                    f1ap_DRBs_ModifiedConf_List_element*        p_src_elem       = NULL;

                    f1ap_adpt_drbs__mod_conf_list_element_t*
                                                                p_trg_item       = NULL;

                    OSRTDListNode*                              p_drb_mod_conf_node = NULL;
                    UInt32                                      index            = 0;

                    p_trg_msg->drbs_mod_conf_list.count =
                            p_protocolIE_elem->value.u.
                            _f1ap_UEContextModificationConfirmIEs_4->count;

                    /* Fetch pointer to the first node in the list */
                    p_drb_mod_conf_node = p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationConfirmIEs_4->head;

                    for (index = 0;
                                    index < p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationConfirmIEs_4->count;
                                    index++)
                    {
                            p_src_elem = (f1ap_DRBs_ModifiedConf_List_element*)
                                                p_drb_mod_conf_node->data;

                            p_src_item = p_src_elem->value.u._f1ap_DRBs_ModifiedConf_ItemIEs_1;
                            p_trg_item = &p_trg_msg->drbs_mod_conf_list.drb_mod_conf_elem[index];

                            /* UL-UP-TNL-Information-ToBe-Setup */
                            populate_mod_confirm_ul_tunnel_info_list(p_src_item, p_trg_item);

                            p_drb_mod_conf_node = p_drb_mod_conf_node->next;
                    }


#if 0		
		f1ap_DRBs_ModifiedConf_List_element* src_drb_mod_conf = NULL;
		f1ap_adpt_drb_mod_conf_list_t*       trg_drb_mod_conf = NULL;

                src_drb_mod_conf = p_protocolIE_elem->value.
                          u._f1ap_UEContextModificationConfirmIEs_4;

                trg_drb_mod_conf = &p_trg_msg->drbs_mod_conf_list;
#endif
                p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_MOD_CONFIRM_DRB_MODIFIED_PRESENT;
		break;
  	    }//DRBs_ModConf

	    case ASN1V_f1ap_id_RRCContainer:
	    {

                p_trg_msg->RRCContainer.numocts = p_protocolIE_elem->value.
                    u._f1ap_UEContextModificationConfirmIEs_5->numocts;

                memcpy(p_trg_msg->RRCContainer.data,
                       p_protocolIE_elem->value.u._f1ap_UEContextModificationConfirmIEs_5->data,
                       p_protocolIE_elem->value.u._f1ap_UEContextModificationConfirmIEs_5->numocts);

                p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_MOD_CONFIRM_RRC_CONTAINER_PRESENT;
                break;
  	    }

	    case ASN1V_f1ap_id_CriticalityDiagnostics:
	    {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                          u._f1ap_UEContextModificationConfirmIEs_6;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_MOD_CONFIRM_CRITICALITY_DIAGNOSTICS_PRESENT;

                break;
  	    }//crit_diag

	    case ASN1V_f1ap_id_ExecuteDuplication:
	    {

                p_trg_msg->execute_duplication = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationConfirmIEs_7;

                p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_MOD_CONFIRM_EXECUTE_DUPLICATION_PRESENT;
                break;
  	    }
            default:
            {

                LOG_TRACE("Unsupported Protocol IE Received: %d",p_protocolIE_elem->id);

                rtFreeContext(asn1_ctx);
                return SIM_FAILURE;
            }
        }//switch

        p_node = p_node->next;
    }//for

    rtFreeContext(asn1_ctx);
    return SIM_SUCCESS;
}//main
/* UE CONTEXT MODIFICATION CONFIRM stop */



#if 0    
{
    _f1ap_UEContextModificationRequest* p_trg_msg          = NULL;
    f1ap_UEContextModificationRequest*  p_src_msg          = NULL;
    f1ap_UEContextModificationRequest_protocolIEs_element*
                                        p_protocolIE_elem  = NULL;
    OSRTDListNode*                      p_node             = NULL;
    U8                                  ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_UEContextModificationRequest);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Modification Request container */
    p_trg_msg = (_f1ap_UEContextModificationRequest*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                                    u.uEContextModification;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Modification Request 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextModificationRequest_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_UEContextModificationRequestIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_UEContextModificationRequestIEs_2;

                break;
            }

            case ASN1V_f1ap_id_TransmissionStopIndicator:
            {
                p_trg_msg->transmissionStopIndicator 
                    = p_protocolIE_elem->value. 
                          u._f1ap_UEContextModificationRequestIEs_6;

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}
#endif

sim_return_val_et
decode_ue_ctx_mod_response(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
#if 0
    _f1ap_UEContextModificationResponse* p_trg_msg          = NULL;
    f1ap_UEContextModificationResponse*  p_src_msg          = NULL;
    f1ap_UEContextModificationResponse_protocolIEs_element*
                                         p_protocolIE_elem  = NULL;
    OSRTDListNode*                       p_node             = NULL;
    U8                                   ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_UEContextModificationResponse);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Modification Response container */
    p_trg_msg = (_f1ap_UEContextModificationResponse*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.
                                    u.uEContextModification;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Modification Response
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextModificationResponse_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationResponseIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationResponseIEs_2;

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                          u._f1ap_UEContextModificationResponseIEs_10;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask |= UE_CTX_MOD_RESP_CRIT_DIAG_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }
#endif
    return SIM_SUCCESS;
}


sim_return_val_et
decode_ue_ctx_mod_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
#if 0
    OSRTDListNode*         p_node                  = NULL;
    f1ap_UEContextModificationFailure*   
                           p_src_msg               = NULL;
    f1ap_UEContextModificationFailure_protocolIEs_element*  
                           p_protocolIE_elem       = NULL;
    _f1ap_UEContextModificationFailure*  
                           p_trg_msg               = NULL;
    unsigned int           ie_count                = 0;

    *p_msgOutBufLen = sizeof(_f1ap_UEContextModificationFailure);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Modification failure container */
    p_trg_msg = (_f1ap_UEContextModificationFailure*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.unsuccessfulOutcome->value.
                                    u.uEContextModification;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Modification Failure 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextModificationFailure_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationFailureIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationFailureIEs_2;

                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = NULL;
                _f1ap_Cause* p_trg_cause = NULL;

                /* Fetch pointer to source container */
                p_src_cause = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationFailureIEs_3; 

                /* Fetch pointer to target container */
                p_trg_cause = &p_trg_msg->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                     = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                        p_trg_cause->u.transport 
                                     = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                        p_trg_cause->u.protocol 
                                     = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_MISC;

                        p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid cause type received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                          u._f1ap_UEContextModificationFailureIEs_4;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask |= UE_CTX_MOD_FAILURE_CRIT_DIAG_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }
#endif
    return SIM_SUCCESS;
}
