/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for decoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "rrc_msg_mgmt.h"
#include "du_sim_common.h"
#include "f1ap_adpt_intf.h"
/* Decode served cell information */
void decode_f1_setup_req_served_cell_info(
        f1ap_Served_Cell_Information*   p_src_srvd_cell_info,
        _f1ap_Served_Cell_Information*  p_trg_srvd_cell_info)
{
#if 0
    /* Decode NR-CGI */
    {
        f1ap_NRCGI* p_src_cgi = F1AP_NULL;
        _f1ap_NCGI* p_trg_cgi = F1AP_NULL;

        /* Fetch pointer to source NR-CGI container */
        p_src_cgi = &p_src_srvd_cell_info->nRCGI;

        /* Fetch pointer to target NR-CGI container */
        p_trg_cgi = &p_trg_srvd_cell_info->nRCGI;

        /* Populate target NR-CGI container */
        p_trg_cgi->pLMN_Identity.numocts
                = p_src_cgi->pLMN_Identity.numocts;

        memcpy(p_trg_cgi->pLMN_Identity.data,
               p_src_cgi->pLMN_Identity.data,
               3);

        p_trg_cgi->nRCellIdentity.numbits
               = p_src_cgi->nRCellIdentity.numbits;

        memcpy(p_trg_cgi->nRCellIdentity.data,
               p_src_cgi->nRCellIdentity.data,
               5);
    }

    /* Decode nRPCI */
    {
        p_trg_srvd_cell_info->nRPCI = 
                    p_src_srvd_cell_info->nRPCI;
    }

#if 0
    /* Decode extended TAC */
    {
        p_trg_srvd_cell_info->extended_tac.numocts = 
            p_src_srvd_cell_info->extended_TAC.numocts;

        memcpy(p_trg_srvd_cell_info->extended_tac.data,
               p_src_srvd_cell_info->extended_TAC.data,
               3);
    }

#endif
    /* Decode broadcast PLMNs */
    {
        unsigned int index = 0;

        p_trg_srvd_cell_info->broadcastPLMNs.n
                = p_src_srvd_cell_info->broadcastPLMNs.n;

        for (index = 0; index < p_src_srvd_cell_info->broadcastPLMNs.n;
             index++)
        {
            p_trg_srvd_cell_info->broadcastPLMNs.elem[index].numocts
                = p_src_srvd_cell_info->broadcastPLMNs.elem[index].numocts;

            memcpy(p_trg_srvd_cell_info->broadcastPLMNs.elem[index].data,
                   p_src_srvd_cell_info->broadcastPLMNs.elem[index].data,
                   3);
        }
    }

    /* Decode NR-Mode Info */
    {
        if (T_f1ap_NR_Mode_Info_fDD == 
                     p_src_srvd_cell_info->nR_Mode_Info.t)
        {
            f1ap_FDD_Info*  p_src_fdd_info = F1AP_NULL;
            _f1ap_FDD_Info* p_trg_fdd_info = F1AP_NULL;

            p_trg_srvd_cell_info->nR_Mode_Info.nr_mode =  NR_MODE_FDD;

            /* Fetch pointer to source FDD info container */
            p_src_fdd_info = p_src_srvd_cell_info->nR_Mode_Info.u.fDD;

            /* Fetch pointer to target FDD info container */
            p_trg_fdd_info = &p_trg_srvd_cell_info->nR_Mode_Info.u.fDD;

            p_trg_fdd_info->uL_NARFCN = p_src_fdd_info->uL_NRARFCN; 
            p_trg_fdd_info->dL_NARFCN = p_src_fdd_info->dL_NRARFCN;

            p_trg_fdd_info->uL_Transmission_Bandwidth.nRSCS 
                = p_src_fdd_info->uL_Transmission_Bandwidth.nRSCS;

            p_trg_fdd_info->uL_Transmission_Bandwidth.nRNRB
                = p_src_fdd_info->uL_Transmission_Bandwidth.nRNRB;

            p_trg_fdd_info->dL_Transmission_Bandwidth.nRSCS
                = p_src_fdd_info->dL_Transmission_Bandwidth.nRSCS;

            p_trg_fdd_info->dL_Transmission_Bandwidth.nRNRB
                = p_src_fdd_info->dL_Transmission_Bandwidth.nRNRB;
        }
        else if (T_f1ap_NR_Mode_Info_tDD == 
                     p_src_srvd_cell_info->nR_Mode_Info.t)
        {
            f1ap_TDD_Info*  p_src_tdd_info = F1AP_NULL;
            _f1ap_TDD_Info* p_trg_tdd_info = F1AP_NULL;

            p_trg_srvd_cell_info->nR_Mode_Info.nr_mode = NR_MODE_TDD; 

            /* Fetch pointer to source FDD info container */
            p_src_tdd_info = p_src_srvd_cell_info->nR_Mode_Info.u.tDD;

            /* Fetch pointer to target FDD info container */
            p_trg_tdd_info = &p_trg_srvd_cell_info->nR_Mode_Info.u.tDD;

            /* Populate target container */
            p_trg_tdd_info->nARFCN 
                        = p_src_tdd_info->nRARFCN; 
            p_trg_tdd_info->transmission_Bandwidth.nRSCS
                        = p_src_tdd_info->transmission_Bandwidth.nRSCS;
            p_trg_tdd_info->transmission_Bandwidth.nRNRB
                        = p_src_tdd_info->transmission_Bandwidth.nRNRB;
        }
        else
        {
            LOG_TRACE("Invalid NR-Mode received : %d\n", 
                            p_src_srvd_cell_info->nR_Mode_Info.t);
        }
    }

    /* Decode S-UL Info, if present in source IE */
    if (p_src_srvd_cell_info->m.sUL_InformationPresent)
    {
        p_trg_srvd_cell_info->sUL_Information.uL_NARFCN 
            = p_src_srvd_cell_info->sUL_Information.sUL_NRARFCN;
        p_trg_srvd_cell_info->sUL_Information.uL_Transmission_Bandwidth.nRSCS
            = p_src_srvd_cell_info->sUL_Information.sUL_transmission_Bandwidth.nRSCS;
        p_trg_srvd_cell_info->sUL_Information.uL_Transmission_Bandwidth.nRNRB
            = p_src_srvd_cell_info->sUL_Information.sUL_transmission_Bandwidth.nRNRB;

        p_trg_srvd_cell_info->bitmask |= F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT; 
    }

    /* Decode measurement timing configuration */
    {
        p_trg_srvd_cell_info->meas_timing_config.bufLen = 
            p_src_srvd_cell_info->measurementTimingConfiguration.numocts;

        memcpy(p_trg_srvd_cell_info->meas_timing_config.buf,
               p_src_srvd_cell_info->measurementTimingConfiguration.data,
               p_src_srvd_cell_info->measurementTimingConfiguration.numocts);
    
    }
    #endif
}


/* Decode served cell system information */
void decode_f1_setup_req_served_cell_system_info(
        f1ap_GNB_DU_System_Information*   p_src_sys_info,
        _f1ap_GNB_DU_System_Information*  p_trg_sys_info)
{
#if 0
    p_trg_sys_info->mib_length  
            = p_src_sys_info->mIB_message.numocts;

    memcpy(p_trg_sys_info->mIB_message,
           p_src_sys_info->mIB_message.data,
           p_src_sys_info->mIB_message.numocts);

    p_trg_sys_info->sib1_length 
            = p_src_sys_info->sIB1_message.numocts;

    memcpy(p_trg_sys_info->sIB1_message,
           p_src_sys_info->sIB1_message.data,
           p_src_sys_info->sIB1_message.numocts);
          
          #endif 
}


sim_return_val_et
decode_f1Setup_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
#if 0
    _f1ap_F1SetupRequest* p_trg_msg             = F1AP_NULL;
    f1ap_F1SetupRequest*  p_src_msg             = F1AP_NULL;
    f1ap_F1SetupRequest_protocolIEs_element*
                          p_protocolIE_elem     = F1AP_NULL;
    OSRTDListNode*        p_node                = F1AP_NULL;
    U8                    ie_count              = 0;

    *p_msgOutBufLen = sizeof(_f1ap_F1SetupRequest);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target F1Setup Request container */
    p_trg_msg = (_f1ap_F1SetupRequest*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.u.f1Setup;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source F1Setup Request container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_F1SetupRequest_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transaction_id
                    = p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_1;

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_ID: 
            {
                p_trg_msg->du_id
                    = p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_2;

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_Name: 
            {
                memcpy(p_trg_msg->du_name,
                       p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_3,
                       MAX_DU_NAME_LENGTH);

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_Served_Cells_List:
            {
                f1ap_GNB_DU_Served_Cells_List_element*
                                    p_cell_elem          = F1AP_NULL;
                f1ap_Served_Cell_Information*
                                    p_src_srvd_cell_info = F1AP_NULL;
                _f1ap_Served_Cell_Information*
                                    p_trg_srvd_cell_info = F1AP_NULL;
                f1ap_GNB_DU_System_Information*
                                    p_src_sys_info       = F1AP_NULL;
                _f1ap_GNB_DU_System_Information*
                                    p_trg_sys_info       = F1AP_NULL;
                OSRTDListNode*      p_cell_node          = F1AP_NULL;
                unsigned short      index                = 0;

                /* Fetch pointer to the first node in the list */
                p_cell_node = p_protocolIE_elem->value.u.
                                _f1ap_F1SetupRequestIEs_4->head;

                for (index = 0; index < p_protocolIE_elem->value.u.
                                      _f1ap_F1SetupRequestIEs_4->count;
                     index++)
                {
                    /* Fetch pointer to source element */
                    p_cell_elem = (f1ap_GNB_DU_Served_Cells_List_element*)
                                         p_cell_node->data;

                    /* Populate served cell information */
                    {
                        /* Fetch pointer to target served cell info container */
                        p_trg_srvd_cell_info = &p_trg_msg->served_cells_list.
                                served_cell[index].served_cell_info; 

                        /* Fetch pointer to source served cell info container */
                        p_src_srvd_cell_info = &p_cell_elem->value.u.
                             _f1ap_GNB_DU_Served_Cells_ItemIEs_1->served_Cell_Information;

                        /* Decode served cell information */
                        decode_f1_setup_req_served_cell_info(
                                        p_src_srvd_cell_info,
                                        p_trg_srvd_cell_info);
                    }

                    /* Populate system information for cell, if present in 
                     * source container */
                    if (p_trg_msg->served_cells_list.served_cell[index].bitmask
                            & F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT)
                    {
                        /* Fetch pointer to target system info container */
                        p_trg_sys_info = &p_trg_msg->served_cells_list.
                            served_cell[index].system_info;

                        /* Fetch pointer to source system info container */
                        p_src_sys_info = &p_cell_elem->value.u.
                            _f1ap_GNB_DU_Served_Cells_ItemIEs_1->gNB_DU_System_Information;

                        /* Decode served cell system information */
                        decode_f1_setup_req_served_cell_system_info(
                                        p_src_sys_info,
                                        p_trg_sys_info);
                    }

                    /* Get pointer to the next node in the list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    #endif
    return SIM_SUCCESS;
}

/*******************************************************************************
 * Function Name  : decode_cu_config_update
 * Description    : This function decode_f1Setup_response and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLen
 * Outputs        : Decoded decode_f1Setup_response
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/

sim_return_val_et
decode_f1Setup_response(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    f1ap_adpt_f1_setup_cnf_t* p_trg_msg            = F1AP_P_NULL;
    f1ap_F1SetupResponse*  p_src_msg            = F1AP_P_NULL;
    f1ap_F1SetupResponse_protocolIEs_element*
                           p_protocolIE_elem    = F1AP_P_NULL;
    OSRTDListNode*         p_node               = F1AP_P_NULL;
    U8                     ie_count             = F1AP_NULL;

    *p_msgOutBufLen = sizeof(f1ap_adpt_f1_setup_cnf_t);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);
    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target Reset ACK */
    p_trg_msg = (f1ap_adpt_f1_setup_cnf_t*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.u.f1Setup;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source F1Setup Response container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_F1SetupResponse_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transaction_id = p_protocolIE_elem->value.
                              u._f1ap_F1SetupResponseIEs_1;

                break;
            }

            case ASN1V_f1ap_id_gNB_CU_Name:
            {
                /* TODO: this list is optional */
                p_trg_msg->bitmask |= F1AP_ADPT_F1_SETUP_CNF_GNB_CU_NAME_PRESENT;

                l3_memcpy_wrapper(p_trg_msg->cu_name,
                        p_protocolIE_elem->value.u._f1ap_F1SetupResponseIEs_2,
                        MAX_GNB_CU_NAME_LENGTH);
                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Activated_List:
            {
                f1ap_Cells_to_be_Activated_List_element* 
                                            p_cell_elem         = F1AP_P_NULL;
                f1ap_Cells_to_be_Activated_List_Item*
                                            p_src_item          = F1AP_P_NULL;
                f1ap_adpt_cells_to_be_activated_list_element_t*
                                            p_trg_item          = F1AP_P_NULL;
                OSRTDListNode*              p_cell_node         = F1AP_P_NULL;
                unsigned int                index               = 0;

                p_trg_msg->bitmask |= F1AP_ADPT_F1_SETUP_CNF_CELLS_TO_BE_ACTIVATED_LIST_PRESENT;

                /* Store the count in the target container */
                p_trg_msg->cellsToBeActivatedList.count 
                        = p_protocolIE_elem->value.u.
                               _f1ap_F1SetupResponseIEs_3->count;

                /* Get pointer to first node in the cell list */
                p_cell_node = p_protocolIE_elem->value.u.
                                    _f1ap_F1SetupResponseIEs_3->head;

                /* Traverse through the list of cells and copy each
                 * to the target container */
                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_F1SetupResponseIEs_3->count;
                     index++)
                {
                    p_cell_elem = (f1ap_Cells_to_be_Activated_List_element*)
                                         p_cell_node->data;                   
                    
                    /* Fetch pointer to source cell item container */
                    p_src_item = p_cell_elem->value.u.
                                   _f1ap_Cells_to_be_Activated_List_ItemIEs_1;

                    /* Fetch pointer to target cell item container */
                    p_trg_item = &p_trg_msg->cellsToBeActivatedList.
                                                cell_to_activate[index];

                    /* Populate CGI */
                    {
                        p_trg_item->cgi.plmn_identity.numocts
                                = p_src_item->nRCGI.pLMN_Identity.numocts;

                        memcpy(p_trg_item->cgi.plmn_identity.data,
                               p_src_item->nRCGI.pLMN_Identity.data,
                               3);

                        p_trg_item->cgi.nr_cellidentity.num_bits
                                = p_src_item->nRCGI.nRCellIdentity.numbits;

                        memcpy(p_trg_item->cgi.nr_cellidentity.data,
                               p_src_item->nRCGI.nRCellIdentity.data,
                               5);
                    }

                    /* Populate PCI, if present in source container */
                    if (p_src_item->m.nRPCIPresent)
                    {
                        p_trg_item->pci     = p_src_item->nRPCI;
                        p_trg_item->bitmask 
                                |= F1AP_ADPT_CELL_TO_BE_ACTIVATED_PCI_PRESENT;
                    }

                    /* Get pointer to the next node in the cell list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}
/*******************************************************************************
 * Function Name  : decode_du_config_update_ack
 * Description    : This function decodes DU Config update and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLien
 * Outputs        : Decoded DU Config update msg
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 *
 ******************************************************************************/
sim_return_val_et
decode_du_config_update_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)

{
    _f1ap_GNBDUConfigurationUpdateAcknowledge * p_trg_msg               = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdateAcknowledge*  p_src_msg                = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element*
                           p_protocolIE_elem                            = F1AP_P_NULL;
    OSRTDListNode*         p_node                                       = F1AP_P_NULL;
    U8                     ie_count                                     = F1AP_NULL;

    *p_msgOutBufLen = sizeof(_f1ap_GNBDUConfigurationUpdateAcknowledge);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);
    /* Get pointer to target Reset ACK */
    p_trg_msg = (_f1ap_GNBDUConfigurationUpdateAcknowledge*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.u.gNBDUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source F1Setup Response container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->trans_id = p_protocolIE_elem->value.
                              u._f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_1;

                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Activated_List:
            {
                f1ap_Cells_to_be_Activated_List_element* 
                                p_cell_elem                 = F1AP_P_NULL;
                f1ap_Cells_to_be_Activated_List_Item*
                                p_src_item                  = F1AP_P_NULL;
                _f1ap_Cells_to_be_Activated_List_element*
                                p_trg_item                  = F1AP_P_NULL;
                OSRTDListNode*  p_cell_node                 = F1AP_P_NULL;
                unsigned int    index                       = F1AP_NULL;

                p_trg_msg->bitmask |= F1_SETUP_RESP_CELLS_TO_BE_ACTIVATED_LIST_PRESENT;

                /* Store the count in the target container */
                p_trg_msg->cells_to_be_activated_list.count 
                        = p_protocolIE_elem->value.u.
                               _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2->count;

                /* Get pointer to first node in the cell list */
                p_cell_node = p_protocolIE_elem->value.u.
                                    _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2->head;

                /* Traverse through the list of cells and copy each
                 * to the target container */
                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2->count;
                     index++)
                {
                    p_cell_elem = (f1ap_Cells_to_be_Activated_List_element*)
                                         p_cell_node->data;                   
                    
                    /* Fetch pointer to source cell item container */
                    p_src_item = p_cell_elem->value.u.
                                   _f1ap_Cells_to_be_Activated_List_ItemIEs_1;

                    /* Fetch pointer to target cell item container */
                    p_trg_item = &p_trg_msg->cells_to_be_activated_list.
                                                cell_to_activate[index];

                    /* Populate CGI */
                    {
                        p_trg_item->cgi.pLMN_Identity.numocts
                                = p_src_item->nRCGI.pLMN_Identity.numocts;

                        memcpy(p_trg_item->cgi.pLMN_Identity.data,
                               p_src_item->nRCGI.pLMN_Identity.data,
                               3);

                        p_trg_item->cgi.nRCellIdentity.numbits
                                = p_src_item->nRCGI.nRCellIdentity.numbits;

                        memcpy(p_trg_item->cgi.nRCellIdentity.data,
                               p_src_item->nRCGI.nRCellIdentity.data,
                               5);
                    }

                    /* Populate PCI, if present in source container */
                    if (p_src_item->m.nRPCIPresent)
                    {
                        p_trg_item->pci     = p_src_item->nRPCI;
                        p_trg_item->bitmask 
                                |= CELL_TO_BE_ACTIVATED_PCI_PRESENT;
                    }

                    /* Get pointer to the next node in the cell list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}


sim_return_val_et
decode_du_config_update_fail
(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_GNBDUConfigurationUpdateFailure* p_trg_msg            = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdateFailure*  p_src_msg            = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element*
        p_protocolIE_elem    = F1AP_P_NULL;
    OSRTDListNode*        p_node               = F1AP_P_NULL;
    U8                    ie_count             = F1AP_NULL;

    *p_msgOutBufLen = sizeof(_f1ap_GNBDUConfigurationUpdateFailure);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }
    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target F1 Setup Failure */
    p_trg_msg = (_f1ap_GNBDUConfigurationUpdateFailure*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.unsuccessfulOutcome->value.u.gNBDUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in F1 Setup Failure source container  
     * and populate each in the target container */
    for (ie_count = 0;
            ie_count < p_src_msg->protocolIEs.count;
            ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
                {
                    p_trg_msg->transaction_id = p_protocolIE_elem->value.
                        u._f1ap_GNBDUConfigurationUpdateFailureIEs_1;

                    break;
                }

            case ASN1V_f1ap_id_Cause:
                {
                    f1ap_Cause*  p_src_cause = F1AP_P_NULL;
                    _f1ap_Cause* p_trg_cause = F1AP_P_NULL;

                    /* Fetch pointer to source container */
                    p_src_cause = p_protocolIE_elem->value.u.
                        _f1ap_GNBDUConfigurationUpdateFailureIEs_2; 

                    /* Fetch pointer to target container */
                    p_trg_cause = &p_trg_msg->cause; 

                    switch(p_src_cause->t)
                    {
                        case T_f1ap_Cause_radioNetwork: 
                            {
                                p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                                p_trg_cause->u.radioNetwork 
                                    = p_src_cause->u.radioNetwork;

                                break;
                            }

                        case T_f1ap_Cause_transport: 
                            {
                                p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                                p_trg_cause->u.transport 
                                    = p_src_cause->u.transport;

                                break;
                            }

                        case T_f1ap_Cause_protocol: 
                            {
                                p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                                p_trg_cause->u.protocol 
                                    = p_src_cause->u.protocol;

                                break;
                            }

                        case T_f1ap_Cause_misc: 
                            {
                                p_trg_cause->cause_type = F1_CAUSE_MISC;

                                p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                                break;
                            }

                        default:
                            {
                                LOG_TRACE("Invalid cause type received \n");
                                break;
                            }
                    }

                    break;
                }

            case ASN1V_f1ap_id_TimeToWait:
                {
                    p_trg_msg->bitmask |= F1_SETUP_FAILURE_TIME_TO_WAIT_PRESENT;

                    switch(p_protocolIE_elem->value.
                            u._f1ap_GNBDUConfigurationUpdateFailureIEs_3)
                    {
                        case f1ap_v1s:
                            {
                                p_trg_msg->timeToWait = f1ap_v1s;
                                break;
                            }

                        case f1ap_v2s:
                            {
                                p_trg_msg->timeToWait = f1ap_v2s;
                                break;
                            }

                        case f1ap_v5s: 
                            {
                                p_trg_msg->timeToWait = f1ap_v5s;
                                break;
                            }

                        case f1ap_v10s: 
                            {
                                p_trg_msg->timeToWait = f1ap_v10s;
                                break;
                            }

                        case f1ap_v20s: 
                            {
                                p_trg_msg->timeToWait = f1ap_v20s;
                                break;
                            }

                        case f1ap_v60s: 
                            {
                                p_trg_msg->timeToWait = f1ap_v60s;
                                break;
                            }

                        default:
                            {
                                LOG_TRACE("Invalid timeToWait value received \n");
                                break;
                            }
                    }

                    break;
                }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
                {
                    f1ap_CriticalityDiagnostics*  p_src_crit_diag = F1AP_P_NULL;
                    _f1ap_CriticalityDiagnostics* p_trg_crit_diag = F1AP_P_NULL;

                    /* Fetch pointer to source criticality diagnostics container */
                    p_src_crit_diag = p_protocolIE_elem->value.
                        u._f1ap_GNBDUConfigurationUpdateFailureIEs_4;

                    /* Fetch pointer to target criticality diagnostics container */
                    p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                    /* Fill Procedure Code, If Present. */
                    if (p_src_crit_diag->m.procedureCodePresent)
                    {
                        /* Fill Bitmask */
                        p_trg_crit_diag->bitmask 
                            |= CRIT_DIAG_PROC_CODE_PRESENT;

                        /* Fill Value */
                        p_trg_crit_diag->procedureCode 
                            = p_src_crit_diag->procedureCode;
                    }

                    /* Fill Triggering Message, If Present. */
                    if (p_src_crit_diag->m.triggeringMessagePresent)
                    {
                        /* Fill Bitmask */
                        p_trg_crit_diag->bitmask 
                            |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                        /* Fill Value */
                        p_trg_crit_diag->triggeringMessage 
                            = p_src_crit_diag->triggeringMessage;
                    }

                    /* Fill Procedure Criticality, If Present. */
                    if (p_src_crit_diag->m.procedureCriticalityPresent)
                    {
                        /* Fill Bitmask */
                        p_trg_crit_diag->bitmask 
                            |= CRIT_DIAG_PROC_CRIT_PRESENT;

                        /* Fill Value */
                        p_trg_crit_diag->procedureCriticality 
                            = p_src_crit_diag->procedureCriticality;
                    }

                    /* Fill iEsCriticality Diagnostics, If Present. */
                    if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                    {
                        OSRTDListNode* p_crit_diag_node        = F1AP_P_NULL;
                        f1ap_CriticalityDiagnostics_IE_Item*
                            p_crit_diag_ie_elem     = F1AP_P_NULL;
                        _f1ap_CriticalityDiagnostics_IE_Item*
                            p_trg_crit_diag_ie_elem = F1AP_P_NULL;
                        unsigned int   index                   = 0;

                        /* Fill Bitmask */
                        p_trg_crit_diag->bitmask 
                            |= CRIT_DIAG_IE_LIST_PRESENT;

                        p_trg_crit_diag->iEsList.ie_count 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                        p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                        for (index = 0; 
                                index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                                index++)
                        {
                            /* Fetch pointer to source criticality diagnostics IE
                             * element */
                            p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                p_crit_diag_node->data;

                            /* Fetch pointer to target criticality diagnostics IE
                             * element and populate it */
                            p_trg_crit_diag_ie_elem 
                                = &p_trg_crit_diag->iEsList.ie_info[index];

                            p_trg_crit_diag_ie_elem->iECriticality 
                                = p_crit_diag_ie_elem->iECriticality; 
                            p_trg_crit_diag_ie_elem->iE_ID         
                                = p_crit_diag_ie_elem->iE_ID;
                            p_trg_crit_diag_ie_elem->typeOfError   
                                = p_crit_diag_ie_elem->typeOfError;

                            /* Get pointer to the next node */
                            p_crit_diag_node = p_crit_diag_node->next;
                        }
                    }

                    /* Set the flag to indicate that Criticality Diagnostics IE
                     * is present in the ACK */
                    p_trg_msg->bitmask 
                        |= F1_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT;

                    break;
                }

            default:
                {
                    LOG_TRACE("Invalid Protocol IE Received:");
                    return SIM_FAILURE;
                }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}




sim_return_val_et
decode_f1Setup_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_F1SetupFailure* p_trg_msg            = F1AP_P_NULL;
    f1ap_F1SetupFailure*  p_src_msg            = F1AP_P_NULL;
    f1ap_F1SetupFailure_protocolIEs_element*
                          p_protocolIE_elem    = F1AP_P_NULL;
    OSRTDListNode*        p_node               = F1AP_P_NULL;
    U8                    ie_count             = F1AP_NULL;

    *p_msgOutBufLen = sizeof(_f1ap_F1SetupFailure);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target F1 Setup Failure */
    p_trg_msg = (_f1ap_F1SetupFailure*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.unsuccessfulOutcome->value.u.f1Setup;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in F1 Setup Failure source container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_F1SetupFailure_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transaction_id = p_protocolIE_elem->value.
                              u._f1ap_F1SetupFailureIEs_1;

                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = F1AP_P_NULL;
                _f1ap_Cause* p_trg_cause = F1AP_P_NULL;

                /* Fetch pointer to source container */
                p_src_cause = p_protocolIE_elem->value.u.
                                   _f1ap_F1SetupFailureIEs_2; 

                /* Fetch pointer to target container */
                p_trg_cause = &p_trg_msg->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                     = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                        p_trg_cause->u.transport 
                                     = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                        p_trg_cause->u.protocol 
                                     = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_MISC;

                        p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid cause type received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_TimeToWait:
            {
                p_trg_msg->bitmask |= F1_SETUP_FAILURE_TIME_TO_WAIT_PRESENT;

                switch(p_protocolIE_elem->value.
                                    u._f1ap_F1SetupFailureIEs_3)
                {
                    case f1ap_v1s:
                    {
                        p_trg_msg->timeToWait = f1ap_v1s;
                        break;
                    }

                    case f1ap_v2s:
                    {
                        p_trg_msg->timeToWait = f1ap_v2s;
                        break;
                    }

                    case f1ap_v5s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v5s;
                        break;
                    }

                    case f1ap_v10s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v10s;
                        break;
                    }

                    case f1ap_v20s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v20s;
                        break;
                    }

                    case f1ap_v60s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v60s;
                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid timeToWait value received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = F1AP_P_NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = F1AP_P_NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                                      u._f1ap_F1SetupFailureIEs_4;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = F1AP_P_NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = F1AP_P_NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = F1AP_P_NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask 
                       |= F1_SETUP_FAILURE_CRIT_DIAGNOSTICS_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}



