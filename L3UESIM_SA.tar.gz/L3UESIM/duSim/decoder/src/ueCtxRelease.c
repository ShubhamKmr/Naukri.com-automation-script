/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for decoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"

/*******************************************************************************
 * Function Name  : populate_adpt_cause_type_and_value
 * Description    : This function encodes the cause received from adaptation
 *                  layer to ASN encoded format.
 * Inputs         : f1ap_adpt_cause_t* : p_src_adpt_cause
 *                  Pointer to F1AP Cause received from adaptation layer
 *                  f1ap_Cause*        : p_encoded_msg
 *                  Pointer to receive ASN encoded cause.
 * Outputs        : ASN Encoded F1AP Cause.
 * Returns        : None
 ******************************************************************************/
void populate_adpt_cause_type_and_value
(   
    f1ap_Cause*         p_src_cause,
    f1ap_adpt_cause_t*  p_trg_cause
)
{
    switch(p_src_cause->t)
    {
        case T_f1ap_Cause_radioNetwork: 
        {
            p_trg_cause->cause_type  = F1_CAUSE_RADIO_NETWORK;
            p_trg_cause->u.radio_network = p_src_cause->u.radioNetwork;

            break;
        }

        case T_f1ap_Cause_transport: 
        {
            p_trg_cause->cause_type  = F1_CAUSE_TRANSPORT;
            p_trg_cause->u.transport = p_src_cause->u.transport;

            break;
        }

        case T_f1ap_Cause_protocol: 
        {
            p_trg_cause->cause_type  = F1_CAUSE_PROTOCOL;
            p_trg_cause->u.protocol = p_src_cause->u.protocol;

            break;
        }

        case T_f1ap_Cause_misc: 
        {
            p_trg_cause->cause_type  = F1_CAUSE_MISC;
            p_trg_cause->u.misc = p_src_cause->u.misc;

            break;
        }

        default:
        {
            LOG_TRACE("Invalid cause type received \n");
            break;
        }
    }
}

/*******************************************************************************
 * Function Name  : decode_ue_ctx_release_command
 * Description    : This function decodes decode_ue_ctx_release_command and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLien
 * Outputs        : Decoded decode_ue_ctx_release_command  msg
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 *
 ******************************************************************************/
    sim_return_val_et
decode_ue_ctx_release_command(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    f1ap_UEContextReleaseCommand*       p_src_msg                   = NULL;
    f1ap_UEContextReleaseCommand_protocolIEs_element*
                                        p_protocolIE_elem           = NULL;
    f1ap_adpt_ue_context_rel_command_t*  p_trg_msg                  = NULL;
    OSRTDListNode*                      p_node                      = NULL;
    sim_return_val_et                   retVal                      = SIM_FAILURE;
    UInt8                               ie_count                    = 0;


    *p_msgOutBufLen = sizeof(f1ap_adpt_ue_context_rel_command_t);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return retVal;
    }

    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Release Command container */
    p_trg_msg = (f1ap_adpt_ue_context_rel_command_t*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
        u.uEContextRelease;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Release Command 
     * container  and populate each in the target container */
    for (ie_count = 0;
            ie_count < p_src_msg->protocolIEs.count;
            ie_count++)
    {
        if (!p_node)
        {
            rtFreeContext(asn1_ctx);
            return retVal;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextReleaseCommand_protocolIEs_element*)
            p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
                {
                    p_trg_msg->gNBCUUEF1APID = p_protocolIE_elem->value.
                        u._f1ap_UEContextReleaseCommandIEs_1; 

                    break;
                }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
                {
                    p_trg_msg->gNBDUUEF1APID = p_protocolIE_elem->value.
                        u._f1ap_UEContextReleaseCommandIEs_2;

                    break;
                }

            case ASN1V_f1ap_id_Cause:
                {
                    /* Populate cause */
                    populate_adpt_cause_type_and_value(
                            p_protocolIE_elem->value.u.
                            _f1ap_UEContextReleaseCommandIEs_3,
                            &p_trg_msg->cause);

                    break;
                }

	    case ASN1V_f1ap_id_RRCContainer:
		{
			p_trg_msg->RRC_Container.numocts = p_protocolIE_elem->value.
				u._f1ap_UEContextReleaseCommandIEs_4->numocts;

			memcpy(p_trg_msg->RRC_Container.data,
					p_protocolIE_elem->value.u._f1ap_UEContextReleaseCommandIEs_4->data,
					p_protocolIE_elem->value.u._f1ap_UEContextReleaseCommandIEs_4->numocts);

			p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_REL_COMMAND_RRC_CONTAINER_PRESENT;

			break;
		}

	    case ASN1V_f1ap_id_SRBID:
		{

			p_trg_msg->SRBID = p_protocolIE_elem->value.
				u._f1ap_UEContextReleaseCommandIEs_5;

			p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_REL_COMMAND_SRBID_PRESENT;
			break;
		}
	    case ASN1V_f1ap_id_oldgNB_DU_UE_F1AP_ID:
		{

			p_trg_msg->oldgNBDUUEF1APID = p_protocolIE_elem->value.
				u._f1ap_UEContextReleaseCommandIEs_6;

			p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_REL_COMMAND_OLD_gNBDUUEF1APID_PRESENT;
			break;
		}

	    case ASN1V_f1ap_id_ExecuteDuplication:
		{

			p_trg_msg->exe_duplication = p_protocolIE_elem->value.
				u._f1ap_UEContextReleaseCommandIEs_7;
			p_trg_msg->bitmask |= F1AP_ADPT_UE_CTX_REL_COMMAND_EXECUTE_DUPLICATION_PRESENT;
			break;
		}
	

            default:
                {

                    LOG_TRACE("Unsupported Protocol IE Received: %d", p_protocolIE_elem->id);

                    break;
                }
        }

        p_node = p_node->next;
    }

    rtFreeContext(asn1_ctx);
    return SIM_SUCCESS;
}


    
#if 0    
{
    _f1ap_UEContextReleaseCommand* p_trg_msg          = NULL;
    f1ap_UEContextReleaseCommand*  p_src_msg          = NULL;
    f1ap_UEContextReleaseCommand_protocolIEs_element*
                                   p_protocolIE_elem  = NULL;
    OSRTDListNode*                 p_node             = NULL;
    U8                             ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_UEContextReleaseCommand);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Release Command container */
    p_trg_msg = (_f1ap_UEContextReleaseCommand*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                             u.uEContextRelease;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Release Command 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextReleaseCommand_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_UEContextReleaseCommandIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                    u._f1ap_UEContextReleaseCommandIEs_2;

                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = NULL;
                _f1ap_Cause* p_trg_cause = NULL;

                /* Fetch pointer to source container */
                p_src_cause = p_protocolIE_elem->value.u.
                                _f1ap_UEContextReleaseCommandIEs_3; 

                /* Fetch pointer to target container */
                p_trg_cause = &p_trg_msg->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                     = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                        p_trg_cause->u.transport 
                                     = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                        p_trg_cause->u.protocol 
                                     = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_MISC;

                        p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid cause type received \n");
                        break;
                    }
                }

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}
#endif

sim_return_val_et
decode_ue_ctx_release_complete(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
#if 0
    _f1ap_UEContextReleaseComplete* p_trg_msg          = NULL;
    f1ap_UEContextReleaseComplete*  p_src_msg          = NULL;
    f1ap_UEContextReleaseComplete_protocolIEs_element*
                                    p_protocolIE_elem  = NULL;
    OSRTDListNode*                  p_node             = NULL;
    U8                              ie_count           = 0;

    *p_msgOutBufLen = sizeof(_f1ap_UEContextReleaseComplete);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target UE Context Release Command container */
    p_trg_msg = (_f1ap_UEContextReleaseComplete*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.
                             u.uEContextRelease;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source UE Context Release Command 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_UEContextReleaseComplete_protocolIEs_element*)
                   p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID:
            {
                p_trg_msg->cu_f1ap_id = p_protocolIE_elem->value.
                        u._f1ap_UEContextReleaseCompleteIEs_1; 

                break;
            }

            case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID: 
            {
                p_trg_msg->du_f1ap_id = p_protocolIE_elem->value.
                        u._f1ap_UEContextReleaseCompleteIEs_2;

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                          u._f1ap_UEContextReleaseCompleteIEs_3;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask 
                          |= F1AP_UE_CTX_REL_CMD_CRIT_DIAGNOSTICS_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Unsupported Protocol IE Received: %d",
                                  p_protocolIE_elem->id);

                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }
#endif
    return SIM_SUCCESS;
}

