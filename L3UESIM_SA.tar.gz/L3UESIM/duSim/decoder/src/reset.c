/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"


sim_return_val_et
decode_reset_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_Reset*         p_trg_reset_req       = NULL;
    f1ap_Reset*          p_reset_req           = NULL;
    f1ap_Reset_protocolIEs_element*
                         p_protocolIE_elem     = NULL;
    OSRTDListNode*       p_node                = NULL;
    U8                   ie_count              = 0;

    *p_msgOutBufLen = sizeof(_f1ap_Reset);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);	
    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target Reset Request container */
    p_trg_reset_req = (_f1ap_Reset*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_reset_req = p_asnMsg->u.initiatingMessage->value.u.reset;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_reset_req->protocolIEs.head;

    /* Iterate List of all IEs in source Reset Request container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_reset_req->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_Reset_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_reset_req->transactionId 
                    = p_protocolIE_elem->value.u._f1ap_ResetIEs_1;

                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = NULL;
                _f1ap_Cause* p_trg_cause = NULL;

                /* Fetch pointer to source Cause IE container */
                p_src_cause = p_protocolIE_elem->value.u._f1ap_ResetIEs_2;

                /* Fetch pointer to target Cause IE container */
                p_trg_cause = &p_trg_reset_req->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork:
                    {
                        p_trg_cause->cause_type 
                                = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport:
                    {
                        p_trg_cause->cause_type 
                                = F1_CAUSE_TRANSPORT;
                        p_trg_cause->u.transport
                                = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol:
                    {
                        p_trg_cause->cause_type 
                                = F1_CAUSE_PROTOCOL;
                        p_trg_cause->u.protocol
                                = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc:
                    {
                        p_trg_cause->cause_type 
                                = F1_CAUSE_MISC;
                        p_trg_cause->u.misc
                                = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Unknown Cause type received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_ResetType: 
            {
                switch(p_protocolIE_elem->value.u._f1ap_ResetIEs_3->t)
                {
                    case T_f1ap_ResetType_f1_Interface:
                    {
                        p_trg_reset_req->resetType.type 
                                = F1AP_RESET_TYPE_COMPLETE; 

                        p_trg_reset_req->resetType.u.f1_Interface
                                = p_protocolIE_elem->value.u.
                                     _f1ap_ResetIEs_3->u.f1_Interface;

                        break;
                    }

                    case T_f1ap_ResetType_partOfF1_Interface:
                    {
                        f1ap_UE_associatedLogicalF1_ConnectionListRes*
                                     p_src_conn_list = NULL;
                        _f1ap_UE_associatedLogicalF1_ConnectionListRes*
                                     p_trg_conn_list = NULL;
                        f1ap_UE_associatedLogicalF1_ConnectionListRes_element*
                                     p_src_conn_elem = NULL;
                        f1ap_UE_associatedLogicalF1_ConnectionItem*
                                     p_src_conn_item = NULL;
                        _f1ap_UE_associatedLogicalF1_ConnectionListRes_element*
                                     p_trg_conn_item = NULL;
                        OSRTDListNode*  
                                     p_conn_node     = NULL;
                        unsigned int index           = 0;

                        p_trg_reset_req->resetType.type 
                                = F1AP_RESET_TYPE_PARTIAL; 

                        /* Fetch pointer to source connection list */
                        p_src_conn_list = p_protocolIE_elem->value.u.
                                  _f1ap_ResetIEs_3->u.partOfF1_Interface;

                        /* Fetch pointer to target connection list */
                        p_trg_conn_list = &p_trg_reset_req->resetType.u.
                                                partOfF1_Interface; 

                        p_trg_reset_req->resetType.u.partOfF1_Interface.
                            count = p_src_conn_list->count;

                        /* Get pointer to first node in the connection list */
                        p_conn_node = p_src_conn_list->head;

                        /* Traverse through the list of connections and copy
                         * each to the target container */
                        for (index = 0; index < p_src_conn_list->count;
                             index++)
                        {
                            p_src_conn_elem 
                                 = (f1ap_UE_associatedLogicalF1_ConnectionListRes_element*)
                                                   p_conn_node->data;

                            p_src_conn_item = p_src_conn_elem->value.u.
                                    _f1ap_UE_associatedLogicalF1_ConnectionItemRes_1;

                            p_trg_conn_item = &p_trg_conn_list->
                                                   ue_associated_connection[index];

                            if (p_src_conn_item->m.gNB_CU_UE_F1AP_IDPresent)
                            {
                                p_trg_conn_item->bitmask 
                                     |= UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT;
                                p_trg_conn_item->gNB_CU_F1AP_ID 
                                     = p_src_conn_item->gNB_CU_UE_F1AP_ID; 
                            }

                            if (p_src_conn_item->m.gNB_DU_UE_F1AP_IDPresent)
                            {
                                p_trg_conn_item->bitmask 
                                    |= UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT;
                                p_trg_conn_item->gNB_DU_F1AP_ID 
                                    = p_src_conn_item->gNB_DU_UE_F1AP_ID; 
                            }

                            /* Get pointer to the next node in the list */
                            p_conn_node = p_conn_node->next;
                        }

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid Reset Type received");
                        break;
                    }
                }
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                //return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}


sim_return_val_et
decode_reset_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_ResetAcknowledge* p_trg_reset_ack      = NULL;
    f1ap_ResetAcknowledge*  p_reset_ack          = NULL;
    f1ap_ResetAcknowledge_protocolIEs_element*
                            p_protocolIE_elem    = NULL;
    OSRTDListNode*          p_node               = NULL;
    U8                      ie_count             = 0;

    *p_msgOutBufLen = sizeof(_f1ap_ResetAcknowledge);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target Reset ACK */
    p_trg_reset_ack = (_f1ap_ResetAcknowledge*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_reset_ack = p_asnMsg->u.successfulOutcome->value.u.reset;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_reset_ack->protocolIEs.head;

    /* Iterate List of all IEs in source Reset Response container  
     * and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_reset_ack->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_ResetAcknowledge_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_reset_ack->transactionId = p_protocolIE_elem->value.
                              u._f1ap_ResetAcknowledgeIEs_1;

                break;
            }

            case ASN1V_f1ap_id_UE_associatedLogicalF1_ConnectionListResAck:
            {
                f1ap_UE_associatedLogicalF1_ConnectionListResAck_element*
                                p_conn_res_ack_elem = NULL;
                OSRTDListNode*  p_conn_node         = NULL;
                unsigned int    index               = 0;

                p_trg_reset_ack->ue_associated_connection_list.count 
                         = p_protocolIE_elem->value.u.
                                _f1ap_ResetAcknowledgeIEs_2->count;

                /* Get pointer to first node in the connection list */
                p_conn_node = p_protocolIE_elem->value.u.
                                    _f1ap_ResetAcknowledgeIEs_2->head;

                /* Traverse through the list of connections and copy
                 * each to the target container */
                for (index = 0; index < p_protocolIE_elem->value.u.
                                          _f1ap_ResetAcknowledgeIEs_2->count;
                     index++)
                {
                    p_conn_res_ack_elem 
                        = (f1ap_UE_associatedLogicalF1_ConnectionListResAck_element*)
                                         p_conn_node->data;                   

                    /* Copy CU F1AP ID, if present in the source container */
                    if (p_conn_res_ack_elem->value.u.
                        _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1
                                 ->m.gNB_CU_UE_F1AP_IDPresent)
                    {
                        p_trg_reset_ack->ue_associated_connection_list.
                               ue_associated_connection[index].bitmask
                               |= UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT; 

                        p_trg_reset_ack->ue_associated_connection_list.
                               ue_associated_connection[index].gnb_cu_f1ap_id
                            = p_conn_res_ack_elem->value.u.
                                _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1
                                        ->gNB_CU_UE_F1AP_ID;
                    }

                    /* Copy DU F1AP ID, if present in the source container */
                    if (p_conn_res_ack_elem->value.u.
                            _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1
                                 ->m.gNB_DU_UE_F1AP_IDPresent)
                    {
                        p_trg_reset_ack->ue_associated_connection_list.
                               ue_associated_connection[index].bitmask
                               |= UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT; 

                        p_trg_reset_ack->ue_associated_connection_list.
                               ue_associated_connection[index].gnb_du_f1ap_id
                            = p_conn_res_ack_elem->value.u.
                                _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1
                                        ->gNB_DU_UE_F1AP_ID;
                    }

                    /* Get pointer to the next node in the list */
                    p_conn_node = p_conn_node->next;
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                                      u._f1ap_ResetAcknowledgeIEs_3;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_reset_ack->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = NULL;
                    unsigned int   index                   = 0;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_reset_ack->bitmask |= F1AP_RESET_ACK_CRIT_DIAG_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}

