/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for decoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "decoder.h"
#include "typedefs.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"
#include "du_sim_common.h"

/* This function decodes CU Config update and populates 
 * a user provided buffer with decoded information. */
/*******************************************************************************
 * Function Name  : decode_cu_config_update
 * Description    : This function decodes CU Config update and populates
 *                  a user provided buffer with decoded information.
 *
 * Inputs         : OSCTXT*         asn1_ctx
 *                  f1ap_F1AP_PDU*  p_asnMsg
 *                  void**          p_msgOutBuf
 *                  unsigned long*  p_msgOutBufLen       
 * Outputs        : Decoded CU Config update msg
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/

sim_return_val_et
decode_cu_config_update(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    f1ap_adpt_cu_config_update_req_t* p_trg_msg             = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdate*  p_src_msg               = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdate_protocolIEs_element*
                                    p_protocolIE_elem       = F1AP_P_NULL;
    OSRTDListNode*                  p_node                  = F1AP_P_NULL;
    U8                              ie_count                = 0;

    /* Calculate size of target message buffer */
    *p_msgOutBufLen = sizeof(f1ap_adpt_cu_config_update_req_t);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }
    asn1Print_f1ap_F1AP_PDU("f1ap_pdu", p_asnMsg);
    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target CU Configuration update container */
    p_trg_msg = (f1ap_adpt_cu_config_update_req_t *)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                                u.gNBCUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source gNB CU Configuration update 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBCUConfigurationUpdate_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->trans_id = p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_1;
                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Activated_List: 
            {
                f1ap_Cells_to_be_Activated_List_element*
                                            p_cell_elem         = F1AP_P_NULL;
                f1ap_Cells_to_be_Activated_List_Item*
                                            p_src_cell_item     = F1AP_P_NULL;
                f1ap_adpt_cells_to_be_activated_list_element_t*
                                            p_trg_cell_item     = F1AP_P_NULL;
                OSRTDListNode*              p_cell_node         = F1AP_P_NULL;
                unsigned short              index               = F1AP_NULL;

                /* Populate count of cells in the list */
                p_trg_msg->cellsToBeActivatedList.count 
                        = p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_2->count;

                /* Fetch pointer to the first node in the list */
                p_cell_node = p_protocolIE_elem->value.u.
                                _f1ap_GNBCUConfigurationUpdateIEs_2->head;

                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_2->count;
                     index++)
                {
                    p_cell_elem = (f1ap_Cells_to_be_Activated_List_element*)
                                           p_cell_node->data;

                    /* Fetch pointer to the cell item */
                    p_src_cell_item = p_cell_elem->value.u.
                          _f1ap_Cells_to_be_Activated_List_ItemIEs_1;
 
                    /* Fetch pointer to target cell item */
                    p_trg_cell_item = &p_trg_msg->cellsToBeActivatedList.
                                           cell_to_activate[index]; 
                    
                    /* Populate CGI */
                    {
                        p_trg_cell_item->cgi.plmn_identity.numocts
                                = p_src_cell_item->nRCGI.pLMN_Identity.numocts;

                        memcpy(p_trg_cell_item->cgi.plmn_identity.data,
                               p_src_cell_item->nRCGI.pLMN_Identity.data,
                               3);

                        p_trg_cell_item->cgi.nr_cellidentity.num_bits
                                = p_src_cell_item->nRCGI.nRCellIdentity.numbits;

                        memcpy(p_trg_cell_item->cgi.nr_cellidentity.data,
                               p_src_cell_item->nRCGI.nRCellIdentity.data,
                               5);
                    }

                    /* Populate PCI, if present in source container */
                    if (p_src_cell_item->m.nRPCIPresent)
                    {
                        p_trg_cell_item->pci = p_src_cell_item->nRPCI; 
                        p_trg_cell_item->bitmask |= CELL_TO_BE_ACTIVATED_PCI_PRESENT; 
                    }

                    /* Get pointer to the next node in the list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Deactivated_List: 
            {
                f1ap_Cells_to_be_Deactivated_List_element*
                                           p_src_cell_elem      = F1AP_P_NULL;
                f1ap_Cells_to_be_Deactivated_List_Item* 
                                           p_src_cell_item      = F1AP_P_NULL;
                f1ap_adpt_cells_to_be_deactivated_list_element_t*
                                           p_trg_cell_item      = F1AP_P_NULL;
                OSRTDListNode*             p_cell_node          = F1AP_P_NULL;
                unsigned short             index                = F1AP_NULL;

                /* Populate count of cells in the list */
                p_trg_msg->cellsToBeDeactivatedList.count 
                        = p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_3->count;

                /* Fetch pointer to the first node in the list */
                p_cell_node = p_protocolIE_elem->value.u.
                                _f1ap_GNBCUConfigurationUpdateIEs_3->head;

                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_3->count;
                     index++)
                {
                    /* Fetch pointer to source cell element */
                    p_src_cell_elem = (f1ap_Cells_to_be_Deactivated_List_element*)
                                            p_cell_node->data;

                    /* Fetch pointer to source cell item container */
                    p_src_cell_item = p_src_cell_elem->value.u.
                            _f1ap_Cells_to_be_Deactivated_List_ItemIEs_1;

                    /* Fetch pointer to target cell item container */
                    p_trg_cell_item = &p_trg_msg->cellsToBeDeactivatedList.
                                             cell_to_deactivate[index];

                    p_trg_cell_item->cgi.plmn_identity.numocts
                            = p_src_cell_item->nRCGI.pLMN_Identity.numocts;

                    memcpy(p_trg_cell_item->cgi.plmn_identity.data,
                           p_src_cell_item->nRCGI.pLMN_Identity.data,
                           3);

                    p_trg_cell_item->cgi.nr_cellidentity.num_bits
                            = p_src_cell_item->nRCGI.nRCellIdentity.numbits;

                    memcpy(p_trg_cell_item->cgi.nr_cellidentity.data,
                           p_src_cell_item->nRCGI.nRCellIdentity.data,
                           5);

                    /* Get pointer to the next node in the list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}


/* This function decodes CU Config update ACK and populates 
 * a user provided buffer with decoded information. */
sim_return_val_et
decode_cu_config_update_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_GNBCUConfigurationUpdateAcknowledge* 
                                    p_trg_msg            =   F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateAcknowledge*  
                                    p_src_msg            = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element*
                                    p_protocolIE_elem    = F1AP_P_NULL;
    OSRTDListNode*                  p_node               = F1AP_P_NULL;
    U8                              ie_count             = F1AP_NULL;

    *p_msgOutBufLen = sizeof(_f1ap_GNBCUConfigurationUpdateAcknowledge);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target CU Configuration Update ACK */
    p_trg_msg = (_f1ap_GNBCUConfigurationUpdateAcknowledge*)
                               (*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.successfulOutcome->value.u.
                       gNBCUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source CU Configuration update ACK
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element*)
                p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transaction_id = p_protocolIE_elem->value.u.
                              _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_1;
                break;
            }

            case ASN1V_f1ap_id_Cells_Failed_to_be_Activated_List: 
            {
                OSRTDListNode*  p_cell_node = F1AP_P_NULL;
                unsigned int    index       = F1AP_NULL;

                /* Store the count in the target container */
                p_trg_msg->cellsFailedToBeActivatedList.count 
                    = p_protocolIE_elem->value.u.
                           _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2->count;

                /* Get pointer to first node in the cell list */
                p_cell_node = p_protocolIE_elem->value.u.
                        _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2->head;

                /* Traverse through the list of cells and copy each
                 * to the target container */
                for (index = 0; index < p_protocolIE_elem->value.u.
                                 _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2->count;
                     index++)
                {
                  //  p_cell_elem = (f1ap_Cells_Failed_to_be_Activated_List_element*)
                    //                     p_cell_node->data;                   

                    /* TODO : Need to update this once updated specs are
                     * available and ASN is re-generated */

                    /* Get pointer to the next node in the cell list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = F1AP_P_NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = F1AP_P_NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                          u._f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = F1AP_P_NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = F1AP_P_NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = F1AP_P_NULL;
                    unsigned int   index                   = F1AP_NULL;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_trg_crit_diag->iEsList.ie_count 
                        = p_src_crit_diag->iEsCriticalityDiagnostics.count;

                    /* Get pointer to the first node in the list */
                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    for (index = 0; 
                         index < p_src_crit_diag->iEsCriticalityDiagnostics.count;
                         index++)
                    {
                        /* Fetch pointer to source criticality diagnostics IE
                         * element */
                        p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                    p_crit_diag_node->data;

                        /* Fetch pointer to target criticality diagnostics IE
                         * element and populate it */
                        p_trg_crit_diag_ie_elem 
                                     = &p_trg_crit_diag->iEsList.ie_info[index];

                        p_trg_crit_diag_ie_elem->iECriticality 
                                     = p_crit_diag_ie_elem->iECriticality; 
                        p_trg_crit_diag_ie_elem->iE_ID         
                                     = p_crit_diag_ie_elem->iE_ID;
                        p_trg_crit_diag_ie_elem->typeOfError   
                                     = p_crit_diag_ie_elem->typeOfError;

                        /* Get pointer to the next node */
                        p_crit_diag_node = p_crit_diag_node->next;
                    }

                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask 
                    |= F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}


/* This function decodes CU Config update failure and populates 
 * a user provided buffer with decoded information. */
sim_return_val_et
decode_cu_config_update_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
    _f1ap_GNBCUConfigurationUpdateFailure* 
                          p_trg_msg          = F1AP_NULL;
    f1ap_GNBCUConfigurationUpdateFailure*  
                          p_src_msg          = F1AP_NULL;
    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element*
                          p_protocolIE_elem  = F1AP_NULL;
    OSRTDListNode*        p_node             = F1AP_NULL;
    U8                    ie_count           = 0;

    /* Calculate size of the target buffer */
    *p_msgOutBufLen = sizeof(_f1ap_GNBCUConfigurationUpdateFailure);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target CU Configuration Update Failure */
    p_trg_msg = (_f1ap_GNBCUConfigurationUpdateFailure*)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.unsuccessfulOutcome->value.
                                  u.gNBCUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in CU Config Update Failure source 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element*)
                      p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->transaction_id = p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateFailureIEs_1;
                break;
            }

            case ASN1V_f1ap_id_Cause:
            {
                f1ap_Cause*  p_src_cause = F1AP_NULL;
                _f1ap_Cause* p_trg_cause = F1AP_NULL;

                /* Fetch pointer to source container */
                p_src_cause = p_protocolIE_elem->value.u.
                                   _f1ap_GNBCUConfigurationUpdateFailureIEs_2; 

                /* Fetch pointer to target container */
                p_trg_cause = &p_trg_msg->cause; 

                switch(p_src_cause->t)
                {
                    case T_f1ap_Cause_radioNetwork: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_RADIO_NETWORK;

                        p_trg_cause->u.radioNetwork 
                                     = p_src_cause->u.radioNetwork;

                        break;
                    }

                    case T_f1ap_Cause_transport: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_TRANSPORT;

                        p_trg_cause->u.transport 
                                     = p_src_cause->u.transport;

                        break;
                    }

                    case T_f1ap_Cause_protocol: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_PROTOCOL;

                        p_trg_cause->u.protocol 
                                     = p_src_cause->u.protocol;

                        break;
                    }

                    case T_f1ap_Cause_misc: 
                    {
                        p_trg_cause->cause_type = F1_CAUSE_MISC;

                        p_trg_cause->u.misc 
                                    = p_src_cause->u.misc;

                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid cause type received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_TimeToWait:
            {
                p_trg_msg->bitmask 
                      |= F1AP_CU_CFG_UPDATE_TIME_TO_WAIT_PRESENT;

                switch(p_protocolIE_elem->value.
                            u._f1ap_GNBCUConfigurationUpdateFailureIEs_3)
                {
                    case f1ap_v1s:
                    {
                        p_trg_msg->timeToWait = f1ap_v1s;
                        break;
                    }

                    case f1ap_v2s:
                    {
                        p_trg_msg->timeToWait = f1ap_v2s;
                        break;
                    }

                    case f1ap_v5s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v5s;
                        break;
                    }

                    case f1ap_v10s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v10s;
                        break;
                    }

                    case f1ap_v20s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v20s;
                        break;
                    }

                    case f1ap_v60s: 
                    {
                        p_trg_msg->timeToWait = f1ap_v60s;
                        break;
                    }

                    default:
                    {
                        LOG_TRACE("Invalid timeToWait value received \n");
                        break;
                    }
                }

                break;
            }

            case ASN1V_f1ap_id_CriticalityDiagnostics:
            {
                f1ap_CriticalityDiagnostics*  p_src_crit_diag = F1AP_NULL;
                _f1ap_CriticalityDiagnostics* p_trg_crit_diag = F1AP_NULL;

                /* Fetch pointer to source criticality diagnostics container */
                p_src_crit_diag = p_protocolIE_elem->value.
                                      u._f1ap_GNBCUConfigurationUpdateFailureIEs_4;

                /* Fetch pointer to target criticality diagnostics container */
                p_trg_crit_diag = &p_trg_msg->criticality_diagnostics;

                /* Fill Procedure Code, If Present. */
                if (p_src_crit_diag->m.procedureCodePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CODE_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCode 
                                = p_src_crit_diag->procedureCode;
                }

                /* Fill Triggering Message, If Present. */
                if (p_src_crit_diag->m.triggeringMessagePresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_TRIGGERING_MSG_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->triggeringMessage 
                                = p_src_crit_diag->triggeringMessage;
                }

                /* Fill Procedure Criticality, If Present. */
                if (p_src_crit_diag->m.procedureCriticalityPresent)
                {
                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                                |= CRIT_DIAG_PROC_CRIT_PRESENT;

                    /* Fill Value */
                    p_trg_crit_diag->procedureCriticality 
                                = p_src_crit_diag->procedureCriticality;
                }

                /* Fill iEsCriticality Diagnostics, If Present. */
                if (p_src_crit_diag->m.iEsCriticalityDiagnosticsPresent)
                {
                    OSRTDListNode* p_crit_diag_node        = F1AP_NULL;
                    f1ap_CriticalityDiagnostics_IE_Item*
                                   p_crit_diag_ie_elem     = F1AP_NULL;
                    _f1ap_CriticalityDiagnostics_IE_Item*
                                   p_trg_crit_diag_ie_elem = F1AP_NULL;

                    /* Fill Bitmask */
                    p_trg_crit_diag->bitmask 
                               |= CRIT_DIAG_IE_LIST_PRESENT;

                    p_crit_diag_node 
                            = p_src_crit_diag->iEsCriticalityDiagnostics.head;

                    /* Fetch pointer to source criticality diagnostics IE
                     * element */
                    p_crit_diag_ie_elem = (f1ap_CriticalityDiagnostics_IE_Item*)
                                                p_crit_diag_node->data;

                    p_trg_crit_diag->iEsList.ie_count = 1;

                    /* Fetch pointer to first target criticality diagnostics IE
                     * element and populate it */
                    p_trg_crit_diag_ie_elem 
                         = &p_trg_crit_diag->iEsList.ie_info[0];

                    p_trg_crit_diag_ie_elem->iECriticality = p_crit_diag_ie_elem->iECriticality; 
                    p_trg_crit_diag_ie_elem->iE_ID         = p_crit_diag_ie_elem->iE_ID;
                    p_trg_crit_diag_ie_elem->typeOfError   = p_crit_diag_ie_elem->typeOfError;
                }

                /* Set the flag to indicate that Criticality Diagnostics IE
                 * is present in the ACK */
                p_trg_msg->bitmask 
                       |= F1AP_CU_CFG_UPDATE_CRIT_DIAGNOSTICS_PRESENT;

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }

    return SIM_SUCCESS;
}
sim_return_val_et
decode_du_config_update(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen)
{
#if 0
    f1ap_adpt_cu_config_update_req_t* p_trg_msg          = F1AP_NULL;
    f1ap_GNBCUConfigurationUpdate*  p_src_msg          = F1AP_NULL;
    f1ap_GNBCUConfigurationUpdate_protocolIEs_element*
                                    p_protocolIE_elem  = F1AP_NULL;
    OSRTDListNode*                  p_node             = F1AP_NULL;
    U8                              ie_count           = 0;

    /* Calculate size of target message buffer */
    *p_msgOutBufLen = sizeof(_f1ap_Reset);

    /* Allocate memory for decoded message */
    *p_msgOutBuf = malloc(*p_msgOutBufLen);
    if (F1AP_NULL == *p_msgOutBuf)
    {
        LOG_TRACE("Failed to allocate memory for decoded message \n");
        return SIM_FAILURE;
    }

    memset(*p_msgOutBuf, 0, *p_msgOutBufLen);

    /* Get pointer to target CU Configuration update container */
    p_trg_msg = (f1ap_adpt_cu_config_update_req_t *)(*p_msgOutBuf);

    /* Fetch pointer to source ASN message */
    p_src_msg = p_asnMsg->u.initiatingMessage->value.
                                u.gNBCUConfigurationUpdate;

    /* Fetch pointer to first node in protocol IEs list */
    p_node = p_src_msg->protocolIEs.head;

    /* Iterate List of all IEs in source gNB CU Configuration update 
     * container  and populate each in the target container */
    for (ie_count = 0;
         ie_count < p_src_msg->protocolIEs.count;
         ie_count++)
    {
        if (!p_node)
        {
            return SIM_FAILURE;
        }

        /* Fetch pointer to source protocol IE element */
        p_protocolIE_elem = 
            (f1ap_GNBCUConfigurationUpdate_protocolIEs_element*)p_node->data;

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_f1ap_id_TransactionID: 
            {
                p_trg_msg->trans_id = p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_1;
                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Activated_List: 
            {
                f1ap_Cells_to_be_Activated_List_element*
                                p_cell_elem     = F1AP_NULL;
                f1ap_Cells_to_be_Activated_List_Item*
                                p_src_cell_item = F1AP_NULL;
                f1ap_adpt_cells_to_be_activated_list_element_t*
                                p_trg_cell_item = F1AP_NULL;
                OSRTDListNode*  p_cell_node     = F1AP_NULL;
                unsigned short  index           = 0;

                /* Populate count of cells in the list */
                p_trg_msg->cellsToBeActivatedList.count 
                        = p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_2->count;

                /* Fetch pointer to the first node in the list */
                p_cell_node = p_protocolIE_elem->value.u.
                                _f1ap_GNBCUConfigurationUpdateIEs_2->head;

                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_2->count;
                     index++)
                {
                    p_cell_elem = (f1ap_Cells_to_be_Activated_List_element*)
                                           p_cell_node;

                    /* Fetch pointer to the cell item */
                    p_src_cell_item = p_cell_elem->value.u.
                          _f1ap_Cells_to_be_Activated_List_ItemIEs_1;
 
                    /* Fetch pointer to target cell item */
                    p_trg_cell_item = &p_trg_msg->cellsToBeActivatedList.
                                           cell_to_activate[index]; 
                    
                    /* Populate CGI */
                    {
                        p_trg_cell_item->cgi.plmn_identity.numocts
                                = p_src_cell_item->nRCGI.pLMN_Identity.numocts;

                        memcpy(p_trg_cell_item->cgi.plmn_identity.data,
                               p_src_cell_item->nRCGI.pLMN_Identity.data,
                               3);

                        p_trg_cell_item->cgi.nr_cellidentity.num_bits
                                = p_src_cell_item->nRCGI.nRCellIdentity.numbits;

                        memcpy(p_trg_cell_item->cgi.nr_cellidentity.data,
                               p_src_cell_item->nRCGI.nRCellIdentity.data,
                               5);
                    }

                    /* Populate PCI, if present in source container */
                    if (p_src_cell_item->m.nRPCIPresent)
                    {
                        p_trg_cell_item->pci = p_src_cell_item->nRPCI; 
                        p_trg_cell_item->bitmask |= CELL_TO_BE_ACTIVATED_PCI_PRESENT; 
                    }

                    /* Get pointer to the next node in the list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            case ASN1V_f1ap_id_Cells_to_be_Deactivated_List: 
            {
                f1ap_Cells_to_be_Deactivated_List_element*
                                p_src_cell_elem = F1AP_NULL;
                f1ap_Cells_to_be_Deactivated_List_Item* 
                                p_src_cell_item = F1AP_NULL;
                f1ap_adpt_cells_to_be_deactivated_list_element_t*
                                p_trg_cell_item = F1AP_NULL;
                OSRTDListNode*  p_cell_node     = F1AP_NULL;
                unsigned short  index           = 0;

                /* Populate count of cells in the list */
                p_trg_msg->cellsToBeDeactivatedList.count 
                        = p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_3->count;

                /* Fetch pointer to the first node in the list */
                p_cell_node = p_protocolIE_elem->value.u.
                                _f1ap_GNBCUConfigurationUpdateIEs_3->head;

                for (index = 0; index < p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateIEs_3->count;
                     index++)
                {
                    /* Fetch pointer to source cell element */
                    p_src_cell_elem = (f1ap_Cells_to_be_Deactivated_List_element*)
                                            p_cell_node;

                    /* Fetch pointer to source cell item container */
                    p_src_cell_item = p_src_cell_elem->value.u.
                            _f1ap_Cells_to_be_Deactivated_List_ItemIEs_1;

                    /* Fetch pointer to target cell item container */
                    p_trg_cell_item = &p_trg_msg->cellsToBeDeactivatedList.
                                             cell_to_deactivate[index];

                    p_trg_cell_item->cgi.plmn_identity.numocts
                            = p_src_cell_item->nRCGI.pLMN_Identity.numocts;

                    memcpy(p_trg_cell_item->cgi.plmn_identity.data,
                           p_src_cell_item->nRCGI.pLMN_Identity.data,
                           3);

                    p_trg_cell_item->cgi.nr_cellidentity.num_bits
                            = p_src_cell_item->nRCGI.nRCellIdentity.numbits;

                    memcpy(p_trg_cell_item->cgi.nr_cellidentity.data,
                           p_src_cell_item->nRCGI.nRCellIdentity.data,
                           5);

                    /* Get pointer to the next node in the list */
                    p_cell_node = p_cell_node->next;
                }

                break;
            }

            default:
            {
                LOG_TRACE("Invalid Protocol IE Received:");
                return SIM_FAILURE;
            }
        }

        p_node = p_node->next;
    }


#endif

    return SIM_SUCCESS;
}

