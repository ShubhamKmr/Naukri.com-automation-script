#include "proto_enc_dec.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"


/* Function for initializing the UE sim decoder */
void init_du_sim_decoder();


/* Function for resetting UE sim decoder */
void reset_du_sim_decoder();


/* Function for decoding messages received by X2 simulator */
unsigned char du_sim_decode(
        void*          msgInBuf,
        long           msgInBufLen,
        void**         msgOutBuf,
        unsigned long* msgOutBufLen);


/* This function creates and return decoder for X2 sim */
decoder_t* create_du_sim_decoder();
sim_return_val_et
decode_du_config_update_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);



sim_return_val_et
decode_cu_config_update(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_cu_config_update_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_cu_config_update_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_error_indication(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_f1Setup_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_f1Setup_response(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_f1Setup_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_reset_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_reset_ack(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_dl_rrc_msg_transfer(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ul_rrc_msg_transfer(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_mod_request(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_mod_response(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_mod_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_release_command(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_release_complete(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_setup_request(
      //OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_setup_response(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);


sim_return_val_et
decode_ue_ctx_setup_failure(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);
sim_return_val_et
decode_du_config_update_fail(
      OSCTXT*         asn1_ctx, 
      f1ap_F1AP_PDU*  p_asnMsg, 
      void**          p_msgOutBuf, 
      unsigned long*  p_msgOutBufLen);

sim_return_val_et
decode_ue_ctx_modification_confirm(
      OSCTXT*         asn1_ctx,
      f1ap_F1AP_PDU*  p_asnMsg,
      void**          p_msgOutBuf,
      unsigned long*  p_msgOutBufLen);

