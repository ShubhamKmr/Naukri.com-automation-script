/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/sctp.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/sctp.h>
#include <time.h>
#include <sys/time.h>
/* Project Includes */
#include "peer_conn_hdlr.h"
#if 0
struct tm {  //Reetika Changes
    int tm_sec;     /* seconds after the minute - [0,59] */
    int tm_min;     /* minutes after the hour - [0,59] */
    int tm_hour;    /* hours since midnight - [0,23] */
    int tm_mday;    /* day of the month - [1,31] */
    int tm_mon;     /* months since January - [0,11] */
    int tm_year;    /* years since 1900 */
    int tm_wday;    /* days since Sunday - [0,6] */
    int tm_yday;    /* days since January 1 - [0,365] */
    int tm_isdst;   /* daylight savings time flag */
};
#endif

typedef struct timestamp_
{
   struct tm current;
    struct timeval      tv; 
}timestamp_tdu;

timestamp_tdu get_time_stampdu()
{
    struct tm current;
    struct timeval      tv;
    gettimeofday(&tv,0);
    localtime_r(&tv.tv_sec, &current);
    timestamp_tdu timestamp;
    timestamp.current = current;
    timestamp.tv = tv;      
    return timestamp;
}

/* UDP Socket changes */
/* This function initializes the peer connection handler */
sim_return_val_et 
du_sim_control_plane_conn_hdlr_udp_init(void* data)
{
    peer_conn_data_t* pData = NULL;
    
    (void)pData; // Unused Arg

    LOG_TRACE("DU sim peer UDP connection handler init \n");

    return SIM_SUCCESS;
}

/* This function open the peer connection handler */
int 
du_sim_control_plane_conn_hdlr_udp_open(void* user_data)
{
    LOG_TRACE("DU sim peer UDP connection handler open \n");

    int                         sockFd          = -1;
    //int                         return_value    = 0;  
    //int                         addr_len        = 0;   
    peer_conn_data_t*           peer_conn_data  = NULL;
    dusim_sctp_comm_info_t*     local_comm_info = NULL;
    struct                      sockaddr_in selfAddr;

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    local_comm_info = &peer_conn_data->du_comm_info;

    memset(&selfAddr, 0, sizeof(selfAddr));

    /* Create a UDP socket FD  */
    if ((sockFd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        LOG_TRACE("Failed to create UDP socket, errno:%d \n", errno);
        return SIM_FAILURE;
    }

    LOG_TRACE("DU UDP socket created with FD %d \n", sockFd);

    /* Bind created socket with address */
    {
        selfAddr.sin_family      = AF_INET;
        selfAddr.sin_addr.s_addr = inet_addr((const char*)&local_comm_info->ipv4_addr[0].ip_addr);
        selfAddr.sin_port        = htons(local_comm_info->port);

        if (bind(sockFd, (struct sockaddr *)&selfAddr, sizeof(selfAddr)) < 0) 
        {
            LOG_TRACE("Server bind failure, errno: %d\n", errno);

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("Bind Successfull for SD and port %d %d\n", sockFd,selfAddr.sin_port);
    }

    /* Store socket FD in peer connection data for further use */
    peer_conn_data->sockFd = sockFd;

    return sockFd;
}


/* This function close the peer connection handler */
void du_sim_control_plane_conn_hdlr_udp_close(void* user_data)
{
    peer_conn_data_t*  peer_conn_data = NULL;

    LOG_TRACE("X2 sim UDP peer connection handler close \n");

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Close the socket connection */
    close(peer_conn_data->sockFd);
}


/* This function is used to send the packet to peer */
void du_sim_control_plane_conn_hdlr_udp_send(
        void*          user_data, 
        void*          apiBuf,
        unsigned short apiLen)
{
    peer_conn_data_t*           peer_conn_data = NULL;
    struct sockaddr_in          peeraddr;
    dusim_sctp_comm_info_t*     peer_comm_info = NULL;
    static int                  info = 0;


    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Fetch pointer to peer communication info */
    peer_comm_info  = &peer_conn_data->cu_comm_info;

    peeraddr.sin_family  = AF_INET;
    peeraddr.sin_port    = htons(peer_comm_info->port);
    peeraddr.sin_addr.s_addr  = inet_addr((const char*)peer_comm_info->ipv4_addr[0].ip_addr);

    LOG_TRACE("[APIX]:- DU sim peer UDP connection handler send with port %d....b4htos(%u)....count(%u)\n",
                  peeraddr.sin_port,peer_comm_info->port,info);
    info++;

    timestamp_tdu  comp_time = {{0},{0}};
    comp_time = get_time_stampdu();
    LOG_TRACE("[APIX TIME :] : %02d:%02d:%02d.%06ld %s\n",
            comp_time.current.tm_hour, comp_time.current.tm_min,
            comp_time.current.tm_sec, comp_time.tv.tv_usec,__FUNCTION__);

   /* Send message to the Peer */
    if (-1 == sendto(peer_conn_data->sockFd,
                     apiBuf, apiLen, 0,
                     (struct sockaddr*)&peeraddr,
                     sizeof(struct sockaddr_in)))
    {
        fprintf(stderr, "Failed to send API to sim, errno: %d\n",
                errno);
    }
}


/* This function is used to receive packet from peer */
unsigned int 
du_sim_control_plane_conn_hdlr_udp_receive(
        void*  user_data,
        void** recvBuf)
{
    peer_conn_data_t*       peer_conn_data = NULL;
    ssize_t                 msgLen         = 0;
    size_t                  buflen         = 0;
    //void*                   retBuf         = NULL;
    struct                  sockaddr_in  sock_addr;
    int                     addrLen        = 0; 

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Allocate memory for recv buffer */
    buflen = 65535;

    if ((*recvBuf = malloc(buflen)) == NULL) 
    {
        LOG_TRACE("out of memory, malloc failed for msg data buffer.\n");
        return msgLen;
    }

    addrLen = sizeof(sock_addr);

    /* Read message from the socket */
    msgLen = recvfrom(peer_conn_data->sockFd, *recvBuf,
                      buflen, 0, (struct sockaddr *)&sock_addr,
                     (socklen_t *) &addrLen);

    if (-1 == msgLen)
    {
        fprintf(stderr,"Error while reading from socket: %d\n", errno);
        return msgLen;
    }

    timestamp_tdu  comp_time = {{0},{0}};
    comp_time = get_time_stampdu();
    LOG_TRACE("[APIY TIME :] : %02d:%02d:%02d.%06ld, ..%s\n",
            comp_time.current.tm_hour, comp_time.current.tm_min,
            comp_time.current.tm_sec, comp_time.tv.tv_usec,__FUNCTION__);

    /*if (NULL != *recvBuf)
    {
        free(*recvBuf);
        *recvBuf = NULL;
    }*/

    return msgLen;

}


/* Create control plane peer connection handler for eNB */
peer_conn_hdlr_t*
dusim_create_control_plane_peer_conn_hdlr_udp(
        dusim_sctp_comm_info_t* local_comm_info,
        dusim_sctp_comm_info_t* peer_comm_info)
{
    peer_conn_hdlr_t*  peer_conn_hdlr = NULL;
    peer_conn_data_t*  conn_hdlr_data = NULL;

    /* Allocate peer connection handler */
    peer_conn_hdlr = allocate_new_peer_conn_hdlr();
    if (NULL == peer_conn_hdlr)
    {
        LOG_TRACE("Failed to create peer UDP connection hdlr for X2 sim\n");
        return peer_conn_hdlr;
    }

    memset(peer_conn_hdlr, 0, sizeof(peer_conn_hdlr_t));

    /* Initializes the function pointers of peer connection handler */
    peer_conn_hdlr->init    = du_sim_control_plane_conn_hdlr_udp_init;
    peer_conn_hdlr->open    = du_sim_control_plane_conn_hdlr_udp_open;
    peer_conn_hdlr->connect = NULL;
    peer_conn_hdlr->close   = du_sim_control_plane_conn_hdlr_udp_close;
    peer_conn_hdlr->send    = du_sim_control_plane_conn_hdlr_udp_send;
    peer_conn_hdlr->receive = du_sim_control_plane_conn_hdlr_udp_receive;

    /* Store connection data in user data of peer connection handler */
    {
        /* Allocate memory for peer connection data */
        conn_hdlr_data = (peer_conn_data_t*)malloc(
                                     sizeof(peer_conn_data_t));
        if (NULL == conn_hdlr_data)
        {
            LOG_TRACE("Failed to allocate memory for peer connection data \n");
            return peer_conn_hdlr;
        }

        /* Reset memory allocated for peer connection data */
        memset(conn_hdlr_data, 0, sizeof(peer_conn_data_t));

        /* Copy local communication info */
        memcpy(&conn_hdlr_data->du_comm_info,
               local_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        /* Copy peer communication info */
        memcpy(&conn_hdlr_data->cu_comm_info,
               peer_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        /* Store connection data in peer connection handler */
        peer_conn_hdlr->user_data = conn_hdlr_data;
    }

    return peer_conn_hdlr;
}

/* UDP Socket changes */
