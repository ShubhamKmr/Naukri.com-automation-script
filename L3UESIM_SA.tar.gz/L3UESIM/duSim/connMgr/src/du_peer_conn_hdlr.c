/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/sctp.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/sctp.h>

/* Project Includes */
#include "peer_conn_hdlr.h"


/* This function initializes the peer connection handler */
sim_return_val_et 
du_sim_control_plane_conn_hdlr_init(void* data)
{
    peer_conn_data_t* pData = NULL;
    
    (void)pData; // Unused Arg

    LOG_TRACE("DU sim peer connection handler init \n");

    return SIM_SUCCESS;
}


/* This function open the peer connection handler */
int 
du_sim_control_plane_conn_hdlr_open(void* user_data)
{
    LOG_TRACE("DU sim peer connection handler open \n");

    int                         sockFd          = -1;
    int                         return_value    = 0;
    struct sctp_initmsg         initmsg         = {0};
    peer_conn_data_t*           peer_conn_data  = NULL;
    dusim_sctp_comm_info_t*      local_comm_info = NULL;
    dusim_sctp_config_param_t*  sctp_params     = NULL;

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    local_comm_info = &peer_conn_data->du_comm_info;

    /* Fetch pointer to SCTP config params */
    sctp_params  = &local_comm_info->config_param;

    /* Create a socket FD  */
    if ((sockFd = socket(AF_INET, SOCK_STREAM, IPPROTO_SCTP)) < 0)
    {
        LOG_TRACE("Failed to create socket, errno:%d \n", errno);
        return SIM_FAILURE;
    }

    LOG_TRACE("SCTP socket created with FD %d \n", sockFd);
#if 0
    /* Bind created socket with address */
    {
        selfAddr.sin_family      = AF_INET;
        selfAddr.sin_addr.s_addr = inet_addr((const char*)&local_comm_info->ipv4_addr[0].ip_addr);
        selfAddr.sin_port        = htons(local_comm_info->port);

        if (bind(sockFd, (struct sockaddr *)&selfAddr, addr_len) < 0) 
        {
            LOG_TRACE("Server bind failure, errno: %d\n", errno);

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("Bind Successfull for SD %d \n", sockFd);
    }
#endif
    /* Set SO_REUSEADDR option on socket */
    {
        const int optVal = 1;

        if (setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, 
                       &optVal, sizeof(int)) < 0)
        {
            LOG_TRACE("SCTP: Connection socket property SO_REUSEADDR not set [errno:%d]\n", errno);

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("SCTP: Connection socket property SO_REUSEADDR is set\n");
    }

    /* Set the init message parameters value as per configuration */
    {
        memset(&initmsg, 0, sizeof(initmsg));

        {
            initmsg.sinit_max_attempts   = sctp_params->init_max_attempts;
            initmsg.sinit_num_ostreams   = sctp_params->init_num_ostreams;
            initmsg.sinit_max_instreams  = sctp_params->init_max_instreams;
            initmsg.sinit_max_init_timeo = sctp_params->init_max_init_timeo;
        }

        return_value = setsockopt(sockFd,
                                  IPPROTO_SCTP,
                                  SCTP_INITMSG,
                                  &initmsg,
                                  sizeof(initmsg));

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set INIT msg params \n");

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("SCTP : Successfully set the INIT msg params \n");
    }

    /* Populate the association specific parameters as per configuration */
    {
        struct sctp_assocparams      assocparams;

        memset(&assocparams, 0, sizeof(assocparams));

        assocparams.sasoc_assoc_id    = (sctp_assoc_t)sockFd;
        assocparams.sasoc_asocmaxrxt  = sctp_params->assoc_max_retrans;
        assocparams.sasoc_cookie_life = sctp_params->valid_cookie_life;

        return_value = setsockopt(sockFd,
                                  IPPROTO_SCTP,
                                  SCTP_ASSOCINFO,
                                  &assocparams,
                                  sizeof(struct sctp_assocparams));

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set assoc params with errno = %d, %s\n", 
                    errno, strerror(errno));

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("SCTP: Successfully set the association params \n");
    }

    /* Set the DSCP parameter for connection */
    {
        int tos       = sctp_params->dscp_value << 2;
        return_value = setsockopt(sockFd, IPPROTO_IP, IP_TOS, &tos, sizeof(tos));

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set DSCP parameter with errno = %d, %s\n",
                      errno, strerror(errno));

            close(sockFd);
            return sockFd;
        }

        LOG_TRACE("SCTP: Successfully set the DSCP value \n");
    }

    /* Subscribe for SCTP notifications */
    {
        struct sctp_event_subscribe events;
        memset((void *)&events, 0, sizeof(events));

        /* Populating SCTP Events structure*/
        events.sctp_association_event  = 1;
        events.sctp_data_io_event      = 1;
        events.sctp_address_event      = 1;
        events.sctp_send_failure_event = 1;
        events.sctp_peer_error_event   = 1;
        events.sctp_shutdown_event     = 1;

        if (0 > setsockopt(sockFd, IPPROTO_SCTP, SCTP_EVENTS, &events,
                           sizeof(events)))
        {
            LOG_TRACE(" SCTP : sctp_setsockopt for setting events failed\n");

            close(sockFd);
            return sockFd;
        }
    }

    /* Set SCTP no delay */
    {
        int noDelay = 1;

        if (0 > setsockopt(sockFd, IPPROTO_SCTP, SCTP_NODELAY, &noDelay,
                           sizeof(noDelay)))
        {
            LOG_TRACE("SCTP : sctp_setsockopt  for setting No-Delay failed\n");

            close(sockFd);
            return sockFd;
        }
    }

    /* Store socket FD in peer connection data for further use */
    peer_conn_data->sockFd = sockFd;

    return sockFd;
}


/* This function initiates connection with the peer and register
 * FD with epoll FD for receive notifications. */
sim_return_val_et
du_sim_control_plane_conn_hdlr_connect(void* user_data)
{
    struct sockaddr_in          servaddr[MAX_NUM_IP_ADDR];
    unsigned char               index          = 0;
    peer_conn_data_t*           peer_conn_data = NULL;
    dusim_sctp_comm_info_t*      peer_comm_info = NULL;

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Fetch pointer to peer communication info */
    peer_comm_info  = &peer_conn_data->cu_comm_info;

    for (index = 0; index < peer_comm_info->num_ipv4_addr; index++)
    {
        bzero((void *)&servaddr[index], sizeof(servaddr[index]));

        servaddr[index].sin_family  = AF_INET;
        servaddr[index].sin_port    = htons(peer_comm_info->port);
        servaddr[index].sin_addr.s_addr  = inet_addr((const char*)peer_comm_info->ipv4_addr[index].ip_addr);

        LOG_TRACE("Connecting to port: %d, changed port:%d, IP: %s\n",
                  peer_comm_info->port,
                  servaddr[index].sin_port,
                  (const char*)peer_comm_info->ipv4_addr[index].ip_addr);
    }

    if (0 > sctp_connectx(peer_conn_data->sockFd, (struct sockaddr *)&servaddr, 
                  peer_comm_info->num_ipv4_addr, NULL))
    {
        LOG_TRACE("Failed to connect to the peer, errno:%d \n", errno);
        return SIM_FAILURE;
    }

    LOG_TRACE("Successfully connected with peer, sockFd: %d\n",
              peer_conn_data->sockFd);

    return SIM_SUCCESS;
}


/* This function close the peer connection handler */
void du_sim_control_plane_conn_hdlr_close(void* user_data)
{
    peer_conn_data_t*  peer_conn_data = NULL;

    LOG_TRACE("DU sim peer connection handler close \n");

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Close the socket connection */
    close(peer_conn_data->sockFd);
}


/* This function is used to send the packet to peer */
void du_sim_control_plane_conn_hdlr_send(
        void*          user_data, 
        void*          apiBuf,
        unsigned short apiLen)
{
    peer_conn_data_t*  peer_conn_data = NULL;
    struct iovec       iov[1];
    struct msghdr      msg[1];

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    LOG_TRACE("DU sim peer connection handler send \n");

    /* Set up the msghdr structure for sending */
    memset(msg, 0, sizeof(*msg));

    iov->iov_base   = apiBuf;
    iov->iov_len    = apiLen;
    msg->msg_iov    = iov;
    msg->msg_iovlen = 1;
    msg->msg_flags  = 0;

    /* Send message to the Peer */
    //if (sendmsg(peer_conn_data->sockFd, msg, 0) < 0) 
    if (send(peer_conn_data->sockFd, apiBuf, apiLen, 0) < 0) 
    {
        LOG_TRACE("Failed to send message to peer \n");
        perror("sendmsg");
        return;
    }
}


// Given an event notification, print out what it is.
static void handle_sctp_notification(int sockFd, void *buf)
{
    struct sctp_assoc_change *p_sac = NULL;
    struct sctp_send_failed  *p_ssf = NULL;
    struct sctp_paddr_change *p_spc = NULL;
    struct sctp_remote_error *p_sre = NULL;
    union  sctp_notification *p_snp = NULL;
    char   inet_addr[INET6_ADDRSTRLEN] = {0};
    const char          *p_conn_hdl = NULL;
    struct sockaddr_in  *p_sin = NULL;
    struct sockaddr_in6 *p_sin6 = NULL;

    p_snp = buf;

    switch (p_snp->sn_header.sn_type) 
    {
        case SCTP_ASSOC_CHANGE:
        {
            p_sac = &p_snp->sn_assoc_change;
            LOG_TRACE("assoc change: state=%u, err=%u, instream=%u "
                "outstream=%u\n", p_sac->sac_state, p_sac->sac_error,
                p_sac->sac_inbound_streams, p_sac->sac_outbound_streams);
            break;
        }

        case SCTP_SEND_FAILED:
        {
            p_ssf = &p_snp->sn_send_failed;
            LOG_TRACE("send failed: length=%u err=%d\n", p_ssf->ssf_length,
                p_ssf->ssf_error);

            /* Close socket FD */
            close(sockFd);

            break;
        }

        case SCTP_PEER_ADDR_CHANGE:
        {
            p_spc = &p_snp->sn_paddr_change;
            if (p_spc->spc_aaddr.ss_family == AF_INET) {
                p_sin = (struct sockaddr_in *)&p_spc->spc_aaddr;
                p_conn_hdl = (const char *)inet_ntop(AF_INET, &p_sin->sin_addr, inet_addr,
                    INET6_ADDRSTRLEN);
            } else {
                p_sin6 = (struct sockaddr_in6 *)&p_spc->spc_aaddr;
                p_conn_hdl = (const char *)inet_ntop(AF_INET6, &p_sin6->sin6_addr, inet_addr,
                    INET6_ADDRSTRLEN);
            }
            LOG_TRACE("interface change: %s state=%d, error=%d\n", p_conn_hdl,
                p_spc->spc_state, p_spc->spc_error);
            break;
        }

        case SCTP_REMOTE_ERROR:
        {
            p_sre = &p_snp->sn_remote_error;
            LOG_TRACE("remote error: err=%u length=%u\n",
                ntohs(p_sre->sre_error), ntohs(p_sre->sre_length));
            break;
        }

        case SCTP_SHUTDOWN_EVENT:
        {
            LOG_TRACE("shutdown received\n");

            /* Close socket connection */
            close(sockFd);

            break;
        }

        default:
        {
            LOG_TRACE("unknown event: %u\n", p_snp->sn_header.sn_type);
            break;
        }
    }
}

// Receive a message from the network.
static void *
read_msg(int fd, struct msghdr *msg, void *buf, size_t *buflen,
       ssize_t *nrp, size_t cmsglen)
{
    ssize_t  nr = 0;
    struct iovec iov[1];

    *nrp = 0;
    iov->iov_base = buf;
    msg->msg_iov = iov;
    msg->msg_iovlen = 1;

    /* Loop until a whole message is received. */
    for (;;) {
        msg->msg_flags = 0;
        msg->msg_iov->iov_len = *buflen;
        msg->msg_controllen = cmsglen;

        nr += recvmsg(fd, msg, 0);
        if (nr <= 0) 
        {
            /* Close connection, if peer has closed the
             * connection. */
            if (errno == ECONNRESET)
            {
                LOG_TRACE("Peer has closed the connection \n");
                close(fd);
            }

            perror("recvmsg failed");

            /* EOF or error */
            *nrp = nr;
            return (NULL);
        }

        /* Whole message is received, return it. */
        if (msg->msg_flags & MSG_EOR) {
            *nrp = nr;
            return (buf);
        }

        /* Maybe we need a bigger buffer, do realloc(). */
        if (*buflen == nr) {
            buf = realloc(buf, *buflen * 2);
            if (buf == 0) {
                LOG_TRACE("out of memory, realloc failed\n");
                exit(1);
            }
            *buflen *= 2;
        }

        /* Set the next read offset */
        iov->iov_base = (char *)buf + nr;
        iov->iov_len = *buflen - nr;
    }
}


/* This function is used to receive packet from peer */
unsigned int 
du_sim_control_plane_conn_hdlr_receive(
        void*  user_data,
        void** recvBuf)
{
    peer_conn_data_t*       peer_conn_data = NULL;
    ssize_t                 msgLen         = 0;
    size_t                  buflen         = 0;
    size_t                  cmsglen        = 0;
    struct sctp_sndrcvinfo* sri            = NULL;
    struct msghdr           msg[1];
    struct cmsghdr*         cmsg;
    char                    cbuf[sizeof (*cmsg) + sizeof (*sri)];
    void*                   retBuf         = NULL;

    /* Calculate cmsglen */
    cmsglen = sizeof (*cmsg) + sizeof (*sri);

    /* Get peer connection data */
    peer_conn_data = (peer_conn_data_t*)user_data;

    /* Allocate memory for data buffer */
    buflen = 8192;

    if ((*recvBuf = malloc(buflen)) == NULL) 
    {
        LOG_TRACE("out of memory, malloc failed for msg data buffer.\n");
        return msgLen;
    }

    /* Set up the msghdr structure for receiving */
    memset(msg, 0, sizeof(*msg));
    msg->msg_control    = cbuf;
    msg->msg_controllen = cmsglen;
    msg->msg_flags      = 0;
    cmsg = (struct cmsghdr *)cbuf;
    sri  = (struct sctp_sndrcvinfo *)(cmsg + 1);

    LOG_TRACE("Receiving message on socket FD: %d\n",
              peer_conn_data->sockFd);

    /* Wait for something to echo */
    retBuf = read_msg(peer_conn_data->sockFd, msg, *recvBuf, 
                      &buflen, &msgLen, cmsglen);

    //if (*recvBuf != NULL)
    if (retBuf != NULL)
    {
        if (msgLen < 0) 
        {
            perror("recvmsg");
        }

        /* Process SCTP notifications */
        if (msg->msg_flags & MSG_NOTIFICATION) 
        {
            handle_sctp_notification(peer_conn_data->sockFd,
                                     *recvBuf);
            free(*recvBuf);
            *recvBuf = NULL;

            return msgLen;
        }
    }
    else
    {
        free(*recvBuf);
        *recvBuf = NULL;
    }
    //LOG_TRACE("DU sim peer connection handler receive \n");
    return msgLen;
}


/* Create control plane peer connection handler for eNB */
peer_conn_hdlr_t*
dusim_create_control_plane_peer_conn_hdlr(
        dusim_sctp_comm_info_t* local_comm_info,
        dusim_sctp_comm_info_t* peer_comm_info)
{
    peer_conn_hdlr_t*  peer_conn_hdlr = NULL;
    peer_conn_data_t*  conn_hdlr_data = NULL;

    /* Allocate peer connection handler */
    peer_conn_hdlr = allocate_new_peer_conn_hdlr();
    if (NULL == peer_conn_hdlr)
    {
        LOG_TRACE("Failed to create peer connection hdlr for DU sim\n");
        return peer_conn_hdlr;
    }

    memset(peer_conn_hdlr, 0, sizeof(peer_conn_hdlr_t));

    /* Initializes the function pointers of peer connection handler */
    peer_conn_hdlr->init    = du_sim_control_plane_conn_hdlr_init;
    peer_conn_hdlr->open    = du_sim_control_plane_conn_hdlr_open;
    peer_conn_hdlr->connect = du_sim_control_plane_conn_hdlr_connect;
    peer_conn_hdlr->close   = du_sim_control_plane_conn_hdlr_close;
    peer_conn_hdlr->send    = du_sim_control_plane_conn_hdlr_send;
    peer_conn_hdlr->receive = du_sim_control_plane_conn_hdlr_receive;

    /* Store connection data in user data of peer connection handler */
    {
        /* Allocate memory for peer connection data */
        conn_hdlr_data = (peer_conn_data_t*)malloc(
                                     sizeof(peer_conn_data_t));
        if (NULL == conn_hdlr_data)
        {
            LOG_TRACE("Failed to allocate memory for peer connection data \n");
            return peer_conn_hdlr;
        }

        /* Reset memory allocated for peer connection data */
        memset(conn_hdlr_data, 0, sizeof(peer_conn_data_t));

        /* Copy local communication info */
        memcpy(&conn_hdlr_data->du_comm_info,
               local_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        /* Copy peer communication info */
        memcpy(&conn_hdlr_data->cu_comm_info,
               peer_comm_info,
               sizeof(dusim_sctp_comm_info_t));

        /* Store connection data in peer connection handler */
        peer_conn_hdlr->user_data = conn_hdlr_data;
    }

    return peer_conn_hdlr;
}

