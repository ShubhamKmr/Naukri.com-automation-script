/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "proto_peer_conn_mgr.h"
#include "sim_defs.h"
#include "du_sim_event.h"
#include "duConnMgr.h"
#include "peer_conn_hdlr.h"
#include "globalContext.h"
#include "du_sim_common.h"
#include "dusim_cmd_defs.h"


/* This function will forward the message to stack application */
void dusim_forward_msg_to_stack_app(
        void*         msgBuf,
        unsigned int  msgLen)
{
    proto_simulator_t* du_sim    = NULL;
    stack_app_t*       stack_app = NULL;

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);
    unsigned short  api_id = ((du_sim_event_t *)msgBuf)->header.apiId;
    /* Fetch peer connection handler */
    stack_app = get_proto_stack_app(du_sim);
    if (NULL == stack_app)
    {
        LOG_TRACE("Failed to fetch DU SIM stack app\n");
        return;
    }

    /* Invoke the send callback registered by 
     * peer connection handler. */
    if(api_id == DUSIM_CONFIGURE_DU_RESP)  //SCTP Changes
    {
      stack_app->stack_msg_hdlr(msgBuf, msgLen);
    }
    else
    {
      stack_app->stack_msg_hdlr(msgBuf, msgLen);
    }

    //LOG_TRACE("Successfully forwarded msg from conn Mgr to stack app, len:%d \n", msgLen);
}


/* This function will build and send SCTP link status 
 * indication to upper layer */
void build_and_send_link_status_ind(
            unsigned short          du_id, 
            f1_sctp_link_status_et  status)
{
    du_sim_event_t  p_api;
    dusim_sctp_link_status_ind_t*                   link_status_ind;
    unsigned int                              apiLen = 0;
    unsigned int                              msgLen = 0;

    /* Calculate message buffer length */
    msgLen = sizeof(dusim_sctp_link_status_ind_t);

    /* Calculate API length */
    apiLen = sizeof(du_sim_event_hdr_t)  
               + msgLen;

    /* Populate header attributes */
    p_api.header.apiId  = DUSIM_SCTP_LINK_STATUS_IND;
    p_api.header.length = apiLen;
    p_api.header.du_id = du_id;

    /* Allocate memory for API body */
    p_api.msgBuf = (unsigned char*)malloc(msgLen);

    if (NULL == p_api.msgBuf)
    {
        LOG_TRACE("Failed to allocate memory\n");
        return;
    }

    /* Get pointer to sctp_link_status_ind */
    link_status_ind = (dusim_sctp_link_status_ind_t*)p_api.msgBuf;

    /* Populate link status */
    link_status_ind->link_status = status;

    /* Forward API to stack app */
    dusim_forward_msg_to_stack_app(&p_api, apiLen);
}


/* This function handled peer connection reset request received
 * from stack app and close connection with that peer */
void handle_du_peer_conn_reset_req(unsigned short du_id)
{
    dusim_du_conn_data_t* p_du_conn_data = NULL;
    peer_conn_hdlr_t*      p_conn_hdlr   = NULL;
    unsigned short         index           = 0;

    /* Traverse through the list of all ENBs connection data
     * and activate the connection handler of eNB whose ID
     * is passed by caller. */
    for (index = 0; index < MAX_SUPPORTED_DU; index++)
    {
        /* Fetch pointer to eNB connection data */
        p_du_conn_data = &gDUSimConnMgrContext.du_conn_data[index];

        if ((p_du_conn_data->used) &&
            (p_du_conn_data->du_id == du_id))
        {
            /* Fetch pointer to peer connection handler */
            p_conn_hdlr   = p_du_conn_data->peer_conn_hdlr.conn_hdlr;

            LOG_TRACE("Calling close on socket for eNB: %d\n", du_id);

            /* Invoke close function of connection handler */
            p_conn_hdlr->close(p_conn_hdlr->user_data);
        }
    }
}


/* This function handles control PDU request received from upper
 * layer */
void handle_du_peer_control_pdu_req(unsigned short du_id, 
                                 unsigned char* p_api,
                                 unsigned int   apiLen)
{

    LOG_TRACE("Calling Send for DUSIM: %d\n", du_id);
    dusim_du_conn_data_t* du_conn_data = NULL;
    peer_conn_hdlr_t*      p_conn_hdlr   = NULL;

    /* Fetch eNB connection data for this enb ID received */
    du_conn_data = &gDUSimConnMgrContext.du_conn_data[du_id]; 

    /* Fetch pointer to peer connection handler */
    p_conn_hdlr   = du_conn_data->peer_conn_hdlr.conn_hdlr;

    /* Invoke send function of connection handler */
    p_conn_hdlr->send(p_conn_hdlr->user_data, p_api, apiLen); 
}


/* This function handles connection initiation request
 * received from upper layer. */
void handle_du_peer_conn_initiation_req(
        unsigned char du_id)
{
    dusim_du_conn_data_t* p_du_conn_data = NULL;
    peer_conn_hdlr_t*      conn_hdlr       = NULL;
    unsigned short         index           = 0;
    f1_sctp_link_status_et status          = F1AP_LINK_STATUS_DOWN;

    /* Traverse through the list of all ENBs connection data
     * and activate the connection handler of eNB whose ID
     * is passed by caller. */
    for (index = 0; index < MAX_SUPPORTED_DU_SCTP; index++)
    {
        /* Fetch pointer to eNB connection data */
        p_du_conn_data = &gDUSimConnMgrContext.du_conn_data[index];

        if ((p_du_conn_data->used) &&
            (p_du_conn_data->du_id == du_id) &&
            (p_du_conn_data->peer_conn_hdlr.isActivated))
        {
            conn_hdlr = p_du_conn_data->peer_conn_hdlr.conn_hdlr;

            if (NULL == conn_hdlr)
            {
                LOG_TRACE("Peer connection handler doesn't exists for du ID: %d\n",
                          du_id);
                break;
            }

            /* Call connect of the connection handler */
            else if (SIM_FAILURE == conn_hdlr->connect(conn_hdlr->user_data))
            {
                LOG_TRACE("Failed to connect with server, du ID: %d\n",
                          du_id);
                break;
            }
            
            else
            {
                LOG_TRACE("Successfully connected with peer eNB, du ID: %d \n",
                         du_id);

                /* Set the link status to UP */
                status = F1AP_LINK_STATUS_UP;

                break;
            }
        }
    }

    build_and_send_link_status_ind(du_id, status);
}


/* This function builds and sends ENB Addition Reponse */
void build_and_send_du_addition_resp(
            unsigned short          du_id,
            dusim_response_code_et  response)
{
    du_sim_event_t  p_api;
    dusim_configure_du_resp_t*                     config_du_resp;
    unsigned int                              apiLen = 0;
    unsigned int                              msgLen = 0;

    /* Calculate message buffer length */
    msgLen = sizeof(dusim_configure_du_resp_t);

    /* Calculate API length */
    apiLen = sizeof(du_sim_event_hdr_t)  
               + msgLen;

    /* Populate header attributes */
    p_api.header.apiId  = DUSIM_CONFIGURE_DU_RESP;
    p_api.header.length = apiLen;
    p_api.header.du_id = du_id;

    /* Allocate memory for API body */
    p_api.msgBuf = (unsigned char*)malloc(msgLen);

    if (NULL == p_api.msgBuf)
    {
        LOG_TRACE("Failed to allocate memory\n");
        return;
    }

    /* Get pointer to dusim_configure_du_resp_t */
    config_du_resp = (dusim_configure_du_resp_t*)p_api.msgBuf;

    /* Populate du_id */
    config_du_resp->du_id = du_id;

    /* Populate response */
    config_du_resp->response_code = response;

    /* Forward API to stack app */
    dusim_forward_msg_to_stack_app(&p_api, apiLen);
}


/* This function process received SENB Addition Request 
 * from upper layer. */
sim_return_val_et
handle_du_addition_req(
        unsigned char  du_id,
        unsigned char* msgBuf)
{
    dusim_configure_du_req_t*  add_du_req     = NULL;
    dusim_sctp_comm_info_t*    du_comm_info    = NULL;
    dusim_sctp_comm_info_t*    cu_comm_info    = NULL;
    peer_conn_hdlr_t*          peer_conn_hdlr  = NULL;
    sim_return_val_et          retVal          = SIM_FAILURE;

    /* Get pointer to DU Addition Request */
    add_du_req   = (dusim_configure_du_req_t*)msgBuf;

    /* Fetch pointer to DU communication info container */
    du_comm_info = &add_du_req->du_comm_info;

    /* Fetch pointer to CU communication info container */
    cu_comm_info = &add_du_req->cu_comm_info;

   if(du_comm_info->bitmask & DU_COMM_INFO_SCTP_CONFIG_PARAM_PRESENT)
   {
        LOG_TRACE("DU SCTP \n");
    /* Create control plane connection handler for DU */
    if (NULL == (peer_conn_hdlr = dusim_create_control_plane_peer_conn_hdlr(
                                      du_comm_info, 
                                      cu_comm_info)))
    {
        LOG_TRACE("Failed to create peer connection handler for"
                  "new DU Addition Request \n");
    }

    /* Register connection handler with DU SIM peer connection 
     * manager. */
    else if (SIM_FAILURE == register_peer_conn_hdlr_with_peer_conn_mgr(
                                        DUSIM_ID,
                                        peer_conn_hdlr))
    {
        LOG_TRACE("Failed to register peer connection handler with"
                   "peer connection manager \n");
    }

    else
    {
        unsigned int           index          = 0;
        dusim_du_conn_data_t*  p_du_conn_data = NULL;

        /* Store peer connection data in connection manager */
        for (index = 0; index < MAX_SUPPORTED_DU_SCTP; index++)
        {
            p_du_conn_data = &gDUSimConnMgrContext.du_conn_data[index];

            if (!p_du_conn_data->used)
            {
                p_du_conn_data->used   = 1;
                p_du_conn_data->du_id = du_id; 
                p_du_conn_data->peer_conn_hdlr.conn_hdlr 
                                        = peer_conn_hdlr; 

                LOG_TRACE("Peer CU successfully added through SCTP connection\n");
                retVal = SIM_SUCCESS;
                break;
            }
        }
    }
  }
  else if(du_comm_info->bitmask & DU_COMM_INFO_UDP_CONFIG_PARAM_PRESENT)
  {
        LOG_TRACE("DU UDP \n");
    /* Create control plane connection handler for eNB */
    if (NULL == (peer_conn_hdlr = dusim_create_control_plane_peer_conn_hdlr_udp(
                                      du_comm_info, 
                                      cu_comm_info)))
    {
        LOG_TRACE("Failed to create UDP peer connection handler for"
                  "new DU Addition Request \n");
    }

    /* Register connection handler with DU SIM peer connection 
     * manager. */
    else if (SIM_FAILURE == register_peer_conn_hdlr_with_peer_conn_mgr(
                                        DUSIM_ID,
                                        peer_conn_hdlr))
    {
        LOG_TRACE("Failed to register peer connection handler with"
                   "peer connection manager \n");
    }
    else
    {
        unsigned int           index          = 0;
        dusim_du_conn_data_t*  p_du_conn_data = NULL;

        /* Store peer connection data in connection manager */
        for (index = 0; index < MAX_SUPPORTED_DU_SCTP; index++)
        {
            p_du_conn_data = &gDUSimConnMgrContext.du_conn_data[index];

            if (!p_du_conn_data->used)
            {
                p_du_conn_data->used   = 1;
                p_du_conn_data->du_id = du_id; 
                p_du_conn_data->peer_conn_hdlr.conn_hdlr 
                                        = peer_conn_hdlr; 

                LOG_TRACE("Peer CU successfully added through UDP connection\n");
                retVal = SIM_SUCCESS;
                break;
            }
        }
    }
  }


    /* Build and send SeNB Addition Response based on return value */
    if (SIM_SUCCESS == retVal)
    {
        build_and_send_du_addition_resp(du_id, DU_SUCCESS_RESP);
    }
    else
    {
        /* TODO: In case of failure, need to free the connection 
         * handler. */
        build_and_send_du_addition_resp(du_id, DU_FAILURE_RESP);
    }

    return retVal;
}


/* This function receives new messages received from 
 * internal modules */
void dusim_internal_msg_hdlr(
        void*        msgBuf, 
        unsigned int msgLen)
{
    du_sim_event_t* p_api  = NULL;
    unsigned char   du_id  = 0;
    unsigned short  api_id = 0;
    unsigned int    apiLen = 0;

    /* Ensure that received pointer is valid */
    if (NULL == msgBuf)
    {
        LOG_TRACE("Received invalid message buffer \n");
        return;
    }

    /* Get pointer to the received API buffer */
    p_api = (du_sim_event_t*)msgBuf;

    /* Fetch API ID */
    api_id = p_api->header.apiId;

    /* Fetch eNB ID */
    du_id = p_api->header.du_id;

    /* Calculate API length */
    apiLen = p_api->header.length - sizeof(du_sim_event_hdr_t);

    switch(api_id)
    {
        case DU_ADDITION_REQ:
        {
            LOG_TRACE("DU Addition Request received, du_id: %d\n", 
                       du_id);

            handle_du_addition_req(du_id, p_api->msgBuf);

            /* Free memory of message buffer */
            free(p_api->msgBuf);

            break;
        }

        case DUSIM_CONN_INITIATION_REQ:
        {
            LOG_TRACE("Connection Initiation Request received for du_id: %d\n",
                      du_id);

            handle_du_peer_conn_initiation_req(du_id);
            break;
        }

        case DU_PEER_CONN_RESET_REQ:
        {
            LOG_TRACE("Connection Reset Request received for du_id: %d\n",
                      du_id);

            handle_du_peer_conn_reset_req(du_id);
            break;
        }

        case DU_PEER_CONTROL_PDU_REQ:
        {
            LOG_TRACE("Control PDU receved from upper layer for DU ID: %d \n",
                      du_id);

            handle_du_peer_control_pdu_req(du_id, p_api->msgBuf, apiLen);

            /* Free memory of message buffer */
            //free(p_api->msgBuf);
            break;
        }

        default:
        {
            LOG_TRACE("Unknown internal API received: %d\n", api_id);
            break;
        }
    }
}


/* Process received message from peer eNB */
void process_peer_du_control_msg(
        unsigned char* msgBuf, 
        unsigned int   msgLen,
        unsigned short du_id)
{
    du_sim_event_t  p_api;
    unsigned int    apiLen = 0;

    /* Calculate API length */
    apiLen = msgLen + sizeof(du_sim_event_hdr_t);

    /* Populate header attributes */
    p_api.header.apiId  = DU_PEER_CONTROL_PDU_IND;
    p_api.header.length = apiLen;
    p_api.header.du_id = du_id;

    /* Allocate memory for API body */
    p_api.msgBuf = (unsigned char*)malloc(msgLen);

    if (NULL == p_api.msgBuf)
    {
        LOG_TRACE("Failed to allocate memory\n");
        return;
    }

    memcpy(p_api.msgBuf, msgBuf, msgLen);

    /* Forward API to stack app */
    dusim_forward_msg_to_stack_app(&p_api, apiLen);

    /* Free memory buffer */
    free(msgBuf);
}


/* This function receives new messages received from 
 * peer and process them. */
void dusim_conn_mgr_peer_msg_hdlr(
        void* peer_conn_data)
{
    dusim_du_conn_data_t*  du_conn_data  = NULL;
    peer_conn_hdlr_t*       conn_hdlr      = NULL;
    unsigned char*          msgBuf         = NULL;
    unsigned int            msgLen         = 0;

    /* Get peer connection handler from received pointer */
    du_conn_data = (dusim_du_conn_data_t*)peer_conn_data;

    /* Fetch connection handler */
    conn_hdlr = du_conn_data->peer_conn_hdlr.conn_hdlr;

    /* Call receive API to read message from socket */
    msgLen = conn_hdlr->receive(conn_hdlr->user_data, 
                                (void*)&msgBuf);
   
    if ((msgLen == 0) || (msgBuf == NULL))
    {
        LOG_TRACE("Invalid message received, msgLen: %d, msgBuf: %p\n", 
                  msgLen, msgBuf);
        return;
    }

    LOG_TRACE("Message received from peer, du ID: %d\n", 
              du_conn_data->du_id);

    /* Process received message from peer eNB */
    process_peer_du_control_msg(
                        msgBuf, 
                        msgLen, 
                        du_conn_data->du_id);
}


/* This function activates the pending connection handlers */
void dusim_conn_mgr_activate(void* pData)
{
    dusim_conn_mgr_context_t* gContext      = pData;
    dusim_du_conn_data_t*    du_conn_data = NULL;
    peer_conn_hdlr_t*         conn_hdlr     = NULL;
    unsigned short            index         = 0;
    int                       sockFd        = -1;

    /* Traverse through the list of all registered eNBs and activate 
     * their peer connection handler. */
    for (index = 0; index < MAX_SUPPORTED_DU; index++)
    {
        /* Fetch pointer to eNB connection data */
        du_conn_data = &gContext->du_conn_data[index];

        if (du_conn_data->used)
        {
            /* Activate peer connection client */
            if (!du_conn_data->peer_conn_hdlr.isActivated)
            {
                conn_hdlr = du_conn_data->peer_conn_hdlr.conn_hdlr;

                /* Store peer connection data in connection manager */
                gDUSimConnMgrContext.du_conn_data[index].
                    peer_conn_hdlr.conn_hdlr = conn_hdlr;

                LOG_TRACE("Peer conn handler for CU is stored in global context \n");

                if (NULL != conn_hdlr)
                {
                    /* Call open of the connection handler */
                    sockFd = conn_hdlr->open(conn_hdlr->user_data);

                    if (0 > sockFd)
                    {
                        LOG_TRACE("Failed to open connection handler for eNB: %d\n",
                                  du_conn_data->du_id);
                    }

                    /* Register socket FD with epoll FD for receive notifications */
                    else if (SIM_FAILURE == register_peer_conn_fd_for_receive_notifications(
                                                        DUSIM_ID,
                                                        sockFd,
                                                        PEER_CONNECTION_HDLR,
                                                        du_conn_data))
                    {
                        LOG_TRACE("Failed to register socket FD of client with"
                                  " epoll FD \n");

                        /* Close the connection */
                        conn_hdlr->close(conn_hdlr->user_data);
                    }

                    else
                    {
                        LOG_TRACE("Successfully open connection handler for du ID:%d\n", 
                                  du_conn_data->du_id);

                        /* Set the flag to indicate that this handler is activated */
                        du_conn_data->peer_conn_hdlr.isActivated = 1;
                    }
                }
            }
        }
    }
}


/* This function initializes the peer connection mgr */
sim_return_val_et 
dusim_peer_conn_mgr_init(void* data)
{
    LOG_TRACE("DU sim peer connection manager init \n");

    return SIM_SUCCESS;
}


/* Create DU SIM peer connection manager */
peer_conn_mgr_t*
create_du_sim_peer_conn_mgr()
{
    peer_conn_mgr_t*  peer_conn_mgr = NULL;

    /* Allocate peer connection manager */
    peer_conn_mgr = allocate_new_peer_conn_mgr();
    if (NULL == peer_conn_mgr)
    {
        LOG_TRACE("Failed to create peer connection mgr for DU sim\n");
        return peer_conn_mgr;
    }

    memset(peer_conn_mgr, 0, sizeof(peer_conn_mgr_t));

    /* Initializes the callbacks of peer connection mgr */
    peer_conn_mgr->init              = dusim_peer_conn_mgr_init;
    peer_conn_mgr->connect_req_hdlr  = NULL;
    peer_conn_mgr->peer_msg_hdlr     = dusim_conn_mgr_peer_msg_hdlr;
    peer_conn_mgr->internal_msg_hdlr = dusim_internal_msg_hdlr;
    peer_conn_mgr->activate          = dusim_conn_mgr_activate;
    peer_conn_mgr->user_data         = (void*)&gDUSimConnMgrContext; 

    return peer_conn_mgr;
}

