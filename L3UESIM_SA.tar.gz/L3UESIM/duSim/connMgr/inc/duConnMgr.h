#include "connection_listener.h"
#include "du_sim_common.h"
#define MAX_SUPPORTED_DU  5

/* APIs exposed by peer connection manager */
typedef enum
{
    DU_ADDITION_REQ = 1,
    DU_ADDITION_RESP,
    DU_PEER_CONN_INITIATION_REQ,
    DU_PEER_CONTROL_PDU_IND,
    DU_PEER_CONTROL_PDU_REQ,
    DU_PEER_CONN_RESET_REQ
} dusim_conn_mgr_api_et;


/* Structure defining the content of API used for 
 * delivering the control plane message received
 * from CU to upper layers. */
typedef struct
{
    /* Message buffer */
    unsigned char   msgBuf[1];

} dusim_du_control_pdu_ind_t;


/* Structure defining the content of API used for 
 * delivering the control plane message from upper
 * layers to CU */
typedef struct
{
    /* Message buffer */
    unsigned char   msgBuf[1];

} dusim_du_control_pdu_req_t;


/* Structure defining the content of API used for adding 
 * a new DU at DUSIM which will be used for testing a CU. */
typedef struct
{
    /* SCTP Communication information of DU */
    dusim_sctp_comm_info_t      du_comm_info;

    /* SCTP Communication information of CU */
    dusim_sctp_comm_info_t      cu_comm_info;

    /* Flag to indicate whether explicit start is required
     * or not. */
    unsigned char               explicit_start_required;

} du_addition_req_t;  /* DU_ADDITION_REQ */


/* Structure defining the content of API used for sending 
 * the response of DU ADDITION REQ. */
typedef struct
{
    /* Indicates the result of DU addition Request */
    unsigned char   response_code;

} du_addition_resp_t;  /* DU_ADDITION_RESP */


/* Structure defining the content of peer connection handler */
typedef struct
{
    /* Flag to indicate if this conneciton handler is 
     * already activated */
    unsigned char     isActivated;

    /* Pointer to peer connection handler */
    peer_conn_hdlr_t* conn_hdlr;

} dusim_peer_conn_hdlr_data_t;


/* Structure defining the content of connection data for a 
 * particular DU configured at DU simulator. */
typedef struct
{
    /* Flag to indicate whether this entry is in use or not */
    unsigned char                   used;

    /* Unique DU Identifier */ 
    unsigned char                   du_id;

    /* Array of peer connection handlers */
    dusim_peer_conn_hdlr_data_t     peer_conn_hdlr;

} dusim_du_conn_data_t;


/* Structure used for storing the information used for
 * operation of connection manager. */
typedef struct
{
    /* Map of DU IDs and their connections data */
    dusim_du_conn_data_t     du_conn_data[MAX_SUPPORTED_DU];

} dusim_conn_mgr_context_t;


/* Object of DU SIM connection manager */
dusim_conn_mgr_context_t  gDUSimConnMgrContext;


/* This function creates and return peer connection manager */
peer_conn_mgr_t* create_du_sim_peer_conn_mgr();


