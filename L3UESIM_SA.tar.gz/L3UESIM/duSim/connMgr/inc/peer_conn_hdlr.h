#ifndef __DUSIM_PEER_CONN_HDLR_H__
#define __DUSIM_PEER_CONN_HDLR_H__

#include "du_sim_common.h"
#include "proto_peer_conn_hdlr.h"
#include "connection_listener.h"

/* Structure defining the content of peer connection 
 * handler configuration data */
typedef struct
{
    /* Socket FD */
    unsigned int                sockFd;

    /* SCTP Communication information of DU */
    dusim_sctp_comm_info_t      du_comm_info;

    /* SCTP Communication information of CU */
    dusim_sctp_comm_info_t      cu_comm_info;

} peer_conn_data_t;


/* Create control plane peer connection handler for DU */
peer_conn_hdlr_t*
dusim_create_control_plane_peer_conn_hdlr(
        dusim_sctp_comm_info_t* du_comm_info,
        dusim_sctp_comm_info_t* cu_comm_info);

peer_conn_hdlr_t*
dusim_create_control_plane_peer_conn_hdlr_udp(
        dusim_sctp_comm_info_t* local_comm_info,
        dusim_sctp_comm_info_t* peer_comm_info);


#endif  // __DUSIM_PEER_CONN_HDLR_H__
