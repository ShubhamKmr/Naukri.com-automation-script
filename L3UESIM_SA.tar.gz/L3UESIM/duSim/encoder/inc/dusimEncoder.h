#ifndef _DUSIM_ENCODER_H_
#define _DUSIM_ENCODER_H_

#include "proto_enc_dec.h"

#define F1AP_MAX_ASN1_BUF_LEN   8192


/* This function creates and return encoder for DU sim */
encoder_t* create_du_sim_encoder();


/* Function exposed by DU sim for encoding messages */
unsigned char du_sim_encode(
    unsigned short  apiId,
    /* spr 24900 changes start */
    unsigned char*  apiBuf,
   /* spr 24900 changes end */
    unsigned int    apiBufLen,
    unsigned char** p_p_encodedmsg,
    unsigned long*  p_encodedmsg_len);

/* This function encodes gNB CU Configuration update Request */
sim_return_val_et
dusim_handle_encode_cu_config_update_req(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes gNB CU Configuration update Response */
sim_return_val_et
dusim_handle_encode_cu_config_update_ack(
/* spr 24900 changes start */
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);



/* This function encodes gNB CU Configuration update Failure */
sim_return_val_et
dusim_handle_encode_cu_config_update_failure(
/* spr 24900 changes start */
       unsigned char*    apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes gNB DU Configuration update Request */
sim_return_val_et
dusim_handle_encode_du_config_update_req(
/* spr 24900 changes start */
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes gNB DU Configuration update Response */
sim_return_val_et
dusim_handle_encode_du_config_update_ack(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes gNB DU Configuration update Failure */
sim_return_val_et
dusim_handle_encode_du_config_update_failure(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes Error Indication */
sim_return_val_et
dusim_handle_encode_error_indication(
/* spr 24900 changes start */
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes F1 Setup Request */
sim_return_val_et
dusim_handle_encode_f1_setup_req(
/* spr 24900 changes start */
        unsigned  char*    apiBuf,
/* spr 24900 changes end */
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes F1 Setup Response */
sim_return_val_et
dusim_handle_encode_f1_setup_resp(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes F1 Setup Failure */
sim_return_val_et
dusim_handle_encode_f1_setup_failure(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes Reset Request */
sim_return_val_et
dusim_handle_encode_reset_request(
/* spr 24900 changes start */
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes Reset Ack */
sim_return_val_et
dusim_handle_encode_reset_ack(
       /* spr 24900 changes start */
        unsigned char*   apiBuf,
      /* spr 24900 changes end */
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes DL RRC Message Transfer */
sim_return_val_et
dusim_handle_encode_dl_rrc_msg_transfer(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes UL RRC Message Transfer */
sim_return_val_et
dusim_handle_encode_ul_rrc_msg_transfer(
/* spr 24900 changes start */
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes UE Context Modification Request */
sim_return_val_et
dusim_handle_encode_ue_context_modification_request(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes UE Context Release Command */
sim_return_val_et
dusim_handle_encode_ue_context_release_command(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);


/* This function encodes UE Context Release Complete */
sim_return_val_et
dusim_handle_encode_ue_context_release_complete(
/* spr 24900 changes start */
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);

/*This function encodes UE Context Rel Req*/

sim_return_val_et 
dusim_handle_encode_ue_context_release_request(
/* spr 24900 changes start */
              unsigned  char*   apiBuf,
/* spr 24900 changes end */              
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len
);


/* This function encodes UE Context Setup Request */
sim_return_val_et
dusim_handle_encode_ue_context_setup_request(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);



/* This function encodes UE Context Setup Failure */
sim_return_val_et
dusim_handle_encode_ue_context_setup_failure(
/* spr 24900 changes start */
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);



/* This function encodes UE Context setup Response */
sim_return_val_et
dusim_handle_encode_ue_context_setup_response(
/* spr 24900 changes start */
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);
sim_return_val_et
dusim_handle_encode_ue_context_modification_response(
/* spr 24900 changes start */
        unsigned char*   apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len);

/* Function prototype of Ue Ctxt Mod Failure: Vikash */
sim_return_val_et
dusim_handle_encode_ue_context_mod_failure(
/* spr 24900 changes start */
               unsigned char*    apiBuf,
/* spr 24900 changes end */               
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len);

/* Function Prototype of F1 Init UL RRC Msg Transfer */
sim_return_val_et
dusim_handle_encode_init_ul_rrc_msg_transfer(
/* spr 24900 changes start */
               unsigned char*    apiBuf,
/* spr 24900 changes end */               
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len);

/* Function prototype of UE Context Mod Required */
sim_return_val_et
dusim_handle_encode_ue_context_modification_required(
/* spr 24900 changes start */
                unsigned char*  apiBuf,
/* spr 24900 changes end */                
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len);



#endif  // _DUSIM_ENCODER_H_
