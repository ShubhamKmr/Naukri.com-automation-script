/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "f1ap_adpt_intf.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "x2ap_asn_enc_dec_3gpp.h"
#include "rrc_asn_enc_dec_nr.h"
#include "du_sim_common.h"


void fill_rate_match_pattern_release_list
(
    rate_match_pattern_to_release_list_t*               p_src_elem,
    nr_rrc_ServingCellConfigCommon_rateMatchPatternToReleaseList*  p_trg_elem
)
{
    UInt8   index = F1AP_NULL;

    p_trg_elem->n = p_src_elem->count;

    for (index = 0; index < p_src_elem->count; index++)
    {
        p_trg_elem->elem[index] = p_src_elem->rateMatchPatternId[index];
    }
}


sim_return_val_et fill_rate_match_pattern_add_mod_list
(
   rate_match_pattern_to_add_mod_t*     p_src_rmp_add_mod,
   nr_rrc_RateMatchPattern*             p_trg_rmp_add_mod,
   OSCTXT*                              p_asn1_ctx
)
{
    /* Rate match pattern ID */
    {
        p_trg_rmp_add_mod->rateMatchPatternId = 
            p_src_rmp_add_mod->rateMatchPatternId;
    }

    /* Pattern Type */
    /*
    if (SIM_FAILURE == fill_pattern_type_info(
                                &p_src_rmp_add_mod->patternType,
                                &p_trg_rmp_add_mod->patternType,
                                p_asn1_ctx))
    {
        return SIM_FAILURE;
    }
    */
    /* Sub carrier Spacing */
    if (RMP_TO_ADD_MOD_SCS_PRESENT & 
               p_src_rmp_add_mod->bitmask)
    {
        p_trg_rmp_add_mod->m.subcarrierSpacingPresent = 1;

        p_trg_rmp_add_mod->subcarrierSpacing = 
                p_src_rmp_add_mod->subcarrierSpacing;
    }

    /* Mode */
    p_trg_rmp_add_mod->dummy = p_src_rmp_add_mod->mode;

    return SIM_SUCCESS;
}

void fill_crs_to_match_around_info
(
    rate_match_pattern_lte_crs_t*   p_src_crs_elem,
    nr_rrc_RateMatchPatternLTE_CRS* p_trg_crs_elem
)
{
    asn1Init_nr_rrc_RateMatchPatternLTE_CRS(p_trg_crs_elem);

    p_trg_crs_elem->carrierFreqDL = p_src_crs_elem->carrierFreqDL;

    p_trg_crs_elem->carrierBandwidthDL = 
        p_src_crs_elem->carrierBandwidthDL;

    p_trg_crs_elem->nrofCRS_Ports = p_src_crs_elem->nrofCRSPorts;

    p_trg_crs_elem->v_Shift = p_src_crs_elem->vShift;

}


sim_return_val_et
fill_ssb_position_in_burst_info
(
    ssb_positions_in_burst_t*                               p_src_ssb_pos_info,
    nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst*    p_trg_ssb_pos_info,
    OSCTXT*                                                 p_asn1_ctx
)
{
    asn1Init_nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst(
            p_trg_ssb_pos_info);

    switch (p_src_ssb_pos_info->bitmap_type)
    {
        case SSB_POSITIONS_IN_BURST_SHORT_BITMAP:
            {
                p_trg_ssb_pos_info->t = 
                    T_nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst_shortBitmap;

                p_trg_ssb_pos_info->u.shortBitmap = rtxMemAllocType(p_asn1_ctx, ASN1BitStr32);

                if (PNULL == p_trg_ssb_pos_info->u.shortBitmap)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

                    return SIM_FAILURE;
                }
                p_trg_ssb_pos_info->u.shortBitmap->numbits = 4;

                memcpy(p_trg_ssb_pos_info->u.shortBitmap->data,
                        (char*)&p_src_ssb_pos_info->short_bitmap,1);

                break;
            }

        case SSB_POSITIONS_IN_BURST_MEDIUM_BITMAP:
            {
                p_trg_ssb_pos_info->t =
                    T_nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst_mediumBitmap;

                p_trg_ssb_pos_info->u.mediumBitmap = rtxMemAllocType(p_asn1_ctx, ASN1BitStr32);

                if (PNULL == p_trg_ssb_pos_info->u.mediumBitmap)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    return SIM_FAILURE;
                }
                p_trg_ssb_pos_info->u.mediumBitmap->numbits = 8;

                memcpy(p_trg_ssb_pos_info->u.mediumBitmap->data,
                        (char*)&p_src_ssb_pos_info->medium_bitmap,1);

                break;
            }

        case SSB_POSITIONS_IN_BURST_LONG_BITMAP:
            {
                p_trg_ssb_pos_info->t =
                    T_nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst_longBitmap;

                p_trg_ssb_pos_info->u.longBitmap = 
                    rtxMemAllocType(p_asn1_ctx,nr_rrc_ServingCellConfigCommon_ssb_PositionsInBurst_longBitmap );

                if (PNULL == p_trg_ssb_pos_info->u.longBitmap)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    return SIM_FAILURE;
                }
                p_trg_ssb_pos_info->u.longBitmap->numbits = 64;

                memcpy(p_trg_ssb_pos_info->u.longBitmap->data,
                        (char*)&p_src_ssb_pos_info->long_bitmap,8);

                break;
            }

        default:
            {
                LOG_TRACE("Incorrect value received [%d] ",p_src_ssb_pos_info->bitmap_type);
                break;
            }
    }
    return SIM_SUCCESS;
}


sim_return_val_et
 fill_config_common_freq_ul_info
(
    freq_info_ul_t*             p_src_ul_freq_elem,
    nr_rrc_FrequencyInfoUL*     p_trg_ul_freq_elem,
    OSCTXT*                     p_asn1_ctx
)
{
    UInt8   index = F1AP_NULL;

    /* Freq Band List */
    if (p_src_ul_freq_elem->bitmask & FREQ_INFO_UL_FREQ_BAND_LIST_PRESENT)
    {
        p_trg_ul_freq_elem->m.frequencyBandListPresent = 1;

        p_trg_ul_freq_elem->frequencyBandList.n = 
            p_src_ul_freq_elem->frequencyBandList.count;

        for (index = 0; index < p_src_ul_freq_elem->frequencyBandList.count; index++)
        {
            p_trg_ul_freq_elem->frequencyBandList.elem[index] = 
                p_src_ul_freq_elem->frequencyBandList.freqBandIndicator[index];
        }
    }

    /* Absolute Frequency Point A */
    if (p_src_ul_freq_elem->bitmask & FREQ_INFO_UL_ABSOLUTE_FREQ_POINT_A_PRESENT)
    {
        p_trg_ul_freq_elem->m.absoluteFrequencyPointAPresent = 1;

        p_trg_ul_freq_elem->absoluteFrequencyPointA = 
            p_src_ul_freq_elem->absoluteFrequencyPointA;
    }

    /* SCS Specific Carriers */
    {
        nr_rrc_FrequencyInfoUL_scs_SpecificCarrierList*    p_trg_list = PNULL;
        scs_sub_carrier_info_t*                         p_src_elem = PNULL;
        nr_rrc_SCS_SpecificCarrier*                     p_trg_elem = PNULL;
        OSRTDListNode*                                  p_trg_node = PNULL;

        p_trg_list = &p_trg_ul_freq_elem->scs_SpecificCarrierList;

        asn1Init_nr_rrc_FrequencyInfoUL_scs_SpecificCarrierList(p_trg_list);

        for (index = 0; index < p_src_ul_freq_elem->scs_specific_carriers.count; index ++)
        {
            rtxDListAllocNodeAndData(
                    p_asn1_ctx,
                    nr_rrc_SCS_SpecificCarrier,
                    &p_trg_node,
                    &p_trg_elem);

            if (PNULL == p_trg_node)
            {
                return SIM_FAILURE;
            }
            p_src_elem = &p_src_ul_freq_elem->scs_specific_carriers.scs_sub_carriers[index];

            asn1Init_nr_rrc_SCS_SpecificCarrier(p_trg_elem);

            p_trg_elem->offsetToCarrier   = p_src_elem->offsetToCarrier;
            p_trg_elem->subcarrierSpacing = p_src_elem->subcarrierSpacing;
            //p_trg_elem->k0                = p_src_elem->scs_sub_carrier_k0;
            p_trg_elem->carrierBandwidth  = p_src_elem->carrierBandwidth;

            rtxDListAppendNode(p_trg_list,p_trg_node);
        }
    }

    /* Additional spectrum emission */
    if (p_src_ul_freq_elem->bitmask & FREQ_INFO_UL_ADDITIONAL_SPECTRUM_EMISSION_PRESENT)
    {
        p_trg_ul_freq_elem->m.additionalSpectrumEmissionPresent = 1;

        p_trg_ul_freq_elem->additionalSpectrumEmission = 
            p_src_ul_freq_elem->additional_spectrum_emission;
    }

    /* Max UE uplink transmission power */
    if (p_src_ul_freq_elem->bitmask & FREQ_INFO_UL_P_MAX_PRESENT)
    {
        p_trg_ul_freq_elem->m.p_MaxPresent = 1;
        p_trg_ul_freq_elem->p_Max = p_src_ul_freq_elem->p_max;
    }

    /* NR UL transmission with a 7.5KHz shift */
    if (p_src_ul_freq_elem->bitmask & FREQ_INFO_UL_FREQ_SHIFT_7P5_KHZ_PRESENT)
    {
        p_trg_ul_freq_elem->m.frequencyShift7p5khzPresent = 1;

        p_trg_ul_freq_elem->frequencyShift7p5khz = 
            p_src_ul_freq_elem->frequencyShift7p5khzEnabled;
    }

    return SIM_SUCCESS;
}


sim_return_val_et
 fill_ul_config_common_info
(
    uplink_config_common_t*     p_src_ul_config_common,
    nr_rrc_UplinkConfigCommon*  p_trg_ul_config_common,
    OSCTXT*                     p_asn1_ctx
)
{
    asn1Init_nr_rrc_UplinkConfigCommon(p_trg_ul_config_common);

    if (p_src_ul_config_common->bitmask & UL_CONFIG_COMMON_FREQ_INFO_UL_PRESENT)
    {
        p_trg_ul_config_common->m.frequencyInfoULPresent = 1;
        
        if (SIM_FAILURE == fill_config_common_freq_ul_info(
                    &p_src_ul_config_common->frequencyInfoUL,
                    &p_trg_ul_config_common->frequencyInfoUL,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
    }

    if (p_src_ul_config_common->bitmask & UL_CONFIG_COMMON_INITIAL_UL_BWP_PRESENT)
    {
        p_trg_ul_config_common->m.initialUplinkBWPPresent = 1;
        /*
        if (SIM_FAILURE == fill_config_common_initial_ul_bwp_info(
                    &p_src_ul_config_common->initialUplinkBWP,
                    &p_trg_ul_config_common->initialUplinkBWP,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
        */
    }

    return SIM_SUCCESS;
}

//Container Changes
void fill_tdd_ul_dl_common_config
(
   tdd_ul_dl_config_common_t*      p_src_elem,
   nr_rrc_TDD_UL_DL_ConfigCommon*  p_trg_elem
)
{
    p_trg_elem->referenceSubcarrierSpacing = 
        p_src_elem->refSubCarrierSpacing;

    p_trg_elem->pattern1.dl_UL_TransmissionPeriodicity = 
        p_src_elem->pattern1.dl_ul_transmission_periodicity;
    p_trg_elem->pattern1.nrofDownlinkSlots = 
        p_src_elem->pattern1.num_dl_slots;
    p_trg_elem->pattern1.nrofDownlinkSymbols = 
        p_src_elem->pattern1.num_dl_symbols;
    p_trg_elem->pattern1.nrofUplinkSlots = 
        p_src_elem->pattern1.num_ul_slots;
    p_trg_elem->pattern1.nrofUplinkSymbols = 
        p_src_elem->pattern1.num_ul_symbols;

    if(p_src_elem->bitmask & 
            TDD_DL_UL_PATTERN2_PRESENT)
    {   
        p_trg_elem->pattern2.dl_UL_TransmissionPeriodicity = 
            p_src_elem->pattern2.dl_ul_transmission_periodicity;
        p_trg_elem->pattern2.nrofDownlinkSlots = 
            p_src_elem->pattern2.num_dl_slots;
        p_trg_elem->pattern2.nrofDownlinkSymbols = 
            p_src_elem->pattern2.num_dl_symbols;
        p_trg_elem->pattern2.nrofUplinkSlots = 
            p_src_elem->pattern2.num_ul_slots;
        p_trg_elem->pattern2.nrofUplinkSymbols = 
            p_src_elem->pattern2.num_ul_symbols;


    } 

}



sim_return_val_et
 fill_spcell_config_common_info
(
    scell_config_common_t*          p_src_msg,
    nr_rrc_ServingCellConfigCommon* p_trg_msg,
    OSCTXT*                         p_asn1_ctx
)    
{
    UInt8   index = F1AP_NULL;

    /* Physical cell id */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_PHY_CELL_ID_PRESENT)
    {
        p_trg_msg->m.physCellIdPresent = 1;
        
        p_trg_msg->physCellId = p_src_msg->phyCellId;
    }

    #if 0 //As per latest ASN, this IE is removed <Container Changes>

    /* DL Freq information */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_DL_FREQ_INFO_PRESENT)
    {
        p_trg_msg->m.frequencyInfoDLPresent = 1;

        if (SIM_FAILURE == fill_dl_freq_info(
                    &p_src_msg->dlFreqInfo,
                    &p_trg_msg->frequencyInfoDL,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
    }
    /* BWP DL info */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_INITIAL_DL_BWP_PRESENT)
    {
        p_trg_msg->m.initialDownlinkBWPPresent = 1;

        if (SIM_FAILURE == fill_bwp_dl_common_info(
                    &p_src_msg->initialDownlinkBWP,
                    &p_trg_msg->initialDownlinkBWP,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
    }
    #endif 


//container Changes

    /* DL config info */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_DL_CONFIG_COMMON_PRESENT)
    {
        p_trg_msg->m.downlinkConfigCommonPresent = 1;
        //TODO
    }


    /* UL config info */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_UL_CONFIG_COMMON_PRESENT)
    {
        p_trg_msg->m.uplinkConfigCommonPresent = 1;

        if (SIM_FAILURE == fill_ul_config_common_info(
                    &p_src_msg->ulConfigCommon,
                    &p_trg_msg->uplinkConfigCommon,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }

    }

    /* Supplementary Uplink frequency info */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_SUPPLEMENTARY_UPLINK_PRESENT)
    {
        p_trg_msg->m.supplementaryUplinkConfigPresent = 1;

        if (SIM_FAILURE == fill_ul_config_common_info(
                    &p_src_msg->supplementaryULConfig,
                    &p_trg_msg->supplementaryUplinkConfig,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
    }


//Container Changes
    /* n_timing Advance */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_N_TIMIMG_ADVANCE_OFFSET_PRESENT)
    {
        p_trg_msg->m.n_TimingAdvanceOffsetPresent= 1;
        //TODO
    }


    /* SSB Position in Burst */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_SSB_POSITIONS_IN_BURST_PRESENT)
    {
        p_trg_msg->m.ssb_PositionsInBurstPresent = 1;

        if (SIM_FAILURE == fill_ssb_position_in_burst_info(
                    &p_src_msg->ssbPositionsInBurst,
                    &p_trg_msg->ssb_PositionsInBurst,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
    }

    /* SSB periodicity */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_SSB_PERIODICITY_SERV_CELL_PRESENT)
    {
        p_trg_msg->m.ssb_periodicityServingCellPresent = 1;

        p_trg_msg->ssb_periodicityServingCell = 
            p_src_msg->ssbPeriodicity;
    }

    /* DMRS Type A Position */
    p_trg_msg->dmrs_TypeA_Position = p_src_msg->dmrs_typeA_position;

    /* CRS to match around */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_LTE_CRS_TO_MATCH_AROUND_PRESENT)
    {
        asn1Init_nr_rrc_ServingCellConfigCommon_lte_CRS_ToMatchAround(
                &p_trg_msg->lte_CRS_ToMatchAround);

        p_trg_msg->m.lte_CRS_ToMatchAroundPresent = 1;

        if (p_src_msg->lte_crs_to_match_around.bitmask &
                LTE_CRS_TO_MATCH_AROUND_RELEASE_PRESENT)
        {
            p_trg_msg->lte_CRS_ToMatchAround.t =
                T_nr_rrc_ServingCellConfigCommon_lte_CRS_ToMatchAround_release;
        }
        else if (p_src_msg->lte_crs_to_match_around.bitmask & 
                LTE_CRS_TO_MATCH_AROUND_SETUP_PRESENT)
        {
            p_trg_msg->lte_CRS_ToMatchAround.t =
                T_nr_rrc_ServingCellConfigCommon_lte_CRS_ToMatchAround_setup;

            p_trg_msg->lte_CRS_ToMatchAround.u.setup = 
                rtxMemAllocType(p_asn1_ctx,nr_rrc_RateMatchPatternLTE_CRS);

            if (PNULL == p_trg_msg->lte_CRS_ToMatchAround.u.setup)
            {
                return SIM_FAILURE;
            }

            fill_crs_to_match_around_info(
                    &p_src_msg->lte_crs_to_match_around.setup,
                    p_trg_msg->lte_CRS_ToMatchAround.u.setup);
        }
        else 
        {
            LOG_TRACE("%s:Incorrect CRS to match around type received\n",__FUNCTION__);
            return SIM_FAILURE;
        }
    }

    /* Rate match pattern to add mod list */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_RMP_TO_ADD_MOD_LIST_PRESENT)
    {
        p_trg_msg->m.rateMatchPatternToAddModListPresent = 1;

        nr_rrc_ServingCellConfigCommon_rateMatchPatternToAddModList*    p_trg_list = PNULL;
        nr_rrc_RateMatchPattern*                                        p_trg_elem = PNULL;
        rate_match_pattern_to_add_mod_t*                                p_src_elem = PNULL;
        OSRTDListNode*                                                  p_trg_node = PNULL;

        p_trg_list = &p_trg_msg->rateMatchPatternToAddModList;

        asn1Init_nr_rrc_ServingCellConfigCommon_rateMatchPatternToAddModList(p_trg_list);

        for (index = 0; index < p_src_msg->rateMatchPatternToAddModList.count;
                index++)
        {
            rtxDListAllocNodeAndData(p_asn1_ctx,
                    nr_rrc_RateMatchPattern,
                    &p_trg_node,
                    &p_trg_elem);

            if (PNULL == p_trg_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
              
                return SIM_FAILURE;
            }

            p_src_elem = &p_src_msg->
                rateMatchPatternToAddModList.rateMatchPatternToAddMod[index];

            if (SIM_FAILURE == fill_rate_match_pattern_add_mod_list(
                                        p_src_elem,
                                        p_trg_elem,
                                        p_asn1_ctx))
            {
                return SIM_FAILURE;
            }

            rtxDListAppendNode(p_trg_list,p_trg_node);
        }
    }

    /* Rate match pattern to release list */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_RMP_TO_RELEASE_LIST_PRESENT)
    {
        p_trg_msg->m.rateMatchPatternToReleaseListPresent = 1;

        fill_rate_match_pattern_release_list(
                &p_src_msg->rateMatchPatternToReleaseList,
                &p_trg_msg->rateMatchPatternToReleaseList);
    }


    /* Subcarrier spacing */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_SUB_CARRIER_SPACING_PRESENT)
    {
        /*  ASN1550 changes start */
        p_trg_msg->m.ssbSubcarrierSpacingPresent = 1;

        p_trg_msg->ssbSubcarrierSpacing = p_src_msg->subcarrierSpacing;
        /*ASN1550 changes stop */
    }

    /* TDD UL/DL common config */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_TDD_DL_UL_CONFIG_COMMON_PRESENT)
    {
        p_trg_msg->m.tdd_UL_DL_ConfigurationCommonPresent = 1;

//Container Changes
        fill_tdd_ul_dl_common_config(
                &p_src_msg->tdd_ul_dl_config_common,
                &p_trg_msg->tdd_UL_DL_ConfigurationCommon);
                
    }

#if 0 //As per latest ASN, this IE is removed <Container Changes>
    /* TDD UL/DL common config 2 */
    if (p_src_msg->bitmask & SCELL_CONFIG_COMMON_TDD_DL_UL_CONFIG_COMMON2_PRESENT)
    {
        p_trg_msg->m.tdd_UL_DL_ConfigurationCommon2Present = 1;

        fill_tdd_ul_dl_common_config(
                &p_src_msg->tdd_ul_dl_config_common2,
                &p_trg_msg->tdd_UL_DL_ConfigurationCommon2);
    }

#endif
    /* SS pbch block power */
    p_trg_msg->ss_PBCH_BlockPower = p_src_msg->ss_pbch_block_power;

    return SIM_SUCCESS;
}



sim_return_val_et fill_scell_to_add_mod_list
(
    scell_to_add_mod_t*     p_src_scell_add_mod_info, 
    nr_rrc_SCellConfig*     p_trg_scell_add_mod_info,
    OSCTXT*                 p_asn1_ctx
)
{
    /* Scell Index */
    p_trg_scell_add_mod_info->sCellIndex = 
        p_src_scell_add_mod_info->scell_index;

    /* Scell common config info */
    if (p_src_scell_add_mod_info->bitmask &
            SCELL_TO_ADD_MOD_SERVING_CELL_CONFIG_COMMON_PRESENT)
    {
        p_trg_scell_add_mod_info->m.sCellConfigCommonPresent = 1;
      
//Container Changes
        if (SIM_FAILURE == fill_spcell_config_common_info(
                    &p_src_scell_add_mod_info->scellConfigCommon,
                    &p_trg_scell_add_mod_info->sCellConfigCommon,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
        
    }

    /* Scell dedicated info */
    if (p_src_scell_add_mod_info->bitmask &
            SCELL_TO_ADD_MOD_SERVING_CELL_CONFIG_DEDICATED_PRESENT)
    {
        p_trg_scell_add_mod_info->m.sCellConfigDedicatedPresent = 1;
 
  /*
        if (SIM_FAILURE == fill_dedicated_cell_config_info(
                    &p_src_scell_add_mod_info->scellConfigDedicated,
                    &p_trg_scell_add_mod_info->sCellConfigDedicated,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
        */
    }

    return SIM_SUCCESS;
}
sim_return_val_et f1ap_encode_scell_config_list 
(
    scell_to_add_mod_list_t*                    p_src_scell_config_list,
    nr_rrc_CellGroupConfig_sCellToAddModList*   p_trg_scell_config_list,
    OSCTXT*                                     p_asn1_ctx
)
{
    UInt8                    index               = 0; 
    nr_rrc_SCellConfig*     p_scell_config_elem  = PNULL;
    OSRTDListNode*          p_scell_node         = PNULL;

    asn1Init_nr_rrc_CellGroupConfig_sCellToAddModList(
            p_trg_scell_config_list);

    rtxDListAllocNodeAndData(
            p_asn1_ctx,
            nr_rrc_SCellConfig,
            &p_scell_node,
            &p_scell_config_elem);

    if (PNULL == p_scell_node)
    {
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }

    asn1Init_nr_rrc_SCellConfig(p_scell_config_elem);

    for (index = 0; index < p_src_scell_config_list->count; index++)
    {
        if (SIM_FAILURE == fill_scell_to_add_mod_list(
                    &p_src_scell_config_list->scellToAddMod[index],
                    p_scell_config_elem,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }

        rtxDListAppendNode(p_trg_scell_config_list,p_scell_node);
    }

    return SIM_SUCCESS;
}


void f1ap_encode_phy_cell_group_config
(
    phy_cell_group_config_t*           p_src_msg,
    nr_rrc_PhysicalCellGroupConfig*    p_trg_msg
)
{
    /* spatial bundling of HARQ ACK for PUCCH reporting */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_HARQ_ACK_SPATIAL_BUNDLING_PUCCH_PRESENT)
    {
        p_trg_msg->m.harq_ACK_SpatialBundlingPUCCHPresent = 1;

        p_trg_msg->harq_ACK_SpatialBundlingPUCCH =
            p_src_msg->harq_ack_spatial_bundling_pucch;
    }

    /* spatial bundling of HARQ ACK for PUSCH reporting */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_HARQ_ACK_SPATIAL_BUNDLING_PUSCH_PRESENT)
    {
        p_trg_msg->m.harq_ACK_SpatialBundlingPUSCHPresent = 1;

        p_trg_msg->harq_ACK_SpatialBundlingPUSCH =
            p_src_msg->harq_ack_spatial_bundling_pusch;
    }

    /* maximum transmit power */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_PMAX_NR_PRESENT)
    {
        p_trg_msg->m.p_NR_FR1Present = 1;
        p_trg_msg->p_NR_FR1 = p_src_msg->p_max;
    }

    /* HARQ-ACK-codebook */
    p_trg_msg->pdsch_HARQ_ACK_Codebook = p_src_msg->pdsch_harq_ack_codebook;

    /* TPC-SRS-RNTI */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_TPC_SRS_RNTI_PRESENT)
    {
         p_trg_msg->m.tpc_SRS_RNTIPresent = 1;
         p_trg_msg->tpc_SRS_RNTI = p_src_msg->tpc_srs_rnti;
    }

    /* TPC-PUCCH-RNTI */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_TPC_PUCCH_RNTI_PRESENT)
    {
         p_trg_msg->m.tpc_PUCCH_RNTIPresent = 1;
         p_trg_msg->tpc_PUCCH_RNTI = p_src_msg->tpc_pucch_rnti;
    }

    /* TPC-PUSCH-RNTI */
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_TPC_PUSCH_RNTI_PRESENT)
    {
         p_trg_msg->m.tpc_PUSCH_RNTIPresent = 1;
         p_trg_msg->tpc_PUSCH_RNTI = p_src_msg->tpc_pusch_rnti;
    }
    
//Container Changes    
    /*SP_CSI_RNTI*/
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_TPC_SP_CSI_RNTI_PRESENT)
    {
         p_trg_msg->m.sp_CSI_RNTIPresent = 1;
         p_trg_msg->sp_CSI_RNTI = p_src_msg->sp_csi_rnti;
    }

    /*CS_RNTI*/
    if (p_src_msg->bitmask &
            PHY_CELL_GROUP_CONFIG_TPC_CSI_RNTI_PRESENT)
    {
         p_trg_msg->m.cs_RNTIPresent = 1;
          
         switch(p_src_msg->cs_rnti.cs_rnti_type)
         {
           case CS_RNTI_RELEASE: 
           {
             p_trg_msg->cs_RNTI.t = T_nr_rrc_PhysicalCellGroupConfig_cs_RNTI_release; 
             LOG_TRACE("%s:CS_RNTI_RELEASE.",__FUNCTION__);
             break;
           }
           case CS_RNTI_SETUP: 
           {
             p_trg_msg->cs_RNTI.t = T_nr_rrc_PhysicalCellGroupConfig_cs_RNTI_setup; 
             p_trg_msg->cs_RNTI.u.setup = p_src_msg->cs_rnti.setup;
             break;
           }
         
         }
    
    }

}


sim_return_val_et 
fill_rlf_timer_and_constants
(
    rlf_timers_and_constants_setup_t*   p_src_timer_const_info,
    nr_rrc_RLF_TimersAndConstants**     p_p_trg_timer_const_info,
    OSCTXT*                             p_asn1_ctx
)
{
    nr_rrc_RLF_TimersAndConstants*  p_trg_timer_const_info = PNULL;

    *p_p_trg_timer_const_info = rtxMemAllocType(p_asn1_ctx,nr_rrc_RLF_TimersAndConstants);

    if (PNULL == *p_p_trg_timer_const_info)
    {
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }
   
    p_trg_timer_const_info = *p_p_trg_timer_const_info;

    asn1Init_nr_rrc_RLF_TimersAndConstants(p_trg_timer_const_info);

    p_trg_timer_const_info->t310 = p_src_timer_const_info->t310;

    p_trg_timer_const_info->n310 = p_src_timer_const_info->n310;

    p_trg_timer_const_info->n311 = p_src_timer_const_info->n311;
    return SIM_SUCCESS;
}



sim_return_val_et
fill_dedicated_rach_config_info
(
    rach_config_dedicated_t*    p_src_rach_config_dedicated,
    nr_rrc_ReconfigurationWithSync_rach_ConfigDedicated*
    p_trg_rach_config_dedicated,
    OSCTXT*                 p_asn1_ctx
)
{
    if (p_src_rach_config_dedicated->t ==
            T_RACH_CONFIG_DEDICATED_UPLINK)
    {
        p_trg_rach_config_dedicated->t = 
            T_nr_rrc_ReconfigurationWithSync_rach_ConfigDedicated_uplink;

        p_trg_rach_config_dedicated->u.uplink =
            rtxMemAllocType(p_asn1_ctx,nr_rrc_RACH_ConfigDedicated);

        if (PNULL == p_trg_rach_config_dedicated->u.uplink)
        {
            return SIM_FAILURE;
        }

        asn1Init_nr_rrc_RACH_ConfigDedicated(p_trg_rach_config_dedicated->u.uplink);

/*
        if (SIM_FAILURE == fill_rach_config_dedicated_cfra_resources(
    //return retVal;
                    &p_src_rach_config_dedicated->uplink.cfra_resources,
                    &p_trg_rach_config_dedicated->u.uplink->cfra_Resources,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
*/
    }
    else if (p_src_rach_config_dedicated->t ==
            T_RACH_CONFIG_DEDICATED_SUPP_UPLINK)
    {
        p_trg_rach_config_dedicated->t = 
            T_nr_rrc_ReconfigurationWithSync_rach_ConfigDedicated_supplementaryUplink;

        p_trg_rach_config_dedicated->u.supplementaryUplink =
            rtxMemAllocType(p_asn1_ctx,nr_rrc_RACH_ConfigDedicated);

        if (PNULL == p_trg_rach_config_dedicated->u.supplementaryUplink)
        {
            return SIM_FAILURE;
        }

        asn1Init_nr_rrc_RACH_ConfigDedicated(p_trg_rach_config_dedicated->u.supplementaryUplink);

       /*
        if (SIM_FAILURE == fill_rach_config_dedicated_cfra_resources(
                    &p_src_rach_config_dedicated->supplementaryUplink.cfra_resources,
                    &p_trg_rach_config_dedicated->u.supplementaryUplink->cfra_Resources,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
        */
    }
    else
    {
        LOG_TRACE("Incorrect RACH config dedicated type received [%d] ",p_src_rach_config_dedicated->t);
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}





sim_return_val_et f1ap_encode_sp_cell_config
(
    sp_cell_config_t*       p_src_msg,
    nr_rrc_SpCellConfig*    p_trg_msg,
    OSCTXT*                 p_asn1_ctx
)
{

    /* Served Cell Index */
    if (p_src_msg->bitmask & SPCELL_CONFIG_SERVED_CELL_INDEX_PRESENT)
    {
        p_trg_msg->m.servCellIndexPresent = 1;

        p_trg_msg->servCellIndex = p_src_msg->served_cell_index;
    }

    /* synchronous reconfiguration config */
    if (p_src_msg->bitmask & SPCELL_CONFIG_SYNC_RECONFIG_CONFIG_PRESENT)
    {
        asn1Init_nr_rrc_ReconfigurationWithSync(
                &p_trg_msg->reconfigurationWithSync);

        p_trg_msg->m.reconfigurationWithSyncPresent = 1;

        /* New identity */
        p_trg_msg->reconfigurationWithSync.newUE_Identity = 
            p_src_msg->syncReconfigurationConfig.crnti;

        /* timer */
        p_trg_msg->reconfigurationWithSync.t304 = 
            p_src_msg->syncReconfigurationConfig.timer_t304;

        if (p_src_msg->syncReconfigurationConfig.bitmask &
                SPCELL_SYNC_RECONFIG_SPCELL_CONFIG_COMMON_PRESENT)
        {
            asn1Init_nr_rrc_ServingCellConfigCommon(
                    &p_trg_msg->reconfigurationWithSync.spCellConfigCommon);

            p_trg_msg->reconfigurationWithSync.m.spCellConfigCommonPresent = 1;

//Container Changes
            if (SIM_FAILURE == fill_spcell_config_common_info(
                    &p_src_msg->syncReconfigurationConfig.scellConfigCommon,
                    &p_trg_msg->reconfigurationWithSync.spCellConfigCommon,
                    p_asn1_ctx))
            {
                return SIM_FAILURE;
            }
            
        }

        if (p_src_msg->syncReconfigurationConfig.bitmask &
                SPCELL_SYNC_RECONFIG_DEDICATED_RACH_CONFIG_PRESENT)
        {
            asn1Init_nr_rrc_ReconfigurationWithSync_rach_ConfigDedicated(
                    &p_trg_msg->reconfigurationWithSync.rach_ConfigDedicated);

            p_trg_msg->reconfigurationWithSync.m.rach_ConfigDedicatedPresent = 1;

            if (SIM_FAILURE == fill_dedicated_rach_config_info(
                        &p_src_msg->syncReconfigurationConfig.dedicatedRachConfig,
                        &p_trg_msg->reconfigurationWithSync.rach_ConfigDedicated,
                        p_asn1_ctx))
            {
                return SIM_FAILURE;
            }
        }
    }

    /* UE specific timers and constants configuration */
    if (p_src_msg->bitmask & SPCELL_CONFIG_RLF_TIMERS_AND_CONSTANTS_PRESENT)
    {
        asn1Init_nr_rrc_SpCellConfig_rlf_TimersAndConstants(
                &p_trg_msg->rlf_TimersAndConstants);

        p_trg_msg->m.rlf_TimersAndConstantsPresent = 1;

        if (p_src_msg->rlfTimersAndConstants.bitmask  &
                RLF_TIMERS_AND_CONSTANTS_SETUP_PRESENT)
        {
            p_trg_msg->rlf_TimersAndConstants.t = 
                T_nr_rrc_SpCellConfig_rlf_TimersAndConstants_setup;

            if (SIM_FAILURE == fill_rlf_timer_and_constants(
                        &p_src_msg->rlfTimersAndConstants.setup,
                        &p_trg_msg->rlf_TimersAndConstants.u.setup,
                        p_asn1_ctx))
            {
                return SIM_FAILURE;
            }
        }
        else if (p_src_msg->bitmask & RLF_TIMERS_AND_CONSTANTS_RELEASE_PRESENT)
        {
            p_trg_msg->rlf_TimersAndConstants.t =
                T_nr_rrc_SpCellConfig_rlf_TimersAndConstants_release;
        }
        else 
               
        {
  
            LOG_TRACE("%s:Incorrect rlf timer and constant type received ",__FUNCTION__);
            return SIM_FAILURE;
        }
    }

    /* RLM in sync/out of syn threshold */
    if (p_src_msg->bitmask & SPCELL_CONFIG_RLM_IN_SYNC_OUT_OF_SYNC_PRESENT)
    {
        p_trg_msg->m.rlmInSyncOutOfSyncThresholdPresent = 1;

        p_trg_msg->rlmInSyncOutOfSyncThreshold = 
            p_src_msg->rlmInSyncOutOfSyncThreshold;
    }

    /* Special cell config dedicated */
    if (p_src_msg->bitmask & SPCELL_CONFIG_DEDICATED_CONFIG_PRESENT)
    {
        p_trg_msg->m.spCellConfigDedicatedPresent = 1;

        asn1Init_nr_rrc_ServingCellConfig(
                &p_trg_msg->spCellConfigDedicated);
       /* 
        if (SIM_FAILURE == fill_dedicated_cell_config_info(
                &p_src_msg->dedicated_cell_config,
                &p_trg_msg->spCellConfigDedicated,
                p_asn1_ctx))
        {
            return SIM_FAILURE;
        }
        */
    }

    return SIM_SUCCESS;
}








/* This function encodes RLC bearer to add mod 
 * parameters into ASN format */
sim_return_val_et
       fill_rlc_bearer_to_add_mod_list
(   
    rlc_bearer_to_add_mod_t*    p_src_msg,
    nr_rrc_RLC_BearerConfig*    p_trg_msg,
    OSCTXT*                     p_asn1_ctx
)
{
    UInt8   index = F1AP_NULL;

    p_trg_msg->logicalChannelIdentity = p_src_msg->lcId;

    /* Served Radio Bearer */ 
    if (p_src_msg->bitmask & BEARER_TO_ADD_MOD_SERVED_RADIO_BEARER_PRESENT)
    {
        asn1Init_nr_rrc_RLC_BearerConfig_servedRadioBearer(
                &p_trg_msg->servedRadioBearer);

        p_trg_msg->m.servedRadioBearerPresent = 1;

        if (p_src_msg->servedRadioBearer.bitmask & SERVED_RADIO_BEARER_TYPE_SRB_PRESENT)
        {
            p_trg_msg->servedRadioBearer.t = 
                T_nr_rrc_RLC_BearerConfig_servedRadioBearer_srb_Identity;

            p_trg_msg->servedRadioBearer.u.srb_Identity =
                p_src_msg->servedRadioBearer.srb_id;
        }
        else if (p_src_msg->servedRadioBearer.bitmask & SERVED_RADIO_BEARER_TYPE_DRB_PRESENT)
        {
            p_trg_msg->servedRadioBearer.t = 
                T_nr_rrc_RLC_BearerConfig_servedRadioBearer_drb_Identity;

            p_trg_msg->servedRadioBearer.u.drb_Identity =
                p_src_msg->servedRadioBearer.drb_id;
        }

    }

    /* RLC Re-establish info */
    if (p_src_msg->bitmask & BEARER_TO_ADD_MOD_RE_ESTABLISH_RLC_PRESENT)
    {
        p_trg_msg->m.reestablishRLCPresent = 1;

        p_trg_msg->reestablishRLC = p_src_msg->reestablishRLC ;
    }

    /* RLC Config info */
    if (p_src_msg->bitmask & BEARER_TO_ADD_MOD_RLC_CONFIG_PRESENT)
    {
        asn1Init_nr_rrc_RLC_Config(&p_trg_msg->rlc_Config);

        p_trg_msg->m.rlc_ConfigPresent = 1;

        if (p_src_msg->rlcConfig.t == T_RLC_LC_CONFIG_AM)
        {
            p_trg_msg->rlc_Config.u.am = rtxMemAllocType(p_asn1_ctx,
                                                          nr_rrc_RLC_Config_am);

            if (PNULL == p_trg_msg->rlc_Config.u.am)
            {
                return SIM_FAILURE;
            }

            p_trg_msg->rlc_Config.t = T_nr_rrc_RLC_Config_am;

            //Container Changes
            if(p_src_msg->rlcConfig.am_config.ul_config.bitmask & T_RLC_AM_UL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {
              p_trg_msg->rlc_Config.u.am->ul_AM_RLC.sn_FieldLength =
                p_src_msg->rlcConfig.am_config.ul_config.sn_field_length;
            }
            p_trg_msg->rlc_Config.u.am->ul_AM_RLC.t_PollRetransmit =
                p_src_msg->rlcConfig.am_config.ul_config.t_poll_retransmit;

            p_trg_msg->rlc_Config.u.am->ul_AM_RLC.pollPDU =
                p_src_msg->rlcConfig.am_config.ul_config.poll_pdu;

            p_trg_msg->rlc_Config.u.am->ul_AM_RLC.pollByte =
                p_src_msg->rlcConfig.am_config.ul_config.poll_byte;

            p_trg_msg->rlc_Config.u.am->ul_AM_RLC.maxRetxThreshold =
                p_src_msg->rlcConfig.am_config.ul_config.max_retx_threshold;

            //Container Changes
            if(p_src_msg->rlcConfig.am_config.dl_config.bitmask & T_RLC_AM_DL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {
              p_trg_msg->rlc_Config.u.am->dl_AM_RLC.sn_FieldLength =
                 p_src_msg->rlcConfig.am_config.dl_config.sn_field_length;
            }
            p_trg_msg->rlc_Config.u.am->dl_AM_RLC.t_Reassembly =
                p_src_msg->rlcConfig.am_config.dl_config.t_re_assembly;

            p_trg_msg->rlc_Config.u.am->dl_AM_RLC.t_StatusProhibit =
                p_src_msg->rlcConfig.am_config.dl_config.t_status_prohibit;

        }
        else if (p_src_msg->rlcConfig.t == T_RLC_LC_CONFIG_UM_BI_DIRECTIONAL)
        {
            p_trg_msg->rlc_Config.u.um_Bi_Directional = 
                rtxMemAllocType(p_asn1_ctx,nr_rrc_RLC_Config_um_Bi_Directional);

            if (PNULL == p_trg_msg->rlc_Config.u.um_Bi_Directional)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            p_trg_msg->rlc_Config.t = T_nr_rrc_RLC_Config_um_Bi_Directional;

            //Container Changes
            if(p_src_msg->rlcConfig.um_dl_ul_config.ul_config.bitmask & T_RLC_UM_UL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {
              p_trg_msg->rlc_Config.u.um_Bi_Directional->ul_UM_RLC.sn_FieldLength =
                p_src_msg->rlcConfig.um_dl_ul_config.ul_config.sn_field_length;
            }
            //Container Changes
            if(p_src_msg->rlcConfig.um_dl_ul_config.dl_config.bitmask & T_RLC_UM_DL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {
              p_trg_msg->rlc_Config.u.um_Bi_Directional->dl_UM_RLC.sn_FieldLength =
                p_src_msg->rlcConfig.um_dl_ul_config.dl_config.sn_field_length;
            }
            p_trg_msg->rlc_Config.u.um_Bi_Directional->dl_UM_RLC.t_Reassembly =
                p_src_msg->rlcConfig.um_dl_ul_config.dl_config.t_re_assembly;
        }
        else if (p_src_msg->rlcConfig.t == T_RLC_LC_CONFIG_UM_UNI_DIRECTIONAL_UL)
        {
            p_trg_msg->rlc_Config.u.um_Uni_Directional_UL = 
                rtxMemAllocType(p_asn1_ctx,nr_rrc_RLC_Config_um_Uni_Directional_UL);

            if (PNULL == p_trg_msg->rlc_Config.u.um_Uni_Directional_UL)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            p_trg_msg->rlc_Config.t = T_nr_rrc_RLC_Config_um_Uni_Directional_UL;
            //Container Changes
            if(p_src_msg->rlcConfig.um_ul_config.ul_config.bitmask & T_RLC_UM_UNI_UL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {
              p_trg_msg->rlc_Config.u.um_Uni_Directional_UL->ul_UM_RLC.sn_FieldLength =
                p_src_msg->rlcConfig.um_ul_config.ul_config.sn_field_length;
            }
        }
        else if (p_src_msg->rlcConfig.t == T_RLC_LC_CONFIG_UM_UNI_DIRECTIONAL_DL)
        {

            p_trg_msg->rlc_Config.u.um_Uni_Directional_DL = 
                rtxMemAllocType(p_asn1_ctx,nr_rrc_RLC_Config_um_Uni_Directional_DL);

            if (PNULL == p_trg_msg->rlc_Config.u.um_Uni_Directional_DL)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }
            p_trg_msg->rlc_Config.t = T_nr_rrc_RLC_Config_um_Uni_Directional_DL;
            //Container Changes
            if(p_src_msg->rlcConfig.um_ul_config.ul_config.bitmask & T_RLC_UM_UNI_DL_CONFIG_SN_FIELD_LENGTH_PRESENT)
            {

              p_trg_msg->rlc_Config.u.um_Uni_Directional_DL->dl_UM_RLC.sn_FieldLength =
                p_src_msg->rlcConfig.um_dl_config.dl_config.sn_field_length;
            }
            p_trg_msg->rlc_Config.u.um_Uni_Directional_DL->dl_UM_RLC.t_Reassembly =
                p_src_msg->rlcConfig.um_dl_config.dl_config.t_re_assembly;
        }
        else 
        {
            LOG_TRACE("Incorrect RLC config type received [%d]",p_src_msg->rlcConfig.t);
            return SIM_FAILURE;
        }

    }

    /* Mac Config */
    if (p_src_msg->bitmask & BEARER_TO_ADD_MOD_MAC_LC_CONFIG_PRESENT)
    {
        asn1Init_nr_rrc_LogicalChannelConfig(&p_trg_msg->mac_LogicalChannelConfig);

        p_trg_msg->m.mac_LogicalChannelConfigPresent = 1;

        if (p_src_msg->macConfig.bitmask & MAC_LC_CONFIG_UL_SPECIFIC_PARAMS_PRESENT)
        {
            p_trg_msg->mac_LogicalChannelConfig.m.ul_SpecificParametersPresent = 1;

            nr_rrc_LogicalChannelConfig_ul_SpecificParameters*  p_ul_specific_params = PNULL;

            p_ul_specific_params = &p_trg_msg->mac_LogicalChannelConfig.ul_SpecificParameters;

            asn1Init_nr_rrc_LogicalChannelConfig_ul_SpecificParameters(
                    p_ul_specific_params);

            p_ul_specific_params->priority =
                p_src_msg->macConfig.ulConfig.priority;

            p_ul_specific_params->prioritisedBitRate =
                p_src_msg->macConfig.ulConfig.prioritisedBitRate;

            p_ul_specific_params->bucketSizeDuration =
                p_src_msg->macConfig.ulConfig.bucketSizeDuration;

            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_ALLOWED_SERVING_CELLS_PRESENT)
            {
                asn1Init_nr_rrc_LogicalChannelConfig_ul_SpecificParameters_allowedServingCells(
                        &p_ul_specific_params->allowedServingCells);

                p_ul_specific_params->m.allowedServingCellsPresent =1;

                p_ul_specific_params->allowedServingCells.n =
                    p_src_msg->macConfig.ulConfig.allowedServingCells.numCells;

                for (index = 0; index < p_src_msg->macConfig.ulConfig.allowedServingCells.numCells;
                        index ++)
                {
                    p_ul_specific_params->allowedServingCells.elem[index] =
                        p_src_msg->macConfig.ulConfig.allowedServingCells.cell_index[index];

                }
            }

            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_SUB_CARRIER_SPACING_LIST_PRESENT)
            {
                asn1Init_nr_rrc_LogicalChannelConfig_ul_SpecificParameters_allowedSCS_List(
                        &p_ul_specific_params->allowedSCS_List);

                p_ul_specific_params->m.allowedSCS_ListPresent =1;

                p_ul_specific_params->allowedSCS_List.n =
                    p_src_msg->macConfig.ulConfig.allowedSCSList.count;

                for (index = 0; index < p_src_msg->macConfig.ulConfig.allowedSCSList.count;
                        index ++)
                {

                    p_ul_specific_params->allowedSCS_List.elem[index] = 
                        p_src_msg->macConfig.ulConfig.allowedSCSList.sub_carrier_spacing[index];

                }
            }

            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_MAX_PUSCH_DURATION_PRESENT)
            {
                p_ul_specific_params->m.maxPUSCH_DurationPresent =1;

                p_ul_specific_params->maxPUSCH_Duration =
                    p_src_msg->macConfig.ulConfig.maxPuschDuration;
            }

            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_CONFIGURED_GRANT_TYPE1_ALLOWED_PRESENT)
            {
                p_ul_specific_params->m.configuredGrantType1AllowedPresent = 1;

                p_ul_specific_params->configuredGrantType1Allowed =
                    p_src_msg->macConfig.ulConfig.configuredGrantType1Allowed;
            }
            
            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_LC_GROUP_PRESENT)
            {
                p_ul_specific_params->m.logicalChannelGroupPresent = 1;

                p_ul_specific_params->logicalChannelGroup =
                    p_src_msg->macConfig.ulConfig.lcGroup;
            }

            if (p_src_msg->macConfig.ulConfig.bitmask & MAC_UL_CONFIG_SCHEDULING_REQUEST_ID_PRESENT)
            {
                p_ul_specific_params->m.schedulingRequestIDPresent = 1;

                p_ul_specific_params->schedulingRequestID =
                    p_src_msg->macConfig.ulConfig.schedulingRequestID;
            }

            p_ul_specific_params->logicalChannelSR_Mask =
                p_src_msg->macConfig.ulConfig.lcSRMask;

            p_ul_specific_params->logicalChannelSR_DelayTimerApplied =
                p_src_msg->macConfig.ulConfig.lcSRDelayTimerApplied;

        }
    }
    return SIM_SUCCESS;
}




sim_return_val_et
    f1ap_encode_rlc_bearer_list
(
    rlc_bearer_to_add_mod_list_t*                   p_src_rlc_bearer_list,
    nr_rrc_CellGroupConfig_rlc_BearerToAddModList*  p_trg_rlc_bearer_list,
    OSCTXT*                                         p_asn1_ctx
)
{
    UInt8                       index                    = F1AP_NULL; 
    nr_rrc_RLC_BearerConfig*    p_rlc_bearer_config_elem = F1AP_P_NULL;
    OSRTDListNode*              p_rlc_bearer_node        = F1AP_P_NULL;

    asn1Init_nr_rrc_CellGroupConfig_rlc_BearerToAddModList(
            p_trg_rlc_bearer_list);

    for (index = 0; index < p_src_rlc_bearer_list->count;index ++)
    {
        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                nr_rrc_RLC_BearerConfig,
                &p_rlc_bearer_node,
                &p_rlc_bearer_config_elem);

        if (NULL == p_rlc_bearer_node)
        {
            return  SIM_FAILURE;
        }

        asn1Init_nr_rrc_RLC_BearerConfig(p_rlc_bearer_config_elem);

//Container Changes
        if (SIM_FAILURE == fill_rlc_bearer_to_add_mod_list(
                    &p_src_rlc_bearer_list->lchConfig[index],
                    p_rlc_bearer_config_elem,
                    p_asn1_ctx))
        {
            return SIM_FAILURE;
        }

        rtxDListAppendNode(
                p_trg_rlc_bearer_list,
                p_rlc_bearer_node);

    }

    return SIM_SUCCESS;
}


//Container Changes

void fill_drx_long_cycle_start_offset_time
(
 drx_config_long_cycle_start_offset_config_t*   p_src_time,
 nr_rrc_DRX_Config_drx_LongCycleStartOffset*    p_trg_time
 )
{

    if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS10)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms10;
        p_trg_time->u.ms10 = p_src_time->ms10;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS20)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms20;
        p_trg_time->u.ms20 = p_src_time->ms20;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS32)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms32;
        p_trg_time->u.ms32 = p_src_time->ms32;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS40)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms40;
        p_trg_time->u.ms40 = p_src_time->ms40;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS60)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms60;
        p_trg_time->u.ms60 = p_src_time->ms60;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS64)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms64;
        p_trg_time->u.ms64 = p_src_time->ms64;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS70)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms70;
        p_trg_time->u.ms70 = p_src_time->ms70;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS80)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms80;
        p_trg_time->u.ms80 = p_src_time->ms80;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS128)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms128;
        p_trg_time->u.ms128 = p_src_time->ms128;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS160)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms160;
        p_trg_time->u.ms160 = p_src_time->ms160;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS256)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms256;
        p_trg_time->u.ms256 = p_src_time->ms256;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS320)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms320;
        p_trg_time->u.ms320 = p_src_time->ms320;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS512)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms512;
        p_trg_time->u.ms512 = p_src_time->ms512;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS640)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms640;
        p_trg_time->u.ms640 = p_src_time->ms640;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS1024)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms1024;
        p_trg_time->u.ms1024 = p_src_time->ms1024;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS1280)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms1280;
        p_trg_time->u.ms1280 = p_src_time->ms1280;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS2048)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms2048;
        p_trg_time->u.ms2048 = p_src_time->ms2048;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS2560)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms2560;
        p_trg_time->u.ms2560 = p_src_time->ms2560;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS5120)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms5120;
        p_trg_time->u.ms5120 = p_src_time->ms5120;
    }
    else if (p_src_time->t ==
            T_DRX_CONFIG_DRX_LONG_CYCLE_START_OFFSET_MS10240)
    {
        p_trg_time->t = T_nr_rrc_DRX_Config_drx_LongCycleStartOffset_ms10240;
        p_trg_time->u.ms10240 = p_src_time->ms10240;
    }
    else
    {
        /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING,
                "Incorrect DRX config long cycle start offset received [%d]",
                p_src_time->t);*/
        LOG_TRACE("%s:Incorrect DRX config long cycle start offset received [%d]",__FUNCTION__,p_src_time->t);
    }

}



sim_return_val_et fill_mac_cell_group_drx_config
(
 nr_drx_config_t*     p_src_drx_config,
 nr_rrc_DRX_Config**  p_p_trg_drx_config,
 OSCTXT*              p_asn1_ctx
 )
{
    nr_rrc_DRX_Config*  p_trg_drx_config = PNULL;

    *p_p_trg_drx_config = rtxMemAllocType(p_asn1_ctx,
            nr_rrc_DRX_Config);

    if (PNULL == *p_p_trg_drx_config)
    {
        //RRC_DU_F1AP_TRACE(DU_F1AP_WARNING," ASN Malloc failed..!!!\n");
        LOG_TRACE("%s:ASN Malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }

    p_trg_drx_config = *p_p_trg_drx_config;

    asn1Init_nr_rrc_DRX_Config(p_trg_drx_config);

    /* DRX On Duration Timer */
    {
        if (p_src_drx_config->drx_onDurationTimer.bitmask &
                DRX_CONFIG_ON_DURATION_TIMER_SUB_MSEC)
        {
            p_trg_drx_config->drx_onDurationTimer.t =
                T_nr_rrc_DRX_Config_drx_onDurationTimer_subMilliSeconds;

            p_trg_drx_config->drx_onDurationTimer.u.subMilliSeconds =
                p_src_drx_config->drx_onDurationTimer.sub_msec;

        }
        if (p_src_drx_config->drx_onDurationTimer.bitmask &
                DRX_CONFIG_ON_DURATION_TIMER_MSEC)
        {
            p_trg_drx_config->drx_onDurationTimer.t =
                T_nr_rrc_DRX_Config_drx_onDurationTimer_milliSeconds;

            p_trg_drx_config->drx_onDurationTimer.u.milliSeconds =
                p_src_drx_config->drx_onDurationTimer.msec;
        }

    }

    /* DRX Inactivity Timer */
    {
        p_trg_drx_config->drx_InactivityTimer =
            p_src_drx_config->drx_InactivityTimer;
    }

    /* HARQ RTT TImer DL and UL */
    {
        p_trg_drx_config->drx_HARQ_RTT_TimerDL =
            p_src_drx_config->drx_HARQ_RTT_TimerDL;

        p_trg_drx_config->drx_HARQ_RTT_TimerUL =
            p_src_drx_config->drx_HARQ_RTT_TimerUL;
    }

    /* DRX Retransmission Timer DL and UL */
    {
        p_trg_drx_config->drx_RetransmissionTimerDL =
            p_src_drx_config->drx_RetransmissionTimerDL;

        p_trg_drx_config->drx_RetransmissionTimerUL =
            p_src_drx_config->drx_RetransmissionTimerUL;
    }

    /* DRX Long Cycle start offset */
    {
        fill_drx_long_cycle_start_offset_time(
                &p_src_drx_config->drx_LongCycleStartOffset,
                &p_trg_drx_config->drx_LongCycleStartOffset);

    }

    /* Short DRX Timer */
    if (p_src_drx_config->bitmask & NR_DRX_CONFIG_SHORT_DRX_PRESENT)
    {
        p_trg_drx_config->m.shortDRXPresent = 1;

        p_trg_drx_config->shortDRX.drx_ShortCycle =
            p_src_drx_config->shortDRX.drx_short_cycle;

        p_trg_drx_config->shortDRX.drx_ShortCycleTimer =
            p_src_drx_config->shortDRX.drx_short_cycle_timer;
    }

    /* DRX Slot Offset */
    {
        p_trg_drx_config->drx_SlotOffset = p_src_drx_config->drx_SlotOffset;
    }

    return SIM_SUCCESS;
}



void fill_sched_req_to_add_mod_list
(
 scheduling_req_to_add_mod_t*        p_src_list_elem,
 nr_rrc_SchedulingRequestToAddMod*   p_trg_list_elem
 )
{
    p_trg_list_elem->schedulingRequestId = p_src_list_elem->schedulingRequestId;

    if (p_src_list_elem->bitmask & SCHED_REQ_TO_ADD_MOD_SR_PROHIBIT_TIMER_PRESENT)
    {
        p_trg_list_elem->m.sr_ProhibitTimerPresent  = 1;

        p_trg_list_elem->sr_ProhibitTimer = p_src_list_elem->srProhibitTimer;
    }

    p_trg_list_elem->sr_TransMax = p_src_list_elem->srTransMax;

}



sim_return_val_et fill_phr_config_setup
(
 phr_config_setup_t*  p_src_phr_config,
 nr_rrc_PHR_Config*   p_trg_phr_config,
 OSCTXT*              p_asn1_ctx
 )
{
    /* PHR periodic timer */
    p_trg_phr_config->phr_PeriodicTimer =
        p_src_phr_config->phr_periodic_timer;

    /* PHR Prohibit timer */
    p_trg_phr_config->phr_ProhibitTimer =
        p_src_phr_config->phr_prohibit_timer;

    /* PHR Tx Power change factor */
    p_trg_phr_config->phr_Tx_PowerFactorChange =
        p_src_phr_config->phr_tx_power_factor_change;

    /* multiple PHR MAC control element */
    p_trg_phr_config->multiplePHR = p_src_phr_config->multiple_phr_enabled;

    /* PHR type2 for SpCell */
    p_trg_phr_config->dummy = p_src_phr_config->phr_type2_Spcell;

    /* PUCCH sCells */
    p_trg_phr_config->phr_Type2OtherCell = p_src_phr_config->phr_type2_other_cell;

    /* PHR Mode for other CG */
    p_trg_phr_config->phr_ModeOtherCG = p_src_phr_config->phr_mode_otherCG;

    return SIM_SUCCESS;

}


sim_return_val_et f1ap_encode_mac_cell_group_config
(
 mac_cell_group_config_t*       p_src_msg,
 nr_rrc_MAC_CellGroupConfig*    p_trg_msg,
 OSCTXT*                        p_asn1_ctx
 )
{
    UInt8   index = F1AP_NULL;

    /* MAC DRX config */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_DRX_CONFIG_PRESENT)
    {
        p_trg_msg->m.drx_ConfigPresent = 1;

        if (p_src_msg->drx_config.bitmask & DRX_CONFIG_SETUP_PRESENT)
        {
            p_trg_msg->drx_Config.t = T_nr_rrc_MAC_CellGroupConfig_drx_Config_setup;

            /* Populate mac drx config params */
            if (SIM_FAILURE == fill_mac_cell_group_drx_config(
                        &p_src_msg->drx_config.config,
                        &p_trg_msg->drx_Config.u.setup,
                        p_asn1_ctx))
            {
                return SIM_FAILURE;
            }

        }
        else if (p_src_msg->drx_config.bitmask & DRX_CONFIG_RELEASE_PRESENT)
        {
            p_trg_msg->drx_Config.t = T_nr_rrc_MAC_CellGroupConfig_drx_Config_release;
        }
        else
        {
            /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING,
                    "Incorrect DRX Config type received\n");*/
            LOG_TRACE("%s:Incorrect DRX Config type received",__FUNCTION__);
            return SIM_FAILURE;
        }

    }

    /* MAC scheduling request config */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_SCHED_REQ_CONFIG_PRESENT)
    {
        asn1Init_nr_rrc_SchedulingRequestConfig(&p_trg_msg->schedulingRequestConfig);

        p_trg_msg->m.schedulingRequestConfigPresent = 1;

        if (p_src_msg->schedulingRequestConfig.bitmask &
                SCHED_REQ_CONFIG_SCHED_REQ_TO_ADD_MOD_LIST_PRESENT)
        {
            p_trg_msg->schedulingRequestConfig.m.schedulingRequestToAddModListPresent = 1;

            OSRTDListNode*                      p_trg_node = PNULL;
            nr_rrc_SchedulingRequestToAddMod*   p_trg_list_elem = PNULL;
            nr_rrc_SchedulingRequestConfig_schedulingRequestToAddModList*
                p_trg_list = PNULL;

            p_trg_list = &p_trg_msg->schedulingRequestConfig.schedulingRequestToAddModList;

            asn1Init_nr_rrc_SchedulingRequestConfig_schedulingRequestToAddModList(p_trg_list);

            for (index = 0; index < p_src_msg->schedulingRequestConfig.schedReqToAddModList.count;
                    index ++)
            {
                rtxDListAllocNodeAndData(p_asn1_ctx,
                        nr_rrc_SchedulingRequestToAddMod,
                        &p_trg_node,
                        &p_trg_list_elem);

                if (PNULL == p_trg_node)
                {
                    /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING,"ASN allocation failed.\n");*/
                    LOG_TRACE("%s:ASN allocation failed.",__FUNCTION__);
                    return SIM_FAILURE;
                }

                asn1Init_nr_rrc_SchedulingRequestToAddMod(p_trg_list_elem);

                fill_sched_req_to_add_mod_list(
                        &p_src_msg->schedulingRequestConfig.
                        schedReqToAddModList.schedReqToAddMod[index],
                        p_trg_list_elem);

                rtxDListAppendNode(p_trg_list,p_trg_node);
            }

        }

        if (p_src_msg->bitmask & SCHED_REQ_CONFIG_SCHED_REQ_TO_REL_LIST_PRESENT)
        {
            p_trg_msg->schedulingRequestConfig.m.schedulingRequestToReleaseListPresent = 1;

            nr_rrc_SchedulingRequestConfig_schedulingRequestToReleaseList*
                p_trg_list = PNULL;

            scheduling_req_to_release_list_t*   p_src_rel_list = PNULL;

            p_trg_list = &p_trg_msg->schedulingRequestConfig.schedulingRequestToReleaseList;
            asn1Init_nr_rrc_SchedulingRequestConfig_schedulingRequestToReleaseList(
                    p_trg_list);

            p_src_rel_list = &p_src_msg->schedulingRequestConfig.schedReqToReleaseList;

            p_trg_list->n = p_src_rel_list->count;

            for (index = 0; index < p_src_rel_list->count; index++)
            {
                p_trg_list->elem[index] = p_src_rel_list->schedReqId[index];

            }
        }
    }

    /* BSR Config */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_BSR_CONFIG_PRESENT)
    {
        p_trg_msg->m.bsr_ConfigPresent = 1;

        asn1Init_nr_rrc_BSR_Config(&p_trg_msg->bsr_Config);

        p_trg_msg->bsr_Config.periodicBSR_Timer = p_src_msg->bsrConfig.periodicBSRTimer;

        p_trg_msg->bsr_Config.retxBSR_Timer = p_src_msg->bsrConfig.retxBSRTimer;

        if (p_src_msg->bsrConfig.bitmask &
                BSR_CONFIG_LC_SR_DELAY_TIMER_PRESENT)
        {
            p_trg_msg->bsr_Config.m.logicalChannelSR_DelayTimerPresent = 1;

            p_trg_msg->bsr_Config.logicalChannelSR_DelayTimer =
                p_src_msg->bsrConfig.logicalChannelSRDelayTimer;
        }
    }

    /* Tag Config */

    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_TAG_CONFIG_PRESENT)
    {
        p_trg_msg->m.tag_ConfigPresent = 1;

        asn1Init_nr_rrc_TAG_Config(&p_trg_msg->tag_Config);

        if (p_src_msg->tagConfig.bitmask &
                TAG_CONFIG_TAG_TO_ADD_MOD_LIST_PRESENT)
        {
            p_trg_msg->tag_Config.m.tag_ToAddModListPresent = 1;

            nr_rrc_TAG_Config_tag_ToAddModList* p_trg_list = PNULL;
            tag_to_add_mod_list_t*              p_src_list = PNULL;
            /*  ASN1550 changes start */
            nr_rrc_TAG_nr*                p_trg_elem = PNULL;
            /*ASN1550 changes stop */
            OSRTDListNode*                      p_trg_node = PNULL;

            p_src_list = &p_src_msg->tagConfig.tagToAddModList;

            p_trg_list = &p_trg_msg->tag_Config.tag_ToAddModList;

            asn1Init_nr_rrc_TAG_Config_tag_ToAddModList(p_trg_list);

            for (index = 0; index < p_src_list->count ; index ++)
            {
                rtxDListAllocNodeAndData(
                        p_asn1_ctx,
                        /*  ASN1550 changes start */
                        nr_rrc_TAG_nr,
                        /*ASN1550 changes stop */
                        &p_trg_node,
                        &p_trg_elem);

                if (PNULL == p_trg_node)
                {
                    /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING,"ASN allocation failed.\n");*/
                    LOG_TRACE("%s:ASN allocation failed.",__FUNCTION__);
                    return SIM_FAILURE;
                }

                /*  ASN1550 changes start */
                asn1Init_nr_rrc_TAG_nr(p_trg_elem);
                /*ASN1550 changes stop */

                p_trg_elem->tag_Id = p_src_list->tagToAddMod[index].tagId;

                p_trg_elem->timeAlignmentTimer =
                    p_src_list->tagToAddMod[index].timeAlignmentTimer;

                rtxDListAppendNode(p_trg_list, p_trg_node);

            }
        }
        if (p_src_msg->tagConfig.bitmask & TAG_CONFIG_TAG_TO_REL_LIST_PRESENT)
        {
            p_trg_msg->tag_Config.m.tag_ToReleaseListPresent = 1;

            p_trg_msg->tag_Config.tag_ToReleaseList.n =
                p_src_msg->tagConfig.tagToReleaseList.count;

            for (index = 0; index <p_src_msg->tagConfig.tagToReleaseList.count;
                    index ++)
            {
                p_trg_msg->tag_Config.tag_ToReleaseList.elem[index] =
                    p_src_msg->tagConfig.tagToReleaseList.tag_id[index];
            }
        }
    }

    /* PHR config */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_PHR_CONFIG_PRESENT)
    {
        p_trg_msg->m.phr_ConfigPresent = 1;

        asn1Init_nr_rrc_MAC_CellGroupConfig_phr_Config(&p_trg_msg->phr_Config);

        if (p_src_msg->phrConfig.bitmask & PHR_CONFIG_RELEASE_PRESENT)
        {
            p_trg_msg->phr_Config.t = T_nr_rrc_MAC_CellGroupConfig_phr_Config_release;
        }
        else if (p_src_msg->phrConfig.bitmask & PHR_CONFIG_SETUP_PRESENT)
        {
            p_trg_msg->phr_Config.t = T_nr_rrc_MAC_CellGroupConfig_phr_Config_setup;

            p_trg_msg->phr_Config.u.setup = rtxMemAllocType(p_asn1_ctx,
                    nr_rrc_PHR_Config);

            if (PNULL == p_trg_msg->phr_Config.u.setup)
            {
                /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING," ASN Malloc failed..!!!\n");*/
                LOG_TRACE("%s:ASN Malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }
	    asn1Init_nr_rrc_PHR_Config(p_trg_msg->phr_Config.u.setup);
	
            if (SIM_FAILURE == fill_phr_config_setup(
                        &p_src_msg->phrConfig.phr_setup,
                        p_trg_msg->phr_Config.u.setup,
                        p_asn1_ctx))
            {
                return SIM_FAILURE;
            }
        }
        else
        {
            /*RRC_DU_F1AP_TRACE(DU_F1AP_WARNING,
                    "Incorrect PHR config type received\n");*/
            LOG_TRACE("%s:Incorrect PHR config type received.",__FUNCTION__);
            return SIM_FAILURE;
        }
    }

    /* Skip UL Tx Dynamic */
    p_trg_msg->skipUplinkTxDynamic = p_src_msg->skipULTxDynamic;

    /* CSI_Mask_v1530 */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_V2_EXT_PRESENT)
    {
        p_trg_msg->m._v2ExtPresent = 1;
        p_trg_msg->m.csi_Mask_v1530Present = 1;
        
        p_trg_msg->csi_Mask_v1530 = p_src_msg->csi_Mask_v1530;
    }

    /* dataInactivityTimer_v1530 */
    if (p_src_msg->bitmask & MAC_CELL_GROUP_CONFIG_DATA_INACTIVITY_TIMER_V1530_PRESENT)
    {
       p_trg_msg->m.dataInactivityTimer_v1530Present = 1;
       asn1Init_nr_rrc_MAC_CellGroupConfig_dataInactivityTimer_v1530(&p_trg_msg->dataInactivityTimer_v1530);
       
       if(p_src_msg->dataInactivityTimer_v1530.bitmask & DATA_INACTIVITY_TIMER_V1530_RELEASE)
       {
         p_trg_msg->dataInactivityTimer_v1530.t =  T_nr_rrc_MAC_CellGroupConfig_dataInactivityTimer_v1530_release ;
       }
       else if(p_src_msg->dataInactivityTimer_v1530.bitmask & DATA_INACTIVITY_TIMER_V1530_SETUP)
       {
         p_trg_msg->dataInactivityTimer_v1530.t =  T_nr_rrc_MAC_CellGroupConfig_dataInactivityTimer_v1530_setup ;
         p_trg_msg->dataInactivityTimer_v1530.u.setup = p_src_msg->dataInactivityTimer_v1530.setup;
       }

             
    }

    return SIM_SUCCESS;
}

                  




sim_return_val_et
f1ap_encode_nr_cell_group_config
(
   OSCTXT               *p_asn1_ctx,
   cell_group_config_t* p_src_cell_group_config,
   UInt8*               p_encodedmsg,
   UInt32*              p_encodedmsg_len
)
{
    sim_return_val_et           retVal                   = SIM_FAILURE;
    UInt8                       index                    = 0;
    nr_rrc_CellGroupConfig      trg_cell_group_config;

    do 
    {

        asn1Init_nr_rrc_CellGroupConfig(&trg_cell_group_config);

        trg_cell_group_config.cellGroupId = p_src_cell_group_config->cellGroupId;

        /* Bearer to add/mod list */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_BEARER_ADD_MOD_LIST_PRESENT)
        {
            trg_cell_group_config.m.rlc_BearerToAddModListPresent = 1;

            if (SIM_FAILURE == f1ap_encode_rlc_bearer_list(
                        &p_src_cell_group_config->bearerAddModList,
                        &trg_cell_group_config.rlc_BearerToAddModList,
                        p_asn1_ctx))
            {
                LOG_TRACE("%s:Encoding of RLC bearer list Failed.",__FUNCTION__);
                break;
            }
            
        }

        /* Bearer to release list */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_BEARER_RELEASE_LIST_PRESENT)
        {
            asn1Init_nr_rrc_CellGroupConfig_rlc_BearerToReleaseList(
                    &trg_cell_group_config.rlc_BearerToReleaseList);

            trg_cell_group_config.m.rlc_BearerToReleaseListPresent = 1;

            trg_cell_group_config.rlc_BearerToReleaseList.n =
                p_src_cell_group_config->bearerReleaseList.count;

            for (index = 0;
                 index < p_src_cell_group_config->bearerReleaseList.count; 
                 index++)
            {
                trg_cell_group_config.rlc_BearerToReleaseList.elem[index] =
                    p_src_cell_group_config->bearerReleaseList.lc_id[index];
            }
        }

        /* MAC Cell Group Config */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_MAC_CELL_GROUP_CONFIG_PRESENT)
        {
            asn1Init_nr_rrc_MAC_CellGroupConfig(
                      &trg_cell_group_config.mac_CellGroupConfig);

            trg_cell_group_config.m.mac_CellGroupConfigPresent = 1;

//Container Changes
            if (SIM_FAILURE == f1ap_encode_mac_cell_group_config(
                        &p_src_cell_group_config->macCellGroupConfig,
                        &trg_cell_group_config.mac_CellGroupConfig,
                        p_asn1_ctx))
            {
                LOG_TRACE("%s:Cell group config failed.",__FUNCTION__);
                break;
            }
            
        }

        /* Physical cell group config info */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_PHY_CELL_GROUP_CONFIG_PRESENT)
        {
            asn1Init_nr_rrc_PhysicalCellGroupConfig(
                    &trg_cell_group_config.physicalCellGroupConfig);

            trg_cell_group_config.m.physicalCellGroupConfigPresent = 1;
            f1ap_encode_phy_cell_group_config(
                    &p_src_cell_group_config->phyCellGroupConfig,
                    &trg_cell_group_config.physicalCellGroupConfig);
        }

#if 0   //Container Changes:TODO

        /* Special Cell Config */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_SPCELL_CONFIG_PRESENT)
        {
            asn1Init_nr_rrc_SpCellConfig(
                    &trg_cell_group_config.spCellConfig);

            trg_cell_group_config.m.spCellConfigPresent = 1;

            if (SIM_FAILURE == f1ap_encode_sp_cell_config(
                    &p_src_cell_group_config->spCellConfig,
                    &trg_cell_group_config.spCellConfig,
                    p_asn1_ctx))
            {

                LOG_TRACE("%s:Encoding of Spcell config Failed.",__FUNCTION__);
                break;
            }
            
        }

        /* Scell to add mod list */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_SCELL_TO_ADD_MOD_LIST_PRESENT)
        {
            trg_cell_group_config.m.sCellToAddModListPresent = 1;

            if (SIM_FAILURE == f1ap_encode_scell_config_list(
                        &p_src_cell_group_config->sCellToAddModList,
                        &trg_cell_group_config.sCellToAddModList,
                        p_asn1_ctx))
            {
                LOG_TRACE("%s:Encoding of Scell to add/mod list Failed",__FUNCTION__);
                break;
            }
            
        }
#endif

        /* Scell to release list */
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_SCELL_TO_RELEASE_LIST_PRESENT)
        {
            asn1Init_nr_rrc_CellGroupConfig_sCellToReleaseList(
                    &trg_cell_group_config.sCellToReleaseList);

            trg_cell_group_config.m.sCellToReleaseListPresent = 1;

            trg_cell_group_config.sCellToReleaseList.n =
                p_src_cell_group_config->sCellToReleaseList.count;

            for (index = 0;
                 index < p_src_cell_group_config->sCellToReleaseList.count; 
                 index++)
            {

                trg_cell_group_config.sCellToReleaseList.elem[index] =
                    p_src_cell_group_config->sCellToReleaseList.scell_index[index];
            }
        }

        /* uplinkTxDirectCurrent_v1530 */   /* new ASN Changes*/ 
        if (p_src_cell_group_config->bitmask & 
                CELL_GROUP_CONFIG_V2_EXT_PRESENT)
        {
            trg_cell_group_config.m._v2ExtPresent = 1;
            trg_cell_group_config.m.reportUplinkTxDirectCurrent_v1530Present = 1;
            trg_cell_group_config.reportUplinkTxDirectCurrent_v1530 = p_src_cell_group_config->reportUplinkTxDirectCurrent_v1530;
        }

        /* ASN Encode message */
        pu_setBuffer(p_asn1_ctx, p_encodedmsg, CELL_GROUP_CONFIG_BUF_LEN, FALSE);

        if (0 != asn1PE_nr_rrc_CellGroupConfig(p_asn1_ctx, &trg_cell_group_config))
        {
            char buff[500];
            rtxErrGetTextBuf(p_asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("%s:ASN1 encoding of Cell group config failed",__FUNCTION__);
            break;
        }
        else
        {
            *p_encodedmsg_len = (U32)pe_GetMsgLen(p_asn1_ctx);
            retVal = SIM_SUCCESS;

            asn1Print_nr_rrc_CellGroupConfig("DU_F1AP cell_group_config", &trg_cell_group_config);
        }

    }while(0);

    return retVal;
}


/*******************************************************************************
 * Function Name  : populate_f1ap_drbs_setup_list
 * Description    : This function encodes UE Context Setup Failure
 * Inputs         : f1ap_adpt_ue_context_setup_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Response
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context response buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/
sim_return_val_et
populate_f1ap_drbs_setup_list
(
    f1ap_adpt_drbs_setup_list_element_t*    p_src_drb_elem, 
    f1ap_DRBs_Setup_List_element*           p_trg_drb_elem,
    OSCTXT*                                 p_asn1_ctx
)
{
    f1ap_adpt_dl_tunnels_to_be_setup_list_element_t*    
                                    p_src_dl_tunnel_elem = F1AP_NULL;
    f1ap_DLUPTNLInformation_ToBeSetup_Item*  p_dl_tunnel_elem     = F1AP_NULL;
    OSRTDListNode*                  p_tunnel_node        = F1AP_NULL;
    UInt16                          tunnel_index         = 0;

    
    asn1Init_f1ap_DRBs_Setup_List_element(p_trg_drb_elem);

    p_trg_drb_elem->id          = ASN1V_f1ap_id_DRBs_Setup_Item;
    p_trg_drb_elem->criticality = f1ap_ignore;

    p_trg_drb_elem->value.t = T43f1ap___f1ap_DRBs_Setup_ItemIEs_1;

    p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1 =
                rtxMemAllocType(p_asn1_ctx, 
                                f1ap_DRBs_Setup_Item);

    if (F1AP_NULL ==
            p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1)
                       
    {
  
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }

    asn1Init_f1ap_DRBs_Setup_Item(
            p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1);

    p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1->dRBID =
        p_src_drb_elem->drb_id;
    
    p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1->lCID =
        p_src_drb_elem->lCID;

    asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_List(
            &p_trg_drb_elem->value.u._f1ap_DRBs_Setup_ItemIEs_1->
                      dLUPTNLInformation_ToBeSetup_List); 

    for (tunnel_index = 0; 
         tunnel_index < p_src_drb_elem->dl_tunnels_list.count; 
         tunnel_index++)
    {
        p_src_dl_tunnel_elem = 
            &p_src_drb_elem->dl_tunnels_list.dl_tunnel_to_setup[tunnel_index];

        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                f1ap_DLUPTNLInformation_ToBeSetup_Item,
                &p_tunnel_node,
                &p_dl_tunnel_elem);

        if (F1AP_NULL == p_tunnel_node)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            return SIM_FAILURE;
        }

        asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_Item(p_dl_tunnel_elem);

        asn1Init_f1ap_UPTransportLayerInformation(
                &p_dl_tunnel_elem->dLUPTNLInformation);

        p_dl_tunnel_elem->dLUPTNLInformation.t = p_src_dl_tunnel_elem->type;

        p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel = rtxMemAllocType(p_asn1_ctx,
                                            f1ap_GTPTunnel);

        if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }


        asn1Init_f1ap_GTPTunnel(p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel);


        if(p_dl_tunnel_elem->dLUPTNLInformation.t == 1)
        {
            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts =
                p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs;

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs);

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits = 
                p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length*8;

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data
                = rtxMemAlloc(p_asn1_ctx,
                        p_src_dl_tunnel_elem->u.gtp_tunnelep.
                        transport_address_length);

            if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->
                    transportLayerAddress.data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_layer_address,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length);

            rtxDListAppendNode(&p_trg_drb_elem->value.u.
                    _f1ap_DRBs_Setup_ItemIEs_1->dLUPTNLInformation_ToBeSetup_List,
                    p_tunnel_node);

        }
    }

    return SIM_SUCCESS;

}
/*******************************************************************************
 * Function Name  : populate_asn_cause_type_and_value
 * Description    : This function encodes the cause received from adaptation
 *                  layer to ASN encoded format.
 * Inputs         : f1ap_adpt_cause_t* : p_src_adpt_cause
 *                  Pointer to F1AP Cause received from adaptation layer
 *                  f1ap_Cause*        : p_encoded_msg
 *                  Pointer to receive ASN encoded cause.
 * Outputs        : ASN Encoded F1AP Cause.
 * Returns        : None
 ******************************************************************************/
void populate_asn_cause_type_and_value
(
   f1ap_adpt_cause_t*   p_src_adpt_cause,
   f1ap_Cause*          p_trg_asn_cause
)
{
    asn1Init_f1ap_Cause(p_trg_asn_cause);

    p_trg_asn_cause->t = p_src_adpt_cause->cause_type;

    switch(p_src_adpt_cause->cause_type)
    {
        case F1_CAUSE_RADIO_NETWORK: 
        {
            p_trg_asn_cause->u.radioNetwork = p_src_adpt_cause->u.radio_network; 
            break;
        }

        case F1_CAUSE_TRANSPORT:  
        {
            p_trg_asn_cause->u.transport = p_src_adpt_cause->u.transport;
            break;
        }

        case F1_CAUSE_PROTOCOL:
        {
            p_trg_asn_cause->u.protocol = p_src_adpt_cause->u.protocol;
            break;
        }

        case F1_CAUSE_MISC:
        {
            p_trg_asn_cause->u.misc = p_src_adpt_cause->u.misc;
            break;
        }

        default:
        {
            LOG_TRACE("%s:Invalid cause type received:.",__FUNCTION__);

            break;
        }
    }
}

/* This function encodes UE Context Setup Request */
sim_return_val_et
dusim_handle_encode_ue_context_setup_request(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
#if 0
    sim_return_val_et      retVal                  = SIM_FAILURE;
    unsigned short         index                   = 0;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_NULL;
    f1ap_UEContextSetupRequest*  
                           p_asn_msg               = F1AP_NULL;
    f1ap_UEContextSetupRequest_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_NULL;
    _f1ap_UEContextSetupRequest* 
                           src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_UEContextSetupRequest*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_UEContextSetup;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to UE Context Setup */ 
        f1ap_pdu.u.initiatingMessage->value.t = T1f1ap__uEContextSetup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_UEContextSetupRequest);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextSetupRequest(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.uEContextSetup
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        if (src_asn_msg->bitmask & UE_CTX_SETUP_REQ_DU_F1AP_ID_PRESENT)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate PSCell ID */
        if (src_asn_msg->bitmask & UE_CTX_SETUP_REQ_PSCELL_ID_PRESENT)
        {
           f1ap_NRCGI*  p_ncgi = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_PSCell_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_3
                    = rtxMemAllocType(&asn1_ctx,f1ap_NRCGI);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_NCGI(p_protocolIE_elem->value.
                            u._f1ap_UEContextSetupRequestIEs_3);

            /* Store pointer in local variable for further processing */
            p_ncgi = p_protocolIE_elem->value.u.
                            _f1ap_UEContextSetupRequestIEs_3;

            asn1Init_f1ap_PLMN_Identity(&p_ncgi->pLMN_Identity);

            p_ncgi->pLMN_Identity.numocts 
                = src_asn_msg->pscell_id.pLMN_Identity.numocts;

            memcpy(p_ncgi->pLMN_Identity.data,
                   src_asn_msg->pscell_id.pLMN_Identity.data,
                   p_ncgi->pLMN_Identity.numocts);

            asn1Init_f1ap_NRCellIdentity(&p_ncgi->nRCellIdentity);

            p_ncgi->nRCellIdentity.numbits
                = src_asn_msg->pscell_id.nRCellIdentity.numbits;

            memcpy(p_ncgi->nRCellIdentity.data,
                   src_asn_msg->pscell_id.nRCellIdentity.data,
                   (p_ncgi->nRCellIdentity.numbits/8));

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate CU to DU RRC Container */
        {
            f1ap_CUtoDURRCInformation* p_cu_to_du_rrc_info = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CUtoDURRCInformation;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_4;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_4
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_CUtoDURRCInformation);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CUtoDURRCInformation(p_protocolIE_elem->value.
                            u._f1ap_UEContextSetupRequestIEs_4);

            /* Store pointer in local variable for further processing */
            p_cu_to_du_rrc_info = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextSetupRequestIEs_4;

            p_cu_to_du_rrc_info->uERadiocapabilities.numocts
                 = src_asn_msg->cuToDuContainer.ueCapabilityBufferLen; 

            p_cu_to_du_rrc_info->uERadiocapabilities.data 
                 = rtxMemAlloc(&asn1_ctx,
                       p_cu_to_du_rrc_info->uERadiocapabilities.numocts);
            
            if (F1AP_NULL == p_cu_to_du_rrc_info->uERadiocapabilities.data)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            memcpy((char*)p_cu_to_du_rrc_info->uERadiocapabilities.data,
                   src_asn_msg->cuToDuContainer.ueCapabilityBuffer,
                   src_asn_msg->cuToDuContainer.ueCapabilityBufferLen);

            if (src_asn_msg->bitmask & 
                    CU_TO_DU_CONTAINER_SCG_CONFIG_INFO_PRESENT)
            {
                p_cu_to_du_rrc_info->sCG_Config_Info.numocts
                     = src_asn_msg->cuToDuContainer.scgConfigInfoBufferLen; 

                p_cu_to_du_rrc_info->sCG_Config_Info.data 
                     = rtxMemAlloc(&asn1_ctx,
                             p_cu_to_du_rrc_info->sCG_Config_Info.
                                        numocts);
                
                if (F1AP_NULL == p_cu_to_du_rrc_info->sCG_Config_Info.data)
                {
                    LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                    break;
                }

                memcpy(&p_cu_to_du_rrc_info->sCG_Config_Info.data,
                       src_asn_msg->cuToDuContainer.scgConfigInfoBuffer,
                       src_asn_msg->cuToDuContainer.scgConfigInfoBufferLen);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DRX cycle */
        if (src_asn_msg->bitmask & UE_CTX_SETUP_REQ_DRX_CYCLE_PRESENT)
        {
            f1ap_DRXCycle*  p_drx_config = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_DRXCycle;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_5;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_5
                    = rtxMemAllocType(&asn1_ctx, f1ap_DRXCycle);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_5)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRXCycle(p_protocolIE_elem->value.
                            u._f1ap_UEContextSetupRequestIEs_5);

            /* Store pointer in local variable for further processing */
            p_drx_config = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextSetupRequestIEs_5;

            p_drx_config->longDRXCycleLength  
                  = src_asn_msg->drx_cycle.longDRXCycleLength;

            if (src_asn_msg->drx_cycle.bitmask &
                      F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_LEN_PRESENT)
            {
                p_drx_config->m.shortDRXCycleLengthPresent = 1;
                p_drx_config->shortDRXCycleLength 
                      = src_asn_msg->drx_cycle.shortDRXCycleLength;
            }

            if (src_asn_msg->drx_cycle.bitmask &
                      F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_TIMER_PRESENT)
            {
                p_drx_config->m.shortDRXCycleTimerPresent  = 1;
                p_drx_config->shortDRXCycleTimer  
                      = src_asn_msg->drx_cycle.shortDRXCycleTimer;
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Resource coordination transfer Container */
        {
            f1ap_ResourceCoordinationTransferContainer* 
                    p_res_coordination_transfer_container = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_ResourceCoordinationTransferContainer;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_6;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_6
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_ResourceCoordinationTransferContainer);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_6)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResourceCoordinationTransferContainer(
                    p_protocolIE_elem->value.
                            u._f1ap_UEContextSetupRequestIEs_6);

            /* Store pointer in local variable for further processing */
            p_res_coordination_transfer_container 
                    = p_protocolIE_elem->value.u.
                                _f1ap_UEContextSetupRequestIEs_6;

            p_res_coordination_transfer_container->numocts
                 = src_asn_msg->resCoordinationTransferContainer.
                                     containerLength; 

            p_res_coordination_transfer_container->data 
                 = rtxMemAlloc(&asn1_ctx, 
                         p_res_coordination_transfer_container->numocts);
            
            if (F1AP_NULL == p_res_coordination_transfer_container->data)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            memcpy((char*)p_res_coordination_transfer_container->data,
                   src_asn_msg->resCoordinationTransferContainer.containerData,
                   src_asn_msg->resCoordinationTransferContainer.
                           containerLength);

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate sCells to setup list */
        if (src_asn_msg->scellsToBeSetupList.count)
        {
            _f1ap_SCell_ToBeSetup_List_element*  p_src_scell_elem = F1AP_NULL;
            f1ap_SCell_ToBeSetup_List_element*   p_trg_scell_elem = F1AP_NULL;
            OSRTDListNode*                       p_cell_node      = F1AP_NULL;
           f1ap_NRCGI*                           p_ncgi           = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_SCell_ToBeSetup_List;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_7;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_7
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_SCell_ToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_7)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_SCell_ToBeSetup_List(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupRequestIEs_7);

            for (index = 0; 
                 index < src_asn_msg->scellsToBeSetupList.count; 
                 index++)
            {
                /* Get pointer to source scell element in the list */
                p_src_scell_elem = &src_asn_msg->scellsToBeSetupList.
                                         scell_toBe_setup[index];

                /* Allocate memory for target scell element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_SCell_ToBeSetup_List_element,
                        &p_cell_node,
                        &p_trg_scell_elem);

                if (F1AP_NULL == p_cell_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_trg_scell_elem->id          = ASN1V_f1ap_id_SCell_ID; 
                p_trg_scell_elem->criticality = f1ap_ignore; 

                p_trg_scell_elem->value.t     
                    = T28f1ap___f1ap_SCell_ToBeSetup_ItemIEs_1;

                p_trg_scell_elem->value.u._f1ap_SCell_ToBeSetup_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,f1ap_NRCGI);

                if (F1AP_NULL == p_trg_scell_elem->value.u.
                                  _f1ap_SCell_ToBeSetup_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_NCGI(p_trg_scell_elem->value.u.
                                    _f1ap_SCell_ToBeSetup_ItemIEs_1);

                /* Store pointer in local variable for further processing */
                p_ncgi = p_trg_scell_elem->value.u.
                                _f1ap_SCell_ToBeSetup_ItemIEs_1;

                asn1Init_f1ap_PLMN_Identity(&p_ncgi->pLMN_Identity);

                p_ncgi->pLMN_Identity.numocts 
                    = p_src_scell_elem->cgi.pLMN_Identity.numocts;

                memcpy(p_ncgi->pLMN_Identity.data,
                       p_src_scell_elem->cgi.pLMN_Identity.data,
                       p_ncgi->pLMN_Identity.numocts);

                asn1Init_f1ap_NRCellIdentity(&p_ncgi->nRCellIdentity);

                p_ncgi->nRCellIdentity.numbits
                    = p_src_scell_elem->cgi.nRCellIdentity.numbits;

                memcpy(p_ncgi->nRCellIdentity.data,
                       p_src_scell_elem->cgi.nRCellIdentity.data,
                       (p_ncgi->nRCellIdentity.numbits/8));

                rtxDListAppendNode(p_protocolIE_elem->value.u.
                                         _f1ap_UEContextSetupRequestIEs_7,
                                   p_cell_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate SRBs to setup list */
        if (src_asn_msg->srbsToBeSetupList.count)
        {
            _f1ap_SRBs_ToBeSetup_List_element*   p_src_srb_elem = F1AP_NULL;
            f1ap_SRBs_ToBeSetup_List_element*    p_trg_srb_elem = F1AP_NULL;
            OSRTDListNode*                       p_srb_node     = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_SRBs_ToBeSetup_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_8;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_8
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_SRBs_ToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_8)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_SRBs_ToBeSetup_List(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupRequestIEs_8);

            for (index = 0; 
                 index < src_asn_msg->srbsToBeSetupList.count; 
                 index++)
            {
                /* Get pointer to source SRB element in the list */
                p_src_srb_elem = &src_asn_msg->srbsToBeSetupList.
                                     srb_toBe_setup[index];

                /* Allocate memory for target SRB element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_SRBs_ToBeSetup_List_element,
                        &p_srb_node,
                        &p_trg_srb_elem);

                if (F1AP_NULL == p_srb_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_trg_srb_elem->id          = ASN1V_f1ap_id_SRBID; 
                p_trg_srb_elem->criticality = f1ap_reject; 

                p_trg_srb_elem->value.t     
                    = T27f1ap___f1ap_SRBs_ToBeSetup_ItemIEs_1;

                p_trg_srb_elem->value.u._f1ap_SRBs_ToBeSetup_ItemIEs_1
                    = p_src_srb_elem->srb_id; 

                rtxDListAppendNode(p_protocolIE_elem->value.u.
                                         _f1ap_UEContextSetupRequestIEs_8,
                                   p_srb_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DRBs to setup list */
        if (src_asn_msg->drbsToBeSetupList.count)
        {
            _f1ap_DRBs_ToBeSetup_List_element*   p_src_drb_elem = F1AP_NULL;
            f1ap_DRBs_ToBeSetup_List_element*    p_trg_drb_elem = F1AP_NULL;
            OSRTDListNode*                       p_drb_node     = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_DRBs_ToBeSetup_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_9;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_9
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_DRBs_ToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_9)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRBs_ToBeSetup_List(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupRequestIEs_9);

            for (index = 0; 
                 index < src_asn_msg->drbsToBeSetupList.count; 
                 index++)
            {
                /* Get pointer to source DRB element in the list */
                p_src_drb_elem = &src_asn_msg->drbsToBeSetupList.
                                         drb_to_setup_elem[index];

                /* TODO : Need to complete this once updated specs
                 * with updated grammar are available and header files
                 * are generated again. */
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

#endif
    return SIM_SUCCESS;
}


/* This function encodes UE Context Setup Failure */
sim_return_val_et
dusim_handle_encode_ue_context_setup_failure(
/* spr 24900 changes start */
      unsigned  char*   apiBuf,
/* spr 24900 changes end */      
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_NULL;
    f1ap_UEContextSetupFailure*  
                           p_asn_msg               = F1AP_NULL;
    f1ap_UEContextSetupFailure_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_NULL;
    f1ap_adpt_ue_context_setup_fail_t * 
                           src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (f1ap_adpt_ue_context_setup_fail_t*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set PDU type to UNsuccessful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

        f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_UnsuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.unsuccessfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UnsuccessfulOutcome(
                         f1ap_pdu.u.unsuccessfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.unsuccessfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_UEContextSetup;

        /* Fill criticality of message type */
        f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

        /* Set the initiating message type to UE Context Setup */ 
        f1ap_pdu.u.unsuccessfulOutcome->value.t = T2f1ap__uEContextSetup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_UEContextSetupFailure);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextSetupFailure(p_asn_msg);

        f1ap_pdu.u.unsuccessfulOutcome->value.u.uEContextSetup
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextSetupFailureIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID, if present in source container */
        if (src_asn_msg->bitmask 
                   & UE_CTX_SETUP_FAILURE_DU_F1AP_ID_PRESENT)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextSetupFailureIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Cause */
        {
            f1ap_Cause*  p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id           
                    = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality  
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextSetupFailureIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_3
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                                   _f1ap_UEContextSetupFailureIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                           _f1ap_UEContextSetupFailureIEs_3;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id           
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality  
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextSetupFailureIEs_4;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_4
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                                   _f1ap_UEContextSetupFailureIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                      p_protocolIE_elem->value.u.
                       _f1ap_UEContextSetupFailureIEs_4);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_UEContextSetupFailureIEs_4;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_NULL;
                OSRTDListNode*                        ieNode   = F1AP_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        if (src_asn_msg->bitmask & 50)
        {

            unsigned int                               count        = 0;
            f1ap_Potential_SpCell_List_element*        p_elem       = F1AP_P_NULL;
            OSRTDListNode*                             list_node    = F1AP_P_NULL;

            if ((0 == src_asn_msg->Potential_SpCell_List.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->Potential_SpCell_List.count))
            {
                LOG_TRACE("Count is not valid in modified cells list: %d", 
                        src_asn_msg->Potential_SpCell_List.count);
                break;
            }
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Potential_SpCell_List;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T47f1ap___f1ap_UEContextSetupFailureIEs_5;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_5
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_Potential_SpCell_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_5)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }

	   asn1Init_f1ap_Potential_SpCell_List(p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_5);
	
            for (count = 0; ((count < src_asn_msg->Potential_SpCell_List.count) && 
                        (count < MAX_CELL_PER_DU)); 
                    count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_Potential_SpCell_List_element,
                        &list_node,
                        &p_elem);

                if (F1AP_NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_elem->id          = ASN1V_f1ap_id_Potential_SpCell_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T48f1ap___f1ap_Potential_SpCell_ItemIEs_1;
                p_elem->value.u._f1ap_Potential_SpCell_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Potential_SpCell_Item);

                if (F1AP_NULL == p_elem->value.u._f1ap_Potential_SpCell_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

		asn1Init_f1ap_Potential_SpCell_Item(p_elem->value.u._f1ap_Potential_SpCell_ItemIEs_1);
                /* Populate served cell information */ 
                {

                    f1ap_NRCGI*  p_trg_old_cell_info = F1AP_P_NULL;
                    _f1ap_NCGI* p_src_old_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_old_cell_info = &p_elem->value.u.
                        _f1ap_Potential_SpCell_ItemIEs_1->potential_SpCell_ID;

                    /* Fetch pointer to source served cell information */
                    p_src_old_cell_info = &src_asn_msg->Potential_SpCell_List.
                        element[count].potential_SpCell_ID;

                    asn1Init_f1ap_NRCGI(p_trg_old_cell_info);


                    p_trg_old_cell_info->pLMN_Identity.numocts 
                        = p_src_old_cell_info->pLMN_Identity.numocts;

                    memcpy(p_trg_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.numocts);

                    p_trg_old_cell_info->nRCellIdentity.numbits   
                        = 36; //p_src_cell_info->nRCGI.nRCellIdentity.numbits;

                    memcpy(p_trg_old_cell_info->nRCellIdentity.data,   
                            p_src_old_cell_info->nRCellIdentity.data,
                            5);


                }

                rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_UEContextSetupFailureIEs_5,
                        list_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }



        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    return SIM_SUCCESS;
}

/* F1 UE CTXT MOD FAILURE Changes: Vikash */
/* This function encodes UE Context Modification Failure */
	sim_return_val_et
dusim_handle_encode_ue_context_mod_failure(
/* spr 24900 changes start */
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
		unsigned int    apiBufLen,
		unsigned char** p_p_encodedmsg,
		unsigned long*  p_encodedmsg_len)
{
	sim_return_val_et      			retVal                  = SIM_FAILURE;
	OSCTXT                 			asn1_ctx;
	f1ap_F1AP_PDU          			f1ap_pdu;
	OSRTDListNode*         			p_node                  = F1AP_NULL;
	f1ap_UEContextModificationFailure*  
						p_asn_msg               = F1AP_NULL;
	f1ap_UEContextModificationFailure_protocolIEs_element*  
						p_protocolIE_elem       = F1AP_NULL;
	f1ap_adpt_ue_context_mod_fail_t * 
						p_ue_ctxt_mod_fail      = F1AP_NULL;

	/* Init ASN1 context */
	if (0 != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.",
				__FUNCTION__);
		return retVal;
	}

	/* Allocate memory for target buffer */
	*p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

	if (F1AP_NULL == *p_p_encodedmsg)
	{
		LOG_TRACE("Failed to allocate memory for message buffer \n");
		return SIM_FAILURE;
	}

	memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

	do
	{
		memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

		p_ue_ctxt_mod_fail = (f1ap_adpt_ue_context_mod_fail_t *)apiBuf;

		/* Fill the values in the ASN structures that shall be encoded by
		 ** ASN Encoder */

		/* Set PDU type to UNsuccessful outcome */
		f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

		f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
				f1ap_UnsuccessfulOutcome);
		if (F1AP_NULL == f1ap_pdu.u.unsuccessfulOutcome)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}

		asn1Init_f1ap_UnsuccessfulOutcome(
				f1ap_pdu.u.unsuccessfulOutcome);

		/* Fill procedure code */
		f1ap_pdu.u.unsuccessfulOutcome->procedureCode 
			= ASN1V_f1ap_id_UEContextModification;

		/* Fill criticality of message type */
		f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

		/* Set the initiating message type to UE Context Setup */ 
		f1ap_pdu.u.unsuccessfulOutcome->value.t = T3f1ap__uEContextModification;

		p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_UEContextModificationFailure);
		if (F1AP_NULL == p_asn_msg)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}

		asn1Init_f1ap_UEContextModificationFailure(p_asn_msg);

		f1ap_pdu.u.unsuccessfulOutcome->value.u.uEContextModification
			= p_asn_msg;

		/* Compose gNB-CU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationFailure_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
			p_protocolIE_elem->criticality 
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T67f1ap___f1ap_UEContextModificationFailureIEs_1;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_1
				= p_ue_ctxt_mod_fail->gNBCUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose gNB-DU UE F1AP ID, if present in source container */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationFailure_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
			p_protocolIE_elem->criticality 
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T67f1ap___f1ap_UEContextModificationFailureIEs_2;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_2
				= p_ue_ctxt_mod_fail->gNBDUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Populate Cause */
		{
			f1ap_Cause*  p_cause = F1AP_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationFailure_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_Cause;
			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t     
				= T67f1ap___f1ap_UEContextModificationFailureIEs_3;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_3
				= rtxMemAllocType(&asn1_ctx, f1ap_Cause);

			if (F1AP_NULL == p_protocolIE_elem->value.u.
					_f1ap_UEContextModificationFailureIEs_3)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}

			/* Store pointer in local variable for further processing */
			p_cause = p_protocolIE_elem->value.u.
				_f1ap_UEContextModificationFailureIEs_3;

			/* Populate cause from the source container */
			p_cause->t = p_ue_ctxt_mod_fail->cause.cause_type;

			switch(p_ue_ctxt_mod_fail->cause.cause_type)
			{
				case F1_CAUSE_RADIO_NETWORK: 
					{
						p_cause->u.radioNetwork 
							= p_ue_ctxt_mod_fail->cause.u.radioNetwork; 
						break;
					}

				case F1_CAUSE_TRANSPORT:  
					{
						p_cause->u.transport 
							= p_ue_ctxt_mod_fail->cause.u.transport;
						break;
					}

				case F1_CAUSE_PROTOCOL:
					{
						p_cause->u.protocol 
							= p_ue_ctxt_mod_fail->cause.u.protocol;
						break;
					}

				case F1_CAUSE_MISC:
					{
						p_cause->u.misc 
							= p_ue_ctxt_mod_fail->cause.u.misc;
						break;
					}

				default:
					{
						LOG_TRACE("Invalid cause type received \n");
						break;
					}
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose criticality diagnostics, if present in source container */
		if (p_ue_ctxt_mod_fail->bitmask & 
				F1AP_ADPT_UE_CTX_MOD_FAILURE_CRIT_DIAGNOSTICS_PRESENT)
		{
			f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_NULL;
			_f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationFailure_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id           
				= ASN1V_f1ap_id_CriticalityDiagnostics;
			p_protocolIE_elem->criticality  
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T67f1ap___f1ap_UEContextModificationFailureIEs_4;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_4
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_CriticalityDiagnostics);

			if (F1AP_NULL == p_protocolIE_elem->value.u.
					_f1ap_UEContextModificationFailureIEs_4)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}

			asn1Init_f1ap_CriticalityDiagnostics(
					p_protocolIE_elem->value.u.
					_f1ap_UEContextModificationFailureIEs_4);

			/* Store pointer in local variable for further processing */
			p_trg_crit_diag = p_protocolIE_elem->value.u.
				_f1ap_UEContextModificationFailureIEs_4;

			/* Fetch pointer to source criticality diagnostics container */
			p_src_crit_diag = &p_ue_ctxt_mod_fail->criticality_diagnostics;

			if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
			{
				p_trg_crit_diag->m.procedureCodePresent = 1;

				p_trg_crit_diag->procedureCode 
					= p_src_crit_diag->procedureCode; 
			}

			if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
			{
				p_trg_crit_diag->m.triggeringMessagePresent = 1;

				p_trg_crit_diag->triggeringMessage 
					= p_src_crit_diag->triggeringMessage; 
			}

			if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
			{
				p_trg_crit_diag->m.procedureCriticalityPresent = 1;

				p_trg_crit_diag->procedureCriticality 
					= p_src_crit_diag->procedureCriticality; 
			}

			if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
			{
				f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_NULL;
				_f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_NULL;
				OSRTDListNode*                        ieNode   = F1AP_NULL;
				unsigned int                          index    = 0;

				asn1Init_f1ap_CriticalityDiagnostics_IE_List(
						&p_trg_crit_diag->iEsCriticalityDiagnostics);

				p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

				for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
							index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
						index++)
				{
					/* Fetch pointer to the source item */
					src_item = &p_src_crit_diag->iEsList.ie_info[index];

					/* Allocate memory for target element */
					rtxDListAllocNodeAndData(&asn1_ctx,
							f1ap_CriticalityDiagnostics_IE_Item,
							&ieNode,
							&trg_item);

					if (F1AP_NULL == ieNode)
					{
						LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
						break;
					}

					/* Initialize target item */
					asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

					/* Populate item attributes */
					trg_item->iECriticality = src_item->iECriticality;
					trg_item->iE_ID         = src_item->iE_ID;
					trg_item->typeOfError   = src_item->typeOfError;

					/* Add element to the list */
					rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
							ieNode);
				}
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* ASN Encode message */
		pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
				F1AP_MAX_ASN1_BUF_LEN, TRUE);

		if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
		{
			char buff[500];
			rtxErrGetTextBuf(&asn1_ctx,buff ,500);
			LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
			LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
			break;
		}
		else
		{
			*p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
			retVal = SIM_SUCCESS;
			asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
		}

	}while(0);

	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);
	return SIM_SUCCESS;
}


sim_return_val_et
encode_res_coordination_info
(
    f1ap_adpt_sgnb_resrc_coordination_info_t*  src_container,
    UInt8*                                     p_encoded_msg,
    UInt32*                                    p_encodedmsg_len
)
{
    x2ap_SgNBResourceCoordinationInformation
                        res_coordination_container;
    OSCTXT              asn1_ctx;
    sim_return_val_et  retVal     = SIM_FAILURE;

    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
       
        return retVal;
    }

    asn1Init_x2ap_SgNBResourceCoordinationInformation(
            &res_coordination_container);

    /* Fill the values in the ASN structures that shall be encoded by
       ASN Encoder */

    asn1Init_x2ap_NRCGI(&res_coordination_container.nR_CGI);

    res_coordination_container.nR_CGI.pLMN_Identity.numocts =
        src_container->ncgi.plmn_identity.numocts;

    memcpy((void*)res_coordination_container.nR_CGI.pLMN_Identity.data,
            src_container->ncgi.plmn_identity.data,
            src_container->ncgi.plmn_identity.numocts);

    res_coordination_container.nR_CGI.nRcellIdentifier.numbits = 36;

    memcpy((void*)res_coordination_container.nR_CGI.nRcellIdentifier.data,
            src_container->ncgi.nr_cellidentity.data,
            5);

    res_coordination_container.uLCoordinationInformation.numbits =
        src_container->ul_coordination_info.num_bits;

    res_coordination_container.uLCoordinationInformation.data = 
        rtxMemAlloc(&asn1_ctx, 550);

    if (F1AP_NULL == res_coordination_container.uLCoordinationInformation.data)
    {
        LOG_TRACE("Failed to allocate memory for resource coordination info \n");

        rtFreeContext(&asn1_ctx);
        return retVal;
    }

    memset((void*)res_coordination_container.uLCoordinationInformation.data, 0,
            550);

    memcpy((void*)res_coordination_container.uLCoordinationInformation.data,
            src_container->ul_coordination_info.data,
            550); 

    res_coordination_container.dLCoordinationInformation.numbits =
        src_container->dl_coordination_info.num_bits;

    res_coordination_container.dLCoordinationInformation.data = 
        rtxMemAlloc(&asn1_ctx, 550);

    if (F1AP_NULL == res_coordination_container.dLCoordinationInformation.data)
    {

        LOG_TRACE("Failed to allocate memory for resource coordination info \n");
        rtFreeContext(&asn1_ctx);
        return retVal;
    }

    memset((void*)res_coordination_container.dLCoordinationInformation.data, 0,
            550);

    memcpy((void*)res_coordination_container.dLCoordinationInformation.data,
            src_container->dl_coordination_info.data,
            550); 

    /* ASN Encode message */
    pu_setBuffer(&asn1_ctx, p_encoded_msg,
            *p_encodedmsg_len, TRUE);

    /* Encode SCG ConfigInfo container */
    if (0 != asn1PE_x2ap_SgNBResourceCoordinationInformation(
                &asn1_ctx,
                &res_coordination_container))
    {
        char buff[500];
        rtxErrGetTextBuf(&asn1_ctx,buff ,500);
        rtFreeContext(&asn1_ctx);
        //RRC_DU_F1AP_TRACE(DU_F1AP_ERROR,"BUFFER[%s] %x\n",(char*)buff,(UInt32)buff);
        return SIM_FAILURE;
    }

    /*asn1Print_x2ap_SgNBResourceCoordinationInformation(
            "Resource Coordination Info",
            &res_coordination_container);*/

    /* Populate encoded message length */
    *p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);

    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}

/* This function encodes UE Context setup Response */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_ue_context_setup_response
 * Description    : This function encodes UE Context setup response
 * Inputs         : f1ap_adpt_ue_context_mod_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Response
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen 
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context setup response
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
dusim_handle_encode_ue_context_setup_response(
/* spr 24900 changes start*/
       unsigned char*   apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    OSCTXT                        asn1_ctx;
    f1ap_F1AP_PDU                 f1ap_pdu;
    OSRTDListNode*                p_node                  = F1AP_P_NULL;
    f1ap_UEContextSetupResponse*  p_asn_msg               = F1AP_P_NULL;
    f1ap_UEContextSetupResponse_protocolIEs_element*  
                                  p_protocolIE_elem       = F1AP_P_NULL;
    f1ap_adpt_ue_context_setup_resp_t*  src_asn_msg       = F1AP_P_NULL;    
    sim_return_val_et             retVal                  = SIM_SUCCESS;
    UInt16                        index                   = F1AP_NULL;

    /* Init ASN1 context */
    if (F1AP_NULL != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                __FUNCTION__);

        return retVal;
    }
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));
        
        src_asn_msg = (f1ap_adpt_ue_context_setup_resp_t *)apiBuf;    

        /* Fill the values in the ASN structures that shall be encoded by
         * ASN Encoder */

        /* Set Pdu type to successful outcome message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                f1ap_SuccessfulOutcome);

        if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.successfulOutcome->procedureCode 
            = ASN1V_f1ap_id_UEContextSetup;

        /* Fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

        /* Set the successfuloutcome message type to UE Context 
         * Setup Response */
        f1ap_pdu.u.successfulOutcome->value.t = T2f1ap__uEContextSetup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                f1ap_UEContextSetupResponse);

        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextSetupResponse(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.u.uEContextSetup
            = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_1
                = src_asn_msg->gNBCUUEF1APID;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_2
                = src_asn_msg->gNBDUUEF1APID;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DU to CU RRC Container */
        {
            UInt32                     cell_group_config_buf_len = 0;
            UInt8*                     p_cell_group_config_buf   = F1AP_P_NULL;
            f1ap_DUtoCURRCInformation* p_du_to_cu_rrc_info       = F1AP_P_NULL;

            p_cell_group_config_buf = (UInt8*)malloc(CELL_GROUP_CONFIG_BUF_LEN);

            if (F1AP_NULL == p_cell_group_config_buf)
            {
                LOG_TRACE("%s:Unable to allocate memory for cell group config buffer",__FUNCTION__);
                break;
            }

            memset(p_cell_group_config_buf, 0, CELL_GROUP_CONFIG_BUF_LEN);

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

                free(p_cell_group_config_buf);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          
                = ASN1V_f1ap_id_DUtoCURRCInformation;
            p_protocolIE_elem->criticality 
                = f1ap_reject;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_3
                = rtxMemAllocType(&asn1_ctx, 
                        f1ap_DUtoCURRCInformation);

            if (F1AP_NULL == p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_3)
            {


                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                /* Free the allocated memory to the cell group config buffer */
                free(p_cell_group_config_buf);
                p_cell_group_config_buf = F1AP_NULL;

                break;
            }

            asn1Init_f1ap_DUtoCURRCInformation(p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_3);

            /* Store pointer in local variable for further processing */
            p_du_to_cu_rrc_info = p_protocolIE_elem->value.u.
                _f1ap_UEContextSetupResponseIEs_3;

            if (SIM_SUCCESS != f1ap_encode_nr_cell_group_config(
                                        &asn1_ctx,
                                        &src_asn_msg->du_to_cu_container,
                                        p_cell_group_config_buf,
                                        &cell_group_config_buf_len))
            {
                /* Free the allocated memory to the cell group config buffer */
                free(p_cell_group_config_buf);
                p_cell_group_config_buf = F1AP_NULL;

                break;
            }

            p_du_to_cu_rrc_info->cellGroupConfig.numocts 
                =  cell_group_config_buf_len; 

            p_du_to_cu_rrc_info->cellGroupConfig.data 
                = rtxMemAlloc(&asn1_ctx,
                        p_du_to_cu_rrc_info->cellGroupConfig.numocts);

            if (F1AP_NULL == p_du_to_cu_rrc_info->cellGroupConfig.data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

                free(p_cell_group_config_buf);
                break;
            }

            memcpy((char*)p_du_to_cu_rrc_info->cellGroupConfig.data,
                    p_cell_group_config_buf,cell_group_config_buf_len);

            /* Free the allocated memory to the cell group config buffer */
            if (F1AP_NULL != p_cell_group_config_buf)
            {
                free(p_cell_group_config_buf);
                p_cell_group_config_buf = F1AP_NULL;
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Resource coordination transfer Container, if present
         * in source container. */
        if (src_asn_msg->bitmask & 
                F1AP_ADPT_UE_CTX_SETUP_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT)
        {
            f1ap_ResourceCoordinationTransferContainer* 
                    p_res_coordination_transfer_container = F1AP_P_NULL;
            UInt8   container_buf[2048]                   = {0};
            UInt32  container_len                         = 2048;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          
                = ASN1V_f1ap_id_ResourceCoordinationTransferContainer;
            p_protocolIE_elem->criticality 
                = f1ap_ignore;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_5;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_5
                = rtxMemAllocType(&asn1_ctx, 
                        f1ap_ResourceCoordinationTransferContainer);

            if (F1AP_NULL == p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_5)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResourceCoordinationTransferContainer(
                    p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_5);

            /* Store pointer in local variable for further processing */
            p_res_coordination_transfer_container 
                = p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_5;

            /* Encode resource coordination container */
            if (SIM_SUCCESS != encode_res_coordination_info(
                                        &src_asn_msg->sgnb_resrc_cord_info,
                                        container_buf,
                                        &container_len))
            {
                LOG_TRACE("%s:Failed to populate SgNB resource coordination info",__FUNCTION__);
                break;
            }

            p_res_coordination_transfer_container->numocts = container_len;

            p_res_coordination_transfer_container->data 
                = rtxMemAlloc(&asn1_ctx,
                        p_res_coordination_transfer_container->numocts);

            if (F1AP_NULL == p_res_coordination_transfer_container->data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            memcpy((char*)p_res_coordination_transfer_container->data,
                    container_buf,
                    container_len);

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose DRBs setup list */
        if ((src_asn_msg->bitmask & 
                    F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_SETUP_LIST_PRESENT) &&
            (src_asn_msg->drbs_setup_list.count))
        {
            f1ap_adpt_drbs_setup_list_element_t*  p_src_drb_elem   = F1AP_P_NULL;
            f1ap_DRBs_Setup_List_element*         p_trg_drb_elem   = F1AP_P_NULL;
            OSRTDListNode*                        p_drb_node       = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_Setup_List;

            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_7;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_7
                = rtxMemAllocType(&asn1_ctx, 
                        f1ap_DRBs_Setup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                                        u._f1ap_UEContextSetupResponseIEs_7)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRBs_Setup_List(p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_7);

            for (index = 0; 
                 index < src_asn_msg->drbs_setup_list.count; 
                 index++)
            {
                /* Get pointer to source DRB element in the list */
                p_src_drb_elem = &src_asn_msg->drbs_setup_list.
                                    drb_to_setup[index];

                rtxDListAllocNodeAndData(
                        &asn1_ctx,
                        f1ap_DRBs_Setup_List_element,
                        &p_drb_node,
                        &p_trg_drb_elem);

                if (F1AP_NULL == p_drb_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                if (SIM_FAILURE == populate_f1ap_drbs_setup_list(
                                            p_src_drb_elem,
                                            p_trg_drb_elem,
                                            &asn1_ctx))
                {
                    LOG_TRACE("%s:Failed to populate F1AP DRBs setup list",__FUNCTION__);
                    break;
                }

                rtxDListAppendNode(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupResponseIEs_7,
                        p_drb_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DRBs failed to setup List */
        if ((src_asn_msg->bitmask &
                    F1AP_ADPT_UE_CTX_SETUP_RESP_DRBS_FAILED_TO_SETUP_LIST_PRESENT) &&
                (src_asn_msg->drbs_failed_to_setup_list.count))
        {
            f1ap_adpt_drbs_failed_to_be_setup_list_element_t*
                                                      p_src_drb_elem   = F1AP_P_NULL;
            f1ap_DRBs_FailedToBeSetup_List_element*   p_trg_drb_elem   = F1AP_P_NULL;
            f1ap_DRBs_FailedToBeSetup_Item*           p_trg_drb_item   = F1AP_P_NULL;
            OSRTDListNode*                            p_drb_node       = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupResponse_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeSetup_List;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     
                = T42f1ap___f1ap_UEContextSetupResponseIEs_9;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupResponseIEs_9
                = rtxMemAllocType(&asn1_ctx, 
                        f1ap_DRBs_FailedToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_9)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRBs_FailedToBeSetup_List(
                    p_protocolIE_elem->value.
                    u._f1ap_UEContextSetupResponseIEs_9);

            for (index = 0; 
                 index < src_asn_msg->drbs_failed_to_setup_list.count; 
                 index++)
            {
                /* Get pointer to source DRB element in the list */
                p_src_drb_elem = &src_asn_msg->drbs_failed_to_setup_list.
                                    drb_failed_to_setup[index];

                rtxDListAllocNodeAndData(
                        &asn1_ctx,
                        f1ap_DRBs_FailedToBeSetup_List_element,
                        &p_drb_node,
                        &p_trg_drb_elem);

                if (F1AP_NULL == p_drb_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_DRBs_FailedToBeSetup_List_element(
                        p_trg_drb_elem);

                p_trg_drb_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeSetup_Item;
                p_trg_drb_elem->criticality = f1ap_ignore;

                p_trg_drb_elem->value.t 
                        = T45f1ap___f1ap_DRBs_FailedToBeSetup_ItemIEs_1;

                p_trg_drb_elem->value.u._f1ap_DRBs_FailedToBeSetup_ItemIEs_1 
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_DRBs_FailedToBeSetup_Item);

                if (F1AP_NULL == p_trg_drb_elem->value.u._f1ap_DRBs_FailedToBeSetup_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_DRBs_FailedToBeSetup_Item(
                        p_trg_drb_elem->value.u._f1ap_DRBs_FailedToBeSetup_ItemIEs_1);

                p_trg_drb_item = p_trg_drb_elem->value.u._f1ap_DRBs_FailedToBeSetup_ItemIEs_1;

                p_trg_drb_item->dRBID = p_src_drb_elem->drb_id;

                /* Fill cause for failed drbs */
                if (F1AP_ADPT_UE_CTX_RESP_DRB_FAILED_TO_SETUP_CAUSE_PRESENT & 
                        p_src_drb_elem->bitmask)
                {
                    p_trg_drb_item->m.causePresent = 1;

                    populate_asn_cause_type_and_value(
                            &p_src_drb_elem->cause,
                            &p_trg_drb_item->cause);
                }

                rtxDListAppendNode(p_protocolIE_elem->value.
                                        u._f1ap_UEContextSetupResponseIEs_9,
                                   p_drb_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                DU_F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("Failed to encode UE CONTEXT SETUP RESPONSE \n");

            break;
        }
        else
        {
            *p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    return retVal;
}



