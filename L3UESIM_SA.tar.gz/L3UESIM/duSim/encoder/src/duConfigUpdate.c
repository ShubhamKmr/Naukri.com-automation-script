#if 0
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"

/* This function encodes gNB DU Configuration update Request */
sim_return_val_et
dusim_handle_encode_du_config_update_req(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = NULL;
    f1ap_GNBDUConfigurationUpdate*  
                          p_asn_msg               = NULL;
    f1ap_GNBDUConfigurationUpdate_protocolIEs_element*  
                          p_protocolIE_elem       = NULL;
    _f1ap_GNBDUConfigurationUpdate* 
                              src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBDUConfigurationUpdate*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_gNBDUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to DU Configuration 
         * update request */
        f1ap_pdu.u.initiatingMessage->value.t 
                       = T14f1ap___f1ap_GNBDUConfigurationUpdateIEs_1;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_GNBDUConfigurationUpdate);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBDUConfigurationUpdate(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.
                      u.gNBDUConfigurationUpdate = p_asn_msg;

        /* Compose served cells to add list */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

           asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T14f1ap___f1ap_GNBDUConfigurationUpdateIEs_1;
            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_1 
                                           = src_asn_msg->TransactionID;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);

        }
        /* Compose served cells to modify list */
        {

            unsigned int                            count     = 0;
            f1ap_Served_Cells_To_Add_List_element*  p_elem    = NULL;
            OSRTDListNode*                          list_node = NULL;

            if ((0 == src_asn_msg->cellsToAddList.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->cellsToAddList.count))
            {
                LOG_TRACE("Count is not valid in served cells list: %d", 
                        src_asn_msg->cellsToAddList.count);
                break;
            }
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }
            
            p_protocolIE_elem->id          = ASN1V_f1ap_id_gNB_DU_Served_Cells_List;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T14f1ap___f1ap_GNBDUConfigurationUpdateIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_GNB_DU_Served_Cells_List);

            if (NULL == p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }

            for (count = 0; ((count < src_asn_msg->cellsToAddList.count) && 
                             (count < MAX_CELL_PER_DU)); 
                                               count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_Served_Cells_To_Add_List_element,
                        &list_node,
                        &p_elem);

                if (NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_elem->id          = ASN1V_f1ap_id_GNB_DU_Served_Cells_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T15f1ap___f1ap_Served_Cells_To_Add_ItemIEs_1;
                p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Served_Cells_To_Add_Item);

                if (NULL == p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                /* Populate served cell information */ 
                {
                    f1ap_Served_Cell_Information*  p_trg_cell_info = PNULL;
                    _f1ap_Served_Cell_Information* p_src_cell_info = PNULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_cell_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Add_ItemIEs_1->served_Cell_Information;

                    /* Fetch pointer to source served cell information */
                    p_src_cell_info = &src_asn_msg->cellsToAddList.
                        cell_to_add[count].served_cell_info;

                    if (SIM_SUCCESS != populate_served_cell_information(
                                &asn1_ctx,
                                p_trg_cell_info,
                                p_src_cell_info))
                    {
                        LOG_TRACE("Failed to compose Served cell information \n");
                        return SIM_FAILURE;
                    }
                }

                /* Populate system information */
                if (src_asn_msg->cellsToAddList.cell_to_add[count].bitmask 
                        & F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT)
                {
                    f1ap_GNB_DU_System_Information*  p_trg_sys_info = PNULL;
                    _f1ap_GNB_DU_System_Information* p_src_sys_info = PNULL;

                    p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1->m.gNB_DU_System_InformationPresent = 1;

                    /* Fetch pointer to target system information container */
                    p_trg_sys_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Add_ItemIEs_1->gNB_DU_System_Information;

                    /* Fetch pointer to source system information container */
                    p_src_sys_info = &src_asn_msg->cellsToAddList.
                        cell_to_add[count].system_info;

                    populate_served_cell_system_information(
                            &asn1_ctx,
                            p_trg_sys_info,
                            p_src_sys_info);
                }

                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
            }

         }   

        /* Compose served cells to delete list */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

                
            /* TODO : Need to complete this once updated specs
             * with updated grammar are available and header files
             * are generated again. */

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal            = SIM_SUCCESS;

            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}

#if 0
/* This function encodes gNB DU Configuration update Response */
sim_return_val_et
dusim_handle_encode_du_config_update_ack(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = NULL;
    f1ap_GNBDUConfigurationUpdateAcknowledge*  
                          p_asn_msg               = NULL;
    f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element*  
                          p_protocolIE_elem       = NULL;
    _f1ap_GNBDUConfigurationUpdateAcknowledge* 
                          src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBDUConfigurationUpdateAcknowledge*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_SuccessfulOutcome);
        if (NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.successfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_gNBDUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

        /* Set the successfuloutcome message type to DU Configuration 
         * update ACK */
        f1ap_pdu.u.successfulOutcome->value.t 
                       = T1f1ap__gNBDUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_GNBDUConfigurationUpdateAcknowledge);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBDUConfigurationUpdateAcknowledge(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.
                      u.gNBDUConfigurationUpdate = p_asn_msg;

        /* Compose cells to be activated list */
        {
            //f1ap_Cells_to_be_Activated_List_element*  p_trg_elem  = NULL;   
            //_f1ap_Cells_to_be_Activated_List_element* p_src_elem  = NULL;   
            //OSRTDListNode*                            p_cell_node = NULL;   

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            /* TODO : Need to complete this once updated specs
             * with updated grammar are available and header files
             * are generated again. */

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  F1AP_DU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdateAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T19f1ap___f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cells_to_be_Activated_List);

            if (NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_GNBDUConfigurationUpdateAcknowledgeIEs_2;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = NULL;
                OSRTDListNode*                        ieNode   = NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of DU Configuration Update ACK failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}

/* This function encodes gNB DU Configuration update Failure */
sim_return_val_et
dusim_handle_encode_du_config_update_failure(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = NULL;
    f1ap_GNBDUConfigurationUpdateFailure*
                          p_asn_msg               = NULL;
    f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element*  
                          p_protocolIE_elem       = NULL;
    _f1ap_GNBDUConfigurationUpdateFailure* 
                          src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBDUConfigurationUpdateFailure*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set PDU type to unsuccessful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

        f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_UnsuccessfulOutcome);
        if (NULL == f1ap_pdu.u.unsuccessfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UnsuccessfulOutcome(
                           f1ap_pdu.u.unsuccessfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.unsuccessfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_gNBDUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

        /* Set the unsuccessfuloutcome message type to DU Configuration 
         * update failure */
        f1ap_pdu.u.unsuccessfulOutcome->value.t 
                       = T1f1ap__gNBDUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                            f1ap_GNBDUConfigurationUpdateFailure);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBDUConfigurationUpdateFailure(p_asn_msg);

        f1ap_pdu.u.unsuccessfulOutcome->value.
                      u.gNBDUConfigurationUpdate = p_asn_msg;

        /* Compose cause */
        {
            f1ap_Cause* p_cause = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T20f1ap___f1ap_GNBDUConfigurationUpdateFailureIEs_1;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateFailureIEs_1
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cause);

            if (NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBDUConfigurationUpdateFailureIEs_1)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                               _f1ap_GNBDUConfigurationUpdateFailureIEs_1;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }
            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose time to wait, if present in source container */
        if (src_asn_msg->bitmask & 
                DU_CONFIG_UPDATE_FAILURE_TIME_TO_WAIT_PRESENT)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TimeToWait;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T20f1ap___f1ap_GNBDUConfigurationUpdateFailureIEs_2;
            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateFailureIEs_2
                                           = src_asn_msg->timeToWait;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T20f1ap___f1ap_GNBDUConfigurationUpdateFailureIEs_3;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateFailureIEs_3
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBDUConfigurationUpdateFailureIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBDUConfigurationUpdateFailureIEs_3);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_GNBDUConfigurationUpdateFailureIEs_3;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = NULL;
                OSRTDListNode*                        ieNode   = NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}

#endif 
#endif

