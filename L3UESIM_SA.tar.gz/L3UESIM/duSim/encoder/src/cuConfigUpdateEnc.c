/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"
#include "du_sim_common.h"

/* This function encodes gNB CU Configuration update Request */
sim_return_val_et
dusim_handle_encode_cu_config_update_req(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    unsigned short        index                   = F1AP_NULL;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdate*  
                          p_asn_msg               = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdate_protocolIEs_element*  
                          p_protocolIE_elem       = F1AP_P_NULL;
    _f1ap_GNBCUConfigurationUpdate* 
                          src_asn_msg             = F1AP_P_NULL;
    
    /* Init ASN1 context */
    if (F1AP_NULL != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBCUConfigurationUpdate*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_gNBCUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to CU Configuration 
         * update request */
        f1ap_pdu.u.initiatingMessage->value.t 
                       = T2f1ap__gNBCUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_GNBCUConfigurationUpdate);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBCUConfigurationUpdate(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.
                      u.gNBCUConfigurationUpdate= p_asn_msg;

        /* Compose Transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdate_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T23f1ap___f1ap_GNBCUConfigurationUpdateIEs_1;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateIEs_1
                    = src_asn_msg->transaction_id; 
        }

        /* Compose cells to be activated list */
        {
            f1ap_Cells_to_be_Activated_List_element*  p_trg_elem  = F1AP_P_NULL;
            _f1ap_Cells_to_be_Activated_List_element* p_src_elem  = F1AP_P_NULL;
            OSRTDListNode*                            p_cell_node = F1AP_P_NULL;
            f1ap_Cells_to_be_Activated_List_Item*     p_trg_item  = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdate_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_Cells_to_be_Activated_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T23f1ap___f1ap_GNBCUConfigurationUpdateIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateIEs_2
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cells_to_be_Activated_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_Cells_to_be_Activated_List(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBCUConfigurationUpdateIEs_2);

            /* Traverse through the list of cells in source container
             * and populate information in target container */
            for (index = 0; 
                 index < src_asn_msg->cellsToBeActivatedList.count; 
                 index++)
            {
                /* Fetch pointer to source cell information */
                p_src_elem = &src_asn_msg->cellsToBeActivatedList.
                                 cell_to_activate[index];

                /* Allocate memory for target protocolIE element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_Cells_to_be_Activated_List_element,
                            &p_cell_node,
                            &p_trg_elem);

                if (F1AP_NULL == p_cell_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_Cells_to_be_Activated_List_element(
                            p_trg_elem);
                
                p_trg_elem->id = ASN1V_f1ap_id_Cells_to_be_Activated_List_Item;        
                p_trg_elem->criticality = f1ap_reject;       

                p_trg_elem->value.t 
                     = T14f1ap___f1ap_Cells_to_be_Activated_List_ItemIEs_1;

                p_trg_elem->value.u._f1ap_Cells_to_be_Activated_List_ItemIEs_1
                        = rtxMemAllocType(&asn1_ctx,
                                f1ap_Cells_to_be_Activated_List_Item);

                if (F1AP_NULL == p_trg_elem->value.u.
                                _f1ap_Cells_to_be_Activated_List_ItemIEs_1)
                {
                    LOG_TRACE("Failed to allocate memory\n");
                    return SIM_FAILURE;
                }

                /* Store pointer in local variable for further processing */
                p_trg_item = p_trg_elem->value.u.
                               _f1ap_Cells_to_be_Activated_List_ItemIEs_1;

                /* Populate NR-CGI for cell */
                {
                    _f1ap_NCGI*   p_src_cgi   = F1AP_P_NULL;
                    f1ap_NRCGI*   p_trg_cgi   = F1AP_P_NULL;

                    /* Get pointer to source CGI container */
                    p_src_cgi = &p_src_elem->cgi;

                    /* Get pointer to target CGI container */
                    p_trg_cgi = &p_trg_item->nRCGI;

                    p_trg_cgi->pLMN_Identity.numocts 
                                = p_src_cgi->pLMN_Identity.numocts;

                    memcpy(p_trg_cgi->pLMN_Identity.data,
                           p_src_cgi->pLMN_Identity.data,
                           p_src_cgi->pLMN_Identity.numocts);

                    p_trg_cgi->nRCellIdentity.numbits 
                                = p_src_cgi->nRCellIdentity.numbits;

                    memcpy(p_trg_cgi->nRCellIdentity.data,
                           p_src_cgi->nRCellIdentity.data,
                           5);
                }

                /* Populate NR-PCP for cell */
                if (CELL_TO_BE_ACTIVATED_PCI_PRESENT & 
                                        p_src_elem->bitmask)
                {
                    p_trg_item->nRPCI = src_asn_msg->cellsToBeActivatedList.
                                           cell_to_activate[index].pci;

                    p_trg_item->m.nRPCIPresent = 1;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cells to be deactivated list */
        {
            f1ap_Cells_to_be_Deactivated_List_element*  p_trg_elem  = F1AP_P_NULL;
            _f1ap_Cells_to_be_Deactivated_List_element* p_src_elem  = F1AP_P_NULL;
            OSRTDListNode*                              p_cell_node = F1AP_P_NULL;
            f1ap_Cells_to_be_Deactivated_List_Item*     p_trg_item  = F1AP_P_NULL;
            _f1ap_NCGI*                                 p_src_cgi   = F1AP_P_NULL;
            f1ap_NRCGI*                                 p_trg_cgi   = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdate_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_Cells_to_be_Deactivated_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T23f1ap___f1ap_GNBCUConfigurationUpdateIEs_3;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateIEs_3
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cells_to_be_Deactivated_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_Cells_to_be_Deactivated_List(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBCUConfigurationUpdateIEs_3);

            /* Traverse through the list of cells in source container
             * and populate information in target container */
            for (index = 0; 
                 index < src_asn_msg->cellsToBeDeactivatedList.count; 
                 index++)
            {
                /* Fetch pointer to source cell information */
                p_src_elem = &src_asn_msg->cellsToBeDeactivatedList.
                                  cell_to_deactivate[index];

                /* Allocate memory for target protocolIE element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_Cells_to_be_Deactivated_List_element,
                            &p_cell_node,
                            &p_trg_elem);

                if (F1AP_NULL == p_cell_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_Cells_to_be_Deactivated_List_element(
                            p_trg_elem);
                
                p_trg_elem->id          
                    = ASN1V_f1ap_id_Cells_to_be_Deactivated_List_Item;

                p_trg_elem->criticality = f1ap_reject; 

                p_trg_elem->value.t     
                   = T24f1ap___f1ap_Cells_to_be_Deactivated_List_ItemIEs_1; 

                p_trg_elem->value.u._f1ap_Cells_to_be_Deactivated_List_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Cells_to_be_Deactivated_List_Item);

                if (F1AP_NULL == p_trg_elem->value.u.
                              _f1ap_Cells_to_be_Deactivated_List_ItemIEs_1)
                {
                    LOG_TRACE("Failed to allocate memory \n");
                    return SIM_FAILURE;
                }

                /* Fetch pointer to target item */
                p_trg_item = p_trg_elem->value.u.
                                _f1ap_Cells_to_be_Deactivated_List_ItemIEs_1;

                /* Fetch pointer to target CGI container */
                p_trg_cgi = &p_trg_item->nRCGI;

                /* Fetch pointer to source CGI container */
                p_src_cgi = &p_src_elem->cgi;

                p_trg_cgi->pLMN_Identity.numocts 
                            = p_src_cgi->pLMN_Identity.numocts;

                memcpy(p_trg_cgi->pLMN_Identity.data,
                       p_src_cgi->pLMN_Identity.data,
                       p_src_cgi->pLMN_Identity.numocts);

                p_trg_cgi->nRCellIdentity.numbits 
                            = p_src_cgi->nRCellIdentity.numbits;

                memcpy(p_trg_cgi->nRCellIdentity.data,
                       p_src_cgi->nRCellIdentity.data,
                       5);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


/* This function encodes gNB CU Configuration update Response */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_cu_config_update_ack
 * Description    : This function encodes cu config update ack 
 * Inputs         : f1ap_adpt_ue_context_mod_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Response
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer.
 *                  length
 * Outputs        : ASN Encoded cu config update ack
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/


sim_return_val_et
dusim_handle_encode_cu_config_update_ack(
/* spr 24900 changes start*/
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    unsigned short        index                   = F1AP_NULL;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateAcknowledge*  
                          p_asn_msg               = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element*  
                          p_protocolIE_elem       = F1AP_P_NULL;
    f1ap_adpt_cu_config_update_resp_t* 
                          src_asn_msg             = F1AP_P_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (f1ap_adpt_cu_config_update_resp_t*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_SuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.successfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_gNBCUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

        /* Set the successfuloutcome message type to CU Configuration 
         * update ACK */
        f1ap_pdu.u.successfulOutcome->value.t 
                       = T2f1ap__gNBCUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                            f1ap_GNBCUConfigurationUpdateAcknowledge);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBCUConfigurationUpdateAcknowledge(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.
                      u.gNBCUConfigurationUpdate = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T30f1ap___f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_1;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_1
                    = src_asn_msg->trans_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cells failed to be activated list */
        if (src_asn_msg->cellsFailedToBeActivatedList.count)
        {
            f1ap_Cells_Failed_to_be_Activated_List_element*  
                                                      p_trg_elem                       = F1AP_P_NULL;
            f1ap_adpt_cells_failed_to_be_activated_list_element_t* 
                                                      p_src_elem                       = F1AP_P_NULL;
            OSRTDListNode*                            p_cell_node                      = F1AP_P_NULL;
            f1ap_Cells_Failed_to_be_Activated_List_Item*
                                                      p_trg_item                       = F1AP_P_NULL;
            f1ap_NRCGI*                               p_trg_cgi                        = F1AP_P_NULL;
            f1ap_adpt_ncgi_t *                        p_src_cgi                        = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_Cells_Failed_to_be_Activated_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T30f1ap___f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cells_Failed_to_be_Activated_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_Cells_Failed_to_be_Activated_List(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2);

            /* Traverse through the list of cells in source container
             * and populate information in target container */
            for (index = 0; 
                 index < src_asn_msg->cellsFailedToBeActivatedList.count; 
                 index++)
            {
                /* Fetch pointer to source cell information */
                p_src_elem = &src_asn_msg->cellsFailedToBeActivatedList.
                                 cellFailedToBeActivated[index];

                /* Allocate memory for target protocolIE element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_Cells_Failed_to_be_Activated_List_element,
                            &p_cell_node,
                            &p_trg_elem);

                if (F1AP_NULL == p_cell_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_Cells_Failed_to_be_Activated_List_element(
                            p_trg_elem);
               
                p_trg_elem->id          
                    = ASN1V_f1ap_id_Cells_Failed_to_be_Activated_List_Item; 

                p_trg_elem->criticality 
                    = f1ap_reject; 

                p_trg_elem->value.t     
                    = T34f1ap___f1ap_GNBCUConfigurationUpdateFailureIEs_1;

                p_trg_elem->value.u._f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Cells_Failed_to_be_Activated_List_Item);

                if (F1AP_NULL == p_trg_elem->value.u.
                        _f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_1)
                {
                    LOG_TRACE("Failed to allocate ASN memory \n");
                    return SIM_FAILURE;
                }
                 
                asn1Init_f1ap_Cells_Failed_to_be_Activated_List_Item(p_trg_elem->value.u._f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_1);
 
                /* Store pointer in local variable for further use */
                p_trg_item = p_trg_elem->value.u.
                    _f1ap_Cells_Failed_to_be_Activated_List_ItemIEs_1;

                /* Populate NR-CGI */
                {
                    /* Fetch pointer to source NCGI container */
                    p_src_cgi = &p_src_elem->cgi;

                    /* Fetch pointer to target NCGI container */
                    p_trg_cgi = &p_trg_item->nRCGI;

                    p_trg_cgi->pLMN_Identity.numocts 
                                = p_src_cgi->plmn_identity.numocts;

                    memcpy(p_trg_cgi->pLMN_Identity.data,
                           p_src_cgi->plmn_identity.data,
                           p_src_cgi->plmn_identity.numocts);

                    p_trg_cgi->nRCellIdentity.numbits 
                                = p_src_cgi->nr_cellidentity.num_bits;

                    memcpy(p_trg_cgi->nRCellIdentity.data,
                           p_src_cgi->nr_cellidentity.data,
                           5);
                }

                /* Populate cause */
                {
                    p_trg_item->cause.t = p_src_elem->cause.cause_type; 

                    if (T_f1ap_Cause_radioNetwork == p_trg_item->cause.t)
                    {
                        p_trg_item->cause.u.radioNetwork
                             = p_src_elem->cause.u.radio_network;
                    }

                    else if (T_f1ap_Cause_transport == p_trg_item->cause.t)
                    {
                        p_trg_item->cause.u.transport
                             = p_src_elem->cause.u.transport;
                    }

                    else if (T_f1ap_Cause_protocol == p_trg_item->cause.t)
                    {
                        p_trg_item->cause.u.protocol
                             = p_src_elem->cause.u.protocol;
                    }

                    else if (T_f1ap_Cause_misc == p_trg_item->cause.t) 
                    {
                        p_trg_item->cause.u.misc
                             = p_src_elem->cause.u.misc;
                    }

                    else
                    {
                        LOG_TRACE("Unknown Cause type received\n");
                        return SIM_FAILURE;
                    }
                }

            rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_2 ,p_cell_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_P_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T30f1ap___f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateAcknowledgeIEs_3;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_P_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_P_NULL;
                OSRTDListNode*                        ieNode   = F1AP_P_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}

/* This function encodes gNB CU Configuration update Response */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_cu_config_update_failure
 * Description    : This function encodes cu config update failure  
 * Inputs         : f1ap_adpt_ue_context_mod_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Response
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer.
 *                  length
 * Outputs        : ASN Encoded cu config update ack
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

/* This function encodes gNB CU Configuration update Failure */
sim_return_val_et
dusim_handle_encode_cu_config_update_failure(
/* spr 24900 changes start*/
       unsigned char*   apiBuf,
/* spr 24900 changes end */       
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                                = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                                = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateFailure*  
                          p_asn_msg                             = F1AP_P_NULL;
    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element*  
                          p_protocolIE_elem                     = F1AP_P_NULL;
    _f1ap_GNBCUConfigurationUpdateFailure* 
                          src_asn_msg                           = F1AP_P_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBCUConfigurationUpdateFailure*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set PDU type to unsuccessful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

        f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_UnsuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.unsuccessfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UnsuccessfulOutcome(
                           f1ap_pdu.u.unsuccessfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.unsuccessfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_gNBCUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

        /* Set the unsuccessfuloutcome message type to CU Configuration 
         * update failure */
        f1ap_pdu.u.unsuccessfulOutcome->value.t 
                       = T2f1ap__gNBCUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                            f1ap_GNBCUConfigurationUpdateFailure);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBCUConfigurationUpdateFailure(p_asn_msg);

        f1ap_pdu.u.unsuccessfulOutcome->value.
                      u.gNBCUConfigurationUpdate = p_asn_msg;

        /* Compose Transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T34f1ap___f1ap_GNBCUConfigurationUpdateFailureIEs_1;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateFailureIEs_1
                    = src_asn_msg->transaction_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cause */
        {
            f1ap_Cause* p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T34f1ap___f1ap_GNBCUConfigurationUpdateFailureIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateFailureIEs_2
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_Cause);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateFailureIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                               _f1ap_GNBCUConfigurationUpdateFailureIEs_2;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose time to wait, if present in source container */
        if (src_asn_msg->bitmask & F1AP_CU_CFG_UPDATE_TIME_TO_WAIT_PRESENT)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TimeToWait;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T34f1ap___f1ap_GNBCUConfigurationUpdateFailureIEs_3;
            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateFailureIEs_3
                                           = src_asn_msg->timeToWait;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  F1AP_CU_CONFIG_UPDATE_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_P_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_P_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBCUConfigurationUpdateFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T34f1ap___f1ap_GNBCUConfigurationUpdateFailureIEs_4;

            p_protocolIE_elem->value.u._f1ap_GNBCUConfigurationUpdateFailureIEs_4
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                            _f1ap_GNBCUConfigurationUpdateFailureIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                      p_protocolIE_elem->value.u.
                       _f1ap_GNBCUConfigurationUpdateFailureIEs_4);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_GNBCUConfigurationUpdateFailureIEs_4;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_P_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_P_NULL;
                OSRTDListNode*                        ieNode   = F1AP_P_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of CU Configuration update Failure failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


