
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"


/* This function encodes Reset Request */
sim_return_val_et
dusim_handle_encode_reset_request(
/* spr 24900 changes start */
       unsigned char*           apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    unsigned short        index                   = 0;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = NULL;
    f1ap_Reset*           p_asn_msg               = NULL;
    f1ap_Reset_protocolIEs_element*  
                          p_protocolIE_elem       = NULL;
    _f1ap_Reset*          src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_Reset*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_Reset;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to Reset Request */ 
        f1ap_pdu.u.initiatingMessage->value.t = T2f1ap__reset;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_Reset);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_Reset(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.reset = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_Reset_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_Reset_protocolIEs_element(p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T5f1ap___f1ap_ResetIEs_1;

            p_protocolIE_elem->value.u._f1ap_ResetIEs_1
                    = src_asn_msg->transactionId;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cause */
        {
            f1ap_Cause*  p_cause = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_Reset_protocolIEs_element,
                            &p_node,
                            &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_Reset_protocolIEs_element(p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T5f1ap___f1ap_ResetIEs_2;

            p_protocolIE_elem->value.u._f1ap_ResetIEs_2
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (NULL == p_protocolIE_elem->value.u._f1ap_ResetIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u._f1ap_ResetIEs_2;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose reset type */
        {
            f1ap_ResetType*  p_reset_type = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_Reset_protocolIEs_element,
                            &p_node,
                            &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_Reset_protocolIEs_element(p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_ResetType;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T5f1ap___f1ap_ResetIEs_3;

            p_protocolIE_elem->value.u._f1ap_ResetIEs_3
                        = rtxMemAllocType(&asn1_ctx, f1ap_ResetType);

            if (NULL == p_protocolIE_elem->value.u._f1ap_ResetIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResetType(
                     p_protocolIE_elem->value.u._f1ap_ResetIEs_3);

            /* Get pointer in the local variable for further processing */
            p_reset_type = p_protocolIE_elem->value.u._f1ap_ResetIEs_3;

            p_reset_type->t = src_asn_msg->resetType.type;

            if (F1AP_RESET_TYPE_COMPLETE == src_asn_msg->resetType.type)
            {
                p_reset_type->u.f1_Interface 
                            = src_asn_msg->resetType.u.f1_Interface; 
            }
            else if (F1AP_RESET_TYPE_PARTIAL == src_asn_msg->resetType.type)
            {
                OSRTDListNode*  conn_node       = NULL;
                f1ap_UE_associatedLogicalF1_ConnectionListRes_element*
                                p_conn_elem     = NULL;
                f1ap_UE_associatedLogicalF1_ConnectionItem*
                                p_conn_item     = NULL;
                _f1ap_UE_associatedLogicalF1_ConnectionListRes_element*
                                p_src_conn_item = NULL;

                p_reset_type->u.partOfF1_Interface
                        = rtxMemAllocType(&asn1_ctx,
                             f1ap_UE_associatedLogicalF1_ConnectionListRes);

                if (NULL == p_reset_type->u.partOfF1_Interface)
                {
                    LOG_TRACE("%s: ASN malloc failed.", __FUNCTION__);
                    break;
                }

                asn1Init_f1ap_UE_associatedLogicalF1_ConnectionListRes(
                         p_reset_type->u.partOfF1_Interface);

                for (index = 0; 
                     index < src_asn_msg->resetType.u.partOfF1_Interface.count; 
                     index++)
                {
                    /* Fetch pointer to source connection container */
                    p_src_conn_item = &src_asn_msg->resetType.u.partOfF1_Interface.
                                              ue_associated_connection[index];

                    /* Allocate memory for connection node element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                             f1ap_UE_associatedLogicalF1_ConnectionListRes_element,
                             &conn_node,
                             &p_conn_elem);

                    if (NULL == conn_node)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_UE_associatedLogicalF1_ConnectionListRes_element(
                                 p_conn_elem);

                    p_conn_elem->id          
                            = ASN1V_f1ap_id_UE_associatedLogicalF1_ConnectionItem;
                    p_conn_elem->criticality 
                            = f1ap_reject;

                    p_conn_elem->value.t     
                            = T7f1ap___f1ap_UE_associatedLogicalF1_ConnectionItemRes_1;

                    p_conn_elem->value.u._f1ap_UE_associatedLogicalF1_ConnectionItemRes_1
                            = rtxMemAllocType(&asn1_ctx, 
                                    f1ap_UE_associatedLogicalF1_ConnectionItem);

                    if (NULL == p_conn_elem->value.u.
                                    _f1ap_UE_associatedLogicalF1_ConnectionItemRes_1)
                    {
                        LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_UE_associatedLogicalF1_ConnectionItem(
                            p_conn_elem->value.u.
                                _f1ap_UE_associatedLogicalF1_ConnectionItemRes_1);

                    /* Store pointer in local variable for further processing */
                    p_conn_item = p_conn_elem->value.u.
                                    _f1ap_UE_associatedLogicalF1_ConnectionItemRes_1;

                    if (p_src_conn_item->bitmask 
                            & UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT)
                    {
                        p_conn_item->m.gNB_CU_UE_F1AP_IDPresent = 1;
                        p_conn_item->gNB_CU_UE_F1AP_ID 
                                       = p_src_conn_item->gNB_CU_F1AP_ID;
                    }

                    if (p_src_conn_item->bitmask 
                            & UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT)
                    {
                        p_conn_item->m.gNB_DU_UE_F1AP_IDPresent = 1; 
                        p_conn_item->gNB_DU_UE_F1AP_ID 
                                       = p_src_conn_item->gNB_DU_F1AP_ID; 
                    }

                    rtxDListAppendNode(p_reset_type->u.partOfF1_Interface, 
                                       conn_node);
                }
            }
            else
            {
                LOG_TRACE("Invalid reset type received in source container \n");
                break;
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


/* This function encodes Reset Ack */
sim_return_val_et
dusim_handle_encode_reset_ack(
/* spr 24900 changes start*/
       unsigned char*   apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et       retVal                  = SIM_FAILURE;
    unsigned short          index                   = 0;
    OSCTXT                  asn1_ctx;
    f1ap_F1AP_PDU           f1ap_pdu;
    OSRTDListNode*          p_node                  = NULL;
    f1ap_ResetAcknowledge*  p_asn_msg               = NULL;
    f1ap_ResetAcknowledge_protocolIEs_element*  
                            p_protocolIE_elem       = NULL;
    _f1ap_ResetAcknowledge* src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_ResetAcknowledge*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to successful outcome message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_SuccessfulOutcome);
        if (NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.successfulOutcome->procedureCode = ASN1V_f1ap_id_Reset;

        /* Fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

        /* Set the successfuloutcome message type to Reset ACK */
        f1ap_pdu.u.successfulOutcome->value.t = T2f1ap__reset;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_ResetAcknowledge);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_ResetAcknowledge(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.u.reset = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ResetAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResetAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T8f1ap___f1ap_ResetAcknowledgeIEs_1;

            p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_1
                    = src_asn_msg->transactionId;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose connection list */
	if(src_asn_msg->bitmask & F1AP_RESET_ACK_ASS0CIATE_PRESENT)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ResetAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResetAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                = ASN1V_f1ap_id_UE_associatedLogicalF1_ConnectionListResAck;
            p_protocolIE_elem->criticality 
                = f1ap_ignore;

            p_protocolIE_elem->value.t     
                = T8f1ap___f1ap_ResetAcknowledgeIEs_2;

            p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_2
                = rtxMemAllocType(&asn1_ctx, 
                        f1ap_UE_associatedLogicalF1_ConnectionListResAck);

            if (NULL == p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_UE_associatedLogicalF1_ConnectionListResAck(
                     p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_2);

            /* Populate connection list */
            {
                OSRTDListNode*  conn_node       = NULL;
                f1ap_UE_associatedLogicalF1_ConnectionListResAck_element*
                                p_conn_elem     = NULL;
                f1ap_UE_associatedLogicalF1_ConnectionItem*
                                p_conn_item     = NULL;
                _f1ap_UE_associatedLogicalF1_ConnectionListResAck_element*
                                p_src_conn_item = NULL;

                for (index = 0; 
                     index < src_asn_msg->ue_associated_connection_list.count; 
                     index++)
                {
                    /* Fetch pointer to source connection container */
                    p_src_conn_item 
                        = &src_asn_msg->ue_associated_connection_list.
                                  ue_associated_connection[index];

                    /* Allocate memory for connection node element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                         f1ap_UE_associatedLogicalF1_ConnectionListResAck_element,
                         &conn_node,
                         &p_conn_elem);

                    if (NULL == conn_node)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_UE_associatedLogicalF1_ConnectionListResAck_element(
                                 p_conn_elem);

                    p_conn_elem->id          
                            = ASN1V_f1ap_id_UE_associatedLogicalF1_ConnectionListResAck;
                    p_conn_elem->criticality 
                            = f1ap_ignore;

                    p_conn_elem->value.t     
                            = T9f1ap___f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1;

                    p_conn_elem->value.u._f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1
                            = rtxMemAllocType(&asn1_ctx, 
                                    f1ap_UE_associatedLogicalF1_ConnectionItem);

                    if (NULL == p_conn_elem->value.u.
                                    _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1)
                    {
                        LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_UE_associatedLogicalF1_ConnectionItem(
                            p_conn_elem->value.u.
                                _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1);

                    /* Store pointer in local variable for further processing */
                    p_conn_item = p_conn_elem->value.u.
                                    _f1ap_UE_associatedLogicalF1_ConnectionItemResAck_1;

                    if (p_src_conn_item->bitmask 
                            & UE_ASSOC_LOGICAL_F1_CONN_CU_F1AP_ID_PRESENT)
                    {
                        p_conn_item->m.gNB_CU_UE_F1AP_IDPresent = 1;
                        p_conn_item->gNB_CU_UE_F1AP_ID 
                                       = p_src_conn_item->gnb_cu_f1ap_id;
                    }

                    if (p_src_conn_item->bitmask 
                            & UE_ASSOC_LOGICAL_F1_CONN_DU_F1AP_ID_PRESENT)
                    {
                        p_conn_item->m.gNB_DU_UE_F1AP_IDPresent = 1; 
                        p_conn_item->gNB_DU_UE_F1AP_ID 
                                       = p_src_conn_item->gnb_du_f1ap_id; 
                    }

                    rtxDListAppendNode(
                        p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_2,
                        conn_node);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & F1AP_RESET_ACK_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ResetAcknowledge_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResetAcknowledge_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T8f1ap___f1ap_ResetAcknowledgeIEs_3;

            p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_3
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (NULL == p_protocolIE_elem->value.u.
                                    _f1ap_ResetAcknowledgeIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                  p_protocolIE_elem->value.u._f1ap_ResetAcknowledgeIEs_3);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                      _f1ap_ResetAcknowledgeIEs_3;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }



            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = NULL;
                OSRTDListNode*                        ieNode   = NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


