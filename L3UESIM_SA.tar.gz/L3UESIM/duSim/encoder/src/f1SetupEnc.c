/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "rrc_asn_enc_dec_nr.h"
#include "du_sim_common.h"

/*******************************************************************************
 * Function Name  : encode_MeasurementTimingConfiguration
 * Description    : This function populates the measurement timing Config.
 * Inputs         :    f1ap_nr_rrc_MeasurementTimingConfiguration_IEs *p_src_meastimeconfig
 *                     OSCTXT          * asn1_ctx:Pointer to ASN Context
 *                     OSDynOctStr     * trg_meastimeconfig
 * Outputs        : ASN Encoded meas timing config.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
void encode_MeasurementTimingConfiguration(
        f1ap_nr_rrc_MeasurementTimingConfiguration_IEs *p_src_meastimeconfig,
        OSCTXT                            * asn1_ctx,
        OSDynOctStr     * trg_meastimeconfig)

{
    nr_rrc_MeasTimingList*  p_meastimeconfig; 
    nr_rrc_MeasurementTimingConfiguration p_trg_meastimeconfig;  
    nr_rrc_MeasTiming *                         p_elem               = NULL; 
    f1ap_nr_rrc_MeasTiming *                        src_elem             = NULL;   
    U8                                     msg[8192];
    unsigned int meas_count                                         = 0;
    OSRTDListNode*        p_node                        = F1AP_P_NULL;

    p_trg_meastimeconfig.criticalExtensions.t = T_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1;

    p_trg_meastimeconfig.criticalExtensions.u.c1 =  rtxMemAllocType(asn1_ctx,
            nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1);

    if (NULL ==  p_trg_meastimeconfig.criticalExtensions.u.c1)
    {
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return;
    }

    asn1Init_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1(p_trg_meastimeconfig.criticalExtensions.u.c1);

    p_trg_meastimeconfig.criticalExtensions.u.c1->t = T_nr_rrc_MeasurementTimingConfiguration_criticalExtensions_c1_measTimingConf;

    p_trg_meastimeconfig.criticalExtensions.u.c1->u.measTimingConf =
        rtxMemAllocType(asn1_ctx,nr_rrc_MeasurementTimingConfiguration_IEs);

    if (NULL ==  p_trg_meastimeconfig.criticalExtensions.u.c1->u.measTimingConf)
    {
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return;
    }

    asn1Init_nr_rrc_MeasurementTimingConfiguration_IEs(p_trg_meastimeconfig.criticalExtensions.u.c1->u.measTimingConf); 

    if (p_src_meastimeconfig->m.measTimingPresent)
    {
        p_trg_meastimeconfig.criticalExtensions.u.c1->u.measTimingConf->m.measTimingPresent = 1;

        p_meastimeconfig = &p_trg_meastimeconfig.criticalExtensions.u.c1->u.measTimingConf->
                                 measTiming;

        asn1Init_nr_rrc_MeasTimingList(p_meastimeconfig);

        memset (msg, 0, 8192);

        for (meas_count = 0; meas_count < p_src_meastimeconfig->measTiming.count; meas_count++)
        {
            src_elem =  &p_src_meastimeconfig->measTiming._nr_rrc_MeasTiming[meas_count];
            /* Allocate memory for list node */
            rtxDListAllocNodeAndData(asn1_ctx,
                    nr_rrc_MeasTiming,
                    &p_node,
                    &p_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("ASN malloc failed \n");
                return;
            }

            asn1Init_nr_rrc_MeasTiming(p_elem);

            if (src_elem->m.frequencyAndTimingPresent)
            {
                p_elem->m.frequencyAndTimingPresent = 1;

                p_elem->frequencyAndTiming.carrierFreq = 
                    src_elem->frequencyAndTiming.carrierFreq.nr_rrc_ARFCN_ValueNR;

		p_elem->frequencyAndTiming.ssbSubcarrierSpacing = 
			src_elem->frequencyAndTiming.ssbSubcarrierSpacing.nr_rrc_SubcarrierSpacing;

		if ( src_elem->frequencyAndTiming.m.ss_RSSI_MeasurementPresent)
		{
			p_elem->frequencyAndTiming.m.ss_RSSI_MeasurementPresent = 1;

			p_elem->frequencyAndTiming.ss_RSSI_Measurement.endSymbol = 
				src_elem->frequencyAndTiming.ss_RSSI_Measurement.endSymbol;

			p_elem->frequencyAndTiming.ss_RSSI_Measurement.measurementSlots.numbits 
				= src_elem->frequencyAndTiming.ss_RSSI_Measurement.measurementSlots.numbits;

			memcpy(p_elem->frequencyAndTiming.ss_RSSI_Measurement.measurementSlots.data,
					src_elem->frequencyAndTiming.ss_RSSI_Measurement.measurementSlots.data,
					src_elem->frequencyAndTiming.ss_RSSI_Measurement.measurementSlots.numbits);
		}

                p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.t = 
                    src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.t;

                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf5 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {
                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf5 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf5;
                }
                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf10 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {
                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf10 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf10;
                }

                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf20 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {
                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf20 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf20;
                }

                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf40 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {
                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf40 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf40;
                }

                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf80 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {

                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf80 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf80;
                }

                if (T_nr_rrc_SSB_MTC_periodicityAndOffset_sf160 == p_elem->frequencyAndTiming.
                        ssb_MeasurementTimingConfiguration.periodicityAndOffset.t)
                {

                    p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf160 = src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.periodicityAndOffset.
                        u.sf160;
                }

                p_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.duration = 
                    src_elem->frequencyAndTiming.ssb_MeasurementTimingConfiguration.duration.nr_rrc_SSB_MTC_duration;
            }//if src_elem->m.frequencyAndTimingPresent

            /* Append node to the list */
            rtxDListAppendNode(
                    p_meastimeconfig,
                    p_node);

        }//for meas_count
        pu_setBuffer (asn1_ctx, msg, 8192, FALSE);

        if (RT_OK != asn1PE_nr_rrc_MeasurementTimingConfiguration (asn1_ctx, &p_trg_meastimeconfig))
        {
            char buff[500];
            rtxErrGetTextBuf(asn1_ctx,buff ,500);
  //  asn1Print_nr_rrc_MeasTimingList("Meastimg",p_meastimeconfig);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff);
            LOG_TRACE("Failed to encode mease timing config \n");
            return;
        }
        trg_meastimeconfig->numocts = (U16)pe_GetMsgLen (asn1_ctx);        
        trg_meastimeconfig->data = (U8 *)rtxMemAlloc (asn1_ctx,trg_meastimeconfig->numocts);
        memcpy ((void *) trg_meastimeconfig->data, msg, trg_meastimeconfig->numocts);

    }
    asn1Print_nr_rrc_MeasurementTimingConfiguration("Meastimg",&p_trg_meastimeconfig);
    return;
}



/* This function populates served cell information from source
 * container to ASN based target container. */

/*******************************************************************************
 * Function Name  : populate_served_cell_information
 * Description    : This function populates the served cell information received
 *                  from DU in F1 Setup Request.
 *
 * Inputs         : OSCTXT*                        : asn1_ctx: Pointer to ASN Context
 * *                f1ap_Served_Cell_Information*  : p_trg_cell_info: Pointer to
 *                  receive served cell info in ASN Format.
 *                  f1ap_served_cell_information_t*: p_src_cell_info: Pointer to
 *                  served cell info received in F1 setup request.
 *
 * Outputs        : ASN Encoded served cell info.
 * Returns        : DU_F1AP_SUCCESS/DU_F1AP_FAILURE
 ******************************************************************************/
sim_return_val_et
populate_served_cell_information(
        OSCTXT*                        asn1_ctx,
        f1ap_Served_Cell_Information*  p_trg_cell_info,
        _f1ap_Served_Cell_Information* p_src_cell_info)
{
    //unsigned int  index = 0;

    asn1Init_f1ap_Served_Cell_Information(p_trg_cell_info);

    p_trg_cell_info->nRCGI.pLMN_Identity.numocts 
          = p_src_cell_info->nRCGI.pLMN_Identity.numocts;

    memcpy(p_trg_cell_info->nRCGI.pLMN_Identity.data,
           p_src_cell_info->nRCGI.pLMN_Identity.data,
           p_src_cell_info->nRCGI.pLMN_Identity.numocts);

    p_trg_cell_info->nRCGI.nRCellIdentity.numbits   
         = 36; //p_src_cell_info->nRCGI.nRCellIdentity.numbits;

    memcpy(p_trg_cell_info->nRCGI.nRCellIdentity.data,   
           p_src_cell_info->nRCGI.nRCellIdentity.data,
           5);

    p_trg_cell_info->nRPCI = p_src_cell_info->nRPCI;
   
    p_trg_cell_info->m.fiveGS_TACPresent = 1;
    p_trg_cell_info->fiveGS_TAC.numocts = 3; 
    memcpy(p_trg_cell_info->fiveGS_TAC.data,
           p_src_cell_info->fiveGS_TAC.data,
           EXTENDED_TAC_LENGTH);

    p_trg_cell_info->configured_EPS_TAC.numocts = 2; 
    memcpy(p_trg_cell_info->configured_EPS_TAC.data,
            p_src_cell_info->configured_EPS_TAC.data,
            2);

    {
        f1ap_BroadcastPLMNs_List*          trg_BroadcastPLMNs_list      = F1AP_P_NULL;
        _f1ap_BroadcastPLMNs_Item*         src_BroadcastPLMNs_list      = F1AP_P_NULL;
        f1ap_BroadcastPLMNs_Item*          trg_PLMNs                    = F1AP_P_NULL;
        _f1ap_PLMN_Identity*               src_PLMNs                    = F1AP_P_NULL;
        OSRTDListNode*                     p_PLMNs_node                 = F1AP_P_NULL;
        unsigned short                     PLMNs_index                  = F1AP_NULL;

        trg_BroadcastPLMNs_list = &p_trg_cell_info->servedPLMNs;
        src_BroadcastPLMNs_list = &p_src_cell_info->broadcastPLMNs;

        asn1Init_f1ap_BroadcastPLMNs_List(trg_BroadcastPLMNs_list);
        for (PLMNs_index = 0; PLMNs_index < src_BroadcastPLMNs_list->n;
                PLMNs_index++)
        {
            src_PLMNs = &src_BroadcastPLMNs_list->elem[PLMNs_index];

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(asn1_ctx,
                    f1ap_BroadcastPLMNs_Item,
                    &p_PLMNs_node,
                    &trg_PLMNs);

            if (F1AP_NULL == p_PLMNs_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_BroadcastPLMNs_Item(trg_PLMNs);
            trg_PLMNs->pLMN_Identity.numocts = src_PLMNs->numocts;
            memcpy(trg_PLMNs->pLMN_Identity.data,src_PLMNs->data,src_PLMNs->numocts);

            rtxDListAppendNode(trg_BroadcastPLMNs_list,
                    p_PLMNs_node);


        }  


    }
     p_trg_cell_info->nR_Mode_Info.t = p_src_cell_info->nR_Mode_Info.nr_mode; 

        if (T_f1ap_NR_Mode_Info_fDD == p_trg_cell_info->nR_Mode_Info.t)
        {
            p_trg_cell_info->nR_Mode_Info.u.fDD
                = rtxMemAllocType(asn1_ctx,
                        f1ap_FDD_Info);

            if (F1AP_NULL == p_trg_cell_info->nR_Mode_Info.u.fDD)
            {
                LOG_TRACE("Failed to allocate memory for FDD configuration \n");
                return SIM_FAILURE;
            }

            asn1Init_f1ap_FDD_Info(p_trg_cell_info->nR_Mode_Info.u.fDD);

            p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.nRARFCN
                = p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.nRARFCN;


            if (p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.bitmask & F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT)
            {
                p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.m.sul_InformationPresent = 1;

                p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.sul_Information.sUL_NRARFCN
                    = p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.sul_Information.sUL_NRARFCN;

                p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRSCS
                    = p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.sul_Information.sUL_transmission_Bandwidth.nRSCS;

                p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRNRB
                    = p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.sul_Information.sUL_transmission_Bandwidth.nRNRB;
            }
            {


                f1ap_NRFreqInfo_freqBandListNr*          trg_freqBand_list = F1AP_NULL;
                _f1ap_NRFreqInfo_freqBandListNr*          src_freqBand_list = F1AP_NULL;
                f1ap_FreqBandNrItem*          trg_freqBand      = F1AP_NULL;
                _f1ap_FreqBandNrItem*                src_freqBand      = F1AP_NULL;
                OSRTDListNode*                       p_freqBand_node   = F1AP_NULL;
                unsigned short                       freqBand_index    = 0;

                trg_freqBand_list = &p_trg_cell_info->nR_Mode_Info.u.fDD->uL_NRFreqInfo.freqBandListNr;
                src_freqBand_list = &p_src_cell_info->nR_Mode_Info.u.fDD.uL_NARFCN.freqBandListNr;

                asn1Init_f1ap_NRFreqInfo_freqBandListNr(trg_freqBand_list);
                for (freqBand_index = 0; freqBand_index < src_freqBand_list->count;
                        freqBand_index++)
                {
                    src_freqBand = &src_freqBand_list->item[freqBand_index];

                    /* Allocate memory for target protocolIE element */
                    rtxDListAllocNodeAndData(asn1_ctx,
                            f1ap_FreqBandNrItem,
                            &p_freqBand_node,
                            &trg_freqBand);

                    if (F1AP_NULL == p_freqBand_node)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_FreqBandNrItem(trg_freqBand);

                    trg_freqBand->freqBandIndicatorNr = src_freqBand->freqBandIndicatorNr;

                    f1ap_FreqBandNrItem_supportedSULBandList*          trg_slfreqBand_list = F1AP_NULL;
                    _f1ap_FreqBandNrItem_supportedSULBandList*          src_slfreqBand_list = F1AP_NULL;
                    f1ap_SupportedSULFreqBandItem*          trg_slfreqBand      = F1AP_NULL;
                    _f1ap_SupportedSULFreqBandItem*                src_slfreqBand      = F1AP_NULL;
                    OSRTDListNode*                       p_slfreqBand_node   = F1AP_NULL;
                    unsigned short                       slfreqBand_index    = 0;

                    trg_slfreqBand_list = &trg_freqBand->supportedSULBandList;
                    src_slfreqBand_list = &src_freqBand->supportedSULBandList;

                    asn1Init_f1ap_FreqBandNrItem_supportedSULBandList(trg_slfreqBand_list);
                    for (slfreqBand_index = 0; slfreqBand_index < src_slfreqBand_list->count;
                            slfreqBand_index++)
                    {
                        src_slfreqBand = &src_slfreqBand_list->item[slfreqBand_index];

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(asn1_ctx,
                                f1ap_SupportedSULFreqBandItem,
                                &p_slfreqBand_node,
                                &trg_slfreqBand);

                        if (F1AP_NULL == p_slfreqBand_node)
                        {
                            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                            break;
                        }

                        asn1Init_f1ap_SupportedSULFreqBandItem(trg_slfreqBand);

                        trg_slfreqBand->freqBandIndicatorNr = src_slfreqBand->freqBandIndicatorNr;

                        rtxDListAppendNode(trg_slfreqBand_list,
                                p_slfreqBand_node);


                    }  
                    rtxDListAppendNode(trg_freqBand_list,
                            p_freqBand_node);
                }

            }
            p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.nRARFCN
                = p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.nRARFCN;


            if (p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.bitmask & F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT)
            {
                p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.m.sul_InformationPresent = 1;

                p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.sul_Information.sUL_NRARFCN
                    = p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.sul_Information.sUL_NRARFCN;

                p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRSCS
                    = p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.sul_Information.sUL_transmission_Bandwidth.nRSCS;

                p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRNRB
                    = p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.sul_Information.sUL_transmission_Bandwidth.nRNRB;
            }
            {


                f1ap_NRFreqInfo_freqBandListNr*          trg_freqBand_list = F1AP_NULL;
                _f1ap_NRFreqInfo_freqBandListNr*          src_freqBand_list = F1AP_NULL;
                f1ap_FreqBandNrItem*          trg_freqBand      = F1AP_NULL;
                _f1ap_FreqBandNrItem*                src_freqBand      = F1AP_NULL;
                OSRTDListNode*                       p_freqBand_node   = F1AP_NULL;
                unsigned short                       freqBand_index    = 0;

                trg_freqBand_list = &p_trg_cell_info->nR_Mode_Info.u.fDD->dL_NRFreqInfo.freqBandListNr;
                src_freqBand_list = &p_src_cell_info->nR_Mode_Info.u.fDD.dL_NARFCN.freqBandListNr;

                asn1Init_f1ap_NRFreqInfo_freqBandListNr(trg_freqBand_list);
                for (freqBand_index = 0; freqBand_index < src_freqBand_list->count;
                        freqBand_index++)
                {
                    src_freqBand = &src_freqBand_list->item[freqBand_index];

                    /* Allocate memory for target protocolIE element */
                    rtxDListAllocNodeAndData(asn1_ctx,
                            f1ap_FreqBandNrItem,
                            &p_freqBand_node,
                            &trg_freqBand);

                    if (F1AP_NULL == p_freqBand_node)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_FreqBandNrItem(trg_freqBand);

                    trg_freqBand->freqBandIndicatorNr = src_freqBand->freqBandIndicatorNr;





                    f1ap_FreqBandNrItem_supportedSULBandList*          trg_slfreqBand_list = F1AP_NULL;
                    _f1ap_FreqBandNrItem_supportedSULBandList*          src_slfreqBand_list = F1AP_NULL;
                    f1ap_SupportedSULFreqBandItem*          trg_slfreqBand      = F1AP_NULL;
                    _f1ap_SupportedSULFreqBandItem*                src_slfreqBand      = F1AP_NULL;
                    OSRTDListNode*                       p_slfreqBand_node   = F1AP_NULL;
                    unsigned short                       slfreqBand_index    = 0;

                    trg_slfreqBand_list = &trg_freqBand->supportedSULBandList;
                    src_slfreqBand_list = &src_freqBand->supportedSULBandList;

                    asn1Init_f1ap_FreqBandNrItem_supportedSULBandList(trg_slfreqBand_list);
                    for (slfreqBand_index = 0; slfreqBand_index < src_slfreqBand_list->count;
                            slfreqBand_index++)
                    {
                        src_slfreqBand = &src_slfreqBand_list->item[slfreqBand_index];

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(asn1_ctx,
                                f1ap_SupportedSULFreqBandItem,
                                &p_slfreqBand_node,
                                &trg_slfreqBand);

                        if (F1AP_NULL == p_slfreqBand_node)
                        {
                            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                            break;
                        }

                        asn1Init_f1ap_SupportedSULFreqBandItem(trg_slfreqBand);

                        trg_slfreqBand->freqBandIndicatorNr = src_slfreqBand->freqBandIndicatorNr;

                        rtxDListAppendNode(trg_slfreqBand_list,
                                p_slfreqBand_node);


                    }  
                    rtxDListAppendNode(trg_freqBand_list,
                            p_freqBand_node);

                }

            }

            p_trg_cell_info->nR_Mode_Info.u.fDD->uL_Transmission_Bandwidth.nRSCS
                = p_src_cell_info->nR_Mode_Info.u.fDD.uL_Transmission_Bandwidth.nRSCS;

            p_trg_cell_info->nR_Mode_Info.u.fDD->uL_Transmission_Bandwidth.nRNRB
                = p_src_cell_info->nR_Mode_Info.u.fDD.uL_Transmission_Bandwidth.nRNRB;

            p_trg_cell_info->nR_Mode_Info.u.fDD->dL_Transmission_Bandwidth.nRSCS
                = p_src_cell_info->nR_Mode_Info.u.fDD.dL_Transmission_Bandwidth.nRSCS; 

            p_trg_cell_info->nR_Mode_Info.u.fDD->dL_Transmission_Bandwidth.nRNRB
                = p_src_cell_info->nR_Mode_Info.u.fDD.dL_Transmission_Bandwidth.nRNRB; 
        }
        else if (T_f1ap_NR_Mode_Info_tDD == p_trg_cell_info->nR_Mode_Info.t)
        {
            p_trg_cell_info->nR_Mode_Info.u.tDD
                = rtxMemAllocType(asn1_ctx,
                        f1ap_TDD_Info);

            if (F1AP_NULL == p_trg_cell_info->nR_Mode_Info.u.tDD)
            {
                LOG_TRACE("Failed to allocate memory for TDD configuration \n");
                return SIM_FAILURE;
            }

            asn1Init_f1ap_TDD_Info(p_trg_cell_info->nR_Mode_Info.u.tDD);

            p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.nRARFCN
                = p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.nRARFCN;

            if (p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.bitmask & F1AP_SERVED_CELL_INFO_SUL_INFO_PRESENT)
            {
                p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.m.sul_InformationPresent = 1;

                p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.sul_Information.sUL_NRARFCN
                    = p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.sul_Information.sUL_NRARFCN;

                p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRSCS
                    = p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRSCS;

                p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRNRB
                    = p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.sul_Information.sUL_transmission_Bandwidth.nRNRB;
            }
            {

                f1ap_NRFreqInfo_freqBandListNr*          trg_freqBand_list = F1AP_P_NULL;
                _f1ap_NRFreqInfo_freqBandListNr*          src_freqBand_list = F1AP_P_NULL;
                f1ap_FreqBandNrItem*          trg_freqBand      = F1AP_P_NULL;
                _f1ap_FreqBandNrItem*                src_freqBand      = F1AP_P_NULL;
                OSRTDListNode*                       p_freqBand_node   = F1AP_P_NULL;
                unsigned short                       freqBand_index    = F1AP_NULL;

                trg_freqBand_list = &p_trg_cell_info->nR_Mode_Info.u.tDD->nRFreqInfo.freqBandListNr;
                src_freqBand_list = &p_src_cell_info->nR_Mode_Info.u.tDD.nRFreqInfo.freqBandListNr;

                asn1Init_f1ap_NRFreqInfo_freqBandListNr(trg_freqBand_list);

                for (freqBand_index = 0; freqBand_index < src_freqBand_list->count;
                        freqBand_index++)
                {
                    src_freqBand = &src_freqBand_list->item[freqBand_index];

                    /* Allocate memory for target protocolIE element */
                    rtxDListAllocNodeAndData(asn1_ctx,
                            f1ap_FreqBandNrItem,
                            &p_freqBand_node,
                            &trg_freqBand);

                    if (F1AP_NULL == p_freqBand_node)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    asn1Init_f1ap_FreqBandNrItem(trg_freqBand);

                    trg_freqBand->freqBandIndicatorNr = src_freqBand->freqBandIndicatorNr;



                    f1ap_FreqBandNrItem_supportedSULBandList*          trg_slfreqBand_list = F1AP_P_NULL;
                    _f1ap_FreqBandNrItem_supportedSULBandList*          src_slfreqBand_list = F1AP_P_NULL;
                    f1ap_SupportedSULFreqBandItem*          trg_slfreqBand      = F1AP_P_NULL;
                    _f1ap_SupportedSULFreqBandItem*                src_slfreqBand      = F1AP_P_NULL;
                    OSRTDListNode*                       p_slfreqBand_node   = F1AP_P_NULL;
                    unsigned short                       slfreqBand_index    = F1AP_NULL;

                    trg_slfreqBand_list = &trg_freqBand->supportedSULBandList;
                    src_slfreqBand_list = &src_freqBand->supportedSULBandList;

                    asn1Init_f1ap_FreqBandNrItem_supportedSULBandList(trg_slfreqBand_list);

                    for (slfreqBand_index = 0; slfreqBand_index < src_slfreqBand_list->count;
                            slfreqBand_index++)
                    {
                        src_slfreqBand = &src_slfreqBand_list->item[slfreqBand_index];

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(asn1_ctx,
                                f1ap_SupportedSULFreqBandItem,
                                &p_slfreqBand_node,
                                &trg_slfreqBand);

                        if (F1AP_NULL == p_slfreqBand_node)
                        {
                            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                            break;
                        }

                        asn1Init_f1ap_SupportedSULFreqBandItem(trg_slfreqBand);

                        trg_slfreqBand->freqBandIndicatorNr = src_slfreqBand->freqBandIndicatorNr;

                        rtxDListAppendNode(trg_slfreqBand_list,
                                p_slfreqBand_node);

                    }  
                    rtxDListAppendNode(trg_freqBand_list,
                            p_freqBand_node);
                }

            }


            p_trg_cell_info->nR_Mode_Info.u.tDD->transmission_Bandwidth.nRSCS
                = p_src_cell_info->nR_Mode_Info.u.tDD.transmission_Bandwidth.nRSCS; 

            p_trg_cell_info->nR_Mode_Info.u.tDD->transmission_Bandwidth.nRNRB
                = p_src_cell_info->nR_Mode_Info.u.tDD.transmission_Bandwidth.nRNRB;

        }

	/* Populate secondary UL information */
	{

		/* Populate measurement timing configuration */
		encode_MeasurementTimingConfiguration(&p_src_cell_info->meas_timing_config.
				criticalExtensions.u.c1.u.measTimingConf,
				asn1_ctx,&p_trg_cell_info->measurementTimingConfiguration);

	}

	return SIM_SUCCESS;
}


/* This function populates served cell system information from 
 * source container to ASN based target container. */
    void
populate_served_cell_system_information(
        OSCTXT*                  asn1_ctx,
        f1ap_GNB_DU_System_Information*  p_trg_sys_info,
        _f1ap_GNB_DU_System_Information* p_src_sys_info)
{
    asn1Init_f1ap_GNB_DU_System_Information(p_trg_sys_info);

    p_trg_sys_info->mIB_message.numocts 
             = p_src_sys_info->mib_length;
 
    p_trg_sys_info->mIB_message.data = rtxMemAlloc(asn1_ctx, p_src_sys_info->mib_length);

    if (F1AP_NULL ==  p_trg_sys_info->mIB_message.data)
    {
        LOG_TRACE("ASN malloc Failed \n");
        return;
    }

    memcpy((char*)p_trg_sys_info->mIB_message.data,
           p_src_sys_info->mIB_message,
           p_src_sys_info->mib_length);

    p_trg_sys_info->sIB1_message.numocts 
             = p_src_sys_info->sib1_length;

    p_trg_sys_info->sIB1_message.data = rtxMemAlloc(asn1_ctx,p_src_sys_info->sib1_length);

    if (F1AP_NULL ==  p_trg_sys_info->sIB1_message.data)
    {
        LOG_TRACE("ASN malloc Failed \n");
        return;
    }

    memcpy((char*)p_trg_sys_info->sIB1_message.data,
           p_src_sys_info->sIB1_message,
           p_src_sys_info->sib1_length);
}



/* This function encodes F1 Setup Request */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_f1_setup_req
 * Description    : This function encodes f1 setup req 
 * Inputs         :
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer.
 *                  length
 * Outputs        : ASN Encoded du config update request
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
dusim_handle_encode_f1_setup_req(
/* spr 24900 changes start */
     unsigned   char*   apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                  = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                  = F1AP_P_NULL;
    f1ap_F1SetupRequest*  p_asn_msg               = F1AP_P_NULL;
    f1ap_F1SetupRequest_protocolIEs_element*  
        p_protocolIE_elem       = F1AP_NULL;
    _f1ap_F1SetupRequest* src_asn_msg             = F1AP_P_NULL;


    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                __FUNCTION__);
        return retVal;
    }


    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_F1SetupRequest*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
         ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* fill procedure code for */
        f1ap_pdu.u.initiatingMessage->procedureCode =
            ASN1V_f1ap_id_F1Setup;

        /* fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to SeNB Addition Preparation */
        f1ap_pdu.u.initiatingMessage->value.t = T2f1ap__f1Setup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                f1ap_F1SetupRequest);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_F1SetupRequest(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.f1Setup = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupRequest_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T11f1ap___f1ap_F1SetupRequestIEs_1;
            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_1 
                = src_asn_msg->transaction_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose DU ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupRequest_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_gNB_DU_ID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T11f1ap___f1ap_F1SetupRequestIEs_2;
            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_2 
                = src_asn_msg->du_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose DU Name, if present in the source container  */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupRequest_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_gNB_DU_Name;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T11f1ap___f1ap_F1SetupRequestIEs_3;
            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_3 
                = rtxMemAlloc(&asn1_ctx, 
                        MAX_DU_NAME_LENGTH);
            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            memcpy((char*)p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_3,
                    src_asn_msg->du_name,
                    MAX_DU_NAME_LENGTH);

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose served cells list */
        {
            unsigned int                            count       = F1AP_NULL;
            f1ap_GNB_DU_Served_Cells_List_element*  p_elem      = F1AP_P_NULL;
            OSRTDListNode*                          list_node   = F1AP_P_NULL;

            if ((F1AP_NULL == src_asn_msg->served_cells_list.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->served_cells_list.count))
            {
                LOG_TRACE("Count is not valid in served cells list: %d", 
                        src_asn_msg->served_cells_list.count);
                break;
            }

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupRequest_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_gNB_DU_Served_Cells_List;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T11f1ap___f1ap_F1SetupRequestIEs_4;

            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_4
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_GNB_DU_Served_Cells_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_4)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }

            asn1Init_f1ap_GNB_DU_Served_Cells_List(p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_4);	

            for (count = 0; ((count < src_asn_msg->served_cells_list.count) && 
                        (count < MAX_CELL_PER_DU)); 
                    count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_GNB_DU_Served_Cells_List_element,
                        &list_node,
                        &p_elem);

                if (F1AP_NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_GNB_DU_Served_Cells_List_element(p_elem);

                p_elem->id          = ASN1V_f1ap_id_GNB_DU_Served_Cells_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T12f1ap___f1ap_GNB_DU_Served_Cells_ItemIEs_1;

                p_elem->value.u._f1ap_GNB_DU_Served_Cells_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_GNB_DU_Served_Cells_Item);

                if (F1AP_NULL == p_elem->value.u._f1ap_GNB_DU_Served_Cells_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                asn1Init_f1ap_GNB_DU_Served_Cells_Item(p_elem->value.u._f1ap_GNB_DU_Served_Cells_ItemIEs_1);

                /* Populate served cell information */ 
                {
                    f1ap_Served_Cell_Information*  p_trg_cell_info = F1AP_P_NULL;
                    _f1ap_Served_Cell_Information* p_src_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_cell_info = &p_elem->value.u.
                        _f1ap_GNB_DU_Served_Cells_ItemIEs_1->served_Cell_Information;

                    /* Fetch pointer to source served cell information */
                    p_src_cell_info = &src_asn_msg->served_cells_list.
                        served_cell[count].served_cell_info;

                    if (SIM_SUCCESS != populate_served_cell_information(
                                &asn1_ctx,
                                p_trg_cell_info,
                                p_src_cell_info))
                    {
                        LOG_TRACE("Failed to compose Served cell information \n");
                        return SIM_FAILURE;
                    }
                }

                /* Populate system information */
                if (src_asn_msg->served_cells_list.served_cell[count].bitmask 
                        & F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT)
                {
                    f1ap_GNB_DU_System_Information*  p_trg_sys_info = F1AP_P_NULL;
                    _f1ap_GNB_DU_System_Information* p_src_sys_info = F1AP_P_NULL;

                    p_elem->value.u._f1ap_GNB_DU_Served_Cells_ItemIEs_1->m.gNB_DU_System_InformationPresent = 1;

                    asn1Init_f1ap_GNB_DU_System_Information(p_trg_sys_info);
                    /* Fetch pointer to target system information container */
                    p_trg_sys_info = &p_elem->value.u.
                        _f1ap_GNB_DU_Served_Cells_ItemIEs_1->gNB_DU_System_Information;

                    /* Fetch pointer to source system information container */
                    p_src_sys_info = &src_asn_msg->served_cells_list.
                        served_cell[count].system_info;

                    populate_served_cell_system_information(
                            &asn1_ctx,
                            p_trg_sys_info,
                            p_src_sys_info);
                }

                rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_4,
                        list_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose rrc_version */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupRequest_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_GNB_DU_RRC_Version;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T11f1ap___f1ap_F1SetupRequestIEs_5;

            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_RRC_Version);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5)
            {
                LOG_TRACE("Failed to allocate memory for rrc version\n");
                return SIM_FAILURE;
            }

            //asn1Init_f1ap_RRC_Version(p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5);	

            //p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5->latest_RRC_Version.numbits = 24;
            p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5->latest_RRC_Version.numbits = 3;

            memcpy(p_protocolIE_elem->value.u._f1ap_F1SetupRequestIEs_5->latest_RRC_Version.data,src_asn_msg->rrc_version.latest_rrc_version.data,4);

            

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }
        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (F1AP_NULL != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


/* This function encodes F1 Setup Response */
sim_return_val_et
dusim_handle_encode_f1_setup_resp(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_P_NULL;
    f1ap_F1SetupResponse*  p_asn_msg               = F1AP_P_NULL;
    f1ap_F1SetupResponse_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_P_NULL;
    _f1ap_F1SetupResponse* src_asn_msg             = F1AP_P_NULL;
    
     /* Init ASN1 context */
    if (F1AP_NULL != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_F1SetupResponse*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to successful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_SuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* fill procedure code for */
        f1ap_pdu.u.successfulOutcome->procedureCode =
                                            ASN1V_f1ap_id_F1Setup;

        /* fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

        /* Set the initiating message type to */
        f1ap_pdu.u.successfulOutcome->value.t = T2f1ap__f1Setup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_F1SetupResponse);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_F1SetupResponse(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.u.f1Setup = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupResponse_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T13f1ap___f1ap_F1SetupResponseIEs_1;
            p_protocolIE_elem->value.u._f1ap_F1SetupResponseIEs_1
                                           = src_asn_msg->transaction_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cells to be activated list */
        {
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


/* This function encodes F1 Setup Failure */
sim_return_val_et
dusim_handle_encode_f1_setup_failure(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_P_NULL;
    f1ap_F1SetupFailure*   p_asn_msg               = F1AP_P_NULL;
    f1ap_F1SetupFailure_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_P_NULL;
    _f1ap_F1SetupFailure*  src_asn_msg             = F1AP_P_NULL;
    
     /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_F1SetupFailure*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to unsuccessful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

        f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_UnsuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.unsuccessfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UnsuccessfulOutcome(
                      f1ap_pdu.u.unsuccessfulOutcome);

        /* fill procedure code for */
        f1ap_pdu.u.unsuccessfulOutcome->procedureCode =
                                            ASN1V_f1ap_id_F1Setup;

        /* fill criticality of message type */
        f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

        /* Set the message type to unsuccessful outcome */
        f1ap_pdu.u.unsuccessfulOutcome->value.t = T2f1ap__f1Setup;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_F1SetupFailure);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_F1SetupFailure(p_asn_msg);

        f1ap_pdu.u.unsuccessfulOutcome->value.u.f1Setup = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T15f1ap___f1ap_F1SetupFailureIEs_1;
            p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_1
                                           = src_asn_msg->transaction_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose Cause */
        {
            f1ap_Cause* p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T15f1ap___f1ap_F1SetupFailureIEs_2;
            p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_2
                                           = rtxMemAllocType(&asn1_ctx,
                                                             f1ap_Cause);
            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_2)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_Cause(p_protocolIE_elem->value.u.
                                       _f1ap_F1SetupFailureIEs_2);

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_2;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose time to wait */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TimeToWait;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T15f1ap___f1ap_F1SetupFailureIEs_3;
            p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_3
                                           = src_asn_msg->timeToWait;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics */
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_F1SetupFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_F1SetupFailure_protocolIEs_element(
                                p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality = f1ap_ignore;

            p_protocolIE_elem->value.t     = T15f1ap___f1ap_F1SetupFailureIEs_4;
            p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_4
                           = rtxMemAllocType(&asn1_ctx,
                                             f1ap_CriticalityDiagnostics);
            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(p_protocolIE_elem->value.u.
                                       _f1ap_F1SetupFailureIEs_4);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u._f1ap_F1SetupFailureIEs_4;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_P_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_P_NULL;
                OSRTDListNode*                        ieNode   = F1AP_P_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}
/* This function encodes gNB DU Configuration update Request */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_du_config_update_req
 * Description    : This function encodes du config update req 
 * Inputs         :
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer.
 *                  length
 * Outputs        : ASN Encoded du config update request
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
dusim_handle_encode_du_config_update_req(
/* spr 24900 changes start*/
      unsigned  char*   apiBuf,
/* spr 24900 changes end */      
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et     retVal                        = SIM_FAILURE;
    OSCTXT                asn1_ctx;
    f1ap_F1AP_PDU         f1ap_pdu;
    OSRTDListNode*        p_node                        = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdate*  
        p_asn_msg                                       = F1AP_P_NULL;
    f1ap_GNBDUConfigurationUpdate_protocolIEs_element*  
        p_protocolIE_elem                               = F1AP_P_NULL;
    _f1ap_GNBDUConfigurationUpdate* 
        src_asn_msg                                     = F1AP_P_NULL;

    /* Init ASN1 context */
    if (F1AP_NULL != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                __FUNCTION__);
        return retVal;
    }

    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_GNBDUConfigurationUpdate*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
         ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
            = ASN1V_f1ap_id_gNBDUConfigurationUpdate;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to DU Configuration 
         * update request */
        f1ap_pdu.u.initiatingMessage->value.t 
            = T2f1ap__gNBDUConfigurationUpdate;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                f1ap_GNBDUConfigurationUpdate);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_GNBDUConfigurationUpdate(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.
            u.gNBDUConfigurationUpdate = p_asn_msg;

        /* Compose served cells to add list */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T16f1ap___f1ap_GNBDUConfigurationUpdateIEs_1;
            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_1 
                = src_asn_msg->TransactionID;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);

        }

        /* Compose served cells to served list */
	if(src_asn_msg->bitmask & DU_CONFIG_UPDATE_CELLS_TO_ADD_LIST_PRESENT)

        {

            unsigned int                            count       = 0;
            f1ap_Served_Cells_To_Add_List_element*  p_elem      = F1AP_NULL;
            OSRTDListNode*                          list_node   = F1AP_NULL;

            if ((0 == src_asn_msg->cellsToAddList.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->cellsToAddList.count))
            {
                LOG_TRACE("Count is not valid in served cells list: %d", 
                        src_asn_msg->cellsToAddList.count);
                break;
            }
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Add_List;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T16f1ap___f1ap_GNBDUConfigurationUpdateIEs_2;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_Served_Cells_To_Add_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }

           asn1Init_f1ap_Served_Cells_To_Add_List(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2);
		
            for (count = 0; ((count < src_asn_msg->cellsToAddList.count) && 
                        (count < MAX_CELL_PER_DU)); 
                    count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_Served_Cells_To_Add_List_element,
                        &list_node,
                        &p_elem);

                if (F1AP_NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Add_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T17f1ap___f1ap_Served_Cells_To_Add_ItemIEs_1;
                p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Served_Cells_To_Add_Item);

                if (F1AP_NULL == p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }
		asn1Init_f1ap_Served_Cells_To_Add_Item(p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1);
                /* Populate served cell information */ 
                {
                    f1ap_Served_Cell_Information*  p_trg_cell_info = F1AP_P_NULL;
                    _f1ap_Served_Cell_Information* p_src_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_cell_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Add_ItemIEs_1->served_Cell_Information;

                    /* Fetch pointer to source served cell information */
                    p_src_cell_info = &src_asn_msg->cellsToAddList.
                        cell_to_add[count].served_cell_info;

                    if (SIM_SUCCESS != populate_served_cell_information(
                                &asn1_ctx,
                                p_trg_cell_info,
                                p_src_cell_info))
                    {
                        LOG_TRACE("Failed to compose Served cell information \n");
                        return SIM_FAILURE;
                    }
                }

                /* Populate system information */
                if (src_asn_msg->cellsToAddList.cell_to_add[count].bitmask 
                        & F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT)
                {
                    f1ap_GNB_DU_System_Information*  p_trg_sys_info = F1AP_P_NULL;
                    _f1ap_GNB_DU_System_Information* p_src_sys_info = F1AP_P_NULL;

                    p_elem->value.u._f1ap_Served_Cells_To_Add_ItemIEs_1->m.gNB_DU_System_InformationPresent = 1;

                    /* Fetch pointer to target system information container */
                    p_trg_sys_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Add_ItemIEs_1->gNB_DU_System_Information;

                    /* Fetch pointer to source system information container */
                    p_src_sys_info = &src_asn_msg->cellsToAddList.
                        cell_to_add[count].system_info;

                    populate_served_cell_system_information(
                            &asn1_ctx,
                            p_trg_sys_info,
                            p_src_sys_info);
                }
                rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_2,
                        list_node);


            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }   
        /* Compose served cells to Modify list */
	
	if(src_asn_msg->bitmask & DU_CONFIG_UPDATE_CELLS_TO_MOD_LIST_PRESENT)
        {

            unsigned int                               count        = 0;
            f1ap_Served_Cells_To_Modify_List_element*  p_elem       = F1AP_P_NULL;
            OSRTDListNode*                          list_node       = F1AP_P_NULL;

            if ((0 == src_asn_msg->cellsToModifyList.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->cellsToModifyList.count))
            {
                LOG_TRACE("Count is not valid in modified cells list: %d", 
                        src_asn_msg->cellsToModifyList.count);
                break;
            }
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Modify_List;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T16f1ap___f1ap_GNBDUConfigurationUpdateIEs_3;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_3
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_Served_Cells_To_Modify_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_3)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }

	     asn1Init_f1ap_Served_Cells_To_Modify_List(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_3);
		
            for (count = 0; ((count < src_asn_msg->cellsToModifyList.count) && 
                        (count < MAX_CELL_PER_DU)); 
                    count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_Served_Cells_To_Modify_List_element,
                        &list_node,
                        &p_elem);

                if (F1AP_NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Modify_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T18f1ap___f1ap_Served_Cells_To_Modify_ItemIEs_1;
                p_elem->value.u._f1ap_Served_Cells_To_Modify_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Served_Cells_To_Modify_Item);

                if (F1AP_NULL == p_elem->value.u._f1ap_Served_Cells_To_Modify_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }
		
		asn1Init_f1ap_Served_Cells_To_Modify_Item(p_elem->value.u._f1ap_Served_Cells_To_Modify_ItemIEs_1);
                /* Populate served cell information */ 
                {

                    f1ap_NRCGI*  p_trg_old_cell_info = F1AP_P_NULL;
                    _f1ap_NCGI* p_src_old_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_old_cell_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Modify_ItemIEs_1->oldNRCGI;

                    /* Fetch pointer to source served cell information */
                    p_src_old_cell_info = &src_asn_msg->cellsToModifyList.
                        cell_to_modify[count].old_ncgi;

                    asn1Init_f1ap_NRCGI(p_trg_old_cell_info);


                    p_trg_old_cell_info->pLMN_Identity.numocts 
                        = p_src_old_cell_info->pLMN_Identity.numocts;

                    memcpy(p_trg_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.numocts);

                    p_trg_old_cell_info->nRCellIdentity.numbits   
                        = 36; //p_src_cell_info->nRCGI.nRCellIdentity.numbits;

                    memcpy(p_trg_old_cell_info->nRCellIdentity.data,   
                            p_src_old_cell_info->nRCellIdentity.data,
                            5);


                }

                /* Populate served cell information */ 
                {
                    f1ap_Served_Cell_Information*  p_trg_cell_info = F1AP_P_NULL;
                    _f1ap_Served_Cell_Information* p_src_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_cell_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Modify_ItemIEs_1->served_Cell_Information;

                    /* Fetch pointer to source served cell information */
                    p_src_cell_info = &src_asn_msg->cellsToModifyList.
                        cell_to_modify[count].served_cell_info;

                    asn1Init_f1ap_Served_Cell_Information(p_trg_cell_info);


                    if (SIM_SUCCESS != populate_served_cell_information(
                                &asn1_ctx,
                                p_trg_cell_info,
                                p_src_cell_info))
                    {
                        LOG_TRACE("Failed to compose Served cell information \n");
                        return SIM_FAILURE;
                    }
                }

                /* Populate system information */
                if (src_asn_msg->cellsToAddList.cell_to_add[count].bitmask 
                        & F1AP_GNB_DU_SERVED_CELL_SYSTEM_INFO_PRESENT)
                {
                    f1ap_GNB_DU_System_Information*  p_trg_sys_info = F1AP_NULL;
                    _f1ap_GNB_DU_System_Information* p_src_sys_info = F1AP_NULL;

                    p_elem->value.u._f1ap_Served_Cells_To_Modify_ItemIEs_1->m.gNB_DU_System_InformationPresent = 1;

                    /* Fetch pointer to target system information container */
                    p_trg_sys_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Modify_ItemIEs_1->gNB_DU_System_Information;

                    /* Fetch pointer to source system information container */
                    p_src_sys_info = &src_asn_msg->cellsToModifyList.
                        cell_to_modify[count].du_system_info;


                    populate_served_cell_system_information(
                            &asn1_ctx,
                            p_trg_sys_info,
                            p_src_sys_info);
                }


                rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_3,
                        list_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose served cells to Delete list */
	
	if(src_asn_msg->bitmask &  DU_CONFIG_UPDATE_CELLS_TO_DEL_LIST_PRESENT)
        {

            unsigned int                            count           = F1AP_NULL;
            f1ap_Served_Cells_To_Delete_List_element*  p_elem       = F1AP_P_NULL;
            OSRTDListNode*                          list_node       = F1AP_P_NULL;

            if ((0 == src_asn_msg->cellsToDeleteList.count) ||
                    (MAX_CELL_PER_DU < src_asn_msg->cellsToDeleteList.count))
            {
                LOG_TRACE("Count is not valid in modified cells list: %d", 
                        src_asn_msg->cellsToDeleteList.count);
                break;
            }
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(
                    p_protocolIE_elem);

            p_protocolIE_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Delete_List;

            p_protocolIE_elem->criticality = f1ap_reject;

            p_protocolIE_elem->value.t     = T16f1ap___f1ap_GNBDUConfigurationUpdateIEs_4;

            p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_4
                = rtxMemAllocType(&asn1_ctx,
                        f1ap_Served_Cells_To_Delete_List);

            if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_4)
            {
                LOG_TRACE("Failed to allocate memory for served cells list\n");
                return SIM_FAILURE;
            }
            asn1Init_f1ap_Served_Cells_To_Delete_List(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_4);		 	
            for (count = 0; ((count < src_asn_msg->cellsToDeleteList.count) && 
                        (count < MAX_CELL_PER_DU)); 
                    count++)
            {
                /* Allocate memory for node in the list */ 
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_Served_Cells_To_Delete_List_element,
                        &list_node,
                        &p_elem);

                if (F1AP_NULL == list_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_elem->id          = ASN1V_f1ap_id_Served_Cells_To_Delete_Item;
                p_elem->criticality = f1ap_reject;
                p_elem->value.t     = T19f1ap___f1ap_Served_Cells_To_Delete_ItemIEs_1;
                p_elem->value.u._f1ap_Served_Cells_To_Delete_ItemIEs_1
                    = rtxMemAllocType(&asn1_ctx,
                            f1ap_Served_Cells_To_Delete_Item);
                if (F1AP_NULL == p_elem->value.u._f1ap_Served_Cells_To_Delete_ItemIEs_1)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }
				
		asn1Init_f1ap_Served_Cells_To_Delete_Item(p_elem->value.u._f1ap_Served_Cells_To_Delete_ItemIEs_1);
                /* Populate served cell information */ 
                {

                    f1ap_NRCGI*  p_trg_old_cell_info = F1AP_P_NULL;
                    _f1ap_NCGI* p_src_old_cell_info = F1AP_P_NULL;

                    /* Fetch pointer to target served cell information */
                    p_trg_old_cell_info = &p_elem->value.u.
                        _f1ap_Served_Cells_To_Delete_ItemIEs_1->oldNRCGI;

                    /* Fetch pointer to source served cell information */
                    p_src_old_cell_info = &src_asn_msg->cellsToDeleteList.
                        cell_to_delete[count].ncgi;

                    asn1Init_f1ap_NRCGI(p_trg_old_cell_info);


                    p_trg_old_cell_info->pLMN_Identity.numocts 
                        = p_src_old_cell_info->pLMN_Identity.numocts;

                    memcpy(p_trg_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.data,
                            p_src_old_cell_info->pLMN_Identity.numocts);

                    p_trg_old_cell_info->nRCellIdentity.numbits   
                        = 36; //p_src_cell_info->nRCGI.nRCellIdentity.numbits;

                    memcpy(p_trg_old_cell_info->nRCellIdentity.data,   
                            p_src_old_cell_info->nRCellIdentity.data,
                            5);


                }

                rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_4,
                        list_node);

            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }
    /*new asn changes*/
#if 0
	if(src_asn_msg->bitmask &  DU_CONFIG_UPDATE_CELLS_TO_ACTIVE_LIST_PRESENT)
	{

		unsigned int                            count           = F1AP_NULL;
		f1ap_Active_Cells_List_element*         p_elem          = F1AP_P_NULL;
		OSRTDListNode*                          list_node       = F1AP_P_NULL;

		if ((0 == src_asn_msg->cellsToActiveList.count) ||
				(MAX_CELL_PER_DU < src_asn_msg->cellsToActiveList.count))
		{
			LOG_TRACE("Count is not valid in Active cells list: %d", 
					src_asn_msg->cellsToActiveList.count);
		//	break;
		}
		/* Allocate memory for target protocolIE element */
		rtxDListAllocNodeAndData(&asn1_ctx,
				f1ap_GNBDUConfigurationUpdate_protocolIEs_element,
				&p_node,
				&p_protocolIE_elem);

		if (F1AP_NULL == p_node)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}

            asn1Init_f1ap_GNBDUConfigurationUpdate_protocolIEs_element(
                    p_protocolIE_elem);

		p_protocolIE_elem->id          = ASN1V_f1ap_id_Active_Cells_List;

		p_protocolIE_elem->criticality = f1ap_reject;

		p_protocolIE_elem->value.t     = T16f1ap___f1ap_GNBDUConfigurationUpdateIEs_5;

		p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_5
			= rtxMemAllocType(&asn1_ctx,
					f1ap_Active_Cells_List);

		if (F1AP_NULL == p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_5)
		{
			LOG_TRACE("Failed to allocate memory for served cells list\n");
			return SIM_FAILURE;
		}

		asn1Init_f1ap_Active_Cells_List(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_5);		 	

		for (count = 0; ((count < src_asn_msg->cellsToActiveList.count) && 
					(count < MAX_CELL_PER_DU)); 
				count++)
		{
			/* Allocate memory for node in the list */ 
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_Active_Cells_List_element,
					&list_node,
					&p_elem);

			if (F1AP_NULL == list_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			p_elem->id          = ASN1V_f1ap_id_Active_Cells_Item;
			p_elem->criticality = f1ap_reject;
			p_elem->value.t     = T18f1ap___f1ap_Active_Cells_ItemIEs_1;
			p_elem->value.u._f1ap_Active_Cells_ItemIEs_1
				= rtxMemAllocType(&asn1_ctx,
						f1ap_Active_Cells_Item);
			if (F1AP_NULL == p_elem->value.u._f1ap_Active_Cells_ItemIEs_1)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_Active_Cells_Item(p_elem->value.u._f1ap_Active_Cells_ItemIEs_1);
			{

				f1ap_NRCGI*  p_trg_old_cell_info = F1AP_P_NULL;
				_f1ap_NCGI* p_src_old_cell_info = F1AP_P_NULL;

				/* Fetch pointer to target served cell information */
				p_trg_old_cell_info = &p_elem->value.u.
					_f1ap_Active_Cells_ItemIEs_1->nRCGI;

				/* Fetch pointer to source served cell information */
				p_src_old_cell_info = &src_asn_msg->cellsToActiveList.
					cell_to_Active[count].ncgi;

				asn1Init_f1ap_NRCGI(p_trg_old_cell_info);


				p_trg_old_cell_info->pLMN_Identity.numocts 
					= p_src_old_cell_info->pLMN_Identity.numocts;

				memcpy(p_trg_old_cell_info->pLMN_Identity.data,
						p_src_old_cell_info->pLMN_Identity.data,
						p_src_old_cell_info->pLMN_Identity.numocts);

				p_trg_old_cell_info->nRCellIdentity.numbits   
					= 36; //p_src_cell_info->nRCGI.nRCellIdentity.numbits;

				memcpy(p_trg_old_cell_info->nRCellIdentity.data,   
						p_src_old_cell_info->nRCellIdentity.data,
						5);


			}

			rtxDListAppendNode(p_protocolIE_elem->value.u._f1ap_GNBDUConfigurationUpdateIEs_4,
					list_node);

		}

		rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
	}
#endif
        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal            = SIM_SUCCESS;

            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


