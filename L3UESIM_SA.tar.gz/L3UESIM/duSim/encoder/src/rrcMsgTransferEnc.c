
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "rrc_asn_enc_dec_nr.h"
#include "du_sim_common.h"

#if 0
/* This function encodes DL RRC Message Transfer */
sim_return_val_et
dusim_handle_encode_dl_rrc_msg_transfer(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = NULL;
    f1ap_DLRRCMessageTransfer*  
                           p_asn_msg               = NULL;
    f1ap_DLRRCMessageTransfer_protocolIEs_element*  
                           p_protocolIE_elem       = NULL;
    _f1ap_DLRRCMessageTransfer* 
                           src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_DLRRCMessageTransfer*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_DLRRCMessageTransfer;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_ignore;

        /* Set the initiating message type to DL RRC Message Transfer */ 
        f1ap_pdu.u.initiatingMessage->value.t = T1f1ap__dLRRCMessageTransfer;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_DLRRCMessageTransfer);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_DLRRCMessageTransfer(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.dLRRCMessageTransfer 
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_DLRRCMessageTransfer_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DLRRCMessageTransfer_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T83f1ap___f1ap_DLRRCMessageTransferIEs_1;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_DLRRCMessageTransfer_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DLRRCMessageTransfer_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T83f1ap___f1ap_DLRRCMessageTransferIEs_2;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose old gNB-DU UE F1AP ID, if present in source container */
        if (F1AP_DL_RRC_MSG_TRANSFER_OLD_DU_UE_F1AP_ID_PRESENT &
                    src_asn_msg->bitmask)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_DLRRCMessageTransfer_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DLRRCMessageTransfer_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_oldgNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T83f1ap___f1ap_DLRRCMessageTransferIEs_3;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_3
                    = src_asn_msg->old_du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose SRB ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_DLRRCMessageTransfer_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DLRRCMessageTransfer_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_SRBID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T83f1ap___f1ap_DLRRCMessageTransferIEs_4;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_4
                    = src_asn_msg->srb_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose RRC Container */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_DLRRCMessageTransfer_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_DLRRCMessageTransfer_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_RRCContainer;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T83f1ap___f1ap_DLRRCMessageTransferIEs_6;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_6
                    = rtxMemAllocType(&asn1_ctx,
                            src_asn_msg->rrcContainerLength);

            if (NULL == p_protocolIE_elem->value.u.
                                    _f1ap_DLRRCMessageTransferIEs_6)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_6->numocts
                  = src_asn_msg->rrcContainerLength;

            p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_6->data
                  = rtxMemAlloc(&asn1_ctx,
                          src_asn_msg->rrcContainerLength);

            if (NULL == p_protocolIE_elem->value.u.
                                  _f1ap_DLRRCMessageTransferIEs_6->data)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            memcpy((char*)p_protocolIE_elem->value.u._f1ap_DLRRCMessageTransferIEs_6->data,
                   src_asn_msg->rrcContainer,
                   src_asn_msg->rrcContainerLength);

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}
#endif

void fill_f1ap_MeasQuantityResults(nr_rrc_MeasQuantityResults* trg_MeasQuantityResults,
        _f1ap_rrc_MeasQuantityResults * src_MeasQuantityResults)

{
    if (src_MeasQuantityResults->m.rsrpPresent)
    {
        trg_MeasQuantityResults->m.rsrpPresent = 1;

        trg_MeasQuantityResults->rsrp = src_MeasQuantityResults->rsrp.f1ap_rrc_RSRP_Range;
    }

    if (src_MeasQuantityResults->m.rsrqPresent)
    {
        trg_MeasQuantityResults->m.rsrqPresent = 1;

        trg_MeasQuantityResults->rsrq = src_MeasQuantityResults->rsrq.f1ap_rrc_RSRQ_Range;
    }

    if (src_MeasQuantityResults->m.sinrPresent)
    {
        trg_MeasQuantityResults->m.sinrPresent = 1;

        trg_MeasQuantityResults->sinr = src_MeasQuantityResults->sinr.f1ap_rrc_SINR_Range;
    }
    return;
}

void fill_du_MeasQuantityResults(nr_rrc_MeasQuantityResults* trg_MeasQuantityResults,
        _f1ap_rrc_MeasQuantityResults* src_MeasQuantityResults)

{
    if (src_MeasQuantityResults->m.rsrpPresent)
    {
        trg_MeasQuantityResults->m.rsrpPresent = 1;

        trg_MeasQuantityResults->rsrp = src_MeasQuantityResults->rsrp.f1ap_rrc_RSRP_Range;
    } 

    if (src_MeasQuantityResults->m.rsrqPresent)
    {
        trg_MeasQuantityResults->m.rsrqPresent = 1;

        trg_MeasQuantityResults->rsrq = src_MeasQuantityResults->rsrq.f1ap_rrc_RSRQ_Range;
    }

    if (src_MeasQuantityResults->m.sinrPresent)
    {
        trg_MeasQuantityResults->m.sinrPresent = 1;

        trg_MeasQuantityResults->sinr = src_MeasQuantityResults->sinr.f1ap_rrc_SINR_Range;
    }
    return; 
}


void fill_du_f1ap_MeasResultNR(nr_rrc_MeasResultNR* trg_MeasResultNR,
        _f1ap_rrc_MeasResultNR* src_MeasResultNR,
        OSCTXT                * asn1_ctx)
{
    //OSCTXT                  asn1_ctx;

    if(src_MeasResultNR->m.physCellIdPresent)
    {
        trg_MeasResultNR->m.physCellIdPresent = 1;
        trg_MeasResultNR->physCellId = src_MeasResultNR->physCellId.f1ap_rrc_PhysCellId;
    }

    /* This has been removed from latest ASN */
    // if(src_MeasResultNR->m.cgi_InfoPresent)
    //{
    //  trg_MeasResultNR->m.cgi_InfoPresent = 1;
    // trg_MeasResultNR->cgi_Info= src_MeasResultNR->cgi_Info.nr_rrc_MeasResultNR_cgi_Info;
    // }

    if(src_MeasResultNR->measResult.cellResults.m.resultsSSB_CellPresent)
    {
        trg_MeasResultNR->measResult.cellResults.m.resultsSSB_CellPresent = 1;
        fill_du_MeasQuantityResults(&trg_MeasResultNR->measResult.cellResults.resultsSSB_Cell,&src_MeasResultNR->measResult.cellResults.resultsSSB_Cell);          

    }
    if(src_MeasResultNR->measResult.cellResults.m.resultsCSI_RS_CellPresent)
    {
        trg_MeasResultNR->measResult.cellResults.m.resultsCSI_RS_CellPresent = 1;
        fill_du_MeasQuantityResults(&trg_MeasResultNR->measResult.cellResults.resultsCSI_RS_Cell,&src_MeasResultNR->measResult.cellResults.resultsCSI_RS_Cell);          
    }
    if(src_MeasResultNR->measResult.m.rsIndexResultsPresent)
    {
        trg_MeasResultNR->measResult.m.rsIndexResultsPresent = 1;
        if(src_MeasResultNR->measResult.rsIndexResults.m.resultsSSB_IndexesPresent)
        {
            trg_MeasResultNR->measResult.rsIndexResults.m.resultsSSB_IndexesPresent = 1;
            nr_rrc_ResultsPerSSB_Index*  p_elem = NULL;
            _f1ap_rrc_ResultsPerSSB_Index* src_elem = NULL;
            OSRTDListNode*               p_node   = NULL;
            unsigned short loop ;

            asn1Init_nr_rrc_ResultsPerSSB_IndexList(&trg_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes);
            //trg_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes.count = src_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes.count;
            for(loop=0; loop<src_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes.count; loop++)
            {
                /* Fetch pointer to source element */
                src_elem = &src_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes.f1ap_rrc_ResultsPerSSB_Index[loop];

                /* Allocate memory for list node */
                rtxDListAllocNodeAndData(asn1_ctx,
                        nr_rrc_ResultsPerSSB_Index,
                        &p_node,
                        &p_elem);

                if (NULL == p_node)
                {
                    LOG_TRACE("ASN malloc failed \n");
                    return;
                }

                asn1Init_nr_rrc_ResultsPerSSB_Index(p_elem);  

                p_elem->ssb_Index = src_elem->ssb_Index.f1ap_rrc_SSB_Index;
                if(src_elem->m.ssb_ResultsPresent)
                {
                    p_elem->m.ssb_ResultsPresent = 1;
                    fill_du_MeasQuantityResults(&p_elem->ssb_Results,&src_elem->ssb_Results);                       
                }

                /* Append node to the list */
                rtxDListAppendNode(
                        &trg_MeasResultNR->measResult.rsIndexResults.resultsSSB_Indexes,
                        p_node);

            }

        }
        if(src_MeasResultNR->measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent)
        {
            trg_MeasResultNR->measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent = 1;
            nr_rrc_ResultsPerCSI_RS_Index*  p_elem = NULL;
            _f1ap_rrc_ResultsPerCSI_RS_Index* src_elem = NULL;
            OSRTDListNode*               p_node   = NULL;
            unsigned short loop;

            asn1Init_nr_rrc_ResultsPerCSI_RS_IndexList(&trg_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes);
            //trg_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes.count = src_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes.count;


            for(loop=0; loop<src_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes.count; loop++)
            {
                /* Fetch pointer to source element */
                src_elem = &src_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes.f1ap_rrc_ResultsPerCSI_RS_Index[loop];

                /* Allocate memory for list node */
                rtxDListAllocNodeAndData(asn1_ctx,
                        nr_rrc_ResultsPerCSI_RS_Index,
                        &p_node,
                        &p_elem);

                if (NULL == p_node)
                {
                    LOG_TRACE("ASN malloc failed \n");
                    return;
                }

                asn1Init_nr_rrc_ResultsPerCSI_RS_Index(p_elem);

                p_elem->csi_RS_Index = src_elem->csi_RS_Index.f1ap_rrc_CSI_RS_Index;
                if (src_elem->m.csi_RS_ResultsPresent)
                {
                    p_elem->m.csi_RS_ResultsPresent = 1; 
                    fill_du_MeasQuantityResults(&p_elem->csi_RS_Results,&src_elem->csi_RS_Results);
                }

                /* Append node to the list */
                rtxDListAppendNode(
                        &trg_MeasResultNR->measResult.rsIndexResults.resultsCSI_RS_Indexes,
                        p_node);


            }
        } 

    }

}


sim_return_val_et
	f1ap_encode_rrc_container
(
 _f1ap_rrc_UL_DCCH_MessageType * p_src_rrc_container,
 UInt8**               p_encodedmsg,
 UInt32*              p_encodedmsg_len
 )
{
	sim_return_val_et           retVal                   = SIM_FAILURE;
	nr_rrc_UL_DCCH_MessageType      p_trg_rrc_container;

	OSCTXT                asn1_ctx;

	/* Init ASN1 context */
	if (0 != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.\n",
				__FUNCTION__);

		return  SIM_FAILURE;
	}
	/* Allocate memory for rrc container  */
	*p_encodedmsg = (unsigned char*)malloc(DU_F1AP_MAX_ASN1_BUF_LEN);
	if (NULL == *p_encodedmsg)
       {
	       LOG_TRACE("Failed to allocate memory for rrc Container \n");
	       return SIM_FAILURE;
       }

       memset((*p_encodedmsg), 0, DU_F1AP_MAX_ASN1_BUF_LEN);

       do 
         {
	//       asn1Init_nr_rrc_UL_DCCH_MessageType(&p_trg_rrc_container);

		p_trg_rrc_container.t = T_nr_rrc_UL_DCCH_MessageType_c1;

		if ( T_nr_rrc_UL_DCCH_MessageType_c1 == p_trg_rrc_container.t)
		{
			p_trg_rrc_container.u.c1 
				= rtxMemAllocType(&asn1_ctx,nr_rrc_UL_DCCH_MessageType_c1);

			if (NULL == p_trg_rrc_container.u.c1)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}

			asn1Init_nr_rrc_UL_DCCH_MessageType_c1(p_trg_rrc_container.u.c1);

			p_trg_rrc_container.u.c1->t =  p_src_rrc_container->u.c1.t;

			if (T_nr_rrc_UL_DCCH_MessageType_c1_measurementReport == p_trg_rrc_container.u.c1->t)
			{
                                  nr_rrc_MeasurementReport_IEs  * p_MeasurementReport_IEs = NULL;
                                _f1ap_rrc_MeasurementReport_IEs * src_MeasurementReport_IEs = NULL ;

				p_trg_rrc_container.u.c1->u.measurementReport 
					= rtxMemAllocType(&asn1_ctx,
							nr_rrc_MeasurementReport);

				if (NULL == p_trg_rrc_container.u.c1->u.measurementReport)
				{
					LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
					break;
				}

				asn1Init_nr_rrc_MeasurementReport
					(p_trg_rrc_container.u.c1->u.measurementReport);

				p_trg_rrc_container.u.c1->u.measurementReport->criticalExtensions.t = 
					T_nr_rrc_MeasurementReport_criticalExtensions_measurementReport;

				if (T_nr_rrc_MeasurementReport_criticalExtensions_measurementReport == 
						p_trg_rrc_container.u.c1->u.measurementReport->criticalExtensions.t)
				{
					p_trg_rrc_container.u.c1->u.measurementReport->criticalExtensions.u.
						measurementReport = rtxMemAllocType(&asn1_ctx,
								nr_rrc_MeasurementReport_IEs);

					if (NULL == p_trg_rrc_container.u.c1->u.measurementReport->
							criticalExtensions.u.measurementReport)
					{
						LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
						break;
					}

					asn1Init_nr_rrc_MeasurementReport_IEs
						(p_trg_rrc_container.u.c1->u.measurementReport->
						 criticalExtensions.u.measurementReport);

					p_MeasurementReport_IEs = p_trg_rrc_container.u.c1->u.measurementReport->
						criticalExtensions.u.measurementReport;

					src_MeasurementReport_IEs = 
						&p_src_rrc_container->u.c1.u.measurementReport.
						criticalExtensions.u.measurementReport;

					p_MeasurementReport_IEs->measResults.measId = 
						src_MeasurementReport_IEs->measResults.measId.f1ap_rrc_MeasId;

					/*measResultServingMOList*/
					_f1ap_rrc_MeasResultServMO *src_elem = NULL;
					nr_rrc_MeasResultServMO * p_elem = NULL;
                                        unsigned short loop = 0;
					OSRTDListNode*               p_node9   = NULL;
					for (loop = 0; loop <  src_MeasurementReport_IEs->measResults.measResultServingMOList.count; loop ++)
					{
						/* Fetch pointer to source element */
						src_elem = &src_MeasurementReport_IEs->measResults.
							measResultServingMOList._f1ap_rrc_MeasResultServMO[loop];

						/* Allocate memory for list node */
						rtxDListAllocNodeAndData(&asn1_ctx,
								nr_rrc_MeasResultServMO,
								&p_node9,
								&p_elem);

						if (NULL == p_node9)
						{
							LOG_TRACE("ASN malloc failed \n");
							return SIM_FAILURE;
						}

						asn1Init_nr_rrc_MeasResultServMO(p_elem);

						/*servCellId*/
						p_elem->servCellId =
							src_elem->servCellId.f1ap_rrc_ServCellIndex;

						/*measResultServingCell*/

						if (src_elem->measResultServingCell.m.physCellIdPresent)
						{
							p_elem->measResultServingCell.m.physCellIdPresent = 1;

							p_elem->measResultServingCell.physCellId = src_elem->measResultServingCell.physCellId.f1ap_rrc_PhysCellId;
						}


						if(src_elem->measResultServingCell.measResult.cellResults.m.resultsSSB_CellPresent)
						{
							p_elem->measResultServingCell.measResult.cellResults.m.resultsSSB_CellPresent = 1;
							fill_f1ap_MeasQuantityResults(&p_elem->measResultServingCell.measResult.
									cellResults.resultsSSB_Cell,&src_elem->measResultServingCell.measResult.
									cellResults.resultsSSB_Cell);

						}
						if(src_elem->measResultServingCell.measResult.cellResults.m.resultsCSI_RS_CellPresent)
						{
							p_elem->measResultServingCell.measResult.cellResults.m.
								resultsCSI_RS_CellPresent = 1;

							fill_f1ap_MeasQuantityResults(&p_elem->measResultServingCell.measResult.cellResults.
									resultsCSI_RS_Cell,&src_elem->measResultServingCell.measResult.
									cellResults.resultsCSI_RS_Cell);

						}
						if(src_elem->measResultServingCell.measResult.m.rsIndexResultsPresent)
						{
							p_elem->measResultServingCell.measResult.m.rsIndexResultsPresent = 1;
							if(src_elem->measResultServingCell.measResult.rsIndexResults.m.resultsSSB_IndexesPresent)
							{
								p_elem->measResultServingCell.measResult.rsIndexResults.m.resultsSSB_IndexesPresent = 1;
								nr_rrc_ResultsPerSSB_Index*  p_elem1 = NULL;
								_f1ap_rrc_ResultsPerSSB_Index* src_elem1 = NULL;
								OSRTDListNode*               p_node1   = NULL;
								unsigned short loop ;

								asn1Init_nr_rrc_ResultsPerSSB_IndexList(&p_elem->measResultServingCell.
										measResult.rsIndexResults.resultsSSB_Indexes);

								for(loop=0; loop<src_elem->measResultServingCell.measResult.
										rsIndexResults.resultsSSB_Indexes.count; loop++)
								{
									/* Fetch pointer to source element */
									src_elem1 = &src_elem->measResultServingCell.measResult.
										rsIndexResults.resultsSSB_Indexes.f1ap_rrc_ResultsPerSSB_Index[loop];

									/* Allocate memory for list node */
									rtxDListAllocNodeAndData(&asn1_ctx,
											nr_rrc_ResultsPerSSB_Index,
											&p_node1,
											&p_elem1);

									if (NULL == p_node1)
									{
										LOG_TRACE("ASN malloc failed \n");
										return SIM_FAILURE;
									}

									asn1Init_nr_rrc_ResultsPerSSB_Index(p_elem1);

									p_elem1->ssb_Index = src_elem1->ssb_Index.f1ap_rrc_SSB_Index;
									if(src_elem1->m.ssb_ResultsPresent)
									{
										p_elem1->m.ssb_ResultsPresent = 1;
										fill_f1ap_MeasQuantityResults(&p_elem1->ssb_Results,&src_elem1->ssb_Results);
									}

									/* Append node to the list */
									rtxDListAppendNode(
											&p_elem->measResultServingCell.measResult.rsIndexResults.resultsSSB_Indexes,
											p_node1);

								}

							}
							if(src_elem->measResultServingCell.measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent)
							{
								p_elem->measResultServingCell.measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent = 1;
								nr_rrc_ResultsPerCSI_RS_Index*  p_elem2 = NULL;
								_f1ap_rrc_ResultsPerCSI_RS_Index* src_elem2 = NULL;
								OSRTDListNode*               p_node2   = NULL;
								unsigned short loop;

								asn1Init_nr_rrc_ResultsPerCSI_RS_IndexList(&p_elem->measResultServingCell.
										measResult.rsIndexResults.resultsCSI_RS_Indexes);

								for(loop=0; loop<src_elem->measResultServingCell.measResult.rsIndexResults.
										resultsCSI_RS_Indexes.count; loop++)
								{
									/* Fetch pointer to source element */
									src_elem2 = &src_elem->measResultServingCell.measResult.rsIndexResults.
										resultsCSI_RS_Indexes.f1ap_rrc_ResultsPerCSI_RS_Index[loop];

									/* Allocate memory for list node */
									rtxDListAllocNodeAndData(&asn1_ctx,
											nr_rrc_ResultsPerCSI_RS_Index,
											&p_node2,
											&p_elem2);

									if (NULL == p_node2)
									{
										LOG_TRACE("ASN malloc failed \n");
										return SIM_FAILURE;

									}

									asn1Init_nr_rrc_ResultsPerCSI_RS_Index(p_elem2);

									p_elem2->csi_RS_Index = src_elem2->csi_RS_Index.f1ap_rrc_CSI_RS_Index;

									if (src_elem2->m.csi_RS_ResultsPresent)
									{
										p_elem2->m.csi_RS_ResultsPresent = 1;
										fill_f1ap_MeasQuantityResults(&p_elem2->csi_RS_Results,&src_elem2->csi_RS_Results);
									}

									/* Append node to the list */
									rtxDListAppendNode(
											&p_elem->measResultServingCell.measResult.rsIndexResults.resultsCSI_RS_Indexes,
											p_node2);


								}
							}//resultsCSI_RS_IndexesPresent

						}//rsIndexResultsPresent

						/*measResultBestNeighCell*/
						if (src_elem->m.measResultBestNeighCellPresent)
						{
							p_elem->m.measResultBestNeighCellPresent = 1;

							if (src_elem->measResultBestNeighCell.m.physCellIdPresent)
							{
								p_elem->measResultBestNeighCell.m.physCellIdPresent = 1;

								p_elem->measResultBestNeighCell.physCellId = src_elem->
									measResultBestNeighCell.physCellId.f1ap_rrc_PhysCellId;
							}

							if(src_elem->measResultBestNeighCell.measResult.cellResults.m.resultsSSB_CellPresent)
							{
								p_elem->measResultBestNeighCell.measResult.cellResults.m.resultsSSB_CellPresent = 1;
								fill_f1ap_MeasQuantityResults(&p_elem->measResultBestNeighCell.measResult.
										cellResults.resultsSSB_Cell,&src_elem->measResultBestNeighCell.measResult.
										cellResults.resultsSSB_Cell);

							}
							if(src_elem->measResultBestNeighCell.measResult.
									cellResults.m.resultsCSI_RS_CellPresent)
							{
								p_elem->measResultBestNeighCell.measResult.cellResults.m.
									resultsCSI_RS_CellPresent = 1;

								fill_f1ap_MeasQuantityResults(&p_elem->measResultBestNeighCell.measResult.cellResults.
										resultsCSI_RS_Cell,&src_elem->measResultBestNeighCell.measResult.
										cellResults.resultsCSI_RS_Cell);
							}

							if(src_elem->measResultBestNeighCell.measResult.m.rsIndexResultsPresent)
							{
								p_elem->measResultBestNeighCell.measResult.m.rsIndexResultsPresent = 1;

								if(src_elem->measResultBestNeighCell.measResult.rsIndexResults.m.resultsSSB_IndexesPresent)
								{
									p_elem->measResultBestNeighCell.measResult.rsIndexResults.m.
										resultsSSB_IndexesPresent = 1;

									nr_rrc_ResultsPerSSB_Index*  p_elem1 = NULL;
								        _f1ap_rrc_ResultsPerSSB_Index* src_elem1 = NULL;
									OSRTDListNode*               p_node1   = NULL;
									unsigned short loop ;

									asn1Init_nr_rrc_ResultsPerSSB_IndexList(&p_elem->measResultBestNeighCell.
											measResult.rsIndexResults.resultsSSB_Indexes);

									for(loop=0; loop<src_elem->measResultBestNeighCell.measResult.
											rsIndexResults.resultsSSB_Indexes.count; loop++)
									{
										/* Fetch pointer to source element */
										src_elem1 = &src_elem->measResultBestNeighCell.measResult.
											rsIndexResults.resultsSSB_Indexes.f1ap_rrc_ResultsPerSSB_Index[loop];

										/* Allocate memory for list node */
										rtxDListAllocNodeAndData(&asn1_ctx,
												nr_rrc_ResultsPerSSB_Index,
												&p_node1,
												&p_elem1);

										if (NULL == p_node1)
										{
											LOG_TRACE("ASN malloc failed \n");
											return SIM_FAILURE;
										}

										asn1Init_nr_rrc_ResultsPerSSB_Index(p_elem1);

										p_elem1->ssb_Index = src_elem1->ssb_Index.f1ap_rrc_SSB_Index;
										if(src_elem1->m.ssb_ResultsPresent)
										{
											p_elem1->m.ssb_ResultsPresent = 1;
											fill_f1ap_MeasQuantityResults(&p_elem1->ssb_Results,&src_elem1->ssb_Results);
										}

										/* Append node to the list */
										rtxDListAppendNode(
												&p_elem->measResultBestNeighCell.
												measResult.rsIndexResults.resultsSSB_Indexes,
												p_node1);

									}

								}
								if(src_elem->measResultBestNeighCell
										.measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent)
								{
									p_elem->measResultBestNeighCell.measResult.rsIndexResults.m.resultsCSI_RS_IndexesPresent = 1;
									nr_rrc_ResultsPerCSI_RS_Index*  p_elem2 = NULL;
									_f1ap_rrc_ResultsPerCSI_RS_Index* src_elem2 = NULL;
									OSRTDListNode*               p_node2   = NULL;
									unsigned short loop;

									asn1Init_nr_rrc_ResultsPerCSI_RS_IndexList(&p_elem->measResultBestNeighCell.
											measResult.rsIndexResults.resultsCSI_RS_Indexes);

									for(loop=0; loop<src_elem->measResultBestNeighCell.measResult.rsIndexResults.
											resultsCSI_RS_Indexes.count; loop++)
									{
										/* Fetch pointer to source element */
										src_elem2 = &src_elem->measResultBestNeighCell.measResult.rsIndexResults.
											resultsCSI_RS_Indexes.f1ap_rrc_ResultsPerCSI_RS_Index[loop];

										/* Allocate memory for list node */
										rtxDListAllocNodeAndData(&asn1_ctx,
												nr_rrc_ResultsPerCSI_RS_Index,
												&p_node2,
												&p_elem2);

										if (NULL == p_node2)
										{
											LOG_TRACE("ASN malloc failed \n");
											return SIM_FAILURE;

										}

										asn1Init_nr_rrc_ResultsPerCSI_RS_Index(p_elem2);

										p_elem2->csi_RS_Index = src_elem2->csi_RS_Index.f1ap_rrc_CSI_RS_Index;

										if (src_elem2->m.csi_RS_ResultsPresent)
										{
											p_elem2->m.csi_RS_ResultsPresent = 1;
											fill_f1ap_MeasQuantityResults(&p_elem2->csi_RS_Results,&src_elem2->csi_RS_Results);
										}

										/* Append node to the list */
										rtxDListAppendNode(
												&p_elem->measResultBestNeighCell.measResult.rsIndexResults.resultsCSI_RS_Indexes,
												p_node2);


									}
								}
							}//rsIndexResultsPresent

						}//measResultBestNeighCell
						rtxDListAppendNode(&p_MeasurementReport_IEs->measResults.measResultServingMOList,p_node9);

					}
					if (src_MeasurementReport_IEs->measResults.m.measResultNeighCellsPresent)
					{
						_f1ap_rrc_MeasResults_measResultNeighCells *src_elem1 = NULL;
						nr_rrc_MeasResults_measResultNeighCells * p_elem1 = NULL;

						src_elem1 = &src_MeasurementReport_IEs->measResults.measResultNeighCells;
						p_elem1 =  &p_MeasurementReport_IEs->measResults.measResultNeighCells;

						p_MeasurementReport_IEs->measResults.m.measResultNeighCellsPresent = 1;
						p_elem1->t = src_elem1->t;

						if (p_elem1->t == T_nr_rrc_MeasResults_measResultNeighCells_measResultListNR)
						{
							p_elem1->u.measResultListNR
								= rtxMemAllocType(&asn1_ctx,
										nr_rrc_MeasResultListNR);

							if (NULL == p_elem1->u.measResultListNR)
							{
								LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
								return SIM_FAILURE;
							}

							asn1Init_nr_rrc_MeasResultListNR(p_elem1->u.measResultListNR);

							nr_rrc_MeasResultNR          *p_elem6 = NULL;
							_f1ap_rrc_MeasResultNR          *src_elem6 = NULL;
							OSRTDListNode*                  p_node5        = NULL;
							unsigned short loop5;

							for(loop5=0; loop5< src_elem1->u.measResultListNR.count; loop5++)
							{
								/* Fetch pointer to source element */
								src_elem6 = &src_elem1->u.measResultListNR.f1ap_rrc_MeasResulNR[loop5];
								/* Allocate memory for list node */
								rtxDListAllocNodeAndData(&asn1_ctx,
										nr_rrc_MeasResultNR,
										&p_node5,
										&p_elem6);

								if (NULL == p_node5)
								{
									LOG_TRACE("ASN malloc failed \n");
									return SIM_FAILURE;
								}

								asn1Init_nr_rrc_MeasResultNR(p_elem6);

								fill_du_f1ap_MeasResultNR(p_elem6,src_elem6,&asn1_ctx);

								/* Append node to the list */
								rtxDListAppendNode(
										p_elem1->u.measResultListNR,
										p_node5);
							}
						}
					}
					if (src_MeasurementReport_IEs->m.lateNonCriticalExtensionPresent)
					{
						p_MeasurementReport_IEs->m.lateNonCriticalExtensionPresent = 1;

						p_MeasurementReport_IEs->lateNonCriticalExtension.numocts =
							src_MeasurementReport_IEs->lateNonCriticalExtension.numocts;

						p_MeasurementReport_IEs->lateNonCriticalExtension.data =
							rtxMemAlloc(&asn1_ctx, src_MeasurementReport_IEs->lateNonCriticalExtension.numocts);

						memcpy((void*)p_MeasurementReport_IEs->lateNonCriticalExtension.data,
								src_MeasurementReport_IEs->lateNonCriticalExtension.data,
								src_MeasurementReport_IEs->lateNonCriticalExtension.numocts);
					}
				}
			}
			else if (T_nr_rrc_UL_DCCH_MessageType_c1_rrcReconfigurationComplete ==  p_trg_rrc_container.u.c1->t)
			{
                                nr_rrc_RRCReconfigurationComplete_IEs  *trg_reconfig = NULL;
                                _f1ap_rrc_RRCReconfigurationComplete_IEs *src_reconfig = NULL;
				p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete 
					= rtxMemAllocType(&asn1_ctx,
							nr_rrc_RRCReconfigurationComplete);

				if (NULL == p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete)
				{
					LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
					break;
				}

				asn1Init_nr_rrc_RRCReconfigurationComplete
					(p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete);

				p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->rrc_TransactionIdentifier = 
					p_src_rrc_container->u.c1.u.rrcReconfigurationComplete.rrc_TransactionIdentifier.
					f1ap_rrc_RRC_TransactionIdentifier;

                                 p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->criticalExtensions.t = 
                                 T_nr_rrc_RRCReconfigurationComplete_criticalExtensions_rrcReconfigurationComplete;

				p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->criticalExtensions.u.
					rrcReconfigurationComplete
					= rtxMemAllocType(&asn1_ctx,
							nr_rrc_RRCReconfigurationComplete_IEs);

				if (NULL ==  p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->criticalExtensions.u.
						rrcReconfigurationComplete)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_nr_rrc_RRCReconfigurationComplete_IEs
					(p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->criticalExtensions.u.
					 rrcReconfigurationComplete);

				trg_reconfig =  p_trg_rrc_container.u.c1->u.rrcReconfigurationComplete->criticalExtensions.u.
					rrcReconfigurationComplete;

				src_reconfig = &p_src_rrc_container->u.c1.u.rrcReconfigurationComplete.criticalExtensions.u.
					rrcReconfigurationComplete;

				if (src_reconfig->m.lateNonCriticalExtensionPresent)
				{
					trg_reconfig->m.lateNonCriticalExtensionPresent = 1;
					trg_reconfig->lateNonCriticalExtension.numocts =
						src_reconfig->lateNonCriticalExtension.numocts;

					trg_reconfig->lateNonCriticalExtension.data =
						rtxMemAlloc(&asn1_ctx, src_reconfig->lateNonCriticalExtension.numocts);

					memcpy((void*)trg_reconfig->lateNonCriticalExtension.data,
							src_reconfig->lateNonCriticalExtension.data,
							src_reconfig->lateNonCriticalExtension.numocts);
				}

			}
		}
		else if (T_nr_rrc_UL_DCCH_MessageType_messageClassExtension == p_trg_rrc_container.t)
		{
			p_trg_rrc_container.u.messageClassExtension 
				= rtxMemAllocType(&asn1_ctx,nr_rrc_UL_DCCH_MessageType_messageClassExtension);

			if (NULL == p_trg_rrc_container.u.messageClassExtension)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}
			//asn1Init_nr_rrc_UL_DCCH_MessageType_c1(p_trg_rrc_container.u.messageClassExtension);
			//p_trg_rrc_container.u.c1->t =  p_src_rrc_container->u.c1.t;
                 }
		/* ASN Encode message */
		pu_setBuffer(&asn1_ctx, *p_encodedmsg,
				DU_F1AP_MAX_ASN1_BUF_LEN, FALSE);

		if (0 != asn1PE_nr_rrc_UL_DCCH_MessageType(&asn1_ctx, &p_trg_rrc_container))
		{
			char buff[500];
			rtxErrGetTextBuf(&asn1_ctx,buff ,500);
			LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
			LOG_TRACE("Failed to encode RRC Container  \n");
		        return SIM_FAILURE;;
		}
		else
		{
			*p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
			retVal = SIM_SUCCESS;
			asn1Print_nr_rrc_UL_DCCH_MessageType("f1ap_pdu", &p_trg_rrc_container);
		}

	}while(0);

	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);
	return retVal;
}

//UL RRC TRANSFER changes
/* This function encodes UL RRC Message Transfer */
	sim_return_val_et
dusim_handle_encode_ul_rrc_msg_transfer(
/* spr 24900 changes start */
		unsigned char*  apiBuf,
/* spr 24900 changes end */        
		unsigned int    apiBufLen,
		unsigned char** p_p_encodedmsg,
		unsigned long*  p_encodedmsg_len)
{
	sim_return_val_et      retVal                  = SIM_FAILURE;
	OSCTXT                 asn1_ctx;
	f1ap_F1AP_PDU          f1ap_pdu;
	OSRTDListNode*         p_node                  = NULL;
	f1ap_ULRRCMessageTransfer*  
		p_asn_msg               = NULL;
	f1ap_ULRRCMessageTransfer_protocolIEs_element*  
		p_protocolIE_elem       = NULL;
	_f1ap_ULRRCMessageTransfer* 
		src_asn_msg             = NULL;
	_f1ap_ULRRCMessageTransfer_protocolIEs_element*
		src_protoIE_elem  = NULL;
          unsigned short index = 0;

	/* Init ASN1 context */
	if (0 != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.",
				__FUNCTION__);
		return retVal;
	}

	/* Allocate memory for target buffer */
	*p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

	if (NULL == *p_p_encodedmsg)
	{
		LOG_TRACE("Failed to allocate memory for message buffer \n");
		return SIM_FAILURE;
	}

	memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

	do
	{
		memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

		src_asn_msg = (_f1ap_ULRRCMessageTransfer*)apiBuf;

		/* Fill the values in the ASN structures that shall be encoded by
		 ** ASN Encoder */

		/* Set Pdu type to Initiating message */
		f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

		f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
				f1ap_InitiatingMessage);
		if (NULL == f1ap_pdu.u.initiatingMessage)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}

		asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

		/* Fill procedure code */
		f1ap_pdu.u.initiatingMessage->procedureCode 
			= ASN1V_f1ap_id_ULRRCMessageTransfer;

		/* Fill criticality of message type */
		f1ap_pdu.u.initiatingMessage->criticality = f1ap_ignore;

		/* Set the initiating message type to UL RRC Message Transfer */ 
		f1ap_pdu.u.initiatingMessage->value.t = T2f1ap__uLRRCMessageTransfer;

		p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_ULRRCMessageTransfer);
		if (NULL == p_asn_msg)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}

		asn1Init_f1ap_ULRRCMessageTransfer(p_asn_msg);

		f1ap_pdu.u.initiatingMessage->value.u.uLRRCMessageTransfer
			= p_asn_msg;

		for (index = 0; index < src_asn_msg->protocolIEs.count; index++)
		{
			src_protoIE_elem = &src_asn_msg->protocolIEs._f1ap_ULRRCMessageTransfer_protocolIEs_element[index];


			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_ULRRCMessageTransfer_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_ULRRCMessageTransfer_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= src_protoIE_elem->id;
			p_protocolIE_elem->criticality 
				= src_protoIE_elem->criticality;

			switch(src_protoIE_elem->id)
			{
				/* Compose gNB-CU UE F1AP ID */
				case ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID: 
					{
						p_protocolIE_elem->value.t     
							= T86f1ap___f1ap_ULRRCMessageTransferIEs_1;

						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_1
							= src_protoIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_1.cu_f1ap_id;

						rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
						break;
					}

					/* Compose gNB-DU UE F1AP ID */
				case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID:
					{
						p_protocolIE_elem->value.t     
							= T86f1ap___f1ap_ULRRCMessageTransferIEs_2;

						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_2
							= src_protoIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_2.du_f1ap_id;

						rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
						break;
					}

					/* Compose SRB ID */
				case ASN1V_f1ap_id_SRBID:
					{
						p_protocolIE_elem->value.t     
							= T86f1ap___f1ap_ULRRCMessageTransferIEs_3;

						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_3
							= src_protoIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_3.srb_id;

						rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
						break;
					}

					/* Compose RRC Container */
				case ASN1V_f1ap_id_RRCContainer:
					{
						UInt32 rrcContainerLength = 0;    
						UInt8*    rrcContainer_buf = F1AP_P_NULL;

						p_protocolIE_elem->value.t     
							= T86f1ap___f1ap_ULRRCMessageTransferIEs_4;

						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4
							= rtxMemAllocType(&asn1_ctx,
									f1ap_RRCContainer);

						if (NULL == p_protocolIE_elem->value.u.
								_f1ap_ULRRCMessageTransferIEs_4)
						{
							LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
							break;
						}

						asn1Init_f1ap_RRCContainer(p_protocolIE_elem->value.u.
								_f1ap_ULRRCMessageTransferIEs_4);

						if (SIM_SUCCESS != f1ap_encode_rrc_container(
									&src_protoIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4,
									&rrcContainer_buf,
									&rrcContainerLength))
						{
							/* Free the allocated memory to the rrc container buffer */
							free(rrcContainer_buf);
							rrcContainer_buf = F1AP_NULL;
							break;
						}


						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4->numocts
							= rrcContainerLength;

						p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4->data
							= rtxMemAlloc(&asn1_ctx,
									rrcContainerLength);

						if (NULL == p_protocolIE_elem->value.u.
								_f1ap_ULRRCMessageTransferIEs_4->data)
						{
							LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
							break;
						}

						memcpy((char*)p_protocolIE_elem->value.u._f1ap_ULRRCMessageTransferIEs_4->data,
								rrcContainer_buf,
								rrcContainerLength);

						rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
						break;
					}
			}
		}
		/* ASN Encode message */
		pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
				F1AP_MAX_ASN1_BUF_LEN, TRUE);

		if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
		{
			char buff[500];
			rtxErrGetTextBuf(&asn1_ctx,buff ,500);
			LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
			LOG_TRACE("ASN1 encoding of UL RRC transfer failed.");
			break;
		}
		else
		{
			*p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
			retVal = SIM_SUCCESS;
			asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
		}

	}while(0);

	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);

	return SIM_SUCCESS;
}

/* This function encodes Initial UL RRC Message Transfer */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_init_ul_rrc_msg_transfer
 * Description    : This function encodes Initial UL RRC Msg Transfer
 * Inputs         : _f1ap_InitialULRRCMessageTransfer* :
 *                src_asn_msg : Pointer to F1AP Init UL RRC Msg Transfer
 *                char*           apiBuf
 *                unsigned int    apiBufLen
 *                UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                length
 * Outputs        : ASN Encoded Init UL RRC Msg Transfer
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 *******************************************************************************/
        sim_return_val_et
dusim_handle_encode_init_ul_rrc_msg_transfer(
/* spr 24900 changes start */
                unsigned char*   apiBuf,
/* spr 24900 changes end */                
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len)
{
        sim_return_val_et                     retVal                = SIM_FAILURE;
        OSCTXT                                asn1_ctx;
        f1ap_F1AP_PDU                         f1ap_pdu;
        OSRTDListNode*                        p_node                = NULL;
        unsigned short                        index                 = 0;


        /* 3GPP Defined Structure */
        f1ap_InitialULRRCMessageTransfer *
                                              p_asn_msg             = NULL;

        f1ap_InitialULRRCMessageTransfer_protocolIEs_element*
                                              p_protocolIE_elem     = NULL;

        /* Flat Structure */
        _f1ap_InitialULRRCMessageTransfer*
                                              src_asn_msg           = NULL;

        _f1ap_InitialULRRCMessageTransfer_protocolIEs_element*
                                              src_protocolIE_elem   = NULL;

	/* Init ASN1 context */
        if (0 != rtInitContext(&asn1_ctx))
        {
                LOG_TRACE("%s:ASN context initialization failed.",
                                __FUNCTION__);
                return retVal;
        }

        /* Allocate memory for target buffer */
        *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

        if (NULL == *p_p_encodedmsg)
        {
                LOG_TRACE("Failed to allocate memory for message buffer \n");
                return SIM_FAILURE;
        }

        memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

        do
        {
                memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

                src_asn_msg =
                        (_f1ap_InitialULRRCMessageTransfer*)apiBuf;

                /* Fill the values in the ASN structures that shall be encoded by ASN Encoder */

                /* Set Pdu type to Initiating message */
                f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

                f1ap_pdu.u.initiatingMessage = rtxMemAllocType(
                                        &asn1_ctx,
                                        f1ap_InitiatingMessage);

                if (NULL == f1ap_pdu.u.initiatingMessage)
                {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                }

                asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);
		
		/* Fill procedure code */
                f1ap_pdu.u.initiatingMessage->procedureCode
                        = ASN1V_f1ap_id_InitialULRRCMessageTransfer;

                /* Fill criticality of message type */
                f1ap_pdu.u.initiatingMessage->criticality = f1ap_ignore;

                /* Set the initiating message type to Init UL RRC Message Transfer */
                f1ap_pdu.u.initiatingMessage->value.t = T2f1ap__initialULRRCMessageTransfer;

                p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_InitialULRRCMessageTransfer);
                if (NULL == p_asn_msg)
                {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                }

                asn1Init_f1ap_InitialULRRCMessageTransfer(p_asn_msg);

                f1ap_pdu.u.initiatingMessage->value.u.initialULRRCMessageTransfer
                        = p_asn_msg;


                for (index = 0; index < src_asn_msg->protocolIEs.count; index++)
                {
                        src_protocolIE_elem = &src_asn_msg->protocolIEs.
                                f1ap_InitialULRRCMessageTransfer_protocolIEs_element[index];

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_InitialULRRCMessageTransfer_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }
                        /* Init for target */
                        asn1Init_f1ap_InitialULRRCMessageTransfer_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id = src_protocolIE_elem->id;
                        p_protocolIE_elem->criticality =
                                src_protocolIE_elem->criticality;

			switch(src_protocolIE_elem->id)
                        {

                                /* Compose gNB-DU-UE-F1AP-ID */
                                case ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID:
                                        {

                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_1;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_1
                                                        = src_protocolIE_elem->value.u.
                                                        _f1ap_InitialULRRCMessageTransferIEs_1.gnb_du_ue_f1ap_id;

                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }

                                        /*Compose NR-CGI */
                                case ASN1V_f1ap_id_NRCGI:
                                        {

                                                f1ap_NRCGI *    p_trg_ncgi_info = NULL;
                                                _f1ap_NCGI *    p_src_ncgi_info = NULL;

                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_2;


                                                /* Fetch pointer to source served cell information */
                                                p_src_ncgi_info = &src_protocolIE_elem->value.u.
                                                        _f1ap_InitialULRRCMessageTransferIEs_2;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_2 =
                                                                rtxMemAllocType(&asn1_ctx,f1ap_NRCGI);
                                                if (NULL == p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_2)
                                                {
                                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                                        break;
                                                }
                                                asn1Init_f1ap_NRCGI(p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_2);

                                                /* Fetch pointer to target served cell information */
                                                p_trg_ncgi_info = p_protocolIE_elem->value.u.
                                                        _f1ap_InitialULRRCMessageTransferIEs_2;

						/* PLMN ID */
                                                p_trg_ncgi_info->pLMN_Identity.numocts =
                                                                p_src_ncgi_info->pLMN_Identity.numocts;

                                                memcpy(p_trg_ncgi_info->pLMN_Identity.data,
                                                                p_src_ncgi_info->pLMN_Identity.data,
                                                                p_src_ncgi_info->pLMN_Identity.numocts);

                                                /* NR-CELL-IDENTITY */
                                                p_trg_ncgi_info->nRCellIdentity.numbits =
                                                        p_src_ncgi_info->nRCellIdentity.numbits;

                                                memcpy(p_trg_ncgi_info->nRCellIdentity.data,
                                                                p_src_ncgi_info->nRCellIdentity.data,
                                                                p_src_ncgi_info->nRCellIdentity.numbits);

                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }

                                        /* Compose c-RNTI */
                                case ASN1V_f1ap_id_C_RNTI:
                                        {
                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_3;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_3
                                                        = src_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_3.c_rnti;

                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }

					/* Compose RRC Container */
                                case ASN1V_f1ap_id_RRCContainer:
                                        {

                                                UInt32 rrcContainerLength = 0;
                                                UInt8*    rrcContainer_buf = F1AP_P_NULL;

                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_4;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_4 =
                                                        rtxMemAllocType(&asn1_ctx, f1ap_RRCContainer);

                                                if (NULL == p_protocolIE_elem->value.u.
                                                                _f1ap_InitialULRRCMessageTransferIEs_4)
                                                {
                                                        LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                                                        break;
                                                }

                                                asn1Init_f1ap_RRCContainer(p_protocolIE_elem->value.u.
                                                                _f1ap_InitialULRRCMessageTransferIEs_4);

                                                if (SIM_SUCCESS != f1ap_encode_rrc_container(
                                                                        &src_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_4,
                                                                        &rrcContainer_buf,
                                                                        &rrcContainerLength))
                                                {
                                                        /* Free the allocated memory to the rrc container buffer */
                                                        free(rrcContainer_buf);
                                                        rrcContainer_buf = F1AP_NULL;
                                                        break;
                                                }


                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_4->numocts
                                                        = rrcContainerLength;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_4->data
                                                        = rtxMemAlloc(&asn1_ctx,
                                                                        rrcContainerLength);
						if (NULL == p_protocolIE_elem->value.u.
                                                                _f1ap_InitialULRRCMessageTransferIEs_4->data)
                                                {
                                                        LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                                                        break;
                                                }

                                                memcpy((char*)p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_4->data,
                                                                rrcContainer_buf,
                                                                rrcContainerLength);

                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }

                                        /* Compose DU to CU RRC Container */
                                case ASN1V_f1ap_id_DUtoCURRCContainer:
                                        {
                                                f1ap_DUtoCURRCContainer*     p_du_to_cu_rrc_info = NULL;
                                                _f1ap_DUtoCURRCContainer *   p_src_du_cu_contnr = NULL;

                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_5;

                                                p_src_du_cu_contnr = &src_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_5;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_5 =
                                                                rtxMemAllocType(&asn1_ctx,
                                                                                f1ap_DUtoCURRCContainer);

                                                if (NULL == p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_5)
                                                {
                                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                                        break;
                                                }
                                                asn1Init_f1ap_DUtoCURRCContainer(
                                                        p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_5);

                                                /* Store pointer in local variable for further processing */
                                                p_du_to_cu_rrc_info =
                                                        p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_5;

                                                p_du_to_cu_rrc_info->numocts = p_src_du_cu_contnr->numocts;

						 p_du_to_cu_rrc_info->data
                                                        = rtxMemAlloc(&asn1_ctx,
                                                                        p_du_to_cu_rrc_info->numocts);

                                                if (F1AP_NULL == p_du_to_cu_rrc_info->data)
                                                {
                                                        LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                                                        break;
                                                }

                                                memcpy((char*)p_du_to_cu_rrc_info->data,
                                                                p_src_du_cu_contnr->data,
                                                                p_src_du_cu_contnr->numocts);


                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }

                                        /* Compose SUL-Access-indication */
                                case ASN1V_f1ap_id_SULAccessIndication:
                                        {

                                                p_protocolIE_elem->value.t
                                                        = T84f1ap___f1ap_InitialULRRCMessageTransferIEs_6;

                                                p_protocolIE_elem->value.u._f1ap_InitialULRRCMessageTransferIEs_6
                                                        = src_protocolIE_elem->value.u.
                                                                _f1ap_InitialULRRCMessageTransferIEs_6.sul_access_indication;

                                                rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                                                break;
                                        }
                                default:
                                        {
                                                LOG_TRACE("Unknown ID received: %d\n", src_protocolIE_elem->id);
                                                break;
                                        }
                        }
                }

		/* ASN Encode message */
                pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                                F1AP_MAX_ASN1_BUF_LEN, TRUE);

                if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
                {
                        char buff[500];
                        rtxErrGetTextBuf(&asn1_ctx,buff ,500);
                        LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff);
                        LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
                        break;
                }
                else
                {
                        *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
                        retVal = SIM_SUCCESS;
                        asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
                }

        }while(0);

        /* Free ASN1 context */
        rtFreeContext(&asn1_ctx);

        return SIM_SUCCESS;
}

/* F1 INIT UL RRC MSG TRANSFER Code Changes stop */

		

