/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"
#include "du_sim_common.h"
/* This function encodes UE Context Release Command */
sim_return_val_et
dusim_handle_encode_ue_context_release_command(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
#if 0
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_NULL;
    f1ap_UEContextReleaseCommand*  
                           p_asn_msg               = F1AP_NULL;
    f1ap_UEContextReleaseCommand_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_NULL;
    _f1ap_UEContextReleaseCommand* 
                           src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_UEContextReleaseCommand*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_UEContextRelease;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to UE Context Release */ 
        f1ap_pdu.u.initiatingMessage->value.t = T1f1ap__uEContextRelease;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_UEContextReleaseCommand);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextReleaseCommand(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.uEContextRelease
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextReleaseCommand_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextReleaseCommand_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T39f1ap___f1ap_UEContextReleaseCommandIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextReleaseCommandIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextReleaseCommand_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextReleaseCommand_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T39f1ap___f1ap_UEContextReleaseCommandIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextReleaseCommandIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Cause */
        {
            f1ap_Cause*  p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextReleaseCommand_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextReleaseCommand_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id           = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality  = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T39f1ap___f1ap_UEContextReleaseCommandIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextReleaseCommandIEs_3
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                                   _f1ap_UEContextReleaseCommandIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                           _f1ap_UEContextReleaseCommandIEs_3;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
#endif
    return SIM_SUCCESS;
}


/* This function encodes UE Context Release Complete */
/*******************************************************************************
 * Function Name  : dusim_handle_encode_ue_context_release_complete
 * Description    : This function encodes UE Context release complete
 * Inputs         : f1ap_adpt_ue_context_rel_complete_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Rel Complete
 *                  char*           apiBuf
 *                  unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context release complete  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

	sim_return_val_et
dusim_handle_encode_ue_context_release_complete(
/* spr 24900 changes start*/
	unsigned char*      apiBuf,
/* spr 24900 changes end */    
		unsigned int    apiBufLen,
		unsigned char** p_p_encodedmsg,
		unsigned long*  p_encodedmsg_len)

{
	sim_return_val_et       	  retVal                          = SIM_FAILURE;
	OSCTXT                  	  asn1_ctx;
	f1ap_F1AP_PDU           	  f1ap_pdu;
	OSRTDListNode*          	  p_node                          = F1AP_P_NULL;
	f1ap_UEContextReleaseComplete*  
					  p_asn_msg                       = F1AP_P_NULL;
	f1ap_UEContextReleaseComplete_protocolIEs_element*  
					  p_protocolIE_elem               = F1AP_P_NULL;
	f1ap_adpt_ue_context_rel_complete_t*    
					  p_ue_context_rel_complete       = F1AP_P_NULL;

	/* Init ASN1 context */
	if (F1AP_NULL != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.",
				__FUNCTION__);

		return retVal;
	}
	/* Allocate memory for target buffer */
	*p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

	if (F1AP_NULL == *p_p_encodedmsg)
	{
		LOG_TRACE("Failed to allocate memory for message buffer \n");
		return SIM_FAILURE;
	}

	memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

	do
	{
		memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

		p_ue_context_rel_complete = (f1ap_adpt_ue_context_rel_complete_t * )apiBuf; 
		/* Fill the values in the ASN structures that shall be encoded by
		 ** ASN Encoder */

		/* Set Pdu type to successful outcome message */
		f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

		f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
				f1ap_SuccessfulOutcome);
		if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
		{
			LOG_TRACE("Failed to allocate memory for message buffer \n");
			break;
		}

		asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

		/* Fill procedure code */
		f1ap_pdu.u.successfulOutcome->procedureCode 
			= ASN1V_f1ap_id_UEContextRelease;

		/* Fill criticality of message type */
		f1ap_pdu.u.successfulOutcome->criticality = f1ap_reject;

		/* Set the successfuloutcome message type to UE Context 
		 * Release confirm */
		f1ap_pdu.u.successfulOutcome->value.t = T3f1ap__uEContextRelease;

		p_asn_msg = rtxMemAllocType(&asn1_ctx,
				f1ap_UEContextReleaseComplete);
		if (F1AP_NULL == p_asn_msg)
		{
			LOG_TRACE("Failed to allocate memory for message buffer \n");
			break;
		}

		asn1Init_f1ap_UEContextReleaseComplete(p_asn_msg);

		f1ap_pdu.u.successfulOutcome->value.u.uEContextRelease 
			= p_asn_msg;

		/* Compose gNB-CU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextReleaseComplete_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("Failed to allocate memory for message buffer \n");
				break;
			}

			asn1Init_f1ap_UEContextReleaseComplete_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;

			p_protocolIE_elem->criticality = f1ap_reject;

			p_protocolIE_elem->value.t     
				= T51f1ap___f1ap_UEContextReleaseCompleteIEs_1;

			p_protocolIE_elem->value.u._f1ap_UEContextReleaseCompleteIEs_1
				= p_ue_context_rel_complete->gNBCUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose gNB-DU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextReleaseComplete_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("Failed to allocate memory for message buffer \n");
				break;
			}

			asn1Init_f1ap_UEContextReleaseComplete_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;

			p_protocolIE_elem->criticality = f1ap_reject;

			p_protocolIE_elem->value.t     
				= T51f1ap___f1ap_UEContextReleaseCompleteIEs_2;

			p_protocolIE_elem->value.u._f1ap_UEContextReleaseCompleteIEs_2
				= p_ue_context_rel_complete->gNBDUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose Criticality-Diagnostics, If present in source container */
		if (p_ue_context_rel_complete->bitmask & 
				F1AP_ADPT_UE_CTX_REL_COMP_CRITICALITY_DIAGNOSTICS_PRESENT)
		{
			f1ap_CriticalityDiagnostics*   p_rel_trg_crit_diag  = F1AP_NULL;
			_f1ap_CriticalityDiagnostics*  p_rel_src_crit_diag  = F1AP_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextReleaseComplete_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextReleaseComplete_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id           
				= ASN1V_f1ap_id_CriticalityDiagnostics;
			p_protocolIE_elem->criticality  
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T51f1ap___f1ap_UEContextReleaseCompleteIEs_3;

			p_protocolIE_elem->value.u._f1ap_UEContextReleaseCompleteIEs_3
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_CriticalityDiagnostics);

			if (F1AP_NULL == p_protocolIE_elem->value.u.
					_f1ap_UEContextReleaseCompleteIEs_3)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}

			asn1Init_f1ap_CriticalityDiagnostics(
					p_protocolIE_elem->value.u.
					_f1ap_UEContextReleaseCompleteIEs_3);

			/* Store pointer in local variable for further processing */
			p_rel_trg_crit_diag = p_protocolIE_elem->value.u.
				_f1ap_UEContextReleaseCompleteIEs_3;

			/* Fetch pointer to source criticality diagnostics container */
			p_rel_src_crit_diag = &p_ue_context_rel_complete->criticality_diagnostics;

			if (p_rel_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
			{
				p_rel_trg_crit_diag->m.procedureCodePresent = 1;

				p_rel_trg_crit_diag->procedureCode 
					= p_rel_src_crit_diag->procedureCode; 
			}

			if (p_rel_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
			{
				p_rel_trg_crit_diag->m.triggeringMessagePresent = 1;

				p_rel_trg_crit_diag->triggeringMessage 
					= p_rel_src_crit_diag->triggeringMessage; 
			}

			if (p_rel_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
			{
				p_rel_trg_crit_diag->m.procedureCriticalityPresent = 1;

				p_rel_trg_crit_diag->procedureCriticality 
					= p_rel_src_crit_diag->procedureCriticality; 
			}

			if (p_rel_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
			{
				f1ap_CriticalityDiagnostics_IE_Item*  p_trg_item = F1AP_NULL;
				_f1ap_CriticalityDiagnostics_IE_Item* p_src_item = F1AP_NULL;
				OSRTDListNode*                        ieNode   = F1AP_NULL;
				unsigned int                          index    = 0;

				asn1Init_f1ap_CriticalityDiagnostics_IE_List(
						&p_rel_trg_crit_diag->iEsCriticalityDiagnostics);

				p_rel_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

				for (index = 0; (index < p_rel_src_crit_diag->iEsList.ie_count &&
							index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
						index++)
				{
					/* Fetch pointer to the source item */
					p_src_item = &p_rel_src_crit_diag->iEsList.ie_info[index];

					/* Allocate memory for target element */
					rtxDListAllocNodeAndData(&asn1_ctx,
							f1ap_CriticalityDiagnostics_IE_Item,
							&ieNode,
							&p_trg_item);

					if (F1AP_NULL == ieNode)
					{
						LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
						break;
					}

					/* Initialize target item */
					asn1Init_f1ap_CriticalityDiagnostics_IE_Item(p_trg_item);

					/* Populate item attributes */
					p_trg_item->iECriticality = p_src_item->iECriticality;
					p_trg_item->iE_ID         = p_src_item->iE_ID;
					p_trg_item->typeOfError   = p_src_item->typeOfError;

					/* Add element to the list */
					rtxDListAppendNode(&p_rel_trg_crit_diag->iEsCriticalityDiagnostics,
							ieNode);
				}
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}



		/* ASN Encode message */
		pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
				DU_F1AP_MAX_ASN1_BUF_LEN, TRUE);

		if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
		{
			char buff[500];
			rtxErrGetTextBuf(&asn1_ctx,buff ,500);
			LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
			LOG_TRACE("Failed to encode UE CONTEXT RELEASE  RESPONSE \n");

			break;
		}
		else
		{
			*p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
			retVal = SIM_SUCCESS;
			asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
		}

	}while(0);

	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);
	return retVal;
}


