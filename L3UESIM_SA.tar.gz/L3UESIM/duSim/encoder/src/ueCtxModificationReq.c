/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "f1ap_adpt_intf.h"
#include "du_sim_common.h"


/* Function Prototype of asn cause type and value */
void populate_asn_cause_type_and_value
(
   f1ap_adpt_cause_t*   p_src_adpt_cause,
   f1ap_Cause*          p_trg_asn_cause
);
/* Function Prototype of resource coordination container  */
sim_return_val_et
encode_res_coordination_info(
f1ap_adpt_sgnb_resrc_coordination_info_t*     src_container,
UInt8*                                        p_encoded_msg,
UInt32*                                       p_encodedmsg_len
);



sim_return_val_et
f1ap_encode_nr_cell_group_config
(
   OSCTXT               *p_asn1_ctx,
   cell_group_config_t* p_src_cell_group_config,
   UInt8*               p_encodedmsg,
   UInt32*              p_encodedmsg_len
);

/* This function encodes UE Context Modification Request */
sim_return_val_et
dusim_handle_encode_ue_context_modification_req(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)


    
{

#if 0
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_NULL;
    f1ap_UEContextModificationRequest*  
                           p_asn_msg               = F1AP_NULL;
    f1ap_UEContextModificationRequest_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_NULL;
    _f1ap_UEContextModificationRequest* 
                           src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_UEContextModificationRequest*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_UEContextModification;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_reject;

        /* Set the initiating message type to UE Context Modification */ 
        f1ap_pdu.u.initiatingMessage->value.t = T1f1ap__uEContextModification;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, 
                           f1ap_UEContextModificationRequest);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextModificationRequest(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.uEContextModification
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate PSCell ID */
        if (src_asn_msg->bitmask & UE_CTX_MOD_REQ_PSCELL_ID_PRESENT)
        {
            f1ap_NCGI*  p_ncgi = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_PSCell_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_3
                    = rtxMemAllocType(&asn1_ctx, f1ap_NCGI);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextModificationRequestIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_NCGI(p_protocolIE_elem->value.
                            u._f1ap_UEContextModificationRequestIEs_3);

            /* Store pointer in local variable for further processing */
            p_ncgi = p_protocolIE_elem->value.u.
                            _f1ap_UEContextModificationRequestIEs_3;

            asn1Init_f1ap_PLMN_Identity(&p_ncgi->pLMN_Identity);

            p_ncgi->pLMN_Identity.numocts 
                = src_asn_msg->pscell_ncgi.pLMN_Identity.numocts;

            memcpy(p_ncgi->pLMN_Identity.data,
                   src_asn_msg->pscell_ncgi.pLMN_Identity.data,
                   p_ncgi->pLMN_Identity.numocts);

            asn1Init_f1ap_NRCellIdentity(&p_ncgi->nRCellIdentity);

            p_ncgi->nRCellIdentity.numbits
                = src_asn_msg->pscell_ncgi.nRCellIdentity.numbits;

            memcpy(p_ncgi->nRCellIdentity.data,
                   src_asn_msg->pscell_ncgi.nRCellIdentity.data,
                   (p_ncgi->nRCellIdentity.numbits/8));

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DRX cycle */
        if (src_asn_msg->bitmask & UE_CTX_MOD_REQ_DRX_CONFIG_PRESENT)
        {
            f1ap_DRXCycle*  p_drx_config = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_DRXCycle;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_4;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_4
                    = rtxMemAllocType(&asn1_ctx, f1ap_DRXCycle);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextModificationRequestIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRXCycle(p_protocolIE_elem->value.
                            u._f1ap_UEContextModificationRequestIEs_4);

            /* Store pointer in local variable for further processing */
            p_drx_config = p_protocolIE_elem->value.u.
                                _f1ap_UEContextModificationRequestIEs_4;

            p_drx_config->longDRXCycleLength  
                  = src_asn_msg->drx_cycle.longDRXCycleLength;

            if (src_asn_msg->drx_cycle.bitmask &
                      F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_LEN_PRESENT)
            {
                p_drx_config->m.shortDRXCycleLengthPresent = 1;
                p_drx_config->shortDRXCycleLength 
                      = src_asn_msg->drx_cycle.shortDRXCycleLength;
            }

            if (src_asn_msg->drx_cycle.bitmask &
                      F1AP_DRX_CONFIG_SHORT_DRX_CYCLE_TIMER_PRESENT)
            {
                p_drx_config->m.shortDRXCycleTimerPresent  = 1;
                p_drx_config->shortDRXCycleTimer  
                      = src_asn_msg->drx_cycle.shortDRXCycleTimer;
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate CU to DU RRC Container */
        if (src_asn_msg->bitmask 
                & UE_CTX_MOD_REQ_CU_TO_DU_CONTAINER_PRESENT)
        {
            f1ap_CUtoDURRCInformation* p_cu_to_du_rrc_info = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CUtoDURRCInformation;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_5;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_5
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_CUtoDURRCInformation);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextModificationRequestIEs_5)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CUtoDURRCInformation(p_protocolIE_elem->value.
                        u._f1ap_UEContextModificationRequestIEs_5);

            /* Store pointer in local variable for further processing */
            p_cu_to_du_rrc_info = p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationRequestIEs_5;

            p_cu_to_du_rrc_info->uERadiocapabilities.numocts
                 = src_asn_msg->cuToDuContainer.ueCapabilityBufferLen; 

            p_cu_to_du_rrc_info->uERadiocapabilities.data 
                 = rtxMemAlloc(&asn1_ctx,
                         p_cu_to_du_rrc_info->uERadiocapabilities.numocts);
            
            if (F1AP_NULL == p_cu_to_du_rrc_info->uERadiocapabilities.data)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            memcpy((char*)p_cu_to_du_rrc_info->uERadiocapabilities.data,
                   src_asn_msg->cuToDuContainer.ueCapabilityBuffer,
                   src_asn_msg->cuToDuContainer.ueCapabilityBufferLen);

            if (src_asn_msg->bitmask & 
                    CU_TO_DU_CONTAINER_SCG_CONFIG_INFO_PRESENT)
            {
                p_cu_to_du_rrc_info->sCG_Config_Info.numocts
                     = src_asn_msg->cuToDuContainer.scgConfigInfoBufferLen; 

                p_cu_to_du_rrc_info->sCG_Config_Info.data 
                     = rtxMemAlloc(&asn1_ctx,
                             p_cu_to_du_rrc_info->sCG_Config_Info.numocts);
                
                if (F1AP_NULL == p_cu_to_du_rrc_info->sCG_Config_Info.data)
                {
                    LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                    break;
                }

                memcpy(&p_cu_to_du_rrc_info->sCG_Config_Info.data,
                       src_asn_msg->cuToDuContainer.scgConfigInfoBuffer,
                       src_asn_msg->cuToDuContainer.scgConfigInfoBufferLen);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose Transmission Stop Indicator */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransmissionStopIndicator;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_6;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_6
                    = src_asn_msg->transmissionStopIndicator;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Resource coordination transfer Container */
        {
            f1ap_ResourceCoordinationTransferContainer* 
                    p_res_coordination_transfer_container = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_ResourceCoordinationTransferContainer;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T40f1ap___f1ap_UEContextModificationRequestIEs_7;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequestIEs_7
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_ResourceCoordinationTransferContainer);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextModificationRequestIEs_7)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_ResourceCoordinationTransferContainer(
                          p_protocolIE_elem->value.
                            u._f1ap_UEContextModificationRequestIEs_7);

            /* Store pointer in local variable for further processing */
            p_res_coordination_transfer_container 
                = p_protocolIE_elem->value.u.
                            _f1ap_UEContextModificationRequestIEs_7;

            /* Store pointer in local variable for further processing */
            p_res_coordination_transfer_container 
                    = p_protocolIE_elem->value.u.
                                _f1ap_UEContextModificationRequestIEs_7;

            p_res_coordination_transfer_container->numocts
                 = src_asn_msg->resCoordinationTransferContainer.
                                     containerLength; 

            p_res_coordination_transfer_container->data 
                 = rtxMemAlloc(&asn1_ctx,
                         p_res_coordination_transfer_container->numocts);
            
            if (F1AP_NULL == p_res_coordination_transfer_container->data)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            memcpy((char*)p_res_coordination_transfer_container->data,
                   src_asn_msg->resCoordinationTransferContainer.containerData,
                   src_asn_msg->resCoordinationTransferContainer.
                           containerLength);

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }
#if 0
        /* Populate SRBs to setup list */
        if (src_asn_msg->srbsToBeSetupList.count)
        {
            _f1ap_SRBs_ToBeSetup_List*           p_src_srb_elem = F1AP_NULL;
            f1ap_SRBs_ToBeSetup_List_element*    p_trg_srb_elem = F1AP_NULL;
            OSRTDListNode*                       p_srb_node     = F1AP_NULL;
            unsigned short                       index          = 0;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_SRBs_ToBeSetup_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_8;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_8
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_SRBs_ToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_8)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_SRBs_ToBeSetup_List(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupRequestIEs_8);

            for (index = 0; 
                 index < src_asn_msg->srbsToBeSetupList.count; 
                 index++)
            {
                /* Get pointer to source SRB element in the list */
                p_src_srb_elem = &src_asn_msg->srbsToBeSetupList.
                                         srbToBeSetup[index];

                /* Allocate memory for target SRB element */
                rtxDListAllocNodeAndData(&asn1_ctx,
                        f1ap_SRBs_ToBeSetup_List_element,
                        &p_srb_node,
                        &p_trg_srb_elem);

                if (F1AP_NULL == p_srb_node)
                {
                    LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                    break;
                }

                p_trg_srb_elem->id          = ASN1V_f1ap_id_SRBID; 
                p_trg_srb_elem->criticality = f1ap_reject; 

                p_trg_srb_elem->value.t     
                    = T27f1ap___f1ap_SRBs_ToBeSetup_ItemIEs_1;

                p_trg_srb_elem->value.u._f1ap_SRBs_ToBeSetup_ItemIEs_1
                    = p_src_srb_elem->srb_id; 

                rtxDListAppendNode(p_protocolIE_elem->value.u.
                                         _f1ap_UEContextSetupRequestIEs_8,
                                   p_srb_node);
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate DRBs to setup list */
        if (src_asn_msg->drbsToBeSetupList.count)
        {
            _f1ap_DRBs_ToBeSetup_List*   p_src_drb_elem = F1AP_NULL;
            f1ap_DRBs_ToBeSetup_List*    p_trg_drb_elem = F1AP_NULL;
            OSRTDListNode*               p_drb_node     = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextSetupRequest_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextSetupRequest_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_DRBs_ToBeSetup_List;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T25f1ap___f1ap_UEContextSetupRequestIEs_9;

            p_protocolIE_elem->value.u._f1ap_UEContextSetupRequestIEs_9
                    = rtxMemAllocType(&asn1_ctx, 
                                f1ap_DRBs_ToBeSetup_List);

            if (F1AP_NULL == p_protocolIE_elem->value.
                             u._f1ap_UEContextSetupRequestIEs_9)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_DRBs_ToBeSetup_List(p_protocolIE_elem->value.
                        u._f1ap_UEContextSetupRequestIEs_9);

            for (index = 0; 
                 index < src_asn_msg->drbsToBeSetupList.count; 
                 index++)
            {
                /* Get pointer to source DRB element in the list */
                p_src_drb_elem = &src_asn_msg->drbsToBeSetupList.
                                         drb_to_setup_elem[index];

                /* TODO : Need to complete this once updated specs
                 * with updated grammar are available and header files
                 * are generated again. */
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }
#endif

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

#endif
    return SIM_SUCCESS;
}


/* This function encodes UE Context Modification Failure */
sim_return_val_et
dusim_handle_encode_ue_context_modification_failure(
        char*           apiBuf,
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)

{


    return SIM_SUCCESS;

}
#if 0
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = F1AP_NULL;
    f1ap_UEContextModificationFailure*  
                           p_asn_msg               = F1AP_NULL;
    f1ap_UEContextModificationFailure_protocolIEs_element*  
                           p_protocolIE_elem       = F1AP_NULL;
    _f1ap_UEContextModificationFailure* 
                           src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_UEContextModificationFailure*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set PDU type to UNsuccessful outcome */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_unsuccessfulOutcome;

        f1ap_pdu.u.unsuccessfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_UnsuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.unsuccessfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UnsuccessfulOutcome(
                         f1ap_pdu.u.unsuccessfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.unsuccessfulOutcome->procedureCode 
                      = ASN1V_f1ap_id_UEContextModification;

        /* Fill criticality of message type */
        f1ap_pdu.u.unsuccessfulOutcome->criticality = f1ap_reject;

        /* Set the unsuccessful message type to UE Context Modification */ 
        f1ap_pdu.u.unsuccessfulOutcome->value.t 
                      = T1f1ap__uEContextModification;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, 
                           f1ap_UEContextModificationFailure);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextModificationFailure(p_asn_msg);

        f1ap_pdu.u.unsuccessfulOutcome->value.u.uEContextModification
                       = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextModificationFailureIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextModificationFailureIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Populate Cause */
        {
            f1ap_Cause*  p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextModificationFailureIEs_3;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_3
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                               _f1ap_UEContextModificationFailureIEs_3)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                           _f1ap_UEContextModificationFailureIEs_3;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & 
                  UE_CTX_MOD_FAILURE_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationFailure_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationFailure_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T47f1ap___f1ap_UEContextModificationFailureIEs_4;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationFailureIEs_4
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                               _f1ap_UEContextModificationFailureIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(p_protocolIE_elem->value.u.
                       _f1ap_UEContextModificationFailureIEs_4);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_UEContextModificationFailureIEs_4;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_NULL;
                OSRTDListNode*                        ieNode   = F1AP_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    return SIM_SUCCESS;
}
#endif

/* This function encodes UE Context Modification Response */
/*******************************************************************************
 * Function Name  : populate_f1ap_drbs_setup_list
 * Description    : This function encodes UE Context Setup Failure
 * Inputs         : f1ap_adpt_ue_context_setup_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Response
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context response buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
populate_f1ap_drbs_modified_list
(
    f1ap_adpt_drbs_modified_list_element_t*    p_src_drb_elem, 
    f1ap_DRBs_Modified_List_element*           p_trg_drb_elem,
    OSCTXT*                                 p_asn1_ctx
)
{
    f1ap_adpt_dl_tunnels_to_be_modified_list_element_t*    
                                    p_src_dl_tunnel_elem = F1AP_NULL;
    f1ap_DLUPTNLInformation_ToBeSetup_Item*  p_dl_tunnel_elem     = F1AP_NULL;
    OSRTDListNode*                  p_tunnel_node        = F1AP_NULL;
    UInt16                          tunnel_index         = 0;

    
    asn1Init_f1ap_DRBs_Modified_List_element(p_trg_drb_elem);

    p_trg_drb_elem->id          = ASN1V_f1ap_id_DRBs_Modified_Item;
    p_trg_drb_elem->criticality = f1ap_ignore;

    p_trg_drb_elem->value.t = T62f1ap___f1ap_DRBs_Modified_ItemIEs_1;

    p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1 =
                rtxMemAllocType(p_asn1_ctx, 
                                f1ap_DRBs_Modified_Item);

    if (F1AP_NULL ==
            p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1)
                       
    {
  
        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }

    asn1Init_f1ap_DRBs_Modified_Item(
            p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1);

    p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1->dRBID =
        p_src_drb_elem->drb_id;
    
    p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1->lCID =
        p_src_drb_elem->lCID;

    asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_List(
            &p_trg_drb_elem->value.u._f1ap_DRBs_Modified_ItemIEs_1->
                      dLUPTNLInformation_ToBeSetup_List); 

    for (tunnel_index = 0; 
         tunnel_index < p_src_drb_elem->dl_tunnels_list.count; 
         tunnel_index++)
    {
        p_src_dl_tunnel_elem = 
            &p_src_drb_elem->dl_tunnels_list.dl_tunnel_to_setup[tunnel_index];

        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                f1ap_DLUPTNLInformation_ToBeSetup_Item,
                &p_tunnel_node,
                &p_dl_tunnel_elem);

        if (F1AP_NULL == p_tunnel_node)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            return SIM_FAILURE;
        }

        asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_Item(p_dl_tunnel_elem);

        asn1Init_f1ap_UPTransportLayerInformation(
                &p_dl_tunnel_elem->dLUPTNLInformation);

        p_dl_tunnel_elem->dLUPTNLInformation.t = p_src_dl_tunnel_elem->type;

        p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel = rtxMemAllocType(p_asn1_ctx,
                                            f1ap_GTPTunnel);

        if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }


        asn1Init_f1ap_GTPTunnel(p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel);


        if(p_dl_tunnel_elem->dLUPTNLInformation.t == 1)
        {
            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts =
                p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs;

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs);

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits = 
                p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length*8;

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data
                = rtxMemAlloc(p_asn1_ctx,
                        p_src_dl_tunnel_elem->u.gtp_tunnelep.
                        transport_address_length);

            if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->
                    transportLayerAddress.data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_layer_address,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length);

            rtxDListAppendNode(&p_trg_drb_elem->value.u.
                    _f1ap_DRBs_Modified_ItemIEs_1->dLUPTNLInformation_ToBeSetup_List,
                    p_tunnel_node);

        }
    }

    return SIM_SUCCESS;

}

/* F1 UE CTXT MODIFICATION RESP START */

/*******************************************************************************
 * Function Name  : populate_f1ap_drbs_setup_modified_list
 * Description    : This function encodes UE Context Setup Modification Response
 * Inputs         : f1ap_adpt_ue_context_mod_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Modification Response
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context response buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
populate_f1ap_drbs_setup_modified_list
(
    f1ap_adpt_drbs_setup_modified_list_element_t*    p_src_drb_setup_mod_elem, 
    f1ap_DRBs_SetupMod_List_element*          	     p_trg_drb_setup_mod_elem,
    OSCTXT*                                          p_asn1_ctx
)
{
    f1ap_adpt_dl_tunnels_to_be_setup_mod_list_element_t*    
                                    			   p_src_dl_tunnel_mod_elem = F1AP_NULL;
    f1ap_DLUPTNLInformation_ToBeSetup_Item*  		   p_dl_tunnel_mod_elem     = F1AP_NULL;
    OSRTDListNode*                  			   p_tunnel_mod_node        = F1AP_NULL;
    UInt16                          			   tunnel_mod_index         = 0;

    

    p_trg_drb_setup_mod_elem->id          = ASN1V_f1ap_id_DRBs_SetupMod_Item;
    p_trg_drb_setup_mod_elem->criticality = f1ap_ignore;

    p_trg_drb_setup_mod_elem->value.t = T61f1ap___f1ap_DRBs_SetupMod_ItemIEs_1;

    p_trg_drb_setup_mod_elem->value.u._f1ap_DRBs_SetupMod_ItemIEs_1 = rtxMemAllocType(p_asn1_ctx,f1ap_DRBs_SetupMod_Item);

    asn1Init_f1ap_DRBs_SetupMod_Item(
            p_trg_drb_setup_mod_elem->value.u._f1ap_DRBs_SetupMod_ItemIEs_1);

    p_trg_drb_setup_mod_elem->value.u._f1ap_DRBs_SetupMod_ItemIEs_1->dRBID =
        p_src_drb_setup_mod_elem->drb_id;
    
    p_trg_drb_setup_mod_elem->value.u._f1ap_DRBs_SetupMod_ItemIEs_1->lCID =
        p_src_drb_setup_mod_elem->lCID;

    asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_List(
            &p_trg_drb_setup_mod_elem->value.u._f1ap_DRBs_SetupMod_ItemIEs_1->
                      dLUPTNLInformation_ToBeSetup_List); 

    for (tunnel_mod_index = 0; 
         tunnel_mod_index < p_src_drb_setup_mod_elem->dl_tunnels_setup_mod_list.count; 
         tunnel_mod_index++)
    {
        p_src_dl_tunnel_mod_elem = 
            &p_src_drb_setup_mod_elem->dl_tunnels_setup_mod_list.dl_tunnel_to_setup_mod[tunnel_mod_index];

        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                f1ap_DLUPTNLInformation_ToBeSetup_Item,
                &p_tunnel_mod_node,
                &p_dl_tunnel_mod_elem);

        if (F1AP_NULL == p_tunnel_mod_node)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            return SIM_FAILURE;
        }

        asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_Item(p_dl_tunnel_mod_elem);

        asn1Init_f1ap_UPTransportLayerInformation(
                &p_dl_tunnel_mod_elem->dLUPTNLInformation);

        p_dl_tunnel_mod_elem->dLUPTNLInformation.t = p_src_dl_tunnel_mod_elem->type;

        p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel = rtxMemAllocType(p_asn1_ctx,
                                            f1ap_GTPTunnel);

        if (F1AP_NULL == p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }


        asn1Init_f1ap_GTPTunnel(p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel);


        if(p_dl_tunnel_mod_elem->dLUPTNLInformation.t == 1)
        {
            p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts =
                p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.gtp_teid.num_octs;

            memcpy((void*)p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                    p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.gtp_teid.data,
                    p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.gtp_teid.num_octs);

            p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits = 
                p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.transport_address_length*8;

            p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data
                = rtxMemAlloc(p_asn1_ctx,
                        p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.
                        transport_address_length);

            if (F1AP_NULL == p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->
                    transportLayerAddress.data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            memcpy((void*)p_dl_tunnel_mod_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                    p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.transport_layer_address,
                    p_src_dl_tunnel_mod_elem->u.gtp_tunnelep.transport_address_length);

            rtxDListAppendNode(&p_trg_drb_setup_mod_elem->value.u.
                    _f1ap_DRBs_SetupMod_ItemIEs_1->dLUPTNLInformation_ToBeSetup_List,
                    p_tunnel_mod_node);

        }
    }

    return SIM_SUCCESS;

}


/* F1 UE CTXT MODIFICATION RESP STOP */


/*******************************************************************************
 * Function Name  : dusim_handle_encode_ue_context_modification_response
 * Description    : This function encodes UE Context Modification response
 * Inputs         : f1ap_adpt_ue_context_mod_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Response
 *                   char*           apiBuf
 *                    unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context Modification Failure response
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

	sim_return_val_et
dusim_handle_encode_ue_context_modification_response(
/* spr 24900 changes start*/
		unsigned char*   apiBuf,
/* spr 24900 changes end */        
		unsigned int    apiBufLen,
		unsigned char** p_p_encodedmsg,
		unsigned long*  p_encodedmsg_len)
{
	unsigned int            index    				    = 0;
	sim_return_val_et       retVal                                  = SIM_FAILURE;
	OSCTXT                  asn1_ctx;
	f1ap_F1AP_PDU           f1ap_pdu;
	OSRTDListNode*          p_node                                  = F1AP_P_NULL;
	f1ap_UEContextModificationResponse*  
				p_asn_msg                               = F1AP_P_NULL;
	f1ap_UEContextModificationResponse_protocolIEs_element*  
				p_protocolIE_elem                       = F1AP_P_NULL;

	f1ap_adpt_ue_context_mod_resp_t*    p_ue_context_mod_resp       = F1AP_P_NULL;

	/* Init ASN1 context */
	if (F1AP_NULL != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.",
				__FUNCTION__);

		return retVal;
	}

	/* Allocate memory for target buffer */
	*p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

	if (F1AP_NULL == *p_p_encodedmsg)
	{
		LOG_TRACE("Failed to allocate memory for message buffer \n");
		return SIM_FAILURE;
	}

	memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

	do
	{
		memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

		/* Fill the values in the ASN structures that shall be encoded by
		 * ASN Encoder */

		p_ue_context_mod_resp = (f1ap_adpt_ue_context_mod_resp_t*)apiBuf;
		/* Set PDU type to successful outcome message */
		f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

		f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
				f1ap_SuccessfulOutcome);

		if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
		{
			LOG_TRACE("ASN malloc failed \n");
			break;
		}

		asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

		/* Fill procedure code */
		f1ap_pdu.u.successfulOutcome->procedureCode 
			= ASN1V_f1ap_id_UEContextModification;

		/* Fill criticality of message type */
		f1ap_pdu.u.successfulOutcome->criticality 
			= f1ap_reject;

		/* Set the successfuloutcome message type to UE Context 
		 * Modification Response */
		f1ap_pdu.u.successfulOutcome->value.t
			= T3f1ap__uEContextModification;

		p_asn_msg = rtxMemAllocType(&asn1_ctx,
				f1ap_UEContextModificationResponse);

		if (F1AP_NULL == p_asn_msg)
		{
			LOG_TRACE("ASN malloc failed \n");
			break;
		}

		asn1Init_f1ap_UEContextModificationResponse(p_asn_msg);

		f1ap_pdu.u.successfulOutcome->value.u.uEContextModification
			= p_asn_msg;

		/* Compose gNB-CU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("ASN malloc failed \n");
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;

			p_protocolIE_elem->criticality = f1ap_reject;

			p_protocolIE_elem->value.t     
				= T60f1ap___f1ap_UEContextModificationResponseIEs_1;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_1
				= p_ue_context_mod_resp->gNBCUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose gNB-DU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("ASN malloc failed \n");
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
			p_protocolIE_elem->criticality 
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T60f1ap___f1ap_UEContextModificationResponseIEs_2;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_2
				= p_ue_context_mod_resp->gNBDUUEF1APID;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose Resource-Coordination-Transfer-Container */

		if (p_ue_context_mod_resp->bitmask & 
				F1AP_ADPT_UE_CTX_MOD_RESP_MENB_RESOURCE_COORDINATION_INFO_PRESENT)
		{
			f1ap_ResourceCoordinationTransferContainer* 
				p_res_coord_trans_container 	      = F1AP_P_NULL;
			UInt8   container_buf[2048]                   = {0};
			UInt32  container_len                         = 2048;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= ASN1V_f1ap_id_ResourceCoordinationTransferContainer;
			p_protocolIE_elem->criticality 
				= f1ap_ignore;

			p_protocolIE_elem->value.t     
				= T60f1ap___f1ap_UEContextModificationResponseIEs_3;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_3
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_ResourceCoordinationTransferContainer);


			if (F1AP_NULL == p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_3)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_ResourceCoordinationTransferContainer(
					p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_3);

			/* Store pointer in local variable for further processing */
			p_res_coord_trans_container 
				= p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_3;

			/* Encode resource coordination container */
			if (SIM_SUCCESS != encode_res_coordination_info(
						&p_ue_context_mod_resp->sgnb_resrc_cord_info,
						container_buf,
						&container_len))
			{
				LOG_TRACE("%s:Failed to populate resource coordination info",__FUNCTION__);
				break;
			}

			p_res_coord_trans_container->numocts = container_len;

			p_res_coord_trans_container->data 
				= rtxMemAlloc(&asn1_ctx,
						p_res_coord_trans_container->numocts);

			if (F1AP_NULL == p_res_coord_trans_container->data)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			memcpy((char*)p_res_coord_trans_container->data,
					container_buf,
					container_len);

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

	
		/* Compose DRBs-Setup-Mod-List */
		if ((p_ue_context_mod_resp->bitmask &
					F1AP_ADPT_UE_CTX_MOD_RESP_DRB_SETUP_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->drbs_setup_modified_list.count))
		{
			f1ap_adpt_drbs_setup_modified_list_element_t*          p_src_drb_setup_mod_elem  =  F1AP_P_NULL;
			f1ap_DRBs_SetupMod_List_element*                       p_trg_drb_setup_mod_elem  =  F1AP_P_NULL;
			OSRTDListNode*                                         p_drb_setup_mod_node      =  F1AP_P_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;	
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_SetupMod_List;

			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t
				= T60f1ap___f1ap_UEContextModificationResponseIEs_5;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_5
				= rtxMemAllocType(&asn1_ctx,
						f1ap_DRBs_SetupMod_List);

			if (F1AP_NULL == p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_5)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_DRBs_SetupMod_List(p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_5);

			for (index = 0; index < p_ue_context_mod_resp->drbs_setup_modified_list.count;
					index++)
			{
				/* Get pointer to source DRB Setup Mod element in the list */	
				p_src_drb_setup_mod_elem = &p_ue_context_mod_resp->drbs_setup_modified_list.
					drb_to_setup_modified[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_DRBs_SetupMod_List_element,
						&p_drb_setup_mod_node,
						&p_trg_drb_setup_mod_elem);

				if (F1AP_NULL == p_drb_setup_mod_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_DRBs_SetupMod_List_element(p_trg_drb_setup_mod_elem);

				if (SIM_FAILURE == populate_f1ap_drbs_setup_modified_list(
							p_src_drb_setup_mod_elem,
							p_trg_drb_setup_mod_elem,
							&asn1_ctx))
				{
					LOG_TRACE("%s:Failed to populate F1AP DRBs setup list\n",__FUNCTION__);
					break;
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_5,
						p_drb_setup_mod_node);

			}	

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);	


		}
	
		/* Compose DRBs setup list */
		if ((p_ue_context_mod_resp->bitmask & 
					F1AP_ADPT_UE_CTX_MOD_RESP_DRB_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->drbs_modified_list.count))
		{
			f1ap_adpt_drbs_modified_list_element_t*     p_src_drb_elem   = F1AP_P_NULL;
			f1ap_DRBs_Modified_List_element*            p_trg_drb_elem   = F1AP_P_NULL;
			OSRTDListNode*                        	    p_drb_node       = F1AP_P_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_Modified_List;

			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t     
				= T60f1ap___f1ap_UEContextModificationResponseIEs_6;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_6
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_DRBs_Modified_List);

			if (F1AP_NULL == p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_6)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_DRBs_Modified_List(p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_6);

			for (index = 0; 
					index < p_ue_context_mod_resp->drbs_modified_list.count; 
					index++)
			{
				/* Get pointer to source DRB element in the list */
				p_src_drb_elem = &p_ue_context_mod_resp->drbs_modified_list.
					drb_to_modified[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_DRBs_Modified_List_element,
						&p_drb_node,
						&p_trg_drb_elem);

				if (F1AP_NULL == p_drb_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				if (SIM_FAILURE == populate_f1ap_drbs_modified_list(
							p_src_drb_elem,
							p_trg_drb_elem,
							&asn1_ctx))
				{
					LOG_TRACE("%s:Failed to populate F1AP DRBs setup list",__FUNCTION__);
					break;
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_6,
						p_drb_node);
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Populate DU to CU RRC Container */
		{
			UInt32                     cell_group_config_buf_len = 0;
			UInt8*                     p_cell_group_config_buf   = F1AP_P_NULL;
			f1ap_DUtoCURRCInformation* p_du_to_cu_rrc_info       = F1AP_P_NULL;

			p_cell_group_config_buf = (UInt8*)malloc(CELL_GROUP_CONFIG_BUF_LEN);

			if (F1AP_NULL == p_cell_group_config_buf)
			{
				LOG_TRACE("%s:Unable to allocate memory for cell group config buffer",__FUNCTION__);
				break;
			}

			memset(p_cell_group_config_buf, 0, CELL_GROUP_CONFIG_BUF_LEN);

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

				free(p_cell_group_config_buf);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id          
				= ASN1V_f1ap_id_DUtoCURRCInformation;
			p_protocolIE_elem->criticality 
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T60f1ap___f1ap_UEContextModificationResponseIEs_4;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_4
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_DUtoCURRCInformation);

			if (F1AP_NULL == p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_4)
			{


				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				/* Free the allocated memory to the cell group config buffer */
				free(p_cell_group_config_buf);
				p_cell_group_config_buf = F1AP_NULL;

				break;
			}

			asn1Init_f1ap_DUtoCURRCInformation(p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_4);

			/* Store pointer in local variable for further processing */
			p_du_to_cu_rrc_info = p_protocolIE_elem->value.u.
				_f1ap_UEContextModificationResponseIEs_4;

			if (SIM_SUCCESS != f1ap_encode_nr_cell_group_config(
						&asn1_ctx,
						&p_ue_context_mod_resp->du_to_cu_container,
						p_cell_group_config_buf,
						&cell_group_config_buf_len))
			{
				/* Free the allocated memory to the cell group config buffer */
				free(p_cell_group_config_buf);
				p_cell_group_config_buf = F1AP_NULL;

				break;
			}

			p_du_to_cu_rrc_info->cellGroupConfig.numocts 
				=  cell_group_config_buf_len; 

			p_du_to_cu_rrc_info->cellGroupConfig.data 
				= rtxMemAlloc(&asn1_ctx,
						p_du_to_cu_rrc_info->cellGroupConfig.numocts);

			if (F1AP_NULL == p_du_to_cu_rrc_info->cellGroupConfig.data)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

				free(p_cell_group_config_buf);
				break;
			}

			memcpy((char*)p_du_to_cu_rrc_info->cellGroupConfig.data,
					p_cell_group_config_buf,cell_group_config_buf_len);

			/* Free the allocated memory to the cell group config buffer */
			if (F1AP_NULL != p_cell_group_config_buf)
			{
				free(p_cell_group_config_buf);
				p_cell_group_config_buf = F1AP_NULL;
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose SRBs-Failed-Setup-Mod-List */
		if ((p_ue_context_mod_resp->bitmask &
					F1AP_ADPT_UE_CTX_MOD_RESP_SRB_FAILED_SETUP_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->srbs_failed_to_setup_mod_list.count))
		{
			f1ap_adpt_srbs_failed_to_be_setup_mod_list_element_t*
				p_src_srb_elem = F1AP_P_NULL;

			f1ap_SRBs_FailedToBeSetupMod_List_element*                p_trg_srb_elem = F1AP_P_NULL;
			f1ap_SRBs_FailedToBeSetupMod_Item*                        p_trg_srb_item = F1AP_P_NULL;
			OSRTDListNode*					          p_srb_node     = F1AP_P_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;	
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_SRBs_FailedToBeSetupMod_List;

			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t
				= T42f1ap___f1ap_UEContextSetupResponseIEs_7;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_7
				= rtxMemAllocType(&asn1_ctx,
						f1ap_SRBs_FailedToBeSetupMod_List);

			if (F1AP_NULL ==  p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_7)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}
			asn1Init_f1ap_SRBs_FailedToBeSetupMod_List(
					p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_7);

			for (index = 0; index <p_ue_context_mod_resp->srbs_failed_to_setup_mod_list.count;
					index++)
			{
				/* Get pointer to source DRB element in the list */
				p_src_srb_elem = &p_ue_context_mod_resp->srbs_failed_to_setup_mod_list.srb_failed_to_setup_mod[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_SRBs_FailedToBeSetupMod_List_element,
						&p_srb_node,
						&p_trg_srb_elem);

				if (F1AP_NULL == p_srb_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}	

				p_trg_srb_elem->id = ASN1V_f1ap_id_SRBs_FailedToBeSetupMod_Item;

				p_trg_srb_elem->criticality = f1ap_ignore;

				p_trg_srb_elem->value.t
					= T63f1ap___f1ap_SRBs_FailedToBeSetupMod_ItemIEs_1;  			

				p_trg_srb_elem->value.u._f1ap_SRBs_FailedToBeSetupMod_ItemIEs_1
					= rtxMemAllocType(&asn1_ctx,
							f1ap_SRBs_FailedToBeSetupMod_Item);

				if (F1AP_NULL == p_trg_srb_elem->value.u._f1ap_SRBs_FailedToBeSetupMod_ItemIEs_1)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_SRBs_FailedToBeSetupMod_Item(
						p_trg_srb_elem->value.u._f1ap_SRBs_FailedToBeSetupMod_ItemIEs_1);

				p_trg_srb_item = p_trg_srb_elem->value.u._f1ap_SRBs_FailedToBeSetupMod_ItemIEs_1;

				p_trg_srb_item->sRBID = p_src_srb_elem->srb_id;

				/* Fill cause for failed srbs */
				if (F1AP_ADPT_UE_CTX_MOD_RESP_SRB_FAILED_TO_SETUP_MOD_CAUSE_PRESENT &
						p_src_srb_elem->bitmask)
				{
					p_trg_srb_item->m.causePresent = 1;

					populate_asn_cause_type_and_value(
							&p_src_srb_elem->cause,
							&p_trg_srb_item->cause);
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_7,
						p_srb_node);
			}	

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);	
		}


		/* Compose DRBs-Failed-Setup-Mod-List */
		if ((p_ue_context_mod_resp->bitmask &
					F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_SETUP_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->drbs_failed_to_setup_mod_list.count))
		{
			f1ap_adpt_drbs_failed_to_be_setup_mod_list_element_t*
				p_src_drb_setup_elem = F1AP_P_NULL;

			f1ap_DRBs_FailedToBeSetupMod_List_element*      	p_trg_drb_setup_elem = F1AP_P_NULL;
			f1ap_DRBs_FailedToBeSetupMod_Item*              	p_trg_drb_setup_item = F1AP_P_NULL;
			OSRTDListNode*						p_drb_setup_node     = F1AP_P_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;	
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeSetupMod_List;

			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t
				= T42f1ap___f1ap_UEContextSetupResponseIEs_8;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_8
				= rtxMemAllocType(&asn1_ctx,
						f1ap_DRBs_FailedToBeSetupMod_List);

			if (F1AP_NULL ==  p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_8)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}
			asn1Init_f1ap_DRBs_FailedToBeSetupMod_List(
					p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_8);

			for (index = 0; index < p_ue_context_mod_resp->drbs_failed_to_setup_mod_list.count;
					index++)
			{
				/* Get pointer to source DRB element in the list */
				p_src_drb_setup_elem  = &p_ue_context_mod_resp->drbs_failed_to_setup_mod_list.drb_failed_to_setup_mod[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_DRBs_FailedToBeSetupMod_List_element,
						&p_drb_setup_node,
						&p_trg_drb_setup_elem);

				if (F1AP_NULL == p_drb_setup_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_DRBs_FailedToBeSetupMod_List_element(p_trg_drb_setup_elem);		

				p_trg_drb_setup_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeSetupMod_Item;
				p_trg_drb_setup_elem->criticality = f1ap_ignore;

				p_trg_drb_setup_elem->value.t
					= T64f1ap___f1ap_DRBs_FailedToBeSetupMod_ItemIEs_1;  			

				p_trg_drb_setup_elem->value.u._f1ap_DRBs_FailedToBeSetupMod_ItemIEs_1
					= rtxMemAllocType(&asn1_ctx,
							f1ap_DRBs_FailedToBeSetupMod_Item);

				if (F1AP_NULL == p_trg_drb_setup_elem->value.u._f1ap_DRBs_FailedToBeSetupMod_ItemIEs_1)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_DRBs_FailedToBeSetupMod_Item(
						p_trg_drb_setup_elem->value.u._f1ap_DRBs_FailedToBeSetupMod_ItemIEs_1);

				p_trg_drb_setup_item = p_trg_drb_setup_elem->value.u._f1ap_DRBs_FailedToBeSetupMod_ItemIEs_1;

				p_trg_drb_setup_item->dRBID = p_src_drb_setup_elem->drb_id;

				/* Fill cause for failed drbs */
				if (F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_TO_SETUP_MOD_CAUSE_PRESENT &
						p_src_drb_setup_elem->bitmask)
				{
					p_trg_drb_setup_item->m.causePresent = 1;

					populate_asn_cause_type_and_value(
							&p_src_drb_setup_elem->cause,
							&p_trg_drb_setup_item->cause);
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_8,
						p_drb_setup_node);
			}	

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);	
		}

		/* Compose SCell-Failed-Setup-Mod-List */

		if ((p_ue_context_mod_resp->bitmask &
					F1AP_ADPT_UE_CTX_MOD_RESP_SCELL_FAILED_SETUP_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->scell_failed_to_setup_mod_list.count))
		{
			f1ap_adpt_scell_failed_to_be_setup_mod_list_element_t*
										  p_src_scell_setup_elem = F1AP_P_NULL;

			f1ap_SCell_FailedtoSetupMod_List_element* 		  p_trg_scell_setup_elem = F1AP_P_NULL;
			f1ap_SCell_FailedtoSetupMod_Item *			  p_trg_scell_setup_item = F1AP_P_NULL;
			OSRTDListNode*						  p_scell_setup_node	 = F1AP_P_NULL;								

			// Allocate memory for target protocolIE element 
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id = ASN1V_f1ap_id_SCell_FailedtoSetupMod_List; 	

			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t
				= T60f1ap___f1ap_UEContextModificationResponseIEs_9;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_9 
					= rtxMemAllocType(&asn1_ctx,
							  f1ap_SCell_FailedtoSetupMod_List);

			asn1Init_f1ap_SCell_FailedtoSetupMod_List(
					p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_9);

			for (index = 0; index < p_ue_context_mod_resp->scell_failed_to_setup_mod_list.count;
					index++)
			{
				/* Get pointer to source sCELL element in the list */
				p_src_scell_setup_elem = &p_ue_context_mod_resp->scell_failed_to_setup_mod_list.scell_failed_to_setup_mod[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_SCell_FailedtoSetupMod_List_element,
						&p_scell_setup_node, 		
						&p_trg_scell_setup_elem);

				if (F1AP_NULL == p_scell_setup_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_SCell_FailedtoSetupMod_List_element(p_trg_scell_setup_elem);

				p_trg_scell_setup_elem->id = ASN1V_f1ap_id_SCell_FailedtoSetupMod_Item;
				p_trg_scell_setup_elem->criticality = f1ap_ignore;

				p_trg_scell_setup_elem->value.t
					= T66f1ap___f1ap_SCell_FailedtoSetupMod_ItemIEs_1;

				p_trg_scell_setup_elem->value.u._f1ap_SCell_FailedtoSetupMod_ItemIEs_1
					= rtxMemAllocType(&asn1_ctx,
							f1ap_SCell_FailedtoSetupMod_Item);

				if (F1AP_NULL == p_trg_scell_setup_elem->value.u._f1ap_SCell_FailedtoSetupMod_ItemIEs_1)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}   

				asn1Init_f1ap_SCell_FailedtoSetupMod_Item(p_trg_scell_setup_elem->
						value.u._f1ap_SCell_FailedtoSetupMod_ItemIEs_1);

				p_trg_scell_setup_item = p_trg_scell_setup_elem->value.u._f1ap_SCell_FailedtoSetupMod_ItemIEs_1;


				/*Fill PLMN */
				p_trg_scell_setup_item->sCell_ID.pLMN_Identity.numocts = 0x03;
				memcpy(&p_trg_scell_setup_item->sCell_ID.pLMN_Identity.data,
						p_src_scell_setup_elem->scell_id.plmn_identity.data,
						p_trg_scell_setup_item->sCell_ID.pLMN_Identity.numocts);

				/* Nr-CellIdentity */
				p_trg_scell_setup_item->sCell_ID.nRCellIdentity.numbits = 0x24;

				memcpy(&p_trg_scell_setup_item->sCell_ID.nRCellIdentity.data,
						p_src_scell_setup_elem->scell_id.nr_cellidentity.data,
						p_trg_scell_setup_item->sCell_ID.nRCellIdentity.numbits);

				/* Fill cause for failed srbs */
				if (F1AP_ADPT_UE_CTX_MOD_RESP_SCELL_FAILED_TO_SETUP_MOD_CAUSE_PRESENT &
						p_src_scell_setup_elem->bitmask)
				{
					p_trg_scell_setup_item->m.causePresent = 1;

					populate_asn_cause_type_and_value(
							&p_src_scell_setup_elem->cause,
							&p_trg_scell_setup_item->cause);
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_9,
						p_scell_setup_node);
			}
			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);

		}

		/* Compose DRBs-Failed-Modified-List */
		if ((p_ue_context_mod_resp->bitmask &
					F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_MODIFIED_PRESENT) &&
				(p_ue_context_mod_resp->drbs_failed_to_mod_list.count))
		{
			f1ap_adpt_drbs_failed_to_be_mod_list_element_t*
									p_src_drb_fail_elem = F1AP_P_NULL;

			f1ap_DRBs_FailedToBeModified_List_element*      p_trg_drb_fail_elem = F1AP_P_NULL;
			f1ap_DRBs_FailedToBeModified_Item*              p_trg_drb_fail_item = F1AP_P_NULL;
			OSRTDListNode*					p_drb_fail_node     = F1AP_P_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;	
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);
			p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeModified_List;
			p_protocolIE_elem->criticality = f1ap_ignore;

			p_protocolIE_elem->value.t
				= T42f1ap___f1ap_UEContextSetupResponseIEs_10;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_10
				= rtxMemAllocType(&asn1_ctx,
						f1ap_DRBs_FailedToBeModified_List);

			if (F1AP_NULL ==  p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_10)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}
			asn1Init_f1ap_DRBs_FailedToBeModified_List(
					p_protocolIE_elem->value.
					u._f1ap_UEContextModificationResponseIEs_10);

			for (index = 0; index <p_ue_context_mod_resp->drbs_failed_to_mod_list.count;
					index++)
			{
				/* Get pointer to source DRB element in the list */
				p_src_drb_fail_elem = &p_ue_context_mod_resp->drbs_failed_to_mod_list.drb_failed_to_mod[index];

				rtxDListAllocNodeAndData(
						&asn1_ctx,
						f1ap_DRBs_FailedToBeModified_List_element,
						&p_drb_fail_node,
						&p_trg_drb_fail_elem);

				if (F1AP_NULL == p_drb_fail_node)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_DRBs_FailedToBeModified_List_element(p_trg_drb_fail_elem);

				p_trg_drb_fail_elem->id = ASN1V_f1ap_id_DRBs_FailedToBeModified_Item;
				p_trg_drb_fail_elem->criticality = f1ap_ignore;

				p_trg_drb_fail_elem->value.t
					= T65f1ap___f1ap_DRBs_FailedToBeModified_ItemIEs_1;  			

				p_trg_drb_fail_elem->value.u._f1ap_DRBs_FailedToBeModified_ItemIEs_1
					= rtxMemAllocType(&asn1_ctx,
							f1ap_DRBs_FailedToBeModified_Item);

				if (F1AP_NULL == p_trg_drb_fail_elem->value.u._f1ap_DRBs_FailedToBeModified_ItemIEs_1)
				{
					LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
					break;
				}

				asn1Init_f1ap_DRBs_FailedToBeModified_Item(p_trg_drb_fail_elem->value.u._f1ap_DRBs_FailedToBeModified_ItemIEs_1);

				p_trg_drb_fail_item = p_trg_drb_fail_elem->value.u._f1ap_DRBs_FailedToBeModified_ItemIEs_1;

				p_trg_drb_fail_item->dRBID = p_src_drb_fail_elem->drb_id;

				/* Fill cause for failed drbs */
				if (F1AP_ADPT_UE_CTX_MOD_RESP_DRB_FAILED_TO_MOD_CAUSE_PRESENT &
						p_src_drb_fail_elem->bitmask)
				{
					p_trg_drb_fail_item->m.causePresent = 1;

					populate_asn_cause_type_and_value(
							&p_src_drb_fail_elem->cause,
							&p_trg_drb_fail_item->cause);
				}

				rtxDListAppendNode(p_protocolIE_elem->value.
						u._f1ap_UEContextModificationResponseIEs_10,
						p_drb_fail_node);
			}	

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);	
		}

		/* Compose Inactivity-Monitoring-Response */
		if (p_ue_context_mod_resp->bitmask & 
				F1AP_ADPT_UE_CTX_MOD_RESP_INACTIVE_MONITOR_RESPONSE_PRESENT)
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);
	
			p_protocolIE_elem->id = ASN1V_f1ap_id_InactivityMonitoringResponse;

			p_protocolIE_elem->criticality = f1ap_reject;

			p_protocolIE_elem->value.t = T60f1ap___f1ap_UEContextModificationResponseIEs_11; 	 

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_11
				= f1ap_not_supported;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node); 
		}

		/* Compose Criticality-Diagnostics, If present in source container */
		if (p_ue_context_mod_resp->bitmask & 
				F1AP_ADPT_UE_CTX_MOD_RESP_CRITICALITY_DIAGNOSTICS_PRESENT)
		{
			f1ap_CriticalityDiagnostics*  trg_crit_diag = F1AP_NULL;
			_f1ap_CriticalityDiagnostics* src_crit_diag = F1AP_NULL;

			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);

			p_protocolIE_elem->id           
				= ASN1V_f1ap_id_CriticalityDiagnostics;
			p_protocolIE_elem->criticality  
				= f1ap_reject;

			p_protocolIE_elem->value.t     
				= T42f1ap___f1ap_UEContextSetupResponseIEs_12;

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_12
				= rtxMemAllocType(&asn1_ctx, 
						f1ap_CriticalityDiagnostics);

			if (F1AP_NULL == p_protocolIE_elem->value.u.
					_f1ap_UEContextModificationResponseIEs_12)
			{
				LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
				break;
			}

			asn1Init_f1ap_CriticalityDiagnostics(
					p_protocolIE_elem->value.u.
					_f1ap_UEContextModificationResponseIEs_12);

			/* Store pointer in local variable for further processing */
			trg_crit_diag = p_protocolIE_elem->value.u.
				_f1ap_UEContextModificationResponseIEs_12;

			/* Fetch pointer to source criticality diagnostics container */
			src_crit_diag = &p_ue_context_mod_resp->criticality_diagnostics;

			if (src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
			{
				trg_crit_diag->m.procedureCodePresent = 1;

				trg_crit_diag->procedureCode 
					= src_crit_diag->procedureCode; 
			}

			if (src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
			{
				trg_crit_diag->m.triggeringMessagePresent = 1;

				trg_crit_diag->triggeringMessage 
					= src_crit_diag->triggeringMessage; 
			}

			if (src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
			{
				trg_crit_diag->m.procedureCriticalityPresent = 1;

				trg_crit_diag->procedureCriticality 
					= src_crit_diag->procedureCriticality; 
			}

			if (src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
			{
				f1ap_CriticalityDiagnostics_IE_Item*  p_trg_item = F1AP_NULL;
				_f1ap_CriticalityDiagnostics_IE_Item* p_src_item = F1AP_NULL;
				OSRTDListNode*                        ieNode   = F1AP_NULL;
				unsigned int                          index    = 0;

				asn1Init_f1ap_CriticalityDiagnostics_IE_List(
						&trg_crit_diag->iEsCriticalityDiagnostics);

				trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

				for (index = 0; (index < src_crit_diag->iEsList.ie_count &&
							index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
						index++)
				{
					/* Fetch pointer to the source item */
					p_src_item = &src_crit_diag->iEsList.ie_info[index];

					/* Allocate memory for target element */
					rtxDListAllocNodeAndData(&asn1_ctx,
							f1ap_CriticalityDiagnostics_IE_Item,
							&ieNode,
							&p_trg_item);

					if (F1AP_NULL == ieNode)
					{
						LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
						break;
					}

					/* Initialize target item */
					asn1Init_f1ap_CriticalityDiagnostics_IE_Item(p_trg_item);

					/* Populate item attributes */
					p_trg_item->iECriticality = p_src_item->iECriticality;
					p_trg_item->iE_ID         = p_src_item->iE_ID;
					p_trg_item->typeOfError   = p_src_item->typeOfError;

					/* Add element to the list */
					rtxDListAppendNode(&trg_crit_diag->iEsCriticalityDiagnostics,
							ieNode);
				}
			}

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}

		/* Compose c-RNTI */
		if (p_ue_context_mod_resp->bitmask & 
				F1AP_ADPT_UE_CTX_MOD_RESP_C_RNTI_PRESENT)
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextModificationResponse_protocolIEs_element,
					&p_node,
					&p_protocolIE_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
				break;
			}

			asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
					p_protocolIE_elem);
	
			p_protocolIE_elem->id = ASN1V_f1ap_id_C_RNTI;

			p_protocolIE_elem->criticality = f1ap_reject;

			p_protocolIE_elem->value.t = T60f1ap___f1ap_UEContextModificationResponseIEs_13; 	 

			p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_13
				= p_ue_context_mod_resp->c_rnti;

			rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node); 
		}


		/* ASN Encode message */
		pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
				DU_F1AP_MAX_ASN1_BUF_LEN, TRUE);

		if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
		{
			char buff[500];
			rtxErrGetTextBuf(&asn1_ctx,buff ,500);

			break;
		}
		else
		{
			*p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
			retVal = SIM_SUCCESS;
			asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
		}

	}while(0);

	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);
	return retVal;
}

sim_return_val_et dusim_handle_encode_ue_context_release_request(
/* spr 24900 changes start */
	unsigned char*      apiBuf,
/* spr 24900 changes end */        
		unsigned int    apiBufLen,
		unsigned char** p_p_encodedmsg,
		unsigned long*  p_encodedmsg_len
)
{
//	unsigned int            index    				= 0;
	sim_return_val_et       retVal                                  = SIM_FAILURE;
	OSCTXT                  asn1_ctx;
	f1ap_F1AP_PDU           f1ap_pdu;
	OSRTDListNode*          p_node                                  = F1AP_P_NULL;
	
	/*ASN Structure */
	f1ap_UEContextReleaseRequest
				*p_trgt_msg 				= F1AP_P_NULL;

	f1ap_UEContextReleaseRequest_protocolIEs_element
				*p_protocolIEs_elem			= F1AP_P_NULL;

	/*Local/ flat sturcture*/
	f1ap_adpt_ue_context_rel_req_t
				*p_src_msg				= F1AP_P_NULL;

	/*Init asn ctc */			
	if (F1AP_NULL != rtInitContext(&asn1_ctx))
	{
		LOG_TRACE("%s:ASN context initialization failed.",
				__FUNCTION__);

		return retVal;
	}

	/* Allocate memory to the asn */
	*p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);
	
	if (F1AP_NULL == *p_p_encodedmsg)
	{
		LOG_TRACE("Failed to allocate memory for message buffer \n");
		return SIM_FAILURE;
	}

	memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

	do{
		memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));
		/* Fill the values in the ASN structures that shall be encoded by
                 * ASN Encoder */

		/*type cast msg pointer ro local st*/
		p_src_msg = (f1ap_adpt_ue_context_rel_req_t*)apiBuf;
		
		/*Fill PDU*/
		f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

		f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
						f1ap_InitiatingMessage);
		
		if (F1AP_NULL == f1ap_pdu.u.initiatingMessage)
		{
			LOG_TRACE("ASN malloc failed \n");
			break;
		}

		asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);	
		
		/*Fill proc*/
		f1ap_pdu.u.initiatingMessage->procedureCode =
						ASN1V_f1ap_id_UEContextReleaseRequest;
		/*fill cric*/
		f1ap_pdu.u.initiatingMessage->criticality =
						f1ap_reject;	
		
		/* Set the initiatingMessage message type to UE Context 
		 * Release Request */
		f1ap_pdu.u.initiatingMessage->value.t
			= T3f1ap__uEContextRelease;
		p_trgt_msg = rtxMemAllocType(&asn1_ctx,
					f1ap_UEContextReleaseRequest);
		
		if (F1AP_NULL == p_trgt_msg)
		{
			LOG_TRACE("ASN malloc failed \n");
			break;
		}
		asn1Init_f1ap_UEContextReleaseRequest(p_trgt_msg);
		f1ap_pdu.u.initiatingMessage->value.u.uEContextReleaseRequest
						= p_trgt_msg;
		/*Compose gNB-CU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
					f1ap_UEContextReleaseRequest_protocolIEs_element,
					&p_node,
					&p_protocolIEs_elem);
			
			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("ASN malloc failed \n");
				break;
			}
			asn1Init_f1ap_UEContextReleaseRequest_protocolIEs_element(
						p_protocolIEs_elem);
			p_protocolIEs_elem->id = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
			
			p_protocolIEs_elem->criticality = f1ap_reject;
			
			p_protocolIEs_elem->value.t
					= T49f1ap___f1ap_UEContextReleaseRequestIEs_1;
			p_protocolIEs_elem->value.u._f1ap_UEContextReleaseRequestIEs_1
					=  p_src_msg->gNBCUUEF1APID;
			rtxDListAppendNode(&p_trgt_msg->protocolIEs, p_node); 
						
		}
		
		/* Compose gNB-DU UE F1AP ID */
		{
			/* Allocate memory for target protocolIE element */
			rtxDListAllocNodeAndData(&asn1_ctx,
				f1ap_UEContextReleaseRequest_protocolIEs_element,
					&p_node,
					&p_protocolIEs_elem);

			if (F1AP_NULL == p_node)
			{
				LOG_TRACE("ASN malloc failed \n");
				break;
			}

			asn1Init_f1ap_UEContextReleaseRequest_protocolIEs_element(
					p_protocolIEs_elem);

			p_protocolIEs_elem->id          
				= ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
			p_protocolIEs_elem->criticality 
				= f1ap_reject;

			p_protocolIEs_elem->value.t     
				= T49f1ap___f1ap_UEContextReleaseRequestIEs_2;

			p_protocolIEs_elem->value.u._f1ap_UEContextReleaseRequestIEs_2
				= p_src_msg->gNBDUUEF1APID;

			rtxDListAppendNode(&p_trgt_msg->protocolIEs, p_node);
		}
		
		
        	/* Populate Cause */
       		 {
            		f1ap_Cause *p_cause = F1AP_NULL;

            		/* Allocate memory for target protocolIE element */
            		rtxDListAllocNodeAndData(&asn1_ctx,
                    		f1ap_UEContextReleaseRequest_protocolIEs_element,
                    		&p_node,
                    		&p_protocolIEs_elem);

           		 if (F1AP_NULL == p_node)
            		 {
                		LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                		break;
           		 }

           		 asn1Init_f1ap_UEContextReleaseRequest_protocolIEs_element(
                      				p_protocolIEs_elem);

            		p_protocolIEs_elem->id          
                    		= ASN1V_f1ap_id_Cause;
            		p_protocolIEs_elem->criticality 
                    		= f1ap_ignore;

            		p_protocolIEs_elem->value.t     
                    		= T49f1ap___f1ap_UEContextReleaseRequestIEs_3;

            		p_protocolIEs_elem->value.u._f1ap_UEContextReleaseRequestIEs_3
                    		= rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            		if (F1AP_NULL == p_protocolIEs_elem->value.u.
                               _f1ap_UEContextReleaseRequestIEs_3)
            		{
                		LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                		break;
           	 	}

            		/* Store pointer in local variable for further processing */
            		p_cause = p_protocolIEs_elem->value.u.
                          	 _f1ap_UEContextReleaseRequestIEs_3;

            		/* Populate cause from the source container */
            		p_cause->t = p_src_msg->cause.cause_type;

            		switch(p_src_msg->cause.cause_type)
            		{
                		case F1_CAUSE_RADIO_NETWORK: 
                		{
                    			p_cause->u.radioNetwork = p_src_msg->cause.u.radio_network; 
                    			break;
                		}

               			case F1_CAUSE_TRANSPORT:  
                		{
                    			p_cause->u.transport 
                                		 = p_src_msg->cause.u.transport;
                    			break;
                		}

                		case F1_CAUSE_PROTOCOL:
                		{
                    			p_cause->u.protocol 
                                		 = p_src_msg->cause.u.protocol;
                    			break;
                		}

                		case F1_CAUSE_MISC:
                		{
                    			p_cause->u.misc 
                                		= p_src_msg->cause.u.misc;
                    			break;
                		}

                		default:
                		{
                    			LOG_TRACE("Invalid cause type received \n");
                    			break;
                		}
            		}
			rtxDListAppendNode(&p_trgt_msg->protocolIEs, p_node);
		}	

		/* ASN Encode message */
       		 pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        	if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        	{
            		char buff[500];
            		rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            		LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff);
            		LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            		break;
        	}
        	else
        	{
            		*p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            		retVal = SIM_SUCCESS;
            		asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        	}

	}while(0);
	/* Free ASN1 context */
	rtFreeContext(&asn1_ctx);
	return SIM_SUCCESS;
}
#if 0
{
    sim_return_val_et       retVal                  = SIM_FAILURE;
    OSCTXT                  asn1_ctx;
    f1ap_F1AP_PDU           f1ap_pdu;
    OSRTDListNode*          p_node                  = F1AP_NULL;
    f1ap_UEContextModificationResponse*  
                            p_asn_msg               = F1AP_NULL;
    f1ap_UEContextModificationResponse_protocolIEs_element*  
                            p_protocolIE_elem       = F1AP_NULL;
    _f1ap_UEContextModificationResponse* 
                            src_asn_msg             = F1AP_NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (F1AP_NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_UEContextModificationResponse*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set PDU type to successful outcome message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_successfulOutcome;

        f1ap_pdu.u.successfulOutcome = rtxMemAllocType(&asn1_ctx,
                                            f1ap_SuccessfulOutcome);
        if (F1AP_NULL == f1ap_pdu.u.successfulOutcome)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_SuccessfulOutcome(f1ap_pdu.u.successfulOutcome);

        /* Fill procedure code */
        f1ap_pdu.u.successfulOutcome->procedureCode 
                        = ASN1V_f1ap_id_UEContextModification;

        /* Fill criticality of message type */
        f1ap_pdu.u.successfulOutcome->criticality 
                    = f1ap_reject;

        /* Set the successfuloutcome message type to UE Context 
         * Modification Response */
        f1ap_pdu.u.successfulOutcome->value.t 
                    = T1f1ap__uEContextModification;

        p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                    f1ap_UEContextModificationResponse);
        if (F1AP_NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_UEContextModificationResponse(p_asn_msg);

        f1ap_pdu.u.successfulOutcome->value.u.uEContextModification
                        = p_asn_msg;

        /* Compose gNB-CU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T60f1ap___f1ap_UEContextModificationResponseIEs_1;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_1
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose gNB-DU UE F1AP ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T44f1ap___f1ap_UEContextModificationResponseIEs_2;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_2
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (src_asn_msg->bitmask & UE_CTX_MOD_RESP_CRIT_DIAG_PRESENT)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = F1AP_NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationResponse_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationResponse_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T44f1ap___f1ap_UEContextModificationResponseIEs_10;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationResponseIEs_10
                    = rtxMemAllocType(&asn1_ctx, 
                                      f1ap_CriticalityDiagnostics);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                                    _f1ap_UEContextModificationResponseIEs_10)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(p_protocolIE_elem->value.u.
                             _f1ap_UEContextModificationResponseIEs_10);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                  _f1ap_UEContextModificationResponseIEs_10;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = F1AP_NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = F1AP_NULL;
                OSRTDListNode*                        ieNode   = F1AP_NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (F1AP_NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %x\n",(char*)buff,(unsigned int)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    return SIM_SUCCESS;
}

#endif

/* This function encodes UE Context Modification Required */
/*******************************************************************************
 * Function Name  : populate_f1ap_drbs_to_be_modified_list
 * Description    : This function encodes UE Context Setup Failure
 * Inputs         : f1ap_adpt_ue_context_setup_resp_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Required
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context response buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

sim_return_val_et
populate_f1ap_drbs_required_to_be_modified_list
(
    f1ap_adpt_drbs_required_modified_list_element_t*    p_src_drb_elem,
    f1ap_DRBs_Required_ToBeModified_List_element*       p_trg_drb_elem,
    OSCTXT*                                 p_asn1_ctx
)
{
        f1ap_adpt_dl_tunnels_to_be_required_mod_list_element_t*
                p_src_dl_tunnel_elem = F1AP_NULL;
        f1ap_DLUPTNLInformation_ToBeSetup_Item*  p_dl_tunnel_elem     = F1AP_NULL;
        OSRTDListNode*                  p_tunnel_node        = F1AP_NULL;
        UInt16                          tunnel_index         = 0;


    asn1Init_f1ap_DRBs_Required_ToBeModified_List_element(p_trg_drb_elem);

    p_trg_drb_elem->id          = ASN1V_f1ap_id_DRBs_Required_ToBeModified_Item;
    p_trg_drb_elem->criticality = f1ap_ignore;

    p_trg_drb_elem->value.t = T69f1ap___f1ap_DRBs_Required_ToBeModified_ItemIEs_1;

    p_trg_drb_elem->value.u._f1ap_DRBs_Required_ToBeModified_ItemIEs_1 =
                rtxMemAllocType(p_asn1_ctx,
                                f1ap_DRBs_Required_ToBeModified_Item);
   if (F1AP_NULL ==
            p_trg_drb_elem->value.u._f1ap_DRBs_Required_ToBeModified_ItemIEs_1)

    {

        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
        return SIM_FAILURE;
    }

    asn1Init_f1ap_DRBs_Required_ToBeModified_Item(
            p_trg_drb_elem->value.u._f1ap_DRBs_Required_ToBeModified_ItemIEs_1);


    p_trg_drb_elem->value.u._f1ap_DRBs_Required_ToBeModified_ItemIEs_1->dRBID =
        p_src_drb_elem->drb_id;


    asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_List(
            &p_trg_drb_elem->value.u._f1ap_DRBs_Required_ToBeModified_ItemIEs_1->
                      dLUPTNLInformation_ToBeSetup_List);

    for (tunnel_index = 0;
         tunnel_index < p_src_drb_elem->dl_tunnels_required_mod_list.count;
         tunnel_index++)
    {
        p_src_dl_tunnel_elem = &p_src_drb_elem->dl_tunnels_required_mod_list.dl_tunnel_to_required_mod[tunnel_index];

        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                f1ap_DLUPTNLInformation_ToBeSetup_Item,
                &p_tunnel_node,
                &p_dl_tunnel_elem);

        if (F1AP_NULL == p_tunnel_node)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            return SIM_FAILURE;
        }

        asn1Init_f1ap_DLUPTNLInformation_ToBeSetup_Item(p_dl_tunnel_elem);

        asn1Init_f1ap_UPTransportLayerInformation(
                &p_dl_tunnel_elem->dLUPTNLInformation);

        p_dl_tunnel_elem->dLUPTNLInformation.t = p_src_dl_tunnel_elem->type;

	p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel = rtxMemAllocType(p_asn1_ctx,
                                            f1ap_GTPTunnel);

        if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }


        asn1Init_f1ap_GTPTunnel(p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel);


        if(p_dl_tunnel_elem->dLUPTNLInformation.t == 1)
        {
            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.numocts =
                p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs;

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->gTP_TEID.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.gtp_teid.num_octs);

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.numbits =
                p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length*8;

            p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data
                = rtxMemAlloc(p_asn1_ctx,
                        p_src_dl_tunnel_elem->u.gtp_tunnelep.
                        transport_address_length);

            if (F1AP_NULL == p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->
                    transportLayerAddress.data)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                return SIM_FAILURE;
            }

            memcpy((void*)p_dl_tunnel_elem->dLUPTNLInformation.u.gTPTunnel->transportLayerAddress.data,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_layer_address,
                    p_src_dl_tunnel_elem->u.gtp_tunnelep.transport_address_length);

            rtxDListAppendNode(&p_trg_drb_elem->value.u.
                    _f1ap_DRBs_Required_ToBeModified_ItemIEs_1->dLUPTNLInformation_ToBeSetup_List,
                    p_tunnel_node);

	     }
    }

    return SIM_SUCCESS;

}


/* F1 UE CTXT MODIFICATION REQUIRED Code Changes start */

/*******************************************************************************
 * Function Name  : dusim_handle_encode_ue_context_modification_required
 * Description    : This function encodes UE Context Modification required
 * Inputs         : f1ap_adpt_ue_context_mod_required_t* :
 *                  src_asn_msg : Pointer to F1AP UE Context Mod Response
 *                   char*           apiBuf
 *                    unsigned int    apiBufLen
 *                  UInt8* : p_encoded_msg   : Pointer to receive ASN encoded.
 *                  UInt32*: p_encodedmsg_len: Pointer to receive ASN buffer
 *                  length
 * Outputs        : ASN Encoded UE context Modification Failure response
 *                  buffer and length
 * Returns        : SIM_SUCCESS/SIM_FAILURE
 ******************************************************************************/

 sim_return_val_et 
dusim_handle_encode_ue_context_modification_required(
/* spr 24900 changes start */
               unsigned char*   apiBuf,
/* spr 24900 changes end */               
                unsigned int    apiBufLen,
                unsigned char** p_p_encodedmsg,
                unsigned long*  p_encodedmsg_len)
{


        unsigned int            index                                       = 0;

        sim_return_val_et       retVal                                  = SIM_FAILURE;
        OSCTXT                  asn1_ctx;
        f1ap_F1AP_PDU           f1ap_pdu;
        OSRTDListNode*          p_node                                  = F1AP_P_NULL;

        f1ap_UEContextModificationRequired*
                                p_asn_msg                               = F1AP_P_NULL;
        f1ap_UEContextModificationRequired_protocolIEs_element*
                                p_protocolIE_elem                       = F1AP_P_NULL;

        f1ap_adpt_ue_context_mod_required_t*    p_ue_context_mod_required       = F1AP_P_NULL;

	/* Init ASN1 context */
        if (F1AP_NULL != rtInitContext(&asn1_ctx))
        {
                LOG_TRACE("%s:ASN context initialization failed.",
                                __FUNCTION__);
                return retVal;
        }

        /* Allocate memory for target buffer */
        *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

        if (NULL == *p_p_encodedmsg)
        {
                LOG_TRACE("Failed to allocate memory for message buffer \n");
                return SIM_FAILURE;
        }

        memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

        do
        {
                memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));


               /* Fill the values in the ASN structures that shall be encoded by 
                     *	ASN Encoder */

                p_ue_context_mod_required = (f1ap_adpt_ue_context_mod_required_t*)apiBuf;

                /* Set Pdu type to Initiating message */
                f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

                f1ap_pdu.u.initiatingMessage = rtxMemAllocType(
                                        &asn1_ctx,
                                        f1ap_InitiatingMessage);

                if (NULL == f1ap_pdu.u.initiatingMessage)
                {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                }

                asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

		/* Fill procedure code */
                f1ap_pdu.u.initiatingMessage->procedureCode
                        = ASN1V_f1ap_id_UEContextModificationRequired;

                /* Fill criticality of message type */
                f1ap_pdu.u.initiatingMessage->criticality
                        = f1ap_reject;

                /* Set the initiating message type to UE Context
                 * Modification Required */
                f1ap_pdu.u.initiatingMessage->value.t
                        = T3f1ap__uEContextModificationRequired;

                p_asn_msg = rtxMemAllocType(&asn1_ctx,
                                f1ap_UEContextModificationRequired);

		if (F1AP_NULL == p_asn_msg)
		{
			LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
			break;
		}	
	
		asn1Init_f1ap_UEContextModificationRequired(p_asn_msg);

		f1ap_pdu.u.initiatingMessage->value.u.uEContextModificationRequired 
			= p_asn_msg;
	
		/* Compose gNB-CU UE F1AP ID */
                {
                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

			if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("ASN malloc failed \n");
                                break;
                        }
			
			asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;

                        p_protocolIE_elem->criticality = f1ap_reject;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_1;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_1
                                = p_ue_context_mod_required->gNBCUUEF1APID;

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
		}	

		/* Compose gNB-DU UE F1AP ID */
                {
                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);
			if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("ASN malloc failed \n");
                                break;
                        }

			asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id
                                = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
                        p_protocolIE_elem->criticality
                                = f1ap_reject;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_2;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_2
                                = p_ue_context_mod_required->gNBDUUEF1APID;

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }

		/* Compose Resource-Coordination-Transfer-Container */

                if (p_ue_context_mod_required->bitmask &
                                F1AP_ADPT_UE_CTX_MOD_REQUIRED_RESOURCE_COORDINATION_INFO_PRESENT)
                {

                        f1ap_ResourceCoordinationTransferContainer*
                                                res_coord_trans_container = F1AP_NULL;

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

                        asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id
                                = ASN1V_f1ap_id_ResourceCoordinationTransferContainer;
                        p_protocolIE_elem->criticality
                                = f1ap_ignore;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_3;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_3
                                = rtxMemAllocType(&asn1_ctx,
                                                f1ap_ResourceCoordinationTransferContainer);

                        if (F1AP_NULL == p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_3)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

			asn1Init_f1ap_ResourceCoordinationTransferContainer(
                                        p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_3);

                        /* Store pointer in local variable for further processing */
                        res_coord_trans_container = p_protocolIE_elem->value.u.
                                _f1ap_UEContextModificationRequiredIEs_3;

                        res_coord_trans_container->numocts
                                = p_ue_context_mod_required->resrc_cord_container.
                                numocts;

                        res_coord_trans_container->data
                                = rtxMemAlloc(&asn1_ctx,
                                                res_coord_trans_container->numocts);

                        if (F1AP_NULL == res_coord_trans_container->data)
                        {
                                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                                break;
                        }

                        memcpy((char*)res_coord_trans_container->data,
                                        p_ue_context_mod_required->resrc_cord_container.data,
                                        p_ue_context_mod_required->resrc_cord_container.numocts);

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }

		/* Populate DU to CU RRC Container */

                {
                        UInt32                     p_mod_required_buf_len = 0;
                        UInt8*                     p_mod_required_config_buf   = F1AP_P_NULL;
                        f1ap_DUtoCURRCInformation* p_du_to_cu_rrc_info       = F1AP_P_NULL;

                        p_mod_required_config_buf = (UInt8*)malloc(CELL_GROUP_CONFIG_BUF_LEN);

                        if (F1AP_NULL == p_mod_required_config_buf)
                        {
                                LOG_TRACE("%s:Unable to allocate memory for cell group config buffer",__FUNCTION__);
                                break;
                        }

                        memset(p_mod_required_config_buf, 0, CELL_GROUP_CONFIG_BUF_LEN);

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

                                free(p_mod_required_config_buf);
                                break;
                        }

                        asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id
                                = ASN1V_f1ap_id_DUtoCURRCInformation;
                        p_protocolIE_elem->criticality
                                = f1ap_reject;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_4;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_4
                                = rtxMemAllocType(&asn1_ctx,
                                                f1ap_DUtoCURRCInformation);

			if (F1AP_NULL == p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_4)
                        {


                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                /* Free the allocated memory to the cell group config buffer */
                                free(p_mod_required_config_buf);
                                p_mod_required_config_buf = F1AP_NULL;
                                break;
                        }

                        asn1Init_f1ap_DUtoCURRCInformation(p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_4);

                        /* Store pointer in local variable for further processing */
                        p_du_to_cu_rrc_info = p_protocolIE_elem->value.u.
                                _f1ap_UEContextModificationRequiredIEs_4;

                        if (SIM_SUCCESS != f1ap_encode_nr_cell_group_config(
                                                &asn1_ctx,
                                                &p_ue_context_mod_required->du_to_cu_container,
                                                p_mod_required_config_buf,
                                                &p_mod_required_buf_len))
                        {
                                /* Free the allocated memory to the cell group config buffer */
                                free(p_mod_required_config_buf);
                                p_mod_required_config_buf = F1AP_NULL;

                                break;
                        }

                        p_du_to_cu_rrc_info->cellGroupConfig.numocts
                                =  p_mod_required_buf_len;

                        p_du_to_cu_rrc_info->cellGroupConfig.data
                                = rtxMemAlloc(&asn1_ctx,
                                                p_du_to_cu_rrc_info->cellGroupConfig.numocts);

			if (F1AP_NULL == p_du_to_cu_rrc_info->cellGroupConfig.data)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);

                                free(p_mod_required_config_buf);
                                break;
                        }

                        memcpy((char*)p_du_to_cu_rrc_info->cellGroupConfig.data,
                                        p_mod_required_config_buf,p_mod_required_buf_len);

                        /* Free the allocated memory to the cell group config buffer */
                        if (F1AP_NULL != p_mod_required_config_buf)
                        {
                                free(p_mod_required_config_buf);
                                p_mod_required_config_buf = F1AP_NULL;
                        }

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }

		/* Compose DRBs-Required-To-Be-Modified-List */
                if ((p_ue_context_mod_required->bitmask &
                                        F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_MODIFIED_PRESENT) &&
                                (p_ue_context_mod_required->drbs_required_mod_list.count))
                {
                        f1ap_adpt_drbs_required_modified_list_element_t*     p_src_drb_elem   = F1AP_P_NULL;
                        f1ap_DRBs_Required_ToBeModified_List_element*            p_trg_drb_elem   = F1AP_P_NULL;
                        OSRTDListNode*                              p_drb_node       = F1AP_P_NULL;

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

                        asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_ToBeModified_List;

                        p_protocolIE_elem->criticality = f1ap_ignore;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_5;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_5
                                = rtxMemAllocType(&asn1_ctx,
                                                f1ap_DRBs_ToBeModified_List);

                        if (F1AP_NULL == p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_5)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

                        asn1Init_f1ap_DRBs_Required_ToBeModified_List(p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_5);

			for (index = 0;
                                        index < p_ue_context_mod_required->drbs_required_mod_list.count;
                                        index++)
                        {

                                /* Get pointer to source DRB element in the list */
                                p_src_drb_elem = &p_ue_context_mod_required->drbs_required_mod_list.drb_to_required_modified[index];

                                rtxDListAllocNodeAndData(
                                                &asn1_ctx,
                                                f1ap_DRBs_Required_ToBeModified_List_element,
                                                &p_drb_node,
                                                &p_trg_drb_elem);

                                if (F1AP_NULL == p_drb_node)
                                {
                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                        break;
                                }

                                if (SIM_FAILURE == populate_f1ap_drbs_required_to_be_modified_list(
                                                        p_src_drb_elem,
                                                        p_trg_drb_elem,
                                                        &asn1_ctx))
                                {
                                        LOG_TRACE("%s:Failed to populate F1AP DRBs setup list",__FUNCTION__);
                                        break;
                                }

                                rtxDListAppendNode(p_protocolIE_elem->value.
                                                u._f1ap_UEContextModificationRequiredIEs_5,
                                                p_drb_node);
                        }

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }
		
		/* Compose SRBs-Required-ToBeReleased-List */
                if ((p_ue_context_mod_required->bitmask &
                                        F1AP_ADPT_UE_CTX_MOD_REQUIRED_SRB_REQUIRED_RELEASE_PRESENT) &&
                                (p_ue_context_mod_required->srbs_required_to_release_list.count))
                {
                        f1ap_adpt_srbs_required_release_list_element_t*
                                p_src_srb_elem = F1AP_P_NULL;

                        f1ap_SRBs_Required_ToBeReleased_List_element*                p_trg_srb_elem = F1AP_P_NULL;
                        f1ap_SRBs_Required_ToBeReleased_Item*                        p_trg_srb_item = F1AP_P_NULL;
                        OSRTDListNode*                                            p_srb_node     = F1AP_P_NULL;
                       // OSRTDListNode*                                          p_drb_setup_node     = F1AP_P_NULL;

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

                        asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id = ASN1V_f1ap_id_SRBs_Required_ToBeReleased_List;

                        p_protocolIE_elem->criticality = f1ap_ignore;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_6;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_6
                                = rtxMemAllocType(&asn1_ctx,
                                                f1ap_SRBs_Required_ToBeReleased_List);

                        if (F1AP_NULL ==  p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_6)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }
                        asn1Init_f1ap_SRBs_Required_ToBeReleased_List(
					p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_6);

                        for (index = 0; index <p_ue_context_mod_required->srbs_required_to_release_list.count;
                                        index++)
                        {
                                /* Get pointer to source SRB element in the list */
                                p_src_srb_elem = &p_ue_context_mod_required->srbs_required_to_release_list.srb_required_to_release[index];

                                rtxDListAllocNodeAndData(
                                                &asn1_ctx,
                                                f1ap_SRBs_Required_ToBeReleased_List_element,
                                                &p_srb_node,
                                                &p_trg_srb_elem);

                                if (F1AP_NULL == p_srb_node)
                                {
                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                        break;
                                }

                                p_trg_srb_elem->id = ASN1V_f1ap_id_SRBs_Required_ToBeReleased_Item;

                                p_trg_srb_elem->criticality = f1ap_ignore;

                                p_trg_srb_elem->value.t
                                        = T71f1ap___f1ap_SRBs_Required_ToBeReleased_ItemIEs_1;

                                p_trg_srb_elem->value.u._f1ap_SRBs_Required_ToBeReleased_ItemIEs_1
                                        = rtxMemAllocType(&asn1_ctx,
                                                        f1ap_SRBs_Required_ToBeReleased_Item);

                                if (F1AP_NULL == p_trg_srb_elem->value.u._f1ap_SRBs_Required_ToBeReleased_ItemIEs_1)
                                {
                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                        break;
                                }

                                asn1Init_f1ap_SRBs_Required_ToBeReleased_Item(
                                                p_trg_srb_elem->value.u._f1ap_SRBs_Required_ToBeReleased_ItemIEs_1);

                                p_trg_srb_item = p_trg_srb_elem->value.u._f1ap_SRBs_Required_ToBeReleased_ItemIEs_1;

                                p_trg_srb_item->sRBID = p_src_srb_elem->srb_id;

				 rtxDListAppendNode(p_protocolIE_elem->value.
                                                u._f1ap_UEContextModificationRequiredIEs_6,
                                                p_srb_node);
                        }

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }

		/* Compose  DRBs-Required-ToBeReleased-List */
                if ((p_ue_context_mod_required->bitmask &
                                        F1AP_ADPT_UE_CTX_MOD_REQUIRED_DRB_REQUIRED_RELEASE_PRESENT) &&
                                (p_ue_context_mod_required->drbs_required_to_release_list.count))
                {
                        f1ap_adpt_drbs_required_release_list_element_t*
                                                                                p_src_drb_setup_elem = F1AP_P_NULL;

                        f1ap_DRBs_Required_ToBeReleased_List_element*           p_trg_drb_setup_elem = F1AP_P_NULL;
                        f1ap_DRBs_Required_ToBeReleased_Item*                   p_trg_drb_setup_item = F1AP_P_NULL;
                        OSRTDListNode*                                          p_drb_setup_node     = F1AP_P_NULL;

                        /* Allocate memory for target protocolIE element */
                        rtxDListAllocNodeAndData(&asn1_ctx,
                                        f1ap_UEContextModificationRequired_protocolIEs_element,
                                        &p_node,
                                        &p_protocolIE_elem);

                        if (F1AP_NULL == p_node)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }

                        asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                                        p_protocolIE_elem);

                        p_protocolIE_elem->id = ASN1V_f1ap_id_DRBs_Required_ToBeReleased_List;

                        p_protocolIE_elem->criticality = f1ap_ignore;

                        p_protocolIE_elem->value.t
                                = T68f1ap___f1ap_UEContextModificationRequiredIEs_7;

                        p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_7
                                = rtxMemAllocType(&asn1_ctx,
                                                f1ap_DRBs_Required_ToBeReleased_List);

                        if (F1AP_NULL ==  p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_7)
                        {
                                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                break;
                        }
			asn1Init_f1ap_DRBs_Required_ToBeReleased_List(
                                        p_protocolIE_elem->value.
                                        u._f1ap_UEContextModificationRequiredIEs_7);

                        for (index = 0; index < p_ue_context_mod_required->drbs_required_to_release_list.count;
                                        index++)
                        {
                                /* Get pointer to source DRB element in the list */
                                p_src_drb_setup_elem  = &(p_ue_context_mod_required->drbs_required_to_release_list.drb_required_to_release[index]);

                                rtxDListAllocNodeAndData(
                                                &asn1_ctx,
                                                f1ap_DRBs_Required_ToBeReleased_List_element,
                                                &p_drb_setup_node,
                                                &p_trg_drb_setup_elem);

                                if (F1AP_NULL == p_drb_setup_node)
                                {
                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                        break;
                                }

                                asn1Init_f1ap_DRBs_Required_ToBeReleased_List_element(p_trg_drb_setup_elem);

                                p_trg_drb_setup_elem->id = ASN1V_f1ap_id_DRBs_Required_ToBeReleased_Item;
                                p_trg_drb_setup_elem->criticality = f1ap_ignore;

                                p_trg_drb_setup_elem->value.t
                                        = T70f1ap___f1ap_DRBs_Required_ToBeReleased_ItemIEs_1;

                                p_trg_drb_setup_elem->value.u._f1ap_DRBs_Required_ToBeReleased_ItemIEs_1
                                        = rtxMemAllocType(&asn1_ctx,
                                                        f1ap_DRBs_Required_ToBeReleased_Item);

                                if (F1AP_NULL == p_trg_drb_setup_elem->value.u._f1ap_DRBs_Required_ToBeReleased_ItemIEs_1)
                                {
                                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                                        break;
                                }

                                asn1Init_f1ap_DRBs_Required_ToBeReleased_Item(
                                                p_trg_drb_setup_elem->value.u._f1ap_DRBs_Required_ToBeReleased_ItemIEs_1);

                                p_trg_drb_setup_item = p_trg_drb_setup_elem->value.u._f1ap_DRBs_Required_ToBeReleased_ItemIEs_1;

                                p_trg_drb_setup_item->dRBID = p_src_drb_setup_elem->drb_id;

				 rtxDListAppendNode(p_protocolIE_elem->value.
                                                u._f1ap_UEContextModificationRequiredIEs_7,
                                                p_drb_setup_node);
                        }

                        rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
                }

		 /* Populate Cause */
        {
            f1ap_Cause*  p_cause = F1AP_NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_UEContextModificationRequired_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (F1AP_NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_UEContextModificationRequired_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id
                    = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality
                    = f1ap_ignore;

            p_protocolIE_elem->value.t
                    = T68f1ap___f1ap_UEContextModificationRequiredIEs_8;

            p_protocolIE_elem->value.u._f1ap_UEContextModificationRequiredIEs_8
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (F1AP_NULL == p_protocolIE_elem->value.u.
                               _f1ap_UEContextModificationRequiredIEs_8)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u.
                           _f1ap_UEContextModificationRequiredIEs_8;

            /* Populate cause from the source container */
            p_cause->t = p_ue_context_mod_required->cause.cause_type;

	    switch(p_ue_context_mod_required->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK:
                {
                    p_cause->u.radioNetwork
                                 = p_ue_context_mod_required->cause.u.radio_network;
                    break;
                }

                case F1_CAUSE_TRANSPORT:
                {
                    p_cause->u.transport
                                 = p_ue_context_mod_required->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol
                                 = p_ue_context_mod_required->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc
                                = p_ue_context_mod_required->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }
	/* ASN Encode message */
                pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                                DU_F1AP_MAX_ASN1_BUF_LEN, TRUE);

                if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
                {
                        char buff[500];
                        rtxErrGetTextBuf(&asn1_ctx,buff ,500);

                        break;
                }
                else
                {
                        *p_encodedmsg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
                        retVal = SIM_SUCCESS;
                        asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
                }



        }while(0);

	/* Free ASN1 context */
        rtFreeContext(&asn1_ctx);
        return retVal;
}
	
/* F1 UE CTXT MODIFICATION REQUIRED Code Changes stop */


