
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project includes */
#include "lteTypes.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"


/* This function encodes Error Indication */
sim_return_val_et
dusim_handle_encode_error_indication(
/* spr 24900 changes start*/
        unsigned char*  apiBuf,
/* spr 24900 changes end */        
        unsigned int    apiBufLen,
        unsigned char** p_p_encodedmsg,
        unsigned long*  p_encodedmsg_len)
{
    sim_return_val_et      retVal                  = SIM_FAILURE;
    OSCTXT                 asn1_ctx;
    f1ap_F1AP_PDU          f1ap_pdu;
    OSRTDListNode*         p_node                  = NULL;
    f1ap_ErrorIndication*  p_asn_msg               = NULL;
    f1ap_ErrorIndication_protocolIEs_element*  
                           p_protocolIE_elem       = NULL;
    _f1ap_ErrorIndication* src_asn_msg             = NULL;
    
    /* Init ASN1 context */
    if (0 != rtInitContext(&asn1_ctx))
    {
        LOG_TRACE("%s:ASN context initialization failed.",
                   __FUNCTION__);
        return retVal;
    }
    
    /* Allocate memory for target buffer */
    *p_p_encodedmsg = (unsigned char*)malloc(F1AP_MAX_ASN1_BUF_LEN);

    if (NULL == *p_p_encodedmsg)
    {
        LOG_TRACE("Failed to allocate memory for message buffer \n");
        return SIM_FAILURE;
    }

    memset(*p_p_encodedmsg, 0, sizeof(F1AP_MAX_ASN1_BUF_LEN));

    do
    {
        memset(&(f1ap_pdu), 0, sizeof(f1ap_F1AP_PDU));

        src_asn_msg = (_f1ap_ErrorIndication*)apiBuf;

        /* Fill the values in the ASN structures that shall be encoded by
        ** ASN Encoder */

        /* Set Pdu type to Initiating message */
        f1ap_pdu.t = T_f1ap_F1AP_PDU_initiatingMessage;

        f1ap_pdu.u.initiatingMessage = rtxMemAllocType(&asn1_ctx,
                                            f1ap_InitiatingMessage);
        if (NULL == f1ap_pdu.u.initiatingMessage)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_InitiatingMessage(f1ap_pdu.u.initiatingMessage);

        /* Fill procedure code */
        f1ap_pdu.u.initiatingMessage->procedureCode 
                      = ASN1V_f1ap_id_ErrorIndication;

        /* Fill criticality of message type */
        f1ap_pdu.u.initiatingMessage->criticality = f1ap_ignore;

        /* Set the initiating message type to Error Indication */ 
        f1ap_pdu.u.initiatingMessage->value.t = T2f1ap__errorIndication;

        p_asn_msg = rtxMemAllocType(&asn1_ctx, f1ap_ErrorIndication);
        if (NULL == p_asn_msg)
        {
            LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
            break;
        }

        asn1Init_f1ap_ErrorIndication(p_asn_msg);

        f1ap_pdu.u.initiatingMessage->value.u.errorIndication = p_asn_msg;

        /* Compose transaction ID */
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ErrorIndication_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ErrorIndication_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_TransactionID;
            p_protocolIE_elem->criticality 
                    = f1ap_reject;

            p_protocolIE_elem->value.t     
                    = T10f1ap___f1ap_ErrorIndicationIEs_1;

            p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_1
                    = src_asn_msg->transactionId;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose CU F1AP ID, if present in source container */
        if (F1AP_ERROR_INDICATION_CU_UE_F1AP_ID_PRESENT &
                src_asn_msg->bitmask)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ErrorIndication_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ErrorIndication_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_CU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T10f1ap___f1ap_ErrorIndicationIEs_2;

            p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_2
                    = src_asn_msg->cu_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose DU F1AP ID, if present in source container */
        if (F1AP_ERROR_INDICATION_DU_UE_F1AP_ID_PRESENT &
                src_asn_msg->bitmask)
        {
            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ErrorIndication_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ErrorIndication_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_gNB_DU_UE_F1AP_ID;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t     
                    = T10f1ap___f1ap_ErrorIndicationIEs_3;

            p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_3
                    = src_asn_msg->du_f1ap_id;

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose cause, if present in source container */
        if (F1AP_ERROR_INDICATION_CAUSE_PRESENT &
                    src_asn_msg->bitmask)
        {
            f1ap_Cause*  p_cause = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ErrorIndication_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ErrorIndication_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_Cause;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t   
                    = T10f1ap___f1ap_ErrorIndicationIEs_4;

            p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_4
                    = rtxMemAllocType(&asn1_ctx, f1ap_Cause);

            if (NULL == p_protocolIE_elem->value.u.
                                   _f1ap_ErrorIndicationIEs_4)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            /* Store pointer in local variable for further processing */
            p_cause = p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_4;

            /* Populate cause from the source container */
            p_cause->t = src_asn_msg->cause.cause_type;

            switch(src_asn_msg->cause.cause_type)
            {
                case F1_CAUSE_RADIO_NETWORK: 
                {
                    p_cause->u.radioNetwork 
                                 = src_asn_msg->cause.u.radioNetwork; 
                    break;
                }

                case F1_CAUSE_TRANSPORT:  
                {
                    p_cause->u.transport 
                                 = src_asn_msg->cause.u.transport;
                    break;
                }

                case F1_CAUSE_PROTOCOL:
                {
                    p_cause->u.protocol 
                                 = src_asn_msg->cause.u.protocol;
                    break;
                }

                case F1_CAUSE_MISC:
                {
                    p_cause->u.misc 
                                = src_asn_msg->cause.u.misc;
                    break;
                }

                default:
                {
                    LOG_TRACE("Invalid cause type received \n");
                    break;
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* Compose criticality diagnostics, if present in source container */
        if (F1AP_ERROR_INDICATION_CRIT_DIAG_PRESENT &
                                        src_asn_msg->bitmask)
        {
            f1ap_CriticalityDiagnostics*  p_trg_crit_diag = NULL;
            _f1ap_CriticalityDiagnostics* p_src_crit_diag = NULL;

            /* Allocate memory for target protocolIE element */
            rtxDListAllocNodeAndData(&asn1_ctx,
                    f1ap_ErrorIndication_protocolIEs_element,
                    &p_node,
                    &p_protocolIE_elem);

            if (NULL == p_node)
            {
                LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                break;
            }

            asn1Init_f1ap_ErrorIndication_protocolIEs_element(
                      p_protocolIE_elem);

            p_protocolIE_elem->id          
                    = ASN1V_f1ap_id_CriticalityDiagnostics;
            p_protocolIE_elem->criticality 
                    = f1ap_ignore;

            p_protocolIE_elem->value.t   
                    = T10f1ap___f1ap_ErrorIndicationIEs_5;

            p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_5
                    = rtxMemAllocType(&asn1_ctx, 
                            f1ap_CriticalityDiagnostics);

            if (NULL == p_protocolIE_elem->value.u.
                                   _f1ap_ErrorIndicationIEs_5)
            {
                LOG_TRACE("%s:ASN malloc failed.", __FUNCTION__);
                break;
            }

            asn1Init_f1ap_CriticalityDiagnostics(
                  p_protocolIE_elem->value.u._f1ap_ErrorIndicationIEs_5);

            /* Store pointer in local variable for further processing */
            p_trg_crit_diag = p_protocolIE_elem->value.u.
                                      _f1ap_ErrorIndicationIEs_5;

            /* Fetch pointer to source criticality diagnostics container */
            p_src_crit_diag = &src_asn_msg->criticality_diagnostics;

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CODE_PRESENT)
            {
                p_trg_crit_diag->m.procedureCodePresent = 1;

                p_trg_crit_diag->procedureCode 
                        = p_src_crit_diag->procedureCode; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_TRIGGERING_MSG_PRESENT)
            {
                p_trg_crit_diag->m.triggeringMessagePresent = 1;

                p_trg_crit_diag->triggeringMessage 
                        = p_src_crit_diag->triggeringMessage; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_PROC_CRIT_PRESENT)
            {
                p_trg_crit_diag->m.procedureCriticalityPresent = 1;

                p_trg_crit_diag->procedureCriticality 
                        = p_src_crit_diag->procedureCriticality; 
            }

            if (p_src_crit_diag->bitmask & CRIT_DIAG_IE_LIST_PRESENT)
            {
                f1ap_CriticalityDiagnostics_IE_Item*  trg_item = NULL;
                _f1ap_CriticalityDiagnostics_IE_Item* src_item = NULL;
                OSRTDListNode*                        ieNode   = NULL;
                unsigned int                          index    = 0;

                asn1Init_f1ap_CriticalityDiagnostics_IE_List(
                        &p_trg_crit_diag->iEsCriticalityDiagnostics);

                p_trg_crit_diag->m.iEsCriticalityDiagnosticsPresent = 1;

                for (index = 0; (index < p_src_crit_diag->iEsList.ie_count &&
                                 index < MAX_IE_IN_CRIT_DIAG_IE_LIST); 
                     index++)
                {
                    /* Fetch pointer to the source item */
                    src_item = &p_src_crit_diag->iEsList.ie_info[index];

                    /* Allocate memory for target element */
                    rtxDListAllocNodeAndData(&asn1_ctx,
                            f1ap_CriticalityDiagnostics_IE_Item,
                            &ieNode,
                            &trg_item);

                    if (NULL == ieNode)
                    {
                        LOG_TRACE("%s:ASN malloc failed.",__FUNCTION__);
                        break;
                    }

                    /* Initialize target item */
                    asn1Init_f1ap_CriticalityDiagnostics_IE_Item(trg_item);

                    /* Populate item attributes */
                    trg_item->iECriticality = src_item->iECriticality;
                    trg_item->iE_ID         = src_item->iE_ID;
                    trg_item->typeOfError   = src_item->typeOfError;

                    /* Add element to the list */
                    rtxDListAppendNode(&p_trg_crit_diag->iEsCriticalityDiagnostics,
                                       ieNode);
                }
            }

            rtxDListAppendNode(&p_asn_msg->protocolIEs, p_node);
        }

        /* ASN Encode message */
        pu_setBuffer(&asn1_ctx, *p_p_encodedmsg,
                     F1AP_MAX_ASN1_BUF_LEN, TRUE);

        if (0 != asn1PE_f1ap_F1AP_PDU(&asn1_ctx, &f1ap_pdu))
        {
            char buff[500];
            rtxErrGetTextBuf(&asn1_ctx,buff ,500);
            LOG_TRACE("BUFFER[%s] %lx\n",(char*)buff,(unsigned long)buff); 
            LOG_TRACE("ASN1 encoding of SeNB Addition failed.");
            break;
        }
        else
        {
            *p_encodedmsg_len = (U16)pe_GetMsgLen(&asn1_ctx);
            retVal = SIM_SUCCESS;
            asn1Print_f1ap_F1AP_PDU("f1ap_pdu", &f1ap_pdu);
        }
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    return SIM_SUCCESS;
}


