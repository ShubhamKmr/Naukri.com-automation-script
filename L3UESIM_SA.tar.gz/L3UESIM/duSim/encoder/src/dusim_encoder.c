/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the encoder calling  functions
 * *                     exposed by DU sim for encoding messages.
 * *
 * ***************************************************************************/
/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "f1ap_asn_enc_dec_3gpp.h"
#include "proto_enc_dec.h"
#include "dusimEncoder.h"
#include "typedefs.h"
//#include "stack_app_cmd_interpreter_intf.h"
//#include "DUAP.h"
#include "intf_mgmnt.h"
#include "ueContextMgmnt.h"
#include "rrcMsgTransfer.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "dusim_cmd_defs.h"


#define __FILENAME__ "encoder.c"

#define DUAP_MAX_ASN1_BUF_LEN  8192


/* Function exposed by DU sim for encoding messages */
unsigned char du_sim_encode(
    unsigned short  apiId,
/* spr 24900 changes start */    
    unsigned char*   apiBuf,
/* spr 24900 changes end */    
    unsigned int    apiBufLen,
    unsigned char** p_p_encodedmsg,
    unsigned long*  p_encodedmsg_len)
{
    unsigned char ret_val    = 0;

    if (0 == apiBufLen || NULL == apiBuf) 
    {   
        printf("[%s:%d] ERROR->>Input buffer length or buffer ptr is ZERO, returning...\n"
                    ,__FILENAME__,__LINE__);

        return SIM_FAILURE;
    }

    switch(apiId)
    {
        case DUSIM_ERROR_INDICATION:
        {
            dusim_handle_encode_error_indication(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

        case DUSIM_RESET_REQ:
        {
            dusim_handle_encode_reset_request(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }
        
        case DUSIM_RESET_RESP:
        {
            dusim_handle_encode_reset_ack(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);



            break;
        }

        case DUSIM_F1SETUP_REQ:
        {
            dusim_handle_encode_f1_setup_req(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }


        case DUSIM_GNB_DU_CONFIG_UPDATE:
        {
            dusim_handle_encode_du_config_update_req(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

        case DUSIM_GNB_CU_CONFIG_UPDATE_ACK:
        {
            dusim_handle_encode_cu_config_update_ack(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }
        case DUSIM_UE_CTX_SETUP_RESP:
        {
            dusim_handle_encode_ue_context_setup_response(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);
            break;
        }
        case DUSIM_UE_CTX_MOD_RESP:
        {
		dusim_handle_encode_ue_context_modification_response(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);

            break;
        }
	case DUSIM_UE_CTX_REL_REQ:
	{
		dusim_handle_encode_ue_context_release_request(
				apiBuf,
				apiBufLen,
				p_p_encodedmsg,
				p_encodedmsg_len);
		break;

	}
	case DUSIM_UE_CTX_MOD_FAILURE:
        {
            dusim_handle_encode_ue_context_mod_failure(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);

            break;
        }	
        case DUSIM_CU_INIT_UE_CTX_REL_COMPLETE:
        {
            dusim_handle_encode_ue_context_release_complete(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);
            break;
        }
        case DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE:
        {
            dusim_handle_encode_cu_config_update_failure(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);
            break;
        }
        case DUSIM_UE_CTX_SETUP_FAILURE:
        {
            dusim_handle_encode_ue_context_setup_failure(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);
            break;
        }

        case DUSIM_F1_UL_RRC_MSG_TRANSFER:
        {
            dusim_handle_encode_ul_rrc_msg_transfer(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

	case DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER:
        {
            dusim_handle_encode_init_ul_rrc_msg_transfer(
                    apiBuf,
                    apiBufLen,
                    p_p_encodedmsg,
                    p_encodedmsg_len);
            break;
        }
   
	case DUSIM_UE_CTX_MOD_REQUIRED:
	{
	     dusim_handle_encode_ue_context_modification_required(
				apiBuf,
				apiBufLen,
				p_p_encodedmsg,
				p_encodedmsg_len);

		break;
	}


#if 0
        case DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE:
        {
            dusim_handle_encode_cu_config_update_failure(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

        case DUSIM_UL_RRC_MSG_REQ:
        {
            dusim_handle_encode_ul_rrc_msg_transfer(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

        case DUSIM_UE_CTX_SETUP_RESP:
        {
            dusim_handle_encode_ue_context_setup_response(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }

                case DUSIM_DU_INIT_UE_CTX_REL_REQ:
        {
            dusim_handle_encode_ue_ctx_rel_request(
                                 apiBuf,
                                 apiBufLen,
                                 p_p_encodedmsg,
                                 p_encodedmsg_len);
            break;
        }
        
        case DUSIM_UE_CTX_MOD_REQUIRED:
        {
            break;
        }

        case DUSIM_UE_CTX_MOD_RESP:
        {
            break;
        }
	
	case DUSIM_UE_CTX_REL_REQ:
	{
	    break;
	}
        case DUSIM_UE_CTX_MOD_FAILURE:
        {
            break;
        }
#endif
        default:
        {
            printf("[%s:%d] ERROR->> Incorrect apiId = %d\n"
                   ,__FILENAME__,__LINE__,apiId);

            break;
        }
    }

    return ret_val;
}


/* This function initializes the DU sim encoder */
sim_return_val_et du_sim_encoder_init()
{
    LOG_TRACE("DU sim encoder initialization \n");
    return SIM_SUCCESS;
}


/* This function creates and return encoder for DU sim */
encoder_t* create_du_sim_encoder()
{
    encoder_t* encoder = NULL;

    /* Allocate encoder for DU simulator */
    encoder  = allocate_new_proto_encoder();
    if (NULL == encoder)
    {
        LOG_TRACE("Failed to allocate encoder for DU sim \n");
        return encoder;
    }

    /* Initializes the function pointers of DU sim encoder */
    encoder->init   = du_sim_encoder_init;
    encoder->encode = du_sim_encode;

    return encoder;
}

