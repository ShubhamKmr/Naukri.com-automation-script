/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "dusim_stack_app.h"
#include "du_sim_event.h"
#include "typedefs.h"
#include "proto_sim.h"
#include "dusim_stack_app.h"
#include "globalContext.h"


/* This function fetch and return UE context based on IMSI
 * passed by caller */
dusim_ue_context_t* 
dusim_get_ue_context_by_imsi(unsigned int imsi)
{
    dusim_ue_context_t*  p_ue_context = NULL;

    p_ue_context = &gDUSimContext.ue_contexts[imsi];
    if (p_ue_context->inUse)
    {
        return p_ue_context;
    }

    return NULL;
}


/* This function fetch and return UE context based on gNB-DU 
 * UE F1AP ID and gNB-DU UE F1AP ID extension passed by caller */
dusim_ue_context_t* 
dusim_get_ue_context(
     unsigned short du_ue_f1ap_id, 
     unsigned int   du_ue_f1ap_id_extn)
{
    dusim_ue_context_t*  p_ue_context = NULL;
    unsigned int         index        = 0;

    /* Traverse through the list of all UEs and check if the
     * MeNB UE F1AP ID and MeNB UE F1AP ID of any UE matches 
     * with one passed by caller. */
    for (index = 0; index < MAX_SUPPORTED_UE; index++)
    {
        p_ue_context = &gDUSimContext.ue_contexts[index];

        if ((p_ue_context->inUse) && 
            (p_ue_context->du_ue_f1ap_id == du_ue_f1ap_id) &&
            (p_ue_context->du_ue_f1ap_id_extn == du_ue_f1ap_id_extn))
        {
            return p_ue_context;
        }
    }

    return NULL;
}


/* This function allocates a new UE context and return to caller */
dusim_ue_context_t* 
allocate_dusim_ue_context(unsigned int imsi)
{
    dusim_ue_context_t*  p_ue_context = NULL;
    
    p_ue_context = &gDUSimContext.ue_contexts[imsi];

    /* Reset UE context */
    memset(p_ue_context, 0, sizeof(dusim_ue_context_t));

    /* Store IMSI in UE context */
    p_ue_context->imsi = imsi;

    /* Set the flag to indicate that UE context is in use */
    p_ue_context->inUse = true;

    return p_ue_context;
}


/* This function de-allocates a UE context */
void deallocate_dusim_ue_context(unsigned int imsi)
{
    dusim_ue_context_t*  p_ue_context = NULL;
    
    p_ue_context = &gDUSimContext.ue_contexts[imsi];

    /* Reset the context of UE context */
    memset(p_ue_context, 0, sizeof(dusim_ue_context_t));
}


/* This function fetches and return IMSI corresponding to a
 * gNB-DU UE F1AP ID */
unsigned int dusim_fetch_ue_imsi(
        unsigned short du_ue_f1ap_id,
        unsigned int   du_ue_f1ap_id_extn)
{
    unsigned int         index        = 0;
    dusim_ue_context_t*  p_ue_context = NULL;
    
    for (index = 0; index < MAX_SUPPORTED_UE; index++)
    {
        p_ue_context = &gDUSimContext.ue_contexts[index];

        if ((p_ue_context->du_ue_f1ap_id == du_ue_f1ap_id)  &&
            (p_ue_context->du_ue_f1ap_id_extn == du_ue_f1ap_id_extn))
        {
            /* Return IMSI stored in UE context */
            return p_ue_context->imsi;
        }
    }

    return -1;
}

