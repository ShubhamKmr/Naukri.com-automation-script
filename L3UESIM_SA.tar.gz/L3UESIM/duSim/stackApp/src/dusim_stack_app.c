/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the API for sends f1 context setup request
 * *                     to command interpreter 
 * *
 * ***************************************************************************/

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "rrc_defines.h"
#include "dusim_stack_app.h"
#include "du_sim_event.h"
#include "typedefs.h"
#include "rrc_msg_mgmt.h"
#include "proto_sim.h"
#include "f1ap_asn_enc_dec_3gpp.h"
#include "dusim_cmd_defs.h"
#include "globalContext.h"
#include "test_suite_mgmt.h"

#define RRC_DUM_MODULE_ID 21 

/* F1 CONTEXT SETUP START */
/* The function sends f1 context setup request
 * to command interpreter */


/*******************************************************************************
 * Function Name  : handle_f1_context_setup_req
 * Description    : The function sends f1 context setup request to command interpreter.
 *
 * Inputs         : unsigned int  du_id
 *                  void*         p_api    
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_context_setup_req(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{   
    du_sim_event_t           api;
    dusim_ue_ctx_setup_req_t* ue_context_setup_req     = NULL;
    //dusim_ue_ctx_setup_req_t* src_ue_context_setup_req = NULL;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;
    unsigned int                              msgLen                = 0;

    /* Fetch pointer to source API buffer */
    //src_ue_context_setup_req = (dusim_ue_ctx_setup_req_t*)p_api;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim); 

    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 Setup Response \n");
        return;
    }


    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t) + 
        sizeof(dusim_ue_ctx_setup_req_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_UE_CTX_SETUP_REQ; 
        api.header.length    = msgLen;
        api.header.imsi      = ue_index;
        api.header.du_id     = du_id; 
    }
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_ue_ctx_setup_req_t));
        memset(api.msgBuf, 0, sizeof(dusim_ue_ctx_setup_req_t));
    }

    /* Populate API body */
    {
        ue_context_setup_req = (dusim_ue_ctx_setup_req_t*)api.msgBuf;

        memcpy(&ue_context_setup_req->message,
                pDecodedMsg, decodedMsgLen);


    }
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded f1 context setup request to command interpreter \n");
}

void handle_f1_dl_rrc_transfer_req(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t                  api;
    dusim_f1_dl_rrc_msg_transfer_t*         dl_rrc_transfer_req     = NULL;
    unsigned int                    msgLen                 = 0;
    proto_simulator_t*              du_sim                          = NULL;  
    decoder_t*                      pDecoder                        = NULL; 
    void*                           pDecodedMsg                     = NULL; 
    unsigned long                   decodedMsgLen                   = 0;    
    unsigned short                  ue_index                        = 0;


    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);


    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 ue context mod request \n");
        return;
    }
    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
    + sizeof(dusim_f1_dl_rrc_msg_transfer_t) + 4;


    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_F1_DL_RRC_MSG_TRANSFER; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }

    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_f1_dl_rrc_msg_transfer_t));
        memset(api.msgBuf, 0, sizeof(dusim_f1_dl_rrc_msg_transfer_t));
    }

    /* Populate API body */
    {
        dl_rrc_transfer_req = (dusim_f1_dl_rrc_msg_transfer_t*)api.msgBuf;

        memcpy(&dl_rrc_transfer_req->message, pDecodedMsg, decodedMsgLen);

        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;
    }

    LOG_TRACE("Forwarding F1 DL RRC TRANSFER to Cmd interpreter, length: %d\n", msgLen);
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded  F1 DL RRC TRANSFER request to "
              "command interpreter \n");
return;
}


/*******************************************************************************
 * Function Name  : handle_f1_ue_context_mod_req
 * Description    : The function sends f1 context modification request to command interpreter.
 *
 * Inputs         : unsigned int  du_id
 *                  void*         p_api    
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_ue_context_mod_req(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t                  api;
    dusim_ue_ctx_mod_req_t*         ue_context_mod_req     = NULL;
    unsigned int                    msgLen                 = 0;
    proto_simulator_t*              du_sim                          = NULL;  
    decoder_t*                      pDecoder                        = NULL; 
    void*                           pDecodedMsg                     = NULL; 
    unsigned long                   decodedMsgLen                   = 0;    
    unsigned short                  ue_index                        = 0;


    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);


    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 ue context mod request \n");
        return;
    }
    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
    + sizeof(dusim_ue_ctx_mod_req_t) + 4;


    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_UE_CTX_MOD_REQUEST; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }

    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_ue_ctx_mod_req_t));
        memset(api.msgBuf, 0, sizeof(dusim_ue_ctx_mod_req_t));
    }

    /* Populate API body */
    {
        ue_context_mod_req = (dusim_ue_ctx_mod_req_t*)api.msgBuf;

        memcpy(&ue_context_mod_req->message, pDecodedMsg, decodedMsgLen);

        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;
    }

    LOG_TRACE("Forwarding F1 Setup Resp to Cmd interpreter, length: %d\n", msgLen);
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded f1 context modification request to "
              "command interpreter \n");
}

/*******************************************************************************
 * Function Name  : handle_f1_ue_context_release_command
 * Description    : The function sends f1 context release command to command interpreter.
 *
 * Inputs         : unsigned int  du_id
 *                  void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_ue_context_release_command(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t                  api;
    dusim_cu_init_ue_ctx_rel_cmd_t* ue_context_rel_req     = NULL;
    unsigned int                    msgLen                 = 0;
    proto_simulator_t*              du_sim                          = NULL;  
    decoder_t*                      pDecoder                        = NULL; 
    void*                           pDecodedMsg                     = NULL; 
    unsigned long                   decodedMsgLen                   = 0;    
    unsigned short                  ue_index                        = 0;

    /* Fetch pointer to source API buffer */
    //src_ue_context_rel_req = (dusim_cu_init_ue_ctx_rel_cmd_t*)p_api;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);


    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 Setup Response \n");
        return;
    }

    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t) + 
                        sizeof(dusim_cu_init_ue_ctx_rel_cmd_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_CU_INIT_UE_CTX_REL_CMD; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_cu_init_ue_ctx_rel_cmd_t));
        memset(api.msgBuf, 0, sizeof(dusim_cu_init_ue_ctx_rel_cmd_t));
    }

    /* Populate API body */
    {
        ue_context_rel_req = (dusim_cu_init_ue_ctx_rel_cmd_t*)api.msgBuf;

        memcpy(&ue_context_rel_req->message, pDecodedMsg, decodedMsgLen);


        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;

    }

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded f1 context release command to command interpreter \n");
}


/* F1 CONTEXT SETUP STOP */
/*******************************************************************************
 * Function Name  : fetch_f1_api_id
 * Description    : This function forwards a message from stack application to command interpreter.
 *
 * Inputs         : OSUINT32     message_type
 *                  f1ap_ProcedureCode  proc_code
 * Outputs        : NA
 * Returns        : procedure code
 ******************************************************************************/



/* Fetch API ID based on message type and procedure code */
unsigned int fetch_f1_api_id(
        OSUINT32            message_type,
        f1ap_ProcedureCode  proc_code)
{
    unsigned int api_id = DUSIM_INVALID_API_ID;
    /* Determine EP based on Message Type and Procedure Code */    
    switch (message_type)
    {
        /* Initiating Message */
        case T_f1ap_F1AP_PDU_initiatingMessage:
        {
            LOG_TRACE("Partial Decode: F1 Initiating message received \n");

            if (ASN1V_f1ap_id_DLRRCMessageTransfer == proc_code)
            {
                api_id = DUSIM_F1_DL_RRC_MSG_TRANSFER;
            break;
            }

            if (ASN1V_f1ap_id_F1Setup == proc_code)
            {
                api_id = DUSIM_F1SETUP_RESP;
            break;
            }

	    if (ASN1V_f1ap_id_ErrorIndication == proc_code)
	    {
		    api_id = DUSIM_ERROR_INDICATION;
		    break;
	    }

            if (ASN1V_f1ap_id_UEContextSetup == proc_code)
            {
                api_id = DUSIM_UE_CTX_SETUP_REQ;
                break;
            }
            if (ASN1V_f1ap_id_gNBCUConfigurationUpdate == proc_code)
            {
                api_id = DUSIM_GNB_CU_CONFIG_UPDATE;
                break;
            }
            if (ASN1V_f1ap_id_gNBDUConfigurationUpdate == proc_code)
            {
                api_id = DUSIM_GNB_DU_CONFIG_UPDATE_ACK;
            break;
            }
            if (ASN1V_f1ap_id_UEContextModification == proc_code)
            {
                api_id = DUSIM_UE_CTX_MOD_REQUEST;
            break;
            }
            if (ASN1V_f1ap_id_UEContextRelease == proc_code)
            {
                api_id = DUSIM_CU_INIT_UE_CTX_REL_CMD;
                break;
            }

        }

        /* Successful Outcome */
        case T_f1ap_F1AP_PDU_successfulOutcome:
        {
            LOG_TRACE("Partial Decode: F1 Successful outcome message received\n");

            if (ASN1V_f1ap_id_F1Setup == proc_code)
            {
                api_id = DUSIM_F1SETUP_RESP;

                break;
            }
            if (ASN1V_f1ap_id_UEContextSetup == proc_code)
            {
                api_id = DUSIM_UE_CTX_SETUP_REQ;
                break;
            }
            if (ASN1V_f1ap_id_gNBCUConfigurationUpdate == proc_code)
            {
                api_id = DUSIM_GNB_CU_CONFIG_UPDATE;
                break;
            }
            if (ASN1V_f1ap_id_gNBDUConfigurationUpdate == proc_code)
            {
                api_id = DUSIM_GNB_DU_CONFIG_UPDATE_ACK;
                break;
            }
            if (ASN1V_f1ap_id_UEContextModification == proc_code)
            {
                api_id = DUSIM_UE_CTX_MOD_REQUEST;
                break;
            }
            if (ASN1V_f1ap_id_UEContextRelease == proc_code)
            {
                api_id = DUSIM_CU_INIT_UE_CTX_REL_CMD;
                break;
            }


        }

        /* Unsuccessful Outcome */
        case T_f1ap_F1AP_PDU_unsuccessfulOutcome:
        {
            LOG_TRACE("Partial Decode: F1 Unsuccessful outcome message received\n");
            if (ASN1V_f1ap_id_gNBDUConfigurationUpdate == proc_code)
            {
                api_id = DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE;
                break;

            }
            if (ASN1V_f1ap_id_F1Setup == proc_code)
            {
           
                api_id =  DUSIM_F1SETUP_FAILURE;  
            
                break;
            
            }
            
            
        }
        default:
        {
            LOG_TRACE("Partial Decode: Unknown message Type received\n");
            break;
        }
    }

    //LOG_TRACE("API received from Peer: %d \n", api_id);
    return api_id;
}


/*******************************************************************************
 * Function Name  : fetch_f1_api_id_for_asn_message
 * Description    : This function fetches and return API ID corresponding to received ASN message.
 *
 * Inputs         : void*         p_api 
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : procedure code
 ******************************************************************************/

/* This function fetches and return API ID corresponding
 * to received ASN message. */
unsigned int fetch_f1_api_id_for_asn_message(
        void*         p_api, 
        unsigned int  apiLen)
{
    OSCTXT              asn1_ctx;
    //f1ap_F1AP_PDU       f1ap_pdu;   
    //unsigned int        buf_size     = 0; 
    unsigned int        api_id       = DUSIM_INVALID_API_ID;
    int                 stat         = 0;
    //OSBOOL              extbit       = FALSE;
    OSUINT32            message_type = 0;
    f1ap_ProcedureCode  proc_code    = 0;
    OSCTXT*             pctxt        = NULL;

    /* Init ASN Context */
    if (RT_OK != rtInitContext(&asn1_ctx))
    {
        return api_id;
    }

    /* Set pointer of asn buffer in asn context */
    pu_setBuffer(&asn1_ctx, p_api, apiLen, TRUE);

    /* Store address of asn context in pointer which will 
     * be used for further processing. */
    pctxt = &asn1_ctx;

    /* Decode message type */
    stat = asn1PD_f1ap_TriggeringMessage(pctxt, &message_type);
    if (stat != 0) 
    {
        return api_id;
    }

    message_type++;

    /* Decode procedure code */
    stat = asn1PD_f1ap_ProcedureCode(pctxt, &proc_code);
    if (stat != 0) 
    {
        return api_id;
    }

    /* Fetch API ID based on message_type and procedure code */
    api_id = fetch_f1_api_id(message_type, proc_code);

    /* Free ASN Context */
    rtFreeContext(&asn1_ctx);

    return api_id;
}


/*******************************************************************************
 * Function Name  : handle_f1_setup_resp_from_peer
 * Description    : This function handle f1 setup response from peer.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api 
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_setup_resp_from_peer(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t  api;
    dusim_f1_setup_resp_t*                    f1_setup_resp         = NULL;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;
    unsigned int                              msgLen                = 0;

    /* Fetch pointer to source API buffer */
    //src_f1_setup_resp = (dusim_f1_setup_resp_t*)p_api;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim); 

    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                                 apiLen,
                                 &pDecodedMsg,
                                 &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 Setup Response \n");
        return;
    }

    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
     + sizeof(dusim_f1_setup_resp_t); //+4;
    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId      = DUSIM_F1SETUP_RESP; 
        api.header.length     = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     =  du_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_f1_setup_resp_t));
        memset(api.msgBuf, 0, sizeof(dusim_f1_setup_resp_t));
    }

    /* Populate API body */
    {
        f1_setup_resp = (dusim_f1_setup_resp_t*)api.msgBuf;
        memcpy(&f1_setup_resp->message, pDecodedMsg, decodedMsgLen);
   }

    LOG_TRACE("Forwarding F1 Setup Resp to Cmd interpreter, length: %d\n", msgLen);

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, msgLen);
}



void handle_f1_error_indiction_from_peer(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t  api;
    dusim_error_indication_t*                 f1_error_indication         = NULL;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;
    unsigned int                              msgLen                = 0;

    /* Fetch pointer to source API buffer */

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim); 

    fprintf(stderr, "Decoding F1 setup response from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                                 apiLen,
                                 &pDecodedMsg,
                                 &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 Setup Response \n");
        return;
    }

    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
     + sizeof(dusim_error_indication_t); //+4;
    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId      = DUSIM_ERROR_INDICATION;
        api.header.length     = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     =  du_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_error_indication_t));
        memset(api.msgBuf, 0, sizeof(dusim_error_indication_t));
    }

    /* Populate API body */
    {
        f1_error_indication = (dusim_error_indication_t*)api.msgBuf;
        memcpy(&f1_error_indication->message, pDecodedMsg, decodedMsgLen);
   }

    LOG_TRACE("Forwarding F1 Setup Resp to Cmd interpreter, length: %d\n", msgLen);

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, msgLen);
}

 /* SPR24420 Fix start */
/*******************************************************************************
 * Function Name  : handle_f1_setup_resp_failure_from_peer
 * Description    : This function handle f1 setup response failure from peer.
 *
 * Inputs         : unsigned int  du_id
 *                  void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_setup_resp_failure_from_peer(
		unsigned int  du_id,
		void*         p_api,
		unsigned int  apiLen)

{
	du_sim_event_t  api;
	dusim_f1_setup_failure_t*                 f1_setup_resp_failure = NULL;
	proto_simulator_t*                        du_sim                = NULL;
	decoder_t*                                pDecoder              = NULL;
	void*                                     pDecodedMsg           = NULL;
	unsigned long                             decodedMsgLen         = 0;
	unsigned short                            ue_index              = 0;
	unsigned int                              msgLen                = 0;

	/* Reset the API buffer */
	memset(&api, 0, sizeof(du_sim_event_t));

	/* Fetch pointer to object of DU simulator */
	du_sim = get_proto_simulator(DUSIM_ID);

	/* Fetch pointer to DU SIM ASN decoder */
	pDecoder = get_proto_decoder(du_sim);

	fprintf(stderr, "Decoding F1 setup response failure from Peer\n");

	/* Decode the received ASN message */
	if (SIM_SUCCESS != pDecoder->decode(p_api,
				apiLen,
				&pDecodedMsg,
				&decodedMsgLen))
	{
		LOG_TRACE("Failed to decode F1 Setup Response failure \n");
		return;
	}

	/* Calculate API length */
	msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
	+ sizeof(dusim_f1_setup_failure_t); //+4;
	/* Populate stack app to cmd interpreter header */
	{
		api.header.apiId      = DUSIM_F1SETUP_FAILURE;
		api.header.length     = msgLen;
		api.header.imsi       = ue_index;
		api.header.du_id     =  du_id;
	}
	/* Allocate memory for API buffer */
	{
		api.msgBuf = malloc(sizeof(dusim_f1_setup_failure_t));
		memset(api.msgBuf, 0, sizeof(dusim_f1_setup_failure_t));
	}

	/* Populate API body */
	{
		f1_setup_resp_failure = (dusim_f1_setup_failure_t*)api.msgBuf;
		memcpy(&f1_setup_resp_failure->message, pDecodedMsg, decodedMsgLen);
	}

	LOG_TRACE("Forwarding F1 Setup Resp failure to Cmd interpreter, length: %d\n", msgLen);

	/* Forward API to cmd interpreter */
	dusim_forward_msg_to_cmd_interpreter(&api, msgLen);

}
/* SPR24420 Fix stop */
  

/*******************************************************************************
 * Function Name  : handle_f1_peer_control_msg
 * Description    : This function process control message received from peer du.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_peer_control_msg(
            unsigned int   du_id,
            unsigned char* p_api,
            unsigned int   apiLen)
{
    //unsigned char* pDecodedMsg    = NULL; 
    //unsigned long  decodedMsgLen  = 0;  
    unsigned int   apiId          = DUSIM_INVALID_API_ID;

    apiId = fetch_f1_api_id_for_asn_message(p_api, apiLen);

#ifndef ADPT_CHANGES
    /*TODO - API ID shall be fetched based upon DU ASN Code */
    /* Fetch API ID based on message type of received ASN message */
    
    if (DUSIM_INVALID_API_ID == apiId)
    {
        LOG_TRACE("Invalid API ID received, discarding !!!\n");
        return;
    }
#else
    apiLen -= RRC_API_HEADER_SIZE;

    apiId = rrc_get_word_from_header((unsigned char*)p_api + 6);
#endif 
    //SPR23779 START
    /*
    if(F1AP_ADPT_CU_CONFIG_UPDATE_REQ != apiId && F1AP_ADPT_F1_SETUP_CNF != apiId)
    {
        if(detect_unexpected_msg_received(apiId)) return;
    }*/
    //SPR23779 END
    switch(apiId)
    {

        case DUSIM_F1_RESET_REQ:
        {
            LOG_TRACE("Processing received F1 reset Request\n");
            handle_f1_reset_req_rom_peer(du_id,p_api, apiLen);
            break;
        }

        case DUSIM_F1SETUP_RESP:
        {
            LOG_TRACE("Processing received F1 Setup Resp\n");
            #ifdef ADPT_CHANGES
            handle_f1_setup_resp_from_peer(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_f1_setup_resp_from_peer(du_id,p_api, apiLen);
            #endif
            break;
        }

	case DUSIM_ERROR_INDICATION:
	{
		LOG_TRACE("Processing received F1 Setup Resp\n");
		handle_f1_error_indiction_from_peer(du_id,p_api, apiLen);
		break;
	}

        case DUSIM_F1SETUP_FAILURE:
        {
              LOG_TRACE("Processing received F1 Setup Failure Resp\n");
            handle_f1_setup_resp_failure_from_peer(du_id,p_api, apiLen);
            break;
        
        
        }


        /* F1 CONTEXT SETUP START */
        case DUSIM_UE_CTX_SETUP_REQ:
        {
            LOG_TRACE("F1 UE Context Setup Request received from conn Mgr \n");
            #ifdef ADPT_CHANGES
            handle_f1_context_setup_req(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_f1_context_setup_req(du_id,p_api, apiLen);
            #endif
            break;
        }
        /* F1 CONTEXT SETUP STOP */
        case DUSIM_GNB_CU_CONFIG_UPDATE:
        {
            LOG_TRACE("F1 CU Config Update Request received from conn Mgr \n");
            #ifdef ADPT_CHANGES
            handle_cu_config_update_req(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_cu_config_update_req(du_id,p_api, apiLen);
            #endif
            break;
        }

	case DUSIM_UE_CTX_MOD_CONFIRM:
        {
            LOG_TRACE("F1 UE Context Modification Confirm received from conn Mgr \n");
            dusim_handle_f1_context_mod_confirm(du_id,p_api, apiLen);
            break;
        }
	
        case DUSIM_GNB_DU_CONFIG_UPDATE_ACK:
        {
            LOG_TRACE("F1 DU Config Update Request received from conn Mgr \n");
            handle_du_config_update_ack(du_id,p_api, apiLen);
            break;
        }
        case DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE:
        {
            LOG_TRACE("F1 DU Config Update Request received from conn Mgr \n");
            handle_du_config_update_fail(du_id,p_api, apiLen);
            break;
        }
        case DUSIM_F1_DL_RRC_MSG_TRANSFER:
        {
            LOG_TRACE("F1 DL RRC TRANSFER received from conn Mgr \n");
            #ifdef ADPT_CHANGES
            handle_f1_dl_rrc_transfer_req(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_f1_dl_rrc_transfer_req(du_id,p_api, apiLen);
            #endif
            break;
        }


        case DUSIM_UE_CTX_MOD_REQUEST:
        {
            LOG_TRACE("F1 UE Context Modification Request received from conn Mgr \n");
            #ifdef ADPT_CHANGES
            handle_f1_ue_context_mod_req(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_f1_ue_context_mod_req(du_id,p_api, apiLen);
            #endif
            break;
        }

        case DUSIM_CU_INIT_UE_CTX_REL_CMD:
        {
            LOG_TRACE("F1 UE Context Release Command received from conn Mgr \n");
            #ifdef ADPT_CHANGES
            handle_f1_ue_context_release_command(du_id,p_api+RRC_API_HEADER_SIZE, apiLen);
            #else 
            handle_f1_ue_context_release_command(du_id,p_api, apiLen);
            #endif
            break;
        }

        default:
        {
            LOG_TRACE("Invalid API ID\n");
            break;
        }

    }
}

/*******************************************************************************
 * Function Name  : handle_sctp_link_status_indication
 * Description    : This function processes the SCTP link status indication received from connection manager.
 *
 * Inputs         : unsigned int  du_id
                    unsigned char* msgBuf
 *                  unsigned int   msgLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

/* This function processes the SCTP link status indication
 * received from connection manager */
void handle_sctp_link_status_indication(
                    unsigned short du_id,
                    unsigned char* msgBuf,
                    unsigned int   msgLen)
{
    du_sim_event_t  api;
    dusim_sctp_link_status_ind_t*  link_status_ind     = NULL;
    dusim_sctp_link_status_ind_t*  src_link_status_ind = NULL;
    unsigned int             apiLen              = 0;

    /* Fetch pointer to source API buffer */
    src_link_status_ind = (dusim_sctp_link_status_ind_t*)msgBuf;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Calculate API length */
    apiLen = sizeof(du_sim_event_hdr_t) + 
                 sizeof(dusim_sctp_link_status_ind_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId      = DUSIM_SCTP_LINK_STATUS_IND; 
        api.header.length     = apiLen;
        api.header.du_id     = du_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_sctp_link_status_ind_t));
        memset(api.msgBuf, 0, sizeof(dusim_sctp_link_status_ind_t));
    }

    /* Populate API body */
    {
        link_status_ind = (dusim_sctp_link_status_ind_t*)api.msgBuf;

        link_status_ind->link_status
                    = src_link_status_ind->link_status;
    }

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
}

/* GNB CU CODE START */
/*******************************************************************************
 * Function Name  : handle_cu_config_update_req
 * Description    : This function processes cu_config_update_req received from connection manager.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_cu_config_update_req(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{   
    du_sim_event_t           api;
    dusim_cu_config_update_t* cu_config_update     = NULL;
    //dusim_cu_config_update_t* src_cu_config_update = NULL;   
    unsigned int            msgLen  = 0;
    proto_simulator_t*        du_sim                = NULL;  
    decoder_t*                pDecoder              = NULL; 
    void*                     pDecodedMsg           = NULL; 
    unsigned long             decodedMsgLen         = 0;    
    unsigned short            ue_index              = 0;

    /* Fetch pointer to source API buffer */
    //src_cu_config_update = (dusim_cu_config_update_t*)p_api;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));


    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);

    fprintf(stderr, "Decoding cu_config_update_req\n");
    /* Calculate API length */

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 ue context mod request \n");
        return;
    }



    msgLen = sizeof(du_sim_event_hdr_t) + 
        sizeof(dusim_cu_config_update_t); //+4 ;

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_GNB_CU_CONFIG_UPDATE; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_cu_config_update_t));
        memset(api.msgBuf, 0, sizeof(dusim_cu_config_update_t));
    }

    /* Populate API body */
    {
        cu_config_update = (dusim_cu_config_update_t*)api.msgBuf;

        memcpy(&cu_config_update->message,pDecodedMsg, decodedMsgLen);


        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;

    }
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);

    LOG_TRACE("Forwarded CU Config Update request to command interpreter \n");
}

/* F1 UE CONTEXT MODIFICATION CONFIRM start */
/*******************************************************************************
 * Function Name  : dusim_handle_f1_context_mod_confirm
 * Description    : The function sends f1 context modification confirm to command interpreter.
 *
 * Inputs         : unsigned int  du_id
 *                  void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void dusim_handle_f1_context_mod_confirm(
		unsigned int  du_id,
		void*         p_api,
		unsigned int  apiLen)
{
	du_sim_event_t                            api;
	dusim_ue_ctx_mod_confirm_t*               ue_context_mod_conf   = NULL;
	proto_simulator_t*                        du_sim                = NULL;
	decoder_t*                                pDecoder              = NULL;
	void*                                     pDecodedMsg           = NULL;
	unsigned long                             decodedMsgLen         = 0;
	unsigned short                            ue_index              = 0;
	unsigned int                              msgLen                = 0;


	/* Reset the API buffer */
	memset(&api, 0, sizeof(du_sim_event_t));

	du_sim = get_proto_simulator(DUSIM_ID);

	/* Fetch pointer to DU SIM ASN decoder */
	pDecoder = get_proto_decoder(du_sim);

	fprintf(stderr, "Decoding F1 context modification confirm message from Peer\n");

	/* Decode the received ASN message */
	if (SIM_SUCCESS != pDecoder->decode(p_api,
				apiLen,
				&pDecodedMsg,
				&decodedMsgLen))
	{
		LOG_TRACE("Failed to decode F1 context modification confirm message  \n");
		return;
	}


	/* Calculate API length */
	msgLen = sizeof(du_sim_event_hdr_t) +
		sizeof(dusim_ue_ctx_mod_confirm_t);

	/* Populate stack app to cmd interpreter header */
	{
		api.header.apiId     = DUSIM_UE_CTX_MOD_CONFIRM;
		api.header.length    = msgLen;
		api.header.imsi      = ue_index;
		api.header.du_id     = du_id;
	}
	/* Allocate memory for API buffer */
	{
		api.msgBuf = malloc(sizeof(dusim_ue_ctx_mod_confirm_t));
		memset(api.msgBuf, 0, sizeof(dusim_ue_ctx_mod_confirm_t));
	}

	/* Populate API body */
	{
		ue_context_mod_conf = (dusim_ue_ctx_mod_confirm_t*)api.msgBuf;

		memcpy(&ue_context_mod_conf->message,
				pDecodedMsg, decodedMsgLen);


	}
	/* Forward API to cmd interpreter */
	dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
	LOG_TRACE("Forwarded f1 context modification confirm message to command interpreter \n");
}
/* F1 UE CONTEXT MODIFICATION CONFIRM stop */



/*******************************************************************************
 * Function Name  : handle_du_config_update_fail
 * Description    : This function processes handle_du_config_update_fail received from connection manager.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_du_config_update_fail(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{   
    du_sim_event_t                            api;
    dusim_du_config_update_failure_t*         du_config_update      = NULL;
    unsigned int                              msgLen                = 0;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;

    
    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));


    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);

    fprintf(stderr, "Decoding cu_config_update_req\n");
    /* Calculate API length */


    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 ue context mod request \n");
        return;
    }



    msgLen = sizeof(du_sim_event_hdr_t) + 
        sizeof(dusim_du_config_update_failure_t) +4 ;

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_GNB_DU_CONFIG_UPDATE_FAILURE; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_du_config_update_failure_t));
        memset(api.msgBuf, 0, sizeof(dusim_du_config_update_failure_t));
    }

    /* Populate API body */
    {
        du_config_update = (dusim_du_config_update_failure_t*)api.msgBuf;

        memcpy(&du_config_update->message,pDecodedMsg, decodedMsgLen);


        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;

    }
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded CU Config Update request to command interpreter \n");
}

/*******************************************************************************
 * Function Name  : handle_du_config_update_ack
 * Description    : This function processes handle_du_config_update_ack received from connection manager.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_du_config_update_ack(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{   
    du_sim_event_t                            api;
    dusim_du_config_update_ack_t*             du_config_update      = NULL;
    unsigned int                              msgLen                = 0;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;

    
    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));


    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim);

    fprintf(stderr, "Decoding cu_config_update_req\n");
    /* Calculate API length */


    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                apiLen,
                &pDecodedMsg,
                &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 ue context mod request \n");
        return;
    }



    msgLen = sizeof(du_sim_event_hdr_t) + 
        sizeof(dusim_du_config_update_ack_t) +4 ;

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_GNB_CU_CONFIG_UPDATE; 
        api.header.length    = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     = du_id; 
    }
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_du_config_update_ack_t));
        memset(api.msgBuf, 0, sizeof(dusim_du_config_update_ack_t));
    }

    /* Populate API body */
    {
        du_config_update = (dusim_du_config_update_ack_t*)api.msgBuf;

        memcpy(&du_config_update->message,pDecodedMsg, decodedMsgLen);


        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;

    }
    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
    LOG_TRACE("Forwarded CU Config Update request to command interpreter \n");
}

/*******************************************************************************
 * Function Name  : dusim_forward_msg_to_cmd_interpreter
 * Description    : This function forwards a message from stack application to command interpreter.
 *
 * Inputs         : void*         apiBuf
                    unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
/* F1 CONTEXT SETUP STOP */
/* This function forwards a message from stack application
 * to command interpreter. */
void dusim_forward_msg_to_cmd_interpreter(
        void*         apiBuf, 
        unsigned int  apiLen)
{
    proto_simulator_t* du_sim          = NULL;
    cmd_interpreter_t* pCmdInterpreter = NULL;

    /* Fetch pointer to object of UE simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch peer connection handler */
    pCmdInterpreter = get_cmd_interpreter(du_sim);

    /* Invoke the command interpreter callback registered
     * for processing incoming messages from stack app */
    pCmdInterpreter->stack_app_msg_hdlr(apiBuf, apiLen);
}
/*This function processes the gNB CU Configuration update request received from connection manager */
void handle_cu_config_update(
        unsigned short  du_id,
        unsigned char*  msgBuf,
        unsigned int    msgLen)
{
    du_sim_event_t             api;
    //dusim_cu_config_update_t*  config_update_cu_resp     = NULL;
   // dusim_cu_config_update_t*  src_config_update_cu_resp = NULL;
    unsigned int               apiLen                    = 0;
   
   /* Fetch pointer to source API buffer */
    //src_config_update_cu_resp = (dusim_cu_config_update_t*)msgBuf;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Calculate API length */
    apiLen = sizeof(du_sim_event_hdr_t) + 
        sizeof(dusim_cu_config_update_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_GNB_CU_CONFIG_UPDATE; 
        api.header.length    = apiLen;
        api.header.du_id     = du_id; 
    }

    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_cu_config_update_t));
        memset(api.msgBuf, 0, sizeof(dusim_cu_config_update_t));
    }

    /* Populate API body */
    {
     //   config_update_cu_resp = (dusim_cu_config_update_t*)api.msgBuf;

        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;
    }

    /*Forward message to command interpreter*/
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
}
/* GNB CU CODE STOP */



/* This function processes the configure DU response received
 * from connection manager */
void handle_configure_du_response(
                    unsigned short du_id,
                    unsigned char* msgBuf,
                    unsigned int   msgLen)
{
    du_sim_event_t  api;
    dusim_configure_du_resp_t*  config_enb_resp     = NULL;
    dusim_configure_du_resp_t*  src_config_du_resp = NULL;
    unsigned int           apiLen              = 0;

    /* Fetch pointer to source API buffer */
    src_config_du_resp = (dusim_configure_du_resp_t*)msgBuf;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Calculate API length */
    apiLen = sizeof(du_sim_event_hdr_t) + 
                 sizeof(dusim_configure_du_resp_t);

    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId     = DUSIM_CONFIGURE_DU_RESP; 
        api.header.length    = apiLen;
        api.header.du_id     = du_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_configure_du_resp_t));
        memset(api.msgBuf, 0, sizeof(dusim_configure_du_resp_t));
    }

    /* Populate API body */
    {
        config_enb_resp = (dusim_configure_du_resp_t*)api.msgBuf;

        config_enb_resp->response_code 
                    = src_config_du_resp->response_code;

        /* Store DU ID to be used in subsequent messages */
        gDUSimContext.du_contexts[0].du_id = du_id;
    }

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, apiLen);
}


/* This function processes the messages received from DU sim stack */
void du_sim_stack_app_stack_msg_hdlr(
        void*         p_api, 
        unsigned int  apiLen)
{
    LOG_TRACE("Message received from DU sim stack, length:%d p_api %p \n",
              apiLen,p_api);

    unsigned short apiId    = 0;

#ifdef ADPT_CHANGES
    unsigned short srcModId = 0;
    unsigned short srcModId = 0;
    srcModId = rrc_get_word_from_header((unsigned char*)p_api + 2);
    LOG_TRACE(" source module id %d \n", srcModId);

    apiId = rrc_get_word_from_header((unsigned char*)p_api + 6);
    LOG_TRACE(" API id %d \n", apiId);

    handle_f1_peer_control_msg(0, 
                            p_api,
                            apiLen);
    return;

#else
    du_sim_event_t* apiBuf = NULL;
    unsigned int    bufLen = 0;


     apiBuf = (du_sim_event_t*)p_api;

     apiId = apiBuf->header.apiId; //SCTP Changes
    /* Calculate API buffer length */
    bufLen = apiBuf->header.length - sizeof(du_sim_event_hdr_t);
    switch(apiId)
    {
        case 4:
        //case PEER_CONTROL_PDU_IND:
        {
            LOG_TRACE("DU message received from conn Mgr \n");
            handle_f1_peer_control_msg(apiBuf->header.du_id, 
                                    apiBuf->msgBuf, 
                                    bufLen);

            break;
        }

        case DUSIM_SCTP_LINK_STATUS_IND:
        {
            LOG_TRACE("SCTP Link status indication received from conn Mgr\n");
            handle_sctp_link_status_indication(apiBuf->header.du_id,
                                        apiBuf->msgBuf,
                                        bufLen);
            break;
        }

        case DUSIM_CONFIGURE_DU_RESP:
        {
            LOG_TRACE("Configure DU response received from conn Mgr\n");
            handle_configure_du_response(apiBuf->header.du_id,
                                         apiBuf->msgBuf,
                                         bufLen);
            break;
        }
        /*GNB CU CODE START*/
        case DUSIM_GNB_CU_CONFIG_UPDATE:
        {
            LOG_TRACE("CU configuration update received from conn Mgr\n");
            handle_cu_config_update(
                    apiBuf->header.du_id,
                    apiBuf->msgBuf,
                    bufLen);
            break;
        }
        /*GNB CU CODE STOP*/
        default:
        {
            LOG_TRACE("Unknown API received from conn Mgr\n");
            break;
        }
    }
#endif
}


/* This function sends message to connection manager */
void dusim_forward_msg_to_conn_mgr(unsigned char* msgBuf,
                                   unsigned int   length)
{
    proto_simulator_t* du_sim   = NULL;
    peer_conn_mgr_t*   pConnMgr = NULL;

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch peer connection manager */
    pConnMgr = get_proto_peer_conn_mgr(du_sim);

    /* Invoke the internal message handler callback 
     * registered by peer connection manager. */
    pConnMgr->internal_msg_hdlr(msgBuf, length);
}

/*GNB CU CODES START*/
void handle_cu_config_update_ack(unsigned char* msgBuf) {

    du_sim_event_t*                 request           = NULL;
    //du_sim_event_t           api; 
    //dusim_cu_config_update_ack_t* cu_config_update_ack     = NULL; 
    dusim_cu_config_update_ack_t* src_cu_config_update_ack = NULL;
    //unsigned int                  api_id                             = F1AP_ADPT_CU_CONFIG_UPDATE_RESP;
    //unsigned char*                apiBuf                             = NULL;
    proto_simulator_t*            du_sim                             = NULL;
    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;
    du_sim_event_t                user_req;


    /*Fetch pointer to request*/
    request = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source API buffer */
    src_cu_config_update_ack = (dusim_cu_config_update_ack_t*)
                                   request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding cu_config_update_ack\n");

    /* Encode the received ASN message */
    if(SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                (void*)&src_cu_config_update_ack->message, 
                request->header.length,
                &pEncodedMsg,
                &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Context Setup Response\n");
        return;
    }
    //ENCODE STOP

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);


#if 0
    {
    msg_api_length = sizeof(f1ap_adpt_cu_config_update_resp_t) 
                          + RRC_API_HEADER_SIZE;

    apiBuf = malloc(msg_api_length);
    memset(apiBuf, 0, msg_api_length);
    }
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0802,
                                        0x15,
                                        api_id,
                                        sizeof(f1ap_adpt_cu_config_update_resp_t),
                                        0);

    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding gNB Config Update Ack to CU, length: %d\n",
            msg_api_length);
   
   #ifndef ADPT_CHANGES
     nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
   #endif
   #endif 
}
void handle_cu_config_update_fail(unsigned char* msgBuf) {

    du_sim_event_t*                 request                          = NULL;
    dusim_cu_config_update_failure_t * src_cu_config_update_fail           = NULL;
    //unsigned int                  api_id                             = F1AP_ADPT_CU_CONFIG_UPDATE_RESP;
    //unsigned char*                apiBuf                             = NULL;
    proto_simulator_t*            du_sim                             = NULL;
    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;
    du_sim_event_t                user_req;


    /*Fetch pointer to request*/
    request = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source API buffer */
    src_cu_config_update_fail = (dusim_cu_config_update_failure_t*)
                                   request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding cu_config_update_ack\n");

    /* Encode the received ASN message */
    if(SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                (void*)&src_cu_config_update_fail->message, 
                request->header.length,
                &pEncodedMsg,
                &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Context Setup Response\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);


#if 0
    {
    msg_api_length = sizeof(_f1ap_GNBCUConfigurationUpdateFailure) 
                          + RRC_API_HEADER_SIZE;

    apiBuf = malloc(msg_api_length);
    memset(apiBuf, 0, msg_api_length);
    }
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0802,
                                        0x15,
                                        api_id,
                                        sizeof(_f1ap_GNBCUConfigurationUpdateFailure),
                                        0);

    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding gNB Config Update Ack to NR ADAPT SIM, length: %d\n",
            msg_api_length);
        
    nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
#endif 
}


/*GNB CU CODE STOP*/


/*GNB DU CODES START*/
void handle_du_config_update_req(unsigned char* msgBuf) {

    du_sim_event_t*               request                           = NULL;
    dusim_du_config_update_t*     src_du_config_update_req          = NULL;
    //unsigned int                  api_id                            = F1AP_ADPT_DU_CONFIG_UPDATE_REQ;
    //unsigned char*                apiBuf                            = NULL;
    proto_simulator_t*            du_sim                            = NULL;
    encoder_t*                    pEncoder                          = NULL;
    unsigned char*                pEncodedMsg                       = NULL;
    unsigned long                 encodedMsgLen                     = 0;
    //unsigned int                  msg_api_length                    = 0;
    du_sim_event_t               user_req;

    /*Fetch pointer to request*/
    request = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source API buffer */
    src_du_config_update_req = (dusim_du_config_update_t*)
                                   request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding du_config_update_req\n");

    /* Encode the received ASN message */
    if(SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                (void*)&src_du_config_update_req->message, 
                request->header.length,
                &pEncodedMsg,
                &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode du_config_update_req\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);

#if 0
    {
    msg_api_length = sizeof(_f1ap_GNBDUConfigurationUpdate) 
                          + RRC_API_HEADER_SIZE;

    apiBuf = malloc(msg_api_length);
    memset(apiBuf, 0, msg_api_length);
    }
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0802,
                                        0x15,
                                        api_id,
                                        sizeof(_f1ap_GNBDUConfigurationUpdate),
                                        0);

    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding gNB Config Update Ack to NR ADAPT SIM, length: %d\n",
            msg_api_length);
        
    nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
    #endif 
}
/*GNB DU CODE STOP*/

void handle_f1_reset_ack(unsigned char* msgBuf)
{
    du_sim_event_t*              request        = NULL;
    du_sim_event_t               user_req;
    dusim_f1_reset_resp_t*        f1_reset_resp   = NULL;
    proto_simulator_t*           du_sim         = NULL;
    encoder_t*                   pEncoder       = NULL;
    unsigned char*               pEncodedMsg    = NULL;
    unsigned long                encodedMsgLen  = 0;

    request = (du_sim_event_t*)msgBuf;

    /* For future Encoding */
    f1_reset_resp = (dusim_f1_reset_resp_t*)request->msgBuf;

    /* Fetch pointer to object of X2 simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to X2 SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 Reset ack \n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&f1_reset_resp->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 reset ack\n");
        return;
    }
    /* For future Encoding */

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
            + sizeof(du_sim_event_t);
    //user_req.header.length = sizeof(dusim_f1_setup_req_t)
    //                            + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
                                  user_req.header.length);
   #endif
}


//UL RRC TRANSFER change
/* This function handles f1 UL RRC Message Transfer received
 * from command interpreter. */
void handle_f1_ul_rrc_msg_transfer(unsigned char* msgBuf)
{
    du_sim_event_t*              request        = NULL;
    du_sim_event_t               user_req;
    dusim_f1_ul_rrc_msg_transfer_t*        f1_ul_rrc_msg_trnsfr   = NULL;
    proto_simulator_t*           du_sim         = NULL;
    encoder_t*                   pEncoder       = NULL;
    unsigned char*               pEncodedMsg    = NULL;
    unsigned long                encodedMsgLen  = 0;

    request = (du_sim_event_t*)msgBuf;

    /* For future Encoding */
    f1_ul_rrc_msg_trnsfr = (dusim_f1_ul_rrc_msg_transfer_t*)request->msgBuf;

    /* Fetch pointer to object of X2 simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to X2 SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 UL RRC Message Transfer \n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&f1_ul_rrc_msg_trnsfr->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 UL RRC Message Transfer\n");
        return;
    }
    /* For future Encoding */

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
            + sizeof(du_sim_event_t);
    //user_req.header.length = sizeof(dusim_f1_ul_rrc_msg_transfer_t)
    //                            + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
                                  user_req.header.length);
   #endif
}

/* This function handles f1 setup request received
 * from command interpreter. */
void handle_f1_setup_request(unsigned char* msgBuf)
{
    du_sim_event_t*              request        = NULL;
    du_sim_event_t               user_req;
    dusim_f1_setup_req_t*        f1_setup_req   = NULL;
    proto_simulator_t*           du_sim         = NULL;
    encoder_t*                   pEncoder       = NULL;
    unsigned char*               pEncodedMsg    = NULL;
    unsigned long                encodedMsgLen  = 0;

    request = (du_sim_event_t*)msgBuf;

    /* For future Encoding */
    f1_setup_req = (dusim_f1_setup_req_t*)request->msgBuf;

    /* Fetch pointer to object of X2 simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to X2 SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 Setup Request \n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&f1_setup_req->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Setup Request\n");
        return;
    }
    /* For future Encoding */

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
            + sizeof(du_sim_event_t);
    //user_req.header.length = sizeof(dusim_f1_setup_req_t)
    //                            + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
                                  user_req.header.length);
 
  #endif
}
void handle_f1_error_indication(unsigned char* msgBuf)
{
    du_sim_event_t*              request        = NULL;
    du_sim_event_t               user_req;
    dusim_error_indication_t*        f1_error_ind   = NULL;
    proto_simulator_t*           du_sim         = NULL;
    encoder_t*                   pEncoder       = NULL;
    unsigned char*               pEncodedMsg    = NULL;
    unsigned long                encodedMsgLen  = 0;

    request = (du_sim_event_t*)msgBuf;

    /* For future Encoding */
    f1_error_ind = (dusim_error_indication_t*)request->msgBuf;

    /* Fetch pointer to object of X2 simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to X2 SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 Setup Request \n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&f1_error_ind->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Setup Request\n");
        return;
    }
    /* For future Encoding */

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
            + sizeof(du_sim_event_t);
    //user_req.header.length = sizeof(dusim_f1_setup_req_t)
    //                            + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
                                  user_req.header.length);
   #endif
}


/*******************************************************************************
 * Function Name  : handle_f1_ue_context_mod_resp
 * Description    : This function handles handle_f1_ue_context_mod_resp received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/


void handle_f1_ue_context_rel_comp(unsigned char* msgBuf)
{
    du_sim_event_t*                     request                      = NULL;
    //du_sim_event_t                    api; 
    dusim_cu_init_ue_ctx_rel_comp_t*    src_ue_context_rel_comp      = NULL;
    //unsigned int                      api_id                       = F1AP_ADPT_UE_CONTEXT_REL_COMPLETE;
    //UInt8*                            apiBuf                       = NULL;
    encoder_t*                          pEncoder                     = NULL;
    unsigned char*                      pEncodedMsg                  = NULL;
    unsigned long                       encodedMsgLen                = 0;
    //unsigned int                      msg_api_length               = 0;
    proto_simulator_t*                  du_sim                       = NULL;
    du_sim_event_t                      user_req;
    request =                          (du_sim_event_t*)msgBuf;
    
    /* Fetch pointer to source API buffer */
    src_ue_context_rel_comp = (dusim_cu_init_ue_ctx_rel_comp_t*)request->msgBuf;
    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding f1_ue_context_rel_complete\n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                (void*)&src_ue_context_rel_comp->message, 
                request->header.length,
                &pEncodedMsg,
                &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 UE Context Release Complete \n");
        return;
    }
    //ENCODE STOP

    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);


#if 0
    /* Allocate memory for API buffer */
    {
        msg_api_length = sizeof(dusim_cu_init_ue_ctx_rel_resp_t) + RRC_API_HEADER_SIZE;

        apiBuf = malloc(msg_api_length);
        memset(apiBuf, 0, msg_api_length);
    }

    /* Populate API body */
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0805,
                                        0x15,
                                        api_id,
                                        sizeof(f1ap_adpt_ue_context_rel_complete_t),
                                        0);


    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding F1 UE Context Release Response to NR ADAPT SIM, length: %d\n",
               msg_api_length);
#endif    

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr(msgBuf, 
                                  request->header.length);
   #endif
}

/*******************************************************************************
 * Function Name  : handle_f1_ue_context_rel_req
 * Description    : This function handles handle_f1_ue_context_rel_req received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_ue_context_rel_req(unsigned char* msgBuf)
{
	du_sim_event_t*      request        = NULL;
  	
	dusim_cu_init_ue_ctx_rel_req_t*
                         src_ue_context_rel_req = NULL;
	proto_simulator_t*            du_sim   				 = NULL;
	encoder_t*                    pEncoder                           = NULL;
    	unsigned char*                pEncodedMsg                        = NULL;
    	unsigned long                 encodedMsgLen                      = 0;
	
	du_sim_event_t                user_req;

        request = (du_sim_event_t*)msgBuf;

        /* Fetch pointer to source API buffer */
        src_ue_context_rel_req = (dusim_cu_init_ue_ctx_rel_req_t*)request->msgBuf;
	
	//ENCODE START
	 
	/* Fetch pointer to object of DU simulator */
        du_sim = get_proto_simulator(DUSIM_ID);

    	/* Fetch pointer to DU SIM ASN encoder */
    	pEncoder = get_proto_encoder(du_sim);

    	fprintf(stderr, "Encoding f1_ue_context_rel_req\n");

    	/* Encode the received ASN message */
    	if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&src_ue_context_rel_req->message,
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
   	 {
        LOG_TRACE("Failed to encode F1 Context Release Request\n");
        return;
   	 }	
	// ENCODE STOP
	memset(&user_req, 0, sizeof(du_sim_event_t));

    	/* Populate target API to be forwarded to connection
 	* manager */
    	user_req.header.apiId  = 5;
    	user_req.header.length = encodedMsgLen
        + sizeof(du_sim_event_t);
    	user_req.header.du_id = request->header.du_id;
    	user_req.msgBuf        = pEncodedMsg;

    	/* Forward API to connection manager */
    	dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req,
            user_req.header.length);

}


/*******************************************************************************
 * Function Name  : handle_f1_ue_context_mod_resp
 * Description    : This function handles handle_f1_ue_context_mod_resp received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_ue_context_mod_resp(unsigned char* msgBuf)
{
    du_sim_event_t*      request        = NULL;
    //du_sim_event_t       api; 
    dusim_cu_init_ue_ctx_mod_resp_t* 
                         src_ue_context_mod_resp = NULL;

    proto_simulator_t*            du_sim                             = NULL;

    //unsigned int                  api_id                             = F1AP_ADPT_UE_CONTEXT_MOD_RESP;
    //UInt8*                        apiBuf                             = NULL;
    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;   
    du_sim_event_t                user_req;

    request = (du_sim_event_t*)msgBuf;
    
    /* Fetch pointer to source API buffer */
    src_ue_context_mod_resp = (dusim_cu_init_ue_ctx_mod_resp_t*)request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding f1_ue_context_mod_resp\n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&src_ue_context_mod_resp->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Context Setup Response\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);


#if 0
    /* Allocate memory for API buffer */
    {
        msg_api_length = sizeof(dusim_cu_init_ue_ctx_mod_resp_t) + RRC_API_HEADER_SIZE;

        apiBuf = malloc(msg_api_length);
        memset(apiBuf, 0, msg_api_length);
    }

    /* Populate API body */
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0805,
                                        0x15,
                                        api_id,
                                        sizeof(f1ap_adpt_ue_context_mod_resp_t),
                                        0);



    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);
    LOG_TRACE("Forwarding F1 Context Modification Response to CU, length: %d\n",
            msg_api_length);

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */

     nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
   #endif
   #endif
}

/* F1 UE CTXT MOD FAILURE Changes: Vikash */
/*******************************************************************************
 * Function Name  : handle_f1_context_mod_fail
 * Description    : This function handles F1 Context Modification Failure received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_context_mod_fail(unsigned char* msgBuf) 
{

	du_sim_event_t*          request                            = NULL;
	//du_sim_event_t           api; 
	dusim_ue_ctx_mod_failure_t* src_ue_context_mod_fail = NULL;
	//UInt8                         *apiBuf                            = NULL;
	proto_simulator_t*            du_sim                             = NULL;
	encoder_t*                    pEncoder                           = NULL;
	unsigned char*                pEncodedMsg                        = NULL;
	unsigned long                 encodedMsgLen                      = 0;
	//unsigned int                  msg_api_length                     = 0;
	du_sim_event_t                user_req;
	//ENCODE STOP

	request = (du_sim_event_t*)msgBuf;

	/* Fetch pointer to source API buffer */
	src_ue_context_mod_fail = (dusim_ue_ctx_mod_failure_t*)request->msgBuf;

	//ENCODE START
	/* Fetch pointer to object of DU simulator */
	du_sim = get_proto_simulator(DUSIM_ID);

	/* Fetch pointer to DU SIM ASN encoder */
	pEncoder = get_proto_encoder(du_sim); 

	fprintf(stderr, "Encoding F1 UE CTXT Modification Failure \n");

	/* Encode the received ASN message */
	if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
				(void*)&src_ue_context_mod_fail->message, 
				request->header.length,
				&pEncodedMsg,
				&encodedMsgLen))
	{
		LOG_TRACE("Failed to encode F1 UE Context Modification Failure \n");
		return;
	}
	//ENCODE STOP
	memset(&user_req, 0, sizeof(du_sim_event_t));

	/* Populate target API to be forwarded to connection
	 * manager */
	user_req.header.apiId  = 5;
	user_req.header.length = encodedMsgLen 
		+ sizeof(du_sim_event_t);
	user_req.header.du_id = request->header.du_id;
	user_req.msgBuf        = pEncodedMsg;

	/* Forward API to connection manager */
	dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
			user_req.header.length);

#if 0
	/* Allocate memory for API buffer */
	{
		msg_api_length = sizeof(dusim_ue_ctx_setup_resp_t) + RRC_API_HEADER_SIZE;

		apiBuf = malloc(msg_api_length);
		memset(apiBuf, 0, msg_api_length);
	}

	/* Populate API body */
	/* Fill RRC header */
	rrc_construct_interface_api_header(apiBuf,
			1,
			0x0805,
			0x15,
			api_id,
			sizeof(f1ap_adpt_ue_context_setup_resp_t),
			0);
	memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

	LOG_TRACE("Forwarding F1 Context Setup Response to CU, length: %d\n",
			msg_api_length);

#ifndef ADPT_CHANGES
	/* Forward API to connection manager */
	nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
#endif
#endif 
}

/* F1 INIT UL RCC MSG TRANS Code Changes start */

/* This function handles f1 Init UL RRC Msg Transfer received
 *  *      from command interpreter. */
void handle_f1_init_ul_rrc_msg_transfer(unsigned char* msgBuf)
{
    du_sim_event_t*                            request        = NULL;
    du_sim_event_t                             user_req;
    dusim_f1_init_ul_rrc_msg_transfer_t*       du_init_rrc_msg_trans  = NULL;
    proto_simulator_t*                         du_sim         = NULL;
    encoder_t*                                 pEncoder       = NULL;
    unsigned char*                             pEncodedMsg    = NULL;
    unsigned long                              encodedMsgLen  = 0;

    request = (du_sim_event_t*)msgBuf;

    /* For future Encoding */
    du_init_rrc_msg_trans = (dusim_f1_init_ul_rrc_msg_transfer_t*)request->msgBuf;

    /* Fetch pointer to object of X2 simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to X2 SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim);

    fprintf(stderr, "Encoding F1 INIT UL RRC Msg Transfer \n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&du_init_rrc_msg_trans->message,
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 INIT UL RRC Msg Transfer \n");
        return;
    }
    /* For future Encoding */
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen
            + sizeof(du_sim_event_t);
    //user_req.header.length = sizeof(dusim_f1_setup_req_t)
    //                            + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req,
                                   user_req.header.length);
    #endif

}
/* F1 INIT UL RCC MSG TRANS Code Changes stop */


/*F1 UE CTXT MOD REQUIRED Code Changes start */
/*******************************************************************************
 * Function Name  : dusim_handle_f1_ue_context_mod_required
 * Description    : This function handles dusim_handle_f1_ue_context_mod_required received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void dusim_handle_f1_ue_context_mod_required(unsigned char* msgBuf)
{
    du_sim_event_t*      request        = NULL;
    //du_sim_event_t       api;
    dusim_ue_ctx_mod_required_t*
                         src_ue_context_mod_required = NULL;

    proto_simulator_t*            du_sim                             = NULL;

    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;
    du_sim_event_t                user_req;

    request = (du_sim_event_t*)msgBuf;

    /* Fetch pointer to source API buffer */
    src_ue_context_mod_required = (dusim_ue_ctx_mod_required_t*)request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim);

    fprintf(stderr, "Encoding f1_ue_context_mod_required\n");
    
    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&src_ue_context_mod_required->message,
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Ue Context Mod  Required\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = DUSIM_UE_CTX_MOD_REQUIRED;
    user_req.header.length = encodedMsgLen
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req,
            user_req.header.length);

}
/*F1 UE CTXT MOD REQUIRED Code Changes stop */




/*******************************************************************************
 * Function Name  : handle_f1_context_setup_resp
 * Description    : This function handles F1 Context Setup Response received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_context_setup_resp(unsigned char* msgBuf) 
{

    du_sim_event_t*          request                            = NULL;
    //du_sim_event_t           api; 
    //dusim_ue_ctx_setup_resp_t* ue_context_setup_resp     = NULL; 
    dusim_ue_ctx_setup_resp_t* src_ue_context_setup_resp = NULL;
    //unsigned int                  api_id                             = F1AP_ADPT_UE_CONTEXT_SETUP_RESP;
    //UInt8                         *apiBuf                            = NULL;
    proto_simulator_t*            du_sim                             = NULL;
    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;
    du_sim_event_t                user_req;
    //ENCODE STOP

    request = (du_sim_event_t*)msgBuf;
    
    /* Fetch pointer to source API buffer */
    src_ue_context_setup_resp = (dusim_ue_ctx_setup_resp_t*)request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 Setup Request\n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&src_ue_context_setup_resp->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Context Setup Response\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);

#if 0
    /* Allocate memory for API buffer */
    {
        msg_api_length = sizeof(dusim_ue_ctx_setup_resp_t) + RRC_API_HEADER_SIZE;

        apiBuf = malloc(msg_api_length);
        memset(apiBuf, 0, msg_api_length);
    }

    /* Populate API body */
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0805,
                                        0x15,
                                        api_id,
                                        sizeof(f1ap_adpt_ue_context_setup_resp_t),
                                        0);
    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding F1 Context Setup Response to CU, length: %d\n",
            msg_api_length);

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
     nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
   #endif
#endif 
}

/*******************************************************************************
 * Function Name  : handle_f1_context_setup_fail
 * Description    : This function handles F1 Context Setup Response received from cmd interpreter.
 *
 * Inputs         : unsigned char* msgBuf 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void handle_f1_context_setup_fail(unsigned char* msgBuf) 
{

    du_sim_event_t*          request                            = NULL;
    //du_sim_event_t           api; 
    //dusim_ue_ctx_setup_resp_t* ue_context_setup_resp     = NULL; 
    dusim_ue_ctx_setup_failure_t* src_ue_context_setup_fail = NULL;
    //unsigned int                  api_id                             = F1AP_ADPT_UE_CONTEXT_SETUP_RESP;
    //UInt8                         *apiBuf                            = NULL;
    proto_simulator_t*            du_sim                             = NULL;
    encoder_t*                    pEncoder                           = NULL;
    unsigned char*                pEncodedMsg                        = NULL;
    unsigned long                 encodedMsgLen                      = 0;
    //unsigned int                  msg_api_length                     = 0;
    du_sim_event_t                user_req;
    //ENCODE STOP

    request = (du_sim_event_t*)msgBuf;
    
    /* Fetch pointer to source API buffer */
    src_ue_context_setup_fail = (dusim_ue_ctx_setup_failure_t*)request->msgBuf;

    //ENCODE START
    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN encoder */
    pEncoder = get_proto_encoder(du_sim); 

    fprintf(stderr, "Encoding F1 Setup Request\n");

    /* Encode the received ASN message */
    if (SIM_SUCCESS != pEncoder->encode(request->header.apiId,
                                 (void*)&src_ue_context_setup_fail->message, 
                                 request->header.length,
                                 &pEncodedMsg,
                                 &encodedMsgLen))
    {
        LOG_TRACE("Failed to encode F1 Context Setup Response\n");
        return;
    }
    //ENCODE STOP
    memset(&user_req, 0, sizeof(du_sim_event_t));

    /* Populate target API to be forwarded to connection
     * manager */
    user_req.header.apiId  = 5;
    user_req.header.length = encodedMsgLen 
        + sizeof(du_sim_event_t);
    user_req.header.du_id = request->header.du_id;
    user_req.msgBuf        = pEncodedMsg;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr((unsigned char*)&user_req, 
            user_req.header.length);

#if 0
    /* Allocate memory for API buffer */
    {
        msg_api_length = sizeof(dusim_ue_ctx_setup_resp_t) + RRC_API_HEADER_SIZE;

        apiBuf = malloc(msg_api_length);
        memset(apiBuf, 0, msg_api_length);
    }

    /* Populate API body */
    /* Fill RRC header */
    rrc_construct_interface_api_header(apiBuf,
                                        1,
                                        0x0805,
                                        0x15,
                                        api_id,
                                        sizeof(f1ap_adpt_ue_context_setup_resp_t),
                                        0);
    memcpy(apiBuf + RRC_API_HEADER_SIZE, pEncodedMsg, encodedMsgLen);

    LOG_TRACE("Forwarding F1 Context Setup Response to CU, length: %d\n",
            msg_api_length);

   #ifndef ADPT_CHANGES
    /* Forward API to connection manager */
     nradaptsim_forward_msg_to_stack(apiBuf, RRC_API_HEADER_SIZE + encodedMsgLen);
   #endif
#endif 
}

/*******************************************************************************
 * Function Name  : handle_f1_reset_req_rom_peer
 * Description    : This function handle f1 reset request from peer.
 *
 * Inputs         : unsigned int  du_id
                    void*         p_api 
 *                  unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

void handle_f1_reset_req_rom_peer(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen)
{
    du_sim_event_t  api;
    dusim_f1_reset_req_t*                    f1_reset_Req         = NULL;
    proto_simulator_t*                        du_sim                = NULL;  
    decoder_t*                                pDecoder              = NULL; 
    void*                                     pDecodedMsg           = NULL; 
    unsigned long                             decodedMsgLen         = 0;    
    unsigned short                            ue_index              = 0;
    unsigned int                              msgLen                = 0;

    /* Fetch pointer to source API buffer */
    //f1_reset_Req = (dusim_f1_reset_req_t*)p_api;

    /* Reset the API buffer */
    memset(&api, 0, sizeof(du_sim_event_t));

    /* Fetch pointer to object of DU simulator */
    du_sim = get_proto_simulator(DUSIM_ID);

    /* Fetch pointer to DU SIM ASN decoder */
    pDecoder = get_proto_decoder(du_sim); 

    fprintf(stderr, "Decoding F1 reset request from Peer\n");

    /* Decode the received ASN message */
    if (SIM_SUCCESS != pDecoder->decode(p_api,
                                 apiLen,
                                 &pDecodedMsg,
                                 &decodedMsgLen))
    {
        LOG_TRACE("Failed to decode F1 reset request \n");
        return;
    }

    /* Calculate API length */
    msgLen = sizeof(du_sim_event_hdr_t)// + decodedMsgLen;
     + sizeof(dusim_f1_reset_req_t); //+4;
    /* Populate stack app to cmd interpreter header */
    {
        api.header.apiId      = DUSIM_RESET_REQ; 
        api.header.length     = msgLen;
        api.header.imsi       = ue_index;
        api.header.du_id     =  du_id; 
    }
    
    /* Allocate memory for API buffer */
    {
        api.msgBuf = malloc(sizeof(dusim_f1_reset_req_t));
        memset(api.msgBuf, 0, sizeof(dusim_f1_reset_req_t));
    }

    /* Populate API body */
    {
        f1_reset_Req = (dusim_f1_reset_req_t*)api.msgBuf;
        memcpy(&f1_reset_Req->message, pDecodedMsg, decodedMsgLen);
   }

    LOG_TRACE("Forwarding F1 reset request to Cmd interpreter, length: %d\n", msgLen);

    /* Forward API to cmd interpreter */
    dusim_forward_msg_to_cmd_interpreter(&api, msgLen);
}



/* F1 CONTEXT SETUP STOP */
/* This function handles configure DU request received
 * from command interpreter. */
void handle_configure_du_request(unsigned char* msgBuf)
{
    du_sim_event_t*      request  = NULL;
    dusim_du_context_t*  p_du_ctx = NULL;

    request = (du_sim_event_t*)msgBuf;

    /* Allocate DU context */
    p_du_ctx = allocate_dusim_du_context();
    if (NULL == p_du_ctx)
    {
        LOG_TRACE("Failed to allocate DU context \n");

        /* TODO: Need to build and send response to user */
        return;
    }

    LOG_TRACE("Successfully allocated DU context with DU ID: %d\n", 
              p_du_ctx->du_id);

    /* Update DU ID in the API header before forwarding
     * to connection manager */
    request->header.du_id = p_du_ctx->du_id;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr(msgBuf, 
                                  request->header.length);
}


/* This function handles connection reset request received from
 * command interpreter */
void handle_connection_reset_request(unsigned char* msgBuf)
{
    du_sim_event_t*  
                          request   = NULL;

    request = (du_sim_event_t*)msgBuf;

    request->header.apiId  = 6;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr(msgBuf, 
                                  request->header.length);
}


/* This function handles connection initiation request 
 * received from command interpreter. */
void duSim_handle_connection_initiation_request(
        void* msgBuf)
{
    du_sim_event_t* request = NULL;

    request  = (du_sim_event_t*)msgBuf;

    /* Forward API to connection manager */
    dusim_forward_msg_to_conn_mgr(msgBuf, 
                                  request->header.length);
}

/*******************************************************************************
 * Function Name  : dusim_forward_msg_to_cmd_interpreter
 * Description    : This function processes the messages received from command interpreter.
 *
 * Inputs         : void*         msgBuf
                    unsigned int  apiLen
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/
void du_sim_stack_app_user_msg_hdlr(
                        void* msgBuf) 
{
    /* Fetch API ID from the received message buffer */
    unsigned short   apiId   = 0;
    //unsigned int     imsi    = 0;
    du_sim_event_t*  request = NULL;

    if (NULL == msgBuf)
    {
        LOG_TRACE("Invalid pointer received \n");
        return;
    }

    /* Get pointer to the received API buffer */
    request = (du_sim_event_t*)msgBuf;

    /* Fetch API ID */
    apiId = request->header.apiId;

    /* Fetch IMSI from the request */
    //imsi = request->header.imsi;

    /* Fetch UE context based on IMSI */
    //dusim_ue_context_t* ue_context = NULL;

    switch(apiId)
    {

        case DUSIM_CONFIGURE_DU_REQ:
        {
            LOG_TRACE("Configure DU Request received from cmd interpreter, apiId: %d\n", apiId);
            handle_configure_du_request(msgBuf);
            break;
        }

        case DUSIM_CONN_INITIATION_REQ:
        {
            LOG_TRACE("Connection Initiation Request received from cmd interpreter, apiId: %d\n", apiId);
            duSim_handle_connection_initiation_request(msgBuf);
            break;
        }

        case DUSIM_CONN_RESET_REQ:
        {
            LOG_TRACE("Connection Reset Request received from cmd interpreter, apiId: %d\n", apiId);
            handle_connection_reset_request(msgBuf);
            break;
        }

        case DUSIM_F1SETUP_REQ:
        {
            LOG_TRACE("F1 Setup Request received from cmd interpreter, apiId: %d\n", apiId);
            handle_f1_setup_request(msgBuf);
            break;
        }
	case DUSIM_ERROR_INDICATION:
	{
		LOG_TRACE("F1 Setup Request received from cmd interpreter, apiId: %d\n", apiId);
		handle_f1_error_indication(msgBuf);
		break;
	}
        case DUSIM_F1_UL_RRC_MSG_TRANSFER: //UL RRC TRANSFER change 
        {
            LOG_TRACE("F1 UL RRC Message Transfer received from cmd interpreter, apiId: %d\n", apiId);
            handle_f1_ul_rrc_msg_transfer(msgBuf);
            break;
        }

        case DUSIM_RESET_RESP:
        {
            LOG_TRACE("F1 reset ack  received from cmd interpreter, apiId: %d\n", apiId);
            handle_f1_reset_ack(msgBuf);
            break;
        }

        /*GNB CU CODE START*/
        case DUSIM_GNB_CU_CONFIG_UPDATE_ACK:
        {
            LOG_TRACE("CU Config update acknowledgement received from cmd interpreter, apiId: %d\n", apiId);
            handle_cu_config_update_ack(msgBuf); 
            break;
        }
        case DUSIM_GNB_CU_CONFIG_UPDATE_FAILURE:
        {
            LOG_TRACE("CU Config update acknowledgement received from cmd interpreter, apiId: %d\n", apiId);
            handle_cu_config_update_fail(msgBuf); 
            break;
        }

        /*GNB CU CODE STOP*/
        /*GNB DU CODE START*/
        case DUSIM_GNB_DU_CONFIG_UPDATE:
        {
            LOG_TRACE("CU Config update acknowledgement received from cmd interpreter, apiId: %d\n", apiId);
            handle_du_config_update_req(msgBuf); 
            break;
        }
        /*GNB DU CODE STOP*/
        /* F1 CONTEXT SETUP START */
        case DUSIM_UE_CTX_SETUP_RESP:
        {
            LOG_TRACE("F1 Context setup response received from command interpreter, apiID: %d\n", apiId);
            handle_f1_context_setup_resp(msgBuf);
            break;
        }
        /* F1 CONTEXT SETUP STOP */
        case DUSIM_UE_CTX_SETUP_FAILURE:
        {
            LOG_TRACE("F1 Context setup fail received from command interpreter, apiID: %d\n", apiId);
            handle_f1_context_setup_fail(msgBuf);
            break;
        }

        case DUSIM_CU_INIT_UE_CTX_REL_COMPLETE:
        {
            LOG_TRACE("F1 UE context release complete received from command interpreter, apiID: %d\n", apiId);
            handle_f1_ue_context_rel_comp(msgBuf);
            break;
        }

        case DUSIM_UE_CTX_MOD_RESP:
        {
            LOG_TRACE("F1 UE context modification response received from command interpreter, apiID: %d\n", apiId);
            handle_f1_ue_context_mod_resp(msgBuf);
            break;
        }
	
	case DUSIM_UE_CTX_REL_REQ:
	{
		LOG_TRACE("F1 UE context release request received from command interpreter, apiID: %d\n", apiId);
		handle_f1_ue_context_rel_req(msgBuf);
		break;
	}
	case DUSIM_UE_CTX_MOD_FAILURE:
        {
            LOG_TRACE("F1 Context modification failure received from command interpreter, apiID: %d\n", apiId);
            handle_f1_context_mod_fail(msgBuf);
            break;
        }

	case DUSIM_F1_INIT_UL_RRC_MSG_TRANSFER:
        {
            LOG_TRACE("F1 INIT UL RRC Message Transfer received from cmd interpreter, apiId: %d\n", apiId);
            handle_f1_init_ul_rrc_msg_transfer(msgBuf);
            break;
        }

        case DUSIM_UE_CTX_MOD_REQUIRED:
        {
            LOG_TRACE("F1 UE context modification required received from command interpreter, apiID: %d\n", apiId);
            dusim_handle_f1_ue_context_mod_required(msgBuf);
            break;
        }

        default:
        {
            LOG_TRACE("Unsupported API received from cmd interpreter, apiID: %d\n",
                      apiId);

            /* Free the message buffer memory */
            free(request->msgBuf);

            break;
        }
    }
}


/* This function initializes the DU sim stack app */
sim_return_val_et du_sim_stack_app_init()
{
    LOG_TRACE("Initialization of DU sim stack app \n");
    return SIM_SUCCESS;
}


/* This function creates and return stackApp for DU sim */
stack_app_t* create_du_sim_stack_app()
{
    stack_app_t* stackApp = NULL;

    /* Allocate stackApp for DU simulator */
    stackApp = allocate_new_protocol_stack_app();
    if (NULL == stackApp)
    {
        LOG_TRACE("Failed to allocate stack app for DU sim\n");
        return stackApp;
    }

    /* Initializes the function pointers of stack app */
    stackApp->init           = du_sim_stack_app_init;
    stackApp->stack_msg_hdlr = du_sim_stack_app_stack_msg_hdlr;
    stackApp->user_msg_hdlr  = du_sim_stack_app_user_msg_hdlr;

    return stackApp;
}

