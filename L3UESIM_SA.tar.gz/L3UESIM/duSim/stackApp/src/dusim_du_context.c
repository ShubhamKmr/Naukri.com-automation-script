/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the API for a new DU context and return to the 
 * *                     caller.
 * *
 * ***************************************************************************/

/* Standard includes */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Includes */
#include "lteTypes.h"
#include "sim_defs.h"
#include "typedefs.h"
#include "dusim_stack_app.h"
#include "du_sim_event.h"
#include "typedefs.h"
#include "proto_sim.h"
#include "globalContext.h"

/*******************************************************************************
 * Function Name  : allocate_dusim_du_context
 * Description    : This function allocates a new DU context and return to the caller.
 *
 * Inputs         : NA 
 * Outputs        : NA
 * Returns        : DU context
 ******************************************************************************/
dusim_du_context_t* allocate_dusim_du_context()
{
    dusim_du_context_t*  p_du_ctx = NULL;
    unsigned int          index     = 0;

    for (index = 1; index <= MAX_SUPPORTED_DU; index++)
    {
        p_du_ctx = &gDUSimContext.du_contexts[index];

        if (true != p_du_ctx->inUse)
        {
            memset(p_du_ctx, 0, sizeof(dusim_du_context_t));

            p_du_ctx->inUse  = true;
            p_du_ctx->du_id  = index;

            return p_du_ctx; 
        }
    }

    return p_du_ctx;
}

/*******************************************************************************
 * Function Name  : free_dusim_du_context
 * Description    : This function allocates free the pre-allocated DU contex.
 *
 * Inputs         : dusim_du_context_t*  p_du_ctx 
 * Outputs        : NA
 * Returns        : NA
 ******************************************************************************/

/* This function free the pre-allocated DU context */
void free_dusim_du_context(
        dusim_du_context_t*  p_du_ctx)
{
    if (NULL != p_du_ctx)
    {
        p_du_ctx->inUse = false;
    }
}


/*******************************************************************************
 * Function Name  : dusim_get_du_context
 * Description    : This function fetch and return DU context based on DU ID passed by caller.
 *
 * Inputs         : unsigned int          du_id 
 * Outputs        : NA
 * Returns        : DU context
 ******************************************************************************/

dusim_du_context_t* dusim_get_du_context(
        unsigned int          du_id)
{
    if (du_id >= MAX_SUPPORTED_DU)
    {
        return NULL;
    }

    return &gDUSimContext.du_contexts[du_id];
}

