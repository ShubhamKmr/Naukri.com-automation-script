#ifndef _DUSIM_STACK_APP_H_ 
#define _DUSIM_STACK_APP_H_

/* This file contains definitions of DU SIM stack app functions */
#include "proto_stack_app.h"

#define MAX_SUPPORTED_UE  3600 
#define MAX_SUPPORTED_DU  5


/* Structure defining the content of UE context */
typedef struct _dusim_ue_context_t
{
    struct 
    {
        unsigned cu_ue_f1ap_id_extn_present : 1;
        unsigned du_ue_f1ap_id_extn_present : 1;
    } m;

    /* Flag to indicate that this UE context is in use */
    bool                         inUse;

    /* UE identifier */
    unsigned int                 imsi;

    /* DU ID */
    unsigned char                du_id;

    /* DU UE F1AP ID allocated for this UE */
    unsigned short               cu_ue_f1ap_id;

    /* DU UE F1AP ID extension allocated for this UE */
    unsigned int                 cu_ue_f1ap_id_extn;

    /* DU UE F1AP ID allocated for this UE */
    unsigned short               du_ue_f1ap_id;

    /* DU UE F1AP ID extension allocated for this UE */
    unsigned int                 du_ue_f1ap_id_extn;

} dusim_ue_context_t;


/* Structure defining the content of DU context */
typedef struct
{
    /* Flag to indicate if DU context is in use or not */
    bool                         inUse;

    /* Unique DU Identifier */
    unsigned int                 du_id;

} dusim_du_context_t;


/* Structure defining the global content of DUSIM stack 
 * application */
typedef struct _dusim_global_context_t
{
    /* Array of UE contexts indexed by their IMSI */
    dusim_ue_context_t   ue_contexts[MAX_SUPPORTED_UE];

    /* Array of DU contexts indexed by their ID */
    dusim_du_context_t   du_contexts[MAX_SUPPORTED_DU];

} dusim_global_context_t;


/* Object of DUSIM global context */
dusim_global_context_t  gDUSimContext;



/*****************************************************************
 * PUBLIC FUNCTIONS
 ****************************************************************/

/* This function allocates a new DU context and return to the
 * caller */
dusim_du_context_t* allocate_dusim_du_context();


/* This function free the pre-allocated DU context */
void 
free_dusim_du_context(
        dusim_du_context_t* du_ctx);


/* This function fetch and return DU context based on DU ID 
 * passed by caller */
dusim_du_context_t* 
dusim_get_du_context(
        unsigned int du_id);


/* This function allocates a new UE context and return to caller */
dusim_ue_context_t* 
allocate_dusim_ue_context(
        unsigned int imsi);


/* This function fetch and return UE context based on DU UE F1AP ID 
 * and DU UE F1AP ID extension passed by caller */
dusim_ue_context_t* 
dusim_get_ue_context(
        unsigned short cu_ue_f1ap_id, 
        unsigned int   cu_ue_f1ap_id_extn);


/* This function creates and return stackApp for DU sim */
stack_app_t* create_du_sim_stack_app();


/* This function initializes the DU sim stack app */
sim_return_val_et du_sim_stack_app_init();

void dusim_forward_msg_to_cmd_interpreter(
        void*         apiBuf,
        unsigned int  apiLen);

unsigned short
rrc_get_word_from_header(
    unsigned char* p_header);

void handle_cu_config_update_req(
        unsigned int  du_id,
        void*         p_api,
        unsigned int  apiLen);


void handle_du_config_update_ack(
        unsigned int  du_id,
        void*         p_api,
        unsigned int  apiLen);

void handle_du_config_update_fail(
        unsigned int  du_id,
        void*         p_api,
        unsigned int  apiLen);

void handle_f1_reset_req_rom_peer(
        unsigned int  du_id,
        void*         p_api, 
        unsigned int  apiLen);

void dusim_handle_f1_context_mod_confirm(
                unsigned int  du_id,
                void*         p_api,
                unsigned int  apiLen);




#if 0
/* Send message to UE SIM stack */
void nradaptsim_forward_msg_to_stack(
        unsigned char* p_msg,
        U16  length);
#endif

#endif  // _DUSIM_STACK_APP_H_
