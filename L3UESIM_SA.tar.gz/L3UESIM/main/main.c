/* Standard includes */
#include <stdbool.h>

/* Project Includes */
#include "globalContext.h"
#include "uesim_init.h"


/* This function takes input from user and register simulators
 * based on that. */
sim_return_val_et register_simulators()
{
    unsigned char choice[2] = {0};

#if 0
    LOG_TRACE("Do you want to run UE simulator, enter (y/n):");
    scanf("%c", choice);
    if (choice[0] == 'y')
    {
        LOG_TRACE("Registering UE simulator with the framework \n");

        /* Register UE simulator with the framework */
        if (SIM_FAILURE == register_ue_sim())
        {
            LOG_TRACE("Failed to register UE SIM, returning\n");
            return SIM_FAILURE;
        }
    }

    LOG_TRACE("Do you want to run S1 simulator, enter (y/n):");
    scanf("%c", choice);
    if (choice[0] == 'y')
    {
        LOG_TRACE("Registering S1 simulator with the framework \n");

        /* Register S1 simulator with the framework */
        register_s1_sim();
    }

#endif
    LOG_TRACE("Do you want to run X2 simulator, enter (y/n):");
    scanf("%c", choice);
    if (choice[0] == 'y')
    {
        LOG_TRACE("Registering X2 simulator with the framework \n");

        /* Register UE simulator with the framework */
        if (SIM_FAILURE == register_x2_sim())
        {
            LOG_TRACE("Failed to register X2 SIM, returning\n");
            return SIM_FAILURE;
        }
    }

    return SIM_SUCCESS;
}


int main()
{
    unsigned short index    = 0;
    unsigned char  ipAddr[] = "127.0.0.1";
    unsigned int   port     = 7788;
    config_data_t  config;

    config.ui_port     = port;
    config.ui_protocol = TCP_PROTOCOL;
    memcpy(&config.ui_ipAddr, &ipAddr, MAX_IP_ADDRESS_LENGTH);

    //config.user_port   = 3457; 
    //memcpy(&config.user_ipAddr, "127.0.0.1", MAX_IP_ADDRESS_LENGTH);

    /* Initialize protocol simulator framework */
    if (SIM_SUCCESS != simulator_framework_init(&config))
    {
        LOG_TRACE("Failed to initialize protocol framework\n");
        return 0;
    }

    /* Register simulators requested by user */
    register_simulators();

    /* Ensure that user has atleast requested for one simulator. */
    if (0 == gContext.num_registered_sim)
    {
        LOG_TRACE("User has not requested for registration of any "
                  "simulator, exiting \n");
        return 0;
    }

    /* Start the loop for processing received messages */
    simulator_framework_input_loop();

    return 0;
}

