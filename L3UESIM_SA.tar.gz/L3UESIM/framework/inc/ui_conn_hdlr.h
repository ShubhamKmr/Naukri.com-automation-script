#ifndef __UI_CONN_HDLR_H__
#define __UI_CONN_HDLR_H__

#include <arpa/inet.h>
#include <netinet/in.h>

/* Project includes */
#include "typedefs.h"
//#include "globalContext.h"

#define UI_HDR_LEN   8 


/* Structure defining the content of message from user 
 * to protocol simulator. */
typedef struct
{
    /* Protocol identifier indicating the simulator which
     * message is supposed to process the message. */
    proto_id       proto_identifier;

    /* Padding for 4 byte alignment */
    unsigned char  padding[2];

    /* Message length */
    unsigned int   msgLen;

    /* Message buffer */
    unsigned char  msgBuf[1];

} user_data_req_t;


/* Structure defining the content of message from protocol
 * simulator to its user. */
typedef struct
{
    /* Protocol identifier indicating the simulator from
     * which message is forwarded to user. */
    proto_id       proto_identifier;

    /* Padding for 4 byte alignment */
    unsigned char  padding[2];

    /* Message length */
    unsigned int   msgLen;

    /* Message buffer */
    unsigned char  msgBuf[1];

} user_data_ind_t;


/* Structure defining the prototype of a UI connection 
 * handler. */
typedef struct
{
    /* Flag to indicate if UI connection handler is 
     * initialized or not. */
    bool                isInitialized;

    /* Socket FD */
    unsigned int        sockFd;

    /* Object of epoll user data */
    epoll_user_data_t   epoll_user_data;

    /* Function for sending a message to user */
    void (*send) (unsigned int, void* , unsigned int);

    /* Function for receiving a message from user */
    sim_return_val_et (*receive) (unsigned int);

} ui_conn_hdlr_t;


/* Release UI Connection handler context */
void release_ui_conn_hdlr(ui_conn_hdlr_t* ui_hdlr);


/* Create UI connection handler */
sim_return_val_et create_ui_conn_hdlr(int clientFd);


/* Handle new user connection request */
/*parallel ue changes start*/
void handle_new_user_connection_req(int clientFd,unsigned int simid);

typedef enum
{
    UI_UESIM_ID,
    
    UI_X2SIM_ID,
    
    UI_AMFSIM_ID,
   
    UI_MAIN_ID,
    
    UI_CELLM_ID,

    UI_MAXSIM_ID

} sim_id_et; 


/*timer_wheel_changes_start*/
#define SIM_TIMER_WHEEL_LEN     60

typedef int(*sim_timeout_hndlr)(void *data);

typedef void* sim_timer_id_t;

typedef struct _sim_timer_t
{
    bool reoccuring_timer;
    uint32_t time_out;
    uint32_t duration;
    void *data;
    sim_timeout_hndlr timeout_hndlr;
}sim_timer_t;

typedef struct _sim_tmr_wheel_node_t
{
    struct _sim_tmr_wheel_node_t *prev;
    struct _sim_tmr_wheel_node_t *next;
    sim_timer_t  timer;
}sim_tmr_wheel_node_t;

typedef struct _sim_tmr_wheel_ctxt_t
{
    sim_tmr_wheel_node_t *head;
    sim_tmr_wheel_node_t *tail;
}sim_tmr_wheel_ctxt_t;

typedef struct _sim_timer_ctxt_t
{
    uint8_t expiry_tick;
    struct timeval curr_time;
    sim_tmr_wheel_ctxt_t wheel[SIM_TIMER_WHEEL_LEN];
}sim_timer_ctxt_t;
sim_tmr_wheel_ctxt_t *listCreate(void);

sim_tmr_wheel_node_t *listAddNodeTail(
        sim_tmr_wheel_ctxt_t *list,
        sim_timer_t *timer);
typedef struct
{
    int sockFd;
    sim_timer_ctxt_t tmr_ctxt;
/*timer_wheel_changes_end*/
}sim_thread_ctxt_t;


/*parallel ue changes end*/

#endif  // __UI_CONN_HDLR_H__
