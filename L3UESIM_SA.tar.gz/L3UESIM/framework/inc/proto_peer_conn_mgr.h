#ifndef __PEER_CONN_MGR_H__
#define __PEER_CONN_MGR_H__

#include "typedefs.h"
#include "proto_peer_conn_hdlr.h"


/* Structure defining the prototype of a protocol peer 
 * connection Manager. */
typedef struct
{
    /* Flag to indicate if connection handler is initialized 
     * or not. */
    bool                isInitialized;

    /* Pointer to user specific data */
    void*               user_data;

    /* Initialization function of connection manager */
    sim_return_val_et (*init) (void*);

    /* Callback for performing activation of newly added
     * peer connection handlers */
    void (*activate) (void*);
    
    /* Function for handling new connection request from peer */
    void (*connect_req_hdlr) (void*);

    /* Function for handling message received from peer */
    void (*peer_msg_hdlr) (void*);

    /* Funciton for handling internal messages */
    void (*internal_msg_hdlr) (void*, unsigned int);

    /* Count of currently registered peer connection
     * handlers */
    unsigned char       num_peer_conn_hdlr;

    /* List of peer connection handlers registered with the
     * peer connection manager. */
    peer_conn_hdlr_t*   peer_conn_hdlr[MAX_PEER_CONN_PER_SIM];

} peer_conn_mgr_t;


/* Function for allocating new peer connection manager */
peer_conn_mgr_t*  allocate_new_peer_conn_mgr();

/* Function for registering new peer connection handler
 * with peer connection manager. */
sim_return_val_et  
register_peer_conn_hdlr_with_peer_conn_mgr(
        unsigned short    sim_id,
        peer_conn_hdlr_t* peer_conn_hdlr);

#endif  // __PEER_CONN_MGR_H__
