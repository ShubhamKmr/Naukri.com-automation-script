#ifndef __PROTO_STACK_H__
#define __PROTO_STACK_H__

#include "typedefs.h"

typedef struct
{
    /* Flag to indicate if stack is initialized or not */
    bool isInitialized;

    /* Pointer to the parent protocol simulator */
    void* proto_sim;

    /* Initialization function of stack */
    sim_return_val_et (*init) (void* pData);

    /* Function for handling message received from protocol peer */
    void (*peer_msg_hdlr) (void* , unsigned int);

    /* Function for handling message received from user */
    void (*user_msg_hdlr) (void* , unsigned int);

    /* This function reset the stack */
    void (*reset) (void);

} proto_stack_t;


/* This function will allocate and return new protocol stack to caller */
proto_stack_t* allocate_new_protocol_stack();


#endif  // __PROTO_STACK_H__
