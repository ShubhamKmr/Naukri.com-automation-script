#ifndef __CONN_HDLR_H__
#define __CONN_HDLR_H__

#include "typedefs.h"

/* Structure defining the prototype of a protocol peer 
 * connection handler. */
typedef struct
{
    /* Flag to indicate if connection handler is initialized 
     * or not. */
    bool                isInitialized;

    /* User data variable */
    void*               user_data;

    /* Function for opening a new connection */
    sim_return_val_et (*open) (void* user_data);

    /* Function for closing an existing connection */
    void (*close) (void* user_data);

    /* Function for triggering connect with peer
     * (applicable for initiator connection only) */
    void (*connect) (void* user_data);

    /* Function for sending message to protocol peer */
    void (*send) (void* user_data, void* msgBuf, unsigned short msgLen);

    /* Function for receiving message from protocol peer */
    void (*receive) (void* user_data);

} connection_handler_t;


/* This function allocate new connection handler and return 
 * it to caller */
connection_handler_t*  allocate_connection_handler();


#endif  // __CONN_HDLR_H__
