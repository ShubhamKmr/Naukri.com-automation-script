#ifndef __GLOBAL_CONTEXT_H__
#define __GLOBAL_CONTEXT_H__

#include "typedefs.h"
#include "ui_conn_hdlr.h"
#include "proto_peer_conn_hdlr.h"
#include "proto_sim.h"
#include "user_interface_mgr.h"

/* Structure defining the global configuation data used for running
 * the simulators */
typedef struct
{
    /* Object of user data to be provided while registering a socket
     * FD with epoll */
    epoll_user_data_t     epoll_data;

    /* Common epoll FD used for receiving messages from external
     * entities i.e. user and protocol peers */
    int                   epoll_recv_fd;

    /* Count of registered simulators */
    unsigned short        num_registered_sim;

    /* List of registered protocol simulators. Each of the registered 
     * protocol simulator will be having a unique protocol identifier
     * to identify that particular simulator. */
    proto_simulator_t*    proto_simulators[MAX_SUPPORTED_SIM];

    /* Object of User interface manager */
    user_interface_mgr_t  ui_mgr;

} global_context_t;


/* This function will initialize the simulator framework */
sim_return_val_et simulator_framework_init(
        config_data_t* config_data);


/* This function starts the external events processing loop */
void simulator_framework_input_loop();


/* This function is used for registering new proto simulator with 
 * simulator framework. It will allocate a unique identifier for 
 * proto simulator and return it to the caller. */
sim_return_val_et register_proto_simulator(
        proto_simulator_t* proto_sim);


/* This function is used for fetching a registered proto simulator 
 * corresponding to a simulator identifier. */
proto_simulator_t* get_proto_simulator(proto_id id);


/* This function is used for registering a user connection handler 
 * with the framework. */
/*parallel ue changes start*/
sim_return_val_et register_user_conn_handler(
        ui_conn_hdlr_t* ui_hdlr,unsigned int simid);
/*parallel ue changes end*/

/* This function is used for fetching pointer to UI handler 
 * stored at a particular index. */
ui_conn_hdlr_t* get_ui_handler(unsigned short index);


/* Register protocol peer connecton handler */
sim_return_val_et register_proto_peer_conn_hdlr(
        peer_conn_hdlr_t* peer_conn_hdlr);


/* This function fetches and returns protocol peer connection 
 * handler for a specific socket descriptor. */
peer_conn_hdlr_t* get_peer_conn_hdlr(unsigned int sockFd);


/* This function fetches and returns protocol peer connection
 * manager for a specific simulator ID. */
peer_conn_mgr_t* get_proto_peer_conn_mgr_by_sim_id(
        unsigned int sim_id);


/* This function fetches and returns protocol peer connection
 * manager for a specific simulator. */
peer_conn_mgr_t* get_proto_peer_conn_mgr(
        proto_simulator_t* proto_sim);


/* This function creates epoll FD used for input events notification */
sim_return_val_et create_epoll_fd_for_receive();


/* This function is used for adding a new socket FD for monitoring
 * by epoll receive FD. */
sim_return_val_et register_fd_for_receive_notification(
        unsigned int       sockFd,
        epoll_user_data_t* userData);


/* This function is used for adding a new sock Fd for monitoring
 * by epoll receive FD */
sim_return_val_et register_peer_conn_fd_for_receive_notifications(
        proto_id          sim_id,
        unsigned int      sockFd,
        conn_type_et      connType,
        void*             user_data);


/* Read configuration specific to simulator configuration */
sim_return_val_et read_configuration();


/* Define the object of global context */
global_context_t  gContext;


#endif  // __GLOBAL_CONTEXT_H__
