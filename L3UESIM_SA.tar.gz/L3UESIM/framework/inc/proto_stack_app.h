#ifndef __PROTO_STACK_APP_H__
#define __PROTO_STACK_APP_H__

#include "typedefs.h"

/* Structure defining the prototype of a protocol stack app */
typedef struct
{
    /* Flag to indicate if stack app is initialized or not */
    bool isInitialized;

    /* Pointer to the parent protocol simulator */
    void* proto_sim;

    /* Initialization function of stack app */
    sim_return_val_et (*init) (void* pData);

    /* Function for handling message received from UE sim stack */
    void (*stack_msg_hdlr) (void* msgBuf, unsigned int msgLen);
//    void (*stack_msg_hdlr) (void* msgBuf, unsigned int msgLen, unsigned short conn_id);

    void (*stack_msg_hdlr_1) (void* msgBuf, unsigned int msgLen, unsigned short conn_id);
    /* Function for handling message received from user */
    void (*user_msg_hdlr) (void* msgBuf);

    /* This function reset the stack app */
    void (*reset) (void);

} stack_app_t;


/* This function will allocate and return new protocol stack app 
 * to the caller. */
stack_app_t* allocate_new_protocol_stack_app();


#endif  // __PROTO_STACK_APP_H__
