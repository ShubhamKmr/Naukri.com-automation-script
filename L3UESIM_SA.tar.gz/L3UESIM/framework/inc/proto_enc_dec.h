#ifndef __PROTO_ENC_DEC_H__
#define __PROTO_ENC_DEC_H__

#include "typedefs.h"

/* Structure defining the encoder prototype for a protocol */
typedef struct 
{
    /* Flag to indicate if encoder is initialized or not */
    bool isInitialized;

    /* Pointer to the parent protocol simulator */
    void* proto_sim;

    /* Initialization function of encoder */
    sim_return_val_et (*init) (void* pData);

    /* Function exposed by encoder for encoding */
    unsigned char (*encode) (unsigned short  apiId,
                            /* spr 24900 changes start */
                             unsigned char*           apiBuf,
                           /* spr 24900 changes end */  
                             unsigned int    apiBufLen,
                             unsigned char** msgOutBuf,
                             /* spr 24900 changes start */
                             unsigned long int*  msgOutBufLen
                             /* spr 24900 changes end */ );

    /* This function reset the encoder */
    void (*reset) (void);

} encoder_t;


/* This function will allocate and return new protocol encoder 
 * to caller. */
encoder_t* allocate_new_proto_encoder();


/* Structure defining the decoder prototype for a protocol */
typedef struct 
{
    /* Flag to indicate if decoder is initialized or not */
    bool isInitialized;

    /* Pointer to the parent protocol simulator */
    void* proto_sim;

    /* Initialization function of decoder */
    sim_return_val_et (*init) (void* pData);

    /* Function exposed by decoder for decoding */
    unsigned char (*decode) (void*          msgIn,   
                             long           msgInLen, 
                             void**         msgOut, 
                             unsigned long* msgOutLen);

    /* This function reset the decoder */
    void (*reset) (void);

} decoder_t;


/* This function will allocate and return new protocol decoder 
 * to caller. */
decoder_t* allocate_new_proto_decoder();


#endif   // __PROTO_ENC_DEC_H__
