#ifndef __TYPEDEFS_H__
#define __TYPEDEFS_H__

#include <stdbool.h>

typedef unsigned short proto_id;

/* Enum defining the possible transport protocols */
typedef enum
{
    UDP_PROTOCOL  = 0,
    TCP_PROTOCOL  = 1,
    SCTP_PROTOCOL = 2
} transport_proto_et;


/* Enum defining the possible return values */
typedef enum
{
    SIM_SUCCESS,
    SIM_FAILURE
} sim_return_val_et;


typedef enum
{
    USER_CONN_LISTENER,
    USER_CONNECTION_HDLR,
    PEER_CONN_LISTENER,
    PEER_CONNECTION_HDLR,
    INTERNAL_CONN_HDLR
} conn_type_et;


/* User information to be stored while adding socket FD
 * to epoll FD and returned by epoll_wait whenever a new
 * notification is received. */
typedef struct
{
    unsigned int  socketFd;
    conn_type_et  connType;
    proto_id      simId;
    void*         ptr;
} epoll_user_data_t;


#define MAX_SUPPORTED_SIM       4
#define MAX_PEER_CONN_HDLR      6
#define MAX_IP_ADDRESS_LENGTH   16
#define MAX_USER_REQ_SIZE      0xffffffff 
#define MAX_USERS_SUPPORTED     1
#define MAX_PEER_CONN_PER_SIM   5

#define LOG_TRACE  printf


#endif  // __TYPEDEFS_H__
