#ifndef __PEER_CONN_HDLR_H__
#define __PEER_CONN_HDLR_H__

#include "typedefs.h"

/* Structure defining the prototype of a protocol peer 
 * connection handler. */
typedef struct
{
    /* Flag to indicate if connection handler is initialized 
     * or not. */
    bool                isInitialized;

    /* Socket FD */
    unsigned int        sockFd;

    /* Pointer to the parent protocol simulator */
    void*               proto_sim;

    /* User data variable */
    void*               user_data;

    /* Object of epoll user data */
    epoll_user_data_t   epoll_user_data;

    /* Initialization function of connection handler */
    sim_return_val_et (*init) (void* user_data);

    /* Function for opening a new connection */
    int (*open) (void* user_data);

    /* Function for initiating connection with peer */
    sim_return_val_et (*connect) (void* user_data);

    /* Function for closing an existing connection */
    void (*close) (void* user_data);

    /* Function for sending message to protocol peer */
    void (*send) (void* user_data, void* msgBuf, unsigned short msgLen);

    /* Function for receiving message from protocol peer */
    unsigned int (*receive) (void* user_data, void** msg);

    /* This function reset the connection handler */
    void (*reset) (void);

} peer_conn_hdlr_t;


/* Pointer to protocol peer connection handler */
peer_conn_hdlr_t*  allocate_new_peer_conn_hdlr();


#endif  // __PEER_CONN_HDLR_H__
