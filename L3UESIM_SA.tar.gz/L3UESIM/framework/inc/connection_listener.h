#ifndef __CONNECTION_LISTENER_H__
#define __CONNECTION_LISTENER_H__

#include <stdbool.h>
#include "typedefs.h"

/* Structure defining the prototype of a connection 
 * listener */ 
typedef struct
{
    /* Flag to indicate if connection listener is initialized */
    bool  isInitialized;

    /* User Data */
    void* user_data;

    /* Callback for starting the connection listener */
    int (*open) (void*);

    /* Callback for accepting new connection */
    int (*accept) (void*);

    /* Callback for start listening for new connection requests */
    sim_return_val_et (*listen) (void*);

    /* Callback for closing the connection listener */
    void (*close) (void*);

} connection_listener_t;


/* This function is used for allocating a new connection 
 * Listener. */
connection_listener_t* allocate_connection_listener();


#endif  // __CONNECTION_LISTENER_H__
