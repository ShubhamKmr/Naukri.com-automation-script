#ifndef __UI_MGR_H__
#define __UI_MGR_H__

#include <arpa/inet.h>
#include <netinet/in.h>

/* Project includes */
#include "typedefs.h"
//#include "globalContext.h"


/* Structure defining the configuration data used for operation 
 * by simulator framework. */
typedef struct 
{
    /* Listen port used for communicating with user */
    unsigned int        ui_port;

    /* IP address used for communicating with user */
    char                ui_ipAddr[MAX_IP_ADDRESS_LENGTH];

    /* Transport protocol used for communicating with user */
    transport_proto_et  ui_protocol;

} config_data_t;


typedef struct
{
    /* Socket FD used for listening new connection requests  
     * from users. */
    int                serverFd;

    /* Object of epoll user data used for UI Server */
    epoll_user_data_t  server_epoll_user_data;

    /* List of registered UI handlers */
    /*parallel ue changes start*/
    ui_conn_hdlr_t*    user_conn_hdlr[UI_MAXSIM_ID];
    /*parallel ue changes end*/
    /* Configuration data used by framework */
    config_data_t      config_data;

} user_interface_mgr_t;


    /*parallel ue changes start*/
typedef struct {

    unsigned char selfIpAddr[20];

    unsigned int selfPort;

    unsigned int protocol;

    unsigned char simIpAddr[20];

    unsigned int simPort ;

}sim_port_and_ip_config_t;

    /*parallel ue changes end*/
#endif  // __UI_MGR_H__

