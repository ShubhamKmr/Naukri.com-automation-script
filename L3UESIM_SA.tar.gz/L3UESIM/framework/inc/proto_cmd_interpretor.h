#ifndef __PROTO_CMD_INTERPRETER_H__
#define __PROTO_CMD_INTERPRETER_H__

#include <stdbool.h>
#include "typedefs.h"

/* Structure defining the prototype of a protocol command  
 * interpreter. */
typedef struct
{
    /* Flag to indicate if command interpreter is initialized 
     * or not. */
    bool isInitialized;

    /* Pointer to the parent protocol simulator */
    void* proto_sim;

    /* Initialization function of command interpreter */
    sim_return_val_et (*init) (void* pData);

    /* This function processes the command received from user */
    void (*user_cmd_hdlr) (void* cmd, unsigned int length);

    /* This function processes the message received from stack app */
    void (*stack_app_msg_hdlr) (void* msgBuf, unsigned int msgLen);

    /* This function resets the command interpreter */
    void (*reset) (void);

} cmd_interpreter_t;


/* This function is used for allocating a new protocol command
 * interpreter */
cmd_interpreter_t* allocate_command_interpreter();


#endif  // __PROTO_CMD_INTERPRETER_H__
