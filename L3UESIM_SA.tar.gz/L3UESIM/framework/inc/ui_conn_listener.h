
/* Create UI Connection Listener */
sim_return_val_et create_ui_connection_listener(
            config_data_t* config_data);


/* This function accept new connection from users */
void ui_connection_listener_accept();
