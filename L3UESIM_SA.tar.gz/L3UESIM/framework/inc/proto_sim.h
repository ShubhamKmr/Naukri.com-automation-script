#ifndef __PROTO_SIM_H__
#define __PROTO_SIM_H__

#include "typedefs.h"
#include "proto_cmd_interpretor.h"
#include "proto_peer_conn_hdlr.h"
#include "proto_enc_dec.h"
#include "proto_stack_app.h"
#include "proto_stack.h"
#include "proto_peer_conn_mgr.h"


//#define MAX_PEER_CONN_PER_SIM  2

/* Structure defining the prototype of a proto Simulator */
typedef struct
{
    /* Indicates if protocol simulator is initialized or not */
    bool                 initialized;

    /* Unique Protocol Identifier */
    proto_id             identifier;

    /* Pointer to protocol command interpreter */
    cmd_interpreter_t*   cmd_interpreter;
    
    /* Pointer to protocol stack app of the simulator */
    stack_app_t*         stackApp;

    /* Pointer to protocol stack of the simulator */
    proto_stack_t*       stack;

    /* Pointer to protocol message encoder */
    encoder_t*           encoder;

    /* Pointer to protocol message decoder */
    decoder_t*           decoder;

    /* Pointer to protocol peer connection manager */
    peer_conn_mgr_t*     conn_mgr;

    /* Indicates the count of registered peer connection
     * handlers of this simulator. */
    unsigned char        num_peer_conn_hdlr;

    /* Pointer to protocol peer connection handler */
    peer_conn_hdlr_t*    peer_conn_hdlr[MAX_PEER_CONN_PER_SIM];

    /* Initialization function of protocol simulator */
    sim_return_val_et  (*init) (void*);

} proto_simulator_t;


/* This function is used for allocating a new protocol simulator. */
proto_simulator_t* allocate_new_proto_simulator();


/* This function is used for initializing the protocol simulator. */
//bool init_proto_simulator(proto_simulator_t* proto_sim);


/* This function is used for fetching command interpreter of the
 * protocol simulator. */
cmd_interpreter_t* get_cmd_interpreter(proto_simulator_t* proto_sim);


/* This function is used for fetching stack app of the protocol
 * simulator. */
stack_app_t* get_proto_stack_app(proto_simulator_t* proto_sim);


/* This function is used for fetching stack of the protocol 
 * simulator. */
proto_stack_t* get_proto_stack(proto_simulator_t* proto_sim);


/* This function is used for fetching encoder of the protocol 
 * simulator. */
encoder_t* get_proto_encoder(proto_simulator_t* proto_sim);


/* This function is used for fetching decoder of the protocol 
 * simulator. */
decoder_t* get_proto_decoder(proto_simulator_t* proto_sim);


/* This function is used for fetching peer connection handler 
 * of the protocol simulator. */
peer_conn_hdlr_t* get_proto_peer_conn_hdlr(
        proto_simulator_t* proto_sim,
        unsigned int sockFd);

/* This function fetch and return peer connection handler of
 * a simulator stored at index passed by caller. */
peer_conn_hdlr_t* get_proto_peer_conn_hdlr_by_index(
        proto_simulator_t* proto_sim,
        unsigned short     index);

/* This function fetches and returns protocol peer connection
 * manager of the simulator. */
peer_conn_mgr_t* get_proto_peer_conn_mgr(
        proto_simulator_t* proto_sim);


#endif   // __PROTO_SIM_H__ 
