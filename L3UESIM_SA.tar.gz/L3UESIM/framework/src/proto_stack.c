/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "proto_stack.h"

/* This function will allocate and return new protocol 
 * stack to caller. */
proto_stack_t* allocate_new_protocol_stack()
{
    proto_stack_t* stack = NULL;

    stack = (proto_stack_t*)malloc(sizeof(proto_stack_t));
    return stack;
}

