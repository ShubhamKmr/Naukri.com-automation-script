/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

/* Project specific includes */
#include "globalContext.h"
#include "proto_peer_conn_hdlr.h"
#include "proto_sim.h"
#include "ui_conn_listener.h"
#include "connection_handler.h"

#include "sim_nas_new.h"

#define MAX_EVENTS   1

/* This function is used for adding a new socket FD for monitoring
 * by epoll receive FD. */
sim_return_val_et register_fd_for_receive_notification(
        unsigned int       sockFd,
        epoll_user_data_t* user_data)
{
    struct epoll_event  ev;

    /* Populate epoll_event structure */
    ev.events   = EPOLLIN | EPOLLERR | EPOLLET;
    ev.data.ptr = user_data;

    /* Add the socket FD to epoll FD */
    if (epoll_ctl(gContext.epoll_recv_fd, EPOLL_CTL_ADD, sockFd, &ev) == -1)
    {
        LOG_TRACE("Failed to add socket FD: [%d] to epoll FD for receive "
                  "notification\n", sockFd);
        return SIM_FAILURE;
    }

    LOG_TRACE("Successfully added socket FD: [%d] with epoll FD for "
              "receive notifications \n", sockFd);
    return SIM_SUCCESS;
}


/* This function is used for adding a new sock Fd for monitoring
 * by epoll receive FD */
sim_return_val_et 
register_peer_conn_fd_for_receive_notifications(
        proto_id          sim_id,
        unsigned int      sockFd,
        conn_type_et      connType,
        void*             user_data)
{
    struct epoll_event  ev;
    epoll_user_data_t*  epoll_data = NULL;

    epoll_data = malloc(sizeof(epoll_user_data_t));
    if (NULL == epoll_data)
    {
        LOG_TRACE("Failed to allocate memory for epoll user data \n");
        return SIM_FAILURE;
    }

    epoll_data->socketFd  = sockFd;
    epoll_data->connType  = connType;
    epoll_data->simId     = sim_id;
    epoll_data->ptr       = user_data;

    /* Populate epoll_event structure */
    ev.events   = EPOLLIN | EPOLLERR | EPOLLET;
    ev.data.ptr = epoll_data;

    /* Add the socket FD to epoll FD */
    if (epoll_ctl(gContext.epoll_recv_fd, EPOLL_CTL_ADD, sockFd, &ev) == -1)
    {
        LOG_TRACE("Failed to add socket FD: [%d] to epoll FD for receive "
                  "notification\n", sockFd);
        return SIM_FAILURE;
    }

    LOG_TRACE("Successfully added socket FD: [%d] with epoll FD for "
              "receive notifications \n", sockFd);
    return SIM_SUCCESS;
}


/* This functon is used for de-registering a user connection handler */
sim_return_val_et deregister_user_conn_handler(
        ui_conn_hdlr_t* ui_hdlr)
{
    /* Ensure that received pointer is valid */
    if (NULL == ui_hdlr)
    {
        LOG_TRACE("Received pointer is NULL\n");
        return SIM_FAILURE;
    }

    /* Close user connection */
    close(ui_hdlr->sockFd);

    /* Release UI connection handler */
    release_ui_conn_hdlr(ui_hdlr);

    /* Decrement the count of registered user connection handlers */
    /*parallel ue changes start*/
    //gContext.ui_mgr.num_user_conn_hdlr -= 1;
    /*parallel ue changes end*/
    LOG_TRACE("User connection handler successfully de-registered "
              "for socket FD: [%d]\n", ui_hdlr->sockFd);

    return SIM_SUCCESS;
}


/* This function is used for registering a user connection handler 
 * with the framework. */
sim_return_val_et register_user_conn_handler(ui_conn_hdlr_t* ui_hdlr,unsigned int simid)
{
        if (gContext.ui_mgr.user_conn_hdlr[simid] && (gContext.ui_mgr.user_conn_hdlr[simid]->sockFd == ui_hdlr->sockFd))
        {
            LOG_TRACE("User connection handler already exists for "
                      "socket FD: [%d]", ui_hdlr->sockFd);

            return SIM_FAILURE;
        }

    /* Add received user connection handler to list */
    /* TODO: Need to search for the free index instead of adding it to 
     * the last index. */
    gContext.ui_mgr.user_conn_hdlr[simid] = ui_hdlr;

    /* Register sock FD of this user connection handler for 
     * receive notifications */
    register_fd_for_receive_notification(
                                ui_hdlr->sockFd,
                                &ui_hdlr->epoll_user_data);

    LOG_TRACE("User connection handler successfully registered for socket FD: [%d] and simId [%d]\n", ui_hdlr->sockFd,simid);

    return SIM_SUCCESS;
}

#if 0
/* Register protocol peer connecton handler */
sim_return_val_et register_proto_peer_conn_hdlr(
                         peer_conn_hdlr_t* peer_conn_hdlr)
{
    unsigned short index = 0;

    /* Ensure that received pointer is valid */
    if (NULL == peer_conn_hdlr)
    {
        LOG_TRACE("Received pointer is NULL\n");
        return SIM_FAILURE;
    }

    /* Ensure that max allowed peer connection handlers are not already 
     * registered */
    if (gContext.num_registered_peer_conn_hdlr >= MAX_PEER_CONN_HDLR)
    {
        LOG_TRACE("Max allowed peer connection handlers are already "
                  "registered: %d\n", gContext.num_registered_peer_conn_hdlr);
        return SIM_FAILURE;
    }

    /* Ensure that peer connection handler for this socket FD doesn't 
     * already exists in the list of registered peer connection handlers */
    for (index = 0; index < gContext.num_registered_peer_conn_hdlr; index++)
    {
        if (gContext.proto_conn_hdlr[index]->sockFd == peer_conn_hdlr->sockFd)
        {
            LOG_TRACE("Protocol Peer connection handler already exists for "
                      "socket FD: [%d]", peer_conn_hdlr->sockFd);
            return SIM_FAILURE;
        }
    }

    /* Add received peer connection handler to list */
    gContext.proto_conn_hdlr[gContext.num_registered_peer_conn_hdlr] 
                = peer_conn_hdlr;

    /* Increment the count of registered peer connection handlers */
    gContext.num_registered_peer_conn_hdlr += 1;

    /* Register sock FD of this connection handler for receive notifications */
    //register_fd_for_receive_notification(peer_conn_hdlr->sockFd);

    LOG_TRACE("Protocol peer connection handler successfully registered "
              "for socket FD: [%d]\n", peer_conn_hdlr->sockFd);

    return SIM_SUCCESS;
}

#endif
/* This function is used for registering new proto simulator with 
 * simulator framework. */
sim_return_val_et register_proto_simulator(
        proto_simulator_t* proto_sim)
{
    unsigned short index = 0;

    /* Ensure that received pointer is valid */
    if (NULL == proto_sim)
    {
        LOG_TRACE("Received pointer is NULL\n");
        return SIM_FAILURE;
    }

    /* Ensure that max allowed simulators are not already registered */
    if (gContext.num_registered_sim >= MAX_SUPPORTED_SIM)
    {
        LOG_TRACE("Max allowed simulators are already registered: %d\n",
                  gContext.num_registered_sim);
        return SIM_FAILURE;
    }

    /* Ensure that simulator for this protocol doesn't already exists
     * in the list of protocol simulators. */
    for (index = 0; index < gContext.num_registered_sim; index++)
    {
        if (gContext.proto_simulators[index]->identifier 
                              == proto_sim->identifier)
        {
            LOG_TRACE("Simulator already registered for protocol ID: %d\n",
                      proto_sim->identifier);
            return SIM_FAILURE;
        }
    }

    /* Add received protocol simulator to list */
    gContext.proto_simulators[gContext.num_registered_sim] = proto_sim;

    /* Increase the count of registered protocol siumlators */
    gContext.num_registered_sim += 1;

    LOG_TRACE("Simulator with protocol ID: [%d] successfully registered\n", 
              proto_sim->identifier);

    return SIM_SUCCESS;
}


/* This function is used for fetching a registered proto simulator 
 * corresponding to a protocol identifier. */
proto_simulator_t* get_proto_simulator(proto_id id)
{
    unsigned short index = 0;

    /* Traverse through the list of registered protocol simulators
     * and check if the protocol identifier of the simulator matches 
     * the one passed by caller. */
    for (index = 0; index < MAX_SUPPORTED_SIM; index++)
    {
        if ((NULL != gContext.proto_simulators[index]) &&
            (gContext.proto_simulators[index]->identifier == id))
        {
            return gContext.proto_simulators[index];
        }
    }

    LOG_TRACE("Protocol simulator with protocol ID: [%d] doesn't exists", id);

    return NULL;
}

#if 0
/* This function fetches and returns protocol peer connection 
 * handler for a specific socket descriptor. */
peer_conn_hdlr_t* get_peer_conn_hdlr(unsigned int sockFd)
{
    unsigned short index = 0;

    /* Traverse through the list of registered protocol peer connection
     * handlers and check if the sockFd of the handler matches the one
     * passed by caller. */
    for (index = 0; index < MAX_PEER_CONN_HDLR; index++)
    {
        if (gContext.proto_conn_hdlr[index]->sockFd == sockFd)
        {
            return gContext.proto_conn_hdlr[index];
        }
    }

    LOG_TRACE("Protocol peer connection handler for socket FD :[%d] "
              "doesn't exists", sockFd);

    return NULL;
}
#endif

/* This function creates epoll FD used for input events notification */
sim_return_val_et create_epoll_fd_for_receive()
{
    /* Create epoll FD */
    gContext.epoll_recv_fd = epoll_create(100);
    if (gContext.epoll_recv_fd < 0)
    {
        LOG_TRACE("Failed to create epoll FD for receive notification\n");
        return SIM_FAILURE;
    }

    LOG_TRACE("Successfully created epoll FD for receive notifications: [%d]",
              gContext.epoll_recv_fd);

    return SIM_SUCCESS;
}


/* This function will initialize the simulator framework */
sim_return_val_et simulator_framework_init(
        config_data_t* config_data)
{
    /* Initialize the number of registered simulators */
    gContext.num_registered_sim = 0;

    /* Create epoll FD for receive notifications */
    if (SIM_SUCCESS != create_epoll_fd_for_receive())
    {
        return SIM_FAILURE;
    }

    LOG_TRACE("Creating UI Server \n");

    /* Create UI Server */
    if (SIM_SUCCESS != create_ui_connection_listener(config_data))
    {
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}


/* This function receive and process message received 
 * from user. */
void receive_and_process_user_message(
        unsigned short connIndex)
{
    ui_conn_hdlr_t*  ui_handler = NULL;

    ui_handler = get_ui_handler(connIndex);
    if (NULL == ui_handler)
    {
        LOG_TRACE("   ---------------- UI handler is not registered for SIM %d-----------\n", connIndex);
        return;
    }

    /* Invoke the UI handler callback registered for 
     * receiving messages from user. */
    if (SIM_FAILURE == ui_handler->receive(ui_handler->sockFd))
    {
        LOG_TRACE("Receive failure, closing user connection, FD: %d\n",
                  ui_handler->sockFd);

        /* De-register user connection handler */
        deregister_user_conn_handler(ui_handler);

        return;
    }
}

/* This function handles new connection request received 
 * from peer */
void process_new_connect_req_from_peer(
            epoll_user_data_t* epoll_data)
{
    proto_simulator_t* proto_sim          = NULL;
    peer_conn_mgr_t*   conn_mgr           = NULL;

    /* Fetch protocol simulator based on SIM ID */
    proto_sim = get_proto_simulator(epoll_data->simId);
    if (NULL == proto_sim)
    {
        LOG_TRACE("No simulator registered for SIM ID: %d\n", 
                   epoll_data->simId);
        return;
    }

    /* Fetch peer connection manager of the simulator */
    conn_mgr = get_proto_peer_conn_mgr(proto_sim);

    if (NULL == conn_mgr)
    {
        LOG_TRACE("No peer connection manager exists for "
                  "simulator ID: %d\n", epoll_data->simId);
        return;
    }

    /* Invoke peer message handler of the peer connection manager */
    conn_mgr->connect_req_hdlr(epoll_data->ptr);
}


/* This function receive and process message received 
 * from peer. */
void receive_and_process_peer_message(
            epoll_user_data_t* epoll_data)
{
    proto_simulator_t* proto_sim          = NULL;
    peer_conn_mgr_t*   conn_mgr           = NULL;

    /* Fetch protocol simulator based on SIM ID */
    proto_sim = get_proto_simulator(epoll_data->simId);
    if (NULL == proto_sim)
    {
        LOG_TRACE("No simulator registered for SIM ID: %d\n", 
                   epoll_data->simId);
        return;
    }

    /* Fetch peer connection manager of the simulator */
    conn_mgr = get_proto_peer_conn_mgr(proto_sim);

    if (NULL == conn_mgr)
    {
        LOG_TRACE("No peer connection manager exists for "
                  "simulator ID: %d\n", epoll_data->simId);
        return;
    }

    LOG_TRACE("Message received from peer, socket FD: %d\n", 
              epoll_data->socketFd);

    /* Invoke peer message handler of the peer connection manager */
    conn_mgr->peer_msg_hdlr(epoll_data->ptr);
}


/* Handle message received from internal module of simulator */
void receive_and_process_internal_message(
            epoll_user_data_t* epoll_data)
{
    connection_handler_t*  conn_hdlr = NULL;

    LOG_TRACE("Message received from internal module for SIM ID: %d\n",
              epoll_data->simId);

    /* Fetch pointer to connection handler */
    conn_hdlr = (connection_handler_t*)epoll_data->ptr;

    /* Invoke callback for receiving API received from 
     * other module */
    conn_hdlr->receive(conn_hdlr->user_data);
}


/* This function will read incoming message and dispatch it to a 
 * protocol simulator for processing. */
void receive_and_dispatch_event(
        epoll_user_data_t* epoll_data)
{
    struct epoll_event ev;
    int                notifiedFd      = 0;

    /* Ensure that received pointer is valid */
    if (NULL == epoll_data)
    {
        LOG_TRACE("Received NULL pointer \n");
        return;
    }

    /* Fetch notified FD */
    notifiedFd = epoll_data->socketFd;

    //LOG_TRACE("receive_and_dispatch_event: %d\n", notifiedFd);

    /* Check if message is received for user connection
     * listener */
    if (USER_CONN_LISTENER == epoll_data->connType)
    {
        /* Handle new connection request */
        ui_connection_listener_accept();
        return;
    }
    
    /* Check if message is received for user connection 
     * handler */
    else if (USER_CONNECTION_HDLR == epoll_data->connType)
    {
        /* Handle message received from user */
        receive_and_process_user_message(
                            epoll_data->simId);
    }

    /* Check if message is received for peer connection 
     * handler */
    else if (PEER_CONN_LISTENER == epoll_data->connType)
    {
        /* Handle connect request received from peer */
        process_new_connect_req_from_peer(epoll_data);
    }

    /* Check if message is received for peer connection 
     * listener */
    else if (PEER_CONNECTION_HDLR == epoll_data->connType)
    {
        /* Handle message received from peer */
        receive_and_process_peer_message(epoll_data);
    }

    /* Check if message is receive from one module of a simulator
     * for another module */
    else if (INTERNAL_CONN_HDLR == epoll_data->connType)
    {
        /* Handle message received from internal module of simulator */
        receive_and_process_internal_message(epoll_data);
    }

    else
    {
        LOG_TRACE("Message received on unknown socket FD, discarded !!! \n");
        return;
    }

    /* TODO : Need to ensure that we need to re-arm FD only if 
     * user asked us to do. */

    /* Re-arm the FD for receive notifications */
    ev.events   = EPOLLIN | EPOLLERR | EPOLLET;
    ev.data.ptr = epoll_data;

    if (epoll_ctl(gContext.epoll_recv_fd, EPOLL_CTL_MOD, notifiedFd, &ev) == -1)
    {
        LOG_TRACE("Failed to re-arm client FD: %d", notifiedFd);
    }
}


/* This function will activate any connection handlers
 * pending for activation. */
void activate_pending_conn_handlers()
{
    proto_simulator_t* proto_sim          = NULL;
    peer_conn_mgr_t*   conn_mgr           = NULL;
    unsigned short     index              = 0;

    /* Traverse through the list of all registered simulators and
     * initialize them. */
    for (index = 0; index < gContext.num_registered_sim; index++)
    {
        /* Fetch pointer to protocol simulator */
        proto_sim = (proto_simulator_t*)gContext.proto_simulators[index];

        /* Fetch pointer to connection manager of simulator */
        conn_mgr = get_proto_peer_conn_mgr(proto_sim);

        /* Activate connection manager of simulator */
        if (NULL != conn_mgr)
        {
            conn_mgr->activate(conn_mgr->user_data);
        }
    }
}


/* This function will initialize all the registered simulators */
sim_return_val_et initialize_registered_simulators()
{
    proto_simulator_t* proto_sim          = NULL;
    peer_conn_mgr_t*   conn_mgr           = NULL;
    unsigned short     index              = 0;

    /* Traverse through the list of all registered simulators and
     * initialize them. */
    for (index = 0; index < gContext.num_registered_sim; index++)
    {
        LOG_TRACE("Initializing simulators\n");

        /* Fetch pointer to protocol simulator */
        proto_sim = (proto_simulator_t*)gContext.proto_simulators[index];

        /* Initialize protocol simulator */
        proto_sim->init(proto_sim);

        /* Fetch pointer to connection manager of simulator */
        conn_mgr = get_proto_peer_conn_mgr(proto_sim);

        /* Activate connection manager of simulator */
        if (NULL != conn_mgr)
        {
            conn_mgr->activate(conn_mgr->user_data);
        }
    }

    return SIM_SUCCESS;
}


/* This function starts the external events processing loop */
void simulator_framework_input_loop()
{
    struct epoll_event events[MAX_EVENTS] = {{0}};
    epoll_user_data_t* epoll_user_data    = NULL;

    LOG_TRACE("Starting simulator framework input loop\n");

    /* Initialize all the registered simulators */
    if (SIM_SUCCESS != initialize_registered_simulators())
    {
        LOG_TRACE("Failed to initialize registered simulators \n");
        return;
    }

    /* Wait for events from external entities and process them */
    while (1)
    {
        /* Activate pending connection handlers of all registered
         * simulators. */
        activate_pending_conn_handlers();

        /* Wait on event descriptor */
        if (epoll_wait(gContext.epoll_recv_fd, events, 1, 1000) <= 0)
        {
            continue;
        }

        /* Fetch pointer to epoll user data */
        epoll_user_data = (epoll_user_data_t*)events[0].data.ptr;

        /* Read received message and dispatch it to a simulator */
        receive_and_dispatch_event(epoll_user_data);
    }
}


/* This function is used for fetching pointer to UI handler */
ui_conn_hdlr_t* get_ui_handler(unsigned short index)
{
    return gContext.ui_mgr.user_conn_hdlr[index];
}

/* This function fetches and returns protocol peer connection
 * manager of the simulator. */
peer_conn_mgr_t* get_proto_peer_conn_mgr(
        proto_simulator_t* proto_sim)
{
    if (NULL != proto_sim)
    {
        return proto_sim->conn_mgr;
    }

    return NULL;
}


