/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

/* Project Includes */
#include "globalContext.h"

/*parallel ue changes start*/
extern sim_port_and_ip_config_t * simobj[UI_MAXSIM_ID];
//doubt
int search_simid(struct sockaddr_in *client)
{
    unsigned int SimPort = ntohs(client->sin_port);
    int index = 0;
    for (index = 0;index < UI_MAXSIM_ID ;index++)
    {
        if (simobj[index] && simobj[index]->selfPort == SimPort)
        {
            break;
        }
    }
  return index;
}
/*parallel ue changes end*/
/* This function accept new connection from users */
void ui_connection_listener_accept()
{
    struct sockaddr_in client;
    int                clientFd = 0;
    unsigned int       namelen  = 0; 

    namelen = sizeof(client);

    if ((clientFd = accept(gContext.ui_mgr.serverFd, 
                           (struct sockaddr *)&client, 
                           &namelen)) < 0)
    {
        LOG_TRACE("Failed to accept new connection attempt, errno:%d \n", 
                  errno);

        return;
    }

    int simid = search_simid(&client);
    if (simid == UI_MAXSIM_ID )
    {
        printf("simid not found");
        return;
    }
    LOG_TRACE("New connection from user, sock FD: %d, UI SIM %d\n", clientFd, simid);
    /* Handle new connection request received from user */
    /*parallel ue changes start*/
    handle_new_user_connection_req(clientFd,simid);
    /*parallel ue changes end*/
}


/* Function for creating server for receiving messages from user */
sim_return_val_et ui_server_open()
{
    int                sockFd     = -1;
    struct sockaddr_in serverAddr = {0};
    config_data_t*     config_data = NULL;

    /* Fetch global configuration data */
    config_data = &gContext.ui_mgr.config_data;
    if (NULL == config_data)
    {
        LOG_TRACE("Configuration data not present\n");
        return SIM_FAILURE;
    }

    /* Populate server address parameters */ 
    serverAddr.sin_family      = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(config_data->ui_ipAddr);
    serverAddr.sin_port        = htons(config_data->ui_port);

    /* Create a server socket */
    sockFd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockFd < 0)
    {
        LOG_TRACE("Failed to create socket for UI server [errno:%d]\n", 
                  errno);

        return SIM_FAILURE;
    }

    LOG_TRACE("Server created with FD: %d \n", sockFd);

    /* Set SO_REUSEADDR option on socket */
    {
        const int optVal = 1;

        if (setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, 
                       &optVal, sizeof(int)) < 0)
        {
            LOG_TRACE("TCP: Connection socket property SO_REUSEADDR not set [errno:%d]\n", errno);
        }

        LOG_TRACE("TCP: Connection socket property SO_REUSEADDR is set\n");
    }
    /* Bind the UI server socket FD with address */
    if (bind(sockFd, (struct sockaddr *)&serverAddr, 
                             sizeof(struct sockaddr_in)) < 0) 
    {
        LOG_TRACE("UI Server socket bind failure, errno: %d\n", errno);

        /* Unable to bind thus deleting created socket */
        close(sockFd);

        return SIM_FAILURE;
    }

    LOG_TRACE("Bind successfull for UI Server sockt FD %d \n", sockFd);

    /* Create socket listen backlog queue */
    if (listen(sockFd, 10) < 0)
    {
        LOG_TRACE("Failed to create listen queue for UI Server socket \n");

        close(sockFd);

        return SIM_FAILURE;
    }

    /* Store server socket FD in global context */
    gContext.ui_mgr.serverFd = sockFd;
 
    /* Populate epoll data to be used with this handler */
    gContext.ui_mgr.server_epoll_user_data.socketFd  = sockFd;
    gContext.ui_mgr.server_epoll_user_data.connType  = USER_CONN_LISTENER;
    gContext.ui_mgr.server_epoll_user_data.simId     = 0;

    /* Register socket FD with epoll for receive notification */ 
    if (SIM_SUCCESS != register_fd_for_receive_notification(
                             sockFd,
                             &gContext.ui_mgr.server_epoll_user_data))
    {
        LOG_TRACE("Failed to register UI server socket FD with epoll FD\n");
        return SIM_FAILURE;
    }

    return SIM_SUCCESS;
}


/* Create UI Server */
sim_return_val_et create_ui_connection_listener(
            config_data_t* config_data)
{
    /* Store configuration data in global context */
    memcpy(&gContext.ui_mgr.config_data, config_data, sizeof(config_data_t));

    /* Create UI server for accepting new connections from users */
    if (ui_server_open() < 0)
    {
        LOG_TRACE("Failed to create UI server \n");
        return SIM_FAILURE;
    }

    LOG_TRACE("Successfully created UI server, waiting "
              "for new user connections ... \n");

    return SIM_SUCCESS;
}
