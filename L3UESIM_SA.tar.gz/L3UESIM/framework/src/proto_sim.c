/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "typedefs.h"
#include "proto_sim.h"

/* This function is used for allocating a new protocol simulator. */
proto_simulator_t* allocate_new_proto_simulator()
{
    proto_simulator_t* proto_sim = NULL;

    proto_sim = (proto_simulator_t*)malloc(sizeof(proto_simulator_t));
    return proto_sim;
}


/* This function is used for fetching command interpreter of the 
 * protocol simulator. */
cmd_interpreter_t* get_cmd_interpreter(proto_simulator_t* proto_sim)
{
    cmd_interpreter_t*  cmd_interpreter = NULL;

    if (NULL != proto_sim)
    {
        cmd_interpreter = proto_sim->cmd_interpreter;
    }

    return cmd_interpreter;
}


/* This function is used for fetching stack app of the protocol
 * simulator. */
stack_app_t* get_proto_stack_app(proto_simulator_t* proto_sim)
{
    stack_app_t* stackApp = NULL;

    if (NULL != proto_sim)
    {
        stackApp = proto_sim->stackApp;
    }

    return stackApp;
}


/* This function is used for fetching stack of the protocol 
 * simulator. */
proto_stack_t* get_proto_stack(proto_simulator_t* proto_sim)
{
    proto_stack_t* stack = NULL;

    if (NULL != proto_sim)
    {
        stack = proto_sim->stack;
    }

    return stack;
}


/* This function is used for fetching encoder of the protocol 
 * simulator. */
encoder_t* get_proto_encoder(proto_simulator_t* proto_sim)
{
    encoder_t* encoder = NULL;

    if (NULL != proto_sim)
    {
        encoder = proto_sim->encoder;
    }

    return encoder;
}


/* This function is used for fetching decoder of the protocol 
 * simulator. */
decoder_t* get_proto_decoder(proto_simulator_t* proto_sim)
{
    decoder_t* decoder = NULL;

    if (NULL != proto_sim)
    {
        decoder = proto_sim->decoder;
    }

    return decoder;
}

#if 0
/* This function is used for fetching peer connection handler 
 * of the protocol simulator correspoding to a socket FD. */
peer_conn_hdlr_t* get_proto_peer_conn_hdlr(
        proto_simulator_t* proto_sim,
        unsigned int       sockFd)
{
    peer_conn_hdlr_t* conn_hdlr = NULL;
    unsigned short    index     = 0;

    /* Ensure that received pointer is valid */
    if (NULL == proto_sim)
    {
        return NULL;
    }

    /* Traverse through the list of all the connection handlers
     * of this simulator and check if there is any one having
     * socket FD matching the one passed by caller. */
    for (index = 0; index < proto_sim->num_peer_conn_hdlr; index++)
    {
        if (sockFd == proto_sim->peer_conn_hdlr[index]->sockFd)
        {
            conn_hdlr = proto_sim->peer_conn_hdlr[index];
        }
    }

    return conn_hdlr;
}

#endif

/* This function is used for fetching peer connection handler 
 * of a simulator stored at index passed by caller. */
peer_conn_hdlr_t* get_proto_peer_conn_hdlr_by_index(
        proto_simulator_t* proto_sim,
        unsigned short     index)
{
    /* Ensure that received pointer is valid */
    if (NULL == proto_sim)
    {
        return NULL;
    }

    /* Ensure that received index is valid */
    if (index >= MAX_USERS_SUPPORTED)
    {
        return NULL;
    }

    /* Return handler stored at index passed by caller */
    return proto_sim->peer_conn_hdlr[index];
}


