/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "proto_stack_app.h"


/* This function will allocate and return new protocol stack app 
 * to the caller. */
stack_app_t* allocate_new_protocol_stack_app()
{
    stack_app_t* stackApp = NULL;

    stackApp = (stack_app_t*)malloc(sizeof(stack_app_t));
    return stackApp;
}

