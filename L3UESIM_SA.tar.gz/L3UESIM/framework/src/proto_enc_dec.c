/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "globalContext.h"
#include "proto_enc_dec.h"


/* This function will allocate and return new protocol encoder 
 * to caller. */
encoder_t* allocate_new_proto_encoder()
{
    encoder_t* encoder = NULL;

    encoder = (encoder_t*)malloc(sizeof(encoder_t));
    return encoder;
}


/* This function will allocate and return new protocol decoder 
 * to caller. */
decoder_t* allocate_new_proto_decoder()
{
    decoder_t* decoder = NULL;

    decoder = (decoder_t*)malloc(sizeof(decoder_t));
    return decoder;
}

