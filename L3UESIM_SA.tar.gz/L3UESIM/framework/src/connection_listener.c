
/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "connection_listener.h"

/* Allocates new connection listener and returns to caller */
connection_listener_t* allocate_connection_listener()
{
    connection_listener_t* conn_listener = NULL;

    conn_listener = malloc(sizeof(connection_listener_t));
    return conn_listener;
}

