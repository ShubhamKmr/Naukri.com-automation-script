/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "globalContext.h"


/* This function allocates and returns UI handler */
ui_conn_hdlr_t*  allocate_ui_conn_hdlr()
{
    ui_conn_hdlr_t* ui_hdlr = NULL;

    ui_hdlr = (ui_conn_hdlr_t*)malloc(sizeof(ui_conn_hdlr_t));
    return ui_hdlr;
}


/* This function will the free UI handler passed by caller */
void release_ui_conn_hdlr(ui_conn_hdlr_t* ui_hdlr)
{
    if (NULL != ui_hdlr)
    {
        //free(ui_hdlr);
    }
}


/* This function will process received message from user */
void process_user_msg(void* msgBuf, unsigned int msgLen)
{
    user_data_req_t*   user_req          = NULL;
    proto_simulator_t* proto_sim         = NULL;
    cmd_interpreter_t* cmd_interpreter   = NULL;

    if (NULL == msgBuf || 0 == msgLen)
    {
        LOG_TRACE("Invalid message received from user\n");
        return;
    }

    /* TODO : Need to ensure that message length is atleast equal
     * to mandatory fields. */

    user_req = (user_data_req_t*)msgBuf;

    /* Fetch protocol simulator for which message is received
     * based on protocol identifer. */
    proto_sim = get_proto_simulator(user_req->proto_identifier);
    if (NULL == proto_sim)
    {
        LOG_TRACE("No simulator registered for protocol ID: %d\n",
                  user_req->proto_identifier);
        return;
    }

    /* Fetch command interpreter of simulator */
    cmd_interpreter = get_cmd_interpreter(proto_sim);
    if (NULL == cmd_interpreter)
    {
        LOG_TRACE("Command interpreter not registered for simulator with "
                  "protocol ID: %d\n", user_req->proto_identifier);
        return;
    }

    LOG_TRACE("Invoking cmd interpreter handler, msgLen: %d\n", user_req->msgLen);

    /* Invoke user command handler of the command interpreter */
    cmd_interpreter->user_cmd_hdlr(user_req->msgBuf, 
                                   user_req->msgLen);
}


/* Close of user interface handler */
void ui_handler_close()
{
}


/* This function will read specified number of bytes from 
 * socket in the message buffer provided by caller. */
int read_bytes_from_sock(unsigned int   sockFd,
                         unsigned char* msgBuf,
                         unsigned int   msgLen)
{
    int          bytesRead     = 0;
    unsigned int bytesTobeRead = 0;
    unsigned int byteOffset    = 0;

    /* Set the bytes to be read to total length of the msg 
     * to be read */
    bytesTobeRead = msgLen;

    /* Keep reading bytes from the socket till either complete 
     * message is read or error is returned by recv() call. */
    while (bytesTobeRead > 0)
    {
        //fprintf(stderr, "Reading :%d bytes, at offset: %d\n",
        //        bytesTobeRead, byteOffset);

        /* Read left over bytes of message from the socket */
        bytesRead = recv(sockFd, &msgBuf[byteOffset], bytesTobeRead, 0);
        if (bytesRead < 0)
        {
            fprintf(stderr, "Error while reading msg from socket, "
                    "errno: %d\n", errno);

            return bytesRead;
        }

        /* Break from loop, if complete message is read */
        if (bytesRead == bytesTobeRead)
        {
   //         fprintf(stderr, "Complete msg read, length: %d\n", msgLen);
            break;
        }
        else
        {
 //           fprintf(stderr, "Partial read, length: %d\n", bytesRead);
        }

        /* Decrement the bytes to be read by count of bytes read */
        bytesTobeRead -= bytesRead;

        /* Increment the byte offset by count of bytes read */
        byteOffset += bytesRead;
    }

    return msgLen;
}


/* This function will read message from TCP socket */
unsigned int read_msg_from_socket(
        unsigned int   sockFd,
        unsigned char* msgBuf)
{
    user_data_req_t*  hdr_p           = NULL;
    int               bytesRead       = 0;
    unsigned int      totalBytesRead  = 0;
    unsigned int      msgLen          = 0;

    //fprintf(stderr, "Reading message header of length: %d\n",
    //        UI_HDR_LEN);

    /* Read header to figure out the length of the msg body */
    bytesRead = read_bytes_from_sock(sockFd, msgBuf, UI_HDR_LEN);
    if (bytesRead < 0)
    {
        fprintf(stderr, "Failed to read message header \n");
        close(sockFd);
        return totalBytesRead;
    }

    //fprintf(stderr, "header read: length: %d\n", bytesRead);

    /* Fetch pointer to user data request header */
    hdr_p = (user_data_req_t*)msgBuf;

    /* Fetch length of message body from header */
    msgLen = hdr_p->msgLen; 

    /* Update total bytes read */
    totalBytesRead += bytesRead;

    //fprintf(stderr, "\nReading message body of length: %d\n", msgLen);

    /* Read body of the msg */
    bytesRead = read_bytes_from_sock(sockFd, &msgBuf[UI_HDR_LEN], msgLen);
    if (bytesRead < 0)
    {
        LOG_TRACE("Failed to read message body \n");

        close(sockFd);
        return totalBytesRead;
    }

    /* Update total bytes read */
    totalBytesRead += bytesRead;

    //fprintf(stderr, "Message read with length: %d\n", totalBytesRead);

    return totalBytesRead;
}

#if 0        
/* This function reads message from TCP socket */
int read_tcp_message(
                unsigned int   sockFd,
                unsigned char* msgBuf,
                unsigned int   msgLen)
{
    struct sockaddr_in   peer_addr;
    int                  bytesRead  = 0;

    memset(&peer_addr, 0, sizeof(struct sockaddr_in));

    /* Read message from socket */
    if ((bytesRead = recv(sockFd, msgBuf, msgLen, 0)) < 0)
    {
        LOG_TRACE("Read failed from client FD = %d, with error num = %d\n", 
                   sockFd, errno);
        return bytesRead;
    }

    LOG_TRACE("Message received by UI handler, size: %d\n", bytesRead);

    return bytesRead;
}

#endif

/* Receive method of user interface handler */
sim_return_val_et ui_handler_receive(unsigned int sockFd)
{
    int    msgLen  = 0;
    void*  msgBuf  = NULL;

    /* Allocate memory for message */
    msgBuf = (char*)malloc(MAX_USER_REQ_SIZE);
    if (NULL == msgBuf)
    {
        LOG_TRACE("Failed to allocate memory for message buffer\n");
        return SIM_SUCCESS;
    }

   // LOG_TRACE("Allocated memory of size: %d\n", MAX_USER_REQ_SIZE);

    /* Read message from TCP socket */
    msgLen = read_msg_from_socket(sockFd, msgBuf); 
                          //    MAX_USER_REQ_SIZE);

    /* Process received message */
    if (msgLen > 0)
    {
        process_user_msg(msgBuf, msgLen);

        free(msgBuf);
        return SIM_SUCCESS;
    }

    /* Free memory buffer */
    free(msgBuf);

    return SIM_FAILURE;
}


/* Send method of user interface handler */
void ui_handler_send(unsigned int    sockFd,
                     void*           msgBuf, 
                     unsigned int    msgLen)
{
    int          bytesSent     = 0;
    unsigned int bytesToBeSent = 0;
    unsigned int msgOffset     = 0;
    unsigned char* bufPtr      = NULL;

    //LOG_TRACE("Sending message to user, length: %d\n", msgLen);

    /* Set bytes to be sent to total len */
    bytesToBeSent = msgLen;

    bufPtr = (unsigned char*)msgBuf;

    while (bytesToBeSent > 0)
    {
        /* Send message to destination */
        if ((bytesSent = send(sockFd, &bufPtr[msgOffset], 
                              bytesToBeSent, 0)) < 0)
        {
            LOG_TRACE("Failed to send message to user, bytes written: %d\n", 
                      bytesSent);

            perror("sendmsg");
            return;
        }

        /* If complete message is sent, break from the while loop */
        if (bytesSent == bytesToBeSent)
        {
            LOG_TRACE("Message sent to user, length: %d\n", bytesSent);
            break;
        }

        /* Decrement the bytes to be sent by bytes sent */
        bytesToBeSent -= bytesSent;

        /* Increment the message offset by bytes sent */
        msgOffset += bytesSent;

    }
}


/* This function will handle new connection requests 
 * from users. */
/*parallel ue changes start*/
void handle_new_user_connection_req(int clientFd,unsigned int simid)
{
/*parallel ue changes end*/    
    ui_conn_hdlr_t*  ui_conn_hdlr = NULL;
    socklen_t optlen;
    int sendbuff = 0;
    int res;

    /* Allocate a new UI handler */
    ui_conn_hdlr = allocate_ui_conn_hdlr();
    if (NULL == ui_conn_hdlr)
    {
        LOG_TRACE("Failed to allocate user connection handler for "
                  "sockFd: %d\n", clientFd);

        return;
    }

    /* Set socket rcv/send buffer sizes */
    // Get buffer size
    optlen = sizeof(sendbuff);
    res = getsockopt(clientFd, SOL_SOCKET, SO_SNDBUF, &sendbuff, &optlen);

    if(res == -1)
     printf("Error getsockopt one");
    else
     printf("send buffer size = %d\n", sendbuff);
 
    optlen = sizeof(sendbuff);
    res = getsockopt(clientFd, SOL_SOCKET, SO_RCVBUF, &sendbuff, &optlen);

    if(res == -1)
     printf("Error getsockopt one");
    else
     printf("Receive buffer size = %d\n", sendbuff);
 
    /* Populate function pointers for send/receive callbacks */
    ui_conn_hdlr->receive = ui_handler_receive; 
    ui_conn_hdlr->send    = ui_handler_send;

    /* Store socketFd in UI connection handler */
    ui_conn_hdlr->sockFd  = clientFd;

    /* Populate epoll data to be used with this handler */
    ui_conn_hdlr->epoll_user_data.socketFd  = clientFd;
    ui_conn_hdlr->epoll_user_data.connType  = USER_CONNECTION_HDLR;
    /*parallel ue changes start*/
    ui_conn_hdlr->epoll_user_data.simId     = simid;
    /*parallel ue changes end*/
    /* Add handler to global list of user connection handlers */
    if (SIM_FAILURE == register_user_conn_handler(ui_conn_hdlr,simid))
    {
        LOG_TRACE("Failed to register user connection handler "
                  "for sockFd: %d\n", clientFd);

        /* Free memory allocated for UI handler */
        release_ui_conn_hdlr(ui_conn_hdlr);

        return;
    }
#if 0
    /* Register client FD with epoll FD for receive notifications */
    if (SIM_SUCCESS != register_fd_for_receive_notification(
                            clientFd,
                            &ui_conn_hdlr->epoll_user_data))
    {
        LOG_TRACE("Failed to register client socket FD with epoll FD\n");

        /* Free memory allocated for UI handler */
        release_ui_conn_hdlr(ui_conn_hdlr);

        return;
    }
#endif
}

