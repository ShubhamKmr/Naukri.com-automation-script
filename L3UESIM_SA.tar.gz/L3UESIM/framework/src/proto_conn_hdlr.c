/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

#include "proto_peer_conn_hdlr.h"
#include "connection_handler.h"


/* Pointer to protocol peer connection handler */
peer_conn_hdlr_t*  allocate_new_peer_conn_hdlr()
{
    peer_conn_hdlr_t* conn_hdlr = NULL;

    conn_hdlr = (peer_conn_hdlr_t*)malloc(sizeof(peer_conn_hdlr_t));
    return conn_hdlr;
}


/* This function allocate new connection handler and return 
 * it to caller */
connection_handler_t*  allocate_connection_handler()
{
    connection_handler_t* conn_hdlr = NULL;

    conn_hdlr = (connection_handler_t*)malloc(sizeof(connection_handler_t));
    return conn_hdlr;
}

