/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>

/* Project Includes */
#include "proto_peer_conn_mgr.h"
#include "proto_sim.h"
#include "globalContext.h"


/* Function for allocating new peer connection manager */
peer_conn_mgr_t*  allocate_new_peer_conn_mgr()
{
    peer_conn_mgr_t* peer_conn_mgr = NULL;

    peer_conn_mgr = (peer_conn_mgr_t*)malloc(sizeof(peer_conn_mgr_t));

    return peer_conn_mgr;
}


/* Function for registering new peer connection handler
 * with peer connection manager. */
sim_return_val_et  
register_peer_conn_hdlr_with_peer_conn_mgr(
        proto_id          sim_id,
        peer_conn_hdlr_t* conn_hdlr)
{
    proto_simulator_t* proto_sim     = NULL;
    peer_conn_mgr_t*   peer_conn_mgr = NULL;

    /* Fetch simulator corresponding to SIM ID passed by caller */
    proto_sim = get_proto_simulator(sim_id);
    if (NULL == proto_sim)
    {
        LOG_TRACE("No simulator exists for sim ID: %d", sim_id);
        return SIM_FAILURE;
    }

    /* Fetch peer connection manager for this protocol simulator */
    peer_conn_mgr = get_proto_peer_conn_mgr(proto_sim); 
    if (NULL == peer_conn_mgr)
    {
        LOG_TRACE("No peer connection manager exists for sim ID: %d", 
                  sim_id);
        return SIM_FAILURE;
    }

    /* Ensure that max peer connection handlers are not
     * already registered with the peer connection manager */
    if (peer_conn_mgr->num_peer_conn_hdlr >= MAX_PEER_CONN_PER_SIM)
    {
        LOG_TRACE("Max allowed peer connection handlers already"
                  " registered with peer connection manager.\n");
        return SIM_FAILURE;
    }

    /* Add peer connection handler to the list of peer connection
     * handlers managed by peer connection manager. */
    peer_conn_mgr->peer_conn_hdlr[peer_conn_mgr->num_peer_conn_hdlr]
                          = conn_hdlr;

    /* Increment the count of currently registered peer connection
     * handlers. */
    peer_conn_mgr->num_peer_conn_hdlr += 1;

    return SIM_SUCCESS;
}

