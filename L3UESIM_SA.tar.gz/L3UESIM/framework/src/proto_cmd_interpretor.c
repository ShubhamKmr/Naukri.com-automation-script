/* Standard includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <signal.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include "proto_cmd_interpretor.h"


/* This function is used for allocating a new protocol command
 * interpreter */
cmd_interpreter_t* allocate_command_interpreter()
{
    cmd_interpreter_t* cmd_interpreter = NULL;

    cmd_interpreter = (cmd_interpreter_t*)malloc(sizeof(cmd_interpreter_t));
    return cmd_interpreter;
}

