/****************************************************************************
 *
 * ARICENT - ngap_asn_enc_wrappers.c
 *
 * Copyright (C) 2015 Aricent Inc . All Rights Reserved.
 *
 * File Name       : ngap_asn_enc_wrappers.c
 * File Description: 
 ***************************************************************************/

#include "ngap_types.h"
#include "ngap_utils.h"
#include "ngap_intf_mgmnt.h"
#include "ngap_tracing.h"
#include "ngap_asn_dec_wrapper.h"
#include "ngap_asn_common_wrapper.h"

#ifndef AMF_SIM_TESTING_ENABLE
#include "rrc_logging.h"
#include "ngap_err_ind.h"
#else
#include "rrc_common_utils.h"
#endif
/***************************************************************************/

/*****************************************************************************
 * Function Name  : ngap_get_asn_msg_type
 * Inputs         : p_asn_msg - Pointer to the received ASN message from AMF
 *                      asn_msg_len - The length of the ASN message
 *                      ep_type - pointer to the received EP type
 * Outputs        : ep_type - This is updated with the EP type
 * Returns        : NGAP_SUCCESS - ASN decoding was successful.
 *                  NGAP_FAILURE - ASN decoding was not successful.
 * Description    : This function derived the received message from AMF after 
 *                  decoding partial ASN message.
 ******************************************************************************/
ngap_return_et ngap_get_asn_msg_type
(
    void                *p_asn_msg,
    UInt32              asn_msg_len,
    ngap_amf_api_et   	*ep_type,
    UInt8               *is_rcv_msg_correct
)
{
    OSCTXT              asn1_ctx;
    OSUINT32 		    msg_type    = 0xFF;
    ngap_ProcedureCode  proc_code   = 0xFF;
    OSBOOL 		        extbit 		= NGAP_FALSE;
    SInt32 		        stat		= NGAP_ZERO;
    ngap_return_et      result      = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_msg);

    /* Initialise ASN1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Drop message */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }

    /*Set pointer of asn buffer in asn context*/
    if (NGAP_ASN_OK != 
        pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Get ASN mSG Type");
        return NGAP_FAILURE;
    }
    
    /* Get Type of Message from the received ASN buffer */
    stat = DEC_BIT (&asn1_ctx, &extbit);
    if (stat != NGAP_ZERO) 
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"ASN: DEC_BIT failed");
        return NGAP_FAILURE;
    }

    if (!extbit)
    {
        stat = pd_ConsUnsigned (&asn1_ctx, &msg_type, NGAP_ZERO, OSUINTCONST(2));
        if (stat != NGAP_ZERO)
        { 
            RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Failed in msg_type");
            return NGAP_FAILURE;
        }

        msg_type++;

        switch (msg_type) 
        {
            case T_ngap_NGAP_PDU_initiatingMessage:
            case T_ngap_NGAP_PDU_successfulOutcome:
            case T_ngap_NGAP_PDU_unsuccessfulOutcome:
            {
                break;
	        }
            
            default:
	        {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "ASN: Invalid msg_type detected %d", 
                    msg_type);

                return NGAP_FAILURE;
	        }
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Ext bit detected");
        return NGAP_FAILURE;
    }

    /* Get procedure code from received ASN buffer */
    stat = asn1PD_ngap_ProcedureCode (&asn1_ctx, &proc_code);
    if (stat != NGAP_ZERO) 
    {
        RRC_NGAP_TRACE(NGAP_ERROR,
            "ASN: Decoding for Procedure Code failed for received msg_type %d",
            msg_type);

        return NGAP_FAILURE;
    }

    *is_rcv_msg_correct = NGAP_TRUE;
    
    /* Get EP type from received type of message and procedure code */
    /* Initiating Message */
    if(T_ngap_NGAP_PDU_initiatingMessage == msg_type)
    {
        switch(proc_code)
        {
            case ASN1V_ngap_id_DownlinkNASTransport:
            {
                *ep_type = NGAP_DOWNLINK_NAS_TRANSPORT;
                break;
            }

            case ASN1V_ngap_id_UplinkNASTransport:
            {
                *ep_type = NGAP_UPLINK_NAS_TRANSPORT;
                break;
            }

            case ASN1V_ngap_id_InitialContextSetup:
            {
                *ep_type = NGAP_INITIAL_CONTEXT_SETUP_REQUEST;
                break;
            }

            case ASN1V_ngap_id_UEContextRelease:
            {
                *ep_type = NGAP_UE_CONTEXT_RELEASE_COMMAND;
                break;
            }

            case ASN1V_ngap_id_NGReset:
            {
                *ep_type = NGAP_NG_RESET;
                break;
            }

	        case ASN1V_ngap_id_ErrorIndication:
            {
                *ep_type = NGAP_ERROR_INDICATION;
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceSetup:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_SETUP_REQUEST;
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceRelease:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_RELEASE_COMMAND;
                break;
            }
            
            case ASN1V_ngap_id_Paging:
            {
                *ep_type = NGAP_PAGING; 
                break;
            }
            case ASN1V_ngap_id_AMFConfigurationUpdate:
            {
                *ep_type = NGAP_AMF_CONFIGURATION_UPDATE; 
                break;
            }
            /*NGAP_BASED_HO_START*/
            case ASN1V_ngap_id_HandoverCancel:
            {
                *ep_type = NGAP_HANDOVER_CANCEL;
                break;
            }
            case ASN1V_ngap_id_HandoverPreparation:
            {
                *ep_type = NGAP_HANDOVER_REQUIRED;
                break;
            }
            case ASN1V_ngap_id_HandoverResourceAllocation:
            {
                *ep_type = NGAP_HANDOVER_REQUEST;
                break;
            }
            case ASN1V_ngap_id_HandoverNotification:
            {
                *ep_type = NGAP_HANDOVER_NOTIFY;
                break;
            }
            /*NGAP_BASED_HO_STOP*/


	        default:
	        {
                RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Initiating Message");
		        result = NGAP_FAILURE;
	        }
        }
    }
    /* Successful Outcome */
    else if(T_ngap_NGAP_PDU_successfulOutcome == msg_type)
    {
	    switch(proc_code)
        {
            case ASN1V_ngap_id_NGReset:
            {
                *ep_type = NGAP_NG_RESET_ACKNOWLEDGE;
                break;
            }

   	        case ASN1V_ngap_id_NGSetup:
            {
                *ep_type = NGAP_NG_SETUP_RESPONSE;
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceSetup:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_SETUP_RESPONSE;
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceRelease:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_RELEASE_RESPONSE;
                break;
            }

            case ASN1V_ngap_id_RANConfigurationUpdate:
            {
                *ep_type = NGAP_RAN_CONFIGURATION_UPDATE_ACKNOWLEDGE;
                break;
            }
            /*NGAP_BASED_HO_START*/
            case ASN1V_ngap_id_HandoverCancel:
            {
                *ep_type = NGAP_HANDOVER_CANCEL_ACKNOWLEDGE;
                break;
            }
            case ASN1V_ngap_id_HandoverPreparation:
            {
                *ep_type = NGAP_HANDOVER_COMMAND;
                break;
            }
            case ASN1V_ngap_id_HandoverResourceAllocation:
            {
                *ep_type = NGAP_HANDOVER_REQUEST_ACKNOWLEDGE;
                break;
            }
            /*NGAP_BASED_HO_STOP*/

   	        default:
	        {
	            RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Successful Outcome Message");
		        result = NGAP_FAILURE;
	        }
        }
    }
    /* Unsuccessful Outcome */
    else
    {
        switch(proc_code)
        {
            case ASN1V_ngap_id_NGSetup:
            {
                *ep_type = NGAP_NG_SETUP_FAILURE;
                break;
            }

            case ASN1V_ngap_id_RANConfigurationUpdate:
            {
                *ep_type = NGAP_RAN_CONFIGURATION_UPDATE_FAILURE;
                break;
            }
            /*NGAP_BASED_HO_START*/
            case ASN1V_ngap_id_HandoverPreparation:
            {
                *ep_type = NGAP_HANDOVER_PREPARATION_FAILURE;
                break;
            }
            case ASN1V_ngap_id_HandoverResourceAllocation:
            {
                *ep_type = NGAP_HANDOVER_FAILURE;
                break;
            }
            /*NGAP_BASED_HO_STOP*/

            default:
	        {
	            RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Unsuccessful Outcome Message");
		        result = NGAP_FAILURE;
	        }
        }
    }

    /* Free ASN1 Context */
    rtFreeContext(&asn1_ctx);

    if (NGAP_FAILURE == result)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
            "ASN: Not Supported Message Received with msg_type:%d, proc_code:%d", 
            msg_type, proc_code);
    }
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/*****************************************************************************
 * Function Name  : amf_get_asn_msg_type
 * Inputs         : p_asn_msg - Pointer to the received ASN message from gNB
 *                    asn_msg_len - The length of the ASN message
 *                    ep_type - pointer to the received EP type
 * Outputs        : ep_type - This is updated with the EP type
 * Returns        : NGAP_SUCCESS - ASN decoding was successful.
 *                  NGAP_FAILURE - ASN decoding was not successful.
 * Description    : This function derived the received message from gNB after 
 *                  decoding partial ASN message.
 ******************************************************************************/
ngap_return_et amf_get_asn_msg_type
(
    void                *p_asn_msg,
    UInt32              asn_msg_len,
    ngap_amf_api_et   	*ep_type,
    UInt8               *is_rcv_msg_correct
)
{
    OSCTXT              asn1_ctx;
    OSUINT32 		    msg_type    = 0xFF;
    ngap_ProcedureCode  proc_code   = 0xFF;
    OSBOOL 		        extbit 		= NGAP_FALSE;
    SInt32 		        stat		= NGAP_ZERO;
    ngap_return_et      result      = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_msg);

    /* Initialise ASN1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Drop message */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }

    /*Set pointer of asn buffer in asn context*/
    if (NGAP_ASN_OK != 
        pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Get ASN msg type");
        return NGAP_FAILURE;
    }
    

    /* Get Type of Message from the received ASN buffer */
    stat = DEC_BIT (&asn1_ctx, &extbit);
    if (stat != NGAP_ZERO) 
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"ASN: DEC_BIT failed");
        return NGAP_FAILURE;
    }

    if (!extbit)
    {
        stat = pd_ConsUnsigned (&asn1_ctx, &msg_type, NGAP_ZERO, OSUINTCONST(2));
        if (stat != NGAP_ZERO)
        { 
            RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Failed in msg_type");
            return NGAP_FAILURE;
        }

        msg_type++;

        switch (msg_type) 
        {
            case T_ngap_NGAP_PDU_initiatingMessage:
            case T_ngap_NGAP_PDU_successfulOutcome:
            case T_ngap_NGAP_PDU_unsuccessfulOutcome:
            {
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid msg_type detected");
                return NGAP_FAILURE;
            }
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Ext bit detected");
        return NGAP_FAILURE;
    }

    /* Get procedure code from received ASN buffer */
    stat = asn1PD_ngap_ProcedureCode (&asn1_ctx, &proc_code);
    if (stat != NGAP_ZERO) 
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"ASN: DEC_BIT failed");
        return NGAP_FAILURE;
    }

    *is_rcv_msg_correct = NGAP_TRUE;
    
    /* Get EP type from received type of message and procedure code */

    /* initiating message */
    if(T_ngap_NGAP_PDU_initiatingMessage == msg_type)
    {
        switch(proc_code)
        {
            case ASN1V_ngap_id_UplinkNASTransport:
            {
                *ep_type = NGAP_UPLINK_NAS_TRANSPORT;
                break;
            }

            case ASN1V_ngap_id_InitialUEMessage:
            {
                *ep_type = NGAP_INITIAL_UE_MESSAGE;
                break;
            }

            case ASN1V_ngap_id_UERadioCapabilityInfoIndication:
            {
                *ep_type = NGAP_UE_RADIO_CAPABILITY_INFO_INDICATION;
                break;
            }

            case ASN1V_ngap_id_UEContextReleaseRequest:
            {
                *ep_type = NGAP_UE_CONTEXT_RELEASE_REQUEST;
                break;
            }

            case ASN1V_ngap_id_UEContextRelease:
            {
                *ep_type = NGAP_UE_CONTEXT_RELEASE_COMPLETE;
                break;
            }

            case ASN1V_ngap_id_NGReset:
            {
                *ep_type = NGAP_NG_RESET;
                break;
            }

	        case ASN1V_ngap_id_ErrorIndication:
            {
                *ep_type = NGAP_ERROR_INDICATION;
                break;
            }
          
            case ASN1V_ngap_id_NASNonDeliveryIndication:
            {
                *ep_type = NGAP_NAS_NON_DELIVERY_INDICATION;
                break;
            }

            case ASN1V_ngap_id_NGSetup:
            {
                *ep_type = NGAP_NG_SETUP_REQUEST;
                break;
            }
            case ASN1V_ngap_id_RANConfigurationUpdate:
            {
                *ep_type = NGAP_RAN_CONFIGURATION_UPDATE;
                break;
            }
            
	        default:
	        {
                RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Initiating Message");
		        result = NGAP_FAILURE;
	        }
        }
    }
    /* successful outcome */
    else if(T_ngap_NGAP_PDU_successfulOutcome == msg_type)
    {
        switch(proc_code)
        {
            case ASN1V_ngap_id_NGReset:
            {
                *ep_type = NGAP_NG_RESET_ACKNOWLEDGE;
                break;
            }

            case ASN1V_ngap_id_InitialContextSetup:
            {
                *ep_type = NGAP_INITIAL_CONTEXT_SETUP_RESPONSE;
                break;
            }
            case ASN1V_ngap_id_UEContextRelease:
            {
                *ep_type = NGAP_UE_CONTEXT_RELEASE_COMPLETE;
                break;
            }
            case ASN1V_ngap_id_PDUSessionResourceSetup:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_SETUP_RESPONSE;
                break;
            }
            case ASN1V_ngap_id_PDUSessionResourceRelease:
            {
                *ep_type = NGAP_PDU_SESSION_RESOURCE_RELEASE_RESPONSE;
                break;
            }

            case ASN1V_ngap_id_AMFConfigurationUpdate:
            {
                *ep_type = NGAP_AMF_CONFIGURATION_UPDATE_ACKNOWLEDGE;
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Successful Outcome Message");
                result = NGAP_FAILURE;
            }
        }
    }
    /* unsuccessful outcome */
    else
    {
        switch(proc_code)
        {
            case ASN1V_ngap_id_InitialContextSetup:
            {
                *ep_type = NGAP_INITIAL_CONTEXT_SETUP_FAILURE;
                break;
            }

            case ASN1V_ngap_id_AMFConfigurationUpdate:
            {
                *ep_type = NGAP_AMF_CONFIGURATION_UPDATE_FAILURE;
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,"ASN: Invalid Unsuccessful Outcome Message");
                result = NGAP_FAILURE;
            }
        }
    }

    /* Free ASN1 Context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/******************************************************************************
 * Function Name    : ngap_decode_ng_setup_req
 * Input            : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Output           : p_ng_setup_req - Information from which local buffer will be filled
 * Returns          : NGAP_SUCCESS - ASN decoding was successful
 *                      NGAP_FAILURE - ASN decoding was not successful
 * DESCRIPTION	    : This function decodes NG SETUP REQUEST ASN message.
 *****************************************************************************/
ngap_return_et ngap_decode_ng_setup_req
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_setup_request_t	*p_ng_setup_req	/* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
    NGAP_MEMSET(p_ng_setup_req, NGAP_ZERO, sizeof(ngap_setup_request_t));
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_setup_req_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.nGSetup,
                p_ng_setup_req);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}


ngap_return_et ng_setup_req_internal_dec
(
    OSCTXT			        *p_asn1_ctx,            /* Input: ASN1 Context to be used */
    ngap_NGSetupRequest     *p_asn_ng_setup_req,    /* Input: Received ASN Buffer */
    ngap_setup_request_t    *p_local_ng_setup_req   /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_NGSetupRequest_protocolIEs_element *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_setup_req);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_GlobalRANNodeID, ngap_mandatory, ngap_reject, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_RANNodeName, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_SupportedTAList, ngap_mandatory, ngap_reject, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {3, ASN1V_ngap_id_DefaultPagingDRX, ngap_mandatory, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {4, ASN1V_ngap_id_UERetentionInformation, ngap_optional, 
            ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
        }
       }
    };
    
    p_local_ng_setup_req->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ng_setup_req->protocolIEs.head;
    
    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_setup_req->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_NGSetupRequest_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_GlobalRANNodeID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_GlobalRANNodeID");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupRequestIEs_1,
                            (void *)&p_local_ng_setup_req->global_ran_node_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_GlobalRANNodeID Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_RANNodeName:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_RANNodeName");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupRequestIEs_2,
                            (void *)p_local_ng_setup_req->ran_node_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - ASN1V_ngap_id_RANNodeName Validation failed");
                }
                else
                {
                    p_local_ng_setup_req->bitmask |= 
                        NG_SETUP_REQ_RAN_NODE_NAME_ID_PRESENT;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_SupportedTAList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_SupportedTAList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupRequestIEs_3,
                            (void *)&p_local_ng_setup_req->supported_ta_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_SupportedTAList Validation failed");
                }
                break;
            } /* End of IE3 */

            /* IE4 */
            case ASN1V_ngap_id_DefaultPagingDRX:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_DefaultPagingDRX");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_NGSetupRequestIEs_4,
                            (void *)&p_local_ng_setup_req->default_paging_drx))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_DefaultPagingDRX Validation failed");
                }

                break;
            } /* End of IE4 */
            
            /*IE5*/
            case ASN1V_ngap_id_UERetentionInformation:
            {
                p_local_ng_setup_req->ue_retention_info =
                (ngap_ue_retention_info_et)p_prootocolIE_elem->value.u._ngap_NGSetupRequestIEs_5;

                break;
            }
            /*End of IE5*/

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */
        
        p_node = p_node->next;
        
    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NG Setup Request");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/****************************************************************************
 * Function Name: validate_and_fill_ue_radio_cap
 *
 * Input:         p_value - pointer of asn structure
 *
 * Output:        p_local - pointer of local strusture
 *
 * Description:  This function takes input from ASN Structure and 
 *               fill the local structure.
 *
 ***************************************************************************/
ngap_map_updation_const_et validate_and_fill_ue_radio_cap
(
       ngap_UERadioCapability   *p_value,
       ngap_dynamic_string_t    *p_local
)
{
    ngap_map_updation_const_et result = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();
    
    if(NGAP_ZERO >= p_value->numocts || NGAP_P_NULL == p_value->data)
    {
        RRC_NGAP_TRACE(NGAP_DETAILEDALL,"UE Capability Buffer is Empty");
        result = INVALID_VALUE;
        return result;
    }

    RRC_NGAP_TRACE(NGAP_DETAILEDALL,"UE Capability Buffer is not Empty");
    
    p_local->num_string_len = p_value->numocts;

    /* Allocate memory to string_data of local structure p_local */
    p_local->string_data = (UInt8 *)rrc_mem_get(p_local->num_string_len);
    
    if(NGAP_P_NULL == p_local->string_data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        result = INVALID_VALUE;
        return result;
    }

    /* Copy the value of data into string_data */
    NGAP_MEMCPY(p_local->string_data, p_value->data, p_value->numocts);
    return result;
}



/****************************************************************************
 * Function Name: validate_and_fill_nas_pdu
 *
 * Input:         p_value - pointer of asn structure
 *
 * Output:        p_local - pointer of local strusture
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 *
 ***************************************************************************/
ngap_map_updation_const_et validate_and_fill_nas_pdu
(
       ngap_NAS_PDU             *p_value,
       ngap_dynamic_string_t    *p_local
)
{
    ngap_map_updation_const_et result = OCCURANCE;
    
    p_local->num_string_len = p_value->numocts;

    /* Allocate memory to string_data of local structure p_local */
    p_local->string_data = (UInt8 *)rrc_mem_get(p_local->num_string_len);
    
    if(NGAP_P_NULL == p_local->string_data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        result = INVALID_VALUE;
        return result;
    }

    /* Copy the value of data into string_data */
    NGAP_MEMCPY(p_local->string_data, p_value->data, p_value->numocts);
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_UAMBitRate
 *
 * Input:         p_value - pointer of asn structure
 *
 * Output:        p_local - pointer of local strusture
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
***************************************************************************/
ngap_map_updation_const_et validate_and_fill_UAMBitRate
(
    ngap_UEAggregateMaximumBitRate          *p_value,
    ngap_ue_aggregate_maximum_bit_rate_t    *p_local
)
{
    ngap_map_updation_const_et result = OCCURANCE;

    p_local->ue_aggregate_maximum_bit_rate_dl.bit_rate = 
                                        p_value->uEAggregateMaximumBitRateDL;

    p_local->ue_aggregate_maximum_bit_rate_ul.bit_rate = 
                                        p_value->uEAggregateMaximumBitRateUL;

    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_allowed_nssai
 *
 * Input:         p_value - pointer of asn structure
 *
 * Inputs : 
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_allowed_nssai
(
   ngap_AllowedNSSAI            *p_value,
   ngap_allowed_nssai_list_t    *p_local
)
{
    ngap_AllowedNSSAI_Item      *p_ngap_allowed_nssai_item  = NGAP_P_NULL;
    OSRTDListNode               *p_nssai_item_node          = NGAP_P_NULL;
    ngap_map_updation_const_et  result                      = OCCURANCE;
    UInt16                      num_nssai_item_count        = NGAP_ZERO;

    
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_nssai_item_node = p_value->head;
    
    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Allowed Nssai List contains no elements");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_ALLOWED_NSSAI_LIST_ITEMS < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != p_nssai_item_node)
            {
                /* Assigning to nagp nssai item.*/
                p_ngap_allowed_nssai_item = 
                    (ngap_AllowedNSSAI_Item *)p_nssai_item_node->data;

                NGAP_MEMCPY
                (
                    p_local->allowed_s_nssai_item[num_nssai_item_count].s_nssai.sst,
                    p_ngap_allowed_nssai_item->s_NSSAI.sST.data,
                    p_ngap_allowed_nssai_item->s_NSSAI.sST.numocts
                );

                if(NGAP_TRUE == p_ngap_allowed_nssai_item->s_NSSAI.m.sDPresent)
                {
                    p_local->allowed_s_nssai_item[num_nssai_item_count].s_nssai.bitmask |= 
                        NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT;

                    NGAP_MEMCPY
                    (
                        p_local->allowed_s_nssai_item[num_nssai_item_count].s_nssai.sd,
                        p_ngap_allowed_nssai_item->s_NSSAI.sD.data,
                        p_ngap_allowed_nssai_item->s_NSSAI.sD.numocts
                    );
                }

                p_nssai_item_node = p_nssai_item_node->next;
                num_nssai_item_count++;
            }
        }
    } while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_source_to_target_amf_info_reroute
 * 
 * Inputs        : p_value
 *
 * Outputs       : p_local
 *
 * Description   :  This function takes input from ASN Structure and
                    fill the local structure.
* ************************************************************************/
ngap_return_et validate_and_fill_source_to_target_amf_info_reroute
(
   ngap_SourceToTarget_AMFInformationReroute      *p_value,  /* INPUT  */
   ngap_source_to_target_information_reroute_t    *p_local   /* OUTPUT */ 
)
{
    ngap_return_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    /*Assigning to Source to Target Information reroute Item*/
/*    p_value = 
        (ngap_SourceToTarget_AMFInformationReroute *)p_src_trgt_node->\
        data;*/

    /* Configurred NSSAI*/
    if(NGAP_TRUE == p_value->m.configuredNSSAIPresent)
    {
        p_local->bitmask |= INITIAL_UE_MESSAGE_CONFIGURED_NSSAI;        

        /* Allocate the memory for configured NSSAI */
        p_local->conf_nssai.string_data = 
            (UInt8*)rrc_mem_get(p_value->configuredNSSAI.numocts);

        /* Initialize allocated memory. */
        NGAP_MEMSET(p_local->conf_nssai.string_data, \
                NGAP_ZERO, p_value->configuredNSSAI.numocts);

        NGAP_MEMCPY
            (
             p_local->conf_nssai.string_data,
             p_value->configuredNSSAI.data,
             p_value->configuredNSSAI.numocts
            );
       p_local->conf_nssai.num_string_len = p_value->configuredNSSAI.numocts;

    }
    /* Rejected NSSAI in PLMN */
    if(NGAP_TRUE == p_value->\
            m.rejectedNSSAIinPLMNPresent)
    {
        p_local->bitmask |=
            INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_PLMN;

        /*Allocate the memory for rejected nssai in plmn*/
        p_local->rej_nssai_plmn.string_data = 
            (UInt8*)rrc_mem_get(p_value->rejectedNSSAIinPLMN.numocts);

        NGAP_MEMCPY
            (
             p_local->rej_nssai_plmn.string_data,
             p_value->rejectedNSSAIinPLMN.data,
             p_value->rejectedNSSAIinPLMN.numocts 
            );
        p_local->rej_nssai_plmn.num_string_len = p_value->rejectedNSSAIinPLMN.numocts;

    }
    /* Rejected NSSAI in TA  */
     if(NGAP_TRUE == p_value->\
         m.rejectedNSSAIinTAPresent)
     {
          p_local->bitmask |=
            INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_TA;
            
    /* Allocate the memory for rejected nssai in TA  */
    p_local->rej_nssai_ta.string_data = 
        (UInt8*)rrc_mem_get(p_value->rejectedNSSAIinTA.numocts);
    
    NGAP_MEMCPY
        (
            p_local->rej_nssai_ta.string_data,
            p_value->rejectedNSSAIinTA.data,
            p_value->rejectedNSSAIinTA.numocts
        );
    p_local->rej_nssai_ta.num_string_len = p_value->rejectedNSSAIinTA.numocts;
     }

   result = NGAP_SUCCESS;
   return result;

}

/***************************************************************************
 *Function Name : validate_and_fill_ng_ran_tnl_remove_list
 *   
 *Inputs        :p_value
 *
 *Outputs       :p_local
 *
 *Description   : This function takes input from ASN Structure and
 fill the local structure.
 * *************************************************************************/
ngap_map_updation_const_et validate_and_fill_ng_ran_tnl_remove_list
(
 ngap_NGRAN_TNLAssociationToRemoveList    *p_value,

 ngap_tnl_association_remove_list_t       *p_local
 )
{
    ngap_NGRAN_TNLAssociationToRemoveItem   *p_ngap_ngran_tnlassociationremoveitem = NGAP_P_NULL;
    OSRTDListNode                           *p_ngran_tnl_node       = NGAP_P_NULL;
    ngap_map_updation_const_et              result                  = OCCURANCE;
    UInt16                                  num_ngran_tnl_count     = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ngran_tnl_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO,
                    "NG-RAN TNL Association to Remove List contains no elements");
            result = INVALID_VALUE;
            break;
        }
        else if(NG_SETUP_MAX_NO_OF_TNL_ASSOCIATION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->tnl_count =  p_value->count;

            while(NGAP_P_NULL != p_ngran_tnl_node)
            {
                /* Assigning to ngran tnl association remove item */
                p_ngap_ngran_tnlassociationremoveitem = 
                    (ngap_NGRAN_TNLAssociationToRemoveItem *)p_ngran_tnl_node->data;

                switch(p_ngap_ngran_tnlassociationremoveitem->\
                        tNLAssociationTransportLayerAddress.t)
                {
                    case T_ngap_CPTransportLayerInformation_endpointIPAddress:
                    {
                        p_local->tnl_association[num_ngran_tnl_count].\
                            transport_layer_addr.choice = NGAP_TNL_ENDPOINT_IP_ADDR;

                        /* Transport layer Address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association[num_ngran_tnl_count].\
                             transport_layer_addr.endpoint_ip_address.transport_layer_address,
                             p_ngap_ngran_tnlassociationremoveitem->\
                             tNLAssociationTransportLayerAddress.u.endpointIPAddress->\
                             data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );
                        break;
                    }/*Case for endpoint address */

                    case T_ngap_CPTransportLayerInformation_choice_Extensions:
                    {
                        p_local->tnl_association[num_ngran_tnl_count].\
                            transport_layer_addr.choice = 
                            NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT;

                        /* Transport layer Address--> fill endpoint ip address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association[num_ngran_tnl_count].\
                             transport_layer_addr.endpoint_ip_address_and_port.\
                             endpoint_ip_address.transport_layer_address,
                             p_ngap_ngran_tnlassociationremoveitem->\
                             tNLAssociationTransportLayerAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             endpointIPAddress.data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );

                        /* Transport layer Address--> fill port number*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association[num_ngran_tnl_count].\
                             transport_layer_addr.endpoint_ip_address_and_port.\
                             port_number,
                             p_ngap_ngran_tnlassociationremoveitem->\
                             tNLAssociationTransportLayerAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             portNumber.data,
                             NGAP_PORT_NUMBER_OCTET_SIZE
                            );

                        /*endpoint_ip_address_and_port*/
                        break;

                    }/*Choice extension for endpoint_ip_address_and_port */
                }//endswitch

                 p_local->tnl_association[num_ngran_tnl_count].\
                        bitmask = NGAP_ZERO;
                /* Transport layer Address at AMF*/                                       
                if(NGAP_TRUE ==  p_ngap_ngran_tnlassociationremoveitem->\
                        m.tNLAssociationTransportLayerAddressAMFPresent)             
                { 
                    p_local->tnl_association[num_ngran_tnl_count].\
                        bitmask |= NGAP_TNL_ASSOCIATION_ADDRESS_AT_AMF_PRESENT;

                    switch(p_ngap_ngran_tnlassociationremoveitem->\
                            tNLAssociationTransportLayerAddressAMF.t)

                    {
                        case T_ngap_CPTransportLayerInformation_endpointIPAddress:
                        {
                            p_local->tnl_association[num_ngran_tnl_count].\
                                transport_layer_at_amf.choice = NGAP_TNL_ENDPOINT_IP_ADDR;

                            NGAP_MEMCPY
                                (
                                 p_local->tnl_association[num_ngran_tnl_count].\
                                 transport_layer_at_amf.endpoint_ip_address.\
                                 transport_layer_address,
                                 p_ngap_ngran_tnlassociationremoveitem->\
                                 tNLAssociationTransportLayerAddressAMF.u.\
                                 endpointIPAddress->data,
                                 NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                                );
                            break;
                        }
                        case T_ngap_CPTransportLayerInformation_choice_Extensions:
                        {
                            p_local->tnl_association[num_ngran_tnl_count].\
                                transport_layer_at_amf.choice = 
                                NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT;

                            /* Transport layer Address at AMF--> 
                             *             fill endpoint ip address*/
                            NGAP_MEMCPY
                                (
                                 p_local->tnl_association[num_ngran_tnl_count].\
                                 transport_layer_at_amf.endpoint_ip_address_and_port.\
                                 endpoint_ip_address.transport_layer_address,
                                 p_ngap_ngran_tnlassociationremoveitem->\
                                 tNLAssociationTransportLayerAddressAMF.u.\
                                 choice_Extensions->value.u.\
                                 _ngap_CPTransportLayerInformation_ExtIEs_1->\
                                 endpointIPAddress.data,
                                 NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                                );

                            /* Transport layer Address at AMF--> fill port number*/
                            NGAP_MEMCPY
                                (
                                 p_local->tnl_association[num_ngran_tnl_count].\
                                 transport_layer_at_amf.endpoint_ip_address_and_port.\
                                 port_number,
                                 p_ngap_ngran_tnlassociationremoveitem->\
                                 tNLAssociationTransportLayerAddressAMF.u.\
                                 choice_Extensions->value.u.\
                                 _ngap_CPTransportLayerInformation_ExtIEs_1->\
                                 portNumber.data,
                                 NGAP_PORT_NUMBER_OCTET_SIZE
                                );

                            break;

                        }
                    }

                }                                                                    

                num_ngran_tnl_count++;
                p_ngran_tnl_node = p_ngran_tnl_node->next;
            }
        }
    }while(0);
    return result;

}

/***************************************************************************
 * Function Name : validate_and_fill_tnl_association_setup_list
 * Input         : p_value - pointer of asn structure
 * Output        : p_local - pointer of local strusture
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_tnl_association_setup_list
(
    ngap_AMF_TNLAssociationSetupList  *p_value,
    amf_tnl_association_setup_list_t  *p_local
)
{
    ngap_AMF_TNLAssociationSetupItem   *p_ngap_ngran_tnlassociationsetupitem      = NGAP_P_NULL;
    OSRTDListNode                           *p_ngran_tnl_node       = NGAP_P_NULL;
    ngap_map_updation_const_et              result                  = OCCURANCE;
    UInt16                                  num_ngran_tnl_count     = NGAP_ZERO;
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ngran_tnl_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO,
                    "AMF TNL Association Failed to Setup List contains no elements");
            result = INVALID_VALUE;
            break;
        }
        else if(NG_SETUP_MAX_NO_OF_TNL_ASSOCIATION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count =  p_value->count;

            while(NGAP_P_NULL != p_ngran_tnl_node)
            {
                /* Assigning to ngran tnl association remove item */
                p_ngap_ngran_tnlassociationsetupitem = 
                    (ngap_AMF_TNLAssociationSetupItem *)p_ngran_tnl_node->data;

                switch(p_ngap_ngran_tnlassociationsetupitem->\
                        aMF_TNLAssociationAddress.t)
                {
                    case T_ngap_CPTransportLayerInformation_endpointIPAddress:
                    {
                        p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                            tnl_association_address.choice = NGAP_TNL_ENDPOINT_IP_ADDR;

                        /* Transport layer Address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address.\
                             transport_layer_address,
                             p_ngap_ngran_tnlassociationsetupitem->\
                             aMF_TNLAssociationAddress.u.endpointIPAddress->\
                             data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );
                        break;
                    }/*Case for endpoint address */

                    case T_ngap_CPTransportLayerInformation_choice_Extensions:
                    {
                        p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                            tnl_association_address.choice = 
                            NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT;

                        /* Transport layer Address--> fill endpoint ip address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address_and_port.\
                             endpoint_ip_address.transport_layer_address,
                             p_ngap_ngran_tnlassociationsetupitem->\
                             aMF_TNLAssociationAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             endpointIPAddress.data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );

                        /* Transport layer Address--> fill port number*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address_and_port.\
                             port_number,
                             p_ngap_ngran_tnlassociationsetupitem->\
                             aMF_TNLAssociationAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             portNumber.data,
                             NGAP_PORT_NUMBER_OCTET_SIZE
                            );

                        /*endpoint_ip_address_and_port*/
                        break;

                    }/*Choice extension for endpoint_ip_address_and_port */
                }//endswitch
                num_ngran_tnl_count++;
                p_ngran_tnl_node = p_ngran_tnl_node->next;
            }
        }

    }while(0);   

    return result;
}

/***************************************************************************
 * Function Name : validate_and_fillassociation_failed_to_setup_list
 * Input         : p_value - pointer of asn structure
 * Output        : p_local - pointer of local strusture
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fillassociation_failed_to_setup_list
(
    ngap_TNLAssociationList                       *p_value,
    amf_tnl_association_failed_to_setup_list_t    *p_local
)
{
    ngap_TNLAssociationItem   *p_ngap_ngran_tnlassociationitem      = NGAP_P_NULL;
    OSRTDListNode                           *p_ngran_tnl_node       = NGAP_P_NULL;
    ngap_map_updation_const_et              result                  = OCCURANCE;
    UInt16                                  num_ngran_tnl_count     = NGAP_ZERO;
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ngran_tnl_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO,
                    "AMF TNL Association Failed to Setup List contains no elements");
            result = INVALID_VALUE;
            break;
        }
        else if(NG_SETUP_MAX_NO_OF_TNL_ASSOCIATION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count =  p_value->count;

            while(NGAP_P_NULL != p_ngran_tnl_node)
            {
                /* Assigning to ngran tnl association remove item */
                p_ngap_ngran_tnlassociationitem = 
                    (ngap_TNLAssociationItem *)p_ngran_tnl_node->data;

                switch(p_ngap_ngran_tnlassociationitem->\
                        tNLAssociationAddress.t)
                {
                    case T_ngap_CPTransportLayerInformation_endpointIPAddress:
                    {
                        p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                            tnl_association_address.choice = NGAP_TNL_ENDPOINT_IP_ADDR;

                        /* Transport layer Address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address.\
                             transport_layer_address,
                             p_ngap_ngran_tnlassociationitem->\
                             tNLAssociationAddress.u.endpointIPAddress->\
                             data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );
                        break;
                    }/*Case for endpoint address */

                    case T_ngap_CPTransportLayerInformation_choice_Extensions:
                    {
                        p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                            tnl_association_address.choice = 
                            NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT;

                        /* Transport layer Address--> fill endpoint ip address*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address_and_port.\
                             endpoint_ip_address.transport_layer_address,
                             p_ngap_ngran_tnlassociationitem->\
                             tNLAssociationAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             endpointIPAddress.data,
                             NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                            );

                        /* Transport layer Address--> fill port number*/
                        NGAP_MEMCPY
                            (
                             p_local->tnl_association_setup_item[num_ngran_tnl_count].\
                             tnl_association_address.endpoint_ip_address_and_port.\
                             port_number,
                             p_ngap_ngran_tnlassociationitem->\
                             tNLAssociationAddress.u.\
                             choice_Extensions->\
                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                             portNumber.data,
                             NGAP_PORT_NUMBER_OCTET_SIZE
                            );

                        /*endpoint_ip_address_and_port*/
                        break;
                    }
                    result = validate_and_fill_choice_cause_group
                        (&p_ngap_ngran_tnlassociationitem->cause,
                         (ngap_choice_cause_group_t *)p_local);      

                }/*end switch*/

                num_ngran_tnl_count++;
                p_ngran_tnl_node = p_ngran_tnl_node->next;
            }
        }

    }while(0);   

    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_UserLocationInformation
 *
 * Input:         p_value - pointer of asn structure
 *
 * Output:        p_local - pointer of local strusture
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_UserLocationInformation
(
    ngap_UserLocationInformation                *p_value,
    ngap_choice_user_location_information_t     *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL == p_value);

    do
    {
        switch(p_value->t)
        {
            /* Decode  E-UTRA user location information*/
            case  T_ngap_UserLocationInformation_userLocationInformationEUTRA:
            {
                /* decode  TAI*/

                /*Decode TAI->PLMN*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_value->u.userLocationInformationEUTRA->tAI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->eutra_user_location_information.tai.plmn_identity.plmn_id_bytes,
                        p_value->u.userLocationInformationEUTRA->tAI.pLMNIdentity.data,
                        p_value->u.userLocationInformationEUTRA->tAI.pLMNIdentity.numocts
                    );
                }

                /*decode TAI->TAC*/
                if(NGAP_TAC_OCTET_SIZE < 
                        p_value->u.userLocationInformationEUTRA->tAI.tAC.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY
                (
                    p_local->eutra_user_location_information.tai.tac.tac,
                    p_value->u.userLocationInformationEUTRA->tAI.tAC.data,
                    p_value->u.userLocationInformationEUTRA->tAI.tAC.numocts
                );

                /*Decode eutra_cgi*/

                /*decode eutra_cgi->PLMN*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                    p_value->u.userLocationInformationEUTRA->eUTRA_CGI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->eutra_user_location_information.eutra_cgi.\
                            plmn_identity.plmn_id_bytes,
                        p_value->u.userLocationInformationEUTRA->eUTRA_CGI.\
                            pLMNIdentity.data,
                        p_value->u.userLocationInformationEUTRA->eUTRA_CGI.\
                            pLMNIdentity.numocts
                    );
                }

                /*decoede eutra_cgi->cellId*/
                if(NGAP_EUTRA_CELL_IDENTITY_NUMBITS < 
                    p_value->u.userLocationInformationEUTRA->eUTRA_CGI.\
                    eUTRACellIdentity.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->eutra_user_location_information.eutra_cgi.\
                            eutra_cell_identity,
                        p_value->u.userLocationInformationEUTRA->eUTRA_CGI.\
                            eUTRACellIdentity.data,
                        NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE
                    );
                }

                /* Decode age_of_location/timeStamp*/
                if(NGAP_TRUE == 
                    p_value->u.userLocationInformationEUTRA->m.timeStampPresent)
                {
                    /*set bit mask */
                    p_local->eutra_user_location_information.bitmask |= 
                        NGAP_EUTRA_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT;

                    if(NGAP_TIME_STAMP_OCTET_SIZE < 
                        p_value->u.userLocationInformationEUTRA->timeStamp.numocts)
                    {
                        result = INVALID_VALUE;
                        break;
                    }

                    NGAP_MEMCPY
                    (
                        p_local->eutra_user_location_information.age_of_location.time_stamp,
                        p_value->u.userLocationInformationEUTRA->timeStamp.data,
                        p_value->u.userLocationInformationEUTRA->timeStamp.numocts
                    );
                }
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "Time Stamp not present");
                }

                break;
            }

            /* NR user location information */
            case T_ngap_UserLocationInformation_userLocationInformationNR:
            {
                /*Decode TAI*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_value->u.userLocationInformationNR->tAI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->nr_user_location_information.tai.plmn_identity.plmn_id_bytes,
                        p_value->u.userLocationInformationNR->tAI.pLMNIdentity.data,
                        p_value->u.userLocationInformationNR->tAI.pLMNIdentity.numocts
                    );
                }

                if(NGAP_TAC_OCTET_SIZE < 
                        p_value->u.userLocationInformationNR->tAI.tAC.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY(p_local->nr_user_location_information.tai.tac.tac,
                        p_value->u.userLocationInformationNR->tAI.tAC.data,
                        p_value->u.userLocationInformationNR->tAI.tAC.numocts);

                /* Decode NR CGI*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_value->u.userLocationInformationNR->nR_CGI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->nr_user_location_information.nr_cgi.plmn_identity.plmn_id_bytes,
                        p_value->u.userLocationInformationNR->nR_CGI.pLMNIdentity.data,
                        p_value->u.userLocationInformationNR->nR_CGI.pLMNIdentity.numocts
                    );
                }

                if(NGAP_NR_CELL_IDENTITY_NUMBITS <
                    p_value->u.userLocationInformationNR->nR_CGI.nRCellIdentity.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->nr_user_location_information.nr_cgi.nr_cell_identity,
                        p_value->u.userLocationInformationNR->nR_CGI.nRCellIdentity.data,
                        NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                    );
                }

                /* Decode age_of_location*/
                if(NGAP_TRUE ==  
                    p_value->u.userLocationInformationNR->m.timeStampPresent)
                {
                    /*set bit mask */
                    p_local->nr_user_location_information.bitmask |= 
                        NGAP_NR_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT;

                    if(NGAP_TIME_STAMP_OCTET_SIZE < 
                        p_value->u.userLocationInformationNR->timeStamp.numocts)
                    {
                        result = INVALID_VALUE;
                        break;
                    }

                    NGAP_MEMCPY
                    (
                        p_local->nr_user_location_information.age_of_location.time_stamp,
                        p_value->u.userLocationInformationNR->timeStamp.data,
                        p_value->u.userLocationInformationNR->timeStamp.numocts
                    );
                }
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "Time Stamp not present");
                }

                p_local->choice_type = /*Handover bug fixes*/ 
                    NGAP_USER_LOCATION_INFO_CHOICE_NR_USER_LOCATION_INFORMATION;

                break;
            }

            /*Decode N3IWF user location information*/
            case T_ngap_UserLocationInformation_userLocationInformationN3IWF:
            {
                if(NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS < 
                    p_value->u.userLocationInformationN3IWF->iPAddress.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->n3iwf_user_location_information.ip_address.\
                            transport_layer_address,
                        p_value->u.userLocationInformationN3IWF->iPAddress.data,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                    );
                }

                if(NGAP_PORT_NUMBER_OCTET_SIZE < 
                    p_value->u.userLocationInformationN3IWF->portNumber.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY(p_local->n3iwf_user_location_information.port_number,
                    p_value->u.userLocationInformationN3IWF->portNumber.data,
                    p_value->u.userLocationInformationN3IWF->portNumber.numocts);

                break;
            }
        }

    }while(0);

    return result; 
}

/***************************************************************************
 * Function Name : validate_and_fill_5G_S_TMSI
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_5G_S_TMSI
(
    ngap_FiveG_S_TMSI *p_value,/*ASN Buffer*/
    ngap_5g_s_tmsi_t  *p_local /*Local BUffer*/
)
{
    ngap_map_updation_const_et  result =   OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_AMF_SET_ID_NUMBITS < p_value->aMFSetID.numbits)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to validate IE aMFSetID");
        result = INVALID_VALUE;
        return result;
    }


    NGAP_MEMCPY(p_local->amf_set_id.amf_set_id,
                p_value->aMFSetID.data,
                NGAP_AMF_SET_ID_OCTET_SIZE);
   
    if(NGAP_AMF_POINTER_NUMBITS < p_value->aMFPointer.numbits)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to validate IE aMFPointer");
        result = INVALID_VALUE;
        return result;
    }

    NGAP_MEMCPY(p_local->amf_pointer.amf_pointer,
                p_value->aMFPointer.data,
                NGAP_AMF_POINTER_OCTET_SIZE);  
    
    if(NGAP_5G_TMSI_OCTET_SIZE < p_value->fiveG_TMSI.numocts)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to validate IE fiveG_TMSI");
        result = INVALID_VALUE;
        return result;
    }

    NGAP_MEMCPY(p_local->tmsi_5g,
                p_value->fiveG_TMSI.data,
                NGAP_5G_TMSI_OCTET_SIZE);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

ngap_map_updation_const_et validate_and_fill_ue_paging_identity
(
    ngap_UEPagingIdentity       *p_value,
    ngap_ue_paging_identity_t   *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    if(p_value->t == T_ngap_UEPagingIdentity_fiveG_S_TMSI)
    {
        p_local->bitmask |= UE_PAGING_IDENTITY_5G_S_TMSI_PRESENT;
        
        validate_and_fill_5G_S_TMSI
        (   
            p_value->u.fiveG_S_TMSI,
            &p_local->tmsi
        );              
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

/****************************************************************************
 * Function Name  : validate_and_fill_ie_value
 * Inputs         : 
 * Outputs        : 
 * Returns        : 
 * Description    : This function updates message map
 ****************************************************************************/
ngap_return_et validate_and_fill_ie_value
(
    ngap_message_data_t *p_ie_order_map,
    UInt32              order_index,
    UInt16              id,
    void                *p_value,
    void                *p_local
)
{
    ngap_return_et              ret_val         = NGAP_SUCCESS;
    UInt8                       counter         = NGAP_ZERO;
    SInt16                      count           = NGAP_ZERO;
    UInt8                       map_index       = NGAP_ZERO;
    UInt8                       offset_count    = NGAP_ZERO;
    UInt32                      orig_index      = NGAP_ZERO;
    ngap_bool_et                id_occurrence   = NGAP_TRUE;
    ngap_map_updation_const_et  result          = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    orig_index = order_index;

    do
    {
        /* Check if the IEs are in ORDER */
        /* Check if the IE before the present IE was optional */
        for (counter = NGAP_ZERO; counter < p_ie_order_map->max_count;
                counter++)
        {    
            /* match found in the MAP */
            if (p_ie_order_map->msg_map[counter].ie_id == id)
            {    
                map_index = counter;
                order_index = map_index;
                /* Now the counter will have the index in MAP */
                /* Note: the counter is the exact position in the MAP*/

                /* Check before the this Array index how many optinals 
                 *                      * are present in the MAP */
                for (count = (SInt16)(map_index - 1); count >= NGAP_ZERO; count--)
                {
                    if ((ngap_optional == p_ie_order_map->msg_map[count].presence)
                        && (NGAP_ZERO == p_ie_order_map->msg_map[count].occurances))
                    {    
                        /* count the absent optional*/
                        offset_count++;
                    }    
                }    

                /* Re-Calculate the correct order for only that IE */
                p_ie_order_map->msg_map[counter].order_num = 
                    (UInt8)(p_ie_order_map->msg_map[counter].order_num - 
                            offset_count);
                break;
            }    
        } /* End of for loop */

        /* Detect the wrong Order */
        if ((p_ie_order_map->msg_map[map_index].order_num == orig_index) &&
                (p_ie_order_map->msg_map[map_index].ie_id == id))
        {
            /* Duplicate Case */
            if (orig_index > map_index)
            {
                ngap_update_message_map(p_ie_order_map, WRONG_ORDER, map_index, id);
                ret_val = NGAP_FAILURE;
                break;
            }
        }
        else
        {
            ngap_update_message_map(p_ie_order_map, WRONG_ORDER, map_index, id);
            ngap_update_message_map(p_ie_order_map, OCCURANCE, map_index, id);
            ret_val = NGAP_FAILURE;
            break;
        }

        /* If wrong order is not detected and the IE is optional, update
         * the rest of the index */ 
        if (NGAP_P_NULL == p_value)
        {
            ngap_update_message_map(p_ie_order_map,DATA_MISSING,order_index,id);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(id)
        {

            case ASN1V_ngap_id_GlobalRANNodeID:
            {
                result = validate_and_fill_global_ran_node_id(
                        (ngap_GlobalRANNodeID *)p_value,
                        (ngap_global_ran_node_id_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_RANNodeName:
            {
                if(NGAP_MAX_RAN_NODE_NAME_LENGTH < NGAP_STRLEN(p_value))
                {
                    result = INVALID_VALUE;
                }
                else
                {
                    NGAP_MEMCPY(p_local, p_value, NGAP_STRLEN(p_value));
                }
                break;
            }
            
            case ASN1V_ngap_id_SupportedTAList:
            {
                result = validate_and_fill_supported_ta_list (
                        p_value,
                        (ngap_supported_ta_list_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_DefaultPagingDRX:
            {
                if(ngap_v256 < *((ngap_PagingDRX_Root *)p_value))
                {
                    result = INVALID_VALUE;
                }
                else
                {
                    /* Copy data from ASN structure to local structure */
                    *((UInt32 *)p_local) = *((ngap_PagingDRX_Root *)p_value);
                }
                break;
            }
      
            case ASN1V_ngap_id_AMFName:
            {
                if(NGAP_MAX_AMF_NAME_LENGTH < NGAP_STRLEN(p_value))
                {
                    result = INVALID_VALUE;
                }
                else
                {
                    NGAP_MEMCPY(p_local, p_value, NGAP_STRLEN(p_value));
                }
                break;
            }

            case ASN1V_ngap_id_ServedGUAMIList:
            {
                result = validate_and_fill_served_guami_list (
                        p_value,
                        (ngap_served_guami_list_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_GUAMI:
            {
                result = validate_and_fill_ie_guami(
                        p_value,
                        (ngap_guami_t *)p_local);
                break;
            }
            case ASN1V_ngap_id_RelativeAMFCapacity:
            {
                /* Copy data from ASN structure to local structure */
                *((UInt8 *)p_local) = *((ngap_RelativeAMFCapacity *)p_value);
                break;
            }

            case ASN1V_ngap_id_PLMNSupportList:
            {
                result = validate_and_fill_broadcast_plmn_list (
                        p_value,
                        (ngap_plmn_support_list_t *)p_local);
                break;
            }
            case ASN1V_ngap_id_AMF_TNLAssociationToAddList:
            {
                result = validate_and_fill_broadcast_tnl_association_to_add_list (
                        p_value,
                        (amf_tnl_association_to_add_list_t  *)p_local);
                break;
            } 
            case ASN1V_ngap_id_AMF_TNLAssociationToRemoveList:
            {
                result = validate_and_fill_tnl_association_to_remove_list (
                        p_value,
                        (amf_tnl_association_remove_list_t  *)p_local);
                break;
            }
            case ASN1V_ngap_id_AMF_TNLAssociationToUpdateList:
            {
                result = validate_and_fill_broadcast_tnl_association_to_update_list (
                        p_value,
                        (amf_tnl_association_update_list_t  *)p_local);
                break;
            }  

            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                /*Copy data from ASN strtucture to local structure*/
            	*((UInt32 *)p_local) = *((UInt32 *)((ngap_AMF_UE_NGAP_ID *)p_value));
		        break;
            }
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                /*Copy data from ASN strtucture to local structure*/
                *((UInt32 *)p_local) = *((UInt32 *)((ngap_RAN_UE_NGAP_ID *)p_value));
		        break;
            }

            case  ASN1V_ngap_id_CriticalityDiagnostics:
            {
                result = validate_and_fill_criticality_diagnostics (
                        p_value,
                        (ngap_criticality_diagnostics_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_Cause:
            {
                result = validate_and_fill_choice_cause_group (
                        p_value,
                        (ngap_choice_cause_group_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_TimeToWait:
            {
                if(ngap_v60s < *(ngap_TimeToWait_Root *)p_value)
                {
                    result = INVALID_VALUE;
                }
                else
                {
                    /* Copy data from ASN structure to local structure */
                    *((ngap_time_to_wait_et *)p_local) = 
                        *((ngap_time_to_wait_et *)p_value);
                }
                break;
            }
           
            case ASN1V_ngap_id_OldAMF:
            {
                if(NGAP_MAX_AMF_NAME_LENGTH < NGAP_STRLEN(p_value))
                {
                    result = INVALID_VALUE;
                }
                else
                {
                    NGAP_MEMCPY(p_local, p_value, NGAP_STRLEN(p_value));
                }
                break;
            }

            case ASN1V_ngap_id_RANPagingPriority:
            {
                *((UInt16 *)p_local) = *((ngap_RANPagingPriority *)p_value);
                break;
            }
            
            case ASN1V_ngap_id_NAS_PDU:
            {
                result = validate_and_fill_nas_pdu(
                            p_value,
                            (ngap_dynamic_string_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_IndexToRFSP:
            {
                if((1 < *((ngap_IndexToRFSP *)p_value)) && 
                        (*((ngap_IndexToRFSP *)p_value) < 256))
                {
                    *((UInt32 *)p_local) = *((ngap_IndexToRFSP *)p_value);
                }
                else
                {
                    result  = INVALID_VALUE;
                }
                break;
            }
            
            case ASN1V_ngap_id_UEAggregateMaximumBitRate:
            {
                result = validate_and_fill_UAMBitRate(
                            p_value,
                            (ngap_ue_aggregate_maximum_bit_rate_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_AllowedNSSAI:
            {
                result = validate_and_fill_allowed_nssai(p_value,
                          (ngap_allowed_nssai_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_UserLocationInformation:
            {
                result = validate_and_fill_UserLocationInformation(p_value,
                        (ngap_choice_user_location_information_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_FiveG_S_TMSI:
            {
                result = validate_and_fill_5G_S_TMSI(p_value,
                        (ngap_5g_s_tmsi_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceSetupListCxtRes:
            {
                result = validate_and_fill_pdu_session_resource_setup_res_list(
                            p_value,
                            (ngap_pdu_session_resource_setup_response_list_t *)p_local);                
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtRes:
            {
                result = validate_and_fill_pdu_session_resource_failed_to_setup(
                            p_value,
                            (ngap_pdu_session_resource_failed_to_setup_list_t *)p_local);
                break;
            }
            

            case ASN1V_ngap_id_PDUSessionResourceSetupListSURes:
            {
                result = validate_and_fill_pdu_session_resource_setup_res_list(
                            (ngap_PDUSessionResourceSetupListCxtRes *)p_value,
                            (ngap_pdu_session_resource_setup_response_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes:
            {
                result = validate_and_fill_pdu_session_resource_failed_to_setup(
                           (ngap_PDUSessionResourceFailedToSetupListCxtRes *) p_value,
                            (ngap_pdu_session_resource_failed_to_setup_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceSetupListCxtReq:
            {
                result = validate_and_fill_ie_pdu_session_resource_setup_req_list(
                            p_value,
                            (ngap_pdu_session_resource_setup_request_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_UE_NGAP_IDs:
            {
                result = validate_and_fill_ie_ue_ngap_id_pair(
                            p_value,
                            (ngap_ue_context_release_command_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_UE_associatedLogicalNG_connectionList:
            {
                result = validate_ue_associated_logical_ng_connection_list(
                            p_value,
                            (ngap_ue_associated_logical_ng_connection_list_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_ResetType:
            {

                result = validate_ie_reset_type(
                            p_value,
                            (ngap_reset_type *)p_local);
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceListCxtRelCpl:
            {
               result = validate_and_fill_pdu_session_resource_list(
                        p_value,
                        (ngap_pdu_session_resource_list_t *)p_local);
               break;
            }

            case ASN1V_ngap_id_PDUSessionResourceListCxtRelReq:
            {
                result = validate_and_fill_pdu_session_resource_list(
                        p_value,
                        (ngap_pdu_session_resource_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_InfoOnRecommendedCellsAndRANNodesForPaging:
            {
                result = validate_and_fill_ie_info_on_recomm_cells_and_ran_nodes_for_paging(
                        p_value,
                        (ngap_info_on_recommended_cells_and_ran_nodes_for_paging_t *)p_local
                );
                break;
            }

            case ASN1V_ngap_id_UESecurityCapabilities:
            {
                result = validate_and_fill_ie_ue_security_capabilities(
                            p_value,
                            (ngap_ue_security_capabilities_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_UERadioCapability:
            {
                result = validate_and_fill_ue_radio_cap(p_value, 
                    (ngap_dynamic_string_t *)p_local);

                break;
            }

            case ASN1V_ngap_id_UERadioCapabilityForPaging:
            {
                result = validate_and_fill_ie_ue_radio_cap_for_paging(
                            p_value,
                            (ngap_ue_radio_capability_for_paging_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_SecurityKey:
            {
                result = validate_and_fill_ie_security_key(
                           p_value,
                           (ngap_security_key_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_PDUSessionAggregateMaximumBitRate:
            {
               ((pdu_session_aggregate_maximum_bit_rate_t *)p_local)->\
                    maximum_bit_rate_dl =
                       ((ngap_PDUSessionAggregateMaximumBitRate *)p_value)->\
                       pDUSessionAggregateMaximumBitRateDL;

               ((pdu_session_aggregate_maximum_bit_rate_t *)p_local)->\
               maximum_bit_rate_ul =
                    ((ngap_PDUSessionAggregateMaximumBitRate *)p_value)->\
                    pDUSessionAggregateMaximumBitRateUL;
                
                break;
            }
           
            case ASN1V_ngap_id_UL_NGU_UP_TNLInformation:
            {
                result = validate_and_fill_ul_ngu_up_TNL_info(
                            p_value,
                            (ngap_up_transport_layer_information_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_AdditionalUL_NGU_UP_TNLInformation:
            {
                result = validate_and_fill_ul_ngu_up_TNL_info_list(
                        p_value,
                        (ngap_up_transport_layer_information_list_t *)p_local);
                break;
            }            

            case ASN1V_ngap_id_DataForwardingNotPossible:
            {
                ((data_forwarding_not_possible_t *)p_local)->\
                data_forwarding_not_possible = 
                    (UInt32)*((ngap_DataForwardingNotPossible *)p_value);
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionType:
            {
                *((pdu_session_type_et *)p_local) = 
                    (pdu_session_type_et)(*((ngap_PDUSessionType *)p_value));

                break;
            }
            
            case ASN1V_ngap_id_SecurityIndication:
            {
                result = validate_and_fill_security_ind(
                            p_value,
                            (security_indication_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_NetworkInstance:
            {
                ((ngap_network_instance_t *)p_local)->network_instance = 
                    (UInt32)*((ngap_NetworkInstance *)p_value);
                break;
            }
            
            case ASN1V_ngap_id_QosFlowSetupRequestList:
            {
                result = validate_and_fill_qos_flow_setup_req_list(
                            p_value,
                            (qos_flow_setup_req_list_t *)p_local);
                break;
            }

            case ASN1V_ngap_id_UEPagingIdentity:
            {
                result = validate_and_fill_ue_paging_identity(p_value,
                           (ngap_ue_paging_identity_t *)p_local);
                        

                break;
            }

            case ASN1V_ngap_id_PagingDRX:
            {
                *((default_paging_drx_et *)p_local) = 
                    (default_paging_drx_et)(*((ngap_PagingDRX *)p_value));
                break;
            }

            case ASN1V_ngap_id_TAIListForPaging:
            {
                result = validate_and_fill_tai_list_for_paging (
                        p_value,
                        (ngap_tai_list_for_paging_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_PagingPriority:
            {
                *((ngap_paging_priority_et *)p_local) =
                    (ngap_paging_priority_et)(*((ngap_PagingPriority *)p_value));
                break;
            }
            
            case ASN1V_ngap_id_PagingOrigin:
            {
                *((ngap_paging_origin_et *)p_local) =
                    (ngap_paging_origin_et)(*((ngap_PagingOrigin *)p_value));/*coverityFix*/
                break;
            }
            
            case ASN1V_ngap_id_AssistanceDataForPaging:
            {
                result = validate_and_fill_assistance_data_for_paging (
                        p_value,
                        (ngap_assistance_data_for_paging_t *)p_local);
                break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceSetupListSUReq:
            {
                result = validate_and_fill_ie_pdu_session_resource_setup_req_list(
                        (ngap_PDUSessionResourceSetupListCxtReq *)p_value,
                        (ngap_pdu_session_resource_setup_request_list_t *)p_local);

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceToReleaseListRelCmd:
            {
                result = validate_and_fill_pdu_session_resource_release_command
                         (
                            (ngap_PDUSessionResourceToReleaseListRelCmd * )p_value,
                            (ngap_pdu_session_resource_to_release_list_rel_cmd_t *)p_local
                         );

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceReleasedListRelRes:
            {
                result = validate_and_fill_pdu_session_resource_release_response
                    (
                     (ngap_PDUSessionResourceReleasedListRelRes *)p_value,
                     (ngap_pdu_session_resource_release_response_list_t *) p_local
                    );
                break;
            }
            
            case ASN1V_ngap_id_LocationReportingRequestType:
            {
                result = validate_and_fill_location_reporting_req_type
                        (
                            (ngap_LocationReportingRequestType *)p_value,
                            (ngap_location_reporting_req_type_t *)p_local
                        );
                break;
            }

            case ASN1V_ngap_id_CNAssistedRANTuning:
            {
                result = validate_and_fill_cn_assisted_ran_tuning
                        (
                            (ngap_CNAssistedRANTuning *)p_value,
                            (ngap_CNAssisted_ran_tuning_t *)p_local
                        );
                break;
            }
            /*HandOver_code_changes_start*/

            case ASN1V_ngap_id_NASC:
            {
                result = validate_and_fill_nas_pdu(
                        p_value,
                        (ngap_dynamic_string_t *)p_local);
                break;
            }//id nasc filling nas_pdu value
            case ASN1V_ngap_id_HandoverType:
            {
                *((ngap_handover_type_et *)p_local) =
                    (ngap_handover_type_et)(*((ngap_HandoverType *)p_value));

                break;
            }


            case ASN1V_ngap_id_TargetID:
            {
                result = validate_and_fill_TargetID
                    (
                     (ngap_TargetID *) p_value,
                     (ngap_target_id_t *)p_local
                    );
                break;
            }

            case ASN1V_ngap_id_DirectForwardingPathAvailability:
            {
                *((ngap_DirectForwardingPathAvailability_et *)p_local) =
                    (ngap_DirectForwardingPathAvailability_et)(*((ngap_DirectForwardingPathAvailability *)p_value));
                break;
            }

            case ASN1V_ngap_id_SourceToTarget_TransparentContainer:
            {
                result = validate_and_fill_src_to_target_transparent_container
                    (
                     (ngap_SourceToTarget_TransparentContainer *)p_value,
                     (ngap_src_to_target_transparent_container_t *)p_local/*Handover_changes*/
                    );       
                break;
            }

            case  ASN1V_ngap_id_PDUSessionResourceListHORqd:
            {
                result = validate_and_fill_pdu_session_resource_HO_required_list
                    (
                           (ngap_PDUSessionResourceListHORqd *)p_value,
                           (ngap_pdu_session_res_list_HO_rqd_t * )p_local
                    );
                break;
            }
            case ASN1V_ngap_id_PDUSessionResourceSetupListHOReq:
            {
                
                result = validate_and_fill_pdu_session_resource_setup_ho_request_list 
                    (
                           (ngap_PDUSessionResourceSetupListHOReq *)p_value,
                           (ngap_pdu_session_res_setup_list_HO_req_t * )p_local
                    );
                break;
            }
            case ASN1V_ngap_id_NASSecurityParametersFromNGRAN:
            {
               result = validate_and_fill_nas_security_parameter_from_ngran
                   (
                       (ngap_NASSecurityParametersFromNGRAN *)p_value,
                       (ngap_dynamic_string_t *) p_local
                   );
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceHandoverList:
            {
                result = valiate_and_fill_pdu_session_resource_handover_list
                    (
                           (ngap_PDUSessionResourceHandoverList *)p_value,
                           (ngap_pdu_session_res_ho_list_t *)p_local
                    );
                break;
            }

            case ASN1V_ngap_id_TargetToSource_TransparentContainer:
            {
                result = validate_and_fill_target_to_src_transparent_container
                        (
                          (ngap_TargetToSource_TransparentContainer *)p_value,
                           (ngap_trg_ngran_to_src_ngran_transparent_container_t *)p_local
                        );/*Handover_changes*/
                        break;
            }

            case ASN1V_ngap_id_PDUSessionResourceToReleaseListHOCmd:
            {
                result = validate_and_fill_PDUSessionResourceToReleaseListHOCmd
                         (
                               (ngap_PDUSessionResourceToReleaseListHOCmd *)p_value,
                                (ngap_pdu_session_res_to_rel_list_ho_cmd_t *)p_local
                         );

                         break;
            }

            case ASN1V_ngap_id_PDUSessionResourceAdmittedList:
            {
                result = validate_and_fill_PDUSessionResourceAdmittedList
                    (
                       (ngap_PDUSessionResourceAdmittedList *)p_value,
                       (ngap_ho_req_ack_pdu_session_res_adm_list_t *)p_local
                    );
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListHOAck: 
            {
                result = validate_and_fill_PDUSessionResourceFailedToSetupListHOAck
                            (
                               (ngap_PDUSessionResourceFailedToSetupListHOAck *)p_value,
                               (ngap_ho_req_ack_pdu_session_res_fail_list_t *)  p_local
                            );
                break;
            }

            case ASN1V_ngap_id_CoreNetworkAssistanceInformationForInactive:
            {
                result = validate_and_fill_CoreNetworkAssistanceInformationForInactive
                         (
                            (ngap_CoreNetworkAssistanceInformationForInactive *)p_value,
                            (ngap_core_network_assistance_info_for_inactive_t *)p_local
                         );
                break;
            }

            case ASN1V_ngap_id_SecurityContext:
            {
                result = validate_and_fill_security_context
                            (
                               (ngap_SecurityContext *)p_value,
                              (ngap_security_context_t *)p_local
                            );
                break;
            }

            case ASN1V_ngap_id_NewSecurityContextInd:
            {
               (*(ngap_new_security_ctx_ind_et *)p_local) =
               (ngap_new_security_ctx_ind_et )(*((ngap_NewSecurityContextInd *)p_value));
                break;
            }

            case ASN1V_ngap_id_TraceActivation:
            {
                result = validate_and_fill_trace_activation
                    (
                     (ngap_TraceActivation *)p_value,
                     (ngap_trace_activation_t *)p_local
                    );
                break;
            }
            case ASN1V_ngap_id_MaskedIMEISV:
            {
               
                NGAP_MEMCPY
                (
                    p_local,
                   ((ngap_MaskedIMEISV *)p_value)->data,
                    NGAP_MASKED_IMEISV_OCTET_SIZE
                );

                break;
            }
            case ASN1V_ngap_id_MobilityRestrictionList:
            {
                result = validate_and_fill_mobility_restriction_list
                            (
                               (ngap_MobilityRestrictionList *)p_value,
                                (ngap_mobility_restriction_list_t *)p_local
                            );
                break;
            }

            case ASN1V_ngap_id_RRCInactiveTransitionReportRequest:
            {
               (*(ngap_rrc_inactive_transition_report_req_et *) p_local) =
               (ngap_rrc_inactive_transition_report_req_et) (*((ngap_RRCInactiveTransitionReportRequest *)p_value));
                break;
            }

            case ASN1V_ngap_id_RedirectionVoiceFallback:
            {
                p_local =
                        (ngap_redirection_voice_fallback_et *)p_value;
                break;
            }


            /*HandOver_code_changes_end*/
            
            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtFail:
            {
                result = validate_and_fill_pdu_session_resource_failed_to_setup_list_ctx_fail(
                        (ngap_PDUSessionResourceFailedToSetupListCxtFail *)p_value,
                        (ngap_pdu_session_resource_failed_to_setup_list_t *)p_local);
                break;
            }
            case ASN1V_ngap_id_NGRAN_TNLAssociationToRemoveList:
            {
                result = validate_and_fill_ng_ran_tnl_remove_list
                (
                  (ngap_NGRAN_TNLAssociationToRemoveList *)p_value,
                  (ngap_tnl_association_remove_list_t *)p_local
                );
                break;
            }

            case ASN1V_ngap_id_AMF_TNLAssociationSetupList: 
            {
                result = validate_and_fill_tnl_association_setup_list
                    (
                     (ngap_AMF_TNLAssociationSetupList *)p_value,
                     (amf_tnl_association_setup_list_t *)p_local
                    );
                break;
            }
            case ASN1V_ngap_id_AMF_TNLAssociationFailedToSetupList:
            {
                result = validate_and_fillassociation_failed_to_setup_list
                    (
                     (ngap_TNLAssociationList *)p_value,
                     (amf_tnl_association_failed_to_setup_list_t *)p_local
                    );
                break;
            }
            
            default:
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Received Unknown IE");
                id_occurrence = NGAP_FALSE;
                ret_val = NGAP_FAILURE;
            }

        } /* End of switch */

        if(NGAP_TRUE == id_occurrence)
        {
            ngap_update_message_map(p_ie_order_map, OCCURANCE, order_index, id);
            
            if(INVALID_VALUE == result)
            {
                ngap_update_message_map(p_ie_order_map, INVALID_VALUE, order_index, id);
                ret_val = NGAP_FAILURE;
            }
            else if(DATA_MISSING == result)
            {
                ngap_update_message_map(p_ie_order_map, DATA_MISSING, order_index, id);
                ret_val = NGAP_FAILURE;
            }
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    
    return ret_val;
}

ngap_map_updation_const_et  ngap_decode_area_of_intrst_ran_node_list
(
    ngap_AreaOfInterestRANNodeList          *p_asn_area_of_intrst_ran_node_list,

    ngap_area_of_interest_ran_node_list_t   *p_local_area_of_intrst_ran_node_list
)
{
    ngap_AreaOfInterestRANNodeItem  *p_area_of_interest_ran_node_list_item = 
                                                                NGAP_P_NULL;

    OSRTDListNode                   *p_area_of_intrest_ran_node_list_node  = 
                                                                NGAP_P_NULL;

    UInt16                      count                             = NGAP_ZERO;
    ngap_map_updation_const_et  result                            = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn_area_of_intrst_ran_node_list);
    
    p_area_of_intrest_ran_node_list_node = 
            p_asn_area_of_intrst_ran_node_list->head;

    do
    {
        if(NGAP_ZERO == p_asn_area_of_intrst_ran_node_list->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "No List is Present");
            result = INVALID_VALUE;
            break;
        }
        
        p_local_area_of_intrst_ran_node_list->count = 
            p_asn_area_of_intrst_ran_node_list->count;

        while(NGAP_P_NULL != p_area_of_intrest_ran_node_list_node)
        {
            p_area_of_interest_ran_node_list_item = 
                p_area_of_intrest_ran_node_list_node->data;
            
            if(OCCURANCE != validate_and_fill_global_ran_node_id(
                    &p_area_of_interest_ran_node_list_item->globalRANNodeID,
                    &p_local_area_of_intrst_ran_node_list->\
                        area_of_interest_ran_node_item[count].\
                        global_ran_node_id
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode Global Ran node id");
                result = INVALID_VALUE;
                break;
            }
            
            count++;
            p_area_of_intrest_ran_node_list_node = 
                p_area_of_intrest_ran_node_list_node->next;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
    
}

ngap_map_updation_const_et ngap_decode_ng_ran_cgi
(
   ngap_NGRAN_CGI       *p_asn_ng_ran_cgi,

   ngap_ng_ran_cgi_t    *p_local_ng_ran_cgi
)
{
    ngap_map_updation_const_et  result = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_ran_cgi);
    
    if(T_ngap_NGRAN_CGI_nR_CGI == p_asn_ng_ran_cgi->t)
    {  
        /* Decode ngRAN-CGI */

        /* copy the value of choice_type */
        p_local_ng_ran_cgi->choice_type = NGAP_NR_CGI;

        if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                p_asn_ng_ran_cgi->u.nR_CGI->pLMNIdentity.numocts)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "PLMN bytes hav greater size than allowed");
            result = INVALID_VALUE;
            return result;
        }

        /* copy the plmn bytes data */
        NGAP_MEMCPY
        (
             p_local_ng_ran_cgi->nr_cgi.plmn_identity.plmn_id_bytes,
             p_asn_ng_ran_cgi->u.nR_CGI->pLMNIdentity.data,
             p_asn_ng_ran_cgi->u.nR_CGI->pLMNIdentity.numocts
        );

        /* copy the value of data */
        /* check if NGAP_NR_CELL_IDENTITY_NUMBITS is greater than or equal to the numbits filled */
        if(NGAP_NR_CELL_IDENTITY_NUMBITS <
                p_asn_ng_ran_cgi->u.nR_CGI->nRCellIdentity.numbits)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "NR cell identity has greater value than allowed");

            result = INVALID_VALUE;
            return result;
        }
        else
        {
            NGAP_MEMCPY
                (
                 p_local_ng_ran_cgi->nr_cgi.nr_cell_identity,
                 p_asn_ng_ran_cgi->u.nR_CGI->nRCellIdentity.data,
                 NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                );
        }
    }

    if(T_ngap_NGRAN_CGI_eUTRA_CGI == p_asn_ng_ran_cgi->t)
    {
        p_local_ng_ran_cgi->choice_type = NGAP_EUTRA_CGI;

        if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                p_asn_ng_ran_cgi->u.eUTRA_CGI->pLMNIdentity.numocts)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "PLMN bytes have greater size than allowed");
            result = INVALID_VALUE;
            return result;
        }

        /* copy the plmn bytes data */
        NGAP_MEMCPY
        (
            p_local_ng_ran_cgi->eutra_cgi.plmn_identity.plmn_id_bytes,
            p_asn_ng_ran_cgi->u.eUTRA_CGI->pLMNIdentity.data,
            p_asn_ng_ran_cgi->u.eUTRA_CGI->pLMNIdentity.numocts
        );

        /* check if NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE is greater than or equal to the numbits filled */
        if(NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE < 
                p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.numbits)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "EUTRA Cell identity has greater value than allowed");
            result = INVALID_VALUE;
            return result;
        }

        /* copy the value of data */
        if(p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.numbits % 8 == 0)
        {
            NGAP_MEMCPY
                (
                 p_local_ng_ran_cgi->eutra_cgi.eutra_cell_identity,
                 p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.data,
                 p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.numbits/8
                );

        }
        else
        {
            NGAP_MEMCPY
                (
                 p_local_ng_ran_cgi->eutra_cgi.eutra_cell_identity,
                 p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.data,
                 ((p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.numbits/8)+1)
                );

        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}



ngap_map_updation_const_et  ngap_decode_area_of_intrst_cell_list
(
   ngap_AreaOfInterestCellList          *p_asn_area_of_intrst_cell_list,
   ngap_area_of_interest_cell_list_t    *p_local_area_of_intrst_cell_list
)
{
    ngap_AreaOfInterestCellItem *p_area_of_interest_cell_list_item = NGAP_P_NULL;
    OSRTDListNode               *p_area_of_intrest_cell_list_node  = NGAP_P_NULL;
    UInt16                      count                             = NGAP_ZERO;
    ngap_map_updation_const_et  result                            = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn_area_of_intrst_cell_list);
    
    p_area_of_intrest_cell_list_node = p_asn_area_of_intrst_cell_list->head;

    do
    {
        if(NGAP_ZERO == p_asn_area_of_intrst_cell_list->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "No List is Present");
            result = INVALID_VALUE;
            break;
        }
        
        p_local_area_of_intrst_cell_list->count = 
            p_asn_area_of_intrst_cell_list->count;

        while(NGAP_P_NULL != p_area_of_intrest_cell_list_node)
        {
            p_area_of_interest_cell_list_item = 
                p_area_of_intrest_cell_list_node->data;
            
            if(OCCURANCE != ngap_decode_ng_ran_cgi(
                    &p_area_of_interest_cell_list_item->nGRAN_CGI,
                    &p_local_area_of_intrst_cell_list->\
                        ngap_area_of_interest_cell_item[count].\
                        ngran_cgi
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode NG RAN CGI");
                result = INVALID_VALUE;
                break;
            }
            
            count++;
            p_area_of_intrest_cell_list_node = 
                p_area_of_intrest_cell_list_node->next;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}


ngap_map_updation_const_et ngap_decode_area_of_intrst_tai_list
(
    ngap_AreaOfInterestTAIList          *p_asn_area_of_intrst_tai_list,
    ngap_area_of_interest_tai_list_t    *p_local_area_of_intrst_tai_list
)
{
    ngap_AreaOfInterestTAIItem  *p_area_of_interest_tai_list_item = NGAP_P_NULL;
    OSRTDListNode               *p_area_of_intrest_tai_list_node  = NGAP_P_NULL;
    UInt16                      count                             = NGAP_ZERO;
    ngap_map_updation_const_et  result                            = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn_area_of_intrst_tai_list);
    
    p_area_of_intrest_tai_list_node = p_asn_area_of_intrst_tai_list->head;

    do
    {
        if(NGAP_ZERO == p_asn_area_of_intrst_tai_list->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "No List is Present");
            result = INVALID_VALUE;
            break;
        }
        
        p_local_area_of_intrst_tai_list->count = 
            p_asn_area_of_intrst_tai_list->count;

        while(NGAP_P_NULL != p_area_of_intrest_tai_list_node)
        {
            p_area_of_interest_tai_list_item = 
                p_area_of_intrest_tai_list_node->data;
            
            if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_area_of_interest_tai_list_item->tAI.pLMNIdentity.numocts)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "PLMN id numocts exceeds"\
                    " max value of %d", NGAP_PLMN_IDENTITY_MAX_BYTES);

                result = INVALID_VALUE;
                break;
            }

            NGAP_MEMCPY
            (   
                p_local_area_of_intrst_tai_list->tai[count].tai.\
                            plmn_identity.plmn_id_bytes,
                p_area_of_interest_tai_list_item->tAI.\
                            pLMNIdentity.data,
                p_area_of_interest_tai_list_item->tAI.\
                            pLMNIdentity.numocts
            );

            if(NGAP_TAC_OCTET_SIZE < 
                    p_area_of_interest_tai_list_item->tAI.tAC.numocts)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "tAC numocts exceeds"\
                    " max value of %d", NGAP_TAC_OCTET_SIZE);

                result = INVALID_VALUE;
                break;
            }
            
            NGAP_MEMCPY
            (
                p_local_area_of_intrst_tai_list->tai[count].tai.tac.tac,
                p_area_of_interest_tai_list_item->tAI.tAC.data,
                p_area_of_interest_tai_list_item->tAI.tAC.numocts
            );

            count++;
            p_area_of_intrest_tai_list_node = 
                p_area_of_intrest_tai_list_node->next;
        
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
ngap_map_updation_const_et ngap_decode_area_of_interest_list
(
    ngap_AreaOfInterestList         *p_value,
    ngap_area_of_interest_list_t    *p_local
)
{
    ngap_AreaOfInterestItem         *p_value_area_of_intrst_item = NGAP_P_NULL;
    UInt16                          count                        = NGAP_ZERO;
    OSRTDListNode                   *p_area_of_intrst_list_node  = NGAP_P_NULL;
    ngap_map_updation_const_et      result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    p_area_of_intrst_list_node = p_value->head;
    
    do{

            if(p_value->count == NGAP_ZERO)
            {
                RRC_NGAP_TRACE(NGAP_INFO, "No List Present");
                result = INVALID_VALUE;
                break;
            }
            
            p_local->count = p_value->count;

            while(p_area_of_intrst_list_node != NGAP_P_NULL)
            {
                p_value_area_of_intrst_item =
                    (ngap_AreaOfInterestItem *)p_area_of_intrst_list_node->data;
                

                /*fill area of_interest*/

                /*fill area of interest tai list*/
                if(NGAP_TRUE == p_value_area_of_intrst_item->areaOfInterest.m.\
                                areaOfInterestTAIListPresent)
                {
                   p_local->area_of_interest_list_item[count].area_of_interest.\
                        bitmask |= NGAP_AREA_OF_INTEREST_TAI_LIST_PRESENT;

                   if(OCCURANCE != ngap_decode_area_of_intrst_tai_list(
                            &p_value_area_of_intrst_item->areaOfInterest.\
                                areaOfInterestTAIList,
                            &p_local->area_of_interest_list_item[count].\
                                area_of_interest.area_of_interest_tai_list
                   ))
                   {
                        RRC_NGAP_TRACE(NGAP_ERROR, "Could not Decode Area of Interest TAI List");
                        result = INVALID_VALUE;
                        break;
                   }

                }
                
                /*fill area of interest cell list*/
                if(NGAP_TRUE == p_value_area_of_intrst_item->areaOfInterest.m.\
                       areaOfInterestCellListPresent)
                {
                    p_local->area_of_interest_list_item[count].area_of_interest.\
                        bitmask |= NGAP_AREA_OF_INTEREST_CELL_LIST_PRESENT;

                    if(OCCURANCE != ngap_decode_area_of_intrst_cell_list(
                                &p_value_area_of_intrst_item->areaOfInterest.\
                                    areaOfInterestCellList,
                                &p_local->area_of_interest_list_item[count].\
                                    area_of_interest.area_of_interest_cell_list
                    ))
                    {
                        RRC_NGAP_TRACE(NGAP_ERROR, "Could not Decode Area of Interest Cell List");
                        result = INVALID_VALUE;
                        break;
                    }
                }
                
                /*fill area of interest ran node list*/
                if(NGAP_TRUE == p_value_area_of_intrst_item->areaOfInterest.m.\
                        areaOfInterestRANNodeListPresent)
                {
                    p_local->area_of_interest_list_item[count].area_of_interest.\
                        bitmask |= NGAP_AREA_OF_INTEREST_RAN_NODE_LIST_PRESENT;;

                    if(OCCURANCE != ngap_decode_area_of_intrst_ran_node_list(
                                &p_value_area_of_intrst_item->areaOfInterest.\
                                    areaOfInterestRANNodeList,
                                &p_local->area_of_interest_list_item[count].\
                                 area_of_interest.area_of_interest_ran_node_list
                    ))
                    {
                        RRC_NGAP_TRACE(NGAP_ERROR, "Could not Decode Area of Interest Ran node List");
                        result = INVALID_VALUE;
                        break;
                    }
                }

                /*fill locationReportingReferenceID */
                p_local->area_of_interest_list_item[count].\
                location_reporting_ref_id = 
                    p_value_area_of_intrst_item->locationReportingReferenceID;

                count++;
                p_area_of_intrst_list_node = p_area_of_intrst_list_node->next;
            }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

ngap_map_updation_const_et ngap_decode_expected_moving_trajectory
(
    ngap_ExpectedUEMovingTrajectory         *p_value,
    ngap_expected_moving_trajectory_list_t  *p_local
)
{
   ngap_ExpectedUEMovingTrajectoryItem      *p_expected_moving_traj_item = 
                                                                     NGAP_P_NULL;
   OSRTDListNode                            *p_expected_moving_traj_node = 
                                                                    NGAP_P_NULL;
   UInt8                                    count   = NGAP_ZERO;
   ngap_map_updation_const_et               result  = OCCURANCE;

   RRC_NGAP_UT_TRACE_ENTER();
    
   NGAP_ASSERT(NGAP_P_NULL != p_value);
   
   p_expected_moving_traj_node = p_value->head;

   do
   {
        if(p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "No List present");
            result  = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count; /*Handover bug fixes*/

        while(NGAP_P_NULL !=p_expected_moving_traj_node)
        {
            p_expected_moving_traj_item = 
              (ngap_ExpectedUEMovingTrajectoryItem *)p_expected_moving_traj_node->data;
            
            /*fill nGRAN_CGI*/
            if(OCCURANCE != ngap_decode_ng_ran_cgi(
                    &p_expected_moving_traj_item->nGRAN_CGI,
                    &p_local->expected_moving_trajectory_item[count].ran_cgi
                    
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode IE - RAN CGI");
                result = INVALID_VALUE;
                return result;
            }


            /*fill time_stayed_in_cell*/
            if(NGAP_TRUE == p_expected_moving_traj_item->m.timeStayedInCellPresent)
            {
                
                p_local->expected_moving_trajectory_item[count].bitmask |= 
                        NGAP_CNAssisted_TIME_STAYED_IN_CELL_PRESENT;

                p_local->expected_moving_trajectory_item[count].time_stayed_in_cell = 
                p_expected_moving_traj_item->timeStayedInCell;
            }
        }

   }while(0);

   RRC_NGAP_UT_TRACE_EXIT();
   return result;
}                                                                       



ngap_map_updation_const_et validate_and_fill_cn_assisted_ran_tuning
(
    ngap_CNAssistedRANTuning        *p_value,

    ngap_CNAssisted_ran_tuning_t    *p_local
)
{
    ngap_map_updation_const_et      result = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    if(NGAP_TRUE == p_value->m.expectedUEBehaviourPresent)
    {
        p_local->bitmask |= NGAP_CNAssisted_EXPECTED_UE_BEHAVIOUR_PRESENT;

        if(NGAP_TRUE == 
            p_value->expectedUEBehaviour.m.expectedUEActivityBehaviourPresent)
        {
            p_local->expected_ue_behaviour.bitmask |= 
                NGAP_CNAssisted_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT;
            
            if(NGAP_TRUE == 
                    p_value->expectedUEBehaviour.expectedUEActivityBehaviour.\
                    m.expectedActivityPeriodPresent)
            {
                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    bitmask |= 
                       NGAP_CNAssisted_EXPECTED_ACTIVITY_PERIOD_PRESENT;
                
                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    expected_activity_period = 
                p_value->expectedUEBehaviour.expectedUEActivityBehaviour.\
                    expectedActivityPeriod;
            }
            
            if(NGAP_TRUE == 
                    p_value->expectedUEBehaviour.expectedUEActivityBehaviour.\
                    m.expectedIdlePeriodPresent)
            {
                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    bitmask |= 
                    NGAP_CNAssisted_EXPECTED_IDLE_PERIOD_PRESENT;

                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    expected_idle_period = 
                    p_value->expectedUEBehaviour.expectedUEActivityBehaviour.\
                    expectedIdlePeriod;
            }
            
            if(NGAP_TRUE == 
                    p_value->expectedUEBehaviour.expectedUEActivityBehaviour.\
                    m.sourceOfUEActivityBehaviourInformationPresent)
            {
                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    bitmask |= 

                NGAP_CNAssisted_EXPECTED_SOURCE_OF_UE_ACTIVITY_BEHAVIOUR_INFORMATION;

                p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                    source_of_ue_activity_behaviour_info = 
                    (ngap_source_of_ue_activity_behaviour_info_et)p_value->\
                        expectedUEBehaviour.expectedUEActivityBehaviour.\
                            sourceOfUEActivityBehaviourInformation;
            }

        }

        if(NGAP_TRUE ==  
                p_value->expectedUEBehaviour.m.expectedHOIntervalPresent)
        {
            p_local->expected_ue_behaviour.bitmask |=
                NGAP_CNAssisted_EXPECTED_HO_INTERVAL_PRESENT;
            
            p_local->expected_ue_behaviour.expected_ho_interval = 
                (ngap_expected_ho_interval_et)p_value->expectedUEBehaviour.\
                expectedHOInterval;
        }
        
        if(NGAP_TRUE == 
                p_value->expectedUEBehaviour.m.expectedUEMobilityPresent)
        {
            p_local->expected_ue_behaviour.bitmask |=
                NGAP_CNAssisted_EXPECTED_UE_MOBILITY_PRESENT;

            p_local->expected_ue_behaviour.expected_ue_mobility = 
                (ngap_expected_ue_mobility_et)p_value->expectedUEBehaviour.\
                expectedUEMobility;
        }

        
        if(NGAP_TRUE == 
                p_value->expectedUEBehaviour.m.expectedUEMovingTrajectoryPresent)
        {
            p_local->expected_ue_behaviour.bitmask |=
                NGAP_CNAssisted_EXPECTED_MOVING_TRAJECTORY_PRESENT;
            
            if(OCCURANCE != ngap_decode_expected_moving_trajectory(
                
                &p_value->expectedUEBehaviour.expectedUEMovingTrajectory,
                &p_local->expected_ue_behaviour.expected_moving_trajectory
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode Expected UE moving Trajectory");
                result = INVALID_VALUE;
                return result;
            }
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

ngap_map_updation_const_et validate_and_fill_location_reporting_req_type
(
    ngap_LocationReportingRequestType   *p_value,
    ngap_location_reporting_req_type_t  *p_local
)
{   
    ngap_map_updation_const_et   result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    
    /*fill eventType*/
    p_local->eventType = (ngap_event_type_et)p_value->eventType;

    /*fill reportArea*/
    p_local->report_area = (ngap_report_area_et)p_value->reportArea;
    
    /*fill area_of_interest*/
    
    if(NGAP_TRUE == p_value->m.areaOfInterestListPresent)
    {
        p_local->bitmask |= 
            NGAP_AREA_OF_LIST_PRESENT;

        if(OCCURANCE != ngap_decode_area_of_interest_list(
                    &p_value->areaOfInterestList,
                    &p_local->area_of_interest
        ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to validate and decode IE - Area of Interest List");
            result = INVALID_VALUE;
            return result;
        }
    }

    /*fill location_reporting_ref_id_to_be_cancelled*/
    if(NGAP_TRUE == p_value->m.locationReportingReferenceIDToBeCancelledPresent)
    {   
        p_local->bitmask |= 
            NGAP_LOCATION_REPORTING_REFERENCE_ID_TO_BE_CANCELLED_PRESENT;
        
        p_local->location_reporting_ref_id_to_be_cancelled = 
            p_value->locationReportingReferenceIDToBeCancelled;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
 
}
/***************************************************************************
 * Function Name : validate_and_fill_assistance_data_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_assistance_data_for_paging
(
    ngap_AssistanceDataForPaging        *p_value, /* ASN Buffer */ 
    ngap_assistance_data_for_paging_t   *p_local  /* Local Buffer */
)
{
    ngap_map_updation_const_et  result           = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    if(p_value->m.assistanceDataForRecommendedCellsPresent)
    {
        p_local->bitmask |=
            ASSISTANCE_DATA_FOR_PAGING_RECOMMENDED_CELLS_PRESENT;

        result = validate_and_fill_recomm_cells_for_paging(
                &p_value->assistanceDataForRecommendedCells.\
                    recommendedCellsForPaging.recommendedCellList, 
                &p_local->assistance_data_for_recommended_cells.\
                    recommended_cells_for_paging);
    }

    if(p_value->m.pagingAttemptInformationPresent)
    {
        p_local->bitmask |=
            ASSISTANCE_DATA_FOR_PAGING_PAGING_ATTEMPT_INFO_PRESENT;

        p_local->paging_attempt_info.paging_attempt_count =
            p_value->pagingAttemptInformation.pagingAttemptCount;

        p_local->paging_attempt_info.intended_number_of_paging_attempts =
            p_value->pagingAttemptInformation.intendedNumberOfPagingAttempts;

        if(p_value->pagingAttemptInformation.m.nextPagingAreaScopePresent)
        {
            p_local->paging_attempt_info.bitmask |=
                PAGING_ATTEMPT_INFO_NEXT_PAGING_AREA_SCOPE_PRESENT;
            
            p_local->paging_attempt_info.next_paging_area_scope =
                (ngap_next_paging_area_scope_et)p_value->pagingAttemptInformation.nextPagingAreaScope;

        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_tai_list_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_tai_list_for_paging
(
    ngap_TAIListForPaging       *p_value, /* ASN Buffer */ 
    ngap_tai_list_for_paging_t  *p_local  /* Local Buffer */
)
{

    ngap_TAIListForPagingItem   *p_value_tai_list_item;
    UInt16                      count_it         = NGAP_ZERO;
    OSRTDListNode               *tai_list_node   = p_value->head; 
    ngap_map_updation_const_et  result           = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {    

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "TAI List for Paging is not present.");
        }
        else if(NGAP_PAGING_MAX_NO_OF_TAI_FOR_PAGING < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->count = p_value->count; 

            while(tai_list_node != NGAP_P_NULL)
            {
                p_value_tai_list_item = 
                    (ngap_TAIListForPagingItem *)tai_list_node->data;

                /*Decode TAI*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                    p_value_tai_list_item->tAI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->tai_list_for_paging_item[count_it].tai.\
                            plmn_identity.plmn_id_bytes,
                        p_value_tai_list_item->tAI.pLMNIdentity.data,
                        p_value_tai_list_item->tAI.pLMNIdentity.numocts
                    );
                }

                if(NGAP_TAC_OCTET_SIZE < 
                        p_value_tai_list_item->tAI.tAC.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY(p_local->tai_list_for_paging_item[count_it].tai.tac.tac,
                        p_value_tai_list_item->tAI.tAC.data,
                        p_value_tai_list_item->tAI.tAC.numocts);

                tai_list_node = tai_list_node->next;
                count_it++;
            }    
        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ul_ngu_up_TNL_info
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ul_ngu_up_TNL_info
(
    ngap_UPTransportLayerInformation        *p_value,
    ngap_up_transport_layer_information_t   *p_local
)
{
    ngap_map_updation_const_et              result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    switch(p_value->t)
    {
        case T_ngap_UPTransportLayerInformation_gTPTunnel:
        {
            p_local->choice_type = UP_TRANSPORT_LAYER_INFO_GP_TUNNEL;
            
            NGAP_MEMCPY(p_local->gtp_tunnel.transport_layer_address,
                        p_value->u.gTPTunnel->transportLayerAddress.data,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);
            
            if(NGAP_GTP_TUNNEL_TEID >= p_value->u.gTPTunnel->gTP_TEID.numocts)
            {
                /* TEID fix start*/
                p_local->gtp_tunnel.gtp_TEID =
                    (p_value->u.gTPTunnel->gTP_TEID.data[0] << 24) |
                    (p_value->u.gTPTunnel->gTP_TEID.data[1] << 16) |
                    (p_value->u.gTPTunnel->gTP_TEID.data[2] << 8) |
                    p_value->u.gTPTunnel->gTP_TEID.data[3];
                /* TEID fix end*/
            }
            else
            {
                result = INVALID_VALUE;
            }

            break;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_ul_ngu_up_TNL_info_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ul_ngu_up_TNL_info_list
(
    ngap_UPTransportLayerInformationList            *p_value,
    ngap_up_transport_layer_information_list_t      *p_local
)
{
    ngap_UPTransportLayerInformationItem    *p_up_transport_layer_info_item = NGAP_P_NULL;
    OSRTDListNode                           *p_node                        = NGAP_P_NULL;
    UInt16                                  count                          = NGAP_ZERO;
    ngap_map_updation_const_et              result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "LIST is empty");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_UP_TRANSPORT_UP_LAYER_INFORMATION_COUNT < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds max value of %d",
            NGAP_UP_TRANSPORT_UP_LAYER_INFORMATION_COUNT);
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(p_node != NGAP_P_NULL)
        {
            p_up_transport_layer_info_item =
                (ngap_UPTransportLayerInformationItem *)p_node->data;

            result = validate_and_fill_ul_ngu_up_TNL_info 
                (
                 &p_up_transport_layer_info_item->nGU_UP_TNLInformation,
                 &p_local->up_transport_layer_info[count].up_transport_layer_info
                );

            if(result == INVALID_VALUE)
            {
                RRC_NGAP_UT_TRACE_EXIT();
                return result;
            }

            p_node = p_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_security_ind
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_security_ind
(
    ngap_SecurityIndication     *p_value,
    security_indication_t       *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    /*encode integrity_protection_indication*/
    p_local->integrity_protection_indication = 
        (integrity_protection_indication_et)p_value->integrityProtectionIndication;
    
    /*encode confidentiality_protection_indication*/
    p_local->confidentiality_protection_indication = 
        (integrity_protection_indication_et)p_value->confidentialityProtectionIndication;

    /*encode maximum_integrity_protected_data_rate*/

    if(NGAP_TRUE == 
            p_value->m.maximumIntegrityProtectedDataRate_ULPresent)
    {
        p_local->bitmask |= 
            NGAP_SECURITY_INDICATION_MAX_INTEGRITY_PROTECTED_DATA_RATE_PRESENT;
        p_local->maximum_integrity_protected_data_rate = 
            (maximum_integrity_protected_data_rate_et)p_value->\
            maximumIntegrityProtectedDataRate_UL;

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_qos_flow_setup_req_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_qos_flow_setup_req_list
(
    ngap_QosFlowSetupRequestList    *p_value,
    qos_flow_setup_req_list_t       *p_local
)
{
    ngap_QosFlowSetupRequestItem    *p_value_qos_flow_item  = NGAP_P_NULL;
    UInt16                          count                   = NGAP_ZERO;
    OSRTDListNode                   *p_node                 = NGAP_P_NULL; 
    ngap_map_updation_const_et      result                  = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    p_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "QOS FLOW SETUP REQUEST LIST IS EMPTY");
            result = INVALID_VALUE;
            break;
        }
        if(MAX_QFI_DRB_PER_PDU_SESSION < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != p_node)
        {
            p_value_qos_flow_item = (ngap_QosFlowSetupRequestItem *)p_node->data;
           
            /*encode qos_flow_identifier*/
            p_local->qos_flow_item[count].qos_flow_identifier = 
                p_value_qos_flow_item->qosFlowIdentifier;

            /*encode qos_flow_level_qos_parameters*/
            result = validate_and_fill_qos_params(
                    &p_value_qos_flow_item->qosFlowLevelQosParameters,
                    &p_local->qos_flow_item[count].qos_flow_level_qos_parameters);
        
            /*encode drb_id*/
            if(p_value_qos_flow_item->m.e_RAB_IDPresent)
            {
                p_local->qos_flow_item[count].bitmask |= 
                    QOS_FLOW_SETUP_REQ_LIST_ITEM_QOS_FLOW_ID_PRESENT;

                p_local->qos_flow_item[count].drb_id = 
                    p_value_qos_flow_item->e_RAB_ID;
            }

            p_node = p_node->next;
            count++;
        }
        
    }while(0);



    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_standardized_5qi
 *
 * Input         : five_qi - Value of Received 5QI parameter
 *
 * Output        : None.
 *
 * Description   : This function takes input 5qi value and validate this 
 *                  from 23.501, Table 5.7.4-1.
 **************************************************************************/
ngap_return_et validate_standardized_5qi
(
    UInt32  five_qi
)
{
    ngap_return_et ret_val = NGAP_FAILURE;

    if((five_qi >= 1) && (five_qi <= 9))
    {
        ret_val = NGAP_SUCCESS;
    }


    return ret_val;
}

/***************************************************************************
 * Function Name : validate_and_fill_qos_params
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_qos_params
(
    ngap_QosFlowLevelQosParameters      *p_value,
    qos_flow_level_qos_parameters_t     *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    /*decode qosCharacteristics*/
    switch(p_value->qosCharacteristics.t)
    {
        case T_ngap_QosCharacteristics_nonDynamic5QI:
        {
            p_local->qos_characterstics.choice_type = 
                QOS_CHARACTERSTICS_NON_DYNAMIC_5QI_DESCRIPTOR;/*Handover bug fixes*/
           
            /*decode fiveQI*/ 

            p_local->qos_characterstics.non_dynamic_5qi_descriptor.five_qi = 
                p_value->qosCharacteristics.u.nonDynamic5QI->fiveQI;

            if(NGAP_FAILURE == 
                validate_standardized_5qi(p_local->qos_characterstics.non_dynamic_5qi_descriptor.five_qi))
            {
                /* Value of 5QI Received from AMF is not as per the 
                 * Standardized 5QI Mapping. 23.501, Table 5.7.4-1.
                 * Thus, currently gNB will not treat this as failure but start using 
                 * a default 5QI value as 7. 
                 * */
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid 5QI Value :%u Received from AMF. gNB Selected Value 7",
                    p_local->qos_characterstics.non_dynamic_5qi_descriptor.five_qi);

                p_local->qos_characterstics.non_dynamic_5qi_descriptor.five_qi = NGAP_SEVEN;
            }
            
            /*decode priorityLevelQos*/
            if(NGAP_TRUE == 
                p_value->qosCharacteristics.u.nonDynamic5QI->m.priorityLevelQosPresent)
            {
                p_local->qos_characterstics.non_dynamic_5qi_descriptor.bitmask |= 
                    NON_DYNAMIC_5QI_DISCRIPTOR_PRITORITY_LEVEL_QOS_PRESENT;

                p_local->qos_characterstics.non_dynamic_5qi_descriptor.priority_level_qos = 
                    p_value->qosCharacteristics.u.nonDynamic5QI->priorityLevelQos;
            }

            /*decode averagingWindow*/

            if(NGAP_TRUE == 
                p_value->qosCharacteristics.u.nonDynamic5QI->m.averagingWindowPresent)
            {
                p_local->qos_characterstics.non_dynamic_5qi_descriptor.bitmask |= 
                    NON_DYNAMIC_5QI_DISCRIPTOR_AVERAGE_WINDOW_PRESENT;

                p_local->qos_characterstics.non_dynamic_5qi_descriptor.average_window = 
                    p_value->qosCharacteristics.u.nonDynamic5QI->averagingWindow;

            }

            /*decode maximumDataBurstVolume*/

            if(NGAP_TRUE == 
                p_value->qosCharacteristics.u.nonDynamic5QI->m.maximumDataBurstVolumePresent)
            {

                p_local->qos_characterstics.non_dynamic_5qi_descriptor.bitmask |= 
                    NON_DYNAMIC_5QI_DISCRIPTORMAXIMUM_DATA_BURST_VOLUME_PRESENT;

                 
                p_local->qos_characterstics.non_dynamic_5qi_descriptor.max_data_burst_volume |= 
                    p_value->qosCharacteristics.u.nonDynamic5QI->maximumDataBurstVolume;
            }

            break;
        }

        case T_ngap_QosCharacteristics_dynamic5QI:
        {
            p_local->qos_characterstics.choice_type = 
               QOS_CHARACTERSTICS_DYNAMIC_5QI_DESCRIPTOR;/*Handover bug fixes*/
            
            /*decode priorityLevelQos*/
            p_local->qos_characterstics.dynamic_5qi_descriptor.priority_level_qos = 
                p_value->qosCharacteristics.u.dynamic5QI->priorityLevelQos;

            /*decode packetDelayBudget*/
            p_local->qos_characterstics.dynamic_5qi_descriptor.packet_delay_budget = 
                p_value->qosCharacteristics.u.dynamic5QI->packetDelayBudget;

            /*decode packetErrorRate*/
            p_local->qos_characterstics.dynamic_5qi_descriptor.packet_error_rate.per_scalar = 
            p_value->qosCharacteristics.u.dynamic5QI->packetErrorRate.pERScalar;
            

            p_local->qos_characterstics.dynamic_5qi_descriptor.packet_error_rate.per_exponent = 
            p_value->qosCharacteristics.u.dynamic5QI->packetErrorRate.pERExponent;


            /*decode  fiveQI*/
            if(NGAP_TRUE == p_value->qosCharacteristics.u.dynamic5QI->m.fiveQIPresent)
            {
                p_local->qos_characterstics.dynamic_5qi_descriptor.bitmask |= 
                   DYNAMIC_5QI_DISCRIPTOR_FIVE_QI_PRESENT;

                p_local->qos_characterstics.dynamic_5qi_descriptor.five_qi = 
                    p_value->qosCharacteristics.u.dynamic5QI->fiveQI;

            }
            
            /*decode delayCritical*/
            
            if(NGAP_TRUE == 
                p_value->qosCharacteristics.u.dynamic5QI->m.delayCriticalPresent)
            {
                p_local->qos_characterstics.dynamic_5qi_descriptor.bitmask |= 
                    DYNAMIC_5QI_DISCRIPTOR_DELAY_CRITICAL_PRESENT;
                p_local->qos_characterstics.dynamic_5qi_descriptor.delay_critical = 
                    (delay_critical_et)p_value->qosCharacteristics.u.dynamic5QI->\
                    delayCritical;
            }

            /*decode averagingWindow*/
            
            if(NGAP_TRUE == p_value->m.gBR_QosInformationPresent)
            {
                if(NGAP_TRUE == 
                        p_value->qosCharacteristics.u.dynamic5QI->m.averagingWindowPresent)
                {
                    p_local->qos_characterstics.dynamic_5qi_descriptor.bitmask |= 
                        DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_AVERAGE_WINDOW_PRESENT;

                    p_local->qos_characterstics.dynamic_5qi_descriptor.average_window = 
                        p_value->qosCharacteristics.u.dynamic5QI->averagingWindow;
                }
            }

            /*decode maximumDataBurstVolume*/
            if(NGAP_TRUE  == 
                p_value->qosCharacteristics.u.dynamic5QI->m.maximumDataBurstVolumePresent)
            {
                p_local->qos_characterstics.dynamic_5qi_descriptor.bitmask |= 
                   DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_MAXIMUM_DATA_BURST_VOLUME_PRESENT ;

                p_local->qos_characterstics.dynamic_5qi_descriptor.max_data_burst_volume =
                    p_value->qosCharacteristics.u.dynamic5QI->maximumDataBurstVolume;
            }
            
            break;
        }

        default:
        {
            RRC_NGAP_TRACE(NGAP_INFO, "INVVALID CHOICE FOR IE - qosCharacteristics");
            result = INVALID_VALUE;
            break;
        }
    }

    /*decode allocationAndRetentionPriority*/
    p_local->allocation_and_retention_priority.priority_level_arp = 
        p_value->allocationAndRetentionPriority.priorityLevelARP;

    p_local->allocation_and_retention_priority.pre_emption_capability = 
        (pre_emption_capability_et)p_value->allocationAndRetentionPriority.\
        pre_emptionCapability;

    p_local->allocation_and_retention_priority.pre_emption_vulnerability = 
        (pre_emption_vnerability_et)p_value->allocationAndRetentionPriority.\
        pre_emptionVulnerability;

    /*decode gBR_QosInformation*/
    if(NGAP_TRUE == p_value->m.gBR_QosInformationPresent)
    {
        p_local->bitmask |= QOS_FLOW_LEVEL_QOS_PARAM_QOS_INFORMATION_PRESENT;
        
        p_local->gbr_qos_info.max_flow_bit_rate_dl = 
            p_value->gBR_QosInformation.maximumFlowBitRateDL;

        p_local->gbr_qos_info.max_flow_bit_rate_ul = 
            p_value->gBR_QosInformation.maximumFlowBitRateUL;

        p_local->gbr_qos_info.guaranteed_flow_bit_rate_dl = 
            p_value->gBR_QosInformation.guaranteedFlowBitRateDL;

        p_local->gbr_qos_info.guaranteed_flow_bit_rate_ul = 
            p_value->gBR_QosInformation.guaranteedFlowBitRateUL;

        if(NGAP_TRUE == p_value->gBR_QosInformation.m.notificationControlPresent)
        {
            p_local->gbr_qos_info.bitmask |= 
                GBR_QOS_INFO_NOTIFICATION_CONTROL_PRESENT;
            
            p_local->gbr_qos_info.notification_control = 
                (notification_control_et)p_value->gBR_QosInformation.\
                notificationControl;
        }

        if(NGAP_TRUE == p_value->gBR_QosInformation.m.maximumPacketLossRateDLPresent)
        {
            p_local->gbr_qos_info.bitmask |= 
                GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_DL_PRESENT;

            p_local->gbr_qos_info.max_packet_loss_rate_dl =  
                p_value->gBR_QosInformation.maximumPacketLossRateDL;
        }
        
        if(NGAP_TRUE == p_value->gBR_QosInformation.m.maximumPacketLossRateULPresent)
        {
            p_local->gbr_qos_info.bitmask |= 
               GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_UL_PRESENT;

            p_local->gbr_qos_info.max_packet_loss_rate_ul =  
                p_value->gBR_QosInformation.maximumPacketLossRateUL;
        }
    }

    /*encode reflectiveQosAttribute*/
    if(NGAP_TRUE == p_value->m.reflectiveQosAttributePresent)
    {
        p_local->bitmask |= 
            QOS_FLOW_LEVEL_QOS_PARAM_REFLECTIVE_QOS_ATTRIBUTE_PRESENT;

        p_local->reflective_qos_attribute.reflective_qos_attribute = 
            (reflective_qos_attribute_et)p_value->reflectiveQosAttribute;
    }

    /*encode additionalQosFlowInformation*/
    if(NGAP_TRUE == p_value->m.additionalQosFlowInformationPresent)
    {
        p_local->bitmask |= 
            QOS_FLOW_LEVEL_QOS_PARAM_ADDITIONAL_QOS_FLOW_INFORMATION_PRESENT;

        p_local->additional_qos_flow_info.additional_qos_flow_info = 
            (additional_qos_flow_info_et)p_value->additionalQosFlowInformation;
    }
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_ue_ngap_id_pair
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_ue_ngap_id_pair
(
     ngap_UE_NGAP_IDs                    *p_value,
     ngap_ue_context_release_command_t   *p_local
)
{

    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    switch(p_value->t)
    {
        case T_ngap_UE_NGAP_IDs_uE_NGAP_ID_pair:
        {
            p_local->bitmask |= UE_CONTEXT_REL_CMD_RAN_UE_NGAP_ID_PRESENT;

            p_local->amf_ue_ngap_id =
                p_value->u.uE_NGAP_ID_pair->aMF_UE_NGAP_ID;

            p_local->ran_ue_ngap_id = 
                p_value->u.uE_NGAP_ID_pair->rAN_UE_NGAP_ID;
            
            break;
        }

        case T_ngap_UE_NGAP_IDs_aMF_UE_NGAP_ID:
        {
            p_local->amf_ue_ngap_id = p_value->u.aMF_UE_NGAP_ID;
            break;
        }

        default:
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Invalid value for ngap_id_pair");
            result = INVALID_VALUE;
            break;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_ie_reset_type
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_ie_reset_type
(
     ngap_ResetType          *p_value,
     ngap_reset_type         *p_local
)
{

    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    switch(p_value->t)
    {
        case T_ngap_ResetType_nG_Interface:
        {
            p_local->choice_type = NGAP_RESET_ALL;
            p_local->reset_all_event_id =
                (ngap_reset_all_et)p_value->u.nG_Interface;

            break;
        }

        case T_ngap_ResetType_partOfNG_Interface:
        {
            p_local->choice_type = NGAP_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST;

            result = validate_ue_associated_logical_ng_connection_list(                     
                    p_value->u.partOfNG_Interface,
                   &p_local->ue_associated_logical_ng_connection_list);

            break;
        }

        default:
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Invalid value for reset type");
            result = INVALID_VALUE;
            break;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_pdu_session_resource_failed_to_setup
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_pdu_session_resource_failed_to_setup
(
     ngap_PDUSessionResourceFailedToSetupListCxtRes      *p_value,
     ngap_pdu_session_resource_failed_to_setup_list_t    *p_local
)
{
    ngap_PDUSessionResourceFailedToSetupItemCxtRes  
        *p_value_pdu_session_resource_failed_to_setup_item;

    UInt16                      count  = NGAP_ZERO;
    ngap_map_updation_const_et  result = OCCURANCE;

    OSRTDListNode   *pdu_session_resource_failed_to_setup_node = NGAP_P_NULL;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_failed_to_setup_node  = p_value->head;

    do
    { 
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_failed_to_setup_node )
        {
            p_value_pdu_session_resource_failed_to_setup_item = 
                (ngap_PDUSessionResourceFailedToSetupItemCxtRes *)\
                    pdu_session_resource_failed_to_setup_node->data;

            /*decode pdu session id*/
            p_local->pdu_session_resource_failed_to_setup_item[count].\
                pdu_session_id.pdu_session_id = 
                p_value_pdu_session_resource_failed_to_setup_item->pDUSessionID;

            /*decode PDU Session Resource Setup Unsuccessful Transfer */
            result = ngap_decode_pdu_session_resource_setup_unsuccessful_transfer(
                    &p_value_pdu_session_resource_failed_to_setup_item->\
                        pDUSessionResourceSetupUnsuccessfulTransfer,
                    &p_local->pdu_session_resource_failed_to_setup_item[count].\
                        pdu_session_resource_setup_unsuccessful_transfer); 

            pdu_session_resource_failed_to_setup_node = 
                pdu_session_resource_failed_to_setup_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_pdu_session_resource_failed_to_setup_list_ctx_fail
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_pdu_session_resource_failed_to_setup_list_ctx_fail
(
     ngap_PDUSessionResourceFailedToSetupListCxtFail    *p_value,
     ngap_pdu_session_resource_failed_to_setup_list_t    *p_local
)
{
    ngap_PDUSessionResourceFailedToSetupItemCxtFail  
        *p_value_pdu_session_resource_failed_to_fail_item;

    UInt16                      count  = NGAP_ZERO;
    ngap_map_updation_const_et  result = OCCURANCE;

    OSRTDListNode   *pdu_session_resource_failed_to_fail_node = NGAP_P_NULL;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_failed_to_fail_node  = p_value->head;
    
    do
    { 
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_failed_to_fail_node )
        {
            p_value_pdu_session_resource_failed_to_fail_item = 
                (ngap_PDUSessionResourceFailedToSetupItemCxtFail *)\
                pdu_session_resource_failed_to_fail_node->data;

            /*decode pdu session id*/
            p_local->pdu_session_resource_failed_to_setup_item[count].\
                pdu_session_id.pdu_session_id = 
                p_value_pdu_session_resource_failed_to_fail_item->pDUSessionID;

            /*decode PDU Session Resource Setup Unsuccessful Transfer */
            result = ngap_decode_pdu_session_resource_setup_unsuccessful_transfer(
                    &p_value_pdu_session_resource_failed_to_fail_item->\
                    pDUSessionResourceSetupUnsuccessfulTransfer,
                    &p_local->pdu_session_resource_failed_to_setup_item[count].\
                    pdu_session_resource_setup_unsuccessful_transfer); 

            pdu_session_resource_failed_to_fail_node = 
                pdu_session_resource_failed_to_fail_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;


}    

/***************************************************************************
 * Function Name : ngap_decode_pdu_session_resource_setup_unsuccessful_transfer
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_unsuccessful_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t     *p_local
)
{
    ngap_PDUSessionResourceSetupUnsuccessfulTransfer    
        *pdu_session_unsuccessful_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax 
         * Error because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        pdu_session_unsuccessful_transfer = (ngap_PDUSessionResourceSetupUnsuccessfulTransfer *)
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_PDUSessionResourceSetupUnsuccessfulTransfer);

        if(NGAP_P_NULL == pdu_session_unsuccessful_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for PDU session resource setup unsuccessful transfer");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PD_ngap_PDUSessionResourceSetupUnsuccessfulTransfer
                (&asn1_ctx1, pdu_session_unsuccessful_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);

            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of PDU session resource setup unsuccessful transfer");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceSetupUnsuccessfulTransfer(
                    &asn1_ctx1,
                    "PDU_SESSION_RESOURCE_SETUP_UNSUCCESSFUL_TRANSFER_PDU", 
                    pdu_session_unsuccessful_transfer);
        }

        /* Decode message */
        
        /* Decode cause*/
        response = ngap_decode_cause(
                    &pdu_session_unsuccessful_transfer->cause,
                    &p_local->choice_cause_group);
        
        if(INVALID_VALUE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "couldn't decode cause.");
            response = INVALID_VALUE;
            break;
        }

        /*decode criticality_diagnostics*/
        if(NGAP_TRUE == 
            pdu_session_unsuccessful_transfer->m.criticalityDiagnosticsPresent)
        {
            p_local->bitmask |= 
                NGAP_PSRSUT_CIRITCALITY_DIAGNOSTICS_PRESENT;

            response = ngap_decode_criticality_diagnostics(
                        &pdu_session_unsuccessful_transfer->criticalityDiagnostics,
                        &p_local->criticality_diagnostics);
            
            if(INVALID_VALUE == response)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "couldn't decode criticality_diagnostics.");

                response = INVALID_VALUE;
                break;
            }
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/***************************************************************************
 * Function Name : ngap_decode_criticality_diagnostics
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_criticality_diagnostics
(
    ngap_CriticalityDiagnostics     *p_value,
    ngap_criticality_diagnostics_t  *p_local
)
{
    ngap_CriticalityDiagnostics_IE_Item *p_value_cd_ie_list_item; 
    UInt16                              no_of_errors_it     = NGAP_ZERO;
    ngap_map_updation_const_et          result              = OCCURANCE;

    OSRTDListNode   *cd_ie_list_node = p_value->iEsCriticalityDiagnostics.head;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_local->bitmask = NGAP_ZERO;

    if(p_value->m.procedureCodePresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CODE;
        p_local->procedure_code = (UInt8)p_value->procedureCode;
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_INFO, "Procedure Code is not present.");
        result = INVALID_VALUE;
        return result;
    }

    if(p_value->m.triggeringMessagePresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_TRIGGERING_MESSAGE;

        if(ngap_unsuccessfull_outcome < p_value->triggeringMessage)
        {
            result = INVALID_VALUE;
            return result;
        }
        else
        {    
            p_local->triggering_message_event_id = 
                (ngap_triggering_message_et)p_value->triggeringMessage; 
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Triggering Message is not present.");
        result = INVALID_VALUE;
        return result;
    }

    if(p_value->m.procedureCriticalityPresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CRITICALITY;

        if(ngap_notify < p_value->procedureCriticality)
        {
            result = INVALID_VALUE;
            return result;
        }
        else
        {    
            p_local->procedure_criticality_event_id = 
                (ngap_procedure_criticality_et)p_value->procedureCriticality;/*Handover bug fixes*/ 
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Procedure Criticality is not present.");
        result = INVALID_VALUE;
        return result;
    }

    if(p_value->m.iEsCriticalityDiagnosticsPresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_IE_LIST;

        p_local->cd_ie_list.no_of_errors = NGAP_ZERO;

        if (p_value->iEsCriticalityDiagnostics.count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, 
                "Criticality Diagnostics Information Element is not present.");
        }
        else if(MAX_CD_ERRORS < p_value->iEsCriticalityDiagnostics.count)
        {
            result = INVALID_VALUE;
            return result;
        }
        else
        {

            p_local->cd_ie_list.no_of_errors = 
                p_value->iEsCriticalityDiagnostics.count;

            while(cd_ie_list_node != NGAP_P_NULL)
            {
                p_value_cd_ie_list_item = 
                    (ngap_CriticalityDiagnostics_IE_Item *)cd_ie_list_node->data;

                if(ngap_notify < p_value_cd_ie_list_item->iECriticality)
                {
                    result = INVALID_VALUE;
                    return result;
                }    
                else
                {    
                    p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].\
                    ie_criticality =
                        (ngap_ie_criticality_et)p_value_cd_ie_list_item->iECriticality;
                }       

                p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].ie_id =
                    p_value_cd_ie_list_item->iE_ID;

                if(ngap_missing < p_value_cd_ie_list_item->typeOfError)
                {
                    result = INVALID_VALUE; 
                    return result;
                }
                else
                {    
                    p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].\
                    type_of_error = 
                        (ngap_type_of_error_et)p_value_cd_ie_list_item->typeOfError;
                }          

                cd_ie_list_node = cd_ie_list_node->next;
                no_of_errors_it++;            
            }

            if (p_local->cd_ie_list.no_of_errors != no_of_errors_it)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Wrong number of IE to be filled in Criticality Diagnostics IE");
                p_local->cd_ie_list.no_of_errors = NGAP_ZERO;
            }
        }
    }    
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
            "Criticality Diagnostics INFO ELEMENT is not present.");
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_pdu_session_resource_setup_res_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_pdu_session_resource_setup_res_list
(
    ngap_PDUSessionResourceSetupListCxtRes          *p_value,
    ngap_pdu_session_resource_setup_response_list_t *p_local
)
{

    ngap_PDUSessionResourceSetupItemCxtRes  *p_value_pdu_session_resource_setup_item;
    UInt16                      count                               = NGAP_ZERO;
    OSRTDListNode               *pdu_session_resource_setup_node    = NGAP_P_NULL; 
    ngap_map_updation_const_et  result                              = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_setup_node  = p_value->head;

    do
    {   
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_setup_node )
        {
            p_value_pdu_session_resource_setup_item = 
                (ngap_PDUSessionResourceSetupItemCxtRes *)pdu_session_resource_setup_node->data;

            /*decode pdu session id*/
            p_local->pdu_session_resource_setup_response_item[count].pdu_session_id.\
            pdu_session_id = 
                p_value_pdu_session_resource_setup_item->pDUSessionID;

            /*decode PDU Session Resource Setup  Transfer */
            result = ngap_decode_pdu_session_resource_setup_res_transfer(
                    &p_value_pdu_session_resource_setup_item->\
                        pDUSessionResourceSetupResponseTransfer,
                    &p_local->pdu_session_resource_setup_response_item[count].\
                        pdu_session_resource_setup_response_transfer);

            pdu_session_resource_setup_node = pdu_session_resource_setup_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/***************************************************************************
 * Function Name : ngap_decode_pdu_session_resource_setup_res_transfer
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_res_transfer
(
    OSDynOctStr                                             *p_value,
    ngap_pdu_session_resource_setup_response_transfer_t     *p_local
)
{
    ngap_PDUSessionResourceSetupResponseTransfer    
        *pdu_session_res_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        pdu_session_res_transfer = rtxMemAllocTypeZ(&asn1_ctx1, 
                    ngap_PDUSessionResourceSetupResponseTransfer);

        if(NGAP_P_NULL == pdu_session_res_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for PDU session resource setup res transfer");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
            asn1PD_ngap_PDUSessionResourceSetupResponseTransfer(&asn1_ctx1, 
                pdu_session_res_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of PDU session resource setup res transfer failed");

            response = INVALID_VALUE;
  
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */

            ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer(NGAP_ASN,
                    (SInt8 *)"NGAP_PDUSessionResourceSetupResponseTransfer",
                    pdu_session_res_transfer);

        }

        /* Decode message */

       /*decode qos_flow_TNL_info*/

        response = ngap_decode_qos_flow_TNL_info(
                    &pdu_session_res_transfer->dLQosFlowPerTNLInformation,
                    &p_local->qos_flow_TNL_info);

        /*decode additional_qos_flow_TNL_info */
        
        if(NGAP_TRUE ==
            pdu_session_res_transfer->m.additionalDLQosFlowPerTNLInformationPresent)
        {
            p_local->bitmask |=
                NGAP_SECURITY_RESULT_PRESENT;

            response = ngap_decode_qos_flow_TNL_info_list(
                    &pdu_session_res_transfer->additionalDLQosFlowPerTNLInformation,
                    &p_local->additional_qos_flow_TNL_info);
        }

        /*decode security_result*/
        if(NGAP_TRUE == 
            pdu_session_res_transfer->m.securityResultPresent)
        {
            p_local->bitmask |= 
                NGAP_SECURITY_RESULT_PRESENT;

            p_local->security_result.integrity_protection_result = 
                (ngap_integrity_protection_result_et)pdu_session_res_transfer->\
                    securityResult.integrityProtectionResult;

            p_local->security_result.confidentiality_protection_result = 
                (ngap_integrity_protection_result_et)pdu_session_res_transfer->\
                    securityResult.confidentialityProtectionResult;
           
        }
        
        /*decode qosFlowFailedToSetupList*/
        
        if(NGAP_TRUE == 
            pdu_session_res_transfer->m.qosFlowFailedToSetupListPresent)
        {
            p_local->bitmask |= 
               NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST;
            
            response = ngap_decode_qos_failed_to_setup_list(
                        &pdu_session_res_transfer->qosFlowFailedToSetupList,
                        &p_local->qos_flow_failed_to_setup_list);

        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
   
}

/***************************************************************************
 * Function Name : ngap_decode_qos_failed_to_setup_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_qos_failed_to_setup_list
(
    ngap_QosFlowListWithCause   *p_asn_list,
    ngap_qos_flow_list_t        *p_local_list
)
{
    ngap_map_updation_const_et  response                    = OCCURANCE;
    ngap_QosFlowWithCauseItem   *p_qos_failed_to_setup_item = NGAP_P_NULL;
    OSRTDListNode               *p_node                     = NGAP_P_NULL;
    UInt32                      index                       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn_list);
    p_node = p_asn_list->head;

    do
    {
        if(NGAP_ZERO == p_asn_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "QOS FAILED TO SETUP LIST not present.");
            response = INVALID_VALUE;
            break;
        }

        if(NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST_COUNT <
                p_asn_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Value of count exceeds max value.");
            response = INVALID_VALUE;
            break;
        }

        p_local_list->count = p_asn_list->count;

        while(NGAP_P_NULL != p_node)
        {
            p_qos_failed_to_setup_item = (ngap_QosFlowWithCauseItem *)p_node->data; 

            /*decode qosFlowIdentifier*/
            p_local_list->ngap_qos_flow_item[index].qos_flow_identifier = 
                p_qos_failed_to_setup_item->qosFlowIdentifier;

            /*decode cause*/
            response = ngap_decode_cause(
                    &p_qos_failed_to_setup_item->cause,
                    &p_local_list->ngap_qos_flow_item[index].choice_cause_group);
            
            if(INVALID_VALUE == response)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Couldn't decode ngap_Cause");
                
                response = INVALID_VALUE;
                break;
            }

            p_node = p_node->next;
            index++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/***************************************************************************
 * Function Name : ngap_decode_cause
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
 /*Handover bug fixes*/
ngap_map_updation_const_et ngap_decode_cause
(
    ngap_Cause                  *p_value,
    ngap_choice_cause_group_t   *p_local
)
{
    ngap_map_updation_const_et   result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    switch(p_value->t)
    {

        case T_ngap_Cause_radioNetwork:
        {
            if(ngap_release_due_to_cn_detected_mobility < p_value->u.radioNetwork)
            {
                RRC_NGAP_TRACE
                (
                    NGAP_WARNING, 
                    "Invalid Radio Network Layer Cause Received %d", 
                    p_value->u.radioNetwork
                );
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER;
                p_local->radio_network_layer_cause_event_id = 
                    (ngap_radio_network_layer_cause_et )p_value->u.radioNetwork;
            }
            break;
        }

        case T_ngap_Cause_transport:
        {
            if(ngap_unspecified_4 < p_value->u.transport)
            {
                RRC_NGAP_TRACE
                (
                    NGAP_WARNING, 
                    "Invalid Transport Cause Layer Received %d", 
                    p_value->u.transport
                );
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER;
                p_local->transport_layer_event_id = 
                    (ngap_transport_layer_et)p_value->u.transport;
            }
            break;
        }

        case T_ngap_Cause_nas:
        {
            if(ngap_unspecified_1 < p_value->u.nas)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid NAS Cause Received %d", p_value->u.nas);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE;
                p_local->nas_cause_event_id = (ngap_nas_cause_et)p_value->u.nas;
            }
            break;
        }

        case T_ngap_Cause_protocol:
        {
            if(ngap_unspecified_2 < p_value->u.protocol)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid Protocol Cause Received %d", p_value->u.protocol);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE;
                p_local->protocol_cause_event_id = (ngap_protocol_cause_et)p_value->u.protocol;
            }
            break;
        }

        case T_ngap_Cause_misc:
        {
            if(ngap_unspecified < p_value->u.misc)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid Misc Cause Received %d", p_value->u.misc);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE;
                p_local->miscellaneous_cause_event_id = 
                    (ngap_miscellaneous_cause_et)p_value->u.misc;
            }
            break;
        }

        default:
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "Received Unknown Cause ID %d", p_value->t);
            result = INVALID_VALUE;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/***************************************************************************
 * Function Name :ngap_decode_qos_flow_TNL_info_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_qos_flow_TNL_info_list
(
    ngap_QosFlowPerTNLInformationList       *p_value,
    ngap_dl_qos_flow_per_TNL_info_list_t    *p_local
)
{
   ngap_QosFlowPerTNLInformationItem        *p_qos_flow_per_tnl_item = NGAP_P_NULL;
   OSRTDListNode                            *p_node                  = NGAP_P_NULL;
   ngap_map_updation_const_et               result                   = OCCURANCE;
   UInt16                                   count                    = NGAP_ZERO;

   RRC_NGAP_UT_TRACE_ENTER();

   NGAP_ASSERT(NGAP_P_NULL != p_value);
   
   p_node = p_value->head;

   do
   {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "LIST is empty");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_DL_QOS_FLOW_PER_TNL_INFO_COUNT <
                p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(p_node != NGAP_P_NULL)
        {
            p_qos_flow_per_tnl_item =
                (ngap_QosFlowPerTNLInformationItem *)p_node->data;

            result = ngap_decode_qos_flow_TNL_info(
                  &p_qos_flow_per_tnl_item->qosFlowPerTNLInformation,
                    &p_local->dl_qos_flow_per_TNL_info_item[count].dl_qos_flow_per_TNL_info);

            p_node = p_node->next;
            count++;
        }

   }while(0);

   RRC_NGAP_UT_TRACE_EXIT();

   return result;
}

/***************************************************************************
 * Function Name : ngap_decode_qos_flow_TNL_info
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_qos_flow_TNL_info
(
    ngap_QosFlowPerTNLInformation           *p_value,
    ngap_dl_qos_flow_per_TNL_info_t         *p_local
)
{
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /*decode up_transport_layer_info*/
    response = validate_and_fill_ul_ngu_up_TNL_info 
        (
         &p_value->uPTransportLayerInformation,
         &p_local->up_transport_layer_info
        );

    if(response == INVALID_VALUE)
    {
        RRC_NGAP_UT_TRACE_EXIT();
        return response;
    }

    /*decode associated_qos_flow_list*/
    response = ngap_decode_associated_flow_list(&p_value->associatedQosFlowList,
            &p_local->associated_qos_flow_list);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/***************************************************************************
 * Function Name : ngap_decode_associated_flow_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_associated_flow_list
(
    ngap_AssociatedQosFlowList      *p_asn_list,
    ngap_associated_flow_list_t     *p_local_list
)
{
    ngap_map_updation_const_et  response                = OCCURANCE;
    ngap_AssociatedQosFlowItem  *p_associated_list_item = NGAP_P_NULL;
    OSRTDListNode               *p_node                 = NGAP_P_NULL;
    UInt32                      index                   = NGAP_ZERO;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_list);
    
    p_node = p_asn_list->head;

    do
    {
        if(NGAP_ZERO == p_asn_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "ASSOCIATED QOS FLOW LIST is not present");
            
            response = INVALID_VALUE;
            break;
        }

        if(NGAP_ASSOCIATED_FLOW_LIST_COUNT < p_asn_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Value of count exceeds max value.");
            response = INVALID_VALUE;
            break;
        }

        p_local_list->count = p_asn_list->count;

        while(NGAP_P_NULL != p_node)
        {
            p_associated_list_item = (ngap_AssociatedQosFlowItem *)p_node->data;

            /*decode qosFlowIdentifier*/
            p_local_list->associated_flow_item[index].qos_flow_identifier = 
                p_associated_list_item->qosFlowIdentifier;

            p_local_list->associated_flow_item[index].qos_flow_mapping_indication =
                (ngap_qos_flow_mapping_ind_et)p_associated_list_item->\
                qosFlowMappingIndication;

            p_node = p_node->next;
            index++;
        }

    }while(0);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/***************************************************************************
 * Function Name : ngap_decode_pdu_session_resource_setup_req_transfer
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_req_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local
)
{
    ngap_PDUSessionResourceSetupRequestTransfer *pdu_session_req_transfer = 
        NGAP_P_NULL;

    OSCTXT                                      asn1_ctx1;
    ngap_map_updation_const_et                  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        pdu_session_req_transfer = rtxMemAllocTypeZ(&asn1_ctx1, 
            ngap_PDUSessionResourceSetupRequestTransfer);

        if(NGAP_P_NULL == pdu_session_req_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
            pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for PDU session resource setup req transfer");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
            asn1PD_ngap_PDUSessionResourceSetupRequestTransfer(&asn1_ctx1, 
                pdu_session_req_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of PDU session resource setup req transfer");
            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer(NGAP_ASN,
                    (SInt8 *)"NGAP_PDUSessionResourceSetupRequestTransfer",
                    pdu_session_req_transfer);

        }

        /* Decode message */
        response = ng_pdu_session_res_setup_req_transfer_internal_dec(&asn1_ctx1,
                            pdu_session_req_transfer,
                            p_local);
         
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/***************************************************************************
 * Function Name : ng_pdu_session_res_setup_req_transfer_internal_dec
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ng_pdu_session_res_setup_req_transfer_internal_dec
(
    OSCTXT                                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupRequestTransfer                 *p_asn_list,
    ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local_list
)
{
    ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_element 
        *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_map_updation_const_et              ret_val             = OCCURANCE;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_list);
    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO,sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {8, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_PDUSessionAggregateMaximumBitRate, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_UL_NGU_UP_TNLInformation, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_AdditionalUL_NGU_UP_TNLInformation, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3,ASN1V_ngap_id_DataForwardingNotPossible , ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_PDUSessionType, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_SecurityIndication, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                6, ASN1V_ngap_id_NetworkInstance, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                7, ASN1V_ngap_id_QosFlowSetupRequestList, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_node = p_asn_list->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");
        return INVALID_VALUE;
    }

    for(ie_index = NGAP_ZERO; ie_index < p_asn_list->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = INVALID_VALUE;
            break;
        }

        p_protocolIE_elem =
            (ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
            ret_val = INVALID_VALUE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_ngap_id_PDUSessionAggregateMaximumBitRate:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_1,
                            (void *)&p_local_list->maximum_bit_rate))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_PDUSessionAggregateMaximumBitRate Validation failed"
                    );
                    ret_val = INVALID_VALUE;

                }
                else
                {
                    p_local_list->bitmask |=
                        PSSRT_PDU_SESSION_MAXIMUM_AGGREGATE_MAXIMUM_BIT_RATE_PRESENT;
                }

                break;
            }

            /*up_transport_layer_info*/
            case ASN1V_ngap_id_UL_NGU_UP_TNLInformation:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_2,
                            (void *)&p_local_list->up_transport_layer_info))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE2 - ASN1V_ngap_id_UL_NGU_UP_TNLInformation Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }

                break;
            }

            /*additional_up_layer_info*/
            case ASN1V_ngap_id_AdditionalUL_NGU_UP_TNLInformation:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_3,
                            (void *)&p_local_list->additional_up_layer_info))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_AdditionalUL_NGU_UP_TNLInformation Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }
                else
                {
                    p_local_list->bitmask |= 
                        PSSRT_ADDITIONAL_UP_LAYER_TRANSFER_PRESENT; 
                }

                break;
            }

            /*data_forwarding_not_possible*/
            case ASN1V_ngap_id_DataForwardingNotPossible:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_4,
                            (void *)&p_local_list->data_forwarding_not_possible))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE4 - ASN1V_ngap_id_DataForwardingNotPossible Validation failed"
                    );


                    ret_val = INVALID_VALUE;
                }
                else
                {
                    p_local_list->bitmask |= 
                        PSSRT_DATA_FORWARDING_NOT_POSSIBLE_PRESENT; 
                }

                break;
            }

            /*pdu_session_type*/
            case ASN1V_ngap_id_PDUSessionType:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_5,
                            (void *)&p_local_list->pdu_session_type))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE5 - ASN1V_ngap_id_PDUSessionType Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }

                break;
            }

            /*security_indication*/
            case ASN1V_ngap_id_SecurityIndication:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_6,
                            (void *)&p_local_list->security_indication))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE6 - ASN1V_ngap_id_SecurityIndication Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }
                else
                {
                    p_local_list->bitmask |= 
                        PSSRT_SECURITY_INDICATION_PRESENT; 
                }

                break;
            }

            /*network_instance*/
            case ASN1V_ngap_id_NetworkInstance:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_7,
                            (void *)&p_local_list->network_instance))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE7 - ASN1V_ngap_id_NetworkInstance Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }
                else
                {
                    p_local_list->bitmask |= 
                        PSSRT_NETWORK_INSTANCE_PRESENT; 
                }

                break;
            }

            /*qos_flow_setup_req_list*/
            case ASN1V_ngap_id_QosFlowSetupRequestList:
            {
                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u.\
                                _ngap_PDUSessionResourceSetupRequestTransferIEs_8,
                            (void *)&p_local_list->qos_flow_setup_req_list))
                {
                    RRC_NGAP_TRACE
                    (
                        NGAP_ERROR,
                        "IE8 - ASN1V_ngap_id_QosFlowSetupRequestList Validation failed"
                    );

                    ret_val = INVALID_VALUE;
                }
                else
                {
                    p_local_list->bitmask |=
                        PSSRT_PDU_SESSION_REQ_QOS_FLOW_SETUP_REQ_LIST_PRESENT;
                }

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Invalid id for the IE");

                ret_val = INVALID_VALUE;
                break;
            }
        }

        p_node = p_node->next;
    }

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_PDUSessionResourceSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode PDU SESSION RESOURCE SETUP REQ TRANSFER");
        ret_val = INVALID_VALUE;
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return ret_val;
}


/***************************************************************************
 * Function Name : validate_and_fill_ie_pdu_session_resource_setup_req_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_pdu_session_resource_setup_req_list
(
    ngap_PDUSessionResourceSetupListCxtReq          *p_value,
    ngap_pdu_session_resource_setup_request_list_t  *p_local
)
{
    ngap_PDUSessionResourceSetupItemCxtReq   *p_value_pdu_session_res_setup_item;
    UInt16                       count                            = NGAP_ZERO; 
    OSRTDListNode               *pdu_session_resource_setup_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                            = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_setup_node = p_value->head;
    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_setup_node)
        {
            p_value_pdu_session_res_setup_item =
                (ngap_PDUSessionResourceSetupItemCxtReq *)
                    pdu_session_resource_setup_node->data;

            /* Decode PDU Session ID */
            p_local->pdu_session_resource_setup_request_item[count].\
                pdu_session_id.pdu_session_id =
                p_value_pdu_session_res_setup_item->pDUSessionID;

            /* Decode NAS PDU */
            if(NGAP_TRUE == 
                    p_value_pdu_session_res_setup_item->m.nAS_PDUPresent)
            {
                p_local->pdu_session_resource_setup_request_item[count].bitmask |= 
                    PDU_SESSION_RESOURCE_SETUP_REQUEST_ITEM_NAS_PDU_PRESENT;

                p_local->pdu_session_resource_setup_request_item[count].\
                    nas_pdu.num_string_len =
                    p_value_pdu_session_res_setup_item->nAS_PDU.numocts;

                p_local->pdu_session_resource_setup_request_item[count].\
                    nas_pdu.string_data = 
                    (UInt8 *)rrc_mem_get(p_value_pdu_session_res_setup_item->nAS_PDU.numocts);

                if(NGAP_P_NULL == 
                    p_local->pdu_session_resource_setup_request_item[count].\
                        nas_pdu.string_data)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY
                (
                    p_local->pdu_session_resource_setup_request_item[count].\
                        nas_pdu.string_data,
                    p_value_pdu_session_res_setup_item->nAS_PDU.data,
                    p_value_pdu_session_res_setup_item->nAS_PDU.numocts
                );
            }

            /* Decode S-NSSAI */
            NGAP_MEMCPY(p_local->pdu_session_resource_setup_request_item[count].s_nssai.sst,
                    p_value_pdu_session_res_setup_item->s_NSSAI.sST.data,
                    p_value_pdu_session_res_setup_item->s_NSSAI.sST.numocts);

            if(NGAP_TRUE == 
                p_value_pdu_session_res_setup_item->s_NSSAI.m.sDPresent)
            {
                p_local->pdu_session_resource_setup_request_item[count].s_nssai.\
                    bitmask |=
                    NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT;

                NGAP_MEMCPY
                (
                    p_local->pdu_session_resource_setup_request_item[count].\
                        s_nssai.sd,
                    p_value_pdu_session_res_setup_item->s_NSSAI.sD.data,
                    p_value_pdu_session_res_setup_item->s_NSSAI.sD.numocts
                );
            }

            /* Decode pDUSessionResourceSetupRequestTransfer */
            result = ngap_decode_pdu_session_resource_setup_req_transfer
                (
                    &p_value_pdu_session_res_setup_item->\
                        pDUSessionResourceSetupRequestTransfer,
                    &p_local->pdu_session_resource_setup_request_item[count].\
                        pdu_session_resource_setup_request_transfer
                );

            /*handle result left*/

            pdu_session_resource_setup_node = pdu_session_resource_setup_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_ue_associated_logical_ng_connection_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_ue_associated_logical_ng_connection_list
(
     ngap_UE_associatedLogicalNG_connectionList      *p_value,
     ngap_ue_associated_logical_ng_connection_list_t *p_local
)
{
    ngap_UE_associatedLogicalNG_connectionItem  
        *p_value_ue_associated_logical_ng_connection_item;

    OSRTDListNode   *ue_associated_logical_ng_connection_node = NGAP_P_NULL;

    UInt16                      count = NGAP_ZERO;
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    ue_associated_logical_ng_connection_node = p_value->head;

    do
    {   
        if(NGAP_ZERO == p_value->count)

        {   
            RRC_NGAP_TRACE(NGAP_INFO, "List is empty");
            result = INVALID_VALUE;
            break;
        }

        else if(NG_RESET_MAX_NO_OF_NG_CONNECTION_TO_RESET < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != ue_associated_logical_ng_connection_node)
        {

            p_value_ue_associated_logical_ng_connection_item = 
                (ngap_UE_associatedLogicalNG_connectionItem *)\
                ue_associated_logical_ng_connection_node->data;

            /*Decode AMF UE NGAP ID */

            if(NGAP_TRUE == 
                    p_value_ue_associated_logical_ng_connection_item->m.\
                    aMF_UE_NGAP_IDPresent)
            {
                /*Set the bitmask*/
                p_local->ue_associated_logical_ng_connection_item[count].bitmask |=
                    NG_RESET_AMF_UE_NGAP_ID_PRESENT;

                /*Copy the value of aMF_UE_NGAP_ID to amf_ue_ngap_id_t*/
                p_local->ue_associated_logical_ng_connection_item[count].\
                    amf_ue_ngap_id = 
                    p_value_ue_associated_logical_ng_connection_item->aMF_UE_NGAP_ID;
            } 

            if(NGAP_TRUE == 
                p_value_ue_associated_logical_ng_connection_item->m.\
                rAN_UE_NGAP_IDPresent)
            {
                /*Set the bitmask*/
                p_local->ue_associated_logical_ng_connection_item[count].bitmask |=
                    NG_RESET_RAN_UE_NGAP_ID_PRESENT;

                /*Copy the value of rAN_UE_NGAP_ID to ran_ue_ngap_id_t*/
                p_local->ue_associated_logical_ng_connection_item[count].\
                    ran_ue_ngap_id = 
                    p_value_ue_associated_logical_ng_connection_item->rAN_UE_NGAP_ID;
            }

            ue_associated_logical_ng_connection_node = 
                ue_associated_logical_ng_connection_node->next;

            count++;
        }

    }while(0);
    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_pdu_session_resource_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_pdu_session_resource_list
(
    ngap_PDUSessionResourceListCxtRelCpl    *p_value,
    ngap_pdu_session_resource_list_t        *p_local
)
{
    ngap_PDUSessionResourceItemCxtRelCpl    *p_value_pdu_session_res_list_item;

    UInt16                      count                        = NGAP_ZERO;
    OSRTDListNode               *pdu_session_res_list_node   = NGAP_P_NULL;
    ngap_map_updation_const_et  result                       = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_res_list_node =  p_value->head;

    do
    {
        if(p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is not present");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {   
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds max value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != pdu_session_res_list_node)
            {
                p_value_pdu_session_res_list_item =
                    (ngap_PDUSessionResourceItemCxtRelCpl *)\
                    pdu_session_res_list_node->data;

                p_local->pdu_session_id[count].pdu_session_id.pdu_session_id =
                    p_value_pdu_session_res_list_item->pDUSessionID; 

                pdu_session_res_list_node = pdu_session_res_list_node->next;
                count++;
            }
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_info_on_recomm_cells_and_ran_nodes_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_info_on_recomm_cells_and_ran_nodes_for_paging
(
    ngap_InfoOnRecommendedCellsAndRANNodesForPaging             *p_value,
    ngap_info_on_recommended_cells_and_ran_nodes_for_paging_t   *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    result = validate_and_fill_recomm_cells_for_paging(
            &p_value->recommendedCellsForPaging.recommendedCellList, 
            &p_local->recommended_cells_for_paging);

    if(OCCURANCE != result)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
            "Couldn't Validate and fill Recommended cells for paging");
        return result;
    }
    result = validate_and_fill_recomm_ran_nodes_for_paging(
            &p_value->recommendRANNodesForPaging.recommendedRANNodeList,
            &p_local->recommended_ran_nodes_for_paging);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_recomm_cells_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_recomm_cells_for_paging
(
     ngap_RecommendedCellList                   *p_value,
     ngap_recommended_cells_for_paging_t        *p_local
)
{
    ngap_RecommendedCellItem    *p_value_recomm_cells_for_paging_item = NGAP_P_NULL;
    OSRTDListNode               *recomm_cells_for_paging_node         = NGAP_P_NULL;
    UInt16                      index                                 = NGAP_ZERO;
    ngap_map_updation_const_et  result                                = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    recomm_cells_for_paging_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "NO List Present");
            break;
        }
        else if(NGAP_MAX_NO_OF_RECOMMENDED_CELLS < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds Max value");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != recomm_cells_for_paging_node)
        {
            /*Set item to data of the node*/
            p_value_recomm_cells_for_paging_item = 
                (ngap_RecommendedCellItem *)recomm_cells_for_paging_node->data;

            if(T_ngap_NGRAN_CGI_nR_CGI == 
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.t)
            {  

                /* Decode ngRAN-CGI */

                /* copy the value of choice_type */
                p_local->recommended_cell_item[index].ng_ran_cgi.choice_type =
                    NGAP_NR_CGI;

                if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                    pLMNIdentity.numocts)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "PLMN bytes hav greater size than allowed");
                    result = INVALID_VALUE;
                    break;
                }

                /* copy the plmn bytes data */
                NGAP_MEMCPY
                (
                    p_local->recommended_cell_item[index].ng_ran_cgi.nr_cgi.\
                        plmn_identity.plmn_id_bytes,
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                        pLMNIdentity.data,
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                        pLMNIdentity.numocts
                );
                

                /* copy the value of data */
                /* check if NGAP_NR_CELL_IDENTITY_NUMBITS is greater than or equal to the numbits filled */
                if(NGAP_NR_CELL_IDENTITY_NUMBITS < 
                        p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                        nRCellIdentity.numbits)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "NR cell identity has greater value than allowed");
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                        (
                         p_local->recommended_cell_item[index].ng_ran_cgi.nr_cgi.\
                         nr_cell_identity,
                         p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                         nRCellIdentity.data,
                         NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                        );
                }
            }

            if(T_ngap_NGRAN_CGI_eUTRA_CGI == 
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.t)
            {
                p_local->recommended_cell_item[index].ng_ran_cgi.choice_type = 
                    NGAP_EUTRA_CGI;

                if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                    pLMNIdentity.numocts)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "PLMN bytes have greater size than allowed");
                    result = INVALID_VALUE;
                    break;
                }

                /* copy the plmn bytes data */
                NGAP_MEMCPY
                (
                    p_local->recommended_cell_item[index].ng_ran_cgi.eutra_cgi.\
                        plmn_identity.plmn_id_bytes,
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                        pLMNIdentity.data,
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                        pLMNIdentity.numocts
                );

                /* check if NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE is greater than or equal to the numbits filled */
                if(NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE < 
                    p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                    eUTRACellIdentity.numbits)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "EUTRA Cell identity has greater value than allowed");
                    result = INVALID_VALUE;
                    break;
                }

                /* copy the value of data */
                if(p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                        eUTRACellIdentity.numbits % 8 == 0)
                {
                    NGAP_MEMCPY
                        (
                         p_local->recommended_cell_item[index].ng_ran_cgi.eutra_cgi.\
                         eutra_cell_identity,
                         p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         eUTRACellIdentity.data,
                         p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         eUTRACellIdentity.numbits/8
                        );
                }
                else
                {
                    NGAP_MEMCPY
                        (
                         p_local->recommended_cell_item[index].ng_ran_cgi.eutra_cgi.\
                         eutra_cell_identity,
                         p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         eUTRACellIdentity.data,
                         ((p_value_recomm_cells_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         eUTRACellIdentity.numbits/8)+1)
                        );

                }
            }
            /* Decode timeStayedInCell */

            p_local->recommended_cell_item[index].time_stayed_in_cell = 
                p_value_recomm_cells_for_paging_item->timeStayedInCell;

            recomm_cells_for_paging_node = recomm_cells_for_paging_node->next;
            index++;

        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}

/***************************************************************************
 * Function Name : validate_and_fill_recomm_ran_nodes_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_recomm_ran_nodes_for_paging
(
     ngap_RecommendedRANNodeList             *p_value,
     ngap_recommended_ran_nodes_for_paging_t *p_local
)
{
    ngap_RecommendedRANNodeItem *p_value_recomm_ran_nodes_for_paging_item = 
        NGAP_P_NULL;

    OSRTDListNode   *recomm_ran_nodes_for_paging_node = NGAP_P_NULL;

    ngap_map_updation_const_et  result  = OCCURANCE;
    UInt16                      index   = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    recomm_ran_nodes_for_paging_node = p_value->head;

    do{
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "NO List Present");
            break;
        }
        else if(NGAP_MAX_NO_OF_RECOMMENDED_CELLS < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds Max value");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != recomm_ran_nodes_for_paging_node)
        {
            p_value_recomm_ran_nodes_for_paging_item = 
                (ngap_RecommendedRANNodeItem *)recomm_ran_nodes_for_paging_node->data;

            if(p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.t ==
                    T_ngap_AMFPagingTarget_globalRANNodeID)
            {
                /* Decode globalRANNodeID */

                p_local->recommended_ran_node_item[index].choice_type = 
                    NGAP_AMF_PAGING_TARGET_CHOICE_RAN_NODE;
                result = validate_and_fill_global_ran_node_id(
                            p_value_recomm_ran_nodes_for_paging_item->\
                                aMFPagingTarget.u.globalRANNodeID,
                            &p_local->recommended_ran_node_item[index].\
                                global_ran_node_id);
            }

            if(T_ngap_AMFPagingTarget_tAI == 
                    p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.t)
            {
                /* Decode tAI */

                p_local->recommended_ran_node_item[index].choice_type =
                    NGAP_AMF_PAGING_TARGET_CHOICE_RAN_TAI;

                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                        p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.\
                            u.tAI->pLMNIdentity.numocts)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "PLMN bytes have larger value than the max value");
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY
                (
                    p_local->recommended_ran_node_item[index].\
                        tai.plmn_identity.plmn_id_bytes,
                    p_value_recomm_ran_nodes_for_paging_item->\
                        aMFPagingTarget.u.tAI->pLMNIdentity.data,
                    p_value_recomm_ran_nodes_for_paging_item->\
                        aMFPagingTarget.u.tAI->pLMNIdentity.numocts
                );

                if(NGAP_TAC_OCTET_SIZE < 
                    p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.\
                    tAI->tAC.numocts)
                {

                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "tAC has larger value than the max value");
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY
                (
                    p_local->recommended_ran_node_item[index].tai.tac.tac,
                    p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.\
                        tAI->tAC.data,
                    p_value_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.\
                        tAI->tAC.numocts
                );

            }

            recomm_ran_nodes_for_paging_node = 
                recomm_ran_nodes_for_paging_node->next;
            index++;

        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_ue_radio_cap_for_paging
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_ue_radio_cap_for_paging
(
     ngap_UERadioCapabilityForPaging         *p_value,
     ngap_ue_radio_capability_for_paging_t   *p_local
)
{
    ngap_map_updation_const_et   result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    if(NGAP_TRUE == p_value->m.uERadioCapabilityForPagingOfNRPresent)
    {
        p_local->bitmask |= 
            UE_RADIO_CAPABILITY_FOR_PAGING_OF_NR_PRESENT;

        p_local->ue_radio_capability_for_paging_of_nr.num_string_len = 
            p_value->uERadioCapabilityForPagingOfNR.numocts;

        p_local->ue_radio_capability_for_paging_of_nr.string_data = 
            (UInt8 *)rrc_mem_get(p_value->uERadioCapabilityForPagingOfNR.numocts);

        if(NGAP_P_NULL == p_local->ue_radio_capability_for_paging_of_nr.string_data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            result = INVALID_VALUE;
            return result;
        }

        NGAP_MEMCPY(p_local->ue_radio_capability_for_paging_of_nr.string_data,
                p_value->uERadioCapabilityForPagingOfNR.data,
                p_value->uERadioCapabilityForPagingOfNR.numocts);
    }
    else if(NGAP_TRUE == p_value->m.uERadioCapabilityForPagingOfEUTRAPresent)
    {
        p_local->bitmask |=
            UE_RADIO_CAPABILITY_FOR_PAGING_OF_EUTRA_PRESENT;

        p_local->ue_radio_capability_for_paging_of_eutra.num_string_len = 
            p_value->uERadioCapabilityForPagingOfEUTRA.numocts;

        p_local->ue_radio_capability_for_paging_of_eutra.string_data = 
            (UInt8 *)rrc_mem_get(p_value->uERadioCapabilityForPagingOfEUTRA.numocts);

        if(NGAP_P_NULL == 
            p_local->ue_radio_capability_for_paging_of_eutra.string_data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            result = INVALID_VALUE;
            return result;
        }

        NGAP_MEMCPY(p_local->ue_radio_capability_for_paging_of_eutra.string_data,
                p_value->uERadioCapabilityForPagingOfEUTRA.data,
                p_value->uERadioCapabilityForPagingOfEUTRA.numocts);
    }
    else
    {
        result = INVALID_VALUE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/****************************************************************************
 * Function Name  : ngap_update_message_map
 * Inputs         : p_ie_order_map - pointer to s1ap message data 
 *                    update_type - pointer to ngap_map_updation_const_et
 *                    order_index - order num 
 *                     id - id of ie
 * Outputs        : None
 * Returns        : NGAP_SUCCESS - Map updated successfully
 *                  NGAP_FAILURE - Map not updated successfully
 * Description    : This function updates message map
 ****************************************************************************/
ngap_return_et ngap_update_message_map
(
    ngap_message_data_t		    *p_ie_order_map,
    ngap_map_updation_const_et  update_type,
    UInt32                      order_index,
    UInt16                      id
)
{
    ngap_message_map_t  *p_msg_map  = NGAP_P_NULL;
    UInt8               count       = NGAP_ZERO;
    ngap_bool_et        match_found = NGAP_FALSE;
    ngap_return_et      result      = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ie_order_map);

    p_msg_map = (ngap_message_map_t *)(p_ie_order_map->msg_map);

    do 
    {
        /* Check if we are updating the value against the correct
         * IE ID*/
        for (count = NGAP_ZERO; count < p_ie_order_map->max_count; count++)
        {
            /* Match found */
            if (id == p_ie_order_map->msg_map[count].ie_id)
            {
                order_index = count;
                match_found = NGAP_TRUE;
                break;
            }
        }

        if(NGAP_TRUE != match_found)
        {
            /* Do not update the Map */
            result = NGAP_FAILURE;
            break;
        }

        switch(update_type)
        {
            case OCCURANCE:
            {
                /* Occurance can also tell the Missing parameters */
                /* Since IE Order check has passed,
                 * We need not check here */
                p_msg_map[order_index].occurances++;
                break;
            }

            case WRONG_ORDER:
            {
                p_msg_map[order_index].wrong_order++;
                break;
            }

            case INVALID_VALUE:
            {
                p_msg_map[order_index].invalid_value_present++;
                break;
            }

            case DATA_MISSING:
            {
                p_msg_map[order_index].data_missing++;
                break;
            }

            default:
            {
                result = NGAP_FAILURE;
                /* Do Nothing */
                RRC_NGAP_TRACE(NGAP_INFO, "Invalid Operation Value given");
            }

        }

    } while(0);

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

/****************************************************************************
 * Function Name  : ngap_add_to_err_ind_ie_list
 * Inputs         : p_ie_list - pointer to list of errors 
 *                  iECriticality  - type of ngap_Criticality
 *                  iE_ID - NGAP protocol ID
 *                  p_index - pointer to index
 *                  p_send_error_indication - pointer to ngap_error_ind_bool_t
 *                  ismissing - value of type ngap_bool_et
 * Outputs        : None
 * Returns        : Nothing
 * Description    : This function adds IE to list of Error Indications
 ****************************************************************************/
void ngap_add_to_err_ind_ie_list
(
    ngap_criticality_diagnostics_ie_list_t  *p_ie_list,
    ngap_Criticality		                ie_criticality,
    ngap_ProtocolIE_ID                      ie_id,
    UInt16                                  *p_index,
    ngap_error_ind_bool_t                   *p_send_error_indication,
    ngap_bool_et                            is_missing
)
{
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ie_list);
    NGAP_ASSERT(NGAP_P_NULL != p_index);

    /* Ignore for criticality Ignore */
    if (NGAP_MAX_IES_IN_MESSAGE <= *p_index)
    {
        RRC_NGAP_TRACE(NGAP_WARNING, "Invalid Index %d", *p_index);
        return;
    }

    p_ie_list->no_of_errors++;

    p_ie_list->criticality_diagnostics_ie[*p_index].ie_criticality = 
        (ngap_ie_criticality_et) ie_criticality;

    p_ie_list->criticality_diagnostics_ie[*p_index].ie_id = ie_id;

    /* set the value according to the added IE, to keep track
     * if there is any notify IE Added to the list we have to 
     * send the Error Indication Message to MCE. */
    if (ngap_notify == ie_criticality)
    {
        p_send_error_indication->send_err_indication_notify_ie_present = NGAP_TRUE;
    }
    else if(ngap_reject == ie_criticality)
    {
        p_send_error_indication->send_err_indication_reject_ie_present = NGAP_TRUE;
    }
    else
    {
        p_send_error_indication->send_err_indication_ignore_ie_present = NGAP_TRUE;
    }

    if (NGAP_TRUE == is_missing)
    {
        p_ie_list->criticality_diagnostics_ie[*p_index].type_of_error = 
            NGAP_MISSING;
    }
    else
    {
        p_ie_list->criticality_diagnostics_ie[*p_index].type_of_error = 
            NGAP_NOT_UNDERSTOOD;
    }

    *p_index = (UInt16)(*p_index + 1);

    RRC_NGAP_UT_TRACE_EXIT();

    return;

}


/****************************************************************************
 * Function Name  : parse_ngap_message_map
 * Inputs         : p_asn1_ctx - pointer to ASN1 context
 *                  p_msg_map - pointer to the message map that needs to be 
 *                  parsed.
 *                  p_ie_list - pointer to list of errors
 *                  p_index_to_update - pointer to index where next IE is to 
 *                  be added in list of error indications to be sent in CD IE 
 *                  list.
 *                  p_send_error_indication - pointer that tells whether any 
 *                  IE was of reject or notify type.
 *                  proc_code - procedure code   
 *                  triggering_msg - message triggered 
 *                  proc_criticality - procedure criticality 
 *                  p_error_indication - pointer to memory where we need to 
 *                  fill CD if response message is present. 
 * Outputs        : None
 * Returns        : NGAP_SUCCESS - If no error was found.
 *                  NGAP_FAILURE - If error was found.
 * Description    : This function parse message map and do the processing as 
 *                  per 36.413, Section 10 description. This function along 
 *                  with NGAP FSM handling for decoding failure ensure the 
 *                  compliance with Section 10 for ASN failure related cases.
 ****************************************************************************/
ngap_return_et parse_ngap_message_map
(
    OSCTXT			                        *p_asn1_ctx,
    ngap_message_data_t                     *p_msg_map,
    ngap_criticality_diagnostics_ie_list_t	*p_ie_list,
    UInt16                                  *p_index_to_update,
    ngap_error_ind_bool_t                   *p_send_error_indication,
    UInt8                                   proc_code,
    ngap_error_indication_t                 *p_error_indication
)
{
    ngap_error_indication_t error_indication;
    UInt8		            count         = NGAP_ZERO;
    ngap_bool_et            error_present = NGAP_FALSE;
    ngap_bool_et            multiple_occurance_error_present = NGAP_FALSE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_msg_map);
    NGAP_ASSERT(NGAP_P_NULL != p_ie_list);

    NGAP_MEMSET(&error_indication, NGAP_ZERO, sizeof(ngap_error_indication_t));

    /* Unknown IE recevied in message scenario */
    if (NGAP_ZERO != p_ie_list->no_of_errors)
    {
        error_present = NGAP_TRUE;
    }

    for(count = NGAP_ZERO;count < p_msg_map->max_count;count++)
    {
        switch(p_msg_map->msg_map[count].criticality)
        {
            case ngap_reject:
            {
                if(/* Duplicate IE */
                        (p_msg_map->msg_map[count].occurances > NGAP_IE_PRESENT) ||
                        /* Invalid value */
                        (p_msg_map->msg_map[count].invalid_value_present >= 
                            NGAP_IE_PRESENT) ||
                        /* IE present in wrong order */
                        (p_msg_map->msg_map[count].wrong_order >= NGAP_IE_PRESENT))
                {
                    /* Add IE to list */
                    ngap_add_to_err_ind_ie_list(p_ie_list, 
                            p_msg_map->msg_map[count].criticality,
                            p_msg_map->msg_map[count].ie_id,
                            p_index_to_update,
                            p_send_error_indication,
                            NGAP_FALSE);

                    error_present = NGAP_TRUE;
                }
                else if(((p_msg_map->msg_map[count].occurances < NGAP_IE_PRESENT)&&
                            (p_msg_map->msg_map[count].presence == ngap_mandatory)))
                {
                    /* Add IE to list */
                    ngap_add_to_err_ind_ie_list(p_ie_list, 
                            p_msg_map->msg_map[count].criticality,
                            p_msg_map->msg_map[count].ie_id,
                            p_index_to_update,
                            p_send_error_indication,
                            NGAP_TRUE);

                    error_present = NGAP_TRUE;

                }
                else if(/* Data Missing */
                        p_msg_map->msg_map[count].data_missing >= NGAP_IE_PRESENT)
                {
                    /* Add IE to list */
                    ngap_add_to_err_ind_ie_list(p_ie_list, 
                            p_msg_map->msg_map[count].criticality,
                            p_msg_map->msg_map[count].ie_id,
                            p_index_to_update,
                            p_send_error_indication,
                            NGAP_TRUE);  /* Data Missing */

                    error_present = NGAP_TRUE;
                }
                else
                {
                    /* No error in this IE */
                    continue;
                }
                break;
            }

            case ngap_ignore:
            {
                /* In case of ignore IE
                 * we check only for wrong order 
                 * and multiple occurence of IE */
                if(/* Duplicate IE */
                        (p_msg_map->msg_map[count].occurances > NGAP_IE_PRESENT) ||
                        /* IE present in wrong order */
                        (p_msg_map->msg_map[count].wrong_order >= NGAP_IE_PRESENT)
                  )
                {
                    /* Add IE to list */
                    ngap_add_to_err_ind_ie_list(p_ie_list, 
                            p_msg_map->msg_map[count].criticality,
                            p_msg_map->msg_map[count].ie_id,
                            p_index_to_update,
                            p_send_error_indication,
                            NGAP_FALSE);

                    error_present = NGAP_TRUE;

                    multiple_occurance_error_present = NGAP_TRUE;
                }
                break;
            }

            default:
            {
                /* Invalid Criticality of IE */
                RRC_NGAP_TRACE(NGAP_ERROR, "Invalid IE Criticality Received : %d", 
                        p_msg_map->msg_map[count].criticality);
                break;
            }
        }
    }
    /* If error is detected in the received message */
    if(NGAP_TRUE == error_present)
    {
        /* if no response or failure message exists for this message,
         * send error indication from here */
        if((NGAP_FALSE == p_msg_map->successful_outcome_present) &&
                (NGAP_FALSE == p_msg_map->unsuccessful_outcome_present))
        {
            if(NGAP_TRUE ==  
                    p_send_error_indication->send_err_indication_reject_ie_present)
            {
                return NGAP_FAILURE;
            }
        }
        else
        {
            /* There exists a failure response or 
             * Criticality Diagnostics IE in response 
             */
            if(NGAP_P_NULL != p_error_indication)
            {
                RRC_NGAP_TRACE(NGAP_INFO, 
                    "Prepare Error Indication with CD to be used by NGAP FSM");

                if( p_msg_map->bitmask & ERROR_INDICATION_AMF_UE_NGAP_ID_PRESENT)
                {
                    p_error_indication->bitmask |=
                        ERROR_INDICATION_AMF_UE_NGAP_ID_PRESENT;

                    p_error_indication->amf_ue_ngap_id_t = p_msg_map->amf_ue_ngap_id;

                }
                if(p_msg_map->bitmask & ERROR_INDICATION_RAN_UE_NGAP_ID_PRESENT)
                {
                    p_error_indication->bitmask |=
                        ERROR_INDICATION_RAN_UE_NGAP_ID_PRESENT;

                    p_error_indication->ran_ue_ngap_id_t = p_msg_map->ran_ue_ngap_id;

                }

                p_error_indication->bitmask |=
                    ERROR_INDICATION_CRITICALITY_DIAGNOSTICS_PRESENT;

                /* Fill only Criticality Diagnostics IE list */
                if(NGAP_ZERO < p_ie_list->no_of_errors)
                {
                    p_error_indication->criticality_diagnostics.bitmask |=
                        NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_IE_LIST;

                    p_error_indication->criticality_diagnostics.cd_ie_list.\
                        no_of_errors =
                        p_ie_list->no_of_errors;

                    fill_criticality_diagnostics_ie_list(
                        &p_error_indication->criticality_diagnostics.cd_ie_list,
                        p_ie_list);
                }

                if(NGAP_TRUE ==  
                    p_send_error_indication->send_err_indication_reject_ie_present)
                {
                    /* Reject means we have to stop procedure as well */
                    return NGAP_FAILURE;
                } 
                else if((NGAP_TRUE == 
                    p_send_error_indication->send_err_indication_ignore_ie_present) && 
                    (NGAP_TRUE == multiple_occurance_error_present))
                {
                    return NGAP_FAILURE;
                }
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to fill Criticality Diagnostics as pointer is NULL.");
            }
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return NGAP_SUCCESS;
}


/***************************************************************************
 * Function Name : fill_criticality_diagnostics_ie_list
 *
 * Input         : p_ie_list
 *
 * Output        : p_err_ind_ie_list
 *
 * Description   : 
 **************************************************************************/
void fill_criticality_diagnostics_ie_list
(
    ngap_criticality_diagnostics_ie_list_t   *p_err_ind_ie_list,
    ngap_criticality_diagnostics_ie_list_t   *p_ie_list
) 
{
    UInt16 error_count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_err_ind_ie_list);
    NGAP_ASSERT(NGAP_P_NULL != p_ie_list);

    for(error_count = NGAP_ZERO; error_count < p_ie_list->no_of_errors; error_count++)
    {
        p_err_ind_ie_list->criticality_diagnostics_ie[error_count].ie_criticality = 
            p_ie_list->criticality_diagnostics_ie[error_count].ie_criticality;

        p_err_ind_ie_list->criticality_diagnostics_ie[error_count].ie_id = 
            p_ie_list->criticality_diagnostics_ie[error_count].ie_id;

        p_err_ind_ie_list->criticality_diagnostics_ie[error_count].type_of_error = 
            p_ie_list->criticality_diagnostics_ie[error_count].type_of_error;

    }
    
    RRC_NGAP_UT_TRACE_EXIT();
    return;
    
}

/***************************************************************************
 * Function Name : validate_and_fill_global_ran_node_id
 *
 * Input         : p_gb_ran_node_id - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_global_ran_node_id
(
    ngap_GlobalRANNodeID        *p_gb_ran_node_id,  /* ASN Buffer */
    ngap_global_ran_node_id_t   *p_local            /* Local Buffer */
)
{
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_gb_ran_node_id);

    do
    {
        switch(p_gb_ran_node_id->t)
        {

            case T_ngap_GlobalRANNodeID_globalGNB_ID:
            {
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_gb_ran_node_id->u.globalGNB_ID->pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {

                    p_local->choice_type = NGAP_GLOBAL_RAN_NODE_CHOICE_GNB_ID;/*Handover bug fixes*/
                    NGAP_MEMCPY(p_local->global_gnb_id.plmn_identity.plmn_id_bytes, 
                        p_gb_ran_node_id->u.globalGNB_ID->pLMNIdentity.data, 
                        p_gb_ran_node_id->u.globalGNB_ID->pLMNIdentity.numocts);
                }   

                if(NGAP_GNB_ID_MAX_NUMBITS < 
                    p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }    
                else
                {
                    /*Handover bug fixes*/
                    p_local->global_gnb_id.gnb_id.num_gnb_id_bits =
                        p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits;

                    if(p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits % 8 == 0)
                    {
                        NGAP_MEMCPY(p_local->global_gnb_id.gnb_id.gnb_id_bytes, 
                                p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->data, 
                                p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits/8);
                    }
                    else
                    {
                        NGAP_MEMCPY(p_local->global_gnb_id.gnb_id.gnb_id_bytes, 
                                p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->data, 
                                ((p_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits/8)+1));
                    }
                }

                break;
            }

            case T_ngap_GlobalRANNodeID_globalNgENB_ID:
            {
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_gb_ran_node_id->u.globalNgENB_ID->pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {

              p_local->choice_type = NGAP_GLOBAL_RAN_NODE_CHOICE_NG_ENB_ID;/*Handover bug fixes*/
                    NGAP_MEMCPY(p_local->global_ng_enb_id.plmn_identity.plmn_id_bytes,
                        p_gb_ran_node_id->u.globalNgENB_ID->pLMNIdentity.data, 
                        p_gb_ran_node_id->u.globalNgENB_ID->pLMNIdentity.numocts);
                }  

                switch(p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.t)
                {
                    case T_ngap_NgENB_ID_macroNgENB_ID:
                    {
                        if(NGAP_MACRO_NG_ENB_ID_OCTET_SIZE < 
                            p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                            macroNgENB_ID->numbits)
                        {
                            p_local->global_ng_enb_id.choice_type = 
                                GLOBAL_NG_ENB_CHOICE_MACRO_ID;/*Handover bug fixes*/

                            if(p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                    macroNgENB_ID->numbits % 8 == 0)
                            {
                                NGAP_MEMCPY(p_local->global_ng_enb_id.macro_ng_enb_id,
                                        p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                        macroNgENB_ID->data,
                                        p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                        macroNgENB_ID->numbits/8);
                            }
                            else
                            {
                                NGAP_MEMCPY(p_local->global_ng_enb_id.macro_ng_enb_id,
                                        p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                        macroNgENB_ID->data,
                                        ((p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                        macroNgENB_ID->numbits/8)+1));
                            }
                        } 
                        break;   
                    }

                    case T_ngap_NgENB_ID_shortMacroNgENB_ID:
                    {
                        if(NGAP_SHORT_MACRO_NG_ENB_ID_OCTET_SIZE < 
                            p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                            shortMacroNgENB_ID->numbits)
                        {
                            p_local->global_ng_enb_id.choice_type = 
                                GLOBAL_NG_ENB_CHOICE_SHORT_MACRO_ID;
                            if(p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                    shortMacroNgENB_ID->numbits % 8 == 0)
                            {
                                NGAP_MEMCPY
                                    (
                                     p_local->global_ng_enb_id.short_macro_ng_enb_id,
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     shortMacroNgENB_ID->data,
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     shortMacroNgENB_ID->numbits/8
                                    );
                            }
                            else
                            {
                                NGAP_MEMCPY
                                    (
                                     p_local->global_ng_enb_id.short_macro_ng_enb_id,
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     shortMacroNgENB_ID->data,
                                     ((p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     shortMacroNgENB_ID->numbits/8)+1)
                                    );
                            }
                        }    
                        break;
                    }

                    case T_ngap_NgENB_ID_longMacroNgENB_ID:
                    {
                        if(NGAP_LONG_MACRO_NG_ENB_ID_OCTET_SIZE < 
                            p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                            longMacroNgENB_ID->numbits)
                        {
                            p_local->global_ng_enb_id.choice_type = 
                                GLOBAL_NG_ENB_CHOICE_LONG_MACRO_ID;/*Handover bug fixes*/

                            if(p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                    longMacroNgENB_ID->numbits % 8 == 0)
                            {
                                NGAP_MEMCPY
                                    (
                                     p_local->global_ng_enb_id.long_macro_ng_enb_id,
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     longMacroNgENB_ID->data, 
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     longMacroNgENB_ID->numbits/8
                                    );
                            }
                            else
                            {
                                NGAP_MEMCPY
                                    (
                                     p_local->global_ng_enb_id.long_macro_ng_enb_id,
                                     p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     longMacroNgENB_ID->data, 
                                     ((p_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                                     longMacroNgENB_ID->numbits/8)+1)
                                    );
                            }
                        }    
                        break;
                    }
                } 
                break;   
            }

            case T_ngap_GlobalRANNodeID_globalN3IWF_ID:
            {
                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_gb_ran_node_id->u.globalN3IWF_ID->pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {

                    p_local->choice_type = NGAP_GLOBAL_RAN_NODE_CHOICE_N3IWF_ID;/*Handover bug fixes*/
                    NGAP_MEMCPY(p_local->global_n3iwf_id.plmn_identity.plmn_id_bytes, 
                            p_gb_ran_node_id->u.globalN3IWF_ID->pLMNIdentity.data, 
                            p_gb_ran_node_id->u.globalN3IWF_ID->pLMNIdentity.numocts);
                }  

                if(NGAP_N3IWF_ID_OCTET_SIZE < 
                    p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }   
                else
                {
                    if(p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->numbits % 8 == 0)
                    {
                        NGAP_MEMCPY(p_local->global_n3iwf_id.n3iwf_id, 
                                p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->data, 
                                p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->numbits/8);
                    }
                    else
                    {
                        NGAP_MEMCPY(p_local->global_n3iwf_id.n3iwf_id, 
                                p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->data, 
                                ((p_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->numbits/8)+1));
                    }
                }
                break;
            }

        }
    }while(0);        

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
 
/***************************************************************************
 * Function Name : validate_and_fill_choice_cause_group
 *
 * Input         : p_cause - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_choice_cause_group 
(
 ngap_Cause                  *p_cause, /* ASN Buffer */
 ngap_choice_cause_group_t   *p_local  /* Local Buffer */
)
{
/*Handover bug fixes*/
    ngap_map_updation_const_et  result = OCCURANCE;
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_cause);

    p_local->choice_type = NGAP_ZERO;

    switch(p_cause->t)
    {

        case T_ngap_Cause_radioNetwork:
        {
            if(ngap_release_due_to_cn_detected_mobility < p_cause->u.radioNetwork)
            {
                RRC_NGAP_TRACE
                (
                    NGAP_WARNING, 
                    "Invalid Radio Network Layer Cause Received %d", 
                    p_cause->u.radioNetwork
                );

                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER;
                p_local->radio_network_layer_cause_event_id = 
                    (ngap_radio_network_layer_cause_et )p_cause->u.radioNetwork;
            }
            break;
        }

        case T_ngap_Cause_transport:
        {
            if(ngap_unspecified_4 < p_cause->u.transport)
            {
                RRC_NGAP_TRACE
                (
                    NGAP_WARNING, 
                    "Invalid Transport Cause Layer Received %d", 
                    p_cause->u.transport
                );

                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER;
                p_local->transport_layer_event_id = 
                    (ngap_transport_layer_et)p_cause->u.transport;
            }
            break;
        }

        case T_ngap_Cause_nas:
        {
            if(ngap_unspecified_1 < p_cause->u.nas)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid NAS Cause Received %d", p_cause->u.nas);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE;
                p_local->nas_cause_event_id = (ngap_nas_cause_et)p_cause->u.nas;
            }
            break;
        }

        case T_ngap_Cause_protocol:
        {
            if(ngap_unspecified_2 < p_cause->u.protocol)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid Protocol Cause Received %d", p_cause->u.protocol);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE;
                p_local->protocol_cause_event_id = 
                    (ngap_protocol_cause_et)p_cause->u.protocol;
            }
            break;
        }

        case T_ngap_Cause_misc:
        {
            if(ngap_unspecified < p_cause->u.misc)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Invalid Misc Cause Received %d", p_cause->u.misc);
                result = INVALID_VALUE;
            }
            else
            {
                p_local->choice_type = NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE;
                p_local->miscellaneous_cause_event_id = 
                    (ngap_miscellaneous_cause_et)p_cause->u.misc;
            }
            break;
        }

        default:
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "Received Unknown Cause ID %d", p_cause->t);
            result = INVALID_VALUE;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_criticality_diagnostics
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_criticality_diagnostics 
(
    ngap_CriticalityDiagnostics      *p_value, /* ASN Buffer */
    ngap_criticality_diagnostics_t   *p_local  /* Local Buffer */
)
{

    ngap_CriticalityDiagnostics_IE_Item *p_value_cd_ie_list_item; 
    UInt16                      no_of_errors_it     = NGAP_ZERO;
    OSRTDListNode               *cd_ie_list_node    = 
        p_value->iEsCriticalityDiagnostics.head; 
    ngap_map_updation_const_et  result              = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_local->bitmask = NGAP_ZERO;

    if(p_value->m.procedureCodePresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CODE;
        p_local->procedure_code = (UInt8)p_value->procedureCode;
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_INFO, "Procedure Code is not present.");
    }

    if(p_value->m.triggeringMessagePresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_TRIGGERING_MESSAGE;

        if(ngap_unsuccessfull_outcome < p_value->triggeringMessage)
        {
            result = INVALID_VALUE;
        }
        else
        {    
            p_local->triggering_message_event_id = 
                (ngap_triggering_message_et)p_value->triggeringMessage; 
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Triggering Message is not present.");
    }

    if(p_value->m.procedureCriticalityPresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CRITICALITY;

        if(ngap_notify < p_value->procedureCriticality)
        {
            result = INVALID_VALUE;
        }
        else
        {    
            p_local->procedure_criticality_event_id = 
                (ngap_procedure_criticality_et)p_value->triggeringMessage;
        }
    }
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Procedure Criticality is not present.");
    }

    if(p_value->m.iEsCriticalityDiagnosticsPresent == NGAP_TRUE)
    {
        p_local->bitmask |= NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_IE_LIST;

        p_local->cd_ie_list.no_of_errors = NGAP_ZERO;

        if (p_value->iEsCriticalityDiagnostics.count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, 
                "Criticality Diagnostics Information Element is not present.");
        }
        else if(MAX_CD_ERRORS < p_value->iEsCriticalityDiagnostics.count)
        {
            result = INVALID_VALUE;
        }
        else
        {

            p_local->cd_ie_list.no_of_errors = 
                p_value->iEsCriticalityDiagnostics.count;

            while(cd_ie_list_node != NGAP_P_NULL)
            {
                p_value_cd_ie_list_item = 
                    (ngap_CriticalityDiagnostics_IE_Item *)cd_ie_list_node->data;

                if(ngap_notify < p_value_cd_ie_list_item->iECriticality)
                {
                    result = INVALID_VALUE;    
                }    
                else
                {    
                    p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].\
                        ie_criticality =
                        (ngap_ie_criticality_et)p_value_cd_ie_list_item->iECriticality;
                }       

                p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].\
                    ie_id =
                    p_value_cd_ie_list_item->iE_ID;

                if(ngap_missing < p_value_cd_ie_list_item->typeOfError)
                {
                    result = INVALID_VALUE;    
                }
                else
                {    
                    p_local->cd_ie_list.criticality_diagnostics_ie[no_of_errors_it].\
                        type_of_error = 
                        (ngap_type_of_error_et)p_value_cd_ie_list_item->typeOfError;
                }          

                cd_ie_list_node = cd_ie_list_node->next;
                no_of_errors_it++;            
            }

            if (p_local->cd_ie_list.no_of_errors != no_of_errors_it)
            {
                RRC_NGAP_TRACE(NGAP_WARNING, 
                    "Wrong number of IE to be filled in Criticality Diagnostics IE");
                p_local->cd_ie_list.no_of_errors = NGAP_ZERO;
            }
        }
    }    
    else
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
            "Criticality Diagnostics INFO ELEMENT is not present.");
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/***************************************************************************
 * Function Name : validate_and_fill_served_guami_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_served_guami_list
(
    ngap_ServedGUAMIList        *p_value, /* ASN Buffer */
    ngap_served_guami_list_t    *p_local  /* Local Buffer */
)
{
    ngap_ServedGUAMIItem        *p_value_guami_item;
    UInt16                      count_it                    = NGAP_ZERO;
    OSRTDListNode               *p_served_guami_list_node   = p_value->head; 
    ngap_map_updation_const_et  result                      = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {

        if(p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Served GUAMI List is not present.");
        }    
        else if(NG_SETUP_RES_MAX_NO_OF_SERVED_GUAMI < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(p_served_guami_list_node != NGAP_P_NULL)
            {
                p_value_guami_item = 
                    (ngap_ServedGUAMIItem *)p_served_guami_list_node->data;

                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_value_guami_item->gUAMI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    
                    NGAP_MEMCPY(p_local->guami_item[count_it].guami.plmn_identity.\
                            plmn_id_bytes,
                        p_value_guami_item->gUAMI.pLMNIdentity.data, 
                        p_value_guami_item->gUAMI.pLMNIdentity.numocts);
                }

                if(NGAP_AMF_REGION_ID_NUMBITS < 
                    p_value_guami_item->gUAMI.aMFRegionID.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY(p_local->guami_item[count_it].guami.amf_region_id,
                        p_value_guami_item->gUAMI.aMFRegionID.data,
                        NGAP_AMF_REGION_ID_OCTET_SIZE);
                }

                if(NGAP_AMF_SET_ID_NUMBITS < 
                    p_value_guami_item->gUAMI.aMFSetID.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY(p_local->guami_item[count_it].guami.amf_set_id,
                        p_value_guami_item->gUAMI.aMFSetID.data,
                        NGAP_AMF_SET_ID_OCTET_SIZE);
                }  

                if(NGAP_AMF_POINTER_NUMBITS < 
                    p_value_guami_item->gUAMI.aMFPointer.numbits)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    if(p_value_guami_item->gUAMI.aMFPointer.numbits % 8 == 0)
                    {
                        NGAP_MEMCPY(p_local->guami_item[count_it].guami.amf_pointer,
                                p_value_guami_item->gUAMI.aMFPointer.data,
                                p_value_guami_item->gUAMI.aMFPointer.numbits/8);
                    }
                    else
                    {
                        NGAP_MEMCPY(p_local->guami_item[count_it].guami.amf_pointer,
                                p_value_guami_item->gUAMI.aMFPointer.data,
                                ((p_value_guami_item->gUAMI.aMFPointer.numbits/8)+1));
                    }
                }   
                
                p_local->guami_item[count_it].bitmask = NGAP_ZERO;
                
                if(p_value_guami_item->m.backupAMFNamePresent == NGAP_TRUE)
                {
                    p_local->guami_item[count_it].bitmask |= 
                        NG_SETUP_RES_BACKUP_AMF_NAME_PRESENT;
                
                    if(NGAP_MAX_AMF_NAME_LENGTH < 
                        NGAP_STRLEN(p_value_guami_item->backupAMFName))
                    {
                        result = INVALID_VALUE;
                    }
                    else
                    {
                        NGAP_MEMCPY
                        (
                            p_local->guami_item[count_it].backup_amf_name.amf_name,
                            p_value_guami_item->backupAMFName, 
                            NGAP_STRLEN(p_value_guami_item->backupAMFName)
                        );
                    }
                }    
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "Backup AMF Name is not present.");
                }

                count_it++;
                p_served_guami_list_node = p_served_guami_list_node->next;
            }
        }    
    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_guami
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_guami
(
    ngap_GUAMI      *p_value,
    ngap_guami_t    *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    /* copy plmn id bytes */
    if(NGAP_PLMN_IDENTITY_MAX_BYTES < p_value->pLMNIdentity.numocts)
    {
        result = INVALID_VALUE;
        return result;
    }

    NGAP_MEMCPY(p_local->plmn_identity.plmn_id_bytes,
            p_value->pLMNIdentity.data,
            p_value->pLMNIdentity.numocts);
    
    /* copy amf region id */
    if(NGAP_AMF_REGION_ID_NUMBITS < p_value->aMFRegionID.numbits)
    {
        result = INVALID_VALUE;
    }

    NGAP_MEMCPY(p_local->amf_region_id,
            p_value->aMFRegionID.data,
            NGAP_AMF_REGION_ID_OCTET_SIZE);

    /* copy amf set id */
    if(NGAP_AMF_SET_ID_NUMBITS < p_value->aMFSetID.numbits)
    {
        result = INVALID_VALUE;
    }

    NGAP_MEMCPY(p_local->amf_set_id,
            p_value->aMFSetID.data,
            NGAP_AMF_SET_ID_OCTET_SIZE);

    /* copy amf pointer */
    if(NGAP_AMF_POINTER_NUMBITS < p_value->aMFPointer.numbits)
    {
        result = INVALID_VALUE;
    }
    if(p_value->aMFPointer.numbits % 8 == 0)
    {
        NGAP_MEMCPY(p_local->amf_pointer,
                p_value->aMFPointer.data,
                p_value->aMFPointer.numbits/8);
    }
    else
    {
        NGAP_MEMCPY(p_local->amf_pointer,
                p_value->aMFPointer.data,
                ((p_value->aMFPointer.numbits/8)+1));
    }

    RRC_NGAP_UT_TRACE_ENTER();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_ue_security_capabilities
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_ue_security_capabilities
(
    ngap_UESecurityCapabilities     *p_value,
    ngap_ue_security_capabilities_t *p_local
)
{
    /* Handling is done only for the supported algorithms 
     * i.e. first byte is considered only because currently 
     * only first 3 bits are used.
     */

    ngap_map_updation_const_et  result = OCCURANCE;
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    RRC_NGAP_UT_TRACE_ENTER();

    /* copy NR ENCRYPTION ALGORITHM */
    if(NGAP_NR_ENCRYPTION_ALGORITHM_NUMBITS < 
         p_value->nRencryptionAlgorithms.numbits)
    {
        result = INVALID_VALUE;
    }

    NGAP_MEMCPY ( p_local->nr_encryption_algorithm ,
        p_value->nRencryptionAlgorithms.data,
        NGAP_NR_ENCRYPTION_ALGORITHM_OCTET_SIZE);/*Handover bug fixes*/

    /* copy Integrity Protection Algorithms */
    if(NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS < 
        p_value->nRintegrityProtectionAlgorithms.numbits)
    {
        result = INVALID_VALUE;
    }

  NGAP_MEMCPY( p_local->nr_integrity_protection_algorithm,
        p_value->nRintegrityProtectionAlgorithms.data,
        NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE);/*Handover bug fixes*/

    /* copy E-UTRA Encryption Algorithms */
    if(NGAP_EUTRA_ENCRYPTION_ALGORITHM_NUMBITS < 
        p_value->eUTRAencryptionAlgorithms.numbits)
    {
        result = INVALID_VALUE;
    }

    NGAP_MEMCPY(p_local->eutra_encryption_algorithm ,
        p_value->eUTRAencryptionAlgorithms.data ,
        NGAP_EUTRA_ENCRYPTION_ALGORITHM_OCTET_SIZE);/*Handover bug fixes*/


    /* copy E-UTRA Integrity Protection Algorithms */
    if(NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS < 
            p_value->eUTRAintegrityProtectionAlgorithms.numbits)
    {
        result = INVALID_VALUE;
    }

   NGAP_MEMCPY ( p_local->eutra_integrity_protection_algorithm ,
        p_value->eUTRAintegrityProtectionAlgorithms.data,
        NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE);/*Handover bug fixes*/
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_ie_security_key
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_ie_security_key
(
    ngap_SecurityKey        *p_value,
    ngap_security_key_t     *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;
  
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    if(NGAP_SECURITY_KEY_NUMBITS < p_value->numbits)
    {
        result = INVALID_VALUE;
    }

    NGAP_MEMCPY(p_local->security_key,
            p_value->data,
            NGAP_SECURITY_KEY_OCTET_SIZE);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_supported_ta_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_supported_ta_list
(
    ngap_SupportedTAList        *p_value, /* ASN Buffer */ 
    ngap_supported_ta_list_t    *p_local  /* Local Buffer */
)
{

    ngap_SupportedTAItem        *p_value_support_ta_item;
    UInt16                      ta_count_it             = NGAP_ZERO;
    OSRTDListNode               *support_ta_list_node   = p_value->head; 
    ngap_map_updation_const_et  result                  = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {    

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Supported TA List is not present.");
        }
        else if(NG_SETUP_REQ_MAX_NO_OF_TAC < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->ta_count = p_value->count; 

            while(support_ta_list_node != NGAP_P_NULL)
            {
                p_value_support_ta_item = 
                    (ngap_SupportedTAItem *)support_ta_list_node->data;

                if(NGAP_TAC_OCTET_SIZE < p_value_support_ta_item->tAC.numocts)
                {
                    result = INVALID_VALUE;   
                    break;
                }    
                else
                {
                    NGAP_MEMCPY(p_local->supported_ta[ta_count_it].tac, 
                            p_value_support_ta_item->tAC.data, 
                            p_value_support_ta_item->tAC.numocts);
                }    

                result = validate_and_fill_broadcast_plmn_list 
                    (
                     &p_value_support_ta_item->broadcastPLMNList,
                     &p_local->supported_ta[ta_count_it].\
                        ngap_broadcast_plmn_list
                    );

                support_ta_list_node = support_ta_list_node->next;
                ta_count_it++;
            }    
        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_broadcast_plmn_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_broadcast_plmn_list
(
    ngap_BroadcastPLMNList      *p_value, /* ASN Buffer */ 
    ngap_broadcast_plmn_list_t  *p_local  /* Local Buffer */
)
{

    ngap_BroadcastPLMNItem      *p_value_b_plmn_item;
    UInt8                       plmn_count_it       = NGAP_ZERO;  
    OSRTDListNode               *p_b_plmn_list_node = p_value->head;
    ngap_map_updation_const_et  result              = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Broadcast PLMN List is not present.");
        }
        else if(NG_SETUP_REQ_MAX_NO_OF_BROADCAST_PLMN < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->plmn_count = p_value->count; 

            while(p_b_plmn_list_node != NGAP_P_NULL)
            {

                p_value_b_plmn_item = 
                    (ngap_BroadcastPLMNItem *)p_b_plmn_list_node->data;

                if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
                    p_value_b_plmn_item->pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->supported_plmn[plmn_count_it].plmn_identity.\
                            plmn_id_bytes,
                        p_value_b_plmn_item->pLMNIdentity.data, 
                        p_value_b_plmn_item->pLMNIdentity.numocts
                    );
                }   

                result = validate_and_fill_slice_support_list 
                    (
                        &p_value_b_plmn_item->tAISliceSupportList,
                        &p_local->supported_plmn[plmn_count_it].\
                            tai_slice_support_list
                    );

                plmn_count_it++;
                p_b_plmn_list_node = p_b_plmn_list_node->next;
            }    

        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/***************************************************************************
 * Function Name : validate_and_fill_broadcast_tnl_association_to_add_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_broadcast_tnl_association_to_add_list
(
 ngap_AMF_TNLAssociationToAddList      *p_value, /* ASN Buffer */
 amf_tnl_association_to_add_list_t     *p_local  /* Local Buffer */
)
{
    ngap_AMF_TNLAssociationToAddItem      *p_value_tnl_association_to_add_item;
    UInt8                                  add_item_count_it       = NGAP_ZERO;  
    OSRTDListNode                         *p_value_add_list_node   = p_value->head;
    ngap_map_updation_const_et             result                  = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    do
    {

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "AMF TNL Association to Add LIST  is not present.");
        }
        else if(NGAP_MAX_NO_OF_TNL_ASSOCIATIONS < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->count = p_value->count; 

            while(p_value_add_list_node != NGAP_P_NULL)
            {

                p_value_tnl_association_to_add_item = 
                    (ngap_AMF_TNLAssociationToAddItem *)p_value_add_list_node->data;

                if(p_value_tnl_association_to_add_item->aMF_TNLAssociationAddress.\
                        u.endpointIPAddress->numbits <= NGAP_ZERO)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {  /*AMF TNL Association Address*/
                    NGAP_MEMCPY
                    (p_local->tnl_association_item[add_item_count_it].tnl_association_address.\
                            endpoint_ip_address.transport_layer_address,
                     p_value_tnl_association_to_add_item->aMF_TNLAssociationAddress.u.\
                            endpointIPAddress->data,
                     p_value_tnl_association_to_add_item->aMF_TNLAssociationAddress.u.\
                            endpointIPAddress->numbits/8       
                    );
                }

                p_local->tnl_association_item[add_item_count_it].bitmask = NGAP_ZERO;

                if(p_value_tnl_association_to_add_item->m.tNLAssociationUsagePresent == NGAP_TRUE)
                {
                    p_local->tnl_association_item[add_item_count_it].bitmask |=
                        TNL_ASSOCIATION_TO_ADD_LIST_USAGE_PRESENT;
                    {

                        /*TNL Association Usage*/
                        p_local->tnl_association_item[add_item_count_it].association_usage =
                            p_value_tnl_association_to_add_item->tNLAssociationUsage;
                    }
                }      
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "TNL Association Usage not used");
                }

                /*TNL Address Weight Factor*/
                p_local->tnl_association_item[add_item_count_it].weight_factor =
                        p_value_tnl_association_to_add_item->tNLAddressWeightFactor;
                 

                add_item_count_it++;
                p_value_add_list_node = p_value_add_list_node->next;
            }    

        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/***************************************************************************
 * Function Name : validate_and_fill_tnl_association_to_remove_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_tnl_association_to_remove_list
(
  ngap_AMF_TNLAssociationToRemoveList   *p_value, /* ASN Buffer */
  amf_tnl_association_remove_list_t     *p_local  /* Local Buffer */
)
{
    ngap_AMF_TNLAssociationToRemoveItem      *p_value_tnl_association_to_rem_item;
    UInt8                                     add_item_count_it       = NGAP_ZERO;  
    OSRTDListNode                            *p_value_rem_list_node   = p_value->head;
    ngap_map_updation_const_et                result                  = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    do
    {

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "AMF TNL Association to Remove List  is not present.");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_TNL_ASSOCIATIONS < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {
            NGAP_MEMSET(p_local, NGAP_ZERO, sizeof(amf_tnl_association_remove_list_t));

            p_local->count = p_value->count; 

            while(p_value_rem_list_node != NGAP_P_NULL)
            {

                p_value_tnl_association_to_rem_item = 
                    (ngap_AMF_TNLAssociationToRemoveItem *)p_value_rem_list_node->data;

                switch(p_value_tnl_association_to_rem_item->\
                        aMF_TNLAssociationAddress.t)
                {
                    case T_ngap_CPTransportLayerInformation_endpointIPAddress:
                    {
                        p_local->tnl_association_item[add_item_count_it].\
                            tnl_association_address.choice = NGAP_TNL_ENDPOINT_IP_ADDR;

                        if(p_value_tnl_association_to_rem_item->aMF_TNLAssociationAddress.\
                                u.endpointIPAddress->numbits < NGAP_ZERO)
                        {
                            result = INVALID_VALUE;
                            break;
                        }
                        else
                        {  /*AMF TNL Association Address*/
                            NGAP_MEMCPY
                                (p_local->tnl_association_item[add_item_count_it].tnl_association_address.\
                                     endpoint_ip_address.transport_layer_address,
                                 p_value_tnl_association_to_rem_item->aMF_TNLAssociationAddress.u.\
                                     endpointIPAddress->data,
                                 NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                                );
                        }
                        break;
                    }

                    case T_ngap_CPTransportLayerInformation_choice_Extensions:
                    {
                        p_local->tnl_association_item[add_item_count_it].\
                            tnl_association_address.choice=
                            NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT;

                        switch(p_value_tnl_association_to_rem_item->\
                            aMF_TNLAssociationAddress.u.choice_Extensions->\
                            value.t)
                        {
                            case T122ngap__UNDEF_:
                            {
                                RRC_NGAP_TRACE(NGAP_WARNING, "Undefined Type");
                                break;
                            }
                            case T122ngap___ngap_CPTransportLayerInformation_ExtIEs_1:
                            {
                                if(p_value_tnl_association_to_rem_item->\
                                        aMF_TNLAssociationAddress.u.choice_Extensions->\
                                        value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                                        endpointIPAddress.numbits > NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS)
                                {
                                    RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of transport layer address failed as numbits=%u",p_value_tnl_association_to_rem_item->\
                                            aMF_TNLAssociationAddress.u.choice_Extensions->\
                                            value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                                            endpointIPAddress.numbits);

                                    result = INVALID_VALUE;
                                    RRC_NGAP_UT_TRACE_EXIT();
                                    return result;
                                }
                                else
                                {
                                    /* Transport layer Address--> fill endpoint ip address*/
                                    NGAP_MEMCPY
                                        (
                                         p_local->tnl_association_item[add_item_count_it].\
                                             tnl_association_address.\
                                             endpoint_ip_address_and_port.\
                                             endpoint_ip_address.transport_layer_address,
                                         p_value_tnl_association_to_rem_item->\
                                             aMF_TNLAssociationAddress.u.choice_Extensions->value.u.\
                                             _ngap_CPTransportLayerInformation_ExtIEs_1->\
                                             endpointIPAddress.data,
                                         NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                                        );
                                }

                                if(p_value_tnl_association_to_rem_item->\
                                        aMF_TNLAssociationAddress.u.choice_Extensions->\
                                        value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                                        portNumber.numocts > NGAP_PORT_NUMBER_OCTET_SIZE)
                                {
                                    RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of port number failed");
                                    result = INVALID_VALUE;
                                    RRC_NGAP_UT_TRACE_EXIT();
                                    return result;
                                }
                                else
                                {
                                    /* Transport layer Address--> fill port number*/
                                    NGAP_MEMCPY
                                        (
                                         p_local->tnl_association_item[add_item_count_it].\
                                             tnl_association_address.\
                                             endpoint_ip_address_and_port.\
                                          port_number,
                                         &p_value_tnl_association_to_rem_item->\
                                             aMF_TNLAssociationAddress.u.choice_Extensions->\
                                             value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                                            portNumber.data,
                                         NGAP_PORT_NUMBER_OCTET_SIZE
                                        );
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
                add_item_count_it++;
                p_value_rem_list_node = p_value_rem_list_node->next;
            }    
        }
    }
    while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/***************************************************************************
 * Function Name : validate_and_fill_broadcast_tnl_association_to_update_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et validate_and_fill_broadcast_tnl_association_to_update_list
(
  ngap_AMF_TNLAssociationToUpdateList   *p_value, /* ASN Buffer */
  amf_tnl_association_update_list_t     *p_local  /* Local Buffer */
)
{
    ngap_AMF_TNLAssociationToUpdateItem      *p_value_tnl_association_to_update_item;
    UInt8                                     add_item_count_it        = NGAP_ZERO;  
    OSRTDListNode                            *p_value_update_list_node = p_value->head;
    ngap_map_updation_const_et                result                   = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    do
    {

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "AMF TNL Association to Add LIST  is not present.");
        }
        else if(NGAP_MAX_NO_OF_TNL_ASSOCIATIONS < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->count = p_value->count; 

            while(p_value_update_list_node != NGAP_P_NULL)
            {

                p_value_tnl_association_to_update_item = 
                    (ngap_AMF_TNLAssociationToUpdateItem *)p_value_update_list_node->data;

                if(p_value_tnl_association_to_update_item->aMF_TNLAssociationAddress.\
                        u.endpointIPAddress->numbits <= NGAP_ZERO)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {  /*AMF TNL Association Address*/
                    NGAP_MEMCPY
                        (p_local->tnl_association_item[add_item_count_it].tnl_association_address.\
                             endpoint_ip_address.transport_layer_address,
                         p_value_tnl_association_to_update_item->aMF_TNLAssociationAddress.u.\
                             endpointIPAddress->data,
                         p_value_tnl_association_to_update_item->aMF_TNLAssociationAddress.u.\
                             endpointIPAddress->numbits/8       
                        );
                }

                p_local->tnl_association_item[add_item_count_it].bitmask = NGAP_ZERO;

                if(p_value_tnl_association_to_update_item->m.tNLAssociationUsagePresent == NGAP_TRUE)
                {
                    p_local->tnl_association_item[add_item_count_it].bitmask |=
                       TNL_ASSOCIATION_TO_UPDATE_USAGE_PRESENT;
                    {

                        /*TNL Association Usage*/
                        p_local->tnl_association_item[add_item_count_it].association_usage =
                            p_value_tnl_association_to_update_item->tNLAssociationUsage;
                    }
                }      
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "TNL Association Usage not found");
                }
                
                if(p_value_tnl_association_to_update_item->m.tNLAddressWeightFactorPresent == NGAP_TRUE)
                {
                    p_local->tnl_association_item[add_item_count_it].bitmask |=
                        TNL_ASSOCIATION_TO_UPDATE_ADDRESS_WEIGHT_FACTOR_PRESENT;

                    /*TNL Address Weight Factor*/
                    p_local->tnl_association_item[add_item_count_it].weight_factor =
                        p_value_tnl_association_to_update_item->tNLAddressWeightFactor;

                }
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "TNL Address Weight Factor  not found");
                }
                add_item_count_it++;
                p_value_update_list_node = p_value_update_list_node->next;
            }    

        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;


}

/***************************************************************************
 * Function Name : validate_and_fill_slice_support_list
 *
 * Input         : p_value - pointer of asn structure
 *
 * Output        : p_local - pointer of local strusture
 *
 * Description   : This function takes input from ASN Structure and
 *                 fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et  validate_and_fill_slice_support_list 
(
    ngap_SliceSupportList           *p_value, /* ASN Buffer */ 
    ngap_tai_slice_support_list_t   *p_local  /* Local Buffer */
)
{
    ngap_SliceSupportItem       *p_value_slice_support_item;
    UInt8                       tai_slice_count_it         = NGAP_ZERO;
    OSRTDListNode               *p_slice_support_list_node = p_value->head;
    ngap_map_updation_const_et  result                     = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {
    
        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Slice Support List is not present.");
        }
        else if(NG_SETUP_REQ_MAX_NO_OF_SLICE_ITEMS < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {
            
            p_local->tai_slice_count = p_value->count;
            
            while(p_slice_support_list_node != NGAP_P_NULL)
            {

                p_value_slice_support_item = 
                    (ngap_SliceSupportItem *)p_slice_support_list_node->data;

                if(NGAP_SST_OCTET_SIZE < 
                    p_value_slice_support_item->s_NSSAI.sST.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->slice_support_item[tai_slice_count_it].s_nssai.sst,
                        p_value_slice_support_item->s_NSSAI.sST.data, 
                        p_value_slice_support_item->s_NSSAI.sST.numocts
                    );
                }   

                if(p_value_slice_support_item->s_NSSAI.m.sDPresent == NGAP_TRUE)
                {

                    p_local->slice_support_item[tai_slice_count_it].s_nssai.bitmask |= 
                        NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT;

                    if(NGAP_SD_OCTET_SIZE < 
                        p_value_slice_support_item->s_NSSAI.sD.numocts)
                    {
                        result = INVALID_VALUE;
                        break;
                    }
                    else
                    {
                        NGAP_MEMCPY
                        (
                            p_local->slice_support_item[tai_slice_count_it].s_nssai.sd,
                            p_value_slice_support_item->s_NSSAI.sD.data, 
                            p_value_slice_support_item->s_NSSAI.sD.numocts
                        );
                    }   

                }
                else
                {
                    RRC_NGAP_TRACE(NGAP_INFO, "The IE SD of S-NSSAI is not present.");
                }  

                tai_slice_count_it++;
                p_slice_support_list_node = p_slice_support_list_node->next;

            }    

        }    

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


/*****************************************************************************
 * Function Name	: ngap_decode_ng_setup_resp
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ng_setup_resp
(
    UInt8                   *p_asn_msg,		    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,		/* Input - ASN Encoded Buffer Length */
    ngap_setup_response_t   *p_ng_setup_resp,   /* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_return_et          response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for ng setup resp");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Response Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_setup_resp_internal_dec(&asn1_ctx,
                        ngap_pdu.u.successfulOutcome->value.u.nGSetup,
                        p_ng_setup_resp);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}
	
ngap_return_et ng_setup_resp_internal_dec
(
    OSCTXT			        *p_asn1_ctx,            /* Input: ASN1 Context to be used */
    ngap_NGSetupResponse	*p_asn_ng_setup_resp,   /* Input: Received ASN Buffer */
    ngap_setup_response_t 	*p_local_ng_setup_resp  /* Output: Local Message Structure */
)
{
    OSRTDListNode                            *p_node             = NGAP_P_NULL;
    ngap_NGSetupResponse_protocolIEs_element *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                    ie_index            = NGAP_ZERO;
    UInt16                                   ie_list_index       = NGAP_ZERO;
    ngap_return_et                           ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                    send_err_ind;
    ngap_criticality_diagnostics_ie_list_t   ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_setup_resp);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO,sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {6, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_AMFName, ngap_mandatory, ngap_reject, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_ServedGUAMIList, ngap_mandatory, ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_RelativeAMFCapacity, ngap_mandatory, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {3, ASN1V_ngap_id_PLMNSupportList, ngap_mandatory, ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {4, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {5, ASN1V_ngap_id_UERetentionInformation, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_ng_setup_resp->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ng_setup_resp->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_setup_resp->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_NGSetupResponse_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_AMFName:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_AMFName");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupResponseIEs_1,
                            (void *)&p_local_ng_setup_resp->amf_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_AMFName Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_ServedGUAMIList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_ServedGUAMIList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupResponseIEs_2,
                            (void *)&p_local_ng_setup_resp->served_guami_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - ASN1V_ngap_id_ServedGUAMIList");
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_RelativeAMFCapacity:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_RelativeAMFCapacity");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_NGSetupResponseIEs_3,
                            (void *)&p_local_ng_setup_resp->relative_amf_capacity))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_RelativeAMFCapacity Validation failed");
                }
                break;
            } /* End of IE3 */

            /* IE4 */
            case ASN1V_ngap_id_PLMNSupportList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_PLMNSupportList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupResponseIEs_4,
                            (void *)&p_local_ng_setup_resp->plmn_support_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_PLMNSupportList Validation failed");
                }

                break;
            } /* End of IE4 */

            /* IE5 */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupResponseIEs_5,
                            (void *)&p_local_ng_setup_resp->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE5 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_ng_setup_resp->bitmask |= 
                        NG_SETUP_RES_CRITICALITY_DIAGNOSTICS_PRESENT;
                }
                break;
            } /* End of IE5 */
            
            /* IE6 */
            case ASN1V_ngap_id_UERetentionInformation:
            {
                p_local_ng_setup_resp->ue_retention_info =
                    (ngap_ue_retention_info_et)p_prootocolIE_elem->value.u.\
                    _ngap_NGSetupResponseIEs_6;

                break;
            }            
            /*End of IE6*/            

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NG Setup Response");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
} 

/******************************************************************************
 * Function Name	: ngap_decode_ng_setup_failure
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ng_setup_failure
(
    UInt8			        *p_asn_msg,	        /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	    /* Input - ASN Encoded Buffer Length */
    ngap_setup_failure_t	*p_ng_setup_failure,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for ng setup failure");
            response = NGAP_FAILURE;
            break;
        }
    
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Failure Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif            
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_setup_failure_internal_dec(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome->value.u.nGSetup,
                p_ng_setup_failure);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

ngap_return_et ng_setup_failure_internal_dec
(
    OSCTXT			        *p_asn1_ctx,               /* Input: ASN1 Context to be used */
    ngap_NGSetupFailure     *p_asn_ng_setup_failure,   /* Input: Received ASN Buffer */
    ngap_setup_failure_t    *p_local_ng_setup_failure  /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_NGSetupFailure_protocolIEs_element *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_setup_failure);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_TimeToWait, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };
    
    p_local_ng_setup_failure->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ng_setup_failure->protocolIEs.head;
    
    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_setup_failure->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_NGSetupFailure_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupFailureIEs_1,
                            (void *)&p_local_ng_setup_failure->choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_TimeToWait:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_TimeToWait");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_NGSetupFailureIEs_2,
                            (void *)&p_local_ng_setup_failure->time_to_wait_event_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - ASN1V_ngap_id_TimeToWait Validation failed");
                }
                else
                {
                    p_local_ng_setup_failure->bitmask |= 
                        NG_SETUP_FAIL_TIME_TO_WAIT_PRESENT;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_NGSetupFailureIEs_3,
                            (void *)&p_local_ng_setup_failure->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_ng_setup_failure->bitmask |= 
                        NG_SETUP_FAIL_CRITICALITY_DIAGNOSTICS_PRESENT;
                }
                break;
            } /* End of IE3 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */
        
        p_node = p_node->next;
        
    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NG Setup Failure");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/******************************************************************************
 * Function Name	: ngap_decode_initial_ue_message
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_initial_ue_message
(
    UInt8			            *p_asn_msg,	            /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	        /* Input - ASN Encoded Buffer Length */
    ngap_initial_ue_message_t   *p_initial_ue_message   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Initial UE Message");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */

        response = ng_initial_ue_message_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.initialUEMessage,
                p_initial_ue_message);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name:ng_initial_ue_message_internal_dec 
 * Inputs:     p_asn1_ctx         
 *             p_asn_initial_ue_msg
 * Output: 
 * Description:
 * ****************************************************************************/
ngap_return_et ng_initial_ue_message_internal_dec
(
    OSCTXT                      *p_asn1_ctx,            /*Input asn context*/
    ngap_InitialUEMessage       *p_asn_initial_ue_msg,  /*Input : encoded ASN strtucture*/
    ngap_initial_ue_message_t   *p_local_initial_ue_msg /*Output: local strtucture to be filled*/
)
{
    OSRTDListNode                               *p_node            = NGAP_P_NULL;
    ngap_InitialUEMessage_protocolIEs_element   *p_protocolIE_elem = NGAP_P_NULL;
    UInt8                                       ie_index           = NGAP_ZERO;
    UInt16                                      ie_list_index      = NGAP_ZERO;
    ngap_return_et                              ret_val            = NGAP_SUCCESS;
    ngap_error_ind_bool_t                       send_err_ind;
    ngap_criticality_diagnostics_ie_list_t      ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_initial_ue_msg);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    ngap_message_data_t message_map = 
    {9, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO    
            },
            {
                1,ASN1V_ngap_id_NAS_PDU, ngap_mandatory, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_UserLocationInformation, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_RRCEstablishmentCause, ngap_mandatory, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_FiveG_S_TMSI, ngap_optional, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_AMFSetID, ngap_optional, ngap_ignore, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                6,ASN1V_ngap_id_UEContextRequest, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                7,ASN1V_ngap_id_AllowedNSSAI, ngap_optional, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                8,ASN1V_ngap_id_SourceToTarget_AMFInformationReroute,
                ngap_optional,ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_local_initial_ue_msg->bitmask = 0x00;

    /* Initialize the p_node with first IE */
    p_node = p_asn_initial_ue_msg->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First IE is NULL");
        ret_val = NGAP_FAILURE;
        return ret_val;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_initial_ue_msg->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_InitialUEMessage_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {    
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /*IE1 - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /*validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.u._ngap_InitialUEMessage_IEs_1,
                            (void *)&p_local_initial_ue_msg->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE
                        (NGAP_ERROR, "IE1 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /*IE2 - ASN1V_ngap_id_NAS_PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE - ASN1V_ngap_id_NAS_PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u._ngap_InitialUEMessage_IEs_2,
                            (void *)&p_local_initial_ue_msg->nas_pdu))
                {    
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_NAS_PDU validation failed");
                }
                break;
            }

            /* IE3 - ASN1V_ngap_id_UserLocationInformation */
            case ASN1V_ngap_id_UserLocationInformation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_UserLocationInformation");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_InitialUEMessage_IEs_3,
                            (void *)&p_local_initial_ue_msg->choice_user_location_information))
                {

                    RRC_NGAP_TRACE
                        (NGAP_ERROR, "IE3 - ASN1V_ngap_id_UserLocationInformation validation failed");
                }

                break;
            }

            /* IE4- ASN1V_ngap_id_RRCEstablishmentCause*/
            case ASN1V_ngap_id_RRCEstablishmentCause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode ASN1V_ngap_id_RRCEstablishmentCause ");

                p_local_initial_ue_msg->rrc_establishment_cause = 
                    (ngap_rrc_establishment_cause_et)p_protocolIE_elem->value.u.\
                    _ngap_InitialUEMessage_IEs_4;
                break;
            }

            /*IE5- ASN1V_ngap_id_FiveG_S_TMSI*/
            case ASN1V_ngap_id_FiveG_S_TMSI:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode ASN1V_ngap_id_FiveG_S_TMSI");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialUEMessage_IEs_5,
                            (void *)&p_local_initial_ue_msg->tmsi))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_FiveG_S_TMSI validation failed");
                }
                else
                {
                    p_local_initial_ue_msg->bitmask |=
                        INITIAL_UE_MESSAGE_5G_S_TMSI_PRESENT;
                }

                break;
            }

            /*IE6 - ASN1V_ngap_id_AMFSetID*/
            case ASN1V_ngap_id_AMFSetID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE6 - ASN1V_ngap_id_AMFSetID");

                if(NGAP_AMF_SET_ID_NUMBITS < 
                    p_protocolIE_elem->value.u._ngap_InitialUEMessage_IEs_6->numbits)
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "Invalid value for AMFSetID");
                    ret_val = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMCPY(p_local_initial_ue_msg->amf_set_id.amf_set_id,
                    p_protocolIE_elem->value.u._ngap_InitialUEMessage_IEs_6->data,
                    NGAP_AMF_SET_ID_OCTET_SIZE);

                p_local_initial_ue_msg->bitmask |=
                        INITIAL_UE_MESSAGE_AMF_SET_ID_PRESENT;
                break;
            }

            /*IE7 - ASN1V_ngap_id_UEContextRequest*/
            case ASN1V_ngap_id_UEContextRequest:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE7 - ASN1V_ngap_id_UEContextRequest");

                p_local_initial_ue_msg->ue_context_request_event_id = 
                    (ngap_ue_context_request_et)p_protocolIE_elem->value.\
                        u._ngap_InitialUEMessage_IEs_7;

                p_local_initial_ue_msg->bitmask |= 
                    INITIAL_UE_MESSAGE_UE_CONTEXT_REQUEST_PRESENT; 

                break;
            }

            /*IE8 - Allowed NSSAI */
            case ASN1V_ngap_id_AllowedNSSAI:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE8 - Allowed NSSAI");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialUEMessage_IEs_8,
                            (void *)&p_local_initial_ue_msg->allowed_nssai_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE8 - Allowed NSSAI Validation failed");
                }
                else
                {
                    p_local_initial_ue_msg->bitmask |=
                        INITIAL_UE_MESSAGE_ALLOWED_NSSAI_PRESENT; 
                }
                break;
            }
            
            /* IE9 - Source to Target AMF Information Reroute */
            case ASN1V_ngap_id_SourceToTarget_AMFInformationReroute:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE9 - Source to Target AMF Information Reroute");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_InitialUEMessage_IEs_9,
                            (void *)&p_local_initial_ue_msg->\
                            source_to_target_information_reroute))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE9-Source to Target AMF Information Reroute validation failed");
                }
                else
                {
                    p_local_initial_ue_msg->bitmask |=
                        INITIAL_UE_MESSAGE_SOURCE_TO_TARGET_AMF_INFO_REROUTE_PRESENT;
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of Switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_InitialUEMessage,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Initial UE Message");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_ng_reset
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ng_reset
(
    UInt8			        *p_asn_msg,	   /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,   /* Input - ASN Encoded Buffer Length */
    ngap_reset_t            *p_ng_reset,   /* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU   ngap_pdu;
    OSCTXT          asn1_ctx;
    ngap_return_et  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for decode ng reset");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }

#endif
            break;

        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */

        response = ng_reset_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.nGReset,
                p_ng_reset);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name: 
 * Inputs: 
 * Output: 
 * Description:
 * ****************************************************************************/
ngap_return_et ng_reset_internal_dec
(
    OSCTXT          *p_asn1_ctx,
    ngap_NGReset    *p_asn_ng_reset,  /*Input: ASN BUFFER Received*/
    ngap_reset_t    *p_local_ng_reset /*Output: Local Strucure to be filled*/
)
{

    OSRTDListNode                     *p_node             = NGAP_P_NULL;
    ngap_NGReset_protocolIEs_element  *p_protocolIE_elem  = NGAP_P_NULL;
    UInt8                             ie_index            = NGAP_ZERO;
    UInt16                            ie_list_index       = NGAP_ZERO;
    ngap_return_et                    ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t             send_err_ind;
    ngap_criticality_diagnostics_ie_list_t   ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_reset);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO,sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/ 
    ngap_message_data_t message_map = 
    {2, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0,ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1,ASN1V_ngap_id_ResetType, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_node = p_asn_ng_reset->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL"); 
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_reset->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_NGReset_protocolIEs_element *)p_node->data; 

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {

            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u._ngap_NGResetIEs_1,
                            (void *)&p_local_ng_reset->choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_Cause validation failed");
                }

                break;
            }

            case ASN1V_ngap_id_ResetType:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decodde IE ASN1V_ngap_id_ResetType");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u._ngap_NGResetIEs_2,
                            (void *)&p_local_ng_reset->reset_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "IE1 - ASN1V_ngap_id_ResetType");
                }

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);

                break;
            }

        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGReset,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Error Indication");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_ng_reset_ack
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes  REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ng_reset_ack
(
    UInt8			            *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_reset_acknowledge_t    *p_ng_reset_ack,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU       ngap_pdu;
    OSCTXT              asn1_ctx;
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }

#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8*)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */

        response = ng_reset_ack_internal_dec(&asn1_ctx,
                ngap_pdu.u.successfulOutcome->value.u.nGReset,
                p_ng_reset_ack);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

 
/**************************************************************************
 * Funciton Name: ng_reset_ack_internal_dec
 *
 * Inputs: 
 *************************************************************************/
ngap_return_et ng_reset_ack_internal_dec
(
     OSCTXT                      *p_asn1_ctx,
     ngap_NGResetAcknowledge     *p_asn_ng_reset_ack,  /*Input: Received ASN Buffer*/
     ngap_reset_acknowledge_t    *p_local_ng_reset_ack /*Output: Local MessageStructure*/
)
{
    OSRTDListNode                               *p_node             = NGAP_P_NULL;
    ngap_NGResetAcknowledge_protocolIEs_element *p_protocolIE_elem  = NGAP_P_NULL;
    UInt8                                       ie_index            = NGAP_ZERO;
    UInt16                                      ie_list_index       = NGAP_ZERO;
    ngap_return_et                              ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                       send_err_ind;
    ngap_criticality_diagnostics_ie_list_t      ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_reset_ack);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    ngap_message_data_t message_map = 
    {2,NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0,ASN1V_ngap_id_UE_associatedLogicalNG_connectionList,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO 
            },
            {
                1, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_local_ng_reset_ack->bitmask = 0x00;

    /*Initialize pnode with first IE*/
    p_node = p_asn_ng_reset_ack->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"First Node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_reset_ack->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR,"First Node is NULL");
            ret_val =  NGAP_FAILURE;
            return ret_val;
        }

        p_protocolIE_elem = 
            (ngap_NGResetAcknowledge_protocolIEs_element *)p_node->data;

        if(NGAP_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exists", ie_index);
            ret_val = NGAP_FAILURE;
            return ret_val;
        }

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_ngap_id_UE_associatedLogicalNG_connectionList:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_UE_associatedLogicalNG_connectionList");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_NGResetAcknowledgeIEs_1,
                            (void *)&p_local_ng_reset_ack->\
                                ue_associated_logical_ng_connection_list))

                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1- ASN1V_ngap_id_UE_associatedLogicalNG_connectionList validation failed");
                }
                else
                {
                    p_local_ng_reset_ack->bitmask = 
                        NG_RESET_ACK_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST_PRESENT;
                }

                break;
            }

            /*Decode Criticality Diagnostics*/
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_NGResetAcknowledgeIEs_2,
                            (void *)&p_local_ng_reset_ack->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                else
                {
                    p_local_ng_reset_ack->bitmask = 
                        NG_RESET_ACK_CRITICALITY_DIAGNOSTICS_PRESENT;
                }

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);

                break;
            }

        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGReset,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NG Reset Acknowledge");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/**************************************************************************
 * Funciton Name: ng_error_ind_internal_dec
 *
 * Inputs: 
 *************************************************************************/
ngap_return_et ng_error_ind_internal_dec
(
    OSCTXT                  *p_asn1_ctx,        /* Input: ASN! Context to be used */
    ngap_ErrorIndication    *p_asn_error_ind,   /*Input: Received ASN buffer */
    ngap_error_indication_t *p_local_error_ind  /*Output : Local Message Structure*/
)
{
    OSRTDListNode                            *p_node             = NGAP_P_NULL;
    ngap_ErrorIndication_protocolIEs_element *p_protocolIE_elem  = NGAP_P_NULL;
    UInt8                                    ie_index            = NGAP_ZERO;
    UInt16                                   ie_list_index       = NGAP_ZERO;
    ngap_return_et                           ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                    send_err_ind;
    ngap_criticality_diagnostics_ie_list_t   ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_error_ind);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map =
    {4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {0,ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {2,ASN1V_ngap_id_Cause, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {3, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_local_error_ind->bitmask = 0x00;

    /*  Initialize pnode with first IE */
    p_node = p_asn_error_ind->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_error_ind->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_ErrorIndication_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exists", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /* IE1 - AMF_UE_NGAP_ID */
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_ErrorIndicationIEs_1,
                            (void *)&p_local_error_ind->amf_ue_ngap_id_t))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                else
                {
                    p_local_error_ind->bitmask |= 
                        ERROR_INDICATION_AMF_UE_NGAP_ID_PRESENT;
                }

                break;
            }

            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_ErrorIndicationIEs_2,
                            (void *)&p_local_error_ind->ran_ue_ngap_id_t))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
                else
                {
                    p_local_error_ind->bitmask |= 
                        ERROR_INDICATION_RAN_UE_NGAP_ID_PRESENT;
                }

                break;
            }

            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_ErrorIndicationIEs_3,
                            (void *)&p_local_error_ind->choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE3 - ASN1V_ngap_id_Cause validation failed");
                }
                else
                {
                    p_local_error_ind->bitmask |= ERROR_INDICATION_CAUSE_PRESENT;
                }

                break;
            }

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_ErrorIndicationIEs_4,
                            (void *)&p_local_error_ind->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                else
                {
                    p_local_error_ind->bitmask |= 
                        ERROR_INDICATION_CRITICALITY_DIAGNOSTICS_PRESENT;
                }

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of Switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_ErrorIndication,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Error Indication");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_error_ind
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_error_ind
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_error_indication_t *p_error_ind,   /* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_return_et          response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of Error Indication Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }

#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */

        response = ng_error_ind_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.errorIndication,
                p_error_ind);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/****************************************************************************
 * Function Name: ng_dl_nas_transport__internal_dec
 *
 * Inputs: 
 *
 *
 * Description:
 *
 *
 ***************************************************************************/
ngap_return_et ng_dl_nas_transport__internal_dec
(
    OSCTXT                          *p_asn1_ctx,              /* Input: ASN1 Context to be used */
    ngap_DownlinkNASTransport       *p_asn_dl_nas_transport,  /* Input: Received ASN Buffer */
    ngap_downlink_nas_transport_t   *p_local_dl_nas_transport /* Output: Local Message Structure */
)
{
    ngap_DownlinkNASTransport_protocolIEs_element   *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_dl_nas_transport);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    /*-------change it to 9 and add logic for ASN1V_ngap_id_MobilityRestrictionList ---------*/
    ngap_message_data_t message_map = 
    {8, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0,ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_OldAMF, ngap_optional, ngap_reject, NGAP_ZERO,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO                  
            },
            {
                3,  ASN1V_ngap_id_RANPagingPriority, ngap_optional, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,NGAP_ZERO      
            },
            {
                4, ASN1V_ngap_id_NAS_PDU, ngap_mandatory, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
            },
            /* {
               5, ASN1V_ngap_id_MobilityRestrictionList 
               }, */
            {
                5, ASN1V_ngap_id_IndexToRFSP, ngap_optional, ngap_ignore, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO  
            },
            {
                6, ASN1V_ngap_id_UEAggregateMaximumBitRate, ngap_optional, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO  
            },
            {
                7, ASN1V_ngap_id_AllowedNSSAI, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO 
            }
        }
    };

    p_local_dl_nas_transport->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_dl_nas_transport->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_dl_nas_transport->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            ( ngap_DownlinkNASTransport_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /*IE1 - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE1 - AMF UE NGAP ID");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_1,
                            (void *)&p_local_dl_nas_transport->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed ");
                }

                break;
            }

            /* IE2 - RAN UE NGAP ID */
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE2 - RAN UE NGAP ID");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_2,
                            (void *)&p_local_dl_nas_transport->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - RAN UE NGAP ID validation failed");
                }

                break;
            }

            /* IE3 - Old AMF*/

            case ASN1V_ngap_id_OldAMF:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE3 - Old AMF");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id, 
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_3,
                            (void *)&p_local_dl_nas_transport->amf_name.amf_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - RAN UE NGAP ID validation failed");
                }

                break;
            }

            /*IE4 - RAN Paging Priority */
            case ASN1V_ngap_id_RANPagingPriority:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE4 - RAN Paging Priority");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_4,
                            (void *)&p_local_dl_nas_transport->\
                                ran_paging_priority.ran_paging_priority))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE4 - RAN Paging Priority validation failed");
                }

                break;
            }

            /*IE5 - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE5 - NAS-PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_5,
                            (void *)&p_local_dl_nas_transport->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE5 - NAS-PDU Validation Failed");
                }

                break;
            }

            /* IE6 - Mobility Restriction List */
            /*To be completed in phase 2*/

            /* IE7 - Index to RAT/Frequency Selection Priority*/

            case ASN1V_ngap_id_IndexToRFSP:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE7 - Index to RAT/Frequency Selection Priority");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_7,
                            (void *)&p_local_dl_nas_transport->\
                                index_to_rat_frequency_priority.index_to_rat_frequency_priority))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE7 - Index to RAT/Frequency Selection Priority Validation Failed");
                }

                break;
            }

            /* IE8 - UE Aggregate Maximum Bit Rate */

            case ASN1V_ngap_id_UEAggregateMaximumBitRate:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE8 - UE Aggregate Maximum Bit Rate");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_8,
                            (void *)&p_local_dl_nas_transport->\
                                ue_aggregate_maximum_bit_rate))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE8 - UE Aggregate Maximum Bit Rate Validation Failed");
                }

                break;
            }

            /*IE9 - Allowed NSSAI */
            case ASN1V_ngap_id_AllowedNSSAI:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE9 - Allowed NSSAI");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_DownlinkNASTransport_IEs_9,
                            (void *)&p_local_dl_nas_transport->allowed_nssai_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE9 - Allowed NSSAI Validation failed");
                }

                break;
            }/*end of IE 9*/

            default :
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }

        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_DownlinkNASTransport,
                NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Downlink NAS Transport");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_dl_nas_transport
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_dl_nas_transport
(
    UInt8			                *p_asn_msg,	        /* Input - ASN Encoded Buffer */
    UInt16                          asn_msg_len,	    /* Input - ASN Encoded Buffer Length */
    ngap_downlink_nas_transport_t   *p_dl_nas_transport,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU               ngap_pdu;
    OSCTXT                      asn1_ctx;
    ngap_return_et              response;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
       
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for DL NAS Transport");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of DL NAS Transport Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8*)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode the  message */
        response = ng_dl_nas_transport__internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.downlinkNASTransport,
                p_dl_nas_transport);
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);	
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
    Function Name : ng_ul_nas_transport_internal_dec

    Input : 
    Description:

******************************************************************************/
ngap_return_et ng_ul_nas_transport_internal_dec
(
    /* Input: ASN1 Context to be used */
    OSCTXT                          *p_asn1_ctx,
    /* Input: Received ASN Buffer */   
    ngap_UplinkNASTransport         *p_asn_ul_nas_transport,
    /* Output: Local Message Structure */
    ngap_uplink_nas_transport_t     *p_local_ul_nas_transport
)
{
    OSRTDListNode                                   *p_node                 = NGAP_P_NULL;
    ngap_UplinkNASTransport_protocolIEs_element     *p_protocolIE_elem      = NGAP_P_NULL;
    UInt8                                           ie_index                = NGAP_ZERO;
    UInt16                                          ie_list_index           = NGAP_ZERO;
    ngap_return_et                                  ret_val                 = NGAP_SUCCESS;
    ngap_error_ind_bool_t                           send_err_ind;
    ngap_criticality_diagnostics_ie_list_t          ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn_ul_nas_transport);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map = 
    {4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                    NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID,ngap_mandatory, ngap_reject,
                    NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_NAS_PDU, ngap_mandatory, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_UserLocationInformation, ngap_mandatory, ngap_ignore, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
        }
    };

    /* Initialize the p_node with first IE */
    p_node = p_asn_ul_nas_transport->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_ul_nas_transport->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_UplinkNASTransport_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
             RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
             ret_val = NGAP_FAILURE;
             break;
        }

        switch(p_protocolIE_elem->id)
        {
            /*IE1 - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE1 - AMF UE NGAP ID");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UplinkNASTransport_IEs_1,
                    (void *)&p_local_ul_nas_transport->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed ");
                }
                break;
            }

             /* IE2 - RAN UE NGAP ID */
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE2 - RAN UE NGAP ID");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UplinkNASTransport_IEs_2,
                    (void *)&p_local_ul_nas_transport->ran_ue_ngap_id))
                {
                     RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - RAN UE NGAP ID validation failed");
                }
                break;
            }

            /*IE3 - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                 RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE3 - NAS-PDU");

                 if(NGAP_FAILURE == validate_and_fill_ie_value(
                      &message_map,
                      ie_index,
                      p_protocolIE_elem->id,
                      (void *)p_protocolIE_elem->value.\
                        u._ngap_UplinkNASTransport_IEs_3,
                      (void *)&p_local_ul_nas_transport->nas_pdu))
                 {
                     RRC_NGAP_TRACE(NGAP_ERROR,"IE3 - NAS-PDU Validation Failed");
                 }
                 break;
            }

            /* IE4 - User Location Information */
            case ASN1V_ngap_id_UserLocationInformation:
            {
                 RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE4 - User Location Information ");

                 if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UplinkNASTransport_IEs_4,
                    (void *)&p_local_ul_nas_transport->\
                        choice_user_location_information))
                 {
                     RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE4 - User Location Information Validation Failed");
                 }

                 break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_protocolIE_elem->id);

               /* Add IE to list of Error IEs */
               ngap_add_to_err_ind_ie_list(&ie_list,
                         p_protocolIE_elem->criticality,
                         p_protocolIE_elem->id,
                         &ie_list_index,
                         &send_err_ind,
                         NGAP_FALSE);
            }
        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_UplinkNASTransport,
                NGAP_P_NULL))
     {
         RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Uplink NAS Transport");
         ret_val = NGAP_FAILURE;
     }
     RRC_NGAP_UT_TRACE_EXIT();
     return ret_val;
}


/******************************************************************************
    Function Name : ng_nas_non_delivery_ind_internal_dec

    Input : 
    Description:

******************************************************************************/
ngap_return_et ng_nas_non_delivery_ind_internal_dec
(
    /* Input: ASN1 Context to be used */
    OSCTXT                                *p_asn1_ctx,
    /* Input: Received ASN Buffer */   
    ngap_NASNonDeliveryIndication         *p_asn_nas_non_delivery_ind,
    /* Output: Local Message Structure */
    ngap_nas_non_delivery_indication_t    *p_local_nas_non_delivery_ind
)
{
    ngap_NASNonDeliveryIndication_protocolIEs_element   *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
    NGAP_ASSERT(NGAP_P_NULL != p_asn_nas_non_delivery_ind);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map = 
    {4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                    NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID,ngap_mandatory, ngap_reject,
                    NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_NAS_PDU, ngap_mandatory, ngap_ignore, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
        }
    };
    /*  Initialize pnode with first IE */
    p_node = p_asn_nas_non_delivery_ind->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_nas_non_delivery_ind->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_NASNonDeliveryIndication_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exists", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /*IE1 - AMF_UE_NGAP_ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /*Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_NASNonDeliveryIndication_IEs_1,
                    (void *)&p_local_nas_non_delivery_ind->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            /*IE2 - RAN_UE_NGAP_ID */
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                 RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                 /* Validate and fill IE */
                 if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_NASNonDeliveryIndication_IEs_2,
                    (void *)&p_local_nas_non_delivery_ind->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }
            /*  IE3 - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE5 - NAS-PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_NASNonDeliveryIndication_IEs_3,
                    (void *)&p_local_nas_non_delivery_ind->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE3 - NAS-PDU Validation Failed");
                }
                break;
            }
            /* IE4 - Cause*/
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");
                 /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_NASNonDeliveryIndication_IEs_4,
                    (void *)&p_local_nas_non_delivery_ind->choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_Cause validation failed");
                }
                break;
            }
            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of Switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_NASNonDeliveryIndication,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NAS Non Delivery Indication");
        ret_val = NGAP_FAILURE;
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_ul_nas_transport
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ul_nas_transport
(
    UInt8			            *p_asn_msg,	        /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	    /* Input - ASN Encoded Buffer Length */
    ngap_uplink_nas_transport_t *p_ul_nas_transport /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_return_et          response;
		
    RRC_NGAP_UT_TRACE_ENTER();
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
        Not Sending Error Indication with Transfer Syntax Error 
        because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for UL NAS Transport");
            response = NGAP_FAILURE;
            break;
        }
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8*)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_ul_nas_transport_internal_dec(&asn1_ctx,
            ngap_pdu.u.initiatingMessage->value.u.uplinkNASTransport,
            p_ul_nas_transport);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}


/******************************************************************************
 * Function Name	: ngap_decode_nas_non_delivery_ind
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_nas_non_delivery_ind
(
    UInt8			                    *p_asn_msg,	            /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,	        /* Input - ASN Encoded Buffer Length */
    ngap_nas_non_delivery_indication_t  *p_nas_non_delivery_ind /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NAS non delivery");
            response = NGAP_FAILURE;
            break;
        }
        
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8*)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_nas_non_delivery_ind_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.nASNonDeliveryIndication,
                p_nas_non_delivery_ind);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}


/******************************************************************************
 * Function Name	: ngap_decode_initial_context_setup_req
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_initial_context_setup_req
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_request_t    *p_initial_ctx_setup_req,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response = NGAP_SUCCESS;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Initial context setup request");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_initial_context_setup_req_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.initialContextSetup,
                p_initial_ctx_setup_req);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

/******************************************************************************
 *  Function Name: ng_initial_context_setup_req_internal_dec
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/
ngap_return_et ng_initial_context_setup_req_internal_dec
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_InitialContextSetupRequest         *p_ngap_init_context_setup_req,
    ngap_initial_context_setup_request_t    *p_ngap_local_init_context_setup_req
)
{
    ngap_InitialContextSetupRequest_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_init_context_setup_req);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {22, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_OldAMF, ngap_optional, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_UEAggregateMaximumBitRate, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_CoreNetworkAssistanceInformationForInactive,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_GUAMI, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                6, ASN1V_ngap_id_PDUSessionResourceSetupListCxtReq, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                7, ASN1V_ngap_id_AllowedNSSAI, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                8, ASN1V_ngap_id_UESecurityCapabilities, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                9, ASN1V_ngap_id_SecurityKey, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                10, ASN1V_ngap_id_TraceActivation, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                11, ASN1V_ngap_id_MobilityRestrictionList, ngap_optional,
                ngap_ignore,  NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                12, ASN1V_ngap_id_UERadioCapability, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                13, ASN1V_ngap_id_IndexToRFSP, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                14, ASN1V_ngap_id_MaskedIMEISV, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                15, ASN1V_ngap_id_NAS_PDU, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                16, ASN1V_ngap_id_EmergencyFallbackIndicator, ngap_optional,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                17, ASN1V_ngap_id_RRCInactiveTransitionReportRequest,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO
            },
            {
                18, ASN1V_ngap_id_UERadioCapabilityForPaging, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                19, ASN1V_ngap_id_RedirectionVoiceFallback, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                20, ASN1V_ngap_id_LocationReportingRequestType, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                21, ASN1V_ngap_id_CNAssistedRANTuning, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_init_context_setup_req->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_init_context_setup_req->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_InitialContextSetupRequest_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_1,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_2,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* Decode IE OLD AMF */
            case ASN1V_ngap_id_OldAMF:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE3 - Old AMF");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_3,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                amf_name.amf_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_OldAMF validation failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_OLD_AMF_PRESENT;
                }
                break;
            }

            /* Decode IE - UE AGGREAGATE MAX BIT RATE*/
            case ASN1V_ngap_id_UEAggregateMaximumBitRate:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE4 - UE Aggregate Maximum Bit Rate");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_4,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                ue_aggregate_maximum_bit_rate))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE4 - UE Aggregate Maximum Bit Rate Validation Failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_UE_AGGR_MAX_BIT_RATE_PRESENT;
                }
                break;
            }

            /* Decode IE - CORE NETWORK ASSISTANCE INFO */
           /* case ASN1V_ngap_id_CoreNetworkAssistanceInformation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE5 - CORE NETWORK ASSISTANCE INFO");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.u._ngap_InitialContextSetupRequestIEs_5,
                            (void *)&p_ngap_local_init_context_setup_req->core_network_assistance_info
                            ))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "IE4 - CORE NETWORK ASSISTANCE INFO Validation Failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_CORE_NETWORK_ASSISTANCE_INFO_PRESENT;
                }
            }*/


            /* Decode IE - GUAMI */
            case ASN1V_ngap_id_GUAMI:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE6 - GUAMI");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                             &message_map,
                             ie_index,
                             p_protocolIE_elem->id,
                             (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_6,
                             (void *)&p_ngap_local_init_context_setup_req->guami))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "IE6 - GUAMI Validation failed");
                }
                break;
            }

            /* Decode IE - PDU Session Resource Setup Request List */
            case ASN1V_ngap_id_PDUSessionResourceSetupListCxtReq:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE7 - ASN1V_ngap_id_PDUSessionResourceSetupListCxtReq");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupRequestIEs_7,
                    (void *)&p_ngap_local_init_context_setup_req->\
                        pdu_session_resource_setup_request_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE7 ASN1V_ngap_id_PDUSessionResourceSetupListCxtReq Validation failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_PDU_SESSION_RESOURCE_SETUP_REQUEST_LIST_PRESENT;
                }
                break;
            }
            /* Decode IE - Allowed NSSAI */

            case ASN1V_ngap_id_AllowedNSSAI:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE8 - Allowed NSSAI");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_8,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                allowed_nssai_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE8 - Allowed NSSAI Validation failed");
                }
                break;
            }

            /* Decode IE - UE Security Capabilities */
            case ASN1V_ngap_id_UESecurityCapabilities:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_UESecurityCapabilities");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_9,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                ue_security_capabilities))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_UESecurityCapabilities validation Failed");

                }
                break;
            }

            /* Decode IE - Security Key */
            case ASN1V_ngap_id_SecurityKey:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_SecurityKey");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_10,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                security_key))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_SecurityKey Validation failed");
                }
                break;
            }

            /* Decode IE - UE RADIO CAPABILITY */
            case ASN1V_ngap_id_UERadioCapability:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE13 - ASN1V_ngap_id_UERadioCapability");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_13,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                ue_radio_capability.ue_radio_capability))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE13 - UE Radio Capability Validation Failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_UE_RADIO_CAPABILITY_PRESENT;
                }
                break;
            }

            /* Decode IE - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE16 - NAS-PDU");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_16,
                            (void *)&p_ngap_local_init_context_setup_req->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE16 - NAS-PDU Validation Failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_NAS_PDU_PRESENT;
                }
                break;
            }

            /* Decode IE - UE Radio Capability for Paging */
            case ASN1V_ngap_id_UERadioCapabilityForPaging:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE19 - ASN1V_ngap_id_UERadioCapabilityForPaging");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupRequestIEs_19,
                            (void *)&p_ngap_local_init_context_setup_req->\
                                ue_radio_capability_for_paging))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE19 - UE Radio Capability for paging Validation Failed");
                }

                break;
            }

            case ASN1V_ngap_id_RedirectionVoiceFallback: 
            {
                break;
            }

            case ASN1V_ngap_id_LocationReportingRequestType:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE21 - Location Reporting Request type");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_InitialContextSetupRequestIEs_21,
                            (void *)&p_ngap_local_init_context_setup_req->\
                            location_reporting_Req_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE3 - ASN1V_ngap_id_LocationReportingRequestType validation failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                        INITIAL_CONTEXT_SETUP_REQUEST_LOCATION_REPORTING_REQUEST_TYPE_PRESENT;
                }

                break;
            }
            
            case ASN1V_ngap_id_CNAssistedRANTuning:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE21 - Location Reporting Request type");
                
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_InitialContextSetupRequestIEs_22,
                            (void *)&p_ngap_local_init_context_setup_req->\
                            can_assisted_ran_tuning))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE3 - ASN1V_ngap_id_CNAssistedRANTuning validation failed");
                }
                else
                {
                    p_ngap_local_init_context_setup_req->bitmask |=
                       INITIAL_CONTEXT_SETUP_REQUEST_CNASSITED_RAN_TUNING_PRESENT;
                }

                break;
            }
            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }
        p_node = p_node->next;
    }
    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_InitialContextSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Initial Context Setup Request");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_initial_context_setup_resp
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_initial_context_setup_resp
(
    UInt8			                        *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_response_t   *p_initial_ctx_setup_resp   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                       ngap_pdu;
    OSCTXT                              asn1_ctx;
    ngap_return_et                      response = NGAP_SUCCESS;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Initial Context Setup response");
            response = NGAP_FAILURE;
            break;
        }
        

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_initial_context_setup_res_internal_dec(&asn1_ctx,
                ngap_pdu.u.successfulOutcome->value.u.initialContextSetup,
                p_initial_ctx_setup_resp);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

/***************************************************************************
 * Function Name : 
 *
 * Inputs: 
 *
 * outputs: 
 *
 * Description : 
 *
 * Returns
 * *************************************************************************/
ngap_return_et ng_initial_context_setup_res_internal_dec
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_InitialContextSetupResponse        *p_asn_ng_initial_context_setup_resp,
    ngap_initial_context_setup_response_t   *p_local_ng_initial_context_setup_resp
)
{
    
    ngap_InitialContextSetupResponse_protocolIEs_element    *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node       = NGAP_P_NULL;
    UInt8                                   ie_index      = NGAP_ZERO;
    UInt16                                  ie_list_index = NGAP_ZERO;
    ngap_return_et                          ret_val       = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_initial_context_setup_resp);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
   
    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                 NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   2,ASN1V_ngap_id_PDUSessionResourceSetupListCxtRes,
                ngap_mandatory, ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, 
                NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtRes,
                ngap_mandatory, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

   p_local_ng_initial_context_setup_resp->bitmask = 0x00;

   /*Initialize pnode with first IE*/
   p_node = p_asn_ng_initial_context_setup_resp->protocolIEs.head;
   if(NGAP_P_NULL == p_node)
   {
       RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");
       return NGAP_FAILURE;
   }

   for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_initial_context_setup_resp->protocolIEs.count;
            ie_index++)
   {
       if(NGAP_P_NULL == p_node)
       {
           RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
           ret_val = NGAP_FAILURE;
           break;
       }

       p_protocolIE_elem = 
            (ngap_InitialContextSetupResponse_protocolIEs_element *)p_node->data;

       if(NGAP_P_NULL == p_protocolIE_elem)
       {
           RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
           ret_val = NGAP_FAILURE;
           break;
       }

       switch(p_protocolIE_elem->id)
       {
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupResponseIEs_1,
                    (void *)&p_local_ng_initial_context_setup_resp->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupResponseIEs_2,
                    (void *)&p_local_ng_initial_context_setup_resp->\
                        ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
               break;
            }
            
            case ASN1V_ngap_id_PDUSessionResourceSetupListCxtRes:
            {
                 RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_PDUSessionResourceSetupListCxtRes");

                 /*Validate and fill IE*/
                 if(NGAP_FAILURE == validate_and_fill_ie_value(
                             &message_map,
                             ie_index,
                             p_protocolIE_elem->id,
                             (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupResponseIEs_3,
                             (void *)&p_local_ng_initial_context_setup_resp->\
                                pdu_session_resource_setup_response_list))
                 {
                     RRC_NGAP_TRACE(NGAP_ERROR, 
                         "IE3 - ASN1V_ngap_id_PDUSessionResourceSetupListCxtRes validation failed");
                 }
                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtRes:
            {

                 RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes");

                 /*Validate and fill IE*/
                 if(NGAP_FAILURE == validate_and_fill_ie_value(
                             &message_map,
                             ie_index,
                             p_protocolIE_elem->id,
                             (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupResponseIEs_4,
                             (void *)&p_local_ng_initial_context_setup_resp->\
                                pdu_session_resource_failed_to_setup_list))
                 {
                     RRC_NGAP_TRACE(NGAP_ERROR, 
                         "IE3 - ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes validation failed");
                 }
                break;
            }

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupResponseIEs_5,
                    (void *)&p_local_ng_initial_context_setup_resp->\
                        criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE5 - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                break;
            }

            default:
            {
                
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
       }/*End of switch*/

       p_node = p_node->next;

   }/*End of for*/

   /*Parse the map for Error Indication */
   if(NGAP_FAILURE == parse_ngap_message_map(
               p_asn1_ctx,
               &message_map,
               &ie_list,
               &ie_list_index,
               &send_err_ind,
               ASN1V_ngap_id_InitialContextSetup,
               (ngap_error_indication_t *)NGAP_P_NULL))
   {
       RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Initial Context Setup Response");
       ret_val = NGAP_FAILURE;
   }



    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
    Function Name: ng_initial_context_setup_fail_internal_dec
    INputs:
    Outputs:
    Returns :
    Description: 

******************************************************************************/
ngap_return_et ng_initial_context_setup_fail_internal_dec
(
    /* Input: ASN1 Context to be used */
    OSCTXT			                        *p_asn1_ctx,        
    /* Input: Received ASN Buffer */                
    ngap_InitialContextSetupFailure         *p_asn_ng_initial_context_setup_fail,
    /* Output: Local Message Structure */
    ngap_initial_context_setup_failure_t    *p_local_ng_initial_context_setup_fail
)
{
    ngap_InitialContextSetupFailure_protocolIEs_element *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn_ng_initial_context_setup_fail);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));
    /*GQA - 1214 :start*/
    NGAP_MEMSET(p_local_ng_initial_context_setup_fail, NGAP_ZERO,
            sizeof(ngap_initial_context_setup_failure_t)); 
    /*GQA - 1214 :end*/
    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, 
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtFail, 
                ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    p_local_ng_initial_context_setup_fail->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ng_initial_context_setup_fail->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ng_initial_context_setup_fail->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_InitialContextSetupFailure_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
             /* IE1 - AMF_UE_NGAP_ID */
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupFailureIEs_1,
                    (void *)&p_local_ng_initial_context_setup_fail->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupFailureIEs_2,
                    (void *)&p_local_ng_initial_context_setup_fail->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
               break;
            }
            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtFail:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtFail");

                /*validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_InitialContextSetupFailureIEs_3,
                            (void *)&p_local_ng_initial_context_setup_fail->\
                                pdu_session_resource_failed_to_setup_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                  "IE 3 - ASN1V_ngap_id_PDUSessionResourceFailedToSetupListCxtFail validation failed");  
                }
                /*GQA - 1214 :start*/
                else
                {
                    p_local_ng_initial_context_setup_fail->bitmask |=
                        INITIAL_CONTEXT_SETUP_FAILURE_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_PRESENT;
                
                }
                /*GQA - 1214 :end*/ 
                break;

            }
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupFailureIEs_4,
                    (void *)&p_local_ng_initial_context_setup_fail->\
                        choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_Cause validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_InitialContextSetupFailureIEs_5,
                    (void *)&p_local_ng_initial_context_setup_fail->\
                        criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE5 - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                break;
            }
            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_InitialContextSetup,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Initial Context Setup Failure");
        ret_val = NGAP_FAILURE;
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_initial_context_setup_fail
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_initial_context_setup_fail
(
    UInt8			                        *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_failure_t    *p_initial_ctx_setup_fail   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response;
		
    RRC_NGAP_UT_TRACE_ENTER();
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
        Not Sending Error Indication with Transfer Syntax Error 
        because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Initial context setup failure");
            response = NGAP_FAILURE;
            break;
        }
        

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_initial_context_setup_fail_internal_dec(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome->value.u.initialContextSetup,
                p_initial_ctx_setup_fail);
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/***************************************************************************
 * Function Name:
 *
 * Inputts:
 *
 * Outputs:
 *
 * Description:
 *
 * Returns:
 *
 * ************************************************************************/
ngap_return_et ngap_decode_ue_radio_capability_info_ind
(
    UInt8			                            *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                      asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_ue_radio_capability_info_indication_t  *p_ue_radio_cap_info_info_ind    /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_return_et                          response;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for UE RADIO capability Info indication");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of UE radio capability Info indication  Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        
        response = ue_radio_capability_info_ind_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.uERadioCapabilityInfoIndication,
                p_ue_radio_cap_info_info_ind);
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

ngap_return_et ue_radio_capability_info_ind_internal_dec
(
     OSCTXT                                     *p_asn1_ctx,
     ngap_UERadioCapabilityInfoIndication       *p_ngap_asn_ue_radio_cap_info_ind,
     ngap_ue_radio_capability_info_indication_t *p_ngap_local_ue_radio_cap_info_ind
)
{

    ngap_UERadioCapabilityInfoIndication_protocolIEs_element    *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                            *p_node             = NGAP_P_NULL;
    UInt8                                    ie_index            = NGAP_ZERO;
    UInt16                                   ie_list_index       = NGAP_ZERO;
    ngap_return_et                           ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                    send_err_ind;
    ngap_criticality_diagnostics_ie_list_t   ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_ue_radio_cap_info_ind);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
    
    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));
    
    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map =
    {4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0,ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO 
            },
            {
                2, ASN1V_ngap_id_UERadioCapability, ngap_mandatory, 
                ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3,ASN1V_ngap_id_UERadioCapabilityForPaging, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO 
            }
        }
    };

     p_node = p_ngap_asn_ue_radio_cap_info_ind->protocolIEs.head;
     if(NGAP_P_NULL == p_node)
     {
         RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
         return NGAP_FAILURE;
     }

     for(ie_index = NGAP_ZERO; ie_index < 
                p_ngap_asn_ue_radio_cap_info_ind->protocolIEs.count;
                ie_index++)
     {
         if(NGAP_P_NULL == p_node)
         {
             RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
             ret_val = NGAP_FAILURE;
             break;
         }

         p_protocolIE_elem =
            (ngap_UERadioCapabilityInfoIndication_protocolIEs_element *)p_node->data;
         if(NGAP_P_NULL == p_protocolIE_elem)
         {
             RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
             ret_val = NGAP_FAILURE;
             break;
         }

         switch(p_protocolIE_elem->id)
         {
            /* IE1 - AMF_UE_NGAP_ID */
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UERadioCapabilityInfoIndicationIEs_1,
                    (void *)&p_ngap_local_ue_radio_cap_info_ind->amf_ue_ngap_id_t))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UERadioCapabilityInfoIndicationIEs_2,
                    (void *)&p_ngap_local_ue_radio_cap_info_ind->ran_ue_ngap_id_t))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
               break;
            }
            
            case ASN1V_ngap_id_UERadioCapability:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE13 - ASN1V_ngap_id_UERadioCapability");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UERadioCapabilityInfoIndicationIEs_3,
                    (void *)&p_ngap_local_ue_radio_cap_info_ind->\
                        ue_radio_capability))
                {
                     RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - UE Radio Capability Validation Failed");
                }
                break;
            }

            case ASN1V_ngap_id_UERadioCapabilityForPaging:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE4 - ASN1V_ngap_id_UERadioCapabilityForPaging");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UERadioCapabilityInfoIndicationIEs_4,
                    (void *)&p_ngap_local_ue_radio_cap_info_ind->\
                        ue_radio_capability_for_paging))
                {
                     RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE4 - UE Radio Capability for paging Validation Failed");
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

         }/*End of switch*/

         p_node = p_node->next;

     }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_UERadioCapabilityInfoIndication,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
            "Failed to decode UE Radio Capability Info Indication");
        ret_val = NGAP_FAILURE;
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;

}





/******************************************************************************
    Function Name  : 

    Inputs :

    Outputs: 

    Description : 
******************************************************************************/
ngap_return_et ng_ue_context_release_req_internal_dec
(
    OSCTXT                              *p_asn1_ctx,                    /* Input: ASN1 Context to be used */
    ngap_UEContextReleaseRequest        *p_asn_ue_context_release_req,  /* Input: Received ASN Buffer */
    ngap_ue_context_release_request_t   *p_local_ue_context_release_req /* Output - Local Buffer */   
)
{
    ngap_UEContextReleaseRequest_protocolIEs_element    *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
    NGAP_ASSERT(NGAP_P_NULL != p_asn_ue_context_release_req);
    
    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map =
    {4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2,ASN1V_ngap_id_PDUSessionResourceListCxtRelReq, 
                ngap_optional, ngap_reject, NGAP_ZERO, NGAP_ZERO, 
                NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    /*  Initialize pnode with first IE */
    p_node = p_asn_ue_context_release_req->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ue_context_release_req->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_UEContextReleaseRequest_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exists", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /* IE1 - AMF_UE_NGAP_ID */
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseRequest_IEs_1,
                    (void *)&p_local_ue_context_release_req->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseRequest_IEs_2,
                    (void *)&p_local_ue_context_release_req->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
               break;
            }

            case ASN1V_ngap_id_PDUSessionResourceListCxtRelReq:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode ASN1V_ngap_id_PDUSessionResourceListCxtRelReq");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseRequest_IEs_3,
                    (void *)&p_local_ue_context_release_req->\
                        pdu_session_resource_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE3 - ASN1V_ngap_id_PDUSessionResourceListCxtRelReq Validation failed");
                }
                else
                {
                    p_local_ue_context_release_req->bitmask |= 
                        UE_CONTEXT_RELEASE_REQUEST_PDU_SESSION_RESOURCE_LIST_PRESENT;
                }
                break;
            }
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseRequest_IEs_4,
                    (void *)&p_local_ue_context_release_req->choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_Cause validation failed");
                }
                break;
            }
            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of Switch*/

        p_node = p_node->next;

    }/*End of for*/

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_UEContextReleaseRequest,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode UE Context Release Request");
        ret_val = NGAP_FAILURE;
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name	: ngap_decode_ue_context_release_req
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ue_context_release_req
(
    UInt8			                    *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_request_t   *p_ue_context_release_req   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_ue_context_release_req_internal_dec(&asn1_ctx,
                (ngap_UEContextReleaseRequest *)ngap_pdu.u.initiatingMessage->value.\
                    u.uEContextRelease,
                p_ue_context_release_req);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}


/******************************************************************************
 * Function Name	: ngap_decode_ue_context_release_req_command
 * Inputs           	: p_ue_context_release_command - Information from which 
 *                          Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function decodes UE CONTEXT RELEASE COMMAND ASN message 
 *                  from the information provided in p_ue_context_release_command
 *****************************************************************************/
ngap_return_et ngap_decode_ue_context_release_command
(
    UInt8			                    *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_command_t   *p_ue_context_release_command,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response = NGAP_SUCCESS;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for UE Context Release Complete");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_ue_context_release_command_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.uEContextRelease,
                p_ue_context_release_command);
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

/****************************************************************************
 *  Function Name: 
 *
 *  Inputs:
 *
 *  Outputs:
 *  
 *  Description:

    Returns:
* *************************************************************************/
ngap_return_et ng_ue_context_release_command_internal_dec
(
    OSCTXT                              *p_asn1_ctx,
    ngap_UEContextReleaseCommand        *p_ngap_ue_context_release_command,
    ngap_ue_context_release_command_t   *p_ngap_local_ue_context_release_command
)
{
    
    ngap_UEContextReleaseCommand_protocolIEs_element *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;


    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_ue_context_release_command);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);
    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE */
    ngap_message_data_t message_map =
    {2, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_UE_NGAP_IDs, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                    NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };
    p_node = p_ngap_ue_context_release_command->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
                p_ngap_ue_context_release_command->protocolIEs.count;
                ie_index++)
    {

        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem =
            (ngap_UEContextReleaseCommand_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exists", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_ngap_id_UE_NGAP_IDs:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_UE_NGAP_IDs");
                
                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseCommand_IEs_1,
                    (void *)p_ngap_local_ue_context_release_command))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_UE_NGAP_IDs validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");
                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseCommand_IEs_2,
                    (void *)&p_ngap_local_ue_context_release_command->\
                        choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_Cause validation failed");
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }/*End of switch*/
        p_node = p_node->next;
    }/*End of for*/


    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_UEContextRelease,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode UE Context Release Command");
        ret_val = NGAP_FAILURE;
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/******************************************************************************
 * Function Name	: ngap_decode_ue_context_release_complete
 * Inputs           	: p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NG SETUP REQUEST ASN message from the information 
 *				   provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_decode_ue_context_release_complete
(
    UInt8			                    *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_complete_t  *p_ue_context_release_complete   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_return_et                  response = NGAP_SUCCESS;
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=  
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for UE Context Release Complete");
            response = NGAP_FAILURE;
            break;
        }
       
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        
        response = ue_context_release_complete_internal_dec(&asn1_ctx,
                ngap_pdu.u.successfulOutcome->value.u.uEContextRelease,
                p_ue_context_release_complete);
        
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}

/******************************************************************************
 *
 * Function Name : ue_context_release_complete_internal_dec
 *
 * Inputs: 
 *  
 * outputs:
 *  
 * Description :
 *
 * Returns:
 * ***************************************************************************/
ngap_return_et ue_context_release_complete_internal_dec
(
    OSCTXT                              *p_asn1_ctx,
    ngap_UEContextReleaseComplete       *p_ngap_asn_ue_context_rel_complete,
    ngap_ue_context_release_complete_t  *p_ngap_local_ue_context_rel_complete
)
{

    ngap_UEContextReleaseComplete_protocolIEs_element *p_protocolIE_elem  = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;


    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_ue_context_rel_complete);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO, sizeof(ngap_criticality_diagnostics_ie_list_t));


    ngap_message_data_t message_map = 
    {6, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {     
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_UserLocationInformation, ngap_optional, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_InfoOnRecommendedCellsAndRANNodesForPaging,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO             
            },
            {
                4, ASN1V_ngap_id_PDUSessionResourceListCxtRelCpl,
                ngap_optional, ngap_reject, NGAP_ZERO, NGAP_ZERO, 
                NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };
    
    p_node = p_ngap_asn_ue_context_rel_complete->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First Node is NULL");
        ret_val = NGAP_FAILURE;
        return ret_val;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
                p_ngap_asn_ue_context_rel_complete->protocolIEs.count;
                ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_UEContextReleaseComplete_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_1,
                    (void *)&p_ngap_local_ue_context_rel_complete->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)&p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_2,
                    (void *)&p_ngap_local_ue_context_rel_complete->ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 
               break;
            }

            
            case ASN1V_ngap_id_UserLocationInformation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - User Location Information ");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_3,
                    (void *)&p_ngap_local_ue_context_rel_complete->\
                        choice_user_location_information))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - User Location Information Validation Failed");
                }
                break;
            }

            /*Decode Information on Recommended Cells and RAN Nodes for Paging*/
            case ASN1V_ngap_id_InfoOnRecommendedCellsAndRANNodesForPaging:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_InfoOnRecommendedCellsAndRANNodesForPaging");

                /*Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_4,
                    (void *)&p_ngap_local_ue_context_rel_complete->\
                        info_on_recommended_cells_and_ran_nodes_for_paging))
                {

                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_InfoOnRecommendedCellsAndRANNodesForPaging validation failed");
                }
                break;
            }

            /*Decode PDU Session Resource List*/

            case ASN1V_ngap_id_PDUSessionResourceListCxtRelCpl:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_PDUSessionResourceListCxtRelCpl");

                /*Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_5,
                    (void *)&p_ngap_local_ue_context_rel_complete->\
                        pdu_session_resource_item_t))
                {

                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_PDUSessionResourceListCxtRelCpl validation failed");
                }

                break;
            }

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                        u._ngap_UEContextReleaseComplete_IEs_6,
                    (void *)&p_ngap_local_ue_context_rel_complete->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                break;
            }
            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }

        }/*End of switch*/

        p_node = p_node->next;

    }/*End of for*/
    
    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
        p_asn1_ctx,
        &message_map,
        &ie_list,
        &ie_list_index,
        &send_err_ind,
        ASN1V_ngap_id_UEContextRelease,
        (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Error Indication");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}



/******************************************************************************
 * Function Name    : ngap_decode_paging
 * Input            : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Output           : p_ngap_paging - Information from which local buffer will be filled
 * Returns          : NGAP_SUCCESS - ASN decoding was successful
 *                      NGAP_FAILURE - ASN decoding was not successful
 * DESCRIPTION	    : This function decodes Paging ASN message.
 *****************************************************************************/
ngap_return_et ngap_decode_paging
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_paging_t           *p_ngap_paging,	/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;

    NGAP_MEMSET(p_ngap_paging, NGAP_ZERO, sizeof(ngap_paging_t));
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Paging");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of Paging Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }

#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_paging_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.paging,
                p_ngap_paging);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}


ngap_return_et ngap_paging_internal_dec
(
    OSCTXT			*p_asn1_ctx,         /* Input: ASN1 Context to be used */
    ngap_Paging     *p_asn_ngap_paging,  /* Input: Received ASN Buffer */
    ngap_paging_t   *p_local_ngap_paging /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_Paging_protocolIEs_element         *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ngap_paging);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {7, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_UEPagingIdentity, ngap_mandatory, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_PagingDRX, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_TAIListForPaging, ngap_mandatory, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {3, ASN1V_ngap_id_PagingPriority, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {4, ASN1V_ngap_id_UERadioCapabilityForPaging, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {5, ASN1V_ngap_id_PagingOrigin, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {6, ASN1V_ngap_id_AssistanceDataForPaging, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };
    
    p_local_ngap_paging->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ngap_paging->protocolIEs.head;
    
    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO;
        ie_index < p_asn_ngap_paging->protocolIEs.count; 
        ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_Paging_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_UEPagingIdentity:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_UEPagingIdentity");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_1,
                            (void *)&p_local_ngap_paging->ue_paging_identity))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_UEPagingIdentity Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_PagingDRX:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_PagingDRX");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_2,
                            (void *)&p_local_ngap_paging->paging_drx))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE2 - ASN1V_ngap_id_PagingDRX Validation failed");
                }
                else
                {
                    p_local_ngap_paging->bitmask |= 
                        NGAP_PAGING_PAGING_DRX_PRESENT;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_TAIListForPaging:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE ASN1V_ngap_id_TAIListForPaging");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_3,
                            (void *)&p_local_ngap_paging->tai_list_for_paging))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_TAIListForPaging Validation failed");
                }
                break;
            } /* End of IE3 */

            /* IE4 */
            case ASN1V_ngap_id_PagingPriority:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_PagingPriority");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_4,
                            (void *)&p_local_ngap_paging->paging_priority))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_PagingPriority Validation failed");
                }
                else
                {
                    p_local_ngap_paging->bitmask |= 
                        NGAP_PAGING_PAGING_PRIORITY_PRESENT;
                }

                break;
            } /* End of IE4 */

            /* IE5 */
            case ASN1V_ngap_id_UERadioCapabilityForPaging:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_UERadioCapabilityForPaging");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_5,
                            (void *)&p_local_ngap_paging->\
                                ue_radio_capability_for_paging))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_UERadioCapabilityForPaging Validation failed");
                }
                else
                {
                    p_local_ngap_paging->bitmask |= 
                        NGAP_PAGING_PAGING_UE_RADIO_CAPABILITY_FOR_PAGING_PRESENT;
                }

                break;
            } /* End of IE5 */

            /* IE6 */
            case ASN1V_ngap_id_PagingOrigin:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_PagingOrigin");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_6,
                            (void *)&p_local_ngap_paging->paging_origin))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_PagingOrigin Validation failed");
                }
                else
                {
                    p_local_ngap_paging->bitmask |= 
                        NGAP_PAGING_PAGING_ORIGIN_PRESENT;
                }

                break;
            } /* End of IE6 */

            /* IE7 */
            case ASN1V_ngap_id_AssistanceDataForPaging:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AssistanceDataForPaging");

                RRC_NGAP_TRACE(NGAP_INFO, 
                    "IE AssistanceDataForPaging not supported at NGAP");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_PagingIEs_7,
                            (void *)&p_local_ngap_paging->\
                                assistance_data_for_paging))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE4 - ASN1V_ngap_id_AssistanceDataForPaging Validation failed");
                }
                else
                {
                    p_local_ngap_paging->bitmask |= 
                        NGAP_PAGING_PAGING_ASSISTANCE_DATA_FOR_PAGING_PRESENT;
                }

                break;
            } /* End of IE7 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */
        
        p_node = p_node->next;
        
    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_NGSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NGAP Paging");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/******************************************************************************
 * Function Name    : ngap_internal_decode_pdu_session_resource_setup_response 
 * Input            : p_asn1_ctx - ASN context pointer
 *                    p_asn_pdu_session_resource_setup_resp - ASN structure 
 *                    pointer.
 *                    p_local_pdu_session_resource_setup_resp - Local 
 *                    Strucuture pointer
 * Output           : Decoded 
 * Returns          : NGAP_SUCCESS - ASN decoding was successful
 *                    NGAP_FAILURE - ASN decoding was not successful
 * DESCRIPTION	    : This function decodes Paging ASN message.
 *****************************************************************************/
ngap_return_et ngap_internal_decode_pdu_session_resource_setup_response
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupResponse        *p_asn_pdu_session_resource_setup_resp,
    ngap_pdu_session_resource_setup_response_t  *p_local_pdu_session_resource_setup_resp
)
{
    ngap_PDUSessionResourceSetupResponse_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn_pdu_session_resource_setup_resp);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));;

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =

    { 5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {            
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2,ASN1V_ngap_id_PDUSessionResourceSetupListSURes ,
                ngap_optional ,ngap_ignore, NGAP_ZERO, NGAP_ZERO, 
                NGAP_ZERO, NGAP_ZERO
            },
            {   3,ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes, 
                ngap_optional, ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO
            },
            {
                4,ASN1V_ngap_id_CriticalityDiagnostics,ngap_optional, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO 
            }
        }
    };

    /* Initialize pnode with first IE */
    p_node = p_asn_pdu_session_resource_setup_resp->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_pdu_session_resource_setup_resp->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem =
            (ngap_PDUSessionResourceSetupResponse_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id )
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupResponseIEs_1,
                            (void *)&p_local_pdu_session_resource_setup_resp->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            
            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupResponseIEs_2,
                            (void *)&p_local_pdu_session_resource_setup_resp->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* Decode IE - PDU Session Resource Setup List SU Res*/
            case ASN1V_ngap_id_PDUSessionResourceSetupListSURes:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceSetupListSURes");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupResponseIEs_3,
                            (void *)&p_local_pdu_session_resource_setup_resp->\
                            pdu_session_resource_setup_response_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE3 - ASN1V_ngap_id_PDUSessionResourceSetupListSURes Validation failed");
                }
                else
                {
                    p_local_pdu_session_resource_setup_resp->bitmask |= 
                        NGAP_PDU_SESSION_RESOURCE_SETUP_LIST_SU_RES;
                }
                break;
            }

            /* Decode IE - PDU Session Resource Failed To Setup List SU Res*/
            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes:

            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupResponseIEs_4,
                            (void *)&p_local_pdu_session_resource_setup_resp->\
                            pdu_session_resource_failed_to_setup_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE4 - ASN1V_ngap_id_PDUSessionResourceFailedToSetupListSURes Validation failed");
                }
                else
                {
                    p_local_pdu_session_resource_setup_resp->bitmask |= 
                        NGAP_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_SU_RES;
                }
                break;
            }

            /* Decode IE - Criticality Diagnostics */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupResponseIEs_5,
                            (void *)&p_local_pdu_session_resource_setup_resp->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE5 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_pdu_session_resource_setup_resp->bitmask |= 
                        NGAP_PDU_SESSION_RESOURCE_CRITICALITY_DIGNOSTICS;
                }
                break;
            }
        }//end switch
        p_node = p_node->next;
    }//end for
    /*Parse the map for Error Indication */    
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_PDUSessionResourceSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Pdu Session Resource Setup Response");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

ngap_return_et ngap_decode_pdu_session_resource_setup_response
(
    UInt8                                       *p_asn_msg,                                   /* Input - ASN Encoded Buffer*/
    UInt16                                      asn_msg_len,                                  /* Input-ASN Encoded Buffer Length*/
    ngap_pdu_session_resource_setup_response_t  *p_local_pdu_session_resource_setup_response  /* Output -Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
    NGAP_MEMSET(
    p_local_pdu_session_resource_setup_response,
    NGAP_ZERO,
    sizeof(ngap_pdu_session_resource_setup_response_t));
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for PDU Session Resource setup Response");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Decoding of PDU SESSION RESOURCE SETUP RESPONSE FAILED ");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
        
        /*Decode Message */
         response = ngap_internal_decode_pdu_session_resource_setup_response(&asn1_ctx,
                   ngap_pdu.u.successfulOutcome->value.u.pDUSessionResourceSetup,
                    p_local_pdu_session_resource_setup_response);


    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;

}

ngap_return_et  ngap_internal_decode_pdu_session_resource_setup_request
(
       OSCTXT                                            *p_asn1_ctx,
       ngap_PDUSessionResourceSetupRequest               *p_asn_pdu_session_resource_setup_req,
       ngap_pdu_session_resource_setup_request_t         *p_local_pdu_session_resource_setup_req

)
{
    ngap_PDUSessionResourceSetupRequest_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_asn_pdu_session_resource_setup_req);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));
    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {6, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                2,  ASN1V_ngap_id_RANPagingPriority, ngap_optional, 
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,NGAP_ZERO      
            },
            {
                3, ASN1V_ngap_id_NAS_PDU, ngap_optional, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                4,ASN1V_ngap_id_PDUSessionResourceSetupListSUReq,ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                5, ASN1V_ngap_id_UEAggregateMaximumBitRate, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    /* Initialize pnode with first IE */

    p_node = p_asn_pdu_session_resource_setup_req->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_pdu_session_resource_setup_req->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem =
            (ngap_PDUSessionResourceSetupRequest_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupRequestIEs_1,
                            (void *)&p_local_pdu_session_resource_setup_req->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupRequestIEs_2,
                            (void *)&p_local_pdu_session_resource_setup_req->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }

                break;
            }

            /*IE3 - RAN Paging Priority */
            case ASN1V_ngap_id_RANPagingPriority:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE3 - RAN Paging Priority");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupRequestIEs_3,
                            (void *)&p_local_pdu_session_resource_setup_req->\
                            ran_paging_priority.ran_paging_priority))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE3 - RAN Paging Priority validation failed");
                }

                break;
            }

            /*IE4 - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE4 - NAS-PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupRequestIEs_4,
                            (void *)&p_local_pdu_session_resource_setup_req->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE4 - NAS-PDU Validation Failed");
                }
                else 
                {
                    p_local_pdu_session_resource_setup_req->bitmask |=
                        PDU_SESSION_REQUEST_NGAP_NAS_PDU;
                }

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceSetupListSUReq:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                    "Decode IE5 - PDU SESSION RESOURCE SETUP REQUEST");
                
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                    &message_map,
                    ie_index,
                    p_protocolIE_elem->id,
                    (void *)p_protocolIE_elem->value.\
                    u._ngap_PDUSessionResourceSetupRequestIEs_5,
                    (void *)&p_local_pdu_session_resource_setup_req->\
                    pdu_session_resource_setup_request_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE5 - PDU SESSION RESOURCE SETUP REQUEST FAILED");
                }
                break;
            }

            /* IE6 - UE Aggregate Maximum Bit Rate */

            case ASN1V_ngap_id_UEAggregateMaximumBitRate:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE6 - UE Aggregate Maximum Bit Rate");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceSetupRequestIEs_6,
                            (void *)&p_local_pdu_session_resource_setup_req->\
                            ue_aggregate_maximum_bit_rate))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE6 - UE Aggregate Maximum Bit Rate Validation Failed");
                }

                break;
            }
            
            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end of switch case
        p_node = p_node->next;
    }//end of for loop

    /*Parse the map for Error Indication */

    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_PDUSessionResourceSetup,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Pdu Session Resource Setup Request");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

ngap_return_et  ngap_decode_pdu_session_resource_setup_request
(
    UInt8                                       *p_asn_msg,/* Input - ASN Encoded Buffer */
    UInt16                                      asn_msg_len,/* Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_setup_request_t   *p_local_pdu_session_res_setup_req
                                                    /* Output - Local Buffer */
)
{
        
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
    NGAP_MEMSET(
    p_local_pdu_session_res_setup_req,
    NGAP_ZERO,
    sizeof(ngap_pdu_session_resource_setup_request_t));
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
        */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of NG Setup Request Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_internal_decode_pdu_session_resource_setup_request(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.pDUSessionResourceSetup,
                p_local_pdu_session_res_setup_req);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}

ngap_map_updation_const_et  validate_and_fill_pdu_session_resource_release_command
(
    ngap_PDUSessionResourceToReleaseListRelCmd            *p_value,
    ngap_pdu_session_resource_to_release_list_rel_cmd_t   *p_local
)
{
    ngap_PDUSessionResourceToReleaseItemRelCmd
                *p_value_pdu_resource_release_command_item = NGAP_P_NULL;

    UInt16              count = NGAP_ZERO;
    OSRTDListNode      *pdu_session_resource_release_cmd_node = NGAP_P_NULL;
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_release_cmd_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of %d",
                NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE);

            result = INVALID_VALUE;

            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_release_cmd_node)
        {
            p_value_pdu_resource_release_command_item =
                (ngap_PDUSessionResourceToReleaseItemRelCmd *)
                pdu_session_resource_release_cmd_node->data;

            /*Decode PDU session ID  */
           p_local->pdu_session_res_to_rel_list_release_cmd_item[count].\
            pdu_session_id.pdu_session_id =
                p_value_pdu_resource_release_command_item->pDUSessionID;

            /*Decode PDU SESSION RESOURCE RELEASE COMMAND TRANSFER */
            result = ngap_decode_pdu_sr_release_cmd_transfer
                    (
                        &p_value_pdu_resource_release_command_item->\
                        pDUSessionResourceReleaseCommandTransfer,
                        &p_local->pdu_session_res_to_rel_list_release_cmd_item[count].\
                        pdu_session_res_to_rel_command_transfer
                    );

            pdu_session_resource_release_cmd_node =
                pdu_session_resource_release_cmd_node->next;

            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

ngap_map_updation_const_et  ngap_decode_pdu_sr_release_cmd_transfer
(
    OSDynOctStr                                             *p_value,
    ngap_pdu_session_resource_release_command_transfer_t    *p_local
)
{
    ngap_PDUSessionResourceReleaseCommandTransfer
            *p_session_resource_release_command_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        p_session_resource_release_command_transfer = rtxMemAllocTypeZ(&asn1_ctx1,
                    ngap_PDUSessionResourceReleaseCommandTransfer);

        if(NGAP_P_NULL == p_session_resource_release_command_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                "Failed pu_setBuffer for PDU session resource release command transfer");

            response = INVALID_VALUE;
            break;
        }

        if(NGAP_ASN_OK !=
             asn1PD_ngap_PDUSessionResourceReleaseCommandTransfer(
                 &asn1_ctx1,
                 p_session_resource_release_command_transfer))
        {

            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                "Decoding of PDU session resource setup res transfer");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceReleaseCommandTransfer(
                   &asn1_ctx1,"PDU_SESSION_RESOURCE_RELEASE_COMMAND_TRANSFER",
                    p_session_resource_release_command_transfer);
        }

        /*Decode choice cause group */

        response = ngap_decode_cause
                   (
                        &p_session_resource_release_command_transfer->cause,
                        &p_local->choice_cause_group
                   );


        if(INVALID_VALUE == response)
        {
           RRC_NGAP_TRACE(NGAP_ERROR, "Couldn't decode ngap_Cause");

            response = INVALID_VALUE;
            break;
        }

    }while(0);

    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et ngap_decode_pdu_sr_release_command
(
    UInt8                                       *p_asn_msg,/* Input - ASN Encoded Buffer */
    UInt16                                      asn_msg_len,/* Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_release_command_t *p_local_pdu_session_res_rel_cmd
)
{
    ngap_NGAP_PDU               ngap_pdu;
    OSCTXT                      asn1_ctx;
    ngap_return_et              response;

    NGAP_MEMSET
    (
        p_local_pdu_session_res_rel_cmd,
        NGAP_ZERO,
        sizeof(ngap_pdu_session_resource_release_command_t)
    );

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg,
                                        asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for PDU"\
                "SESSION RESOURE RELEASE COMMAND");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);

            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of PDU SESSION RESOURCE"\
                "RELEASE COMMAND Failed");

            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_internal_decode_pdu_session_resource_release_command(
                        &asn1_ctx,
                         ngap_pdu.u.initiatingMessage->value.u.\
                         pDUSessionResourceRelease,
                         p_local_pdu_session_res_rel_cmd
                    );

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et ngap_internal_decode_pdu_session_resource_release_command
(
   OSCTXT                                            *p_asn1_ctx,
   ngap_PDUSessionResourceReleaseCommand             *p_asn_pdu_session_res_rel_cmd,
   ngap_pdu_session_resource_release_command_t       *p_local_pdu_session_res_rel_cmd
)
{
    ngap_PDUSessionResourceReleaseCommand_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_pdu_session_res_rel_cmd);

    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));

    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =

    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                2,  ASN1V_ngap_id_RANPagingPriority, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_NAS_PDU, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4,ASN1V_ngap_id_PDUSessionResourceToReleaseListRelCmd,ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    /* Initialize pnode with first IE */

    p_node = p_asn_pdu_session_res_rel_cmd->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_pdu_session_res_rel_cmd->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem =
            (ngap_PDUSessionResourceReleaseCommand_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseCommandIEs_1,
                            (void *)&p_local_pdu_session_res_rel_cmd->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseCommandIEs_2,
                            (void *)&p_local_pdu_session_res_rel_cmd->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }

                break;
            }

            /*IE3 - RAN Paging Priority */
            case ASN1V_ngap_id_RANPagingPriority:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE3 - RAN Paging Priority");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseCommandIEs_3,
                           (void *)&p_local_pdu_session_res_rel_cmd->\
                            ran_paging_priority.ran_paging_priority))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE3 - RAN Paging Priority validation failed");
                }
                else
                {
                    p_local_pdu_session_res_rel_cmd->bitmask |=
                        PDU_SESSION_RELEASE_COMMAND_RAN_PAGING_PRIORITY;
                }

                break;
            }

            /*IE4 - NAS-PDU */
            case ASN1V_ngap_id_NAS_PDU:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE4 - NAS-PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseCommandIEs_4,
                            (void *)&p_local_pdu_session_res_rel_cmd->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE4 - NAS-PDU Validation Failed");
                }
                else
                {
                    p_local_pdu_session_res_rel_cmd->bitmask |=
                        PDU_SESSION_RELEASE_COMMAND_NAS_PDU;
                }

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceToReleaseListRelCmd:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE4 - PDU SESSION RESOURCE TO RELEASE COMMAND LIST");

                if(NGAP_FAILURE == validate_and_fill_ie_value(&message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseCommandIEs_5,
                            (void * )&p_local_pdu_session_res_rel_cmd->\
                            pdu_session_resource_to_release_list_rel_cmd))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE4 -PDU SESSION RESOURCE TO RELEASE COMMAND LIST Validation Failed");
                }

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Invalid id for the IE");

                ret_val = NGAP_FAILURE;
                break;
            }

        }//switch end
        p_node = p_node->next;
    }
    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_PDUSessionResourceRelease,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode PDU SESSION RESOURCE RELEASE COMMAND");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

ngap_return_et  ngap_decode_pdu_session_resource_release_response
(
    UInt8                                        *p_asn_msg,/*Input - ASN Encoded Buffer */
    UInt16                                       asn_msg_len,/*Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_release_response_t *p_local_pdu_session_res_rel_resp /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_return_et          response;


    NGAP_MEMSET(p_local_pdu_session_res_rel_resp,
                NGAP_ZERO,
                sizeof( ngap_pdu_session_resource_release_response_t));

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for ng setup resp");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU(&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Decoding of pdu session resource release respnse Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_internal_decode_pdu_session_resource_release_response(&asn1_ctx,
                        ngap_pdu.u.successfulOutcome->value.u.pDUSessionResourceRelease,
                        p_local_pdu_session_res_rel_resp);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}


ngap_return_et  ngap_internal_decode_pdu_session_resource_release_response
(
    OSCTXT                                           *p_asn1_ctx,
    ngap_PDUSessionResourceReleaseResponse           *p_asn_pdu_session_sr_resp,
    ngap_pdu_session_resource_release_response_t     *p_local_pdu_session_sr_resp
)
{
    OSRTDListNode                            *p_node             = NGAP_P_NULL;
    ngap_PDUSessionResourceReleaseResponse_protocolIEs_element   *p_protocolIE_elem = NGAP_P_NULL;
    UInt8                                    ie_index            = NGAP_ZERO;
    UInt16                                   ie_list_index       = NGAP_ZERO;
    ngap_return_et                           ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                    send_err_ind;
    ngap_criticality_diagnostics_ie_list_t   ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_pdu_session_sr_resp);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO,sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    ngap_message_data_t message_map =

    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2,ASN1V_ngap_id_PDUSessionResourceReleasedListRelRes,ngap_mandatory,
                ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3,ASN1V_ngap_id_UserLocationInformation,ngap_optional,ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4,ASN1V_ngap_id_CriticalityDiagnostics,ngap_optional,ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };
    /* Initialize pnode with first IE */

    p_node = p_asn_pdu_session_sr_resp->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_pdu_session_sr_resp->protocolIEs.count; ie_index++)
    {

        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem =
            (ngap_PDUSessionResourceReleaseResponse_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseResponseIEs_1,
                            (void *)&p_local_pdu_session_sr_resp->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseResponseIEs_2,
                            (void *)&p_local_pdu_session_sr_resp->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /*Encode IE PDU Session Resource Released List Rel Res */

            case ASN1V_ngap_id_PDUSessionResourceReleasedListRelRes:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE - ASN1V_ngap_id_PDUSessionResourceReleasedListRelRes");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseResponseIEs_3,
                            (void *)&p_local_pdu_session_sr_resp->pdu_session_resource_release_response))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "Failed To Decode IE- ASN1V_ngap_id_PDUSessionResourceReleasedListRelRes");
                }
                break;
            }

            /* Encode IE User Location Information */

            case ASN1V_ngap_id_UserLocationInformation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE - ASN1V_ngap_id_UserLocationInformation");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseResponseIEs_4,
                            (void *)&p_local_pdu_session_sr_resp->choice_user_location_information))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE4 - ASN1V_ngap_id_UserLocationInformation validation failed");
                }
                else
                {
                    p_local_pdu_session_sr_resp->bitmask =
                        NGAP_PDU_SR_RELEASE_RESPONSE_USER_LOCATION_INFO_PRESENT;
                }
                break;
            }

            /*Encode IE Criticality Diagnostics */

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_PDUSessionResourceReleaseResponseIEs_5,
                            (void *)&p_local_pdu_session_sr_resp->criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_CriticalityDiagnostics validation failed");
                }
                else
                {
                    p_local_pdu_session_sr_resp->bitmask =
                        NGAP_PDU_SR_RELEASE_RESPONSE_CRITICALITY_DIAGNOSTICS_PRESENT;
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch
        p_node = p_node->next;
    }//end for

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_PDUSessionResourceRelease,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode NG Reset Acknowledge");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


ngap_map_updation_const_et validate_and_fill_pdu_session_resource_release_response
(
    ngap_PDUSessionResourceReleasedListRelRes               *p_value,
    ngap_pdu_session_resource_release_response_list_t       *p_local
)
{
    ngap_PDUSessionResourceReleasedItemRelRes
                *p_value_pdu_resource_release_response_item = NGAP_P_NULL;

    UInt16              count = NGAP_ZERO;
    OSRTDListNode      *pdu_session_resource_release_resp_node = NGAP_P_NULL;
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_release_resp_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum  NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE");

            result = INVALID_VALUE;

            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_release_resp_node )
        {
            p_value_pdu_resource_release_response_item =
                (ngap_PDUSessionResourceReleasedItemRelRes *)
                pdu_session_resource_release_resp_node->data;

            /*Decode PDU session ID*/

            p_local->pdu_session_resource_released_response[count].\
            pdu_session_id.pdu_session_id =
            p_value_pdu_resource_release_response_item->pDUSessionID;

            /*Decode PDU SESSION RESOURCE RELEASED RESPONSE TRANSFER */
            result = ngap_decode_pdu_srr_response_transfer
                    (
                        &p_value_pdu_resource_release_response_item->\
                        pDUSessionResourceReleaseResponseTransfer,
                        &p_local->pdu_session_resource_released_response[count].\
                        pdu_session_resource_released_response_transfer
                    );
                    if(result == INVALID_VALUE)
                    {
                        RRC_NGAP_TRACE(NGAP_INFO, "Failed to decode pdu srr resp transfer");
                        result = INVALID_VALUE;
                        break;
                    }

            pdu_session_resource_release_resp_node=
                pdu_session_resource_release_resp_node->next;
                count++;
        }

    }while(0);
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

ngap_map_updation_const_et  ngap_decode_pdu_srr_response_transfer
(
    OSDynOctStr                                             *p_value,
    ngap_pdu_session_resource_released_response_transfer_t  *p_local
)
{
    ngap_PDUSessionResourceReleaseResponseTransfer
            *p_session_resource_release_response_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        p_session_resource_release_response_transfer = rtxMemAllocTypeZ(&asn1_ctx1, 
                ngap_PDUSessionResourceReleaseResponseTransfer);

        if(NGAP_P_NULL == p_session_resource_release_response_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                "Failed pu_setBuffer for PDU session resource release response transfer");

            response = INVALID_VALUE;
            break;
        }

        if(NGAP_ASN_OK !=
             asn1PD_ngap_PDUSessionResourceReleaseResponseTransfer(
                 &asn1_ctx1,
                 p_session_resource_release_response_transfer))
        {

            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                "Decoding of PDU session resource release response transfer");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceReleaseResponseTransfer(
                   &asn1_ctx1,"PDU_SESSION_RESOURCE_RELEASE_RESPONSE_TRANSFER",
                    p_session_resource_release_response_transfer);
        }


        /*Decode Secondary rat usage information */

        response  = ngap_decode_secondary_rat_information
        (
            &p_session_resource_release_response_transfer->iE_Extensions,
            &p_local->secondary_rat_usage_information
        );

        if(INVALID_VALUE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Couldn't decode secondary rat information");

            response = INVALID_VALUE;
            break;
        }

    }while(0);
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

ngap_map_updation_const_et  ngap_decode_secondary_rat_information
(
   ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions    *p_value,
   ngap_secondary_rat_usage_information_t                          *p_local
)
{
    ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions_element
            *p_value_asn_secondary_rat_item = NGAP_P_NULL;
    UInt16                       count                            = NGAP_ZERO;
    OSRTDListNode               *pdu_session_secondary_rat_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  response                           = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_secondary_rat_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
             response = INVALID_VALUE;
            break;
        }
      /*local side there is no structure corresponding to list so no max count check for list */
        //p_local = p_value->count;

        while(NGAP_P_NULL != pdu_session_secondary_rat_node)
        {
            p_value_asn_secondary_rat_item =
                (ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions_element * )
                pdu_session_secondary_rat_node->data;

            /*Decode PDU SESSION USAGE REPORT */

            /*Decode RAT TYPE */
            p_local->pdu_session_usage_report.rat_type =
                (ngap_rat_type_et)p_value_asn_secondary_rat_item->extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                    pDUSessionUsageReport.rATType;

            /*Decode Timed Report */
            response = decode_ie_timed_report_list
                        (
                            &p_value_asn_secondary_rat_item->extensionValue.u.\
                            _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                            pDUSessionUsageReport.pDUSessionTimedReportList,
                            &p_local->pdu_session_usage_report.timed_report
                        );

            if (INVALID_VALUE == response )
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Couldn't decode pdu session timed report list");
                response = INVALID_VALUE;
                break;
            }
            /*Decode QOS FLOW USAGE REPORT */

            response = decdode_ie_qos_flow_usage_report
                (
                    &p_value_asn_secondary_rat_item->extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                    qosFlowsUsageReportList,
                    &p_local->qos_flows_usage_report
                );

            if (INVALID_VALUE == response )
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Couldn't decode secondary rat information");
                response = INVALID_VALUE;
                break;
            }

        pdu_session_secondary_rat_node = pdu_session_secondary_rat_node->next;
        count++;
        }
    }while(0);

    /* Free ASN1 context */
    //rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_map_updation_const_et  decdode_ie_qos_flow_usage_report
(
    ngap_QoSFlowsUsageReportList        *p_value,
    ngap_qos_flows_usage_report_list    *p_local
)
{
    ngap_QoSFlowsUsageReport_Item       *p_value_qos_flow_report_item = NGAP_P_NULL;

    UInt16                       count                            = NGAP_ZERO;
    OSRTDListNode                *pdu_qos_flow_report_node         = NGAP_P_NULL;
    ngap_map_updation_const_et   response                            = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_qos_flow_report_node = p_value->head;
    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            response = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_QOS_FLOWS < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 64");
            response = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_qos_flow_report_node)
        {
            p_value_qos_flow_report_item =
                (ngap_QoSFlowsUsageReport_Item *)
                pdu_qos_flow_report_node->data;

            /*Decode QOS FLOW IDENTIFIER */
            p_local->qos_flow_usage_report_item[count].\
                qos_flow_identifier.qos_flow_identifier =
                p_value_qos_flow_report_item->qosFlowIdentifier;

            /*Decode Rat Tpye*/

            p_local->qos_flow_usage_report_item[count].rat_type=
                (ngap_rat_type_et)p_value_qos_flow_report_item->rATType;

            /*Decode Timed Report List */
            response = decode_ie_timed_report_list

                (
                 &p_value_qos_flow_report_item->qoSFlowsTimedReportList,
                 &p_local->qos_flow_usage_report_item[count].timed_report
                );
            if(INVALID_VALUE == response)
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Failed to decode timed report list");
                response = INVALID_VALUE;
                break;
            }
            pdu_qos_flow_report_node = pdu_qos_flow_report_node->next;
        }

    }while(0);
    /* Free ASN1 context */
//    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_map_updation_const_et  decode_ie_timed_report_list
(
    ngap_VolumeTimedReportList      *p_value,
    ngap_timed_report_list          *p_local
)
{
    ngap_VolumeTimedReport_Item     *p_value_time_report_list_item = NGAP_P_NULL;
    UInt16                       count                            = NGAP_ZERO;
    OSRTDListNode               *pdu_time_report_list_node        = NGAP_P_NULL;
    ngap_map_updation_const_et  result                            = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_time_report_list_node    = p_value->head;
    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_TIME_REPORTING_PERIOD < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO,
            "Count exceeds maximum of NGAP_MAX_NO_OF_TIME_REPORTING_PERIOD");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_time_report_list_node)
        {
            p_value_time_report_list_item =
            (ngap_VolumeTimedReport_Item *)pdu_time_report_list_node->data;

            /*Decode Start Time Stamp */
            NGAP_MEMCPY(p_local->timed_report_list_item[count].start_time_stamp,
            p_value_time_report_list_item->startTimeStamp.data,
            p_value_time_report_list_item->startTimeStamp.numocts);

            /*Decode End Time Stamp */

            NGAP_MEMCPY(p_local->timed_report_list_item[count].end_time_stamp,
            p_value_time_report_list_item->endTimeStamp.data,
            p_value_time_report_list_item->endTimeStamp.numocts);

            /*Decode Usage Count Uplink */

            p_local->timed_report_list_item[count].usage_count_uplink =
                p_value_time_report_list_item->usageCountUL;

            /*Decode Usage Count Downlink */

            p_local->timed_report_list_item[count].usage_count_downlink =
                p_value_time_report_list_item->usageCountDL;


                pdu_time_report_list_node = pdu_time_report_list_node->next;
          }

     }while(0);
    /* Free ASN1 context */
//    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

/******************************************************************************
 * Function Name    : ngap_decode_ran_config_update
 * Input            : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Output           : p_ran_config_update - Information from which local buffer will be filled
 * Returns          : NGAP_SUCCESS - ASN decoding was successful
 *                      NGAP_FAILURE - ASN decoding was not successful
 * DESCRIPTION	    : This function decodes RAN CONFIG UPDATE ASN message.
 *****************************************************************************/
ngap_return_et ngap_decode_ran_config_update
(
    UInt8			       *p_asn_msg,	        /* Input - ASN Encoded Buffer */
    UInt16                 asn_msg_len,	        /* Input - ASN Encoded Buffer Length */
    ran_config_update_t    *p_ran_config_update	/* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
    NGAP_MEMSET(p_ran_config_update, NGAP_ZERO, sizeof(ran_config_update_t));

    
    RRC_NGAP_UT_TRACE_ENTER();
    
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for RAN CONFIG UPDATE");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of RAN CONFIG UPDATE Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ran_config_update_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.rANConfigurationUpdate,
                p_ran_config_update);

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

ngap_return_et ran_config_update_internal_dec
(
    OSCTXT			                 *p_asn1_ctx,                 /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdate      *p_asn_ran_config_update,    /* Input: Received ASN Buffer */
    ran_config_update_t              *p_local_ran_config_update   /* Output: Local Message Structure */
)
{
    OSRTDListNode                                       *p_node             = NGAP_P_NULL;
    ngap_RANConfigurationUpdate_protocolIEs_element     *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                               ie_index            = NGAP_ZERO;
    UInt16                                              ie_list_index       = NGAP_ZERO;
    ngap_return_et                                      ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                               send_err_ind;
    ngap_criticality_diagnostics_ie_list_t              ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ran_config_update);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t message_map = 
    {5, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_RANNodeName, ngap_optional, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_SupportedTAList, ngap_optional, ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_DefaultPagingDRX, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {3, ASN1V_ngap_id_GlobalRANNodeID, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {4, ASN1V_ngap_id_NGRAN_TNLAssociationToRemoveList,ngap_optional,ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_ran_config_update->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ran_config_update->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ran_config_update->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_RANConfigurationUpdate_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_RANNodeName:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RANNodeName");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateIEs_1,
                            (void *)p_local_ran_config_update->ran_node_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_RANNodeName Validation failed");
                }
                else
                {
                    p_local_ran_config_update->bitmask |= 
                        RAN_CONFIG_UPDATE_RAN_NODE_NAME_PRESENT;
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_SupportedTAList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_SupportedTAList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateIEs_2,
                            (void *)&p_local_ran_config_update->supported_ta_list))


                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_SupportedTAList Validation failed");
                }
                else
                {
                    p_local_ran_config_update->bitmask |= 
                        RAN_CONFIG_UPDATE_SUPPORTED_TA_LIST_PRESENT;
                }
                break;
            }

            /* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_DefaultPagingDRX:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_DefaultPagingDRX");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateIEs_3,
                            (void *)&p_local_ran_config_update->default_paging_drx))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE3- ASN1V_ngap_id_DefaultPagingDRX Validation failed");
                }

                else
                {
                    p_local_ran_config_update->bitmask |=
                        RAN_CONFIG_UPDATE_DEFAULT_PAGING_DRX_PRESENT;
                }
                break;

            }/* End of IE3 */

            /* IE4*/
            case ASN1V_ngap_id_GlobalRANNodeID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_GlobalRANNodeID");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateIEs_4,
                            (void *)&p_local_ran_config_update->global_ran_node_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE4 - ASN1V_ngap_id_GlobalRANNodeID Validation failed");
                }
                else
                {
                    p_local_ran_config_update->bitmask |=
                        RAN_CONFIG_UPDATE_GLOBAL_RAN_NODE_ID_PRESENT;
                }

                break;
            } /* End of IE4 */

            /* IE5 */
            case ASN1V_ngap_id_NGRAN_TNLAssociationToRemoveList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_NGRAN_TNLAssociationToRemoveList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateIEs_5,
                            (void *)&p_local_ran_config_update->tnl_asso_remove_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE5 - ASN1V_ngap_id_NGRAN_TNLAssociationToRemoveList failed");
                }
                else
                {
                    p_local_ran_config_update->bitmask |=
                        RAN_CONFIG_UPDATE_TNL_ASSOCIATION_LIST_PRESENT;
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }


        }/* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_RANConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode RAN CONFIG UPDATE");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;

}
/***********************************************************************************************************
 * Function Name	: ngap_decode_ran_config_update_ack
 * Inputs         	: p_ng_ran_config_update_ack - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function decodes RAN CONFIG UPDATE ACKNOWLEDGE  ASN message from the information 
 *				      provided in p_ng_ran_config_update_ack
 ***********************************************************************************************************/
ngap_return_et ngap_decode_ran_config_update_ack
(
    UInt8			            *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    ran_config_update_ack_t 	*p_ran_config_update_ack    /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for RAN CONFIG UPDATE ACK");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of RAN CONFIG UPDATE ACK");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ran_config_update_ack_internal_dec(&asn1_ctx,
                ngap_pdu.u.successfulOutcome->value.u.\
                rANConfigurationUpdate,
                p_ran_config_update_ack);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

ngap_return_et ran_config_update_ack_internal_dec
(
    OSCTXT			                       *p_asn1_ctx,                    /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdateAcknowledge *p_asn_ran_config_update_ack,   /* Input: Received ASN Buffer */
    ran_config_update_ack_t                *p_local_ran_config_update_ack  /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_RANConfigurationUpdateAcknowledge_protocolIEs_element
        *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ran_config_update_ack);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {1, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_ran_config_update_ack->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ran_config_update_ack->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ran_config_update_ack->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_RANConfigurationUpdateAcknowledge_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                                u._ngap_RANConfigurationUpdateAcknowledgeIEs_1,
                            (void *)&p_local_ran_config_update_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_ran_config_update_ack->bitmask |= 
                        RAN_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT;
                }
                break;
            } /* End of IE */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_RANConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode RAN CONFIG UPDATE ACK");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/*******************************************************************************************************
 * Function Name	: ngap_decode_ran_config_update_failure
 * Inputs         	: p_ng_ran_config_update_fail - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function decodes RAN CONFIG UPDATE FAILURE  ASN message from the information 
 *				      provided in p_ng_ran_config_update_fail
 *******************************************************************************************************/
ngap_return_et ngap_decode_ran_config_update_failure
(
    UInt8			            *p_asn_msg,	                   /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	               /* Input - ASN Encoded Buffer Length */
    ran_config_update_failure_t	*p_ran_config_update_failure   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for RAN CONFIG UPDATE FAILURE");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of RAN CONFIG UPDATE FAILURE");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ran_config_update_failure_internal_dec(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome->value.u.\
                rANConfigurationUpdate,
                p_ran_config_update_failure);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

ngap_return_et ran_config_update_failure_internal_dec
(
    OSCTXT			                   *p_asn1_ctx,                        /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdateFailure *p_asn_ran_config_update_failure,   /* Input: Received ASN Buffer */
    ran_config_update_failure_t        *p_local_ran_config_update_failure  /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_RANConfigurationUpdateFailure_protocolIEs_element
        *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_ran_config_update_failure);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_TimeToWait, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_ran_config_update_failure->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_ran_config_update_failure->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_ran_config_update_failure->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_RANConfigurationUpdateFailure_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateFailureIEs_1,
                            (void *)&p_local_ran_config_update_failure->\
                            choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_TimeToWait:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_TimeToWait");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateFailureIEs_2,
                            (void *)&p_local_ran_config_update_failure->\
                            time_to_wait_event_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_TimeToWait Validation failed");
                }
                else
                {
                    p_local_ran_config_update_failure->bitmask |= 
                        RAN_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_RANConfigurationUpdateFailureIEs_3,
                            (void *)&p_local_ran_config_update_failure->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE3 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_ran_config_update_failure->bitmask |= 
                        RAN_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT;
                }
                break;
            } /* End of IE3 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_RANConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode RAN CONFIG UPDATE FAILURE");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/*HandOver_code_changes_start*/

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_HO_required_list
(
       ngap_PDUSessionResourceListHORqd      *p_value,
       ngap_pdu_session_res_list_HO_rqd_t    *p_local
)
{

    ngap_PDUSessionResourceItemHORqd  *p_value_pdu_session_resource_HO_req_item;
    UInt16                      count                               = NGAP_ZERO;
    OSRTDListNode               *pdu_session_resource_HO_req_node   = NGAP_P_NULL; 
    ngap_map_updation_const_et  result                              = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_HO_req_node  = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while (NGAP_P_NULL != pdu_session_resource_HO_req_node )
        {
           p_value_pdu_session_resource_HO_req_item =
           (ngap_PDUSessionResourceItemHORqd *)pdu_session_resource_HO_req_node->data;

           /*decode pdu session id*/
           p_local->pdu_session_res_list_HO_rqd_item[count].pdu_session_id.\
               pdu_session_id =
               p_value_pdu_session_resource_HO_req_item->pDUSessionID;

           /* Decode PDU Session Handover required transfer */

            result =  ngap_decode_handover_required_transfer(
               &p_value_pdu_session_resource_HO_req_item->handoverRequiredTransfer,
               &p_local->pdu_session_res_list_HO_rqd_item[count].\
                    handover_rqd_transfer);

           pdu_session_resource_HO_req_node = 
                        pdu_session_resource_HO_req_node->next;
           count++;
        }

    }while(0);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/****************************************************************************************
 *                      NGAP DECODE HANDOVER REQUIRED TRANSFER
 * *************************************************************************************/
ngap_map_updation_const_et ngap_decode_handover_required_transfer
(
    OSDynOctStr                 *p_value,
    ho_required_transfer_t      *p_local
)
{
    ngap_HandoverRequiredTransfer   *p_handover_required_transfer = NGAP_P_NULL;
    OSCTXT                          asn1_ctx1;
    ngap_map_updation_const_et      response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax 
         * Error because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
       p_handover_required_transfer = (ngap_HandoverRequiredTransfer *)
       rtxMemAllocTypeZ(&asn1_ctx1 , ngap_HandoverRequiredTransfer);

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Handover Required transfer");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PD_ngap_HandoverRequiredTransfer
                (&asn1_ctx1, p_handover_required_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);

            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of handover Required transfer");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverRequiredTransfer(
                    &asn1_ctx1,
                    "HANDOVER REQUIRED TRANSFER", 
                    p_handover_required_transfer);
        }
            /*Decode Message direct_fwding_path_avail */
        if ( NGAP_TRUE ==
                p_handover_required_transfer->m.directForwardingPathAvailabilityPresent 
           )
        {
             p_local->bitmask |= HO_RQD_TRANSFER_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT;
       
             /*COVERITY FIX*/
             p_local->direct_fwding_path_avail =
                (ngap_DirectForwardingPathAvailability_et)p_handover_required_transfer->directForwardingPathAvailability;
             /*COVERITY FIX*/
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}




/*****************************************************************************
 *          validate and fill pdu session resource setup list handover request
 *                
 * ****************************************************************************/

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_setup_ho_request_list
(
       ngap_PDUSessionResourceSetupListHOReq      *p_value,
       ngap_pdu_session_res_setup_list_HO_req_t    *p_local
)
{

    ngap_PDUSessionResourceSetupItemHOReq  *p_value_pdu_session_resource_HO_req_item;
    UInt16                      count                               = NGAP_ZERO;
    OSRTDListNode               *pdu_session_resource_HO_req_node   = NGAP_P_NULL; 
    ngap_map_updation_const_et  result                              = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_HO_req_node  = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while (NGAP_P_NULL != pdu_session_resource_HO_req_node )
        {
            p_value_pdu_session_resource_HO_req_item =
                (ngap_PDUSessionResourceSetupItemHOReq *)pdu_session_resource_HO_req_node->data;

            /*decode pdu session id*/
            p_local->pdu_session_res_setup_list_HO_req_item[count].pdu_session_id =
                p_value_pdu_session_resource_HO_req_item->pDUSessionID;

            /*Decode s_NSSAI */

            NGAP_MEMCPY(p_local->pdu_session_res_setup_list_HO_req_item[count].s_nssai.sst,
                    p_value_pdu_session_resource_HO_req_item->s_NSSAI.sST.data,
                    p_value_pdu_session_resource_HO_req_item->s_NSSAI.sST.numocts);

            if(NGAP_TRUE == 
                p_value_pdu_session_resource_HO_req_item->s_NSSAI.m.sDPresent)
            {
                p_local->pdu_session_res_setup_list_HO_req_item[count].s_nssai.\
                    bitmask |=
                    NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT;

                NGAP_MEMCPY
                (
                    p_local->pdu_session_res_setup_list_HO_req_item[count].\
                        s_nssai.sd,
                    p_value_pdu_session_resource_HO_req_item->s_NSSAI.sD.data,
                    p_value_pdu_session_resource_HO_req_item->s_NSSAI.sD.numocts
                );
            }
            /* Decode PDU Session Handover request  transfer */


            result = ngap_decode_pdu_session_resource_setup_req_transfer(
                     &p_value_pdu_session_resource_HO_req_item->\
                     handoverRequestTransfer,
                     &p_local->pdu_session_res_setup_list_HO_req_item[count].\
                     handover_req_transfer);

            pdu_session_resource_HO_req_node = 
                pdu_session_resource_HO_req_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/*Handover_changes_start */
ngap_map_updation_const_et validate_and_fill_src_to_target_transparent_container 
(
     ngap_SourceToTarget_TransparentContainer *p_value,
     ngap_src_to_target_transparent_container_t   *p_local
 )
{
    ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
        *p_src_to_trg_ngran_container = NGAP_P_NULL;
    OSCTXT                          asn1_ctx1;
    ngap_map_updation_const_et      response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }
    do
    {
        p_src_to_trg_ngran_container = rtxMemAllocTypeZ(&asn1_ctx1,
                ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer);
        if (NGAP_P_NULL == p_src_to_trg_ngran_container )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for Source To Target NGRAN Container");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PD_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer(&asn1_ctx1, 
                    p_src_to_trg_ngran_container))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Decoding of Source To Target NGRAN Container");
            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer(NGAP_ASN,
                 (SInt8 *)"Source To Target NGRAN Container",
                 p_src_to_trg_ngran_container);
        }

        /* Decode message */

        /*Decode Rrc_container */
        p_local->src_to_trg_ngran_container.rrc_container.num_string_len =
            p_src_to_trg_ngran_container->rRCContainer.numocts;

        p_local->src_to_trg_ngran_container.rrc_container.string_data =
                    (UInt8 *)rrc_mem_get(sizeof(UInt8));

        if (NGAP_P_NULL ==
            p_local->src_to_trg_ngran_container.rrc_container.string_data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }
        NGAP_MEMCPY
        (p_local->src_to_trg_ngran_container.rrc_container.string_data,
         p_src_to_trg_ngran_container->rRCContainer.data,
         p_src_to_trg_ngran_container->rRCContainer.numocts
        );

        /*Decode pDUSessionResourceInformationList */
    
        if ( NGAP_TRUE ==
            p_src_to_trg_ngran_container->m.pDUSessionResourceInformationListPresent )
        {
            p_local->src_to_trg_ngran_container.bitmask |=
                NGAP_PDU_SESSION_RESOURCE_INFORAMTION_LIST;
            response = 
                    ngap_decode_pdu_session_resource_info_list
                    (&p_src_to_trg_ngran_container->pDUSessionResourceInformationList,
                     &p_local->src_to_trg_ngran_container.pdu_session_resource_info_list);
        }

        /*Decode e_RABInformationList */
        /*NOT needed in 5g to 5g handover */

        /*Decode targetCell_ID */
         response = 
                    ngap_decode_ng_ran_cgi(&p_src_to_trg_ngran_container->targetCell_ID,
                        &p_local->src_to_trg_ngran_container.target_cell_id);
        /*Decode indexToRFSP */

        if (NGAP_TRUE == p_src_to_trg_ngran_container->m.indexToRFSPPresent )
        {
            p_local->src_to_trg_ngran_container.bitmask |=
                        NGAP_INDEX_TO_RFSP;

            p_local->src_to_trg_ngran_container.index_to_rfsp =
                p_src_to_trg_ngran_container->indexToRFSP;
        }


        /*Decode uEHistoryInformation */
         response =
                    ngap_decode_ue_history_information
                    (&p_src_to_trg_ngran_container->uEHistoryInformation,
                     &p_local->src_to_trg_ngran_container.ue_history_information);

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
ngap_map_updation_const_et ngap_decode_ue_history_information
(
    ngap_UEHistoryInformation               *p_value,
    ngap_ue_history_information_list_t      *p_local
)
{
    ngap_LastVisitedCellItem    *p_last_visited_cell_item = NGAP_P_NULL;
    OSRTDListNode               *p_node                   = NGAP_P_NULL;
    ngap_map_updation_const_et result = OCCURANCE;
    UInt16                      count      = NGAP_ZERO;

 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List contains no elements");
        result = INVALID_VALUE;
            break;
        }
        else if(MAXIMUM_CELL_IN_UE_HISTORY_INFORMATION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != p_node)
            {
                p_last_visited_cell_item = 
                    (ngap_LastVisitedCellItem *)p_node->data;
                switch (p_last_visited_cell_item->lastVisitedCellInformation.t)
                {
                    case T_ngap_LastVisitedCellInformation_nGRANCell:
                    {
                        p_local->ue_history_information_item[count].\
                            last_visited_cell_information.choice_type =
                            ngap_LastVisitedCellInformation_nGRANCell;

                        /*Decode ngap_ng_ran_cgi_t */
                        result =    ngap_decode_ng_ran_cgi(
                                    &p_last_visited_cell_item->lastVisitedCellInformation.u.\
                                    nGRANCell->globalCellID,
                                    &p_local->ue_history_information_item[count].\
                                    last_visited_cell_information.ng_ran_cell.global_cell_id
                                    );

                        /*Decode cell_type */

                        p_local->ue_history_information_item[count].\
                        last_visited_cell_information.\
                        ng_ran_cell.cell_type =
                        p_last_visited_cell_item->lastVisitedCellInformation.u.\
                        nGRANCell->cellType.cellSize;

                        /*Decode time_ue_stayed_in_cell */
                        p_local->ue_history_information_item[count].\
                        last_visited_cell_information.\
                        ng_ran_cell.time_ue_stayed_in_cell =
                        p_last_visited_cell_item->lastVisitedCellInformation.u.\
                        nGRANCell->timeUEStayedInCell;
                        
                        /*Decode time_ue_stayed_in_cell_enchanced_granularity */

                        if (p_last_visited_cell_item->lastVisitedCellInformation.u.\
                            nGRANCell->m.timeUEStayedInCellEnhancedGranularityPresent)
                        {
                            p_local->ue_history_information_item[count].\
                            last_visited_cell_information.\
                            ng_ran_cell.bitmask |=
                            TIME_UE_STAYED_IN_CELL_ENCHANCED_GRANULARITY;
                            
                            p_local->ue_history_information_item[count].\
                            last_visited_cell_information.\
                            ng_ran_cell.time_ue_stayed_in_cell_enchanced_granularity =
                            p_last_visited_cell_item->lastVisitedCellInformation.u.\
                            nGRANCell->timeUEStayedInCellEnhancedGranularity;

                        }

                        /*Decode handover_cause_value */
                        if (p_last_visited_cell_item->lastVisitedCellInformation.u.\
                            nGRANCell->m.hOCauseValuePresent)
                        {
                            p_local->ue_history_information_item[count].\
                            last_visited_cell_information.\
                            ng_ran_cell.bitmask |=  HO_CAUSE_VALUE;

                            result = validate_and_fill_choice_cause_group(
                                    &p_last_visited_cell_item->lastVisitedCellInformation.u.\
                                    nGRANCell->hOCauseValue,
                                    &p_local->ue_history_information_item[count].\
                                    last_visited_cell_information.\
                                    ng_ran_cell.handover_cause_value);

                            if(INVALID_VALUE == result)
                            {
                                RRC_NGAP_TRACE(NGAP_ERROR,
                                        "Failled to Decode Choice Cause Group");
                                break;
                            }
                        }

                        break;
                    }
                }//end switch
                p_node = p_node->next;
                count++;
            }
        }
    } while(0);
    RRC_NGAP_UT_TRACE_EXIT();
        return result;
    }
/***************************************************************************
 * Function Name : ngap_decode_pdu_session_resource_info_list
 *
 * Input:         p_value - pointer of asn structure
 *
 * Inputs : 
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_pdu_session_resource_info_list
(
   ngap_PDUSessionResourceInformationList    *p_value,
   ngap_pdu_session_resource_info_list_t     *p_local
)
{
    ngap_PDUSessionResourceInformationItem   *p_ngap_pdu_sr_info_item = NGAP_P_NULL;
    OSRTDListNode               *p_node              = NGAP_P_NULL;
    ngap_map_updation_const_et  result               = OCCURANCE;
    UInt16                      count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_node = p_value->head;
    do
    {
        if (NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List has no elements");
            result = INVALID_VALUE;
            break;
        }
        else if (NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count ;
            while(NGAP_P_NULL != p_node )
            {   
                p_ngap_pdu_sr_info_item =  
                    (ngap_PDUSessionResourceInformationItem *)p_node->data;
                /*Decode pdu_session_id */
                p_local->pdu_session_resource_info_item[count].pdu_session_id.pdu_session_id =
                    p_ngap_pdu_sr_info_item->pDUSessionID;

                /*Decode qos_flow_info_list */

                result = ngap_decode_qos_flow_info_list
                    (&p_ngap_pdu_sr_info_item->qosFlowInformationList,
                     &p_local->pdu_session_resource_info_item[count].\
                     qos_flow_info_list);

                /*Decode drb_to_qos_flow_mapping_list */

                result = ngap_decode_drb_to_qos_flow_mapping_list
                    (&p_ngap_pdu_sr_info_item->dRBsToQosFlowsMappingList,
                     &p_local->pdu_session_resource_info_item[count].\
                     drb_to_qos_flow_mapping_list);

                p_node = p_node->next;
                count++;
            }//end while
        }//end else

    }while(0);//end do_while

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/***************************************************************************
 * Function Name : ngap_decode_drb_to_qos_flow_mapping_list
 *
 * Input:         p_value - pointer of asn structure
 *
 * Inputs : 
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_drb_to_qos_flow_mapping_list
(
   ngap_DRBsToQosFlowsMappingList           *p_value,
   ngap_drb_to_qos_flow_mapping_list_t      *p_local
)
{
    ngap_DRBsToQosFlowsMappingItem   *p_drb_to_qos_flow_info_item = NGAP_P_NULL;
    OSRTDListNode                    *p_node               = NGAP_P_NULL;
    ngap_map_updation_const_et       result                = OCCURANCE;
    UInt16                           count                 = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);
    p_node = p_value->head;

    do
    {
        if (NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is null");
            result = INVALID_VALUE;
            break;
}
        else if(MAX_DRB < p_value->count )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != p_node)
            {
                p_drb_to_qos_flow_info_item =
                        (ngap_DRBsToQosFlowsMappingItem *)p_node->data;

                /*Decode dRB_ID */
                p_local->drb_to_qos_flow_mapping_item[count].drb_id =
                    p_drb_to_qos_flow_info_item->dRB_ID;

                /*Decode associatedQosFlowList */
                result = ngap_decode_associated_flow_list(
                            &p_drb_to_qos_flow_info_item->associatedQosFlowList,
                            &p_local->drb_to_qos_flow_mapping_item[count].\
                            associated_qos_flow_list);

                p_node = p_node->next;
                count++;
            }//end while
        }//end else

    }while(0);//end do_while

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/***************************************************************************
 * Function Name : ngap_decode_qos_flow_info_list
 *
 * Input:         p_value - pointer of asn structure
 *
 * Inputs : 
 *
 * Description:  This function takes input from ASN Structure and
 *               fill the local structure.
 **************************************************************************/
ngap_map_updation_const_et ngap_decode_qos_flow_info_list
(
   ngap_QosFlowInformationList            *p_value,
   ngap_qos_flow_information_list_t       *p_local
)
{
    ngap_QosFlowInformationItem *p_qos_flow_info_item = NGAP_P_NULL;
    OSRTDListNode               *p_node               = NGAP_P_NULL;
    ngap_map_updation_const_et  result                = OCCURANCE;
    UInt16                      count                 = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);
    p_node = p_value->head;

    do
    {
        if (NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Allowed Nssai List contains no elements");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_QOS_FLOWS < p_value->count )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max Value");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != p_node)
            {
                p_qos_flow_info_item =
                        (ngap_QosFlowInformationItem *)p_node->data;

                /*Decode Qos_folw_identifier */
                p_local->qos_flow_information_item[count].qos_flow_identifier =
                    p_qos_flow_info_item->qosFlowIdentifier;

                /*Decode dl_forwarding*/
                if (p_qos_flow_info_item->m.dLForwardingPresent )
                {
                    p_local->qos_flow_information_item[count].bitmask |=
                                        NGAP_DL_FORWARDING;
                    p_local->qos_flow_information_item[count].dl_forwarding =
                        p_qos_flow_info_item->dLForwarding;
                }
                /*Decode ul_forwarding*/
                //TBD
                p_node = p_node->next;
                count++;
            }//end while
        }//end else

    }while(0);//end do_while

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}
/*Handover_changes_end */
#if 1
ngap_map_updation_const_et validate_and_fill_SelectedTai
(
     ngap_TAI            *p_value,
     ngap_tai_t          *p_local

)
{
    ngap_map_updation_const_et result = OCCURANCE;
    /* Decode tAI */

    if(NGAP_PLMN_IDENTITY_MAX_BYTES < 
            p_value->pLMNIdentity.numocts)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
                "PLMN bytes have larger value than the max value");
        result = INVALID_VALUE;
        return result;        
    }

    NGAP_MEMCPY
        (
         p_local->plmn_identity.plmn_id_bytes,
         p_value->pLMNIdentity.data,
         p_value->pLMNIdentity.numocts
        );

    if(NGAP_TAC_OCTET_SIZE < 
            p_value->tAC.numocts)
    {

        RRC_NGAP_TRACE(NGAP_ERROR, 
                "tAC has larger value than the max value");
        result = INVALID_VALUE;
        return result;
    }

    NGAP_MEMCPY
        (
         p_local->tac.tac,
         p_value->tAC.data,
         p_value->tAC.numocts
        );

    return result;
}
#endif

ngap_map_updation_const_et  validate_and_fill_TargetID
(
     ngap_TargetID           *p_value,
     ngap_target_id_t        *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    switch (p_value->t)
    {
        case T_ngap_TargetID_targetRANNodeID:
        {
            /*Decode Target Ran Node ID */
            p_local->choice_type = T_ngap_TargetID_targetRANNodeID;

            if ( OCCURANCE != validate_and_fill_global_ran_node_id(
                        &p_value->u.targetRANNodeID->globalRANNodeID,//need to allocate memory to target_ran_node_id or not
                        &p_local->target_ran_node_id.global_ran_node_id))/*Handover bug fixes*/
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode Global Ran node id");
                result = INVALID_VALUE;
                break;
            }

            /* Decode selectedTAI */

            if ( OCCURANCE != validate_and_fill_SelectedTai(
                        &p_value->u.targetRANNodeID->selectedTAI,
                        &p_local->target_ran_node_id.selected_tai) )/*Handover bug fixes*/
            {

                RRC_NGAP_TRACE(NGAP_ERROR, "Could not decode selected TAI ");
                result = INVALID_VALUE;
                break;
            }

            break;
        }//doubt HandOver
        case T_ngap_TargetID_targeteNB_ID:
        {
            break;
        }
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}




ngap_return_et ngap_decode_handover_required
(
UInt8                                  *p_asn_msg,     /* Input - ASN Encoded Buffer */
UInt16                                 asn_msg_len,    /* Input - ASN Encoded Buffer Length */
ngap_handover_required_t               *p_handover_required,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/

    RRC_NGAP_UT_TRACE_ENTER();

    /*Init ASN.1 context */

    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
           Not Sending Error Indication with Transfer Syntax Error 
           because ASN Init failure doesn't match the same.
           */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {

        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for Handover Required \n ");

            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of Handover required failed\n");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                    (
                     p_amf_context,
                     NGAP_FALSE,
                     INVALID_VAL_TWO_BYTE,
                     NGAP_FALSE,
                     INVALID_VAL_FOUR_BYTE,
                     NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                     TRANSFER_SYNTAX_ERROR,
                     NGAP_FALSE,
                     ngap_id_InvalidProcedureCode,
                     NGAP_TRIG_INVALID_TRIGGERING_MSG,
                     NGAP_PROC_CRITICALITY_REJECT,
                     NGAP_P_NULL
                    );
            }

#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        response = ngap_handover_required_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.handoverPreparation,
                p_handover_required );

    }while(0);

    /* Free ASN1 context */

    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}



/******************************************************************************
 *  Function Name: ngap_handover_required_internal_dec
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/

ngap_return_et ngap_handover_required_internal_dec
(
 OSCTXT                         *p_asn1_ctx,
 ngap_HandoverRequired          *p_asn_handover_required,
 ngap_handover_required_t       *p_local_handover_required
 )
{
    ngap_HandoverRequired_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL; 
    OSRTDListNode *p_node                                        = NGAP_P_NULL;
    UInt8 ie_index                                               = NGAP_ZERO;
    UInt16 ie_list_index                                         = NGAP_ZERO;
    ngap_return_et ret_val                                       = NGAP_SUCCESS;
    ngap_error_ind_bool_t send_err_ind;
    ngap_criticality_diagnostics_ie_list_t ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_handover_required);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {
        8,NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_HandoverType,ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4, ASN1V_ngap_id_TargetID,ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_DirectForwardingPathAvailability, ngap_optional,
                ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                6, ASN1V_ngap_id_PDUSessionResourceListHORqd, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                7, ASN1V_ngap_id_SourceToTarget_TransparentContainer,ngap_mandatory,
                ngap_reject,  NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };

    /* Initialize pnode with first IE */

    p_node = p_asn_handover_required->protocolIEs.head;


    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_handover_required->protocolIEs.count; ie_index++)
    {

        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        p_protocolIE_elem = 
            (ngap_HandoverRequired_protocolIEs_element *)p_node->data;


        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }

        switch (p_protocolIE_elem->id )
        {
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_1,
                            (void *)&p_local_handover_required->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_2,
                            (void *)&p_local_handover_required->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }
            /*Decode IE - HANDOVER TYPE */
            case ASN1V_ngap_id_HandoverType:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_HandoverType");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_3,
                            (void *)&p_local_handover_required->\
                            handover_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE3 - ASN1V_ngap_id_HANDOVER_TYPE_validation failed");
                }
                break;

            }

            case ASN1V_ngap_id_Cause:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_4,
                            (void *)&p_local_handover_required->id_cause))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE3 - ASN1V_ngap_id_Cause validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_TargetID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_TargetID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_5,
                            (void *)&p_local_handover_required->\
                            target_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE4 - ASN1V_ngap_id_TargetID validation failed");
                }
                break;

            }

            case ASN1V_ngap_id_DirectForwardingPathAvailability:
            {
                RRC_NGAP_TRACE
                    (NGAP_DETAILEDALL,
                     "Decode IE - ASN1V_ngap_id_DirectForwardingPathAvailability");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_6,
                            (void *)&p_local_handover_required->\
                             direct_forwarding_path_availability))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_DirectForwardingPathAvailability");
                }
                else
                {
                    p_local_handover_required->bitmask |=
                        HO_REQUIRED_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT;
                }
                break;
            }

            case  ASN1V_ngap_id_PDUSessionResourceListHORqd:
            {
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_7,
                            (void *)&p_local_handover_required->\
                            pdu_session_res_list_HO_rqd_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                       "IE - ASN1V_ngap_id_PDUSessionResourceListHORqd");
                }
                break;
            }

            case ASN1V_ngap_id_SourceToTarget_TransparentContainer:
            {

                RRC_NGAP_TRACE
                    (NGAP_DETAILEDALL,
                     "Decode IE - ASN1V_ngap_id_SourceToTarget_TransparentContainer");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequiredIEs_8,
                            (void *)&p_local_handover_required->\
                            src_to_trg_transparent_container))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_SourceToTarget_TransparentContainer");
                }
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Invalid Protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }

        }/*End of Switch*/
        p_node = p_node->next;

    }/*End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverPreparation,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Required ");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/******************************************************************************
 *  Function Name: ngap_decode_handover_command
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/

ngap_return_et ngap_decode_handover_command
(
    
    UInt8			            *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_command_t     *p_local_handover_command,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover command");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_command_internal_dec(&asn1_ctx,
            ngap_pdu.u.successfulOutcome->value.u.handoverPreparation,
            p_local_handover_command);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}

/******************************************************************************
 *  Function Name: ngap_handover_command_internal_dec 
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/


ngap_return_et  ngap_handover_command_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_HandoverCommand        *p_ngap_asn_handover_cmd,
    ngap_handover_command_t     *p_ngap_local_handover_cmd
)
{
       
    ngap_HandoverCommand_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_handover_cmd);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    
    ngap_message_data_t  message_map = 
    {
        8, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            
            {   
                2, ASN1V_ngap_id_HandoverType, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   /* Doubt */
                3, ASN1V_ngap_id_NASSecurityParametersFromNGRAN, ngap_conditional,
                ngap_reject , NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                4, ASN1V_ngap_id_PDUSessionResourceHandoverList, ngap_optional , ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_PDUSessionResourceToReleaseListHOCmd , ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            
            {   
                6, ASN1V_ngap_id_TargetToSource_TransparentContainer, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   
                7, ASN1V_ngap_id_CriticalityDiagnostics , ngap_optional , ngap_ignore ,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_handover_cmd->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_handover_cmd->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverCommand_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverCommandIEs_1,
                            (void *)&p_ngap_local_handover_cmd->\
                                amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverCommandIEs_2,
                            (void *)&p_ngap_local_handover_cmd->\
                                ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }
            
            case ASN1V_ngap_id_HandoverType:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_HandoverType");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_3,
                            (void *)&p_ngap_local_handover_cmd->\
                            handover_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE3 - ASN1V_ngap_id_HANDOVER_TYPE_validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_NASSecurityParametersFromNGRAN:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_NASSecurityParametersFromNGRAN");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_4,
                            (void *)&p_ngap_local_handover_cmd->\
                            nas_sec_param_from_ngran))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_NASSecurityParametersFromNGRAN ");
                    //fprintf(stderr, "msg %d ", 1/0);
                }

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceHandoverList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceHandoverList");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_5,
                            (void *)&p_ngap_local_handover_cmd->\
                            pdu_session_ho_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_PDUSessionResourceHandoverList ");
                }

                break;
            }

            case ASN1V_ngap_id_PDUSessionResourceToReleaseListHOCmd:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceToReleaseListHOCmd");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_6,
                            (void *)&p_ngap_local_handover_cmd->\
                            pdu_session_res_to_rel_list_ho_cmd))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_PDUSessionResourceToReleaseListHOCmd");
                }
                else
                {   p_ngap_local_handover_cmd->bitmask |=
                    HANDOVER_COMMAND_PDU_SESSION_RESOURCE_TO_RELEASE_LIST_HO_CMD;/*Handover bug fixes*/
                }
                break;
            }
            
            case ASN1V_ngap_id_TargetToSource_TransparentContainer:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_TargetToSource_TransparentContainer");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_7,
                            (void *)&p_ngap_local_handover_cmd->\
                            trg_to_src_transparent_container))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_TargetToSource_TransparentContainer");
                }
                break;
            }

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverCommandIEs_8,
                            (void *)&p_ngap_local_handover_cmd->\
                            critically_dignostic))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_PDUSessionResourceHandoverList ");
                }
                else
                {
                    p_ngap_local_handover_cmd->bitmask |= 
                       HANDOVER_COMMAND_CRITICALITY_DIGNOSTICS ;/*Handover bug fixes*/
                }

                break;
            }

            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }/*End of switch */   
             p_node = p_node->next;
    }
    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverPreparation,//need to be asked
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Initial Context Setup Request");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


ngap_map_updation_const_et validate_and_fill_nas_security_parameter_from_ngran 
(
       ngap_NASSecurityParametersFromNGRAN   *p_value,
       ngap_dynamic_string_t                 *p_local
)
{
    ngap_map_updation_const_et result = OCCURANCE;
    
    p_local->num_string_len = p_value->numocts;

    /* Allocate memory to string_data of local structure p_local */
    p_local->string_data = (UInt8 *)rrc_mem_get(p_local->num_string_len);
    
    if(NGAP_P_NULL == p_local->string_data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        result = INVALID_VALUE;
        return result;
    }

    /* Copy the value of data into string_data */
    NGAP_MEMCPY(p_local->string_data, p_value->data, p_value->numocts);
    return result;
}

ngap_map_updation_const_et valiate_and_fill_pdu_session_resource_handover_list
(
    ngap_PDUSessionResourceHandoverList     *p_value,
    ngap_pdu_session_res_ho_list_t          *p_local
)
{
   ngap_PDUSessionResourceHandoverItem      *p_value_pdu_session_resource_HO_list_item;

    UInt16                       count                              = NGAP_ZERO; 
    OSRTDListNode               *pdu_session_resource_ho_list_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                              = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_ho_list_node = p_value->head;

    do
    {
        
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;
        
        while(NGAP_P_NULL != pdu_session_resource_ho_list_node )
        {
            p_value_pdu_session_resource_HO_list_item =
                (ngap_PDUSessionResourceHandoverItem *)
                pdu_session_resource_ho_list_node->data;

            /*decode pdu session id */

            p_local->pdu_session_res_ho_item_list[count].\
                pdu_session_id.pdu_session_id = 
                p_value_pdu_session_resource_HO_list_item->pDUSessionID;

            /* Decode handover commmand Transfer */

            result = ngap_decode_handover_command_transfer
                (
                    &p_local->pdu_session_res_ho_item_list[count].\
                    handover_cmd_transfer,
                    &p_value_pdu_session_resource_HO_list_item->\
                    handoverCommandTransfer
                );
            
            pdu_session_resource_ho_list_node = pdu_session_resource_ho_list_node->next;
            count++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}


ngap_map_updation_const_et ngap_decode_handover_command_transfer
(
     ho_command_transfer_t    *p_local,
     OSDynOctStr              *p_value
)
{
    ngap_HandoverCommandTransfer
        *p_handover_cmd_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }

    do
    {
        p_handover_cmd_transfer = rtxMemAllocTypeZ(&asn1_ctx1,
                ngap_HandoverCommandTransfer);

        if(NGAP_P_NULL == p_handover_cmd_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for handover command transfer");

            response = INVALID_VALUE;
            break;
        }


        if (NGAP_ASN_OK != 
                asn1PD_ngap_HandoverCommandTransfer(&asn1_ctx1, 
                    p_handover_cmd_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Decoding of handover command transfer failed");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */

         ngap_asn1PrtToStr_ngap_HandoverCommandTransfer(NGAP_ASN,
                    (SInt8 *)"NGAP_Handover_Command_Transfer",
                    p_handover_cmd_transfer);
  
        }

        /* Decode message */

        /* decode dl_fwding_up_tunnel_info */

        if (NGAP_TRUE ==
                p_handover_cmd_transfer->m.dLForwardingUP_TNLInformationPresent)
        {
            p_local->bitmask |=
                NGAP_HO_COMMAND_TRANSFER_DL_FWDING_UP_TUNNEL_INFO_PRESENT;
        
            p_local->dl_fwding_up_tunnel_info.choice_type |=
                                UP_TRANSPORT_LAYER_INFO_GP_TUNNEL;

            response = validate_and_fill_ul_ngu_up_TNL_info 
                (
                 &p_handover_cmd_transfer->dLForwardingUP_TNLInformation,
                 &p_local->dl_fwding_up_tunnel_info
                );
        }

        /* decode qos_flow_fwd_list */

        if (NGAP_TRUE == 
                p_handover_cmd_transfer->m.qosFlowToBeForwardedListPresent)
        {

            p_local->bitmask |=
                NGAP_HO_COMMAND_TRANSFER_QOS_FLOW_FORWARD_LIST_PRESENT;

            response = decode_ngap_qos_flow_fwd_list
                (
                 &p_handover_cmd_transfer->qosFlowToBeForwardedList,
                 &p_local->qos_flow_fwd_list
                );
        }

        /* decode data_fwding_resp_drb_list */
        if (NGAP_TRUE ==
                p_handover_cmd_transfer->m.dataForwardingResponseDRBListPresent)
        {
            p_local->bitmask |=
                NGAP_HO_COMMAND_TRANSFER_DATA_FWDING_RESP_DRB_LIST_PRESENT;

            response = decode_ngap_data_fwding_resp_drb_list
                (
                 &p_handover_cmd_transfer->dataForwardingResponseDRBList,
                 &p_local->data_fwding_resp_drb_list
                );

        }

        /* decode additional_dl_fwding_up_tunnel_info */
        /* decode ul_fwding_up_tunnel_info */

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_map_updation_const_et decode_ngap_qos_flow_fwd_list 
(
    ngap_QosFlowToBeForwardedList       *p_asn_qos_flow_fwd_list,
    ngap_qos_flow_to_be_fwd_list_t      *p_local_qos_flow_fwd_list
)
{

    ngap_map_updation_const_et  response                = OCCURANCE;
    ngap_QosFlowToBeForwardedItem  *p_qos_flow_forwarded_list_item = NGAP_P_NULL;
    OSRTDListNode               *p_node                 = NGAP_P_NULL;
    UInt32                      index                   = NGAP_ZERO;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_list);
    p_node = p_asn_qos_flow_fwd_list->head;

    do
    {

        if(NGAP_ZERO == p_asn_qos_flow_fwd_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "QOS FLOW FWD LIST is not present");
            
            response = INVALID_VALUE;
            break;
        }

        if( NGAP_MAX_NO_OF_QOS_FLOWS < p_asn_qos_flow_fwd_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Value of count exceeds max value.");
            response = INVALID_VALUE;
            break;
        }

        p_local_qos_flow_fwd_list->count = p_asn_qos_flow_fwd_list->count;
        
        while(NGAP_P_NULL != p_node )
        {
            p_qos_flow_forwarded_list_item = p_node->data;

            /*Decode qos flow identifier */

            p_local_qos_flow_fwd_list->qos_flow_usage_report_item[index].\
                qos_flow_identifier =
            p_qos_flow_forwarded_list_item->qosFlowIdentifier;

            p_node = p_node->next;
            index++;
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}


ngap_map_updation_const_et  decode_ngap_data_fwding_resp_drb_list
(
    ngap_DataForwardingResponseDRBList      *p_asn_data_fwd_resp_drb_list,
    nagp_data_fwding_response_drb_list_t    *p_local_p_asn_data_fwd_resp_drb_list
)
{
    
    ngap_map_updation_const_et  response                = OCCURANCE;
    ngap_DataForwardingResponseDRBItem  *p_data_fwd_resp_drb_list_item = NGAP_P_NULL;
    OSRTDListNode               *p_node                 = NGAP_P_NULL;
    UInt32                      index                   = NGAP_ZERO;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_data_fwd_resp_drb_list);
    p_node = p_asn_data_fwd_resp_drb_list->head;

    do
    {

        if(NGAP_ZERO == p_asn_data_fwd_resp_drb_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "DATA FORWADING RESPONSE DRB LIST is not present");
            response = INVALID_VALUE;
            break;
        }

        if( MAX_DRB  < p_asn_data_fwd_resp_drb_list->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Value of count exceeds max value.");
            response = INVALID_VALUE;
            break;
        }

        p_local_p_asn_data_fwd_resp_drb_list->count =
                             p_asn_data_fwd_resp_drb_list->count;
        while (NGAP_P_NULL != p_node)
        {
            p_data_fwd_resp_drb_list_item = p_node->data;

            /* Decode dRB_ID */

            p_local_p_asn_data_fwd_resp_drb_list->\
                data_fwding_resp_drb_item[index].drb_id  =
                p_data_fwd_resp_drb_list_item->dRB_ID;

            /* Decode dLForwardingUP_TNLInformation  */
            if( NGAP_TRUE ==
                 p_data_fwd_resp_drb_list_item->m.dLForwardingUP_TNLInformationPresent)
            {
                p_local_p_asn_data_fwd_resp_drb_list->\
                    data_fwding_resp_drb_item[index].bitmask |=
                    NGAP_DL_FWDING_UP_TUNNEL_INFO_PRESENT;

                response =  validate_and_fill_ul_ngu_up_TNL_info
                            (    &p_data_fwd_resp_drb_list_item->\
                                dLForwardingUP_TNLInformation,
                               &p_local_p_asn_data_fwd_resp_drb_list->\
                                data_fwding_resp_drb_item[index].\
                                dl_fwding_up_tunnel_info
                            );
            }

            /* Decode uLForwardingUP_TNLInformation */

            if( NGAP_TRUE ==
                 p_data_fwd_resp_drb_list_item->m.uLForwardingUP_TNLInformationPresent)
            {
                p_local_p_asn_data_fwd_resp_drb_list->\
                    data_fwding_resp_drb_item[index].bitmask |=
                    NGAP_UL_FWDING_UP_TUNNEL_INFO_PRESENT;

                response =  validate_and_fill_ul_ngu_up_TNL_info
                             (   &p_data_fwd_resp_drb_list_item->\
                                uLForwardingUP_TNLInformation,
                               &p_local_p_asn_data_fwd_resp_drb_list->\
                                data_fwding_resp_drb_item[index].\
                                ul_fwding_up_tunnel_info
                             );
            }

            p_node = p_node->next;
            index++;
        }
    
    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;

}

/*Handover_changes_end*/
ngap_map_updation_const_et validate_and_fill_target_to_src_transparent_container 
(
       ngap_TargetToSource_TransparentContainer   *p_value,
       ngap_trg_ngran_to_src_ngran_transparent_container_t      *p_local
)
{
  
    
   ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer 
                                    *p_trg_to_src_ngran_container = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }
    do
    {
        p_trg_to_src_ngran_container = rtxMemAllocTypeZ(&asn1_ctx1,
                ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer);

        if (NGAP_P_NULL == p_trg_to_src_ngran_container)
    {
        NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for target to source ngran container");
            response = INVALID_VALUE;
            break;
    }


        if (NGAP_ASN_OK != 
                asn1PD_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer
                (&asn1_ctx1, 
                 p_trg_to_src_ngran_container))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Decoding of target to source ngran container failed");
            response = INVALID_VALUE;
            break;
}
        else
        {
            /* Print the NGAP PDU depending on Log Level */
         ngap_asn1PrtToStr_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer
         (NGAP_ASN,
         (SInt8 *)"NGAP_Handover_Command_Transfer",
         p_trg_to_src_ngran_container);

        }


        /* Decode message */
        /*Decode rrc_container*/
        p_local->rrc_container.num_string_len =
            p_trg_to_src_ngran_container->rRCContainer.numocts;

        p_local->rrc_container.string_data =
             (UInt8 *)rrc_mem_get(sizeof(UInt8));

        if (NGAP_P_NULL ==
            p_local->rrc_container.string_data)
        {
             NGAP_SYSTEM_MEM_FAIL();
             response = INVALID_VALUE;
             break;
        }
        NGAP_MEMCPY
        (p_local->rrc_container.string_data,
         p_trg_to_src_ngran_container->rRCContainer.data,
         p_trg_to_src_ngran_container->rRCContainer.numocts
        );

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/* Handover_changes_end*/
ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceToReleaseListHOCmd
(
    ngap_PDUSessionResourceToReleaseListHOCmd  *p_value,
    ngap_pdu_session_res_to_rel_list_ho_cmd_t  *p_local
)
{
    ngap_PDUSessionResourceToReleaseItemHOCmd   *p_value_pdu_session_resource_release_list_item;
    UInt16                       count                                     = NGAP_ZERO; 
    OSRTDListNode               *pdu_session_resource_release_ho_cmd_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                                     = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    pdu_session_resource_release_ho_cmd_node = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != pdu_session_resource_release_ho_cmd_node )
        {
            p_value_pdu_session_resource_release_list_item =
               (ngap_PDUSessionResourceToReleaseItemHOCmd *)
               pdu_session_resource_release_ho_cmd_node->data;
                
            /*Decode pdu session id */

            p_local->pdu_session_res_to_rel_item_ho_cmd_list[count].\
                pdu_session_id.pdu_session_id =
            p_value_pdu_session_resource_release_list_item->pDUSessionID;

            /*Decode Handover Prepration Unsuccessful Transfer */

            result = ngap_decode_handover_prepration_unsuccessful_transfer
                        (
                        &p_local->pdu_session_res_to_rel_item_ho_cmd_list[count].\
                         handover_prep_unsuccess_transfer,
                        &p_value_pdu_session_resource_release_list_item->\
                         handoverPreparationUnsuccessfulTransfer
                        );
            
            pdu_session_resource_release_ho_cmd_node =
                pdu_session_resource_release_ho_cmd_node->next;
            count++;
        }

    }while(0);

    return  result;
}

ngap_map_updation_const_et ngap_decode_handover_prepration_unsuccessful_transfer
(
    ngap_ho_preparation_unsuccessful_transfer_t *p_local,
    OSDynOctStr                                 *p_value
)
{
    ngap_HandoverPreparationUnsuccessfulTransfer    
        *p_ho_prep_unsuccessful_transfer = NGAP_P_NULL;

    OSCTXT                      asn1_ctx1;
    ngap_map_updation_const_et  response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax 
         * Error because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }
    do
    {
    p_ho_prep_unsuccessful_transfer = (ngap_HandoverPreparationUnsuccessfulTransfer *)
        rtxMemAllocTypeZ(&asn1_ctx1 , ngap_HandoverPreparationUnsuccessfulTransfer);

        if(NGAP_P_NULL == p_ho_prep_unsuccessful_transfer )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Handover Preparation unsuccessful transfer");

            response = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PD_ngap_HandoverPreparationUnsuccessfulTransfer
                (&asn1_ctx1, p_ho_prep_unsuccessful_transfer ))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);

            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Decoding of Handover Preparation unsuccessful transfer");

            response = INVALID_VALUE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverPreparationUnsuccessfulTransfer(
                    &asn1_ctx1,
                    "HANDOVER_PREPARATION_UNSUCCESSFUL_TRANSFER", 
                     p_ho_prep_unsuccessful_transfer );
        }

        /* Decode message */
        
        /* Decode cause*/
        response = ngap_decode_cause(
                    &p_ho_prep_unsuccessful_transfer->cause,
                    &p_local->id_cause);
        
        if(INVALID_VALUE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "couldn't decode cause.");
            response = INVALID_VALUE;
            break;
        }

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/**********************************************************************/
                        //HANDOVER PREPARATION FAILURE
/**********************************************************************/


ngap_return_et ngap_decode_handover_preparation_failure
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_preparation_failure_t  *p_local_ho_preparation_failure,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover preparation failure");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_preparation_failure_internal_dec(&asn1_ctx,
            ngap_pdu.u.unsuccessfulOutcome->value.u.handoverPreparation,
            p_local_ho_preparation_failure);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}

ngap_return_et  ngap_handover_preparation_failure_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverPreparationFailure             *p_ngap_asn_ho_preparation_failure,
    ngap_handover_preparation_failure_t         *p_ngap_local_ho_preparation_failure
)
{

    ngap_HandoverPreparationFailure_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_ho_preparation_failure);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t  message_map = 
    {
        4, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO
            },

            {
                2, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   
                3, ASN1V_ngap_id_CriticalityDiagnostics , ngap_optional , ngap_ignore ,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_preparation_failure->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }


    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_preparation_failure->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverPreparationFailure_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverPreparationFailureIEs_1,
                            (void *)&p_ngap_local_ho_preparation_failure->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverPreparationFailureIEs_2,
                            (void *)&p_ngap_local_ho_preparation_failure->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID Failed");
                }
                break;
            }
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverPreparationFailureIEs_3,
                            (void *)&p_ngap_local_ho_preparation_failure->cause))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } 

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverPreparationFailureIEs_4,
                            (void *)&p_ngap_local_ho_preparation_failure->\
                            critically_dignostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_CriticalityDiagnostics Failed ");
                }
                else
                {
                    p_ngap_local_ho_preparation_failure->bitmask |= 
                        NGAP_HANDOVER_PREPRATON_FAILURE_CRITICALITY_DIGNOSTICS;
                }
                break;
            }

            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch

        p_node = p_node->next;

    }//end for
    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverPreparation,//need to be asked
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Preparation failure");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}
/**********************************************************************/
                        //HANDOVER FAILURE
/**********************************************************************/


ngap_return_et ngap_decode_handover_failure
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_failure_t          *p_local_ho_failure,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover preparation failure");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_failure_internal_dec(&asn1_ctx,
            ngap_pdu.u.unsuccessfulOutcome->value.u.handoverResourceAllocation,
            p_local_ho_failure);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}
ngap_return_et  ngap_handover_failure_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverFailure                        *p_ngap_asn_ho_failure,
    ngap_handover_failure_t                     *p_ngap_local_ho_failure
)
{

    ngap_HandoverFailure_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_ho_failure);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t  message_map = 
    {
        3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                1, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   
                2, ASN1V_ngap_id_CriticalityDiagnostics , ngap_optional , ngap_ignore ,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_failure->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }


    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_failure->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverFailure_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverFailureIEs_1,
                            (void *)&p_ngap_local_ho_failure->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverFailureIEs_2,
                            (void *)&p_ngap_local_ho_failure->\
                            choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE1 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } 

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverFailureIEs_3,
                            (void *)&p_ngap_local_ho_failure->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_CriticalityDiagnostics ");
                }
                else
                {
                    p_ngap_local_ho_failure->bitmask |= 
                        HO_FAILURE_CRITICAL_DIAGNOSTICS_PRESENT;
                }
                break;
            }

            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch

        p_node = p_node->next;

    }//end for

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverResourceAllocation,//need to be asked
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Preparation failure");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}



/*************************************************************************************/

//                      HANDOVER NOTIFY
/*************************************************************************************/


ngap_return_et ngap_decode_handover_notify
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_notify_t              *p_local_ho_notify,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover notify");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_notify_internal_dec(&asn1_ctx,
            ngap_pdu.u.initiatingMessage->value.u.handoverNotification,
            p_local_ho_notify);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}

ngap_return_et  ngap_handover_notify_internal_dec
(
    OSCTXT                         *p_asn1_ctx,
    ngap_HandoverNotify            *p_ngap_asn_ho_notify,
    ngap_handover_notify_t         *p_ngap_local_ho_notify
)
{

    ngap_HandoverNotify_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_ho_notify);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t  message_map = 
    {
        3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {
                1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO
            },

            {
                2, ASN1V_ngap_id_UserLocationInformation, ngap_mandatory,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_notify->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }


    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_notify->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverNotify_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverNotifyIEs_1,
                            (void *)&p_ngap_local_ho_notify->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverNotifyIEs_2,
                            (void *)&p_ngap_local_ho_notify->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /* IE3 - ASN1V_ngap_id_UserLocationInformation */
            case ASN1V_ngap_id_UserLocationInformation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_UserLocationInformation");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverNotifyIEs_3,/*Handover bug fixes*/
                            (void *)&p_ngap_local_ho_notify->\
                            choice_user_location_information))
                {

                    RRC_NGAP_TRACE
                        (NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_UserLocationInformation validation failed"
                        );
                }

                break;
            }
                default:
                {

                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                    /* Add IE to list of Error IEs*/
                    ngap_add_to_err_ind_ie_list(&ie_list,
                            p_protocolIE_elem->criticality,
                            p_protocolIE_elem->id,
                            &ie_list_index,
                            &send_err_ind,
                            NGAP_FALSE);
                    break;
                }
            }//end switch

            p_node = p_node->next;

        }//end for

        /*Parse the map for Error Indication */
        if(NGAP_FAILURE == parse_ngap_message_map(
                    p_asn1_ctx,
                    &message_map,
                    &ie_list,
                    &ie_list_index,
                    &send_err_ind,
                    ASN1V_ngap_id_HandoverNotification,//need to be asked
                    (ngap_error_indication_t *)NGAP_P_NULL))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Notify");
            ret_val = NGAP_FAILURE;
        }

        RRC_NGAP_UT_TRACE_EXIT();
        return ret_val;
}


/**********************************************************************************/
//                      HANDOVER CANCLE
/**********************************************************************************/


ngap_return_et ngap_decode_handover_cancel
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_cancel_t          *p_local_ho_cancel,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover cancel");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_cancel_internal_dec(&asn1_ctx,
            ngap_pdu.u.initiatingMessage->value.u.handoverCancel,
            p_local_ho_cancel);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}
ngap_return_et  ngap_handover_cancel_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverCancel                        *p_ngap_asn_ho_cancel,
    ngap_handover_cancel_t                     *p_ngap_local_ho_cancel
)
{

    ngap_HandoverCancel_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_handover_cmd);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t  message_map = 
    {
        3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {   1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_cancel->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }


    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_cancel->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverCancel_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverCancelIEs_1,
                            (void *)&p_ngap_local_ho_cancel->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverCancelIEs_2,
                            (void *)&p_ngap_local_ho_cancel->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 

                break;
            }
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverCancelIEs_3,
                            (void *)&p_ngap_local_ho_cancel->\
                            choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE3 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } 

            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch

        p_node = p_node->next;

    }//end for

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverCancel,//need to be asked
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Preparation failure");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/***********************************************************************************/
//                  HANDOVER CALCEL ACKNOWLEDGE
/***********************************************************************************/


ngap_return_et ngap_decode_handover_cancel_acknowledge
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_cancel_ack_t          *p_local_ho_cancel_ack,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for handover cancel");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }
            /*Decode Message */
        response = ngap_handover_cancel_acknowledge_internal_dec(&asn1_ctx,
            ngap_pdu.u.successfulOutcome->value.u.handoverCancel,
            p_local_ho_cancel_ack);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}



ngap_return_et  ngap_handover_cancel_acknowledge_internal_dec
(
    OSCTXT                                     *p_asn1_ctx,
    ngap_HandoverCancelAcknowledge             *p_ngap_asn_ho_cancel_ack,
    ngap_handover_cancel_ack_t                 *p_ngap_local_ho_cancel_ack
)
{

    ngap_HandoverCancelAcknowledge_protocolIEs_element  *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_asn_handover_cmd);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t  message_map = 
    {
        3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {

            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },

            {   1,ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {   2, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }

        }
    };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_cancel_ack->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }


    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_cancel_ack->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverCancelAcknowledge_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }


        switch(p_protocolIE_elem->id)
        {
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverCancelAcknowledgeIEs_1,
                            (void *)&p_ngap_local_ho_cancel_ack->\
                            amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }

            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {   
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverCancelAcknowledgeIEs_2,
                            (void *)&p_ngap_local_ho_cancel_ack->\
                            ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                } 

                break;
            }

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverCancelAcknowledgeIEs_3,
                            (void *)&p_ngap_local_ho_cancel_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE3 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_ngap_local_ho_cancel_ack->bitmask |= 
                        HO_CANCEL_ACK_CRITICAL_DIAGNOSTICS_PRESENT;
                }
                break;
            } 
            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch

        p_node = p_node->next;

    }//end for

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverCancel,//need to be asked
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Preparation failure");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/******************************************************************************
 *  Function Name:  ngap_decode_handover_request_acknowledge 
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/


ngap_return_et ngap_decode_handover_request_acknowledge 
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_req_ack_t         *p_local_handover_req_ack,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{

    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Initial context setup request");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_handover_request_ack_internal_dec(&asn1_ctx,
        ngap_pdu.u.successfulOutcome->value.u.handoverResourceAllocation,
        p_local_handover_req_ack);    

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;
}


/******************************************************************************
 *  Function Name: ngap_handover_request_ack_internal_dec
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/


ngap_return_et ngap_handover_request_ack_internal_dec 
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_HandoverRequestAcknowledge         *p_ngap_asn_ho_req_ack,
    ngap_handover_req_ack_t                 *p_ngap_local_ho_req_ack
)
{

    ngap_HandoverRequestAcknowledge_protocolIEs_element *p_protocolIE_elem = NGAP_P_NULL;
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_init_context_setup_req);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/

    ngap_message_data_t message_map =
    {6, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_RAN_UE_NGAP_ID, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2,ASN1V_ngap_id_PDUSessionResourceAdmittedList,ngap_mandatory,
                ngap_ignore,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO
            },
            {
                3,ASN1V_ngap_id_PDUSessionResourceFailedToSetupListHOAck,ngap_optional,
                ngap_ignore,NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                4,ASN1V_ngap_id_TargetToSource_TransparentContainer,ngap_mandatory,
                ngap_reject,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO
            },
            {
                5,ASN1V_ngap_id_CriticalityDiagnostics,ngap_optional,ngap_ignore,
                NGAP_ZERO,NGAP_ZERO,NGAP_ZERO,NGAP_ZERO
            }
        }
     };

    /* Initialize pnode with first IE */
    p_node = p_ngap_asn_ho_req_ack->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_ngap_asn_ho_req_ack->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverRequestAcknowledge_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        
        switch(p_protocolIE_elem->id )
        {
            
            /* Decode IE - AMF UE NGAP ID*/
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestAcknowledgeIEs_1,
                            (void *)&p_ngap_local_ho_req_ack->\
                                amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }
                break;
            }
            /* Decode IE - RAN UE NGAP ID*/
            case ASN1V_ngap_id_RAN_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_RAN_UE_NGAP_ID");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestAcknowledgeIEs_2,
                            (void *)&p_ngap_local_ho_req_ack->\
                                ran_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE2 - ASN1V_ngap_id_RAN_UE_NGAP_ID validation failed");
                }
                break;
            }

            /*Decode id-PDUSessionResourceAdmittedList */
            
            
            case ASN1V_ngap_id_PDUSessionResourceAdmittedList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceAdmittedList");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestAcknowledgeIEs_3,
                            (void *)&p_ngap_local_ho_req_ack->\
                            ho_req_ack_pdu_session_res_adm_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_PDUSessionResourceAdmittedList Failed");
                }
                break;
            }
            /*Decode id-PDUSessionResourceFailedToSetupListHOAck */

            case ASN1V_ngap_id_PDUSessionResourceFailedToSetupListHOAck:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PDUSessionResourceFailedToSetupListHOAck");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestAcknowledgeIEs_4,
                            (void *)&p_ngap_local_ho_req_ack->\
                            ho_req_ack_pdu_session_res_fail_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE -ASN1V_ngap_id_PDUSessionResourceFailedToSetupListHOAck Failed ");
                }
                else
                {
                    p_ngap_local_ho_req_ack->bitmask |=
                        HO_REQ_ACK_PDU_SESSION_FAILED_TO_SETUP_LIST_PRESENT;
                }
                break;
            }
            /*Decode id-TargetToSource-TransparentContainer */

            case ASN1V_ngap_id_TargetToSource_TransparentContainer:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_TargetToSource_TransparentContainer");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestAcknowledgeIEs_5,
                            (void *)&p_ngap_local_ho_req_ack->\
                            trg_to_src_transparent_container))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_TargetToSource_TransparentContainer");
                }
                break;
            }
            /*Decode id-CriticalityDiagnostics */

            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestAcknowledgeIEs_6,
                            (void *)&p_ngap_local_ho_req_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE5 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                  p_ngap_local_ho_req_ack->bitmask |= 
                        HO_REQ_ACK_CRITICAL_DIAGNOSTICS_PRESENT;
                }
                break;
            } /* End of IE5 */
        }//end of switch
            p_node = p_node->next;
    }
    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverResourceAllocation,//to be disscussed
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode handover Request acknowledge");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}



ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceAdmittedList
    (
        ngap_PDUSessionResourceAdmittedList           *p_value,
        ngap_ho_req_ack_pdu_session_res_adm_list_t    *p_local
    )
{
    ngap_PDUSessionResourceAdmittedItem
        *p_value_pdu_session_resource_admitted_item;


    UInt16                      count  = NGAP_ZERO;
    ngap_map_updation_const_et  result = OCCURANCE;

    OSRTDListNode   *p_pdu_session_resource_adimitted_node = NGAP_P_NULL;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_pdu_session_resource_adimitted_node  = p_value->head;

    do
    {
        
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        
        else
        {
            p_local->count = p_value->count;

            while(NGAP_P_NULL != p_pdu_session_resource_adimitted_node )
            {
                p_value_pdu_session_resource_admitted_item =
                    (ngap_PDUSessionResourceAdmittedItem *)\
                    p_pdu_session_resource_adimitted_node->data;

                /* Decode pdu session id */
                p_local->pdu_session_res_adm_item[count].\
                    pdu_session_id.pdu_session_id =
                    p_value_pdu_session_resource_admitted_item->pDUSessionID;

                /* Decode handoverRequestAcknowledgeTransfer */


            if(OCCURANCE != ngap_decode_ho_request_ack_transfer(
                
                     &p_value_pdu_session_resource_admitted_item->\
                     handoverRequestAcknowledgeTransfer,
                     &p_local->pdu_session_res_adm_item[count].\
                     ho_request_ack_transfer
            ))//HandOver chnages in function
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode Handover Request Acknowledge Transfer");
                result = INVALID_VALUE;
                return result;
            }

                p_pdu_session_resource_adimitted_node =
                    p_pdu_session_resource_adimitted_node->next;
                count++;
            }
        }
    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/**************************************************************************************
 *              ngap_decode_ho_request_ack_transfer
 * *************************************************************************************/

ngap_map_updation_const_et ngap_decode_ho_request_ack_transfer
(
    OSDynOctStr                                  *p_value,
    ngap_ho_request_acknowledge_transfer_t       *p_local
)
{
    ngap_HandoverRequestAcknowledgeTransfer
        *p_ho_request_ack_transfer = NGAP_P_NULL;

    OSCTXT                              asn1_ctx1;
    ngap_map_updation_const_et          response = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = INVALID_VALUE;
        return response;
    }
    
    do
    {
        p_ho_request_ack_transfer = rtxMemAllocTypeZ(&asn1_ctx1,
                ngap_HandoverRequestAcknowledgeTransfer);
        if (NGAP_P_NULL == p_ho_request_ack_transfer )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = INVALID_VALUE;
            break;
        }
        
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Handover Request Acknowledge Transfer");

            response = INVALID_VALUE;
            break;
        }
        
        if (NGAP_ASN_OK  !=
                asn1PD_ngap_HandoverRequestAcknowledgeTransfer(&asn1_ctx1,
                p_ho_request_ack_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Decoding of Handover Request Acknowledge transfer failed");
            response = INVALID_VALUE;
            break;
        }

        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer(NGAP_ASN,
                (SInt8 *)"NGAP_HANDOVER_REQUEST_ACKNOWLEDGE_TRANSFER",
                p_ho_request_ack_transfer);
        }

        /*Decode Mesaages */

        /*Decode IE dl_ngu_up_tnl_information */
        
            if(OCCURANCE != validate_and_fill_ul_ngu_up_TNL_info(
                
                &p_ho_request_ack_transfer->dL_NGU_UP_TNLInformation,
                &p_local->dl_ngu_up_tnl_information
            ))/* ul_ngu and dl_ngu are similer */
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode DL NGU UP TNL Information");
                response = INVALID_VALUE;
                return response;
            }

        /*Decode IE dl_forwarding_up_tnl_information */
        if (NGAP_TRUE ==
                p_ho_request_ack_transfer->m.dLForwardingUP_TNLInformationPresent)
        {
            p_local->bitmask |=
                HO_REQ_ACK_DL_FORWARDING_UP_TNL_INFORMATION_PRESENT;

            if(OCCURANCE != validate_and_fill_ul_ngu_up_TNL_info(

                        &p_ho_request_ack_transfer->dLForwardingUP_TNLInformation,
                        &p_local->dl_forwarding_up_tnl_information
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not decode DL Forwarding UP TNL Information");
                response = INVALID_VALUE;
                return response;
            }

        }

        /*Decode IE security_result */

        if (NGAP_TRUE ==
                p_ho_request_ack_transfer->m.securityResultPresent)
        {
            p_local->bitmask |=
                HO_REQ_ACK_SECURITY_RESULT_PRESENT;

            p_local->security_result.integrity_protection_result = 
                (ngap_integrity_protection_result_et)p_ho_request_ack_transfer->\
                    securityResult.integrityProtectionResult;

            p_local->security_result.confidentiality_protection_result = 
                (ngap_integrity_protection_result_et)p_ho_request_ack_transfer->\
                    securityResult.confidentialityProtectionResult;

        }
        /*Decode IE qos_flow_setup_response_list*/

            response = ngap_decode_qos_flow_setup_response_list(
                &p_ho_request_ack_transfer->qosFlowSetupResponseList,
                        &p_local->qos_flow_setup_response_list);

        /*Decode IE qos_flow_failed_to_setup_list */

        if (NGAP_TRUE ==
                p_ho_request_ack_transfer->m.qosFlowFailedToSetupListPresent)
        {
            p_local->bitmask |=
                HO_REQ_ACK_QOS_FLOW_FAILED_TO_SETUP_LIST_PRESENT;

            if(OCCURANCE != ngap_decode_qos_failed_to_setup_list(

                        &p_ho_request_ack_transfer->qosFlowFailedToSetupList,
                        &p_local->qos_flow_failed_to_setup_list
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not decode qos Flow Failed To Setup List");
                response = INVALID_VALUE;
                return response;
            }

        }

        /*Decode IE data_forwarding_response_drb_list */

        if (NGAP_TRUE ==
                p_ho_request_ack_transfer->m.dataForwardingResponseDRBListPresent)
        {
            p_local->bitmask |=
                HO_REQ_ACK_DATA_FORWARDING_RESPONSE_DRB_LIST_PRESENT;

            if(OCCURANCE != decode_ngap_data_fwding_resp_drb_list(

                        &p_ho_request_ack_transfer->dataForwardingResponseDRBList,
                        &p_local->data_forwarding_response_drb_list
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not decode Data Forwarding Response drb List");
                response = INVALID_VALUE;
                return response;
            }

        }
    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
   
}
/***********************************************************************************
 *                  ngap_decode_additional_dl_up_tnl_info_for_ho_list
 * *********************************************************************************/

ngap_map_updation_const_et ngap_decode_additional_dl_up_tnl_info_for_ho_list
(
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions       *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t                *p_local
)
{
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions_element 
        *p_value_asn_item = NGAP_P_NULL;

    OSRTDListNode               *p_node            = NGAP_P_NULL;
    ngap_map_updation_const_et  result           = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        while (NGAP_P_NULL != p_node )
        {
            p_value_asn_item = 
                (ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions_element *)p_node->data;

            /*additional_dl_up_tnl_info_for_ho_list_item */
            switch (p_value_asn_item->extensionValue.t )
            {
                case HO_REQ_ACK_ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_ITEM://doubt in cases
                {
                    p_local->bitmask =
                        HO_REQ_ACK_ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_ITEM;

                    if ( OCCURANCE !=
                            validate_and_fill_additional_dl_up_tnl_info_for_ho_list_item
                            (
                             p_value_asn_item->extensionValue.u.\
                             _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1,
                             p_local
                            ))
                    {
                        RRC_NGAP_TRACE
                            (NGAP_ERROR,
                             "Could not decode additional_dl_up_tnl_info_for_ho_list_item"
                            );
                        result = INVALID_VALUE;
                        break;
                    }
                    break;
                }

                case HO_REQ_ACK_TRANSFER_UP_TRANSPORT_LAYER_INFORMATION:
                {
                    p_local->bitmask =
                        HO_REQ_ACK_TRANSFER_UP_TRANSPORT_LAYER_INFORMATION;

                    /*Decode IE up_transport_layer_information */

                    if ( OCCURANCE != validate_and_fill_ul_ngu_up_TNL_info(
                                p_value_asn_item->extensionValue.u.\
                                _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_2,
                                &p_local->up_transport_layer_information) )
                    {
                        RRC_NGAP_TRACE(NGAP_ERROR,
                                "Could not decode UP TRANSPORT LAYER INFORMATION ");
                        result = INVALID_VALUE;
                        break;
                    }
                    break;
                }

               default:
               {
                   break;
               }
            }//end switch

        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

/**************************************************************************************
 *             validate_and_fill_additional_dl_up_tnl_info_for_ho_list_item
 *
 * ************************************************************************************/

ngap_map_updation_const_et validate_and_fill_additional_dl_up_tnl_info_for_ho_list_item
(
    ngap_AdditionalDLUPTNLInformationForHOList      *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t    *p_local
)
{
    ngap_AdditionalDLUPTNLInformationForHOItem  *p_value_item = NGAP_P_NULL;

    UInt16                       count   = NGAP_ZERO;
    OSRTDListNode               *p_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_node = p_value->head;

    do
    {
        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while( NGAP_P_NULL != p_node)
        {
            p_value_item =
                (ngap_AdditionalDLUPTNLInformationForHOItem *)p_node->data;

            /*Decode IE additionalDL_NGU_UP_TNLInformation */
            if (OCCURANCE != 
                    validate_and_fill_ul_ngu_up_TNL_info(
                        &p_value_item->additionalDL_NGU_UP_TNLInformation,
                        &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                        up_transport_layer_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not decode UP TRANSPORT LAYER INFORMATION ");
                result = INVALID_VALUE;
                break;
            }
            /* Decode IE additionalQosFlowSetupResponseList*/

            if (OCCURANCE != 
                    ngap_decode_qos_flow_setup_response_list(
                        &p_value_item->additionalQosFlowSetupResponseList,
                        &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                        qos_flow_list_with_data_forwarding))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not decode additionalQosFlowSetupResponseList");
                result = INVALID_VALUE;
                break;
            }

            /*Decode IE additionalDLForwardingUPTNLInformation */
            if (NGAP_TRUE ==
                    p_value_item->m.additionalDLForwardingUPTNLInformationPresent)
            {
                p_local->bitmask |= ADDITIONAL_DL_FORWARDING_UP_TNL_INFORMATION;

                if (OCCURANCE != 
                        validate_and_fill_ul_ngu_up_TNL_info(
                            &p_value_item->additionalDLForwardingUPTNLInformation,
                            &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                            additional_dl_forwarding_up_tnl_information))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "Could not decode UP TRANSPORT LAYER INFORMATION ");
                    result = INVALID_VALUE;
                    break;
                }
            }

            p_node = p_node->next;
            count++;

        }//end while

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/**********************************************************************************
 *                      ngap_decode_qos_flow_setup_response_list
 * ********************************************************************************/

ngap_map_updation_const_et  ngap_decode_qos_flow_setup_response_list
(
    ngap_QosFlowListWithDataForwarding          *p_value,
    ngap_qos_flow_list_with_data_forwarding     *p_local
)
{
    ngap_map_updation_const_et  result                = OCCURANCE;
    ngap_QosFlowItemWithDataForwarding  *p_qos_flow_item_with_data_fwd = NGAP_P_NULL;
    OSRTDListNode               *p_node                 = NGAP_P_NULL;
    UInt32                      count                   = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {
        if (NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;

        }
        else if(NGAP_MAX_NO_OF_QOS_FLOWS < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        else
        {
            p_local->count = p_value->count;
            
            p_node = p_value->head;

            while(NGAP_P_NULL != p_node)
            {
                p_qos_flow_item_with_data_fwd =
                    (ngap_QosFlowItemWithDataForwarding *)p_node->data;

                /*Decode qos flow identifier*/

                p_local->qos_flow_item_with_data_forwading[count].\
                    qos_flow_identifier.qos_flow_identifier =
                    p_qos_flow_item_with_data_fwd->qosFlowIdentifier;

                /*Decode dataForwardingAccepted */
                p_local->qos_flow_item_with_data_forwading[count].bitmask |=  
                        HO_REQ_ACK_TRANSFER_DATA_DORWARDING_ACCEPT;/*Handover bug fixes*/
                /*COVERITY FIX*/
                p_local->qos_flow_item_with_data_forwading[count].\
                    data_forwading_accepted =
                    (ngap_data_forwarding_accepted_et)p_qos_flow_item_with_data_fwd->dataForwardingAccepted;
                /*COVERITY FIX*/

                p_node = p_node->next;
                count++;
            }
        }

    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/******************************************************************************
 *  Function Name: validate_and_fill_PDUSessionResourceFailedToSetupListHOAck 
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/
ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceFailedToSetupListHOAck
     (
        ngap_PDUSessionResourceFailedToSetupListHOAck * p_value,
        ngap_ho_req_ack_pdu_session_res_fail_list_t *  p_local
     )
{
    ngap_PDUSessionResourceFailedToSetupItemHOAck
            *p_value_pdu_session_resource_failed_setup_item;


    UInt16                      count  = NGAP_ZERO;
    ngap_map_updation_const_et  result = OCCURANCE;

    OSRTDListNode   *p_pdu_session_resource_failed_setup_node = NGAP_P_NULL;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_pdu_session_resource_failed_setup_node  = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_PDU_SESSION < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }

        p_local->count = p_value->count;

        while(NGAP_P_NULL != p_pdu_session_resource_failed_setup_node)
        {
            p_value_pdu_session_resource_failed_setup_item =
               (ngap_PDUSessionResourceFailedToSetupItemHOAck *)\
               p_pdu_session_resource_failed_setup_node->data;

               /*Decode pdu session id */

               p_local->pdu_session_res_failed_item[count].\
               pdu_session_id.pdu_session_id =
               p_value_pdu_session_resource_failed_setup_item->pDUSessionID;

               /*Decode handoverResourceAllocationUnsuccessfulTransfer */

               result = validate_and_fill_ho_resource_allocation_unsuccessful_transfer
                            (
                            &p_value_pdu_session_resource_failed_setup_item->\
                            handoverResourceAllocationUnsuccessfulTransfer,
                            &p_local->pdu_session_res_failed_item[count].\
                            ho_res_alloc_unsuccessful_transfer
                            );
              p_pdu_session_resource_failed_setup_node =
                    p_pdu_session_resource_failed_setup_node->next;
                    count++;
        }

    }while(0);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/******************************************************************************
 *  Function Name:  validate_and_fill_ho_resource_allocation_unsuccessful_transfer
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/

ngap_map_updation_const_et validate_and_fill_ho_resource_allocation_unsuccessful_transfer
(
 OSDynOctStr                                             *p_value,
 ngap_ho_resource_allocation_unsuccessful_transfer_t     *p_local
)
{
    ngap_HandoverResourceAllocationUnsuccessfulTransfer
        *p_ho_res_allocation_unssuccessfulTransfer = NGAP_P_NULL;

    OSCTXT                              asn1_ctx1;
    ngap_map_updation_const_et          result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         *                         */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        result = INVALID_VALUE;
        return result;
    }

    do
    {
        p_ho_res_allocation_unssuccessfulTransfer =
            rtxMemAllocTypeZ(&asn1_ctx1,
                    ngap_HandoverResourceAllocationUnsuccessfulTransfer);

        if (NGAP_P_NULL == p_ho_res_allocation_unssuccessfulTransfer )
        {
            NGAP_SYSTEM_MEM_FAIL();
            result = INVALID_VALUE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, 
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE
                (NGAP_ERROR, 
                 "Failed pu_setBuffer for Handover Resource Allocation Unsuccessful Transfer"
                );

            result = INVALID_VALUE;
            break;
        }

        if (NGAP_ASN_OK  !=
                asn1PD_ngap_HandoverResourceAllocationUnsuccessfulTransfer(&asn1_ctx1,
                    p_ho_res_allocation_unssuccessfulTransfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Decoding of Handover Resource Allocation Unsuccessful transfer failed");
            result = INVALID_VALUE;
            break;
        }

        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_ngap_HandoverResourceAllocationUnsuccessfulTransfer(NGAP_ASN,
                    (SInt8 *)"NGAP_HANDOVER_RESOURCE_ALLOCATION_UNSUCCESSFUL_TRANSFER",
                    p_ho_res_allocation_unssuccessfulTransfer);
        }

        /*Decode Message */

        /*Decode Cause */

        result = validate_and_fill_choice_cause_group(
                    &p_ho_res_allocation_unssuccessfulTransfer->cause,
                    &p_local->choice_cause_group);

        if(INVALID_VALUE == result)
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failled to Decode Choice Cause Group");
            break;
        }/*Handover bug fixes*/
                    
        /*Decode Criticality*/
        if (NGAP_TRUE ==
                p_ho_res_allocation_unssuccessfulTransfer->m.criticalityDiagnosticsPresent)
        {
            p_local->bitmask |=
                HO_RESOURCE_ALLOCATION_UNSUCCESSFUL_TRANSFER_CRITICALITY_DIGNOSTICS;

            result = validate_and_fill_criticality_diagnostics(
                        &p_ho_res_allocation_unssuccessfulTransfer->\
                        criticalityDiagnostics,
                        &p_local->criticality_dignostics
                    );

            if(INVALID_VALUE == result)
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Could not criticality_dignostics");
                break;
            }/*Handover bug fixes*/
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return result;
}

/******************************************************************************
 *  Function Name:  
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/

ngap_return_et ngap_decode_handover_request
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_request_t                 *p_local_handover_request,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    /*COVERITY FIX*/
    ngap_return_et                  response;
    /*COVERITY FIX*/
		
    RRC_NGAP_UT_TRACE_ENTER();
	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /* Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
            pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                "Failed pu_setBuffer for Initial context setup request");

            response = NGAP_FAILURE;
            break;
        }
      
        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of ICS Request Failed");
            response = NGAP_FAILURE;

#ifndef AMF_SIM_TESTING_ENABLE
            /* Send Transfer Syntax Error */
            if(p_amf_context != NGAP_P_NULL)
            {
                ngap_build_and_send_error_ind
                (
                    p_amf_context,
                    NGAP_FALSE,
                    INVALID_VAL_TWO_BYTE,
                    NGAP_FALSE,
                    INVALID_VAL_FOUR_BYTE,
                    NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE,
                    TRANSFER_SYNTAX_ERROR,
                    NGAP_FALSE,
                    ngap_id_InvalidProcedureCode,
                    NGAP_TRIG_INVALID_TRIGGERING_MSG,
                    NGAP_PROC_CRITICALITY_REJECT,
                    NGAP_P_NULL
                );
            }
            
#endif
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ngap_handover_request_internal_dec(&asn1_ctx,
                   ngap_pdu.u.initiatingMessage->value.u.handoverResourceAllocation,
                   p_local_handover_request
                   );

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
	
    RRC_NGAP_UT_TRACE_EXIT();
	
    return response;

}


/******************************************************************************
 *  Function Name: ngap_handover_request_internal_dec 
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/

ngap_return_et  ngap_handover_request_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_HandoverRequest        *p_asn_handover_request,
    ngap_handover_request_t     *p_local_handover_request
)
{
    ngap_HandoverRequest_protocolIEs_element    *p_protocolIE_elem = NGAP_P_NULL;

    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_handover_request);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map =
    {20, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {
            {
                0, ASN1V_ngap_id_AMF_UE_NGAP_ID, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                1, ASN1V_ngap_id_HandoverType,ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                2, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                3, ASN1V_ngap_id_UEAggregateMaximumBitRate, ngap_mandatory, 
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO  
            },
            {
                4, ASN1V_ngap_id_CoreNetworkAssistanceInformationForInactive,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                5, ASN1V_ngap_id_UESecurityCapabilities, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                6, ASN1V_ngap_id_SecurityContext , ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                7, ASN1V_ngap_id_NewSecurityContextInd, ngap_optional, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                8 ,ASN1V_ngap_id_NASC, ngap_optional, ngap_reject, 
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                9, ASN1V_ngap_id_PDUSessionResourceSetupListHOReq, ngap_mandatory,
                ngap_reject, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                10,ASN1V_ngap_id_AllowedNSSAI, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                11, ASN1V_ngap_id_TraceActivation, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                12, ASN1V_ngap_id_MaskedIMEISV, ngap_optional, ngap_ignore,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                13, ASN1V_ngap_id_SourceToTarget_TransparentContainer,ngap_mandatory,
                ngap_reject,  NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                14, ASN1V_ngap_id_MobilityRestrictionList,ngap_optional,
                ngap_ignore,  NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                15, ASN1V_ngap_id_LocationReportingRequestType, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                16, ASN1V_ngap_id_RRCInactiveTransitionReportRequest,
                ngap_optional, ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
                NGAP_ZERO
            },
            {
                17, ASN1V_ngap_id_GUAMI, ngap_mandatory, ngap_reject,
                NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                18, ASN1V_ngap_id_RedirectionVoiceFallback, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            },
            {
                19, ASN1V_ngap_id_CNAssistedRANTuning, ngap_optional,
                ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
            }
        }
    };    
    /* Initialize pnode with first IE */
    p_node = p_asn_handover_request->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "First node is NULL");
        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index <
            p_asn_handover_request->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        p_protocolIE_elem =
            (ngap_HandoverRequest_protocolIEs_element *)p_node->data;

        if(NGAP_P_NULL == p_protocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u doesnt exist", ie_index);
            ret_val = NGAP_FAILURE;
            break;
        }
        
        switch(p_protocolIE_elem->id)
        {

            /* IE1 - AMF_UE_NGAP_ID */
            case ASN1V_ngap_id_AMF_UE_NGAP_ID:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE ASN1V_ngap_id_AMF_UE_NGAP_ID");

                /* Validate and fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_1,
                            (void *)&p_local_handover_request->amf_ue_ngap_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE1 - ASN1V_ngap_id_AMF_UE_NGAP_ID validation failed");
                }

                break;
            }
            
            /*Decode IE - HANDOVER TYPE */
            case ASN1V_ngap_id_HandoverType:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_HandoverType");

                /* Validate and fill IE*/
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_2,
                            (void *)&p_local_handover_request->\
                            handover_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE - ASN1V_ngap_id_HANDOVER_TYPE_validation failed");
                }
                break;

            }
            /*Decode IE ASN1V_ngap_id_Cause */
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_3,
                            (void *)&p_local_handover_request->choice_cause))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } 

            /* IE - UE Aggregate Maximum Bit Rate */

            case ASN1V_ngap_id_UEAggregateMaximumBitRate:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - UE Aggregate Maximum Bit Rate");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_4,
                            (void *)&p_local_handover_request->\
                                ue_aggregate_maximum_bit_rate))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                        "IE - UE Aggregate Maximum Bit Rate Validation Failed");
                }

                break;
            }
            /* Decode IE - UE Security Capabilities */
            case ASN1V_ngap_id_UESecurityCapabilities:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_UESecurityCapabilities");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_6,
                            (void *)&p_local_handover_request->\
                                ue_security_capabilities))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE - ASN1V_ngap_id_UESecurityCapabilities validation Failed");

                }
                break;
            }
            
            /* Decode IE - ASN1V_ngap_id_SecurityContext */
            case ASN1V_ngap_id_SecurityContext:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_SecurityContext");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_7,
                            (void *)&p_local_handover_request->\
                                security_context))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE -ASN1V_ngap_id_SecurityContext Failed ");

                }
                break;
            }

            /* Decode IE - ASN1V_ngap_id_NewSecurityContextInd */
            case ASN1V_ngap_id_NewSecurityContextInd:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                    "Decode IE - ASN1V_ngap_id_NewSecurityContextInd");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_8,
                            (void *)&p_local_handover_request->\
                                new_security_ctx_ind))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                        "IE -ASN1V_ngap_id_NewSecurityContextInd Failed  ");

                }
                else
                {
                    p_local_handover_request->bitmask |= 
                        NGAP_HANDOVER_REQUEST_NEW_SECURITY_CONTEXT_IND_PRESENT;
                }
                break;
            }
            
            /* Decode IE - ASN1V_ngap_id_NASC */
            
            case ASN1V_ngap_id_NASC:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE9 - NAS-PDU");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_9,
                            (void *)&p_local_handover_request->nas_pdu))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE9 - NAS-PDU Validation Failed");
                }
                else
                {
                   p_local_handover_request->bitmask |=
                       NGAP_HANDOVER_REQUEST_NAS_PDU_PRESENT;
                }

                break;
            }
           /*Decode ASN1V_ngap_id_PDUSessionResourceSetupListHOReq  */ 
            case ASN1V_ngap_id_PDUSessionResourceSetupListHOReq:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE- ASN1V_ngap_id_PDUSessionResourceSetupListHOReq");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_10,
                            (void *)&p_local_handover_request->\
                            pdu_session_res_setup_list_HO_req))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                       "IE - ASN1V_ngap_id_PDUSessionResourceSetupListHOReq Failed");
                }
                break;
            }
            
            /*IE - Allowed NSSAI */
            case ASN1V_ngap_id_AllowedNSSAI:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                                "Decode IE - Allowed NSSAI");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_11,
                            (void *)&p_local_handover_request->\
                            allowed_nssai_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,"IE - Allowed NSSAI Validation failed");
                }
                break;
            }
           
            /*IE - ASN1V_ngap_id_TraceActivation */
            case ASN1V_ngap_id_TraceActivation:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode ASN1V_ngap_id_TraceActivation ");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_12,
                            (void *)&p_local_handover_request->\
                            trace_activation))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE - ASN1V_ngap_id_TraceActivation failed ");
                }
                else
                {
                   p_local_handover_request->bitmask |=
                        NGAP_HANDOVER_REQUEST_TRACE_ACIVATION_PRESENT; 
                }
                break;
            }

            /*IE - ASN1V_ngap_id_MaskedIMEISV */
            case ASN1V_ngap_id_MaskedIMEISV:
            {

                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode ASN1V_ngap_id_MaskedIMEISV ");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_13,
                            (void *)&p_local_handover_request->\
                            masked_imeisv))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE - ASN1V_ngap_id_MaskedIMEISV failed ");
                }
                else
                {
                    p_local_handover_request->bitmask |=
                        NGAP_HANDOVER_REQUEST_MASKED_IMEISV_PRESENT; 
                }
                break;
            }
            
            /* IE - ASN1V_ngap_id_SourceToTarget_TransparentContainer */
            case ASN1V_ngap_id_SourceToTarget_TransparentContainer:
            {

                RRC_NGAP_TRACE
                    (NGAP_DETAILEDALL,
                     "Decode IE - ASN1V_ngap_id_SourceToTarget_TransparentContainer");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_14,
                            (void *)&p_local_handover_request->\
                            src_to_trg_transparent_container))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_SourceToTarget_TransparentContainer Failed ");
                }
                break;
            }
            
            /* IE - ASN1V_ngap_id_MobilityRestrictionList */
            case ASN1V_ngap_id_MobilityRestrictionList:
            {

                RRC_NGAP_TRACE
                    (NGAP_DETAILEDALL,
                     "Decode IE - ASN1V_ngap_id_MobilityRestrictionList");

                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_15,
                            (void *)&p_local_handover_request->\
                            mobility_restriction_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_MobilityRestrictionList Failed ");
                }
                else 
                {
                    p_local_handover_request->bitmask |= 
                        NGAP_HANDOVER_REQUEST_MOBILITY_RESTRICTION_LIST_PRESENT;
                }
                break;
            }
            /* Decode ASN1V_ngap_id_LocationReportingRequestType */
            case ASN1V_ngap_id_LocationReportingRequestType:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode IE- ASN1V_ngap_id_LocationReportingRequestType");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_16,
                            (void *)&p_local_handover_request->\
                            location_reposrting_req_type))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE - ASN1V_ngap_id_LocationReportingRequestType Type validation failed");
                }
                else
                {
                    p_local_handover_request->bitmask |=
                        NGAP_HANDOVER_REQUEST_LOCATION_REPORTING_REQ_TYPE_PRESENT;
                }

                break;
            }
            /* Decode ASN1V_ngap_id_RRCInactiveTransitionReportRequest */
            case ASN1V_ngap_id_RRCInactiveTransitionReportRequest:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode IE- ASN1V_ngap_id_RRCInactiveTransitionReportRequest");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_17,
                            (void *)&p_local_handover_request->\
                            rrc_inactive_transition_report_req_t))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE - ASN1V_ngap_id_RRCInactiveTransitionReportRequest Type validation failed");
                }
                else
                {
                    p_local_handover_request->bitmask |=
                       NGAP_HANDOVER_REQUEST_RRC_INACTIVE_TRANSITION_REPORT_REQ_PRESENT;
                }

                break;
            }

            /* Decode IE - GUAMI */
            case ASN1V_ngap_id_GUAMI:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE - GUAMI");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                             &message_map,
                             ie_index,
                             p_protocolIE_elem->id,
                             (void *)p_protocolIE_elem->value.\
                                u._ngap_HandoverRequestIEs_18,
                             (void *)&p_local_handover_request->guami))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "IE - GUAMI Validation failed");
                }
                break;
            }

            /* Decode ASN1V_ngap_id_RedirectionVoiceFallback */
            case ASN1V_ngap_id_RedirectionVoiceFallback:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode IE- ASN1V_ngap_id_RedirectionVoiceFallback");
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)&p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_19,
                            (void *)&p_local_handover_request->\
                            redirection_voice_fallback))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE - ASN1V_ngap_id_RedirectionVoiceFallback validation failed");
                }
                else
                {
                   p_local_handover_request->bitmask |=
                      NGAP_HANDOVER_REQUEST_REDIRECTION_VOICE_FALLBACK_PRESENT;
                }

                break;
            }
            /*Decode IE ASN1V_ngap_id_CNAssistedRANTuning */
            case ASN1V_ngap_id_CNAssistedRANTuning:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                "Decode IE - ASN1V_ngap_id_CNAssistedRANTuning");
                
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_protocolIE_elem->id,
                            (void *)p_protocolIE_elem->value.\
                            u._ngap_HandoverRequestIEs_20,
                            (void *)&p_local_handover_request->\
                            cn_assisted_ran_tuning))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                    "IE3 - ASN1V_ngap_id_CNAssistedRANTuning validation failed");
                }
                else
                {
                    p_local_handover_request->bitmask |=
                       NGAP_HANDOVER_CN_ASSISTED_RAN_TUNING_PRESENT;
                }

                break;
            }

            default:
            {

                RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Invalid protocol IE ID : %u", p_protocolIE_elem->id);

                /* Add IE to list of Error IEs*/
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_protocolIE_elem->criticality,
                        p_protocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
                break;
            }
        }//end switch

        p_node = p_node->next;

     }//end of for

    /*Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map(
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_HandoverResourceAllocation,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode Handover Request\n");
        ret_val = NGAP_FAILURE;
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}


/******************************************************************************
 *  Function Name:  
 *  
 *  Inputs:
 *  
 *  Outputs:
 *    
 *  Description:
 *        
 *  Returns:
 * ***************************************************************************/
ngap_map_updation_const_et  validate_and_fill_CoreNetworkAssistanceInformationForInactive
(
    ngap_CoreNetworkAssistanceInformationForInactive *p_value,
    ngap_core_network_assistance_info_for_inactive_t *p_local
)
{
    ngap_map_updation_const_et  result = OCCURANCE;
    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    /*Decode ue identity index value */
    if (p_value->uEIdentityIndexValue.t == T_ngap_UEIdentityIndexValue_indexLength10 )
    {
        NGAP_MEMCPY
            (
             p_local->ue_identity_index_value,
             p_value->uEIdentityIndexValue.u.indexLength10->data,
             NGAP_UE_IDENTITY_INDEX_VALUE_OCTET_SIZE
            );
    }
    /*Decode ue specific drx Present */
    if (NGAP_TRUE ==
            p_value->m.uESpecificDRXPresent)
    {
        p_local->bitmask |= 
                NGAP_CORE_NETWORK_ASSISTANCE_INFO_UE_SPECIFIC_DRX_PRESENT;
        /*COVERITY FIX*/
        p_local->paging_drx_event_id =
            (default_paging_drx_et)p_value->uESpecificDRX;
        /*COVERITY FIX*/
    }

    /*Decode IE periodicRegistrationUpdateTimer */
    
    NGAP_MEMCPY
        (
         p_local->periodic_registration_update_timer,
         p_value->periodicRegistrationUpdateTimer.data,
         NGAP_PERIODIC_REGISTRATION_UPDATE_TIMER_OCTET_SIZE
        );
    
    /*Decode IE mICOModeIndication */

    if (NGAP_TRUE == p_value->m.mICOModeIndicationPresent )
    {
        p_local->bitmask |=
            NGAP_CORE_NETWORK_ASSISTANCE_INFO_MICO_MODE_INDICATION_PRESENT;

        /*COVERITY FIX*/
        p_local->mico_mode_indication_event_id =
            (ngap_mico_mode_indication_et)p_value->mICOModeIndication;
        /*COVERITY FIX*/
    }

    /*Decode IE tAIListForInactive */

        result =   validate_and_fill_tai_list_for_incative
                    (
                        &p_value->tAIListForInactive,
                        &p_local->tai_list_for_inactive
                    );


    /*Decode IE Expected ue behaviour present */

    if (NGAP_TRUE == p_value->m.expectedUEBehaviourPresent )
    {
        p_local->bitmask |=
            NGAP_CORE_NETWORK_ASSISTANCE_INFO_EXPECTED_UE_BEHAVIOUR_PRESENT;

            result = validate_and_fill_expexted_ue_behaviour
                    (
                        &p_local->expected_ue_behaviour,
                        &p_value->expectedUEBehaviour
                    );
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/*****************************************************************************************
 * validate_and_fill_expexted_ue_behaviour
 * ***************************************************************************************/

ngap_map_updation_const_et validate_and_fill_expexted_ue_behaviour
(
    ngap_expected_ue_behaviour_t *p_local,
    ngap_ExpectedUEBehaviour     *p_value
)
{
    ngap_map_updation_const_et      result = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
    
    /*Decode IE expectedUEActivityBehaviour */
    if (NGAP_TRUE == p_value->m.expectedUEActivityBehaviourPresent )
    {
        p_local->bitmask |=
            NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT;

        /*Decoding IE expectedActivityPeriodPresent */
        if (NGAP_TRUE == p_value->expectedUEActivityBehaviour.\
            m.expectedActivityPeriodPresent )
        {
            p_local->expected_ue_activity_behaviour.bitmask |=
                    NGAP_CNAssisted_EXPECTED_ACTIVITY_PERIOD_PRESENT;

            p_local->expected_ue_activity_behaviour.expected_activity_period =
                p_value->expectedUEActivityBehaviour.\
                expectedActivityPeriod;

        }
        /*Decoding IE expectedIdlePeriodPresent */
        if (NGAP_TRUE == p_value->expectedUEActivityBehaviour.\
            m.expectedIdlePeriodPresent )
        {

            p_local->expected_ue_activity_behaviour.bitmask |=
                    NGAP_CNAssisted_EXPECTED_IDLE_PERIOD_PRESENT;

            p_local->expected_ue_activity_behaviour.\
            expected_idle_period =
                p_value->expectedUEActivityBehaviour.\
                expectedIdlePeriod;

        }
        /*Decoding IE sourceOfUEActivityBehaviourInformationPresent */
        if (NGAP_TRUE == p_value->expectedUEActivityBehaviour.\
            m.sourceOfUEActivityBehaviourInformationPresent )
        {
            p_local->expected_ue_activity_behaviour.bitmask |=
              NGAP_CNAssisted_EXPECTED_SOURCE_OF_UE_ACTIVITY_BEHAVIOUR_INFORMATION;

            /*COVERITY FIX*/
            p_local->expected_ue_activity_behaviour.\
                source_of_ue_activity_behaviour_info =
                (ngap_source_of_ue_activity_behaviour_info_et)\
                p_value->expectedUEActivityBehaviour.\
                sourceOfUEActivityBehaviourInformation;
            /*COVERITY FIX*/

        }

    }

    /*Decode IE expectedHOInterval */

    if (NGAP_TRUE == p_value->m.expectedHOIntervalPresent )
    {
        p_local->bitmask |=
            NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_HO_INTERVAL_PRESENT;

        /* COVERITY FIX */
        p_local->expected_ho_interval_event_id =
            (ngap_expected_ho_interval_et)p_value->expectedHOInterval;
        /*COVERITY FIX*/
    }

    /* Decode IE expectedUEMobility */
    if (NGAP_TRUE == p_value->m.expectedUEMobilityPresent )
    {
        p_local->bitmask |=
            NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_MOBILITY_PRESENT;
        /*COVERITY FIX*/
        p_local->expected_ue_mobility_event_id =
            (ngap_expected_ue_mobility_et)p_value->expectedUEMobility;
        /*COVERITY FIX*/

    }

    /*Decode IE expectedUEMovingTrajectory */

    if (NGAP_TRUE == p_value->m.expectedUEMovingTrajectoryPresent )
    {
        p_local->bitmask |=
            NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_MOVING_TRAJECTORY;
        
            if(OCCURANCE != ngap_decode_expected_moving_trajectory(
                
                &p_value->expectedUEMovingTrajectory,
                &p_local->expected_moving_trajectory
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode Expected UE moving Trajectory");
                result = INVALID_VALUE;
                return result;
            }

    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/*********************************************************************
 * validate_and_fill_tai_list_for_incative
 * ******************************************************************/
ngap_map_updation_const_et  validate_and_fill_tai_list_for_incative
(
    ngap_TAIListForInactive       *p_value, /* ASN Buffer */ 
    ngap_tai_list_for_inactive_t  *p_local  /* Local Buffer */
)
{

    ngap_TAIListForInactiveItem   *p_value_tai_list_item;
    UInt16                      count_it         = NGAP_ZERO;
    OSRTDListNode               *tai_list_node   = p_value->head; 
    ngap_map_updation_const_et  result           = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    do
    {    

        if (p_value->count == NGAP_ZERO)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "TAI List for Paging is not present.");
        }
        else if(NGAP_MAX_NO_OF_TAI_FOR_INACTIVE < p_value->count)
        {
            result = INVALID_VALUE;
            break;
        }
        else
        {

            p_local->count = p_value->count; 

            while(tai_list_node != NGAP_P_NULL)
            {
                p_value_tai_list_item = 
                    (ngap_TAIListForInactiveItem*)tai_list_node->data;

                /*Decode TAI*/
                if(NGAP_PLMN_IDENTITY_MAX_BYTES <
                    p_value_tai_list_item->tAI.pLMNIdentity.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }
                else
                {
                    NGAP_MEMCPY
                    (
                        p_local->tai_list_for_rrc_inactive_item[count_it].tai.\
                            plmn_identity.plmn_id_bytes,
                        p_value_tai_list_item->tAI.pLMNIdentity.data,
                        p_value_tai_list_item->tAI.pLMNIdentity.numocts
                    );
                }

                if(NGAP_TAC_OCTET_SIZE < 
                        p_value_tai_list_item->tAI.tAC.numocts)
                {
                    result = INVALID_VALUE;
                    break;
                }

                NGAP_MEMCPY(p_local->tai_list_for_rrc_inactive_item[count_it].tai.tac.tac,
                        p_value_tai_list_item->tAI.tAC.data,
                        p_value_tai_list_item->tAI.tAC.numocts);

                tai_list_node = tai_list_node->next;
                count_it++;
            }    
        }

    }while(0);    

    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

/****************************************************************************************
 *              HANDOVER REQUEST SECURITY CONTEXT
 * **************************************************************************************/

ngap_map_updation_const_et validate_and_fill_security_context
 (
    ngap_SecurityContext *p_value,
    ngap_security_context_t *p_local
 )
{

    ngap_map_updation_const_et      result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    /*Decode  next hop changing count */
    p_local->next_hop_chaining_count =
            p_value->nextHopChainingCount;

            /*Decode Next Hoo NH */

     NGAP_MEMCPY
     (
     p_local->next_hop_nh.security_key,
     p_value->nextHopNH.data,
     NGAP_SECURITY_KEY_OCTET_SIZE
     );//HandOver_changes

     RRC_NGAP_UT_TRACE_EXIT();
     return result;
}

/****************************************************************************************
 *                  HANDOVER REQUEST TRACE ACTIVATION
 *
 * **************************************************************************************/
ngap_map_updation_const_et validate_and_fill_trace_activation
(
 ngap_TraceActivation     *p_value,
 ngap_trace_activation_t  *p_local
)
{

    ngap_map_updation_const_et      result = OCCURANCE;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);

    /*Decode NG RAN TRACE ID */
    NGAP_MEMCPY
        (
         p_local->ng_ran_trace_id,
         p_value->nGRANTraceID.data,
         NGAP_NG_RAN_TRACE_ID_OCTET_SIZE
        );

    /* Decode Interfaces to traces */
    NGAP_MEMCPY
        (
         p_local->interfaces_to_trace,
         p_value->interfacesToTrace.data,
         NGAP_INTERFACE_TO_TRACE_OCTET_SIZE
        );

    /*Decode Trace Depth event id */
/*COVERITY FIX*/
    p_local->trace_depth_event_id = 
        (ngap_trace_depth_et)p_value->traceDepth;
/*COVERITY FIX*/

    /*Decode IP Address */

    NGAP_MEMCPY
        (
         p_local->ip_address.transport_layer_address,
         p_value->traceCollectionEntityIPAddress.data,
         NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
        );

    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}

/****************************************************************************************
 *                               MOBILITY RESTRICTION LIST
 *
 * **************************************************************************************/
ngap_map_updation_const_et  validate_and_fill_mobility_restriction_list
(
 ngap_MobilityRestrictionList * p_value,
 ngap_mobility_restriction_list_t * p_local
 )
{
    UInt8                           i = NGAP_ZERO; 
    ngap_map_updation_const_et      result = OCCURANCE;
    
    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_value);
   
    /*Decode Serving PLMN */
    NGAP_MEMCPY
    (
    p_local->serving_plmn.plmn_id_bytes,
    p_value->servingPLMN.data,
    NGAP_PLMN_IDENTITY_MAX_BYTES
    );

    /*Decode equivalentPLMNsPresent */
    if (NGAP_TRUE == p_value->m.equivalentPLMNsPresent )
    {
        p_local->bitmask |=
            NGAP_MOBILITY_RESTRICTION_EQUIVALENT_PLMN_PRESENT;
        for (i = NGAP_ZERO; i< p_value->equivalentPLMNs.n ; i++ )    
        {
        p_local->equivalent_plmn.num_equivalent_plmn =
                p_value->equivalentPLMNs.n;/*Handover bug fixes*/
        
            NGAP_MEMCPY
                (
                 p_local->equivalent_plmn.equivalent_plmn[i].plmn_identity.plmn_id_bytes,
                 p_value->equivalentPLMNs.elem[i].data,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );/*Handover bug fixes*/
        }
    }
   
    /*Decode rATRestrictionsPresent */
    if (NGAP_TRUE == p_value->m.rATRestrictionsPresent )
    {
        p_local->bitmask |=
            NGAP_MOBILITY_RESTRICTION_RAT_RESTRICTION_PRESENT;
        if (
            OCCURANCE != ngap_decode_rat_restriction_information_list(
                           &p_local->rat_restriction,
                           &p_value->rATRestrictions)
            )
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode rat restriction information ");
                result = INVALID_VALUE;
                return result;
                
            }

    }

    /*Decode forbiddenAreaInformationPresent */
    if (NGAP_TRUE == p_value->m.forbiddenAreaInformationPresent )
    {
        p_local->bitmask |=
            NGAP_MOBILITY_RESTRICTION_FORBIDDEN_AREA_INFO_PRESENT;

        if (OCCURANCE != ngap_decode_forbidden_area_information(
                           &p_local->forbidden_area_information,
                           &p_value->forbiddenAreaInformation))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode forbidden area information ");
                result = INVALID_VALUE;
                return result; 

            }
    }

    /*Decode serviceAreaInformationPresent */
    if (NGAP_TRUE == p_value->m.serviceAreaInformationPresent )
    {
        p_local->bitmask |=
            NGAP_MOBILITY_SERVING_AREA_INFO_PRESENT;

        if (
            OCCURANCE != ngap_decode_service_area_information(
                           &p_local->service_area_information,
                           &p_value->serviceAreaInformation)
            )
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Could not decode service area information ");
                result = INVALID_VALUE;
                return result;

            }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}
/*****************************************************************************************
 *                  ngap_decode_rat_restriction_information_list
 * ***************************************************************************************/

ngap_map_updation_const_et ngap_decode_rat_restriction_information_list
(
    ngap_rat_restriction_t      *p_local,
    ngap_RATRestrictions        *p_value
)
{
     
   ngap_RATRestrictions_Item      *p_value_rat_restriction_item;

    UInt16                       count                              = NGAP_ZERO; 
    OSRTDListNode               *p_ho_rat_restriction_list_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                              = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ho_rat_restriction_list_node = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != p_ho_rat_restriction_list_node )
        {
            p_value_rat_restriction_item = 
                p_ho_rat_restriction_list_node->data;

            /*Decode pLMNIdentity */
            NGAP_MEMCPY
                (
                 p_local->rat_restriction_item[count].\
                 plmn_identity.plmn_id_bytes,
                 p_value_rat_restriction_item->pLMNIdentity.data,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );

            /*Decode rATRestrictionInformation */
            NGAP_MEMCPY
                (
                 p_local->rat_restriction_item[count].rat_restriction_information,/*Handover bug fixes*/
                 p_value_rat_restriction_item->rATRestrictionInformation.data,
                 NGAP_RAT_RESTRICTION_INFORMATION_SET_ID_OCTET_SIZE
                );


            p_ho_rat_restriction_list_node = 
                p_ho_rat_restriction_list_node->next;
        }
    }while(0);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;
}

ngap_map_updation_const_et ngap_decode_forbidden_area_information
(
   ngap_forbidden_area_information_t *p_local,
   ngap_ForbiddenAreaInformation     *p_value
)
{
     
    ngap_ForbiddenAreaInformation_Item      *p_value_forbidden_area_info_item;
    UInt8                        i =                                  NGAP_ZERO;
    UInt16                       count                              = NGAP_ZERO; 
    OSRTDListNode               *p_ho_forbidden_area_info_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                              = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ho_forbidden_area_info_node = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != p_ho_forbidden_area_info_node )
        {
            p_value_forbidden_area_info_item = 
                p_ho_forbidden_area_info_node->data;

            /*Decode pLMNIdentity */
            NGAP_MEMCPY
                (
                 p_local->forbidden_area_information_item[count].\
                 plmn_identity.plmn_id_bytes,
                 p_value_forbidden_area_info_item->pLMNIdentity.data,
                 NGAP_PLMN_IDENTITY_MAX_BYTES 
                );

            /*Decode forbidden tac */
            p_local->forbidden_area_information_item[count].forbidden_tac.count = 
                p_value_forbidden_area_info_item->forbiddenTACs.n; /*Handover bug fixes*/

            for (i= 0; i< p_value_forbidden_area_info_item->forbiddenTACs.n ;i++ )
            {

                 NGAP_MEMCPY
                (
                 p_local->forbidden_area_information_item[count].\
                 forbidden_tac.tac_t[i].tac,
                 p_value_forbidden_area_info_item->forbiddenTACs.elem[i].data,
                 NGAP_TAC_OCTET_SIZE
                );/*Handover bug fixes*/

            }


            p_ho_forbidden_area_info_node = 
                p_ho_forbidden_area_info_node->next;
        }
    }while(0);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}

/****************************************************************************************
 *                      ngap_decode_service_area_information
 * **************************************************************************************/

ngap_map_updation_const_et  ngap_decode_service_area_information
(
    ngap_service_area_information_t     *p_local,
    ngap_ServiceAreaInformation         *p_value
)
{

    ngap_ServiceAreaInformation_Item   *p_value_service_area_info_item;
    UInt8                        i                                  = NGAP_ZERO;
    UInt16                       count                              = NGAP_ZERO; 
    OSRTDListNode               *p_ho_service_area_info_node  = NGAP_P_NULL;
    ngap_map_updation_const_et  result                              = OCCURANCE; 

    RRC_NGAP_UT_TRACE_ENTER();
    NGAP_ASSERT(NGAP_P_NULL != p_value);

    p_ho_service_area_info_node = p_value->head;

    do
    {

        if(NGAP_ZERO == p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "List is NULL");
            result = INVALID_VALUE;
            break;
        }
        else if(NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE < p_value->count)
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Count exceeds maximum of 256");
            result = INVALID_VALUE;
            break;
        }
        p_local->count = p_value->count;

        while(NGAP_P_NULL != p_ho_service_area_info_node )
        {
            p_value_service_area_info_item = 
                p_ho_service_area_info_node->data;

            /*Decode pLMNIdentity */
            NGAP_MEMCPY
                (
                 p_local->service_area_information_item[count].\
                 plmn_identity.plmn_id_bytes,
                 p_value_service_area_info_item->pLMNIdentity.data,
                 NGAP_PLMN_IDENTITY_MAX_BYTES 
                );

            /*Decode Allowed tac */
            if (NGAP_TRUE == p_value_service_area_info_item->m.allowedTACsPresent )
            {
                p_local->service_area_information_item[count].bitmask |=
                    NGAP_SERVICE_AREA_INFO_ALLOWED_TAC_PRESENT;

                p_local->service_area_information_item[count].allowed_tac.count =
                    p_value_service_area_info_item->allowedTACs.n;/*Handover bug fixes*/

                for (i= 0; i< p_local->service_area_information_item[count].allowed_tac.count ;i++ )
                {
                    NGAP_MEMCPY
                        (
                         p_local->service_area_information_item[count].\
                         allowed_tac.tac_t[i].tac,
                         p_value_service_area_info_item->allowedTACs.elem[i].data,
                         NGAP_TAC_OCTET_SIZE
                        );/*Handover bug fixes*/

                }
            }
            /*Decode NOT  Allowed tac */
            if (NGAP_TRUE == p_value_service_area_info_item->m.notAllowedTACsPresent )
            {
                p_local->service_area_information_item[count].bitmask |=
                    NGAP_SERVICE_AREA_INFO_NOT_ALLOWED_TAC_PRESENT;

                    p_local->service_area_information_item[count].not_allowed_tac.count =
                        p_value_service_area_info_item->notAllowedTACs.n;/*Handover bug fixes*/

                for (i= 0; i< p_local->service_area_information_item[count].not_allowed_tac.count ;i++ )
                {
                    NGAP_MEMCPY
                        (
                         p_local->service_area_information_item[count].\
                         not_allowed_tac.tac_t[i].tac,
                         p_value_service_area_info_item->notAllowedTACs.elem[i].data,
                         NGAP_TAC_OCTET_SIZE
                        );/*Handover bug fixes*/

                }
            }
            p_ho_service_area_info_node = 
                p_ho_service_area_info_node->next;
        }
    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return result;

}

/*HandOver_code_changes_end*/

/******************************************************************************
 * Function Name    : ngap_decode_ng_amf_config_update
 * Input            : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Output           : amf_config_update_t - Information from which local buffer will be filled
 * Returns          : NGAP_SUCCESS - ASN decoding was successful
 *                    NGAP_FAILURE - ASN decoding was not successful
 * DESCRIPTION	    : This function decodes AMF CONFIG UPDATE ASN message.
 *****************************************************************************/
ngap_return_et ngap_decode_ng_amf_config_update
(
    UInt8			     *p_asn_msg,	         /* Input - ASN Encoded Buffer */
    UInt16               asn_msg_len,	         /* Input - ASN Encoded Buffer Length */
    amf_config_update_t  *p_ng_amf_config_update /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;
    NGAP_MEMSET(p_ng_amf_config_update, NGAP_ZERO, sizeof(amf_config_update_t));

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        /*  Silently Dropping Received ASN Mesage.
            Not Sending Error Indication with Transfer Syntax Error 
            because ASN Init failure doesn't match the same.
            */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_NGAP_PDU));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of Amf Config Update  Failed");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = ng_amf_config_update_internal_dec(&asn1_ctx,
                ngap_pdu.u.initiatingMessage->value.u.aMFConfigurationUpdate,
                p_ng_amf_config_update);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;



}
ngap_return_et ng_amf_config_update_internal_dec
(
 OSCTXT                      *p_asn1_ctx,               /* Input: ASN1 Context to be used */
 ngap_AMFConfigurationUpdate *p_asn_amf_config_update,  /* Input: Received ASN Buffer */
 amf_config_update_t         *p_local_amf_config_update /* Output: Local Message Structure */
)
{
    OSRTDListNode                                    *p_node              = NGAP_P_NULL;
    ngap_AMFConfigurationUpdate_protocolIEs_element  *p_prootocolIE_elem  = NGAP_P_NULL;
    UInt8                                             ie_index            = NGAP_ZERO;
    UInt16                                            ie_list_index       = NGAP_ZERO;
    ngap_return_et                                    ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                             send_err_ind;
    ngap_criticality_diagnostics_ie_list_t            ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_amf_config_update);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {7, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_AMFName, ngap_optional, ngap_reject, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_ServedGUAMIList, ngap_mandatory, ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_RelativeAMFCapacity, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {3, ASN1V_ngap_id_PLMNSupportList, ngap_mandatory, ngap_reject,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {4, ASN1V_ngap_id_AMF_TNLAssociationToAddList, ngap_mandatory, 
            ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
        },
        {5, ASN1V_ngap_id_AMF_TNLAssociationToRemoveList, ngap_mandatory, 
            ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
        },
        {6, ASN1V_ngap_id_AMF_TNLAssociationToUpdateList, ngap_mandatory, 
            ngap_ignore, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO
        }
        }
    };

    p_local_amf_config_update->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_amf_config_update->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_amf_config_update->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_AMFConfigurationUpdate_protocolIEs_element*)p_node->data; //check

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }
        p_prootocolIE_elem = 
            (ngap_AMFConfigurationUpdate_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        { 
            /* IE1 */
            case  ASN1V_ngap_id_AMFName:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE  ASN1V_ngap_id_AMFName");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_1,
                            (void *)&p_local_amf_config_update->amf_name))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 -  ASN1V_ngap_id_AMFName Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_AMF_NAME;
                }
                break;
            }/* End of IE1 */   

            /* IE2 */
            case ASN1V_ngap_id_ServedGUAMIList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_ServedGUAMIList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_2,
                            (void *)&p_local_amf_config_update->served_guami_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - A2SN1V_ngap_id_ServedGUAMIList Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_SERVED_GUAMI_LIST;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_RelativeAMFCapacity:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_RelativeAMFCapacity");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_3,
                            (void *)&p_local_amf_config_update->relative_amf_capacity))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE3 - ASN1V_ngap_id_RelativeAMFCapacity Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_RELATIVE_AMF_CAPACITY;
                }

                break;
            } /* End of IE3 */

            /* IE4 */
            case ASN1V_ngap_id_PLMNSupportList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_PLMNSupportList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_4,
                            (void *)&p_local_amf_config_update->plmn_support_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE4 - ASN1V_ngap_id_PLMNSupportList Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_PLMN_SUPPORT_LIST;
                }
                break;
            } /* End of IE4 */

            /* IE5 */
            case ASN1V_ngap_id_AMF_TNLAssociationToAddList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_TNLAssociationToAddList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_5,
                            (void *)&p_local_amf_config_update->association_add_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE5 - ASN1V_ngap_id_AMF_TNLAssociationToAddList Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_ADD_LIST;
                }

                break;
            } /* End of IE5 */

            /* IE6 */
            case ASN1V_ngap_id_AMF_TNLAssociationToRemoveList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_TNLAssociationToRemoveList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_6,
                            (void *)&p_local_amf_config_update->association_remove_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE6 - ASN1V_ngap_id_AMF_TNLAssociationToRemoveList Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_REMOVE_LIST;
                }
                break;
            } /* End of IE6 */

            /* IE7 */
            case ASN1V_ngap_id_AMF_TNLAssociationToUpdateList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, 
                        "Decode IE ASN1V_ngap_id_AMF_TNLAssociationToUpdateList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateIEs_7,
                            (void *)&p_local_amf_config_update->association_update_list))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "IE7 - ASN1V_ngap_id_AMF_TNLAssociationToUpdateList Validation failed");
                }
                else
                {
                    p_local_amf_config_update->bitmask |= 
                        AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_UPDATE_LIST;
                }
                break;
            } /* End of IE7 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        }/* end of switch*/

        p_node = p_node->next;

    }/*end of for*/

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_AMFConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode AMF Configuration Update");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/***********************************************************************************************************
 * Function Name	: ngap_decode_amf_config_update_ack
 * Inputs         	: p_ng_amf_config_update_ack - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function decodes AMF CONFIG UPDATE ACKNOWLEDGE  ASN message from the information 
 *				      provided in p_ng_amf_config_update_ack
 ***********************************************************************************************************/
ngap_return_et ngap_decode_amf_config_update_ack
(
    UInt8			            *p_asn_msg,	                /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	            /* Input - ASN Encoded Buffer Length */
    amf_config_update_ack_t	    *p_amf_config_update_ack    /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for AMF CONFIG UPDATE ACK");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of AMF CONFIG UPDATE ACK");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = amf_config_update_ack_internal_dec(&asn1_ctx,
                ngap_pdu.u.successfulOutcome->value.u.\
                aMFConfigurationUpdate,
                p_amf_config_update_ack);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et amf_config_update_ack_internal_dec
(
    OSCTXT			                       *p_asn1_ctx,                    /* Input: ASN1 Context to be used */
    ngap_AMFConfigurationUpdateAcknowledge *p_asn_amf_config_update_ack,   /* Input: Received ASN Buffer */
    amf_config_update_ack_t                *p_local_amf_config_update_ack  /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_AMFConfigurationUpdateAcknowledge_protocolIEs_element
        *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_amf_config_update_ack);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_AMF_TNLAssociationSetupList, ngap_optional, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_AMF_TNLAssociationFailedToSetupList, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_amf_config_update_ack->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_amf_config_update_ack->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_amf_config_update_ack->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_AMFConfigurationUpdateAcknowledge_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE 1 */
            case ASN1V_ngap_id_AMF_TNLAssociationSetupList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_AMF_TNLAssociationSetupList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateAcknowledgeIEs_1,
                            (void *)&p_local_amf_config_update_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_AMF_TNLAssociationSetupList Validation failed");
                }
                else
                {
                    p_local_amf_config_update_ack->bitmask |= 
                        AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_SETUP_PRESENT;
                }
                break;
            }
            /* IE 2 */
            case ASN1V_ngap_id_AMF_TNLAssociationFailedToSetupList:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_AMF_TNLAssociationFailedToSetupList");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateAcknowledgeIEs_2,
                            (void *)&p_local_amf_config_update_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_AMF_TNLAssociationFailedToSetupList Validation failed");
                }
                else
                {
                    p_local_amf_config_update_ack->bitmask |= 
                        AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_FAILED_TO_SETUP_PRESENT;
                }

                break;            
            }
            /* IE 3*/
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateAcknowledgeIEs_3,
                            (void *)&p_local_amf_config_update_ack->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_amf_config_update_ack->bitmask |= 
                        AMF_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT;
                }
                break;
            } /* End of IE 3 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_RANConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode RAN CONFIG UPDATE ACK");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}

/*******************************************************************************************************
* Function Name	    : ngap_decode_amf_config_update_failure
* Inputs         	: p_ng_amf_config_update_fail - Information from which Asn message will be prepared
* Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
*                     p_asn_msg_len - Pointer to the length of ASN encoded msg
* Returns         	: NGAP_SUCCESS - ASN encoding was successful
*                	  NGAP_FAILURE - ASN encoding was not successful
* DESCRIPTION	    : This function decodes AMF CONFIG UPDATE FAILURE ASN message from the information 
*				      provided in p_ng_amf_config_update_fail
********************************************************************************************************/
ngap_return_et ngap_decode_amf_config_update_failure
(
    UInt8			            *p_asn_msg,	                   /* Input - ASN Encoded Buffer */
    UInt16                       asn_msg_len,	               /* Input - ASN Encoded Buffer Length */
    amf_config_update_failure_t	*p_amf_config_update_failure   /* Output - Local Buffer */
)
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_return_et          	response;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, (OSUINT8 *)p_asn_msg, asn_msg_len, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for AMF CONFIG UDPADE FAILURE");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PD_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Decoding of AMF CONFIG UPDATE Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
        }

        /* Decode message */
        response = amf_config_update_failure_internal_dec(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome->value.u.aMFConfigurationUpdate,
                p_amf_config_update_failure);

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et amf_config_update_failure_internal_dec
(
    OSCTXT			                   *p_asn1_ctx,                        /* Input: ASN1 Context to be used */
    ngap_AMFConfigurationUpdateFailure *p_asn_amf_config_update_failure,   /* Input: Received ASN Buffer */
    amf_config_update_failure_t        *p_local_amf_config_update_failure  /* Output: Local Message Structure */
)
{
    OSRTDListNode                           *p_node             = NGAP_P_NULL;
    ngap_AMFConfigurationUpdateFailure_protocolIEs_element 
        *p_prootocolIE_elem = NGAP_P_NULL;
    UInt8                                   ie_index            = NGAP_ZERO;
    UInt16                                  ie_list_index       = NGAP_ZERO;
    ngap_return_et                          ret_val             = NGAP_SUCCESS;
    ngap_error_ind_bool_t                   send_err_ind;
    ngap_criticality_diagnostics_ie_list_t  ie_list;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_asn_amf_config_update_failure);
    NGAP_ASSERT(NGAP_P_NULL != p_asn1_ctx);

    NGAP_MEMSET(&send_err_ind, NGAP_ZERO, sizeof(ngap_error_ind_bool_t));
    NGAP_MEMSET(&ie_list, NGAP_ZERO,sizeof(ngap_criticality_diagnostics_ie_list_t));

    /* Message map defining ID, Presence and Criticality for each IE*/
    ngap_message_data_t message_map = 
    {3, NGAP_FALSE, NGAP_FALSE, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO,
        {{0, ASN1V_ngap_id_Cause, ngap_mandatory, ngap_ignore, 
             NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {1, ASN1V_ngap_id_TimeToWait, ngap_optional, ngap_ignore,
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO},
        {2, ASN1V_ngap_id_CriticalityDiagnostics, ngap_optional, ngap_ignore, 
            NGAP_ZERO, NGAP_ZERO, NGAP_ZERO, NGAP_ZERO}
        }
    };

    p_local_amf_config_update_failure->bitmask = 0x00;

    /* Initialise pnode with first IE */
    p_node = p_asn_amf_config_update_failure->protocolIEs.head;

    if(NGAP_P_NULL == p_node)
    {
        RRC_NGAP_TRACE(NGAP_ERROR ,"First node is NULL");

        return NGAP_FAILURE;
    }

    for(ie_index = NGAP_ZERO; ie_index < 
            p_asn_amf_config_update_failure->protocolIEs.count; ie_index++)
    {
        if(NGAP_P_NULL == p_node)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Node %u is NULL", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        p_prootocolIE_elem = 
            (ngap_AMFConfigurationUpdateFailure_protocolIEs_element*)p_node->data;

        if(NGAP_P_NULL == p_prootocolIE_elem)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "IE %u does not exist", ie_index);

            ret_val = NGAP_FAILURE;
            break;
        }

        switch(p_prootocolIE_elem->id)
        {
            /* IE1 */
            case ASN1V_ngap_id_Cause:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL, "Decode IE ASN1V_ngap_id_Cause");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateFailureIEs_1,
                            (void *)&p_local_amf_config_update_failure->\
                            choice_cause_group))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE1 - ASN1V_ngap_id_Cause Validation failed");
                }
                break;
            } /* End of IE1 */

            /* IE2 */
            case ASN1V_ngap_id_TimeToWait:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,"Decode IE ASN1V_ngap_id_TimeToWait");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)&p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateFailureIEs_2,
                            (void *)&p_local_amf_config_update_failure->\
                            time_to_wait_event_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE2 - ASN1V_ngap_id_TimeToWait Validation failed");
                }
                else
                {
                    p_local_amf_config_update_failure->bitmask |= 
                        AMF_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT;
                }
                break;
            }/* End of IE2 */

            /* IE3 */
            case ASN1V_ngap_id_CriticalityDiagnostics:
            {
                RRC_NGAP_TRACE(NGAP_DETAILEDALL,
                        "Decode IE ASN1V_ngap_id_CriticalityDiagnostics");

                /* validate_and_fill IE */
                if(NGAP_FAILURE == validate_and_fill_ie_value(
                            &message_map,
                            ie_index,
                            p_prootocolIE_elem->id,
                            (void *)p_prootocolIE_elem->value.\
                            u._ngap_AMFConfigurationUpdateFailureIEs_3,
                            (void *)&p_local_amf_config_update_failure->\
                            criticality_diagnostics))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "IE3 - ASN1V_ngap_id_CriticalityDiagnostics Validation failed");
                }
                else
                {
                    p_local_amf_config_update_failure->bitmask |= 
                        AMF_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT;
                }
                break;
            } /* End of IE3 */

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Invalid Protocol IE ID : %u", p_prootocolIE_elem->id);

                /* Add IE to list of Error IEs */
                ngap_add_to_err_ind_ie_list(&ie_list,
                        p_prootocolIE_elem->criticality,
                        p_prootocolIE_elem->id,
                        &ie_list_index,
                        &send_err_ind,
                        NGAP_FALSE);
            }
        } /* End of switch */

        p_node = p_node->next;

    }/* End of for */

    /* Parse the map for Error Indication */
    if(NGAP_FAILURE == parse_ngap_message_map( 
                p_asn1_ctx,
                &message_map,
                &ie_list,
                &ie_list_index,
                &send_err_ind,
                ASN1V_ngap_id_AMFConfigurationUpdate,
                (ngap_error_indication_t *)NGAP_P_NULL))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Failed to decode AMF CONFIGURATION FAILURE");
        ret_val = NGAP_FAILURE;
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return ret_val;
}
