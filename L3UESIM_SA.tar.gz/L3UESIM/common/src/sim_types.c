/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the functions definations.
 * *
 * ***************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "CUnit/Basic.h"
#include "sim_types.h"

/******************************************************************************
*   FUNCTION NAME: gnb_msg_mem_get
*   INPUT        : gnb_size_t size
*   OUTPUT       : None
*   RETURNS      : Pointer to memory buffer or NULL in case of failure
*   DESCRIPTION  : Function is used for messages management purposes.
******************************************************************************/
void*
gnb_msg_mem_get
(
    gnb_size_t size /* Size of buffer which will be allocated */
)
{
    void *p_buf = NULL;
    //int err = 0;

    p_buf = malloc(size);

  return p_buf;
}

/******************************************************************************
*   FUNCTION NAME: gnb_msg_mem_free
*   INPUT        : void *p_buffer
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : This function frees memory buffer allocated in pool.
*                  Function is used for messages management purposes.
******************************************************************************/
void
gnb_msg_mem_free
(
    void *p_buffer /* Pointer to buffer which will be freed */
)
{
    free(p_buffer);
}

/******************************************************************************
 *   FUNCTION NAME: gnb_cp_trace
 *   INPUT        : void *p_buffer
 *   OUTPUT       : None
 *   RETURNS      : None
 *   DESCRIPTION  : This function frees memory buffer using direct OS call free
 *                  routine.
 *
 ******************************************************************************/
void gnb_cp_trace(char* fileName,char* funcName,unsigned int lineNo,
        unsigned char logLevel,char* str,...)
{
 return;
}

