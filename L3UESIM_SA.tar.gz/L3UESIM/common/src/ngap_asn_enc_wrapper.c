/******************************************************************************
 *
 * ARICENT - ngap_asn_enc_wrappers.c
 *
 * Copyright (C) 2015 Aricent Inc . All Rights Reserved.
 *
 * File Name       : ngap_asn_enc_wrappers.c
 * File Description: 
 ***************************************************************************/
#include "ngap_asn_enc_wrapper.h"
#include "ngap_asn_common_wrapper.h"
#include "ngap_types.h"
#include "ngap_utils.h"
#include "ngap_intf_mgmnt.h"
#include "ngap_tracing.h"
#ifndef AMF_SIM_TESTING_ENABLE
#include "rrc_logging.h"
#else
#include "rrc_common_utils.h"
#endif 

rrc_return_et rrc_encode_ue_radio_access_capability_info
(
    ngap_ue_radio_capability_info_indication_t  *p_ue_radio_cap_info_ind,   /* INTPUT- */
    UInt8                                       *p_asn_msg,                 /* OUTPUT - */
    UInt16                                      *p_asn_msg_len              /* OUTPUT - */
)
{
	rrc_return_et                               result                     = RRC_SUCCESS;
	OSCTXT                                      asn1_ctx;
	nr_rrc_UERadioAccessCapabilityInformation   *p_ue_radio_access_cap_info = NGAP_P_NULL;

	RRC_NGAP_UT_TRACE_ENTER();

	/* Init ASN.1 context */
	if(RT_OK != rtInitContext(&asn1_ctx))
	{
		//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
		//        p_uecc_gb_context->facility_name,
		//        GNB_WARNING, "ASN Context Initialization Failed");
		result = RRC_FAILURE;
		return result;
	}
	do
	{
		p_ue_radio_access_cap_info = rtxMemAllocTypeZ(&asn1_ctx, \
				nr_rrc_UERadioAccessCapabilityInformation);

		if(NGAP_P_NULL == p_ue_radio_access_cap_info)
		{
			//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
			//        p_uecc_gb_context->facility_name,
			//        GNB_ERROR, "Memory allocation failed");

			result = RRC_FAILURE;
			break;
		}

		/* Encode criticalExtensions */
		p_ue_radio_access_cap_info->criticalExtensions.t = 
			T_nr_rrc_UERadioAccessCapabilityInformation_criticalExtensions_c1;

		p_ue_radio_access_cap_info->criticalExtensions.u.c1 = 
			rtxMemAllocTypeZ(&asn1_ctx, nr_rrc_UERadioAccessCapabilityInformation_criticalExtensions_c1);

		if(NGAP_P_NULL == p_ue_radio_access_cap_info->criticalExtensions.u.c1)
		{
			//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
			//        p_uecc_gb_context->facility_name,
			//        GNB_ERROR, "SYSTEM MEMORY FAILED");

			result = RRC_FAILURE;
			break;
		}

		p_ue_radio_access_cap_info->criticalExtensions.u.c1->t =
			T_nr_rrc_UERadioAccessCapabilityInformation_criticalExtensions_c1_ueRadioAccessCapabilityInformation;

		p_ue_radio_access_cap_info->criticalExtensions.u.c1->u.ueRadioAccessCapabilityInformation =
			rtxMemAllocTypeZ(&asn1_ctx, nr_rrc_UERadioAccessCapabilityInformation_IEs);

		if(NGAP_P_NULL == p_ue_radio_access_cap_info->\
				criticalExtensions.u.c1->u.ueRadioAccessCapabilityInformation)
		{
			//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
			//        p_uecc_gb_context->facility_name,
			//        GNB_ERROR, "SYSTEM MEMORY FAILED");

			result = RRC_FAILURE;
			break;
		}

		/* Encode all IEs */
		p_ue_radio_access_cap_info->criticalExtensions.u.c1->\
			u.ueRadioAccessCapabilityInformation->ue_RadioAccessCapabilityInfo.data =
                (OSOCTET *)rtxMemAllocZ(&asn1_ctx,p_ue_radio_cap_info_ind->ue_radio_capability.ue_radio_capability.num_string_len);

        NGAP_MEMCPY
            (
             (void *)p_ue_radio_access_cap_info->criticalExtensions.u.c1->\
             u.ueRadioAccessCapabilityInformation->ue_RadioAccessCapabilityInfo.data,
             p_ue_radio_cap_info_ind->ue_radio_capability.ue_radio_capability.string_data,
             p_ue_radio_cap_info_ind->ue_radio_capability.ue_radio_capability.num_string_len
            );

		p_ue_radio_access_cap_info->criticalExtensions.u.c1->\
			u.ueRadioAccessCapabilityInformation->ue_RadioAccessCapabilityInfo.numocts =
			p_ue_radio_cap_info_ind->ue_radio_capability.ue_radio_capability.num_string_len;

		/* ASN Encode Message */
		if (RT_OK != pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, 
					ASN_RRC_BUF_TYPE))
		{
			//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
			//        p_uecc_gb_context->facility_name, GNB_ERROR,
			//        "pu_setBuffer failed",__FUNCTION__);

			result = RRC_FAILURE;
			break;
		}

		if(RRC_ZERO != asn1PE_nr_rrc_UERadioAccessCapabilityInformation(&asn1_ctx, 
					p_ue_radio_access_cap_info))
		{
			rtxErrPrint(&asn1_ctx);
			//RRC_UECC_TRACE(p_uecc_gb_context->context_index,
			//        p_uecc_gb_context->facility_name,
			//        GNB_ERROR, "Encoding of UE radio access capability information Failed");
			result = RRC_FAILURE;
			break;
		}
		else
		{
			/* Print the ASN Encoded UE Capability InformationPDU */
			asn1Print_nr_rrc_UERadioAccessCapabilityInformation("UE Radio Access Capability Information", 
					p_ue_radio_access_cap_info);

			*p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
			result = RRC_SUCCESS;
		}

	}while(0);

	rtFreeContext(&asn1_ctx);

	RRC_NGAP_UT_TRACE_EXIT();
	return result;
}

/******************************************************************************
 * Function Name    : ngap_encode_ng_setup_req
 * Inputs           : p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NG SETUP REQUEST ASN message from the
 *				      information provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_encode_ng_setup_req
(
 ngap_setup_request_t	*p_ng_setup_req, /* Input - Local Buffer */
 UInt8                   *p_asn_msg, 	 /* Output - ASN Encoded Buffer */
 UInt16                  *p_asn_msg_len	 /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_NGSetupRequest     *p_ngap_NGSetupRequest = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Request */
        p_ngap_NGSetupRequest = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGSetupRequest);

        if(NGAP_P_NULL == p_ngap_NGSetupRequest)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_nGSetup(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_NGSetupRequest);

        /* Encode 4 IEs of NG Setup Request Message */

        /* Encode IE 1 - Global RAN Node Id */
        ngap_GlobalRANNodeID *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_GlobalRANNodeID);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_global_ran_node_id(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_setup_req->global_ran_node_id)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1-Global RAN Node ID Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupRequest_protocolIEs_1(&asn1_ctx,
                    &p_ngap_NGSetupRequest->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE1 - Global RAN Node Id to NGAP PDU");
            break;
        }

        /* Encode IE 2 - RAN Node Name */
        if(NG_SETUP_REQ_RAN_NODE_NAME_ID_PRESENT &
                p_ng_setup_req->bitmask)
        {
            ngap_RANNodeName value_ie2 = NGAP_P_NULL;
            value_ie2 = (ngap_RANNodeName)p_ng_setup_req->ran_node_name;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupRequest_protocolIEs_2(&asn1_ctx,
                        &p_ngap_NGSetupRequest->protocolIEs, value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE2 - RAN Node Name to NGAP PDU");
                break;
            }
        }

        /* Encode IE 3 - Supported TA List */
        ngap_SupportedTAList    *p_value_ie3 = NGAP_P_NULL;
        OSRTDList               ngSetupRequestIEs_3;

        rtxDListInit(&ngSetupRequestIEs_3);

        p_value_ie3 = &ngSetupRequestIEs_3;

        if(NGAP_FAILURE == ngap_encode_ie_supported_ta_list(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_ng_setup_req->supported_ta_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3-Supported TA List Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupRequest_protocolIEs_3(&asn1_ctx,
                    &p_ngap_NGSetupRequest->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE3 - Supported TA List to NGAP PDU");
            break;
        }

        /* Encode IE 4 - Default Paging DRX */
        ngap_PagingDRX value_ie4 = NGAP_ZERO;
        value_ie4 = (ngap_PagingDRX)p_ng_setup_req->default_paging_drx;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupRequest_protocolIEs_4(&asn1_ctx,
                    &p_ngap_NGSetupRequest->protocolIEs, value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE4 - Default Paging DRX to NGAP PDU");
            break;
        }

        /* Encode IE 5- UE Retention Information */
        if(NG_SETUP_REQ_UE_RETENTION_INFO_PRESENT &
                p_ng_setup_req->bitmask)
        {
            ngap_UERetentionInformation value_ie5 = NGAP_ZERO;

            value_ie5 =
                (ngap_UERetentionInformation)p_ng_setup_req->ue_retention_info;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupRequest_protocolIEs_5(&asn1_ctx,
                        &p_ngap_NGSetupRequest->protocolIEs, value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE5 - UE Retention Inforamtion to NGAP PDU");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Setup Request");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Request Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_global_ran_node_id
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_gb_ran_node_id
 * Outputs          : p_ngap_asn_gb_ran_node_id	
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_global_ran_node_id
(
 OSCTXT					    *p_asn1_ctx,
 ngap_GlobalRANNodeID		*p_ngap_asn_gb_ran_node_id,  /* ASN Buffer */
 ngap_global_ran_node_id_t 	*p_ngap_local_gb_ran_node_id /* NGAP Local Buffer */
 )
{
    ngap_return_et          	response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    switch (p_ngap_local_gb_ran_node_id->choice_type)
    {
        case NGAP_GLOBAL_RAN_NODE_CHOICE_GNB_ID:
        { 
            /* Encode IE - Global gNB ID */
            p_ngap_asn_gb_ran_node_id->t = T_ngap_GlobalRANNodeID_globalGNB_ID;
            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_GlobalGNB_ID);

            if(NGAP_P_NULL == p_ngap_asn_gb_ran_node_id->u.globalGNB_ID)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMSET(p_ngap_asn_gb_ran_node_id->u.globalGNB_ID , NGAP_ZERO , sizeof(ngap_GlobalGNB_ID));/*Handover bug fixes*/

            /* Set Extension Bits as FALSE */
            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->m.iE_ExtensionsPresent = 
                NGAP_FALSE;

            /* Encode IE - PLMN Identity */
            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->pLMNIdentity.numocts = 
                NGAP_PLMN_IDENTITY_MAX_BYTES;

            NGAP_MEMCPY
                (
                 p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->pLMNIdentity.data,
                 p_ngap_local_gb_ran_node_id->global_gnb_id.plmn_identity.\
                 plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );

            /* Encode IE - gNB ID */
            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->gNB_ID.t = 
                T_ngap_GNB_ID_gNB_ID;

            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID = 
                rtxMemAllocTypeZ(p_asn1_ctx, ASN1BitStr32);

            if(NGAP_P_NULL == 
                    p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->numbits = 
                p_ngap_local_gb_ran_node_id->global_gnb_id.gnb_id.num_gnb_id_bits;

            NGAP_MEMCPY
                (
                 p_ngap_asn_gb_ran_node_id->u.globalGNB_ID->gNB_ID.u.gNB_ID->data,
                 p_ngap_local_gb_ran_node_id->global_gnb_id.gnb_id.gnb_id_bytes, 
                 NGAP_GNB_ID_OCTET_SIZE 
                );

            break;
        }

        case NGAP_GLOBAL_RAN_NODE_CHOICE_NG_ENB_ID:
        { 
            /* Encode IE - Global ng-eNB ID */

            p_ngap_asn_gb_ran_node_id->t = T_ngap_GlobalRANNodeID_globalNgENB_ID;
            p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_GlobalNgENB_ID);

            if(NGAP_P_NULL == p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            NGAP_MEMSET(p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID , NGAP_ZERO ,sizeof(ngap_GlobalNgENB_ID));/*Handover bug fixes*/
            /* Set Extension Bits as FALSE */
            p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->m.iE_ExtensionsPresent =
                NGAP_FALSE;

            /* Encode IE - PLMN Identity */
            p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->pLMNIdentity.numocts = 
                NGAP_PLMN_IDENTITY_MAX_BYTES;

            NGAP_MEMCPY
                (
                 p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->pLMNIdentity.data,
                 p_ngap_local_gb_ran_node_id->global_ng_enb_id.plmn_identity.\
                 plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );

            switch (p_ngap_local_gb_ran_node_id->global_ng_enb_id.choice_type)
            {
                case GLOBAL_NG_ENB_CHOICE_MACRO_ID: 
                {
                    /* Encode IE - Macro ng-eNB ID */
                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.t = 
                        T_ngap_NgENB_ID_macroNgENB_ID;		

                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                        macroNgENB_ID->numbits = NGAP_MACRO_NG_ENB_ID_OCTET_SIZE;

                    NGAP_MEMCPY
                        (
                         p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                         macroNgENB_ID->data,
                         p_ngap_local_gb_ran_node_id->global_ng_enb_id.\
                         macro_ng_enb_id,
                         NGAP_MACRO_NG_ENB_ID_OCTET_SIZE
                        );

                    break;    
                }

                case GLOBAL_NG_ENB_CHOICE_SHORT_MACRO_ID:
                {
                    /* Encode IE - Short Macro ng-eNB ID */
                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.t = 
                        T_ngap_NgENB_ID_shortMacroNgENB_ID;		

                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                        shortMacroNgENB_ID->numbits = NGAP_SHORT_MACRO_NG_ENB_ID_OCTET_SIZE;

                    NGAP_MEMCPY 
                        (
                         p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                         shortMacroNgENB_ID->data,
                         p_ngap_local_gb_ran_node_id->global_ng_enb_id.\
                         short_macro_ng_enb_id,
                         NGAP_SHORT_MACRO_NG_ENB_ID_OCTET_SIZE
                        );

                    break;    
                } 
                case GLOBAL_NG_ENB_CHOICE_LONG_MACRO_ID:
                {
                    /* Encode IE - Long Macro ng-eNB ID */
                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.t = 
                        T_ngap_NgENB_ID_longMacroNgENB_ID;	

                    p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                        longMacroNgENB_ID->numbits = 
                        NGAP_LONG_MACRO_NG_ENB_ID_OCTET_SIZE;

                    NGAP_MEMCPY 
                        (
                         p_ngap_asn_gb_ran_node_id->u.globalNgENB_ID->ngENB_ID.u.\
                         longMacroNgENB_ID->data,
                         p_ngap_local_gb_ran_node_id->global_ng_enb_id.\
                         long_macro_ng_enb_id,
                         NGAP_LONG_MACRO_NG_ENB_ID_OCTET_SIZE 
                        );

                    break;    
                } 
                default:
                {
                    /* Invalid Choice Type */
                    RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Request Failed");
                    response = NGAP_FAILURE;		
                }
            }	

            break;    
        }

        case NGAP_GLOBAL_RAN_NODE_CHOICE_N3IWF_ID:
        { 
            /* Encode IE - Global N3IWF ID */

            p_ngap_asn_gb_ran_node_id->t = T_ngap_GlobalRANNodeID_globalN3IWF_ID;

            p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_GlobalN3IWF_ID);

            if(NGAP_P_NULL == p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            NGAP_MEMSET(p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID , NGAP_ZERO ,sizeof(ngap_GlobalN3IWF_ID));/*Handover bug fixes*/

            /* Set Extension Bits as FALSE */
            p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->m.iE_ExtensionsPresent = 
                NGAP_FALSE;

            /* Encode IE - PLMN Identity */
            p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->pLMNIdentity.numocts = 
                NGAP_PLMN_IDENTITY_MAX_BYTES;

            NGAP_MEMCPY 
                (
                 p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->pLMNIdentity.data,
                 p_ngap_local_gb_ran_node_id->global_n3iwf_id.plmn_identity.\
                 plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );

            /* Encode IE - n3iwf ID */
            p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.t = 
                T_ngap_N3IWF_ID_n3IWF_ID;
            p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->numbits = 
                NGAP_N3IWF_ID_OCTET_SIZE;

            NGAP_MEMCPY
                (
                 p_ngap_asn_gb_ran_node_id->u.globalN3IWF_ID->n3IWF_ID.u.n3IWF_ID->data,
                 p_ngap_local_gb_ran_node_id->global_n3iwf_id.n3iwf_id,
                 NGAP_N3IWF_ID_OCTET_SIZE 
                );

            break;    
        }

        default:
        {
            /* Invalid Choice Type */
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Request Failed");
            response = NGAP_FAILURE;		
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_supported_ta_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_supported_ta_list
 * Outputs          : p_ngap_asn_supported_ta_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_supported_ta_list
(
 OSCTXT			            *p_asn1_ctx,
 ngap_SupportedTAList	    *p_ngap_asn_supported_ta_list, /* ASN Buffer */
 ngap_supported_ta_list_t   *p_ngap_local_supported_ta_list /* NGAP Local Buffer */
 )
{
    ngap_SupportedTAItem    *p_ngap_supported_tai_item = NGAP_P_NULL;
    OSRTDListNode           *p_tai_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16			        num_tai_item_count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 TAI item should be present */
    if (NGAP_ZERO == p_ngap_local_supported_ta_list->ta_count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No TAI List Present");
        response = NGAP_FAILURE;
    }

    for (num_tai_item_count = NGAP_ZERO; 
            num_tai_item_count < p_ngap_local_supported_ta_list->ta_count;
            num_tai_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_SupportedTAItem,
                &p_tai_item_node,
                &p_ngap_supported_tai_item);

        if ( (NGAP_P_NULL == p_tai_item_node) || 
                (NGAP_P_NULL == p_ngap_supported_tai_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_supported_tai_item, 
                NGAP_ZERO, sizeof(ngap_SupportedTAItem));

        /* Set Extension Bits as FALSE */
        p_ngap_supported_tai_item->m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - TAC */
        p_ngap_supported_tai_item->tAC.numocts = NGAP_TAC_OCTET_SIZE;

        NGAP_MEMCPY (p_ngap_supported_tai_item->tAC.data,
                p_ngap_local_supported_ta_list->supported_ta[num_tai_item_count].tac,
                NGAP_TAC_OCTET_SIZE);

        /* Encode IE - Broadcast PLMN List */
        if (NGAP_FAILURE == ngap_encode_ie_plmn_list (p_asn1_ctx,
                    &p_ngap_supported_tai_item->broadcastPLMNList,
                    &p_ngap_local_supported_ta_list->supported_ta[num_tai_item_count].\
                    ngap_broadcast_plmn_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - Supported PLMN List");
            response = NGAP_FAILURE;
            break;
        }

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_ngap_asn_supported_ta_list, p_tai_item_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
ngap_return_et ngap_fill_ip_add_and_port_info
(
    OSCTXT                                 *p_asn1_ctx,
    ngap_CPTransportLayerInformation       *p_asn_tnl_association,
    amf_tnl_association_address_t          *p_ngap_local_tnl_remove_list
)
{
    ngap_return_et                         response                = NGAP_SUCCESS;

    switch(p_ngap_local_tnl_remove_list->choice)
    {
        case NGAP_TNL_ENDPOINT_IP_ADDR:
        {
            /* Encode IE - TNL Associations Transport layer Address*/

            p_asn_tnl_association->t = 
                T_ngap_CPTransportLayerInformation_endpointIPAddress;

            /* Allocate the memory for TNL Associations Transport layer Address */

            p_asn_tnl_association->u.endpointIPAddress = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_TransportLayerAddress);

            if(NGAP_P_NULL == p_asn_tnl_association->u.endpointIPAddress)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_asn_tnl_association->u.endpointIPAddress->data = 
                (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

            if(NGAP_P_NULL == p_asn_tnl_association->u.endpointIPAddress->data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break; 
            }

            p_asn_tnl_association->u.endpointIPAddress->numbits = 
                NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

            NGAP_MEMCPY((void *)p_asn_tnl_association->u.endpointIPAddress->data,
                    p_ngap_local_tnl_remove_list->endpoint_ip_address.transport_layer_address,
                    NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);
            break;
        }

        case NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT:
        {
            /* Endpoint IP Address*/
            p_asn_tnl_association->t = 
                T_ngap_CPTransportLayerInformation_choice_Extensions;

            /* Allocate the memory for TNL Associations Transport layer Address */
            p_asn_tnl_association->u.choice_Extensions = 
                rtxMemAllocTypeZ(p_asn1_ctx, 
                        ngap_CPTransportLayerInformation_choice_Extensions);

            if(NGAP_P_NULL == p_asn_tnl_association->u.choice_Extensions)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_asn_tnl_association->u.choice_Extensions->id = 
                ASN1V_ngap_id_EndpointIPAddressAndPort;

            p_asn_tnl_association->u.choice_Extensions->criticality = ngap_reject;


            p_asn_tnl_association->u.choice_Extensions->value.t =
                T122ngap___ngap_CPTransportLayerInformation_ExtIEs_1;

            /* Allocate the memory for TNL Associations Transport layer Address
             * for _ngap_CPTransportLayerInformation_ExtIEs_1*/

            p_asn_tnl_association->u.choice_Extensions->value.u.\
                _ngap_CPTransportLayerInformation_ExtIEs_1 =
                rtxMemAllocTypeZ(p_asn1_ctx,
                        ngap_EndpointIPAddressAndPort);

            if(NGAP_P_NULL ==  p_asn_tnl_association->u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_asn_tnl_association->u.choice_Extensions->value.u.\
                _ngap_CPTransportLayerInformation_ExtIEs_1->\
                endpointIPAddress.data = 
                (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

            if(NGAP_P_NULL == p_asn_tnl_association->u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1->\
                    endpointIPAddress.data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_asn_tnl_association->u.choice_Extensions->value.u.\
                _ngap_CPTransportLayerInformation_ExtIEs_1->\
                endpointIPAddress.numbits=
                NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

            NGAP_MEMCPY((void *)
                    p_asn_tnl_association->u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1->\
                    endpointIPAddress.data,
                    p_ngap_local_tnl_remove_list->endpoint_ip_address_and_port.\
                    endpoint_ip_address.transport_layer_address,
                    NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

            /*Port Number*/
            p_asn_tnl_association->u.choice_Extensions->value.u.\
                _ngap_CPTransportLayerInformation_ExtIEs_1->\
                portNumber.numocts = 
                NGAP_PORT_NUMBER_OCTET_SIZE;

            NGAP_MEMCPY((void *)p_asn_tnl_association->u.\
                    choice_Extensions->value.u._ngap_CPTransportLayerInformation_ExtIEs_1->\
                    portNumber.data,
                    p_ngap_local_tnl_remove_list->endpoint_ip_address_and_port.\
                    port_number,
                    NGAP_PORT_NUMBER_OCTET_SIZE);

            break;
        }
    }
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*****************************************************************************
 * Function Name    : ngap_encode_ie_tnl_remove_list
 * Inputs           : p_asn1_ctx
 *
 * Outputs          : p_ngap_local_tnl_remove_list
 *                    p_ngap_asn_tnl_remove_list
 *
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 *
 * DESCRIPTION      : This function fill ASN Structure using local structure
 * **************************************************************************/
ngap_return_et ngap_encode_ie_tnl_remove_list
(
 OSCTXT                                 *p_asn1_ctx,
 ngap_NGRAN_TNLAssociationToRemoveList  *p_ngap_asn_tnl_remove_list, /*ASN Buffer*/
 ngap_tnl_association_remove_list_t     *p_ngap_local_tnl_remove_list/*NGAP Local Buffer*/
)
{
    ngap_NGRAN_TNLAssociationToRemoveItem  *p_ngap_tnl_remove_item = NGAP_P_NULL;
    OSRTDListNode                          *p_tnl_item_node        = NGAP_P_NULL;
    ngap_return_et                         response                = NGAP_SUCCESS;
    UInt16                                 num_tnl_item_count      = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 TNL Remove item should be present */
    if(NGAP_ZERO == p_ngap_local_tnl_remove_list->tnl_count)
    {
        RRC_NGAP_TRACE(NGAP_WARNING, "No TNL Remove List Present");
        return response;
    }

    for(num_tnl_item_count = NGAP_ZERO;
            num_tnl_item_count < p_ngap_local_tnl_remove_list->tnl_count;
            num_tnl_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_NGRAN_TNLAssociationToRemoveItem,
                &p_tnl_item_node,
                &p_ngap_tnl_remove_item);

        if((NGAP_P_NULL == p_tnl_item_node)||(NGAP_P_NULL == p_ngap_tnl_remove_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_tnl_remove_item,
                NGAP_ZERO, sizeof(ngap_NGRAN_TNLAssociationToRemoveItem));


        /*fill at Transport Layer Address */
        response = ngap_fill_ip_add_and_port_info
            (
             p_asn1_ctx,
             &p_ngap_tnl_remove_item->tNLAssociationTransportLayerAddress,
             &p_ngap_local_tnl_remove_list->tnl_association[num_tnl_item_count].\
             transport_layer_addr
            );


        /* Encode IE - TNL Associations Transport layer Address at AMF*/
        if(NGAP_TNL_ASSOCIATION_ADDRESS_AT_AMF_PRESENT & 
                p_ngap_local_tnl_remove_list->tnl_association[num_tnl_item_count].bitmask)
        {
            p_ngap_tnl_remove_item->m.\
             tNLAssociationTransportLayerAddressAMFPresent = NGAP_TRUE;

            /*fill at Transport Address Layer at AMF*/
            response = ngap_fill_ip_add_and_port_info
                (
                 p_asn1_ctx,
                 &p_ngap_tnl_remove_item->\
                 tNLAssociationTransportLayerAddressAMF,
                 &p_ngap_local_tnl_remove_list->\
                 tnl_association[num_tnl_item_count].\
                 transport_layer_at_amf
                );

        }
        rtxDListAppendNode(p_ngap_asn_tnl_remove_list,p_tnl_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_plmn_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_supported_plmn_list
 * Outputs          : p_ngap_asn_supported_plmn_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_plmn_list
(
 OSCTXT					    *p_asn1_ctx,
 ngap_BroadcastPLMNList		*p_ngap_asn_supported_plmn_list,  /* ASN Buffer */
 ngap_broadcast_plmn_list_t *p_ngap_local_supported_plmn_list /* NGAP Local Buffer */
 )
{
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    ngap_BroadcastPLMNItem  *p_ngap_broadcast_plmn_item = NGAP_P_NULL;
    OSRTDListNode           *p_bplmn_item_node = NGAP_P_NULL;
    UInt8                   num_bplmn_item_count = NGAP_ZERO;

    /* At least 1 Broadcast PLMN item should be present */
    if (NGAP_ZERO == p_ngap_local_supported_plmn_list->plmn_count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No Broadcast PLMN List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (num_bplmn_item_count = NGAP_ZERO; 
            num_bplmn_item_count < p_ngap_local_supported_plmn_list->plmn_count;
            num_bplmn_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_BroadcastPLMNItem,
                &p_bplmn_item_node,
                &p_ngap_broadcast_plmn_item);

        if ( (NGAP_P_NULL == p_bplmn_item_node) || 
                (NGAP_P_NULL == p_ngap_broadcast_plmn_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_broadcast_plmn_item, 
                NGAP_ZERO, sizeof(ngap_BroadcastPLMNItem));

        /* Set Extension Bits as FALSE */
        p_ngap_broadcast_plmn_item->m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - PLMN Identity */
        p_ngap_broadcast_plmn_item->pLMNIdentity.numocts = 
            NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY (p_ngap_broadcast_plmn_item->pLMNIdentity.data,
                p_ngap_local_supported_plmn_list->supported_plmn[num_bplmn_item_count].\
                plmn_identity.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES);

        /* Encode IE - TAI Slice Support List */
        {
            ngap_SliceSupportItem           *p_ngap_slice_item = NGAP_P_NULL;
            OSRTDListNode                   *p_tai_slice_item_node = NGAP_P_NULL;
            UInt16                          num_slice_item_count = NGAP_ZERO;

            ngap_tai_slice_support_list_t   *p_tai_slice_list = 
                &p_ngap_local_supported_plmn_list->\
                supported_plmn[num_bplmn_item_count].tai_slice_support_list;

            /* At least 1 Broadcast PLMN item should be present */
            if (NGAP_ZERO == p_tai_slice_list->tai_slice_count)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "No TAI Slice Support List Present");
                response = NGAP_FAILURE;
                break;
            }

            for (num_slice_item_count = NGAP_ZERO; 
                    num_slice_item_count < p_tai_slice_list->tai_slice_count;
                    num_slice_item_count++)
            {
                rtxDListAllocNodeAndData(p_asn1_ctx,
                        ngap_SliceSupportItem,
                        &p_tai_slice_item_node,
                        &p_ngap_slice_item);

                if ( (NGAP_P_NULL == p_tai_slice_item_node) || 
                        (NGAP_P_NULL == p_ngap_slice_item))
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMSET(p_ngap_slice_item, NGAP_ZERO, 
                        sizeof(ngap_SliceSupportItem));

                /* Set Extension Bits as FALSE */
                p_ngap_slice_item->m.iE_ExtensionsPresent = NGAP_FALSE;

                /* Encode IE - S NSSAI */
                p_ngap_slice_item->s_NSSAI.m.iE_ExtensionsPresent = NGAP_FALSE;

                /* Encode IE - S NSSAI - SST */
                p_ngap_slice_item->s_NSSAI.sST.numocts = NGAP_SST_OCTET_SIZE;

                NGAP_MEMCPY (p_ngap_slice_item->s_NSSAI.sST.data, 
                        p_tai_slice_list->slice_support_item[num_slice_item_count].\
                        s_nssai.sst,
                        NGAP_SST_OCTET_SIZE);

                if (NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT & 
                        p_tai_slice_list->slice_support_item[num_slice_item_count].\
                        s_nssai.bitmask)
                {
                    /* Encode IE - S NSSAI - SD */
                    p_ngap_slice_item->s_NSSAI.m.sDPresent = NGAP_TRUE;
                    p_ngap_slice_item->s_NSSAI.sD.numocts = NGAP_SD_OCTET_SIZE;

                    NGAP_MEMCPY (p_ngap_slice_item->s_NSSAI.sD.data, 
                            p_tai_slice_list->slice_support_item[num_slice_item_count].\
                            s_nssai.sd,
                            NGAP_SD_OCTET_SIZE);
                }
                else
                {
                    /* Not Present IE - S NSSAI - SD */
                    p_ngap_slice_item->s_NSSAI.m.sDPresent = NGAP_FALSE;
                }

                /* Add 1 Node of type TAI Slice Support */
                rtxDListAppendNode(&p_ngap_broadcast_plmn_item->tAISliceSupportList, 
                        p_tai_slice_item_node);
            }
        }

        /* Add 1 Node of type PLMN Item */
        rtxDListAppendNode(p_ngap_asn_supported_plmn_list, p_bplmn_item_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_served_guami_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_served_guami_list
 * Outputs          : p_ngap_served_guami_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_served_guami_list
(
 OSCTXT					    *p_asn1_ctx,
 ngap_ServedGUAMIList		*p_ngap_served_guami_list,      /* ASN Buffer */
 ngap_served_guami_list_t  	*p_ngap_local_served_guami_list /* NGAP Local Buffer */
 )
{
    ngap_ServedGUAMIItem	*p_ngap_served_guami_item;
    OSRTDListNode           *p_guami_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16                  num_guami_item_count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 GUAMI item should be present */
    if (NGAP_ZERO == p_ngap_local_served_guami_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No GUAMI List Present");
        response = NGAP_FAILURE;
    }

    for (num_guami_item_count = NGAP_ZERO; num_guami_item_count < 
            p_ngap_local_served_guami_list->count;
            num_guami_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_ServedGUAMIItem,
                &p_guami_item_node,
                &p_ngap_served_guami_item);

        if ( (NGAP_P_NULL == p_guami_item_node) || 
                (NGAP_P_NULL == p_ngap_served_guami_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_served_guami_item, NGAP_ZERO, sizeof(ngap_ServedGUAMIItem));

        /* Set Extension Bits as FALSE */
        p_ngap_served_guami_item->m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - GUAMI */
        p_ngap_served_guami_item->gUAMI.pLMNIdentity.numocts = 
            NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY (p_ngap_served_guami_item->gUAMI.pLMNIdentity.data,
                p_ngap_local_served_guami_list->guami_item[num_guami_item_count].guami.\
                plmn_identity.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES );

        p_ngap_served_guami_item->gUAMI.aMFRegionID.numbits = 
            NGAP_AMF_REGION_ID_NUMBITS;

        NGAP_MEMCPY (p_ngap_served_guami_item->gUAMI.aMFRegionID.data,
                p_ngap_local_served_guami_list->guami_item[num_guami_item_count].\
                guami.amf_region_id,
                NGAP_AMF_REGION_ID_OCTET_SIZE );

        p_ngap_served_guami_item->gUAMI.aMFSetID.numbits = NGAP_AMF_SET_ID_NUMBITS;

        NGAP_MEMCPY (p_ngap_served_guami_item->gUAMI.aMFSetID.data,
                p_ngap_local_served_guami_list->guami_item[num_guami_item_count].\
                guami.amf_set_id,
                NGAP_AMF_SET_ID_OCTET_SIZE );

        p_ngap_served_guami_item->gUAMI.aMFPointer.numbits = 
            NGAP_AMF_POINTER_NUMBITS;

        NGAP_MEMCPY (p_ngap_served_guami_item->gUAMI.aMFPointer.data,
                p_ngap_local_served_guami_list->guami_item[num_guami_item_count].\
                guami.amf_pointer,
                NGAP_AMF_POINTER_OCTET_SIZE );

        /* Encode IE - Backup AMF Name */
        if( NG_SETUP_RES_BACKUP_AMF_NAME_PRESENT & 
                p_ngap_local_served_guami_list->\
                guami_item[num_guami_item_count].bitmask
          )
        {
            p_ngap_served_guami_item->m.backupAMFNamePresent = NGAP_TRUE;

            p_ngap_served_guami_item->backupAMFName =
                (ngap_AMFName)p_ngap_local_served_guami_list->\
                guami_item[num_guami_item_count].backup_amf_name.amf_name;
        }

        /*Add One Item to the Node */
        rtxDListAppendNode(p_ngap_served_guami_list, p_guami_item_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name    : ngap_encode_ie_plmn_support_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_plmn_support_list
 * Outputs          : p_ngap_plmn_support_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_plmn_support_list
(
 OSCTXT					    *p_asn1_ctx,
 ngap_PLMNSupportList		*p_ngap_plmn_support_list,      /* ASN Buffer */
 ngap_plmn_support_list_t  	*p_ngap_local_plmn_support_list /* NGAP Local Buffer */
 )
{
    ngap_PLMNSupportItem	*p_ngap_plmn_support_item;
    OSRTDListNode           *p_plmn_support_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16                  num_plmn_support_item_count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 PLMN Support List should be present */
    if (NGAP_ZERO == p_ngap_local_plmn_support_list->plmn_count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No PLMN Support List Present");
        response = NGAP_FAILURE;
    }

    for (num_plmn_support_item_count = NGAP_ZERO; 
            num_plmn_support_item_count < p_ngap_local_plmn_support_list->plmn_count;
            num_plmn_support_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PLMNSupportItem,
                &p_plmn_support_item_node,
                &p_ngap_plmn_support_item);

        if ( (NGAP_P_NULL == p_plmn_support_item_node) || 
                (NGAP_P_NULL == p_ngap_plmn_support_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_plmn_support_item, NGAP_ZERO, sizeof(ngap_PLMNSupportItem));

        /* Set Extension Bits as FALSE */
        p_ngap_plmn_support_item->m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - PLMN Identity */
        p_ngap_plmn_support_item->pLMNIdentity.numocts = 
            NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY (p_ngap_plmn_support_item->pLMNIdentity.data,
                p_ngap_local_plmn_support_list->supported_plmn[num_plmn_support_item_count].\
                plmn_identity.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES);

        /* Encode IE - Slice Support List */
        {
            ngap_SliceSupportItem           *p_ngap_slice_item = NGAP_P_NULL;
            OSRTDListNode                   *p_tai_slice_item_node = NGAP_P_NULL;
            UInt16                          num_slice_item_count = NGAP_ZERO;

            ngap_tai_slice_support_list_t   *p_tai_slice_list = 
                &p_ngap_local_plmn_support_list->supported_plmn[num_plmn_support_item_count].\
                tai_slice_support_list;

            /* At least 1 Broadcast PLMN item should be present */
            if (NGAP_ZERO == p_tai_slice_list->tai_slice_count)
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "No PLMN Support List Present");
                response = NGAP_FAILURE;
                break;
            }

            for (num_slice_item_count = NGAP_ZERO; 
                    num_slice_item_count < p_tai_slice_list->tai_slice_count;
                    num_slice_item_count++)
            {
                rtxDListAllocNodeAndData(p_asn1_ctx,
                        ngap_SliceSupportItem,
                        &p_tai_slice_item_node,
                        &p_ngap_slice_item);

                if ((NGAP_P_NULL == p_tai_slice_item_node) || 
                        (NGAP_P_NULL == p_ngap_slice_item))
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMSET(p_ngap_slice_item, NGAP_ZERO, 
                        sizeof(ngap_SliceSupportItem));

                /* Set Extension Bits as FALSE */
                p_ngap_slice_item->m.iE_ExtensionsPresent = NGAP_FALSE;

                /* Encode IE - S NSSAI */
                p_ngap_slice_item->s_NSSAI.m.iE_ExtensionsPresent = NGAP_FALSE;

                /* Encode IE - S NSSAI - SST */
                p_ngap_slice_item->s_NSSAI.sST.numocts = NGAP_SST_OCTET_SIZE;

                NGAP_MEMCPY (p_ngap_slice_item->s_NSSAI.sST.data, 
                        p_tai_slice_list->slice_support_item[num_slice_item_count].\
                        s_nssai.sst,
                        NGAP_SST_OCTET_SIZE);

                if (NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT & 
                        p_tai_slice_list->slice_support_item[num_slice_item_count].\
                        s_nssai.bitmask)
                {
                    /* Encode IE - S NSSAI - SD */
                    p_ngap_slice_item->s_NSSAI.m.sDPresent = NGAP_TRUE;
                    p_ngap_slice_item->s_NSSAI.sD.numocts = NGAP_SD_OCTET_SIZE;

                    NGAP_MEMCPY (p_ngap_slice_item->s_NSSAI.sD.data, 
                            p_tai_slice_list->slice_support_item[num_slice_item_count].\
                            s_nssai.sd,
                            NGAP_SD_OCTET_SIZE);
                }
                else
                {
                    /* Not Present IE - S NSSAI - SD */
                    p_ngap_slice_item->s_NSSAI.m.sDPresent = NGAP_FALSE;
                }

                /* Add 1 Node of type TAI Slice Support */
                rtxDListAppendNode(&p_ngap_plmn_support_item->sliceSupportList, 
                        p_tai_slice_item_node);
            }
        }

        rtxDListAppendNode(p_ngap_plmn_support_list, p_plmn_support_item_node);
    }    

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_criticality_diagnostics
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_criticality_diagnostics
 * Outputs          : p_ngap_criticality_diagnostics_item
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_criticality_diagnostics
(
 OSCTXT                          *p_asn1_ctx,
 ngap_CriticalityDiagnostics     *p_ngap_criticality_diagnostics_item, /* ASN Buffer */
 ngap_criticality_diagnostics_t  *p_ngap_local_criticality_diagnostics /* NGAP Local Buffer */
 )
{
    ngap_return_et      response = NGAP_SUCCESS;

    /* Encode IE - Procedure Code */
    if(NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CODE &
            p_ngap_local_criticality_diagnostics->bitmask)
    {
        p_ngap_criticality_diagnostics_item->m.procedureCodePresent = NGAP_TRUE;

        p_ngap_criticality_diagnostics_item->procedureCode =
            (ngap_ProcedureCode)p_ngap_local_criticality_diagnostics->procedure_code;
    }

    /* Encode IE - Triggering Message */
    if(NGAP_CRITICALITY_DIAGNOSTICS_TRIGGERING_MESSAGE &
            p_ngap_local_criticality_diagnostics->bitmask)
    {
        p_ngap_criticality_diagnostics_item->m.triggeringMessagePresent = NGAP_TRUE;

        p_ngap_criticality_diagnostics_item->triggeringMessage = 
            (ngap_TriggeringMessage)p_ngap_local_criticality_diagnostics->\
            triggering_message_event_id;
    }

    /* Encode IE - Procedure Criticality */
    if(NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CRITICALITY &
            p_ngap_local_criticality_diagnostics->bitmask)
    {
        p_ngap_criticality_diagnostics_item->m.procedureCriticalityPresent = 
            NGAP_TRUE;

        p_ngap_criticality_diagnostics_item->procedureCriticality = 
            (ngap_Criticality)p_ngap_local_criticality_diagnostics->\
            procedure_criticality_event_id;
    }

    /* At least 1 Criticality Diagnostics Information Element item should be present */
    if (NGAP_ZERO == p_ngap_local_criticality_diagnostics->cd_ie_list.no_of_errors)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
                "No Criticality Diagnostics Information Element Present");
        response = NGAP_FAILURE;
    }
    else
    {
        /* Encode IE - Information Element Criticality Diagnostics */
        ngap_CriticalityDiagnostics_IE_Item	*p_ngap_cd_ie_item;

        OSRTDListNode   *p_cd_ie_item_node = NGAP_P_NULL;
        UInt16			num_cd_ie_item_count = NGAP_ZERO;	

        for (num_cd_ie_item_count = NGAP_ZERO; 
                num_cd_ie_item_count < p_ngap_local_criticality_diagnostics->\
                cd_ie_list.no_of_errors;
                num_cd_ie_item_count++)

        {	
            rtxDListAllocNodeAndData(p_asn1_ctx,
                    ngap_CriticalityDiagnostics_IE_Item,
                    &p_cd_ie_item_node,
                    &p_ngap_cd_ie_item);

            if ( (NGAP_P_NULL == p_cd_ie_item_node) || 
                    (NGAP_P_NULL == p_ngap_cd_ie_item))
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_ngap_criticality_diagnostics_item->m.iEsCriticalityDiagnosticsPresent = 
                NGAP_TRUE;

            NGAP_MEMSET(p_ngap_cd_ie_item, NGAP_ZERO, 
                    sizeof(ngap_CriticalityDiagnostics_IE_Item));

            /* Set Extension Bits as FALSE */
            p_ngap_cd_ie_item->m.iE_ExtensionsPresent = NGAP_FALSE;

            /* IE Criticality */
            p_ngap_cd_ie_item->iECriticality = 
                (ngap_Criticality) p_ngap_local_criticality_diagnostics->cd_ie_list.\
                criticality_diagnostics_ie[num_cd_ie_item_count].ie_criticality;

            /* IE ID */
            p_ngap_cd_ie_item->iE_ID = 
                (ngap_ProtocolIE_ID) p_ngap_local_criticality_diagnostics->\
                cd_ie_list.criticality_diagnostics_ie[num_cd_ie_item_count].ie_id;

            /* Type Of Error */
            p_ngap_cd_ie_item->typeOfError = 
                (ngap_TypeOfError) p_ngap_local_criticality_diagnostics->\
                cd_ie_list.criticality_diagnostics_ie[num_cd_ie_item_count].\
                type_of_error;

            rtxDListAppendNode(&p_ngap_criticality_diagnostics_item->\
                    iEsCriticalityDiagnostics, p_cd_ie_item_node);

        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name	: ngap_encode_ng_setup_resp
 * Inputs           : p_ng_setup_resp - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NG SETUP RESPONSE ASN message from the information 
 *				        provided in p_ng_setup_resp
 *****************************************************************************/
ngap_return_et ngap_encode_ng_setup_resp
(
 ngap_setup_response_t   *p_ng_setup_resp,
 UInt8                   *p_asn_msg,
 UInt16                  *p_asn_msg_len
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_NGSetupResponse   	*p_ngap_NGSetupResponse = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Response */
        p_ngap_NGSetupResponse = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGSetupResponse);

        if(NGAP_P_NULL == p_ngap_NGSetupResponse)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_nGSetup(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_ngap_NGSetupResponse);

        /* Encode 5 IEs of NG Setup Response Message */

        /* Encode IE 1 - AMF Name */
        ngap_AMFName p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = (ngap_AMFName)p_ng_setup_resp->amf_name.amf_name;


        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupResponse_protocolIEs_1(&asn1_ctx,
                    &p_ngap_NGSetupResponse->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - AMF Name to NGAP PDU");
            break;
        }

        /* Encode IE 2 - Served GUAMI List */
        ngap_ServedGUAMIList    *p_value_ie2 = NGAP_P_NULL;
        OSRTDList               ngSetupResponseIEs_2;

        rtxDListInit(&ngSetupResponseIEs_2);

        p_value_ie2 = &ngSetupResponseIEs_2;

        if(NGAP_FAILURE == ngap_encode_ie_served_guami_list(
                    &asn1_ctx,
                    p_value_ie2,
                    &p_ng_setup_resp->served_guami_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2-Served GUAMI List");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupResponse_protocolIEs_2(&asn1_ctx,
                    &p_ngap_NGSetupResponse->protocolIEs, p_value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - Served GUAMI List to NGAP PDU");
            break;
        }

        /* Encode IE 3 - Relative AMF Capacity */
        ngap_RelativeAMFCapacity value_ie3 = NGAP_ZERO;
        value_ie3 = (ngap_RelativeAMFCapacity)p_ng_setup_resp->relative_amf_capacity;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupResponse_protocolIEs_3(&asn1_ctx,
                    &p_ngap_NGSetupResponse->protocolIEs, value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE3 - Relative AMF Capacity to NGAP PDU");
            break;
        }

        /* Encode IE 4 - PLMN Support List */
        ngap_PLMNSupportList    *p_value_ie4 = NGAP_P_NULL;
        OSRTDList               ngSetupResponseIEs_4;

        rtxDListInit(&ngSetupResponseIEs_4);

        p_value_ie4 = &ngSetupResponseIEs_4;

        if(NGAP_FAILURE == ngap_encode_ie_plmn_support_list(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_ng_setup_resp->plmn_support_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4-PLMN Support List");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupResponse_protocolIEs_4(&asn1_ctx,
                    &p_ngap_NGSetupResponse->protocolIEs, p_value_ie4))
        {   
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE4 - PLMN Support List to NGAP PDU");
            break;
        }

        /* Encode IE 5 - Criticality Diagnostics */
        if(NG_SETUP_RES_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_ng_setup_resp->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie5 = NGAP_P_NULL; 
            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_ng_setup_resp->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE5-Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupResponse_protocolIEs_5(&asn1_ctx,
                        &p_ngap_NGSetupResponse->protocolIEs, p_value_ie5))
            {   
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE5 - Criticality Diagnostics");
                break;
            }

        }

        /* Encode IE 6- UE Retention Information */
        if(NG_SETUP_RES_UE_RETENTION_INFO_PRESENT &
                p_ng_setup_resp->bitmask)
        {
            ngap_UERetentionInformation value_ie6 = NGAP_ZERO;

            value_ie6 =
                (ngap_UERetentionInformation)p_ng_setup_resp->ue_retention_info;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupResponse_protocolIEs_6(&asn1_ctx,
                        &p_ngap_NGSetupResponse->protocolIEs, value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE6 - UE Retention Inforamtion to NGAP PDU");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG SETUP Response");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Response Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name    : ngap_encode_ie_cause
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_cause
 * Outputs          : p_ngap_asn_cause
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_cause
(
 OSCTXT					    *p_asn1_ctx,
 ngap_Cause      		    *p_ngap_asn_cause,  /* ASN Buffer */
 ngap_choice_cause_group_t 	*p_ngap_local_cause /* NGAP Local Buffer */
)
{
    ngap_return_et          	response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    switch (p_ngap_local_cause->choice_type)
    {

        case NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER:
        {
            /* Encode IE - Radio Network Layer */
            p_ngap_asn_cause->t = T_ngap_Cause_radioNetwork;

            p_ngap_asn_cause->u.radioNetwork = 
                (ngap_CauseRadioNetwork) p_ngap_local_cause->\
                radio_network_layer_cause_event_id;

            break;
        }

        case NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER:
        {
            /* Encode IE - Transport Layer */
            p_ngap_asn_cause->t = T_ngap_Cause_transport;

            p_ngap_asn_cause->u.transport = 
                (ngap_CauseTransport) p_ngap_local_cause->transport_layer_event_id;
            break;
        }

        case NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE:
        {
            /* Encode IE - NAS Cause */
            p_ngap_asn_cause->t = T_ngap_Cause_nas;

            p_ngap_asn_cause->u.nas = 
                (ngap_CauseNas) p_ngap_local_cause->nas_cause_event_id;
            break;
        }

        case NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE:
        {
            /* Encode IE - Protocol Cause */
            p_ngap_asn_cause->t = T_ngap_Cause_protocol;

            p_ngap_asn_cause->u.protocol = 
                (ngap_CauseProtocol) p_ngap_local_cause->protocol_cause_event_id;
            break;
        }

        case NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE:
        {
            /* Encode IE - Miscellaneous Cause */
            p_ngap_asn_cause->t = T_ngap_Cause_misc;

            p_ngap_asn_cause->u.misc = 
                (ngap_CauseMisc) p_ngap_local_cause->miscellaneous_cause_event_id;
            break;
        }

        default:
        {
            /* Invalid Choice Type */
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of ID Cause Failed\n");/*Handover bug fixes*/
            response = NGAP_FAILURE;		
            break;/*Handover bug fixes*/
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_ng_setup_fail
 * Inputs           : p_ng_setup_fail - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NG SETUP FAILURE ASN message from the information 
 *				   provided in p_ng_setup_fail
 *****************************************************************************/
ngap_return_et ngap_encode_ng_setup_fail
(
 ngap_setup_failure_t        *p_ng_setup_fail,
 UInt8                       *p_asn_msg,
 UInt16                      *p_asn_msg_len
 )
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_NGSetupFailure   	    *p_ngap_NGSetupFailure = NGAP_P_NULL;
    ngap_return_et          	response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;

        ngap_pdu.u.unsuccessfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Failure */
        p_ngap_NGSetupFailure = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGSetupFailure);

        if(NGAP_P_NULL == p_ngap_NGSetupFailure)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_UnsuccessfulOutcome_nGSetup(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_ngap_NGSetupFailure);

        /* Encode 3 IEs of NG Setup Failure Message */
        /* Encode IE 1 - Cause */
        ngap_Cause *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_setup_fail->choice_cause_group)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupFailure_protocolIEs_1(&asn1_ctx,
                    &p_ngap_NGSetupFailure->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - Cause");
            break;
        }

        /* Encode IE 2 - Time to Wait  */
        if(NG_SETUP_FAIL_TIME_TO_WAIT_PRESENT &
                p_ng_setup_fail->bitmask)
        {
            /* Encode IE 2 - Time to Wait  */
            ngap_TimeToWait_Root value_ie2 = ngap_v1s;

            value_ie2 = (ngap_TimeToWait_Root)p_ng_setup_fail->time_to_wait_event_id;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupFailure_protocolIEs_2(&asn1_ctx,
                        &p_ngap_NGSetupFailure->protocolIEs, value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - TimeToWait");
                break;
            }
        }

        /* Encode IE 3 - Criticality Diagnostics */
        if(NG_SETUP_FAIL_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_ng_setup_fail->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie3 = NGAP_P_NULL; 

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ng_setup_fail->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE3 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupFailure_protocolIEs_3(&asn1_ctx,
                        &p_ngap_NGSetupFailure->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;
            }

        }    

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Ng setup Fail");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Failure Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name	    : ngap_encode_initial_ue_msg
 * Inputs           	: p_initial_ue_msg - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes INITIAL UE MESSAGE ASN message from the information 
 *				   provided in p_initial_ue_msg
 *****************************************************************************/
ngap_return_et ngap_encode_initial_ue_message
(
 ngap_initial_ue_message_t  *p_initial_ue_msg,	/* Input - Local Buffer */
 UInt8                      *p_asn_msg, 		/* Output - ASN Encoded Buffer */
 UInt16                     *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
 )
{

    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_InitialUEMessage   *p_ngap_InitialUEMessage = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t=T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Request */
        p_ngap_InitialUEMessage = rtxMemAllocTypeZ(&asn1_ctx, ngap_InitialUEMessage);

        if(NGAP_P_NULL == p_ngap_InitialUEMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_initialUEMessage(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_InitialUEMessage);

        /* Encode 8 IEs of Initial UE Message */

        /* Encode IE 1 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID  value_ie1 = NGAP_ZERO;
        value_ie1 = (ngap_RAN_UE_NGAP_ID)p_initial_ue_msg->ran_ue_ngap_id;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_InitialUEMessage_protocolIEs_1(&asn1_ctx,
                    &p_ngap_InitialUEMessage->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE1 - RAN UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - NAS-PDU */
        ngap_NAS_PDU *p_value_ie2 = NGAP_P_NULL;
        p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

        if(NGAP_P_NULL == p_value_ie2)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie2->numocts = p_initial_ue_msg->nas_pdu.num_string_len;
        p_value_ie2->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie2->numocts);

        NGAP_MEMCPY ((void *)p_value_ie2->data,
                p_initial_ue_msg->nas_pdu.string_data,
                p_value_ie2->numocts );


        if(NGAP_ASN_OK !=
                asn1Append_ngap_InitialUEMessage_protocolIEs_2(&asn1_ctx,
                    &p_ngap_InitialUEMessage->protocolIEs, p_value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - NAS-PDU to NGAP PDU");
            break;
        }

        /* Encode IE 3 - User Location Information */
        ngap_UserLocationInformation    *p_value_ie3 = NGAP_P_NULL;
        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UserLocationInformation);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_user_location_info(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_initial_ue_msg->choice_user_location_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of IE3 - User Location Information Failed");

            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_InitialUEMessage_protocolIEs_3(&asn1_ctx,
                    &p_ngap_InitialUEMessage->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE3 - User Location Information to NGAP PDU");
            break;
        }

        /* Encode IE 4 - RRC Establishment Cause */

        ngap_RRCEstablishmentCause  value_ie4 = NGAP_ZERO;

        value_ie4 = (ngap_RRCEstablishmentCause)p_initial_ue_msg->\
                    rrc_establishment_cause;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_InitialUEMessage_protocolIEs_4(&asn1_ctx,
                    &p_ngap_InitialUEMessage->protocolIEs, value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE4 - RRC Establishment Cause to NGAP PDU");
            break;
        }

        /* Encode IE 5 - 5G-S-TMSI */
        if(INITIAL_UE_MESSAGE_5G_S_TMSI_PRESENT & p_initial_ue_msg->bitmask)
        {    
            ngap_FiveG_S_TMSI   *p_value_ie5 = NGAP_P_NULL;
            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_FiveG_S_TMSI);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_5g_s_tmsi(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_initial_ue_msg->tmsi))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE5 - 5G-S-TMSI Failed");
                response = NGAP_FAILURE;
                break;
            }


            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialUEMessage_protocolIEs_5(&asn1_ctx,
                        &p_ngap_InitialUEMessage->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE5 - 5G-S-TMSI to NGAP PDU");
                break;
            }
        }

        /* Encode IE 6 - AMF Set Id */
        if(INITIAL_UE_MESSAGE_AMF_SET_ID_PRESENT & p_initial_ue_msg->bitmask)
        {
            ngap_AMFSetID   *p_value_ie6 = NGAP_P_NULL;

            p_value_ie6 = rtxMemAllocTypeZ(&asn1_ctx, ngap_AMFSetID);

            if(NGAP_P_NULL == p_value_ie6)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie6->numbits = NGAP_AMF_SET_ID_NUMBITS;

            NGAP_MEMCPY (p_value_ie6->data,
                    p_initial_ue_msg->amf_set_id.amf_set_id,
                    NGAP_AMF_SET_ID_OCTET_SIZE );

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialUEMessage_protocolIEs_6(&asn1_ctx,
                        &p_ngap_InitialUEMessage->protocolIEs, p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6 - AMF Set Id to NGAP PDU");
                break;
            }
        }    

        /* Encode IE 7 - UE Context Request */
        if(INITIAL_UE_MESSAGE_UE_CONTEXT_REQUEST_PRESENT & p_initial_ue_msg->bitmask)
        {
            ngap_UEContextRequest   value_ie7 = NGAP_ZERO; 

            value_ie7 = (ngap_UEContextRequest)p_initial_ue_msg->\
                        ue_context_request_event_id;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialUEMessage_protocolIEs_7(&asn1_ctx,
                        &p_ngap_InitialUEMessage->protocolIEs, value_ie7))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE7 - UE Context Request to NGAP PDU");
                break;
            }
        }

        /* Encode IE 8 - Allowed NSSI */
        if(INITIAL_UE_MESSAGE_ALLOWED_NSSAI_PRESENT & p_initial_ue_msg->bitmask)
        {
            ngap_AllowedNSSAI   *p_value_ie8 = NGAP_P_NULL;
            OSRTDList           ngap_InitialUEMessage_IEs_8;

            rtxDListInit(&ngap_InitialUEMessage_IEs_8);

            p_value_ie8 = &ngap_InitialUEMessage_IEs_8;

            if(NGAP_FAILURE == ngap_encode_ie_allowed_nssai(
                        &asn1_ctx,
                        p_value_ie8,
                        &p_initial_ue_msg->allowed_nssai_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE8 - Allowed NSSAI Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialUEMessage_protocolIEs_8(&asn1_ctx,
                        &p_ngap_InitialUEMessage->protocolIEs, p_value_ie8))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE8 - Allowed NSSAI to NGAP PDU");
                break;
            }
        }
        /* Encode IE 9 - Source to Target AMF Information Reroute */
       if(INITIAL_UE_MESSAGE_SOURCE_TO_TARGET_AMF_INFO_REROUTE_PRESENT & p_initial_ue_msg->bitmask) 
        {
            ngap_SourceToTarget_AMFInformationReroute    *p_value_ie9 = NGAP_P_NULL;
            
            p_value_ie9 = rtxMemAllocTypeZ(&asn1_ctx, ngap_SourceToTarget_AMFInformationReroute);
            
            if(NGAP_P_NULL == p_value_ie9)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
           
           if(NGAP_FAILURE == ngap_encode_source_to_target_amf_information(
                    &asn1_ctx,
                    p_value_ie9,
                    &p_initial_ue_msg->source_to_target_information_reroute))
           {
               RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE9 - Source to Target AMF Information Reroute Failed");
               response = NGAP_FAILURE;
               break;
           }
            
           if (NGAP_ASN_OK != 
                    asn1Append_ngap_InitialUEMessage_protocolIEs_9(&asn1_ctx,
                        &p_ngap_InitialUEMessage->protocolIEs, p_value_ie9))
           {
               RRC_NGAP_TRACE(NGAP_ERROR,
                       "Failed to Add IE9 - Source to Target AMF Information Reroute");
               break;
           }

        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for NG INITIAL UE MESSAGE");
            response = NGAP_FAILURE;
            break;
        } 

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Initial UE Message Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_user_location_info
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_user_location_info
 * Outputs          : p_ngap_asn_user_location_info
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_user_location_info
(
 OSCTXT					                *p_asn1_ctx,
 ngap_UserLocationInformation            *p_ngap_asn_user_location_info,
 ngap_choice_user_location_information_t *p_ngap_local_user_location_info
 )
{

    ngap_return_et          	response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    switch(p_ngap_local_user_location_info->choice_type)
    {

        /* Encode IE - E-UTRA USER LOCATION INFORMATION */
        case NGAP_USER_LOCATION_INFO_CHOICE_EUTRA_USER_LOCATION_INFORMATION:
        {
            p_ngap_asn_user_location_info->t = 
                T_ngap_UserLocationInformation_userLocationInformationEUTRA;

            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_UserLocationInformationEUTRA);

            if(NGAP_P_NULL == 
                    p_ngap_asn_user_location_info->u.userLocationInformationEUTRA)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            /* Encode IE - E-UTRA CGI */
            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                eUTRA_CGI.m.iE_ExtensionsPresent = NGAP_FALSE;

            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                eUTRA_CGI.pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES; 

            NGAP_MEMCPY 
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                 eUTRA_CGI.pLMNIdentity.data,
                 p_ngap_local_user_location_info->eutra_user_location_information.\
                 eutra_cgi.plmn_identity.plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );


            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                eUTRA_CGI.eUTRACellIdentity.numbits
                = NGAP_EUTRA_CELL_IDENTITY_NUMBITS; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                 eUTRA_CGI.eUTRACellIdentity.data,
                 p_ngap_local_user_location_info->eutra_user_location_information.\
                 eutra_cgi.eutra_cell_identity,
                 NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE
                );


            /* Encode IE - TAI */
            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->tAI.m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->tAI.\
                pLMNIdentity.numocts
                = NGAP_PLMN_IDENTITY_MAX_BYTES; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                 tAI.pLMNIdentity.data,
                 p_ngap_local_user_location_info->eutra_user_location_information.\
                 tai.plmn_identity.plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );


            p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->tAI.\
                tAC.numocts = NGAP_TAC_OCTET_SIZE; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                 tAI.tAC.data,
                 p_ngap_local_user_location_info->eutra_user_location_information.\
                 tai.tac.tac,
                 NGAP_TAC_OCTET_SIZE
                );


            /* Encode IE - Age of Location */
            if( NGAP_EUTRA_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT & 
                    p_ngap_local_user_location_info->eutra_user_location_information.bitmask)
            {
                p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                    timeStamp.numocts
                    = NGAP_TIME_STAMP_OCTET_SIZE; 

                NGAP_MEMCPY
                    (
                     p_ngap_asn_user_location_info->u.userLocationInformationEUTRA->\
                     timeStamp.data,
                     p_ngap_local_user_location_info->eutra_user_location_information.\
                     age_of_location.time_stamp,
                     NGAP_TIME_STAMP_OCTET_SIZE
                    );
            }

            if(NGAP_EUTRA_USER_LOCATION_INFO_PSCELL_INFO_PRESENT & 
                    p_ngap_local_user_location_info->eutra_user_location_information.bitmask)

            {

            }
            break;

        }

        /* Encode IE - NR USER LOCATION INFORMATION */
        case NGAP_USER_LOCATION_INFO_CHOICE_NR_USER_LOCATION_INFORMATION:
        {
            p_ngap_asn_user_location_info->t = 
                T_ngap_UserLocationInformation_userLocationInformationNR;

            p_ngap_asn_user_location_info->u.userLocationInformationNR = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_UserLocationInformationNR);

            if(NGAP_P_NULL == 
                    p_ngap_asn_user_location_info->u.userLocationInformationNR)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationNR->m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            /* Encode IE - NR UTRA CGI */
            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationNR->nR_CGI.m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            p_ngap_asn_user_location_info->u.userLocationInformationNR->nR_CGI.\
                pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationNR->\
                 nR_CGI.pLMNIdentity.data,
                 p_ngap_local_user_location_info->nr_user_location_information.\
                 nr_cgi.plmn_identity.plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );

            p_ngap_asn_user_location_info->u.userLocationInformationNR->nR_CGI.\
                nRCellIdentity.numbits = NGAP_NR_CELL_IDENTITY_NUMBITS; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationNR->\
                 nR_CGI.nRCellIdentity.data,
                 p_ngap_local_user_location_info->nr_user_location_information.\
                 nr_cgi.nr_cell_identity,
                 NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                );


            /* Encode IE - TAI */
            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationNR->tAI.m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            p_ngap_asn_user_location_info->u.userLocationInformationNR->tAI.\
                pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationNR->tAI.\
                 pLMNIdentity.data,
                 p_ngap_local_user_location_info->nr_user_location_information.tai.\
                 plmn_identity.plmn_id_bytes,
                 NGAP_PLMN_IDENTITY_MAX_BYTES
                );


            p_ngap_asn_user_location_info->u.userLocationInformationNR->tAI.tAC.\
                numocts = NGAP_TAC_OCTET_SIZE; 

            NGAP_MEMCPY
                (
                 p_ngap_asn_user_location_info->u.userLocationInformationNR->tAI.\
                 tAC.data,
                 p_ngap_local_user_location_info->nr_user_location_information.tai.\
                 tac.tac,
                 NGAP_TAC_OCTET_SIZE
                );


            /* Encode IE - Age of Location */
            if( NGAP_NR_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT & 
                    p_ngap_local_user_location_info->nr_user_location_information.bitmask)
            {

              p_ngap_asn_user_location_info->u.userLocationInformationNR->m.timeStampPresent =
                            NGAP_TRUE;/*Handover bug fixes*/

                p_ngap_asn_user_location_info->u.userLocationInformationNR->\
                    timeStamp.numocts = NGAP_TIME_STAMP_OCTET_SIZE; 

                NGAP_MEMCPY 
                    (
                     p_ngap_asn_user_location_info->u.userLocationInformationNR->\
                     timeStamp.data,
                     p_ngap_local_user_location_info->nr_user_location_information.\
                     age_of_location.time_stamp,
                     NGAP_TIME_STAMP_OCTET_SIZE
                    );
            }
            break;
        }

        /* Encode IE - N3IWF USER LOCATION INFORMATION */
        case NGAP_USER_LOCATION_INFO_CHOICE_N3IWF_USER_LOCATION_INFORMATION:
        {
            p_ngap_asn_user_location_info->t = 
                T_ngap_UserLocationInformation_userLocationInformationN3IWF;

            p_ngap_asn_user_location_info->u.userLocationInformationN3IWF = 
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_UserLocationInformationN3IWF);

            if(NGAP_P_NULL == 
                    p_ngap_asn_user_location_info->u.userLocationInformationN3IWF)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /* Set Extension Bits as FALSE */
            p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->m.\
                iE_ExtensionsPresent = NGAP_FALSE;

            /* Encode IE - IP Address */
            p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->\
                iPAddress.numbits = NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS; 

            p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->\
                iPAddress.data = 
                (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, 
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

            if(NGAP_P_NULL == 
                    p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->iPAddress.data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMCPY 
                (
                 (void *)p_ngap_asn_user_location_info->u.\
                 userLocationInformationN3IWF->iPAddress.data,
                 p_ngap_local_user_location_info->n3iwf_user_location_information.\
                 ip_address.transport_layer_address,
                 NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                );

            /* Encode IE - Port Number */
            if( NGAP_N3IWF_USER_LOCATION_INFO_PORT_NUMBER_PRESENT & 
                    p_ngap_local_user_location_info->n3iwf_user_location_information.bitmask)
            {
                p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->\
                    portNumber.numocts = NGAP_PORT_NUMBER_OCTET_SIZE; 

                NGAP_MEMCPY
                    (
                     p_ngap_asn_user_location_info->u.userLocationInformationN3IWF->\
                     portNumber.data,
                     p_ngap_local_user_location_info->n3iwf_user_location_information.\
                     port_number,
                     NGAP_PORT_NUMBER_OCTET_SIZE
                    );
            }    
            break;

        }

        default:
        {
            /* Invalid Choice Type */
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Initial UE Message Failed");
            response = NGAP_FAILURE;
            break;
        }

    }    

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_allowed_nssai
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_allowed_nssai_list
 * Outputs          : p_ngap_asn_allowed_nssai_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_allowed_nssai
(
 OSCTXT					     *p_asn1_ctx,
 ngap_AllowedNSSAI           *p_ngap_asn_allowed_nssai_list,
 ngap_allowed_nssai_list_t   *p_ngap_local_allowed_nssai_list
 )
{
    ngap_AllowedNSSAI_Item  *p_ngap_allowed_nssai_item = NGAP_P_NULL;
    OSRTDListNode           *p_nssai_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16			        num_nssai_item_count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 NSSAI item should be present */
    if (NGAP_ZERO == p_ngap_local_allowed_nssai_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No NSSAI List Present");
        response = NGAP_FAILURE;
    }

    for (num_nssai_item_count = NGAP_ZERO; 
            num_nssai_item_count < p_ngap_local_allowed_nssai_list->count;
            num_nssai_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AllowedNSSAI_Item,
                &p_nssai_item_node,
                &p_ngap_allowed_nssai_item);

        if ( (NGAP_P_NULL == p_nssai_item_node) || 
                (NGAP_P_NULL == p_ngap_allowed_nssai_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_allowed_nssai_item, NGAP_ZERO, 
                sizeof(ngap_AllowedNSSAI_Item));

        /* Set Extension Bits as FALSE */
        p_ngap_allowed_nssai_item->m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - S NSSAI */
        p_ngap_allowed_nssai_item->s_NSSAI.m.iE_ExtensionsPresent = NGAP_FALSE;

        /* Encode IE - S NSSAI - SST */
        p_ngap_allowed_nssai_item->s_NSSAI.sST.numocts = NGAP_SST_OCTET_SIZE;

        NGAP_MEMCPY (p_ngap_allowed_nssai_item->s_NSSAI.sST.data,
                p_ngap_local_allowed_nssai_list->\
                allowed_s_nssai_item[num_nssai_item_count].s_nssai.sst,
                NGAP_SST_OCTET_SIZE);

        if (NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT & 
                p_ngap_local_allowed_nssai_list->\
                allowed_s_nssai_item[num_nssai_item_count].s_nssai.bitmask)
        {
            /* Encode IE - S NSSAI - SD */
            p_ngap_allowed_nssai_item->s_NSSAI.m.sDPresent = NGAP_TRUE;
            p_ngap_allowed_nssai_item->s_NSSAI.sD.numocts = NGAP_SD_OCTET_SIZE;

            NGAP_MEMCPY (p_ngap_allowed_nssai_item->s_NSSAI.sD.data,
                    p_ngap_local_allowed_nssai_list->\
                    allowed_s_nssai_item[num_nssai_item_count].s_nssai.sd,
                    NGAP_SD_OCTET_SIZE);
        }
        else
        {
            /* Not Present IE - S NSSAI - SD */
            p_ngap_allowed_nssai_item->s_NSSAI.m.sDPresent = NGAP_FALSE;
        }

        /* Add 1 Node */
        rtxDListAppendNode(p_ngap_asn_allowed_nssai_list, p_nssai_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_ng_reset
 * Inputs          	: p_ng_reset - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                   	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NG RESET ASN message from the information 
 *				          provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_encode_ng_reset
(
 ngap_reset_t    *p_ng_reset,	/* Input - Local Buffer */
 UInt8           *p_asn_msg, 	/* Output - ASN Encoded Buffer */
 UInt16          *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU   ngap_pdu;
    OSCTXT          asn1_ctx;
    ngap_NGReset    *p_ngReset = NGAP_P_NULL;
    ngap_return_et  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Allocate memory to p_ng_reset */
        p_ngReset = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGReset);

        if(NGAP_P_NULL == p_ngReset)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the initiatinf message to ng_reset*/
        asn1SetTC_ngap_InitiatingMessage_nGReset(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngReset);

        /*Encoding of all IEs starts here*/

        /*Encode IE1- Cause*/

        ngap_Cause *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }	

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_reset->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1 - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }
        if(NGAP_ASN_OK != 
                asn1Append_ngap_NGReset_protocolIEs_1(&asn1_ctx,
                    &p_ngReset->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1- Cause to NGAP PDU");
            break;
        }

        /*Encode IE2 - CHOICE Reset Type*/
        ngap_ResetType  *p_value_ie2 = NGAP_P_NULL;
        p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx, ngap_ResetType);

        if(NGAP_P_NULL == p_value_ie2)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_choice_reset_type(
                    &asn1_ctx,
                    p_value_ie2,
                    &p_ng_reset->reset_type
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2 - CHOICE Reset Type failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != 
                asn1Append_ngap_NGReset_protocolIEs_2(&asn1_ctx,
                    &p_ngReset->protocolIEs, p_value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - CHOICE Reset Type to NGAP PDU");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for ng reset");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Reset Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_choice_reset_type
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_reset_type
 * Outputs          : p_ngap_asn_reset_type
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_choice_reset_type
(
 OSCTXT              *p_asn1_ctx,
 ngap_ResetType      *p_ngap_asn_reset_type,
 ngap_reset_type     *p_ngap_local_reset_type
 )
{
    ngap_return_et        response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    switch(p_ngap_local_reset_type->choice_type)
    {
        case NGAP_RESET_ALL:
        {
            /*Set the value of t*/
            p_ngap_asn_reset_type->t = T_ngap_ResetType_nG_Interface;

            /*Copy the data of reset_all_event_id to nG_Interface*/
            p_ngap_asn_reset_type->u.nG_Interface = 
                p_ngap_local_reset_type->reset_all_event_id;

            break;
        }

        case NGAP_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST:
        {
            /*Set the value of t*/
            p_ngap_asn_reset_type->t = T_ngap_ResetType_partOfNG_Interface;

            p_ngap_asn_reset_type->u.partOfNG_Interface = 
                rtxMemAllocTypeZ(p_asn1_ctx, 
                        ngap_UE_associatedLogicalNG_connectionList);

            if(NGAP_P_NULL == p_ngap_asn_reset_type->u.partOfNG_Interface)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == 
                    ngap_encode_ie_ue_associated_logical_ng_connection_list(
                        p_asn1_ctx,
                        p_ngap_asn_reset_type->u.partOfNG_Interface,
                        &p_ngap_local_reset_type->\
                        ue_associated_logical_ng_connection_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode Part of NG Interface");
                response = NGAP_FAILURE;
            }
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_ng_reset_acknowledge
 * Inputs           : p_ngap_reset_acknowledge - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NG RESET ACKNOWLEDGE ASN message from the information 
 *				          provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_encode_ng_reset_acknowledge
(
 ngap_reset_acknowledge_t    *p_ngap_reset_acknowledge,	/* Input - Local Buffer */
 UInt8                       *p_asn_msg, 		/* Output - ASN Encoded Buffer */
 UInt16                      *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_NGResetAcknowledge *p_reset_ack = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the successful outcome to ng reset acknowledge*/
        p_reset_ack = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGResetAcknowledge);

        if(NGAP_P_NULL == p_reset_ack)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_nGReset(&asn1_ctx,
                ngap_pdu.u.successfulOutcome,  p_reset_ack); 


        /*Encode IEs */

        /*Encode IE1 - UE-Associated Logical NG-Connection List */
        if(NG_RESET_ACK_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST_PRESENT &
                p_ngap_reset_acknowledge->bitmask)
        {
            ngap_UE_associatedLogicalNG_connectionList *p_value_ie1 = NGAP_P_NULL;

            OSRTDList   ngap_NGResetAcknowledgeIEs_1;

            rtxDListInit(&ngap_NGResetAcknowledgeIEs_1);
            p_value_ie1 = &ngap_NGResetAcknowledgeIEs_1;

            if(NGAP_FAILURE == 
                    ngap_encode_ie_ue_associated_logical_ng_connection_list(
                        &asn1_ctx,
                        p_value_ie1,
                        &p_ngap_reset_acknowledge->\
                        ue_associated_logical_ng_connection_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE1- UE-Associated Logical NG-Connection List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_NGResetAcknowledge_protocolIEs_1(&asn1_ctx,
                        &p_reset_ack->protocolIEs, p_value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE$ - Criticality Diagnostics");
                break;
            }
        }

        /*Encode IE2 - */

        if(NG_RESET_ACK_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_ngap_reset_acknowledge->bitmask)
        {

            ngap_CriticalityDiagnostics     *p_value_ie2 = NGAP_P_NULL;

            p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie2)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie2,
                        &p_ngap_reset_acknowledge->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE2 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_NGResetAcknowledge_protocolIEs_2(&asn1_ctx,
                        &p_reset_ack->protocolIEs, p_value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE2 - Criticality Diagnostics");
                break;
            }
        }
        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG Reset Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Reset Acknowledge Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_ue_associated_logical_ng_connection_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_ue_associated_logical_ng_connection_list
 * Outputs          : p_ngap_asn_ue_associated_logical_ng_connection_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_ue_associated_logical_ng_connection_list
(
 OSCTXT                                          *p_asn1_ctx,
 /*ASN Buffer*/
 ngap_UE_associatedLogicalNG_connectionList      *p_ngap_asn_ue_associated_logical_ng_connection_list,
 /*Local Structure*/
 ngap_ue_associated_logical_ng_connection_list_t *p_ngap_local_ue_associated_logical_ng_connection_list
 )
{
    ngap_UE_associatedLogicalNG_connectionItem   
        *p_ngap_ue_associated_logical_ng_connection_item = NGAP_P_NULL;

    OSRTDListNode *p_ue_associated_ng_connection_node    = NGAP_P_NULL;

    ngap_return_et response                              = NGAP_SUCCESS;
    UInt16 index                                         = NGAP_ZERO;


    RRC_NGAP_UT_TRACE_ENTER();

    /*Check if list is present or not*/

    if(NGAP_ZERO == p_ngap_local_ue_associated_logical_ng_connection_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    if(NG_RESET_MAX_NO_OF_NG_CONNECTION_TO_RESET <
            p_ngap_local_ue_associated_logical_ng_connection_list->count)
    {    
        RRC_NGAP_TRACE(NGAP_ERROR,"Value of count exceeds the max count of %d",
                NG_RESET_MAX_NO_OF_NG_CONNECTION_TO_RESET);
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < 
            p_ngap_local_ue_associated_logical_ng_connection_list->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_UE_associatedLogicalNG_connectionItem,
                &p_ue_associated_ng_connection_node,
                &p_ngap_ue_associated_logical_ng_connection_item);

        if((NGAP_P_NULL == p_ue_associated_ng_connection_node) ||
                (NGAP_P_NULL == p_ngap_ue_associated_logical_ng_connection_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_ue_associated_logical_ng_connection_item, 
                NGAP_ZERO,
                sizeof(ngap_UE_associatedLogicalNG_connectionItem));

        /*Encode IE - AMF UE NGAP ID */
        if(NG_RESET_AMF_UE_NGAP_ID_PRESENT & 
                p_ngap_local_ue_associated_logical_ng_connection_list->\
                ue_associated_logical_ng_connection_item[index].bitmask)
        {
            /*Set the presence bit to NGAP_TRUE*/
            p_ngap_ue_associated_logical_ng_connection_item->m.\
                aMF_UE_NGAP_IDPresent = NGAP_TRUE;

            /*Copy the value of amf_ue_ngap_id_t to aMF_UE_NGAP_ID*/
            p_ngap_ue_associated_logical_ng_connection_item->aMF_UE_NGAP_ID = 
                p_ngap_local_ue_associated_logical_ng_connection_list->\
                ue_associated_logical_ng_connection_item[index].amf_ue_ngap_id;

        }

        /*Encode IE - RAN UE NGAP ID */
        if(NG_RESET_RAN_UE_NGAP_ID_PRESENT   &   
                p_ngap_local_ue_associated_logical_ng_connection_list->\
                ue_associated_logical_ng_connection_item[index].bitmask)

        {
            /*Set the presence bit to NGAP_TRUE*/
            p_ngap_ue_associated_logical_ng_connection_item->m.\
                rAN_UE_NGAP_IDPresent = NGAP_TRUE;
            /*Copy the value of amf_ue_ngap_id_t to aMF_UE_NGAP_ID*/ 
            p_ngap_ue_associated_logical_ng_connection_item->rAN_UE_NGAP_ID = 
                p_ngap_local_ue_associated_logical_ng_connection_list->\
                ue_associated_logical_ng_connection_item[index].ran_ue_ngap_id;
        }

        /* Append node to the list */
        rtxDListAppendNode(p_ngap_asn_ue_associated_logical_ng_connection_list,
                p_ue_associated_ng_connection_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_error_indication
 * Inputs           : p_error_ind - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes ERROR INDICATION ASN message from the information 
 *				          provided in p_ng_setup_req
 *****************************************************************************/
ngap_return_et ngap_encode_error_indication
(
 ngap_error_indication_t *p_error_ind,	/* Input - Local Buffer */
 UInt8                   *p_asn_msg, 	/* Output - ASN Encoded Buffer */
 UInt16                  *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_ErrorIndication    *p_ngap_ErrorIndication = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_ErrorIndication = rtxMemAllocTypeZ(&asn1_ctx, ngap_ErrorIndication);

        if(NGAP_P_NULL == p_ngap_ErrorIndication)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_errorIndication(&asn1_ctx, 
                ngap_pdu.u.initiatingMessage, p_ngap_ErrorIndication);

        /*  Encode IE's of Error Indication */

        /* Encoding IE1 - AMF_UE_NGAP_ID */
        if(ERROR_INDICATION_AMF_UE_NGAP_ID_PRESENT & p_error_ind->bitmask)
        {

            ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
            value_ie1 = (ngap_AMF_UE_NGAP_ID)p_error_ind->amf_ue_ngap_id_t;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_ErrorIndication_protocolIEs_1(&asn1_ctx,
                        &p_ngap_ErrorIndication->protocolIEs, value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
                break;
            }
        }	

        /* Encoding IE2 - RAN_UE_NGAP_ID*/
        if(ERROR_INDICATION_RAN_UE_NGAP_ID_PRESENT & p_error_ind->bitmask)
        {
            ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
            value_ie2 = (ngap_RAN_UE_NGAP_ID)p_error_ind->ran_ue_ngap_id_t;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_ErrorIndication_protocolIEs_2(&asn1_ctx,
                        &p_ngap_ErrorIndication->protocolIEs, value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE2 - RAN_UE_NGAP_ID to NGAP PDU");
                break;
            }	
        }

        /* Encoding IE3 -  Cause */
        if(ERROR_INDICATION_CAUSE_PRESENT & p_error_ind->bitmask)
        {
            ngap_Cause *p_value_ie3 = NGAP_P_NULL;
            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }	

            if(NGAP_FAILURE == ngap_encode_ie_cause(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_error_ind->choice_cause_group))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3 - Cause Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_ErrorIndication_protocolIEs_3(&asn1_ctx,
                        &p_ngap_ErrorIndication->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3- Cause to NGAP PDU");
                break;
            }
        }
        /* Encode IE4 - Critically Diagnostic */
        if(ERROR_INDICATION_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_error_ind->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie4 = NGAP_P_NULL;

            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_error_ind->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE4 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_ErrorIndication_protocolIEs_4(&asn1_ctx,
                        &p_ngap_ErrorIndication->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE$ - Criticality Diagnostics");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Error Indication");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Error Indication Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_dl_nas_transport
 * Inputs           	: p_dl_nas_transport - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes DL NAS TRANSPORT ASN message from the information 
 *				   provided in p_dl_nas_transport
 *****************************************************************************/
ngap_return_et ngap_encode_dl_nas_transport
(
 ngap_downlink_nas_transport_t   *p_dl_nas_transport,/* Input - Local Buffer */
 UInt8                           *p_asn_msg, 		/* Output - ASN Encoded Buffer */
 UInt16                          *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU               ngap_pdu;
    OSCTXT                      asn1_ctx;
    ngap_DownlinkNASTransport   *p_ngap_DownlinkNASTransport = NGAP_P_NULL;
    ngap_return_et              response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        /* Allocate memory to initiatingMessage structure variable */
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Allocate memory to asn strtucture varibale */
        p_ngap_DownlinkNASTransport = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_DownlinkNASTransport);

        if(NGAP_P_NULL == p_ngap_DownlinkNASTransport)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        /*Set the initiating message type to Downlink NAS transport*/

        asn1SetTC_ngap_InitiatingMessage_downlinkNASTransport(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_DownlinkNASTransport);

        /* Encoding for all IE's starts here*/

        /* Encode IE1 - AMF UE NGAP ID */
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;

        value_ie1  = (ngap_AMF_UE_NGAP_ID)p_dl_nas_transport->amf_ue_ngap_id;

        /* Append IE to NGAP PDU*/
        if(NGAP_ASN_OK != 
                asn1Append_ngap_DownlinkNASTransport_protocolIEs_1(&asn1_ctx,
                    &p_ngap_DownlinkNASTransport->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "FAiled to add IE1 - AMF UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_dl_nas_transport->ran_ue_ngap_id;

        /* Append IE to NGAP PDU */
        if(NGAP_ASN_OK != 
                asn1Append_ngap_DownlinkNASTransport_protocolIEs_2(&asn1_ctx, 
                    &p_ngap_DownlinkNASTransport->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to add  Encode IE2 - RAN UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE3- Old AMF/ AMF NAME */
        if(DL_NAS_TRANSPORT_OLD_AMF_PRESENT &
                p_dl_nas_transport->bitmask)
        {
            ngap_AMFName p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = (ngap_AMFName)p_dl_nas_transport->amf_name.amf_name;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_DownlinkNASTransport_protocolIEs_3(&asn1_ctx,
                        &p_ngap_DownlinkNASTransport->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Fialed to add IE3- Old AMF/ AMF NAME to NGAP PDU");
                break;
            }
        } 

        /* Encode IE4 - RAN Paging Priority */
        if(DL_NAS_TRANSPORT_RAN_PAGING_PRIORITY_PRESENT &
                p_dl_nas_transport->bitmask)
        {
            ngap_RANPagingPriority value_ie4 = NGAP_ZERO;
            value_ie4 = (ngap_RANPagingPriority)p_dl_nas_transport->\
                        ran_paging_priority.ran_paging_priority;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_DownlinkNASTransport_protocolIEs_4(&asn1_ctx, 
                        &p_ngap_DownlinkNASTransport->protocolIEs, value_ie4))

            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add  IE4 - RAN Paging Priority to NGAP PDU");
                break;
            }
        }

        /* Encode IE5 - NAS-PDU */
        ngap_NAS_PDU *p_value_ie5 = NGAP_P_NULL;
        p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

        if(NGAP_P_NULL == p_value_ie5)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie5->numocts = p_dl_nas_transport->nas_pdu.num_string_len;

        /*Allocate Memory to data pointer */
        p_value_ie5->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie5->numocts);

        if(NGAP_P_NULL == p_value_ie5->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMCPY((void *)p_value_ie5->data, 
                p_dl_nas_transport->nas_pdu.string_data,
                p_value_ie5->numocts);

        if(NGAP_ASN_OK !=
                asn1Append_ngap_DownlinkNASTransport_protocolIEs_5(&asn1_ctx, 
                    &p_ngap_DownlinkNASTransport->protocolIEs, p_value_ie5))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add  IE5 - NAS-PDU to NGAP PDU");
            break;
        }



        /* Encode IE7 - Index to RAT/Frequency Selection Priority */
        if(DL_NAS_TRANSPORT_INDEX_TO_RAT_FREQUENCY_SELECTION_PRIORITY_PRESENT & 
                p_dl_nas_transport->bitmask)
        {   
            ngap_IndexToRFSP value_ie7 = NGAP_ZERO;
            value_ie7 = p_dl_nas_transport->index_to_rat_frequency_priority.\
                        index_to_rat_frequency_priority;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_DownlinkNASTransport_protocolIEs_7(&asn1_ctx,
                        &p_ngap_DownlinkNASTransport->protocolIEs, value_ie7))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add  IE7 - Index to RAT/Frequency Selection Priority to NGAP PDU");
                break;
            }

        }

        /* Encode IE8 - UE Aggregate Maximum Bit Rate */
        if(DL_NAS_TRANSPORT_UE_AGGREGATE_MAXIMUM_BIT_RATE_PRESENT &
                p_dl_nas_transport->bitmask)
        {

            ngap_UEAggregateMaximumBitRate *p_value_ie8 = NGAP_P_NULL;
            p_value_ie8  = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_UEAggregateMaximumBitRate);

            if(NGAP_P_NULL == p_value_ie8)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie8->uEAggregateMaximumBitRateDL = 
                p_dl_nas_transport->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_dl.bit_rate;

            p_value_ie8->uEAggregateMaximumBitRateUL = 
                p_dl_nas_transport->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_ul.bit_rate;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_DownlinkNASTransport_protocolIEs_8(&asn1_ctx, 
                        &p_ngap_DownlinkNASTransport->protocolIEs, p_value_ie8))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE8 - UE Aggregate Maximum Bit Rate to NGAP PDU");
                break;
            }
        }

        /* Encode IE9 - Allowed NSSAI*/
        if(DL_NAS_TRANSPORT_ALLOWED_NSSAI_PRESENT &
                p_dl_nas_transport->bitmask)
        {
            ngap_AllowedNSSAI   *p_value_ie9 = NGAP_P_NULL;
            OSRTDList           ngap_downlink_nas_transIE_9;

            /* Initialize the list */
            rtxDListInit(&ngap_downlink_nas_transIE_9);
            p_value_ie9 = &ngap_downlink_nas_transIE_9;

            if(NGAP_FAILURE == ngap_encode_ie_allowed_nssai(
                        &asn1_ctx,
                        p_value_ie9,
                        &p_dl_nas_transport->allowed_nssai_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of Encode IE9 - Allowed NSSAI Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_DownlinkNASTransport_protocolIEs_9(&asn1_ctx,
                        &p_ngap_DownlinkNASTransport->protocolIEs, p_value_ie9))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE9 - Allowed NSSAI to NGAP PDU");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=  
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for DL NAS Transport");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of DL NAS Transport Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN,(SInt8 *) "NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_encode_ul_nas_transport
 * Inputs           	: p_ul_nas_transport - Information from which Asn message will be prepared
 * Outputs          	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes UL NAS TRANSPORT ASN message from the information 
 *				   provided in p_ul_nas_transport
 *****************************************************************************/
ngap_return_et ngap_encode_ul_nas_transport
(
 ngap_uplink_nas_transport_t *p_ul_nas_transport,/* Input - Local Buffer */
 UInt8                       *p_asn_msg, 		/* Output - ASN Encoded Buffer */
 UInt16                      *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_UplinkNASTransport *p_ngap_UplinkNASTransport = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        /* Allocate memory to the initiatingMessage strtucture variable*/
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Allocate memory to asn strtucture varibale */
        p_ngap_UplinkNASTransport = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UplinkNASTransport);

        if(NGAP_P_NULL == p_ngap_UplinkNASTransport)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the initialting message to Uplink NAS Transport */
        asn1SetTC_ngap_InitiatingMessage_uplinkNASTransport(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_UplinkNASTransport);

        /* Encoding of all the IE's starts here*/
        /* Encode IE1 -  AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_ul_nas_transport->amf_ue_ngap_id;

        /* Append IE1 to NGAP PDU*/
        if(NGAP_ASN_OK != 
                asn1Append_ngap_UplinkNASTransport_protocolIEs_1(&asn1_ctx,
                    &p_ngap_UplinkNASTransport->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to add IE1 - AMF UE NGAP ID to NGAP PDU ");
            break;
        }

        /*Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_ul_nas_transport->ran_ue_ngap_id;

        /*Append IE2 to NGAP PDU */
        if(NGAP_ASN_OK != 
                asn1Append_ngap_UplinkNASTransport_protocolIEs_2(&asn1_ctx,
                    &p_ngap_UplinkNASTransport->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to add  Encode IE2 - RAN UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE3 - NAS-PDU */
        ngap_NAS_PDU *p_value_ie3 = NGAP_P_NULL;
        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie3->numocts = p_ul_nas_transport->nas_pdu.num_string_len;

        /* allocate memory to data */
        p_value_ie3->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie3->numocts);

        if(NGAP_P_NULL == p_value_ie3->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Copy the string_data with length = numocts in data*/
        NGAP_MEMCPY((void *)p_value_ie3->data,
                p_ul_nas_transport->nas_pdu.string_data,
                p_value_ie3->numocts);

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UplinkNASTransport_protocolIEs_3(&asn1_ctx,
                    &p_ngap_UplinkNASTransport->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add  IE3 - NAS-PDU to NGAP PDU");
            break;
        }

        /* Encode IE4 - User Location Information*/
        ngap_UserLocationInformation *p_value_ie4 = NGAP_P_NULL;
        p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UserLocationInformation);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* encoding the various members of the structure */
        if(NGAP_FAILURE == ngap_encode_user_location_info(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_ul_nas_transport->choice_user_location_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    " Encoding of IE4 - User Location Information Failed ");
            response = NGAP_FAILURE;
            break;
        } 
        if(NGAP_ASN_OK !=
                asn1Append_ngap_UplinkNASTransport_protocolIEs_4(&asn1_ctx,
                    &p_ngap_UplinkNASTransport->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add E4 - User Location Information to NGAP PDU");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NG UL NAS TRANSPORT");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of UL NAS Transport Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();	
    return response;
}

/******************************************************************************
 * Function Name	: ngap_nas_non_delivery_ind
 * Inputs           : p_nas_non_delivery_ind - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes NAS NON DELIVERY INDICATION ASN message from the information 
 *				   provided in p_nas_non_delivery_ind
 *****************************************************************************/
ngap_return_et ngap_nas_non_delivery_ind
(
 ngap_nas_non_delivery_indication_t  *p_nas_non_delivery_ind,/* Input - Local Buffer */
 UInt8                               *p_asn_msg, 		    /* Output - ASN Encoded Buffer */
 UInt16                              *p_asn_msg_len		    /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_NASNonDeliveryIndication   *p_ngap_NASNonDeliveryIndication = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_NASNonDeliveryIndication = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_NASNonDeliveryIndication);

        if(NGAP_P_NULL == p_ngap_NASNonDeliveryIndication)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NAS Non Delivery */
        asn1SetTC_ngap_InitiatingMessage_nASNonDeliveryIndication(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_NASNonDeliveryIndication);

        /* Encoding of all IEs starts here*/

        /* Encode IE1 - AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_nas_non_delivery_ind->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_NASNonDeliveryIndication_protocolIEs_1(&asn1_ctx,
                    &p_ngap_NASNonDeliveryIndication->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE1 - AMF UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_nas_non_delivery_ind->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_NASNonDeliveryIndication_protocolIEs_2(&asn1_ctx,
                    &p_ngap_NASNonDeliveryIndication->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE2 -RAN UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE3 - NAS-PDU */
        ngap_NAS_PDU *p_value_ie3 = NGAP_P_NULL;
        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie3->numocts = p_nas_non_delivery_ind->nas_pdu.num_string_len;

        p_value_ie3->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie3->numocts);

        if(NGAP_P_NULL == p_value_ie3->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMCPY((void *)p_value_ie3->data, 
                p_nas_non_delivery_ind->nas_pdu.string_data,
                p_value_ie3->numocts);

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NASNonDeliveryIndication_protocolIEs_3(&asn1_ctx,               
                    &p_ngap_NASNonDeliveryIndication->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add  IE3 - NAS-PDU to NGAP PDU");
            break;
        }

        /* Encoding IE4 -  Cause */
        ngap_Cause *p_value_ie4 = NGAP_P_NULL;
        p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_nas_non_delivery_ind->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4 - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != 
                asn1Append_ngap_NASNonDeliveryIndication_protocolIEs_4(&asn1_ctx,
                    &p_ngap_NASNonDeliveryIndication->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE4- Cause to NGAP PDU");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for NAS non delivery indication");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of UL NAS Transport Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_guami
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_guami
 * Outputs          : p_ngap_asn_guami
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_guami
(
 OSCTXT			*p_asn1_ctx,
 ngap_GUAMI     *p_ngap_asn_guami,/*ASN buffer*/
 ngap_guami_t   *p_ngap_local_guami /*Local structure*/
 )
{
    ngap_return_et  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Encode PLMNIdentity */
    p_ngap_asn_guami->pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES;

    NGAP_MEMCPY(p_ngap_asn_guami->pLMNIdentity.data, 
            p_ngap_local_guami->plmn_identity.plmn_id_bytes, 
            NGAP_PLMN_IDENTITY_MAX_BYTES);

    /* Encode AMF Region ID */
    p_ngap_asn_guami->aMFRegionID.numbits = NGAP_AMF_REGION_ID_NUMBITS;

    NGAP_MEMCPY(p_ngap_asn_guami->aMFRegionID.data, 
            p_ngap_local_guami->amf_region_id, NGAP_AMF_REGION_ID_OCTET_SIZE);

    /* Encode AMF Set ID*/
    p_ngap_asn_guami->aMFSetID.numbits = NGAP_AMF_SET_ID_NUMBITS;

    NGAP_MEMCPY(p_ngap_asn_guami->aMFSetID.data,
            p_ngap_local_guami->amf_set_id, NGAP_AMF_SET_ID_OCTET_SIZE);

    /* Encode - AMF Pointer */
    p_ngap_asn_guami->aMFPointer.numbits = NGAP_AMF_POINTER_NUMBITS;

    NGAP_MEMCPY(p_ngap_asn_guami->aMFPointer.data,
            p_ngap_local_guami->amf_pointer, NGAP_AMF_POINTER_OCTET_SIZE);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_ue_security_capabilities
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_ue_security_capabilities
 * Outputs          : p_ngap_asn_ue_security_capabilities
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_ue_security_capabilities
(
 OSCTXT			                    *p_asn1_ctx,
 ngap_UESecurityCapabilities         *p_ngap_asn_ue_security_capabilities,/*ASN buffer*/
 ngap_ue_security_capabilities_t     *p_ngap_local_ue_security_capabilities /*Local structure*/
 )
{
    ngap_return_et                      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Encode nr_encryption_algorithm*/
    p_ngap_asn_ue_security_capabilities->nRencryptionAlgorithms.numbits = 
        NGAP_NR_ENCRYPTION_ALGORITHM_NUMBITS;/*Handover bug fixes*/
    /*  Allocate memory to "data" */
    p_ngap_asn_ue_security_capabilities->nRencryptionAlgorithms.data =
        (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, NGAP_NR_ENCRYPTION_ALGORITHM_OCTET_SIZE);

    if(NGAP_P_NULL ==
            p_ngap_asn_ue_security_capabilities->nRencryptionAlgorithms.data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        response = NGAP_FAILURE;
        return response;
    }

    NGAP_MEMCPY(
            (void *)p_ngap_asn_ue_security_capabilities->nRencryptionAlgorithms.data,
            p_ngap_local_ue_security_capabilities->nr_encryption_algorithm,
            NGAP_NR_ENCRYPTION_ALGORITHM_OCTET_SIZE);

    /*Encode  NR Integrity Protection Algorithms */
    p_ngap_asn_ue_security_capabilities->nRintegrityProtectionAlgorithms.numbits = 
        NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS;/*Handover bug fixes*/

    /*  Allocate memory to "data" */
    p_ngap_asn_ue_security_capabilities->nRintegrityProtectionAlgorithms.data =
        (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, 
                NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE);

    if(NGAP_P_NULL ==
            p_ngap_asn_ue_security_capabilities->nRintegrityProtectionAlgorithms.data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        response = NGAP_FAILURE;
        return response;
    }

    NGAP_MEMCPY
        (
         (void *)p_ngap_asn_ue_security_capabilities->\
         nRintegrityProtectionAlgorithms.data,
         p_ngap_local_ue_security_capabilities->nr_integrity_protection_algorithm,
         NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE
        );

    /* Encode  E-UTRA Encryption Algorithms*/ 
    p_ngap_asn_ue_security_capabilities->eUTRAencryptionAlgorithms.numbits = 
        NGAP_EUTRA_ENCRYPTION_ALGORITHM_NUMBITS;/*Handover bug fixes*/

    /*  Allocate memory to "data" */
    p_ngap_asn_ue_security_capabilities->eUTRAencryptionAlgorithms.data =
        (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, 
                NGAP_EUTRA_ENCRYPTION_ALGORITHM_OCTET_SIZE);

    if(NGAP_P_NULL ==
            p_ngap_asn_ue_security_capabilities->eUTRAencryptionAlgorithms.data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        response = NGAP_FAILURE;
        return response;
    }

    NGAP_MEMCPY((void *)p_ngap_asn_ue_security_capabilities->\
            eUTRAencryptionAlgorithms.data,
            p_ngap_local_ue_security_capabilities->eutra_encryption_algorithm,
            NGAP_EUTRA_ENCRYPTION_ALGORITHM_OCTET_SIZE);

    /* Encode E-UTRA Integrity Protection Algorithms*/
    p_ngap_asn_ue_security_capabilities->eUTRAintegrityProtectionAlgorithms.numbits = 
        NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS;/*Handover bug fixes*/

    /*  Allocate memory to "data" */
    p_ngap_asn_ue_security_capabilities->eUTRAintegrityProtectionAlgorithms.data =
        (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, 
                NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE);

    if(NGAP_P_NULL ==
            p_ngap_asn_ue_security_capabilities->eUTRAintegrityProtectionAlgorithms.data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        response = NGAP_FAILURE;
        return response;
    }
    NGAP_MEMCPY((void *)p_ngap_asn_ue_security_capabilities->\
            eUTRAintegrityProtectionAlgorithms.data,
            p_ngap_local_ue_security_capabilities->eutra_integrity_protection_algorithm,
            NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_trace_activation
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_trace_activation
 * Outputs          : p_ngap_asn_trace_activation
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_trace_activation
(
 OSCTXT			            *p_asn1_ctx,
 ngap_TraceActivation       *p_ngap_asn_trace_activation, /* ASN buffer */
 ngap_trace_activation_t    *p_ngap_local_trace_activation /* Local Structure*/
 )
{
    ngap_return_et              response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    /*Encode  NG-RAN Trace ID */
    p_ngap_asn_trace_activation->nGRANTraceID.numocts =
        NGAP_NG_RAN_TRACE_ID_OCTET_SIZE;

    NGAP_MEMCPY(p_ngap_asn_trace_activation->nGRANTraceID.data,
            p_ngap_local_trace_activation->ng_ran_trace_id,
            NGAP_NG_RAN_TRACE_ID_OCTET_SIZE);      

    /*Encode Interfaces to Trace */
    p_ngap_asn_trace_activation->interfacesToTrace.numbits = 
        NGAP_INTERFACE_TO_TRACE_NUMBITS;

    NGAP_MEMCPY(p_ngap_asn_trace_activation->interfacesToTrace.data,
            p_ngap_local_trace_activation->interfaces_to_trace,
            NGAP_INTERFACE_TO_TRACE_OCTET_SIZE);                

    /* Encode Trace Depth */
    p_ngap_asn_trace_activation->traceDepth = 
        p_ngap_local_trace_activation->trace_depth_event_id;

    /* Encode Trace Collection Entity IP Address */
    p_ngap_asn_trace_activation->traceCollectionEntityIPAddress.numbits = 
        NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

    p_ngap_asn_trace_activation->traceCollectionEntityIPAddress.data  = 
        (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

    if(NGAP_P_NULL == p_ngap_asn_trace_activation->traceCollectionEntityIPAddress.data)
    {
        NGAP_SYSTEM_MEM_FAIL();
        response = NGAP_FAILURE;
        return response;
    }

    NGAP_MEMCPY((void *)p_ngap_asn_trace_activation->\
            traceCollectionEntityIPAddress.data,
            p_ngap_local_trace_activation->ip_address.transport_layer_address,
            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE); 

    RRC_NGAP_UT_TRACE_EXIT();
    return response; 
}


ngap_return_et ngap_encode_ng_ran_cgi
(
    OSCTXT              *p_asn1_ctx,
    ngap_NGRAN_CGI      *p_asn_ng_ran_cgi,
    ngap_ng_ran_cgi_t   *p_local_ng_ran_cgi 
)
{
    ngap_return_et  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    

    switch(p_local_ng_ran_cgi->choice_type)
    {
        case NGAP_NR_CGI:
        {
            p_asn_ng_ran_cgi->t = 
                T_ngap_NGRAN_CGI_nR_CGI;

            p_asn_ng_ran_cgi->u.nR_CGI =
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_NR_CGI);

            if(NGAP_P_NULL == p_asn_ng_ran_cgi->u.nR_CGI)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;    
            }
            else
            {
                /*Encode pLMNIdentity*/

                /*Set the value of numocts*/
                p_asn_ng_ran_cgi->u.nR_CGI->pLMNIdentity.numocts = 
                NGAP_PLMN_IDENTITY_MAX_BYTES;

                /*Copy the value of data*/
                NGAP_MEMCPY
                (
                     p_asn_ng_ran_cgi->u.nR_CGI->pLMNIdentity.data,
                     p_local_ng_ran_cgi->nr_cgi.plmn_identity.plmn_id_bytes,
                     NGAP_PLMN_IDENTITY_MAX_BYTES
                );

                /*Encode nRCellIdentity*/

                /*Set the value of numbits*/
               p_asn_ng_ran_cgi->u.nR_CGI->nRCellIdentity.numbits = 
               NGAP_NR_CELL_IDENTITY_NUMBITS;

                /*Copy the value of data*/
                NGAP_MEMCPY
                (
                    p_asn_ng_ran_cgi->u.nR_CGI->nRCellIdentity.data,
                    p_local_ng_ran_cgi->nr_cgi.nr_cell_identity,
                    NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                );
            }
            break;
        }

        case NGAP_EUTRA_CGI:
        {
            p_asn_ng_ran_cgi->t = 
                T_ngap_NGRAN_CGI_eUTRA_CGI;

            p_asn_ng_ran_cgi->u.eUTRA_CGI =
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_EUTRA_CGI);

            if(NGAP_P_NULL == 
                    p_asn_ng_ran_cgi->u.eUTRA_CGI)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            else
            {
                /*Encode pLMNIdentity*/
                /*Set the value of numocts*/
                p_asn_ng_ran_cgi->u.eUTRA_CGI->pLMNIdentity.numocts = 
                NGAP_PLMN_IDENTITY_MAX_BYTES;

                /*Copy the value of data*/
                NGAP_MEMCPY
                (
                     p_asn_ng_ran_cgi->u.eUTRA_CGI->pLMNIdentity.data,
                     p_local_ng_ran_cgi->eutra_cgi.plmn_identity.plmn_id_bytes,
                     NGAP_PLMN_IDENTITY_MAX_BYTES
                );

                /*Encode eUTRACellIdentity*/

                /*Set the value of numbits*/
                p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.numbits = 
                    NGAP_EUTRA_CELL_IDENTITY_NUMBITS;

                /*Copy the value of data*/
                NGAP_MEMCPY
                (
                     p_asn_ng_ran_cgi->u.eUTRA_CGI->eUTRACellIdentity.data,
                     p_local_ng_ran_cgi->eutra_cgi.eutra_cell_identity,
                     NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE
                );

            }
            break;
        }
        default:
        {
            RRC_NGAP_TRACE(NGAP_INFO, "Value of choice type is invalid");
            response = NGAP_FAILURE;
            break;
        }
    }


    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et  ngap_encode_area_of_interest_ran_node_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_AreaOfInterestRANNodeList          *p_asn_list,
    ngap_area_of_interest_ran_node_list_t   *p_local_list
)
{
    ngap_AreaOfInterestRANNodeItem      *p_area_of_intrst_item = NGAP_P_NULL;
    OSRTDListNode                       *p_area_of_intrst_node = NGAP_P_NULL;
    UInt8                               count = NGAP_ZERO;
    ngap_return_et                      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    
    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO; count < p_local_list->count;count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AreaOfInterestRANNodeItem,
                &p_area_of_intrst_node,
                &p_area_of_intrst_item);

        if ( (NGAP_P_NULL == p_area_of_intrst_node) || 
                (NGAP_P_NULL == p_area_of_intrst_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_area_of_intrst_item, 
                NGAP_ZERO, sizeof(ngap_AreaOfInterestRANNodeItem));
        
        if(NGAP_FAILURE == ngap_encode_ie_global_ran_node_id(   
                p_asn1_ctx,
                &p_area_of_intrst_item->globalRANNodeID,
                &p_local_list->area_of_interest_ran_node_item[count].\
                global_ran_node_id
            ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Could not encode Global RAN Node ID");
            response = NGAP_FAILURE;
            break;
        }
      
        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_area_of_intrst_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}


ngap_return_et  ngap_encode_area_of_interest_cell_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_AreaOfInterestCellList             *p_asn_list,
    ngap_area_of_interest_cell_list_t       *p_local_list
)
{
    ngap_AreaOfInterestCellItem     *p_area_of_intrst_item = NGAP_P_NULL;
    OSRTDListNode                   *p_area_of_intrst_node = NGAP_P_NULL;
    UInt8                           count = NGAP_ZERO;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    
    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO; count < p_local_list->count;count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AreaOfInterestCellItem,
                &p_area_of_intrst_node,
                &p_area_of_intrst_item);

        if ( (NGAP_P_NULL == p_area_of_intrst_node) || 
                (NGAP_P_NULL == p_area_of_intrst_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_area_of_intrst_item, 
                NGAP_ZERO, sizeof(ngap_AreaOfInterestCellItem));
        
        if(NGAP_FAILURE == ngap_encode_ng_ran_cgi(
            
                p_asn1_ctx,
                &p_area_of_intrst_item->nGRAN_CGI,
                &p_local_list->ngap_area_of_interest_cell_item[count].ngran_cgi
                ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Could not encode NG RAN CGI");
            response = NGAP_FAILURE;
            break;

        }

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_area_of_intrst_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}



ngap_return_et  ngap_encode_area_of_interest_tai_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_AreaOfInterestTAIList          *p_asn_list,
    ngap_area_of_interest_tai_list_t    *p_local_list
)
{
    ngap_AreaOfInterestTAIItem      *p_area_of_intrst_item = NGAP_P_NULL;
    OSRTDListNode                   *p_area_of_intrst_node = NGAP_P_NULL;
    UInt8                           count = NGAP_ZERO;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    
    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO; count < p_local_list->count;count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AreaOfInterestTAIItem,
                &p_area_of_intrst_node,
                &p_area_of_intrst_item);

        if ( (NGAP_P_NULL == p_area_of_intrst_node) || 
                (NGAP_P_NULL == p_area_of_intrst_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_area_of_intrst_item, 
                NGAP_ZERO, sizeof(ngap_AreaOfInterestTAIItem));
        
        /*fill plmnIdentity*/
        p_area_of_intrst_item->tAI.pLMNIdentity.numocts =   
            NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY
        (
            p_area_of_intrst_item->tAI.pLMNIdentity.data,   
            p_local_list->tai[count].tai.plmn_identity.plmn_id_bytes,
            NGAP_PLMN_IDENTITY_MAX_BYTES
        );

        /*fill tac*/

        p_area_of_intrst_item->tAI.tAC.numocts = 
           NGAP_TAC_OCTET_SIZE;

        NGAP_MEMCPY
        (
            p_area_of_intrst_item->tAI.tAC.data,
            p_local_list->tai[count].tai.tac.tac,
            NGAP_TAC_OCTET_SIZE
        );
      
        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_area_of_intrst_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et ngap_encode_area_of_interest
(   
   OSCTXT                           *p_asn1_ctx,
   ngap_AreaOfInterest              *p_asn_area_of_interest,
   ngap_area_of_interest_t          *p_local_area_of_interest
)
{
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();
    

    rtxDListInit(&p_asn_area_of_interest->areaOfInterestTAIList);
    rtxDListInit(&p_asn_area_of_interest->areaOfInterestCellList);
    rtxDListInit(&p_asn_area_of_interest->areaOfInterestRANNodeList);

    
    if(NGAP_AREA_OF_INTEREST_TAI_LIST_PRESENT & p_local_area_of_interest->bitmask)
    {
        p_asn_area_of_interest->m.areaOfInterestTAIListPresent = NGAP_TRUE;
        
        if(NGAP_FAILURE == ngap_encode_area_of_interest_tai_list(

                    p_asn1_ctx,
                    &p_asn_area_of_interest->areaOfInterestTAIList,
                    &p_local_area_of_interest->area_of_interest_tai_list
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - Area of interest TAI List");
            response = NGAP_FAILURE;
            return response;
        }
    }
    if(NGAP_AREA_OF_INTEREST_CELL_LIST_PRESENT & p_local_area_of_interest->bitmask)
    {
        p_asn_area_of_interest->m.areaOfInterestCellListPresent = NGAP_TRUE;
        
        if(NGAP_FAILURE == ngap_encode_area_of_interest_cell_list(

                    p_asn1_ctx,
                    &p_asn_area_of_interest->areaOfInterestCellList,
                    &p_local_area_of_interest->area_of_interest_cell_list
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - Area of interest Cell List");
            response = NGAP_FAILURE;
            return response;
        }
    }

    if(NGAP_AREA_OF_INTEREST_RAN_NODE_LIST_PRESENT & 
                    p_local_area_of_interest->bitmask)
    {
        p_asn_area_of_interest->m.areaOfInterestRANNodeListPresent = NGAP_TRUE;
        
        if(NGAP_FAILURE == ngap_encode_area_of_interest_ran_node_list(

                    p_asn1_ctx,
                    &p_asn_area_of_interest->areaOfInterestRANNodeList,
                    &p_local_area_of_interest->area_of_interest_ran_node_list
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - Area of interest TAI List");
            response = NGAP_FAILURE;
            return response;
        }
    }
    
    
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}




ngap_return_et ngap_encode_area_of_interest_list
(
   OSCTXT                           *p_asn1_ctx,
   ngap_AreaOfInterestList          *p_asn_area_of_interest_list,
   ngap_area_of_interest_list_t     *p_local_area_of_interest_list
)
{
    ngap_AreaOfInterestItem     *p_ngap_area_of_interest_item = NGAP_P_NULL;
    OSRTDListNode               *p_area_of_interest_item_node = NGAP_P_NULL;
    ngap_return_et              response = NGAP_SUCCESS;
    UInt16			            count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_area_of_interest_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO; 
            count <  p_local_area_of_interest_list->count;count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AreaOfInterestItem,
                &p_area_of_interest_item_node,
                &p_ngap_area_of_interest_item);

        if ( (NGAP_P_NULL == p_area_of_interest_item_node) || 
                (NGAP_P_NULL == p_ngap_area_of_interest_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_area_of_interest_item, 
                NGAP_ZERO, sizeof(ngap_AreaOfInterestItem));
        
        
        /*fill areaOfInterest*/
        if(NGAP_FAILURE == ngap_encode_area_of_interest(
                
                    p_asn1_ctx, 
                    &p_ngap_area_of_interest_item->areaOfInterest,
                    &p_local_area_of_interest_list->\
                    area_of_interest_list_item[count].area_of_interest
        ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - Area of interest");
            response = NGAP_FAILURE;
            return response;
        }


        /*fill locationReportingReferenceID*/
        p_ngap_area_of_interest_item->locationReportingReferenceID = 
            p_local_area_of_interest_list->\
                area_of_interest_list_item[count].location_reporting_ref_id;

     
        /* Add  Item to the Node */
        rtxDListAppendNode(p_asn_area_of_interest_list, 
            p_area_of_interest_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;

}

ngap_return_et ngap_encode_expected_ue_moving_trajectory_list
(
    OSCTXT                                  *p_asn1_ctx, 
    ngap_ExpectedUEMovingTrajectory         *p_asn_expected_ue_moving_trajectory,
    ngap_expected_moving_trajectory_list_t  *p_local_expected_ue_moving_trajectory
)
{
    ngap_ExpectedUEMovingTrajectoryItem      *p_ngap_expected_ue_moving_traj_item 
                                                                    = NGAP_P_NULL;
    OSRTDListNode                            *p_expected_ue_moving_traj_item_node
                                                                    = NGAP_P_NULL;
    ngap_return_et                           response               = NGAP_SUCCESS;
    UInt16			                         count                  = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_expected_ue_moving_trajectory->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO; 
            count <  p_local_expected_ue_moving_trajectory->count;count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_ExpectedUEMovingTrajectoryItem,
                &p_expected_ue_moving_traj_item_node,
                &p_ngap_expected_ue_moving_traj_item);

        if ( (NGAP_P_NULL == p_expected_ue_moving_traj_item_node) || 
                (NGAP_P_NULL == p_ngap_expected_ue_moving_traj_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_expected_ue_moving_traj_item, 
                NGAP_ZERO, sizeof(ngap_ExpectedUEMovingTrajectoryItem));
        
        
        if(NGAP_FAILURE == ngap_encode_ng_ran_cgi(
                
                    p_asn1_ctx, 
                    &p_ngap_expected_ue_moving_traj_item->nGRAN_CGI,
                    &p_local_expected_ue_moving_trajectory->\
                    expected_moving_trajectory_item[count].ran_cgi
        ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - NG RAN CGI");
            response = NGAP_FAILURE;
            break;
        }
        
        /*fill timeStayedInCell*/
        /*Handover Bug fixes start*/
        if(NGAP_CNAssisted_TIME_STAYED_IN_CELL_PRESENT & 
                p_local_expected_ue_moving_trajectory->
                expected_moving_trajectory_item[count].bitmask)
        {
            p_ngap_expected_ue_moving_traj_item->m.
                timeStayedInCellPresent =  NGAP_TRUE;

            /*Handover Bug fixes end*/
            p_ngap_expected_ue_moving_traj_item->timeStayedInCell = 
                p_local_expected_ue_moving_trajectory->\
                expected_moving_trajectory_item[count].time_stayed_in_cell;
        }

        /* Add  Item to the Node */
        rtxDListAppendNode(p_asn_expected_ue_moving_trajectory, 
                        p_expected_ue_moving_traj_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;

}


/******************************************************************************
 * Function Name	: ngap_initial_context_setup_req
 * Inputs           : p_ng_setup_req - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes INITIAL CONTEXT SETUP REQUEST ASN message from the information 
 *				   provided in p_initial_context_setup_req
 *****************************************************************************/
ngap_return_et ngap_initial_context_setup_req
(
 ngap_initial_context_setup_request_t    *p_initial_context_setup_req,   /* Input - Local Buffer */
 UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_InitialContextSetupRequest *p_ngap_InitialContextSetupRequest = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_InitialContextSetupRequest = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitialContextSetupRequest);

        if(NGAP_P_NULL ==  p_ngap_InitialContextSetupRequest)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to Initial context setup request */
        asn1SetTC_ngap_InitiatingMessage_initialContextSetup(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_InitialContextSetupRequest);

        /*Encoding of all the IEs starts here*/

        /* Encode IE1 - AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_initial_context_setup_req->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_1(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,"Failed to add IE1 - AMF UE NGAP ID to NGAP PDU");
            break;
        }
        /* Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_initial_context_setup_req->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_2(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,"Failed to add IE2 -RAN UE NGAP ID to NGAP PDU");
            break;
        }

        /* Encode IE3- Old AMF/ AMF NAME */
        if(INITIAL_CONTEXT_SETUP_REQUEST_OLD_AMF_PRESENT  & 
                p_initial_context_setup_req->bitmask)
        {
            ngap_AMFName p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = 
                (ngap_AMFName)p_initial_context_setup_req->amf_name.amf_name;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_3(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Fialed to add IE3- Old AMF/ AMF NAME to NGAP PDU");
                break;
            }
        } 

        /* Encode IE4 - UE Aggregate Maximum Bit Rate */
        if(INITIAL_CONTEXT_SETUP_REQUEST_UE_AGGR_MAX_BIT_RATE_PRESENT  & 
                p_initial_context_setup_req->bitmask)
        {
            ngap_UEAggregateMaximumBitRate *p_value_ie4 = NGAP_P_NULL;
            p_value_ie4  = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_UEAggregateMaximumBitRate);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie4->uEAggregateMaximumBitRateDL = 
                p_initial_context_setup_req->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_dl.bit_rate;

            p_value_ie4->uEAggregateMaximumBitRateUL = 
                p_initial_context_setup_req->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_ul.bit_rate;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_4(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - UE Aggregate Maximum Bit Rate to NGAP PDU");
                break;
            }
        }

        /* Encode IE5 -  Core Network Assistance Information */


        /* Encode IE6 - GUAMI */
        ngap_GUAMI *p_value_ie6 = NGAP_P_NULL;
        p_value_ie6 = rtxMemAllocTypeZ(&asn1_ctx, ngap_GUAMI);

        if(NGAP_P_NULL == p_value_ie6)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_guami(
                    &asn1_ctx,
                    p_value_ie6,
                    &p_initial_context_setup_req->guami))
        {   
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE6 -  GUAMI Failed");
            response = NGAP_FAILURE;
            break;
        }
        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_6(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie6))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE6 -  GUAMI ");
            break;
        }

        /* Encode IE7 - PDU Session Resource Setup Request List */
        if(INITIAL_CONTEXT_SETUP_REQUEST_PDU_SESSION_RESOURCE_SETUP_REQUEST_LIST_PRESENT &
                p_initial_context_setup_req->bitmask)
        {
            ngap_PDUSessionResourceSetupListCxtReq *p_value_ie7 = NGAP_P_NULL;
            p_value_ie7 =
                rtxMemAllocTypeZ(&asn1_ctx, ngap_PDUSessionResourceSetupListCxtReq);

            if(NGAP_P_NULL == p_value_ie7)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == 
                    ngap_encode_ie_pdu_session_resource_setup_request_list(
                        &asn1_ctx, p_value_ie7,
                        &p_initial_context_setup_req->pdu_session_resource_setup_request_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE7- PDU Session"\
                        " Resource Setup Request List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_7(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie7))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE7 -  PDU Session"\
                        "Resource Setup Request List ");
                break;
            }
        }

        /*Encode - Allowed NSSAI*/
        ngap_AllowedNSSAI *p_value_ie8 = NGAP_P_NULL;
        OSRTDList         _ngap_InitialContextSetupRequestIEs_8;

        rtxDListInit(&_ngap_InitialContextSetupRequestIEs_8);
        p_value_ie8 = &_ngap_InitialContextSetupRequestIEs_8;

        if(NGAP_FAILURE == ngap_encode_ie_allowed_nssai(
                    &asn1_ctx,
                    p_value_ie8,
                    &p_initial_context_setup_req->allowed_nssai_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE8 - Allowed NSSAI Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_8(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie8))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE8 - Allowed NSSAI to NGAP PDU");
            break;
        }

        /* Encode - UE Security Capabilities */
        ngap_UESecurityCapabilities *p_value_ie9 = NGAP_P_NULL;
        p_value_ie9 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UESecurityCapabilities);

        if(NGAP_P_NULL == p_value_ie9)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_ue_security_capabilities(
                    &asn1_ctx,
                    p_value_ie9,
                    &p_initial_context_setup_req->ue_security_capabilities))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of IE9 -  UE Security Capabilities Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_9(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie9))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE9 -  UE Security Capabilities");
            break;
        }

        /* Encode - Security Key */
        ngap_SecurityKey *p_value_ie10 = NGAP_P_NULL;
        p_value_ie10 = rtxMemAllocTypeZ(&asn1_ctx, ngap_SecurityKey);

        if(NGAP_P_NULL == p_value_ie10)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie10->numbits = NGAP_SECURITY_KEY_NUMBITS;
        NGAP_MEMCPY(p_value_ie10->data, 
                p_initial_context_setup_req->security_key.security_key,
                NGAP_SECURITY_KEY_OCTET_SIZE);

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupRequest_protocolIEs_10(&asn1_ctx,
                    &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie10))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE10 -  Security Key");
            break;
        }

        /* Encode - Trace Activation*/
        if(INITIAL_CONTEXT_SETUP_REQUEST_TRACE_ACTIVATION_PRESENT & 
                p_initial_context_setup_req->bitmask)
        {
            ngap_TraceActivation *p_value_ie11 = NGAP_P_NULL;
            p_value_ie11 = rtxMemAllocTypeZ(&asn1_ctx, ngap_TraceActivation);

            if(NGAP_P_NULL == p_value_ie11)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_trace_activation(
                        &asn1_ctx,
                        p_value_ie11,
                        &p_initial_context_setup_req->tarce_activation))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE11 - Trace Activation Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_11(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie11))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE11 -  Trace Activation");
                break;
            }
        }

        /* Encode - UE Radio Capability */
        /* Encode - UE Radio Capability */
        if(INITIAL_CONTEXT_SETUP_REQUEST_UE_RADIO_CAPABILITY_PRESENT &
                p_initial_context_setup_req->bitmask)
        {
            ngap_UERadioCapability *p_value_ie13 = NGAP_P_NULL;

            p_value_ie13 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UERadioCapability);

            if(NGAP_P_NULL == p_value_ie13)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie13->numocts = p_initial_context_setup_req->ue_radio_capability.\
                                    ue_radio_capability.num_string_len;

            p_value_ie13->data    = p_initial_context_setup_req->ue_radio_capability.\
                                    ue_radio_capability.string_data;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_13(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie13))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE13 - UE RADIO CAPABILITY");
                break;
            }
        }


        /* Encode - NAS PDU */
        if(INITIAL_CONTEXT_SETUP_REQUEST_NAS_PDU_PRESENT &
                p_initial_context_setup_req->bitmask)
        {
            ngap_NAS_PDU *p_value_ie16 = NGAP_P_NULL;

            p_value_ie16 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

            if (NGAP_P_NULL == p_value_ie16)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie16->numocts = p_initial_context_setup_req->nas_pdu.num_string_len;
            p_value_ie16->data    = p_initial_context_setup_req->nas_pdu.string_data;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_16(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie16))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE16 -  NAS PDU");
                break;
            }
        }

        /* Encode - Mobility Restriction List*/

        if(INITIAL_CONTEXT_SETUP_REQUEST_LOCATION_REPORTING_REQUEST_TYPE_PRESENT &  p_initial_context_setup_req->bitmask)
        {
            ngap_LocationReportingRequestType *p_value_ie21 = NGAP_P_NULL;

            p_value_ie21 = rtxMemAllocTypeZ(&asn1_ctx, ngap_LocationReportingRequestType);
            
            if(NGAP_P_NULL == p_value_ie21)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            } 

            /*fill ecentType*/
            p_value_ie21->eventType = p_initial_context_setup_req->location_reporting_Req_type.eventType;

            /*fill reportArea*/
            p_value_ie21->reportArea = p_initial_context_setup_req->\
                                      location_reporting_Req_type.report_area;

            /*fill area_of_interest*/

            if(NGAP_AREA_OF_LIST_PRESENT & 
                    p_initial_context_setup_req->location_reporting_Req_type.bitmask)
            {

                p_value_ie21->m.areaOfInterestListPresent = NGAP_TRUE;

                /*initialize the list*/
                rtxDListInit(&p_value_ie21->areaOfInterestList);

                if(NGAP_FAILURE == ngap_encode_area_of_interest_list(

                            &asn1_ctx,
                            &p_value_ie21->areaOfInterestList,
                            &p_initial_context_setup_req->\
                            location_reporting_Req_type.area_of_interest

                            ))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "Encoding of IE21 -  Area Of interest List");
                    response = NGAP_FAILURE;
                    break;
                }
            }

            /*fill_locationReportingReferenceIdToBeCancelled*/
            if(NGAP_LOCATION_REPORTING_REFERENCE_ID_TO_BE_CANCELLED_PRESENT & 
                    p_initial_context_setup_req->location_reporting_Req_type.bitmask)
            {
                p_value_ie21->m.locationReportingReferenceIDToBeCancelledPresent = 
                    NGAP_TRUE;

                p_value_ie21->locationReportingReferenceIDToBeCancelled = 
                    p_initial_context_setup_req->location_reporting_Req_type.\
                    location_reporting_ref_id_to_be_cancelled;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_21(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie21
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE21 - Location Reporting Request type");
                break;
            }
        }

        if(INITIAL_CONTEXT_SETUP_REQUEST_CNASSITED_RAN_TUNING_PRESENT &  
                p_initial_context_setup_req->bitmask)
        {

            ngap_CNAssistedRANTuning    *p_value_ie22;

            p_value_ie22 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CNAssistedRANTuning);
            
            if(NGAP_P_NULL == p_value_ie22)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            if(NGAP_CNAssisted_EXPECTED_UE_BEHAVIOUR_PRESENT & 
                    p_initial_context_setup_req->can_assisted_ran_tuning.bitmask)
            {
                p_value_ie22->m.expectedUEBehaviourPresent = NGAP_TRUE;

                /*fill expected_ue_activity_behaviour*/
                if(NGAP_CNAssisted_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT & 
                        p_initial_context_setup_req->\
                        can_assisted_ran_tuning.expected_ue_behaviour.bitmask)
                {
                    p_value_ie22->expectedUEBehaviour.m.\
                        expectedUEActivityBehaviourPresent = NGAP_TRUE;

                    if(NGAP_CNAssisted_EXPECTED_ACTIVITY_PERIOD_PRESENT & 
                            p_initial_context_setup_req->\
                            can_assisted_ran_tuning.expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            expectedActivityPeriodPresent = NGAP_TRUE;

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            expectedActivityPeriod =
                            p_initial_context_setup_req->can_assisted_ran_tuning.\
                            expected_ue_behaviour.expected_ue_activity_behaviour.\
                            expected_activity_period;

                    }

                    if(NGAP_CNAssisted_EXPECTED_IDLE_PERIOD_PRESENT & 
                            p_initial_context_setup_req->\
                            can_assisted_ran_tuning.expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            expectedIdlePeriodPresent = NGAP_TRUE;

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            expectedIdlePeriod =
                            p_initial_context_setup_req->can_assisted_ran_tuning.\
                            expected_ue_behaviour.expected_ue_activity_behaviour.\
                            expected_idle_period;
                    }

                    if(NGAP_CNAssisted_EXPECTED_SOURCE_OF_UE_ACTIVITY_BEHAVIOUR_INFORMATION & 
                            p_initial_context_setup_req->\
                            can_assisted_ran_tuning.expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            sourceOfUEActivityBehaviourInformationPresent = 
                            NGAP_TRUE;

                        p_value_ie22->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            sourceOfUEActivityBehaviourInformation =
                            p_initial_context_setup_req->can_assisted_ran_tuning.\
                            expected_ue_behaviour.expected_ue_activity_behaviour.\
                            source_of_ue_activity_behaviour_info;
                    }


                }

                /*fill expected_ho_interval*/
                if(NGAP_CNAssisted_EXPECTED_HO_INTERVAL_PRESENT &   
                        p_initial_context_setup_req->\
                        can_assisted_ran_tuning.expected_ue_behaviour.bitmask)
                {
                    p_value_ie22->expectedUEBehaviour.m.\
                        expectedHOIntervalPresent = NGAP_TRUE; 

                    p_value_ie22->expectedUEBehaviour.expectedHOInterval = 
                        p_initial_context_setup_req->can_assisted_ran_tuning.\
                        expected_ue_behaviour.expected_ho_interval; 
                }

                /*fill expected_ue_mobility*/
                if(NGAP_CNAssisted_EXPECTED_UE_MOBILITY_PRESENT &   
                        p_initial_context_setup_req->\
                        can_assisted_ran_tuning.expected_ue_behaviour.bitmask)
                {
                    p_value_ie22->expectedUEBehaviour.m.\
                        expectedUEMobilityPresent = NGAP_TRUE; 

                    p_value_ie22->expectedUEBehaviour.expectedUEMobility = 
                        p_initial_context_setup_req->can_assisted_ran_tuning.\
                        expected_ue_behaviour.expected_ue_mobility; 
                }

                /*fill expected_moving_trajectory*/
                if(NGAP_CNAssisted_EXPECTED_MOVING_TRAJECTORY_PRESENT &   
                        p_initial_context_setup_req->\
                        can_assisted_ran_tuning.expected_ue_behaviour.bitmask)
                {
                    p_value_ie22->expectedUEBehaviour.m.\
                        expectedUEMovingTrajectoryPresent = NGAP_TRUE; 

                    if(NGAP_FAILURE==ngap_encode_expected_ue_moving_trajectory_list(
                                &asn1_ctx,
                                &p_value_ie22->expectedUEBehaviour.\
                                expectedUEMovingTrajectory,
                                &p_initial_context_setup_req->\
                                can_assisted_ran_tuning.expected_ue_behaviour.\
                                expected_moving_trajectory

                                ))
                    {
                        RRC_NGAP_TRACE(NGAP_ERROR, "Could not encode IE - Expected UE Moving Trajectory");
                        response = NGAP_FAILURE;
                        break;
                    }
                }
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupRequest_protocolIEs_22(&asn1_ctx,
                        &p_ngap_InitialContextSetupRequest->protocolIEs, p_value_ie22
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE21 - CNAssisted Tuning");
                break;
            }

        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for NG INITIAL CONTEXT SETUP");
            response = NGAP_FAILURE;
            break;
        } 

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of UL NAS Transport Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
/*HandOver changes strat */

ngap_return_et ngap_encode_ie_cn_assisted_ran_tuning
(
OSCTXT                          *p_asn1_ctx,
ngap_CNAssistedRANTuning        *p_value,
ngap_CNAssisted_ran_tuning_t    *p_local
)
{

    ngap_return_et              response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();


            if(NGAP_CNAssisted_EXPECTED_UE_BEHAVIOUR_PRESENT & 
                p_local->bitmask)
            {
                p_value->m.expectedUEBehaviourPresent = NGAP_TRUE;
                
                /*fill expected_ue_activity_behaviour*/
                if(NGAP_CNAssisted_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT & 
                        p_local->expected_ue_behaviour.bitmask)
                {
                    p_value->expectedUEBehaviour.m.\
                    expectedUEActivityBehaviourPresent = NGAP_TRUE;
                    
                    if(NGAP_CNAssisted_EXPECTED_ACTIVITY_PERIOD_PRESENT & 
                            p_local->expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            expectedActivityPeriodPresent = NGAP_TRUE;

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            expectedActivityPeriod =
                           p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                            expected_activity_period;

                    }

                    if(NGAP_CNAssisted_EXPECTED_IDLE_PERIOD_PRESENT & 
                            p_local->expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            expectedIdlePeriodPresent = NGAP_TRUE;

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            expectedIdlePeriod =
                            p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                            expected_idle_period;
                    }
                    
                    if(NGAP_CNAssisted_EXPECTED_SOURCE_OF_UE_ACTIVITY_BEHAVIOUR_INFORMATION & 
                            p_local->expected_ue_behaviour.\
                            expected_ue_activity_behaviour.bitmask)
                    {

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.m.\
                            sourceOfUEActivityBehaviourInformationPresent = 
                            NGAP_TRUE;

                        p_value->expectedUEBehaviour.\
                            expectedUEActivityBehaviour.\
                            sourceOfUEActivityBehaviourInformation =
                            p_local->expected_ue_behaviour.expected_ue_activity_behaviour.\
                            source_of_ue_activity_behaviour_info;
                    }


                   }

                /*fill expected_ho_interval*/
                if(NGAP_CNAssisted_EXPECTED_HO_INTERVAL_PRESENT &   
                        p_local->\
                        expected_ue_behaviour.bitmask)
                {
                   p_value->expectedUEBehaviour.m.\
                    expectedHOIntervalPresent = NGAP_TRUE; 

                    p_value->expectedUEBehaviour.expectedHOInterval = 
                       p_local->expected_ue_behaviour.expected_ho_interval; 
                }
                
                /*fill expected_ue_mobility*/
                if(NGAP_CNAssisted_EXPECTED_UE_MOBILITY_PRESENT &   
                        p_local->expected_ue_behaviour.bitmask)
                {
                   p_value->expectedUEBehaviour.m.\
                   expectedUEMobilityPresent = NGAP_TRUE; 
                    
                   p_value->expectedUEBehaviour.expectedUEMobility = 
                        p_local->expected_ue_behaviour.expected_ue_mobility; 
                }

                /*fill expected_moving_trajectory*/
                if(NGAP_CNAssisted_EXPECTED_MOVING_TRAJECTORY_PRESENT &   
                        p_local->expected_ue_behaviour.bitmask)
                {
                   p_value->expectedUEBehaviour.m.\
                   expectedUEMovingTrajectoryPresent = NGAP_TRUE; 
                    
                   if(NGAP_FAILURE==ngap_encode_expected_ue_moving_trajectory_list(
                       p_asn1_ctx,
                       &p_value->expectedUEBehaviour.\
                       expectedUEMovingTrajectory,
                       &p_local->expected_ue_behaviour.\
                       expected_moving_trajectory ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                       "Could not encode IE - Expected UE Moving Trajectory");
            response = NGAP_FAILURE;
                        return response;                      
        } 
        }
        }


    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/*HandOver changes end */

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_setup_unsuccessful_transfer
 * Inputs           : p_asn1_ctx
 *                      p_local
 * Outputs          : p_value
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_setup_unsuccessful_transfer
(
 OSDynOctStr                                                 *p_value,
 ngap_pdu_session_resource_setup_unsuccessful_transfer_t     *p_local
 )
{
    ngap_PDUSessionResourceSetupUnsuccessfulTransfer    *pdu_session_un_transfer;
    OSCTXT                                              asn1_ctx1;
    ngap_return_et                                      response = NGAP_SUCCESS;
    UInt8                                               encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error 
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {

        pdu_session_un_transfer = 
            rtxMemAllocTypeZ(&asn1_ctx1,
                    ngap_PDUSessionResourceSetupUnsuccessfulTransfer);

        switch(p_local->choice_cause_group.choice_type)
        {
            case NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER:
            {
                pdu_session_un_transfer->cause.t = T_ngap_Cause_radioNetwork;
                pdu_session_un_transfer->cause.u.radioNetwork = 
                    p_local->choice_cause_group.radio_network_layer_cause_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER:                  
            {                                                                  
                pdu_session_un_transfer->cause.t = T_ngap_Cause_transport;
                pdu_session_un_transfer->cause.u.transport =
                    p_local->choice_cause_group.transport_layer_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE:                  
            {                                                                  
                pdu_session_un_transfer->cause.t = T_ngap_Cause_nas;
                pdu_session_un_transfer->cause.u.nas =
                    p_local->choice_cause_group.nas_cause_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE:                  
            {                                                                  
                pdu_session_un_transfer->cause.t = T_ngap_Cause_protocol;
                pdu_session_un_transfer->cause.u.protocol =
                    p_local->choice_cause_group.protocol_cause_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE:                  
            {                                                                  
                pdu_session_un_transfer->cause.t = T_ngap_Cause_misc;
                pdu_session_un_transfer->cause.u.misc =
                    p_local->choice_cause_group.miscellaneous_cause_event_id;
                break;

            }
            case NGAP_CAUSE_GROUP_CHOICE_INVALID_CAUSE:
            {                                                                  
                pdu_session_un_transfer->cause.t = T_ngap_Cause_choice_Extensions;
                break;
            }                                                                                                                                    
        }


        if(p_local->bitmask == NGAP_PSRSUT_CIRITCALITY_DIAGNOSTICS_PRESENT)
        {
            pdu_session_un_transfer->m.criticalityDiagnosticsPresent = NGAP_TRUE;
            switch(p_local->criticality_diagnostics.bitmask)
            {
                case NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CODE:
                {
                    pdu_session_un_transfer->criticalityDiagnostics.\
                        m.procedureCodePresent = NGAP_TRUE;
                    pdu_session_un_transfer->criticalityDiagnostics.procedureCode = 
                        p_local->criticality_diagnostics.procedure_code;
                    break;
                }
                case NGAP_CRITICALITY_DIAGNOSTICS_TRIGGERING_MESSAGE:
                {
                    pdu_session_un_transfer->criticalityDiagnostics.\
                        m.triggeringMessagePresent = NGAP_TRUE;
                    pdu_session_un_transfer->criticalityDiagnostics.\
                        triggeringMessage = 
                        p_local->criticality_diagnostics.triggering_message_event_id;
                    break;
                }
                case NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CRITICALITY:
                {
                    pdu_session_un_transfer->criticalityDiagnostics.\
                        m.procedureCriticalityPresent = NGAP_TRUE;
                    pdu_session_un_transfer->criticalityDiagnostics.procedureCriticality =
                        p_local->criticality_diagnostics.procedure_criticality_event_id;
                    break;
                }
                case NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_IE_LIST:
                {
                    pdu_session_un_transfer->criticalityDiagnostics.\
                        m.iEsCriticalityDiagnosticsPresent = NGAP_TRUE;
                    response = ngap_encode_criticality_diagnostics_ie_list(
                            &asn1_ctx1,
                            &pdu_session_un_transfer->criticalityDiagnostics.\
                            iEsCriticalityDiagnostics,
                            &p_local->criticality_diagnostics.cd_ie_list);
                    break;
                }
            }
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for PDU session resource setup unsuccessful transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PE_ngap_PDUSessionResourceSetupUnsuccessfulTransfer(&asn1_ctx1, 
                    pdu_session_un_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of PDU session resource setup unsuccessful transfer");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceSetupUnsuccessfulTransfer(
                    &asn1_ctx1,
                    "PDU_SESSION_RESOURCE_SETUP_UNSUCCESSFUL_TRANSFER_PDU", 
                    pdu_session_un_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_criticality_diagnostics_ie_list
 * Inputs           : p_asn1_ctx
 *                      p_local_ngap_criticality_diagnostics_ie_list
 * Outputs          : p_ngap_asn_ies_criticality_diagnostics
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_criticality_diagnostics_ie_list
(
 OSCTXT                                  *p_asn1_ctx,
 ngap_CriticalityDiagnostics_IE_List     *p_ngap_asn_ies_criticality_diagnostics,
 ngap_criticality_diagnostics_ie_list_t  *p_local_ngap_criticality_diagnostics_ie_list
 )
{
    ngap_CriticalityDiagnostics_IE_Item *p_ngap_criticality_diagnostics_ie_item;
    OSRTDListNode                       *p_node = NGAP_P_NULL;
    ngap_return_et                      response = NGAP_SUCCESS;
    UInt16                              count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_ngap_criticality_diagnostics_ie_list->no_of_errors)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    p_ngap_asn_ies_criticality_diagnostics =                                               
        (ngap_CriticalityDiagnostics_IE_List *)
        rtxMemAllocTypeZ(p_asn1_ctx, ngap_CriticalityDiagnostics_IE_List);  

    if(NGAP_P_NULL == p_ngap_asn_ies_criticality_diagnostics)
    {                                                                                   
        NGAP_SYSTEM_MEM_FAIL();                                                         
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO;
            count < p_local_ngap_criticality_diagnostics_ie_list->no_of_errors;
            count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_CriticalityDiagnostics_IE_Item,
                &p_node,
                &p_ngap_criticality_diagnostics_ie_item);

        if ( (NGAP_P_NULL == p_node) || 
                (NGAP_P_NULL == p_ngap_criticality_diagnostics_ie_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_criticality_diagnostics_ie_item, NGAP_ZERO, 
                sizeof(ngap_CriticalityDiagnostics_IE_Item));

        /*encode qosFlowIdentifier*/
        p_ngap_criticality_diagnostics_ie_item->iECriticality =
            p_local_ngap_criticality_diagnostics_ie_list->\
            criticality_diagnostics_ie[count].ie_criticality;

        p_ngap_criticality_diagnostics_ie_item->iE_ID =
            p_local_ngap_criticality_diagnostics_ie_list->\
            criticality_diagnostics_ie[count].ie_id;

        p_ngap_criticality_diagnostics_ie_item->typeOfError =
            p_local_ngap_criticality_diagnostics_ie_list->\
            criticality_diagnostics_ie[count].type_of_error;

    }
    return response;
} 

/******************************************************************************
 * Function Name    : ngap_encode_qos_flow_failed_setup_list
 * Inputs           : p_asn1_ctx
 *                      p_local_qos_flow_failed_to_setup_list
 * Outputs          : p_ngap_asn_qos_flow_failed_setup_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_qos_flow_failed_setup_list
(
 OSCTXT                          *p_asn1_ctx,
 ngap_QosFlowListWithCause       *p_ngap_asn_qos_flow_failed_setup_list,
 ngap_qos_flow_list_t            *p_local_qos_flow_failed_to_setup_list
 )
{
    ngap_QosFlowWithCauseItem       *p_ngap_asn_qos_flow_item;
    OSRTDListNode                   *p_node = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;
    UInt16                          count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_local_qos_flow_failed_to_setup_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }



    for (count = NGAP_ZERO;
            count < p_local_qos_flow_failed_to_setup_list->count; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowWithCauseItem,
                &p_node,
                &p_ngap_asn_qos_flow_item);

        if ( (NGAP_P_NULL == p_node) || (NGAP_P_NULL == p_ngap_asn_qos_flow_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_asn_qos_flow_item, NGAP_ZERO,
                sizeof(ngap_QosFlowWithCauseItem));

        /*encode qosFlowIdentifier*/
        p_ngap_asn_qos_flow_item->qosFlowIdentifier  =
            p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
            qos_flow_identifier;

        switch(p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                choice_cause_group.choice_type)
        {
            case NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER:
            {
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_radioNetwork;
                p_ngap_asn_qos_flow_item->cause.u.radioNetwork = 
                    p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                    choice_cause_group.radio_network_layer_cause_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER:                  
            {                                                                  
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_transport;
                p_ngap_asn_qos_flow_item->cause.u.transport =
                    p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                    choice_cause_group.transport_layer_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE:                  
            {                                                                  
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_nas;
                p_ngap_asn_qos_flow_item->cause.u.nas =
                    p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                    choice_cause_group.nas_cause_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE:                  
            {                                                                  
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_protocol;
                p_ngap_asn_qos_flow_item->cause.u.protocol =
                    p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                    choice_cause_group.protocol_cause_event_id;
                break;
            }                                                                  
            case NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE:                  
            {                                                                  
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_misc;
                p_ngap_asn_qos_flow_item->cause.u.misc =
                    p_local_qos_flow_failed_to_setup_list->ngap_qos_flow_item[count].\
                    choice_cause_group.miscellaneous_cause_event_id;
                break;

            }
            case NGAP_CAUSE_GROUP_CHOICE_INVALID_CAUSE:
            {                                                                  
                p_ngap_asn_qos_flow_item->cause.t = T_ngap_Cause_choice_Extensions;
                break;
            }                                                                                                                                    
        }

        rtxDListAppendNode(p_ngap_asn_qos_flow_failed_setup_list, p_node);

    }
    return response;
}    

/******************************************************************************
 * Function Name    : ngap_encode_ie_additional_qos_flow_response_setup_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_associated_qos_flow_list
 * Outputs          : p_ngap_asn_associated_qos_flow_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_additional_qos_flow_response_setup_list
(
 OSCTXT                          *p_asn1_ctx,
 ngap_AssociatedQosFlowList      *p_ngap_asn_associated_qos_flow_list,
 ngap_associated_flow_list_t     *p_ngap_local_associated_qos_flow_list
 )
{
    ngap_AssociatedQosFlowItem      *p_ngap_asn_associated_qos_flow_item;
    OSRTDListNode                   *p_node = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;
    UInt16                          count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_ngap_local_associated_qos_flow_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;

    }

    for (count = NGAP_ZERO;
            count < p_ngap_local_associated_qos_flow_list->count; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AssociatedQosFlowItem,
                &p_node,
                &p_ngap_asn_associated_qos_flow_item);

        if ( (NGAP_P_NULL == p_node) || 
                (NGAP_P_NULL == p_ngap_asn_associated_qos_flow_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_asn_associated_qos_flow_item, NGAP_ZERO, 
                sizeof(ngap_AssociatedQosFlowItem));

        /*encode qosFlowIdentifier*/
        p_ngap_asn_associated_qos_flow_item->qosFlowIdentifier  =
            p_ngap_local_associated_qos_flow_list->associated_flow_item[count].\
            qos_flow_identifier;

        /*encode qosCharacteristics*/

        if(p_ngap_local_associated_qos_flow_list->associated_flow_item[count].bitmask ==
                NGAP_QOS_FLOW_MAPPING_INDICATION_PRESENT)
        {
            p_ngap_asn_associated_qos_flow_item->m.qosFlowMappingIndicationPresent = 
                NGAP_TRUE;

            p_ngap_asn_associated_qos_flow_item->qosFlowMappingIndication =
                p_ngap_local_associated_qos_flow_list->associated_flow_item[count].\
                qos_flow_mapping_indication;
        }

        rtxDListAppendNode(p_ngap_asn_associated_qos_flow_list, p_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}    

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_setup_res_transfer
 * Inputs           : p_asn1_ctx
 *                      p_local
 * Outputs          : p_value
 *
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *
 * DESCRIPTION      : This function fill ASN Structure using local structure
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_setup_res_transfer
(
 OSDynOctStr                                                 *p_value,
 ngap_pdu_session_resource_setup_response_transfer_t         *p_local
 )
{
    ngap_PDUSessionResourceSetupResponseTransfer    *pdu_session_res_transfer = NGAP_P_NULL;
    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {

        pdu_session_res_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_PDUSessionResourceSetupResponseTransfer);

        if(NGAP_P_NULL == pdu_session_res_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE dLQosFlowPerTNLInformation */
        pdu_session_res_transfer->dLQosFlowPerTNLInformation.uPTransportLayerInformation.\
            u.gTPTunnel =
            (ngap_GTPTunnel *)rtxMemAllocTypeZ(&asn1_ctx1, ngap_GTPTunnel);

        if(NGAP_P_NULL == pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                uPTransportLayerInformation.u.gTPTunnel)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        switch(p_local->qos_flow_TNL_info.up_transport_layer_info.choice_type)
        {
            case UP_TRANSPORT_LAYER_INFO_GP_TUNNEL:
            {
                pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                    uPTransportLayerInformation.t =
                    T_ngap_UPTransportLayerInformation_gTPTunnel;



                if (p_local->pdu_session_type == PDU_SESSION_TYPE_IPV4)
                {
                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                                NGAP_TRANSPORT_LAYER_ADDRESS_IPV4_OCTET_SIZE);

                    if(NGAP_P_NULL == pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                            uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.data)
                    {
                        NGAP_SYSTEM_MEM_FAIL();
                        response = NGAP_FAILURE;
                        break;
                    }

                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        numbits = NGAP_TRANSPORT_LAYER_ADDRESS_IPV4_NUMBITS;

                    NGAP_MEMCPY((void *)pdu_session_res_transfer->\
                            dLQosFlowPerTNLInformation.uPTransportLayerInformation.u.\
                            gTPTunnel->transportLayerAddress.data,
                            p_local->qos_flow_TNL_info.up_transport_layer_info.gtp_tunnel.\
                            transport_layer_address,
                            NGAP_TRANSPORT_LAYER_ADDRESS_IPV4_OCTET_SIZE);
                }
                else if (p_local->pdu_session_type == PDU_SESSION_TYPE_IPV6)
                {
                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                                NGAP_TRANSPORT_LAYER_ADDRESS_IPV6_OCTET_SIZE);

                    if(NGAP_P_NULL == pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                            uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.data)
                    {
                        NGAP_SYSTEM_MEM_FAIL();
                        response = NGAP_FAILURE;
                        break;
                    }

                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        numbits = NGAP_TRANSPORT_LAYER_ADDRESS_IPV6_NUMBITS;

                    NGAP_MEMCPY((void *)pdu_session_res_transfer->\
                            dLQosFlowPerTNLInformation.uPTransportLayerInformation.u.\
                            gTPTunnel->transportLayerAddress.data,
                            p_local->qos_flow_TNL_info.up_transport_layer_info.gtp_tunnel.\
                            transport_layer_address,
                            NGAP_TRANSPORT_LAYER_ADDRESS_IPV6_OCTET_SIZE);
                }
                else if (p_local->pdu_session_type == PDU_SESSION_TYPE_IPV4V6)
                {
                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                                NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                    if(NGAP_P_NULL == pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                            uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.data)
                    {
                        NGAP_SYSTEM_MEM_FAIL();
                        response = NGAP_FAILURE;
                        break;
                    }

                    pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->transportLayerAddress.\
                        numbits = NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                    NGAP_MEMCPY((void *)pdu_session_res_transfer->\
                            dLQosFlowPerTNLInformation.uPTransportLayerInformation.u.\
                            gTPTunnel->transportLayerAddress.data,
                            p_local->qos_flow_TNL_info.up_transport_layer_info.gtp_tunnel.\
                            transport_layer_address,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);
                }
                else
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "Pdu session type : %d not supported",\
                            p_local->pdu_session_type);
                }
                
                /*encode gtp_TEID*/
                pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                    uPTransportLayerInformation.u.gTPTunnel->gTP_TEID.numocts =
                    NGAP_GTP_TUNNEL_TEID;

                NGAP_MEMCPY
                    (
                     (void *)pdu_session_res_transfer->dLQosFlowPerTNLInformation.\
                     uPTransportLayerInformation.u.gTPTunnel->gTP_TEID.data,
                     &p_local->qos_flow_TNL_info.up_transport_layer_info.gtp_tunnel.\
                     gtp_TEID,
                     NGAP_GTP_TUNNEL_TEID
                    );

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Invalid choice for gtp Tunnel");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode ngap_associated_flow_list_t*/
        if(NGAP_FAILURE == ngap_encode_ie_additional_qos_flow_response_setup_list(
                    &asn1_ctx1,
                    &pdu_session_res_transfer->dLQosFlowPerTNLInformation.associatedQosFlowList,
                    &p_local->qos_flow_TNL_info.associated_qos_flow_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE3 ASSOCIATED QOS FLOW List failed");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE additional_qos_flow_TNL_info */
        if(p_local->bitmask &
                NGAP_ADDITIONAL_QOS_FLOW_PER_TNL_INFORMATION_PRESENT)
        {
            pdu_session_res_transfer->m.additionalDLQosFlowPerTNLInformationPresent =
                NGAP_TRUE;
            if(NGAP_FAILURE == ngap_encode_ie_addnl_qos_flow_tnl_info(
                        &asn1_ctx1,
                        &pdu_session_res_transfer->additionalDLQosFlowPerTNLInformation,
                        &p_local->additional_qos_flow_TNL_info))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode ie additional_qos_flow_TNL_info");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* Encode IE security_result */
        if(p_local->bitmask &
                NGAP_SECURITY_RESULT_PRESENT)
        {
            pdu_session_res_transfer->m.securityResultPresent = RRC_TRUE;
            pdu_session_res_transfer->securityResult.integrityProtectionResult =
                p_local->security_result.integrity_protection_result;
            pdu_session_res_transfer->securityResult.confidentialityProtectionResult =
                p_local->security_result.confidentiality_protection_result;

        }

        /* Encode IE qos_flow_failed_to_setup_list*/
        if(p_local->bitmask &
                NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST)
        {
            pdu_session_res_transfer->m.qosFlowFailedToSetupListPresent = RRC_TRUE;
            if(NGAP_FAILURE == ngap_encode_qos_flow_failed_setup_list(
                        &asn1_ctx1,
                        &pdu_session_res_transfer->qosFlowFailedToSetupList,
                        &p_local->qos_flow_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3 ASSOCIATED QOS FLOW List failed");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE)) 
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for PDU session resource setup res transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_PDUSessionResourceSetupResponseTransfer(&asn1_ctx1,
                    pdu_session_res_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of PDU session resource setup res transfer Failed"); 
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */

            ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer(NGAP_ASN, 
                    (SInt8 *)"NGAP_PDUSessionResourceSetupResponseTransfer", 
                    pdu_session_res_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_addnl_qos_flow_tnl_info
 * Inputs           : p_asn1_ctx
 *                    p_local_addnl_qos_flow_tnl_info_list
 * Outputs          : p_asn_addnl_qos_flow_tnl_info_list
 *
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *
 * DESCRIPTION      : This function fill ASN Structure using local structure
 *****************************************************************************/
ngap_return_et ngap_encode_ie_addnl_qos_flow_tnl_info
(
 OSCTXT                                 *p_asn1_ctx,
 ngap_QosFlowPerTNLInformationList      *p_asn_addnl_qos_flow_tnl_info_list,
 ngap_dl_qos_flow_per_TNL_info_list_t   *p_local_addnl_qos_flow_tnl_info_list
 )
{
    ngap_QosFlowPerTNLInformationItem    *p_qos_flow_per_tnl_item = NGAP_P_NULL;
    OSRTDListNode                        *p_node = NGAP_P_NULL;
    ngap_return_et                       response  = NGAP_SUCCESS;
    UInt16                               index   = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_addnl_qos_flow_tnl_info_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "LIST is empty");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_addnl_qos_flow_tnl_info_list->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowPerTNLInformationItem,
                &p_node,
                &p_qos_flow_per_tnl_item);

        if ((NGAP_P_NULL == p_node) ||
                (NGAP_P_NULL == p_qos_flow_per_tnl_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET(p_qos_flow_per_tnl_item,
                NGAP_ZERO, sizeof(ngap_QosFlowPerTNLInformationItem));

        /*encode up_transport_layer_info */
        switch(p_local_addnl_qos_flow_tnl_info_list->\
                dl_qos_flow_per_TNL_info_item[index].\
                dl_qos_flow_per_TNL_info.up_transport_layer_info.choice_type)
        {
            case UP_TRANSPORT_LAYER_INFO_GP_TUNNEL:
            {
                p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    uPTransportLayerInformation.t =
                    T_ngap_UPTransportLayerInformation_gTPTunnel;

                p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    uPTransportLayerInformation.u.gTPTunnel =
                    (ngap_GTPTunnel *)rtxMemAllocTypeZ(p_asn1_ctx, ngap_GTPTunnel);

                if(NGAP_P_NULL == p_qos_flow_per_tnl_item->\
                        qosFlowPerTNLInformation.uPTransportLayerInformation.\
                        u.gTPTunnel)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    uPTransportLayerInformation.u.gTPTunnel->\
                    transportLayerAddress.numbits =
                    NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    uPTransportLayerInformation.u.gTPTunnel->\
                    transportLayerAddress.data =
                    (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                if(NGAP_P_NULL == p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                        uPTransportLayerInformation.u.gTPTunnel->\
                        transportLayerAddress.data)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMCPY
                    (
                     (void *)p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                     uPTransportLayerInformation.u.gTPTunnel->\
                     transportLayerAddress.data,
                     p_local_addnl_qos_flow_tnl_info_list->\
                     dl_qos_flow_per_TNL_info_item[index].\
                     dl_qos_flow_per_TNL_info.up_transport_layer_info.\
                     gtp_tunnel.transport_layer_address,
                     NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                    );

                /*encode gtp_TEID*/
                p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    uPTransportLayerInformation.u.gTPTunnel->gTP_TEID.numocts =
                    NGAP_GTP_TUNNEL_TEID;

                NGAP_MEMCPY
                    (
                     (void *)p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                     uPTransportLayerInformation.u.gTPTunnel->gTP_TEID.data,
                     &p_local_addnl_qos_flow_tnl_info_list->\
                     dl_qos_flow_per_TNL_info_item[index].\
                     dl_qos_flow_per_TNL_info.up_transport_layer_info.\
                     gtp_tunnel.gtp_TEID,
                     NGAP_GTP_TUNNEL_TEID
                    );

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Invalid Value of choice_type");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* encode IE associated_qos_flow_list */

        if(NGAP_FAILURE == ngap_encode_ie_additional_qos_flow_response_setup_list(
                    p_asn1_ctx,
                    &p_qos_flow_per_tnl_item->qosFlowPerTNLInformation.\
                    associatedQosFlowList,
                    &p_local_addnl_qos_flow_tnl_info_list->\
                    dl_qos_flow_per_TNL_info_item[index].\
                    dl_qos_flow_per_TNL_info.associated_qos_flow_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding ASSOCIATED QOS FLOW List failed");
            response = NGAP_FAILURE;
            break;
        }

        rtxDListAppendNode(p_asn_addnl_qos_flow_tnl_info_list, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_setup_req_transfer
 * Inputs           : p_asn1_ctx
 *                      p_local
 * Outputs          : p_value
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_setup_req_transfer
(
 OSDynOctStr                                                 *p_value,
 ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local
 )
{
    ngap_PDUSessionResourceSetupRequestTransfer     *p_pdu_session_req_transfer;
    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }

    do
    {
        p_pdu_session_req_transfer = 
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_PDUSessionResourceSetupRequestTransfer);

        if(NGAP_P_NULL == p_pdu_session_req_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE1 - maximum_bit_rate  */
        if(PSSRT_PDU_SESSION_MAXIMUM_AGGREGATE_MAXIMUM_BIT_RATE_PRESENT & 
                p_local->bitmask)
        {
            ngap_PDUSessionAggregateMaximumBitRate  *p_aggr_max_bit_rate = 
                NGAP_P_NULL;

            p_aggr_max_bit_rate = rtxMemAllocTypeZ(&asn1_ctx1, 
                    ngap_PDUSessionAggregateMaximumBitRate);

            p_aggr_max_bit_rate->pDUSessionAggregateMaximumBitRateDL = 
                p_local->maximum_bit_rate.maximum_bit_rate_dl;

            p_aggr_max_bit_rate->pDUSessionAggregateMaximumBitRateUL = 
                p_local->maximum_bit_rate.maximum_bit_rate_ul;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_1(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        p_aggr_max_bit_rate))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - MAXIMUM AGGREGATE BIT RATE");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode IE - up_transport_layer_info*/
        ngap_UPTransportLayerInformation    *p_up_transport_layer_information;
        
        p_up_transport_layer_information = rtxMemAllocTypeZ(&asn1_ctx1, ngap_UPTransportLayerInformation);
            
        if(NGAP_P_NULL == p_up_transport_layer_information)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        } 

        switch(p_local->up_transport_layer_info.choice_type)
        {
            case UP_TRANSPORT_LAYER_INFO_GP_TUNNEL:
            {
                p_up_transport_layer_information->t = 
                    T_ngap_UPTransportLayerInformation_gTPTunnel;

                p_up_transport_layer_information->u.gTPTunnel = 
                    (ngap_GTPTunnel *)rtxMemAllocTypeZ(&asn1_ctx1, ngap_GTPTunnel);

                if(NGAP_P_NULL == 
                        p_up_transport_layer_information->u.gTPTunnel)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                /* Encode transportLayerAddress*/
                p_up_transport_layer_information->u.gTPTunnel->transportLayerAddress.\
                    numbits = NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                p_up_transport_layer_information->u.gTPTunnel->transportLayerAddress.\
                    data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                if(NGAP_P_NULL == 
                        p_up_transport_layer_information->u.gTPTunnel->\
                        transportLayerAddress.data)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMCPY
                    (
                     (void *)p_up_transport_layer_information->u.gTPTunnel->\
                     transportLayerAddress.data,
                     p_local->up_transport_layer_info.gtp_tunnel.\
                     transport_layer_address,
                     NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                    );

                /* Encode gtp_TEID */
                p_up_transport_layer_information->u.gTPTunnel->gTP_TEID.numocts = 
                    NGAP_GTP_TUNNEL_TEID;

                NGAP_MEMCPY
                    (
                     (void *)p_up_transport_layer_information->u.gTPTunnel->gTP_TEID.data,
                     &p_local->up_transport_layer_info.gtp_tunnel.gtp_TEID,
                     NGAP_GTP_TUNNEL_TEID
                    );

                break;
            }
        }

        if (NGAP_FAILURE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - UP TRANSPORT LAYER INFO");
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_2(
                    &asn1_ctx1,
                    &p_pdu_session_req_transfer->protocolIEs, 
                    p_up_transport_layer_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - UP TRANSPORT LAYER INFO");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE - additional_up_layer_info */
        if(PSSRT_ADDITIONAL_UP_LAYER_TRANSFER_PRESENT & p_local->bitmask)
        {
            ngap_UPTransportLayerInformationList *p_addnl_up_transport_layer_information;
        
            p_addnl_up_transport_layer_information = rtxMemAllocTypeZ(&asn1_ctx1, ngap_UPTransportLayerInformationList);

            if(NGAP_P_NULL == p_addnl_up_transport_layer_information)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_addnl_up_transport_layer_info_list(
                        &asn1_ctx1,
                        p_addnl_up_transport_layer_information,
                        &p_local->additional_up_layer_info
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3- ADDITIONAL UP TRANSPORT LAYER INFO List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_3(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs,
                        p_addnl_up_transport_layer_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - ADDITIONAL UP TRANSPORT LAYER INFO");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* Encode data_forwarding_not_possible */
        if(PSSRT_DATA_FORWARDING_NOT_POSSIBLE_PRESENT & p_local->bitmask)
        {
            ngap_DataForwardingNotPossible data_fwdng_not_pssbl;
            NGAP_MEMSET(&data_fwdng_not_pssbl, NGAP_ZERO, 
                    sizeof(ngap_DataForwardingNotPossible));

            data_fwdng_not_pssbl = 
                p_local->data_forwarding_not_possible.\
                data_forwarding_not_possible;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_4(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        data_fwdng_not_pssbl))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - DATA FORWARDING NOT POSSIBLE");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* Encode ngap_PDUSessionType */
        ngap_PDUSessionType pdu_session_type;
        NGAP_MEMSET(&pdu_session_type, NGAP_ZERO, sizeof(ngap_PDUSessionType));

        pdu_session_type = p_local->pdu_session_type;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_5(
                    &asn1_ctx1,
                    &p_pdu_session_req_transfer->protocolIEs, 
                    pdu_session_type))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE5 - PDU SESSION TYPE");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode security_indication */
        if(PSSRT_SECURITY_INDICATION_PRESENT & p_local->bitmask)
        {
            ngap_SecurityIndication     *p_security_ind;

            p_security_ind = 
                rtxMemAllocTypeZ(&asn1_ctx1, ngap_SecurityIndication);

            if(NGAP_P_NULL == p_security_ind)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_security_ind->integrityProtectionIndication = 
                p_local->security_indication.integrity_protection_indication;

            p_security_ind->confidentialityProtectionIndication = 
                p_local->security_indication.confidentiality_protection_indication;

            if(p_local->security_indication.bitmask)
            {
                p_security_ind->m.maximumIntegrityProtectedDataRate_ULPresent = 
                    NGAP_TRUE;

                p_security_ind->maximumIntegrityProtectedDataRate_UL = 
                    p_local->security_indication.\
                    maximum_integrity_protected_data_rate;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_6(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        p_security_ind))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6 - SECURITY INDICATION");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* network_instance */
        if(PSSRT_NETWORK_INSTANCE_PRESENT & p_local->bitmask)
        {
            ngap_NetworkInstance ntw_instance;
            NGAP_MEMSET(&ntw_instance, NGAP_ZERO, sizeof(ngap_NetworkInstance));

            ntw_instance = p_local->network_instance.network_instance;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_7(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        ntw_instance))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE7 - NETWORK INSTANCE");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* encode qos_flow_setup_req_list */
        if (PSSRT_PDU_SESSION_REQ_QOS_FLOW_SETUP_REQ_LIST_PRESENT & p_local->bitmask)
        {
            ngap_QosFlowSetupRequestList *p_qos_flow_setup_list;

            OSRTDList ngap_PDUSessionResourceSetupRequestTransferIEs_8;

            rtxDListInit(&ngap_PDUSessionResourceSetupRequestTransferIEs_8);

            p_qos_flow_setup_list = 
                &ngap_PDUSessionResourceSetupRequestTransferIEs_8;

            if(NGAP_FAILURE == ngap_encode_ie_qos_flow_setup_list(
                        &asn1_ctx1,
                        p_qos_flow_setup_list,
                        &p_local->qos_flow_setup_req_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE8 -  QOS Flow Setup List failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_8(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        p_qos_flow_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE8 - QOS FLOW SETUP LIST");
                break;
            }
        }
        
        /*encode common_network_instance*/

        if (PSSRT_COMMOM_NETWORK_INSTANCE_PRESENT & p_local->bitmask)
        {
            ngap_CommonNetworkInstance *p_commom_network_instance;
            
            p_commom_network_instance = rtxMemAllocTypeZ(&asn1_ctx1, ngap_CommonNetworkInstance);
            
            if(NGAP_P_NULL == p_commom_network_instance)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            
            p_commom_network_instance->numocts = 
                p_local->common_network_instance.num_string_len;

            p_commom_network_instance->data = 
                rtxMemAllocTypeZ(&asn1_ctx1, OSOCTET);
            
            if(NGAP_P_NULL == p_commom_network_instance->data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            
            NGAP_MEMCPY
            (
                (void *)p_commom_network_instance->data,
                p_local->common_network_instance.string_data,
                p_commom_network_instance->numocts
            );
            
            if(NGAP_ASN_OK !=
              asn1Append_ngap_PDUSessionResourceSetupRequestTransfer_protocolIEs_9(
                        &asn1_ctx1,
                        &p_pdu_session_req_transfer->protocolIEs, 
                        p_commom_network_instance
            ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE9 - Common Network Instance");
                break;
            }
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for PDU session resource setup req transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PE_ngap_PDUSessionResourceSetupRequestTransfer(&asn1_ctx1,
                    p_pdu_session_req_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "FAILED: Encoding of PDU session resource setup req transfer");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */

            ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer(NGAP_ASN, 
                    (SInt8 *)"NGAP_PDUSessionResourceSetupRequestTransfer", 
                    p_pdu_session_req_transfer);

            /* calculate asn encoded buffer length */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    } while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_addnl_up_transport_layer_info_list
 * Inputs           : p_asn1_ctx
 *                    p_additional_up_layer_info
 *
 * Outputs          : p_value
 *
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *
 * DESCRIPTION      : This function fill ASN Structure using local structure
 *****************************************************************************/
ngap_return_et ngap_encode_ie_addnl_up_transport_layer_info_list
(
 OSCTXT                                      *p_asn1_ctx,
 ngap_UPTransportLayerInformationList        *p_addnl_up_transport_layer_information,
 ngap_up_transport_layer_information_list_t  *p_additional_up_layer_info
 )
{
    ngap_UPTransportLayerInformationItem        *p_addnl_up_transport_layer_item = NGAP_P_NULL;
    OSRTDListNode                               *p_node = NGAP_P_NULL;
    ngap_return_et                              response = NGAP_SUCCESS;
    UInt16                                      index = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_additional_up_layer_info->count)
    {
        RRC_NGAP_TRACE(NGAP_INFO,
                "ADDITIONAL UP TRANSPORT LAYER INFO LIST: List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_additional_up_layer_info->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_UPTransportLayerInformationItem,
                &p_node,
                &p_addnl_up_transport_layer_item);

        if ( (NGAP_P_NULL == p_node) ||
                (NGAP_P_NULL == p_addnl_up_transport_layer_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_addnl_up_transport_layer_item,
                NGAP_ZERO, sizeof(ngap_UPTransportLayerInformationItem));

        /* Encode nGU_UP_TNLInformation*/
        switch(p_additional_up_layer_info->up_transport_layer_info[index].\
                up_transport_layer_info.choice_type)
        {
            case UP_TRANSPORT_LAYER_INFO_GP_TUNNEL:
            {
                p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.t =
                    T_ngap_UPTransportLayerInformation_gTPTunnel;

                p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.gTPTunnel =
                    (ngap_GTPTunnel *)rtxMemAllocTypeZ(p_asn1_ctx,
                            ngap_GTPTunnel);

                if(NGAP_P_NULL ==
                        p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.gTPTunnel)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMSET(p_addnl_up_transport_layer_item->\
                        nGU_UP_TNLInformation.u.gTPTunnel,
                        NGAP_ZERO, sizeof(ngap_GTPTunnel));

                /* Encode transportLayerAddress */
                p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.\
                    gTPTunnel->transportLayerAddress.numbits  =
                    NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.\
                    gTPTunnel->transportLayerAddress.data =
                    (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                if(p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.\
                        gTPTunnel->transportLayerAddress.data)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                NGAP_MEMCPY
                    (
                     (void *)p_addnl_up_transport_layer_item->
                     nGU_UP_TNLInformation.u.gTPTunnel->\
                     transportLayerAddress.data,
                     p_additional_up_layer_info->up_transport_layer_info[index].\
                     up_transport_layer_info.gtp_tunnel.transport_layer_address,
                     NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
                    );

                /* Encode gtp_TEID */
                p_addnl_up_transport_layer_item->nGU_UP_TNLInformation.u.\
                    gTPTunnel->gTP_TEID.numocts = NGAP_GTP_TUNNEL_TEID;

                NGAP_MEMCPY
                    (
                     (void *)p_addnl_up_transport_layer_item->\
                     nGU_UP_TNLInformation.u.gTPTunnel->gTP_TEID.data,
                     &p_additional_up_layer_info->up_transport_layer_info[index].\
                     up_transport_layer_info.gtp_tunnel.gtp_TEID,
                     NGAP_GTP_TUNNEL_TEID
                    );

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Invalid Value of choice_type");
                response = NGAP_FAILURE;
                break;
            }
        }

        /* Add One Item to the Node */
        rtxDListAppendNode(p_addnl_up_transport_layer_information, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_qos_flow_setup_list
 * Inputs           : p_asn1_ctx
 *                      p_local
 * Outputs          : p_value
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_qos_flow_setup_list
(
 OSCTXT                          *p_asn1_ctx,
 ngap_QosFlowSetupRequestList    *p_ngap_asn_qos_flow_setup_req_list,
 qos_flow_setup_req_list_t       *p_ngap_local_qos_flow_setup_req_list
 )
{
    ngap_QosFlowSetupRequestItem    *p_qos_flow_setup_item = NGAP_P_NULL;
    OSRTDListNode                   *p_node = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;
    UInt16			                count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_ngap_local_qos_flow_setup_req_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
    }

    for (count = NGAP_ZERO; 
            count < p_ngap_local_qos_flow_setup_req_list->count; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowSetupRequestItem,
                &p_node,
                &p_qos_flow_setup_item);

        if ( (NGAP_P_NULL == p_node) || (NGAP_P_NULL == p_qos_flow_setup_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_qos_flow_setup_item, 0, sizeof(ngap_QosFlowSetupRequestItem));

        /*encode qosFlowIdentifier*/
        p_qos_flow_setup_item->qosFlowIdentifier  = 
            p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
            qos_flow_identifier;

        /*encode qos_flow_level_qos_parameters*/

        /*encode qosCharacteristics*/
        /*encode nonDynamic5QI*/
        if(QOS_CHARACTERSTICS_NON_DYNAMIC_5QI_DESCRIPTOR & 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.choice_type)/*Handover bug fixes*/
        {
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.t = 
                T_ngap_QosCharacteristics_nonDynamic5QI;

            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.u.\
                nonDynamic5QI = 
                (ngap_NonDynamic5QIDescriptor *)rtxMemAllocTypeZ(p_asn1_ctx, 
                        ngap_NonDynamic5QIDescriptor);

            if(NGAP_P_NULL == 
                    p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /*fill fiveQI*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.u.\
                nonDynamic5QI->fiveQI = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.\
                non_dynamic_5qi_descriptor.five_qi;

            /*fill priority_level_qos*/
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.bitmask &
                    NON_DYNAMIC_5QI_DISCRIPTOR_PRITORITY_LEVEL_QOS_PRESENT )
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->m.priorityLevelQosPresent = NGAP_TRUE; 

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->priorityLevelQos = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.priority_level_qos;
            }

            /*fill average_window*/

            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.bitmask &
                    NON_DYNAMIC_5QI_DISCRIPTOR_AVERAGE_WINDOW_PRESENT )
            {

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->m.averagingWindowPresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->averagingWindow = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.average_window;
            }


            /*fill maximumDataBurstVolume*/

            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.bitmask &
                    NON_DYNAMIC_5QI_DISCRIPTORMAXIMUM_DATA_BURST_VOLUME_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->m.maximumDataBurstVolumePresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.nonDynamic5QI->maximumDataBurstVolume = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    non_dynamic_5qi_descriptor.max_data_burst_volume;
            }
        }

        /*fill dynamic_5qi_descriptor*/
        if(QOS_CHARACTERSTICS_DYNAMIC_5QI_DESCRIPTOR & 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.choice_type)/*Handover bug fixes*/
        {
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.t = 
                T_ngap_QosCharacteristics_dynamic5QI;

            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.u.\
                dynamic5QI = 
                (ngap_Dynamic5QIDescriptor *)rtxMemAllocTypeZ(p_asn1_ctx, 
                        ngap_Dynamic5QIDescriptor);

            if(NGAP_P_NULL == 
                    p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /*fill priority_level_qos*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                u.dynamic5QI->priorityLevelQos = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.\
                dynamic_5qi_descriptor.priority_level_qos;

            /*fill packet_delay_budget*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                u.dynamic5QI->packetDelayBudget = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.\
                dynamic_5qi_descriptor.packet_delay_budget;

            /*fill packetErrorRate*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.u.\
                dynamic5QI->packetErrorRate.pERScalar = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.\
                dynamic_5qi_descriptor.packet_error_rate.per_scalar;

            p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.u.\
                dynamic5QI->packetErrorRate.pERExponent = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.qos_characterstics.\
                dynamic_5qi_descriptor.packet_error_rate.per_exponent;

            /*fill five_qi */
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.bitmask &
                    DYNAMIC_5QI_DISCRIPTOR_FIVE_QI_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->m.fiveQIPresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->fiveQI = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.five_qi;
            }

            /*fill delay_critical */
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.bitmask &
                    DYNAMIC_5QI_DISCRIPTOR_DELAY_CRITICAL_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->m.delayCriticalPresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->delayCritical = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.delay_critical;
            }

            /*fill averagingWindow*/
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.bitmask &
                    DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_AVERAGE_WINDOW_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->m.averagingWindowPresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->averagingWindow = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.average_window;
            }

            /*fill maximumDataBurstVolume */
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.bitmask &
                    DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_MAXIMUM_DATA_BURST_VOLUME_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->m.maximumDataBurstVolumePresent = NGAP_TRUE;

                p_qos_flow_setup_item->qosFlowLevelQosParameters.qosCharacteristics.\
                    u.dynamic5QI->maximumDataBurstVolume = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.qos_characterstics.\
                    dynamic_5qi_descriptor.max_data_burst_volume;
            }
        }

        /*encode allocationAndRetentionPriority*/
        p_qos_flow_setup_item->qosFlowLevelQosParameters.\
            allocationAndRetentionPriority.priorityLevelARP = 
            p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
            qos_flow_level_qos_parameters.allocation_and_retention_priority.\
            priority_level_arp;

        p_qos_flow_setup_item->qosFlowLevelQosParameters.\
            allocationAndRetentionPriority.pre_emptionCapability = 
            p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
            qos_flow_level_qos_parameters.allocation_and_retention_priority.\
            pre_emption_capability;

        p_qos_flow_setup_item->qosFlowLevelQosParameters.\
            allocationAndRetentionPriority.pre_emptionVulnerability = 
            p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
            qos_flow_level_qos_parameters.allocation_and_retention_priority.\
            pre_emption_vulnerability;

        /*encode gBR_QosInformation*/
        if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.bitmask & 
                QOS_FLOW_LEVEL_QOS_PARAM_QOS_INFORMATION_PRESENT)
        {
            p_qos_flow_setup_item->qosFlowLevelQosParameters.m.\
                gBR_QosInformationPresent = NGAP_TRUE;

            /*fill max_flow_bit_rate_dl*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                maximumFlowBitRateDL = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.gbr_qos_info.max_flow_bit_rate_dl;

            /*fill max_flow_bit_rate_ul*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                maximumFlowBitRateUL = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.gbr_qos_info.max_flow_bit_rate_ul;

            /*fill guaranteed_flow_bit_rate_dl*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                guaranteedFlowBitRateDL = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.gbr_qos_info.\
                guaranteed_flow_bit_rate_dl;

            /*fill guaranteed_flow_bit_rate_ul*/
            p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                guaranteedFlowBitRateUL = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.gbr_qos_info.\
                guaranteed_flow_bit_rate_ul;

            /*fill notification_control*/
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.bitmask &
                    GBR_QOS_INFO_NOTIFICATION_CONTROL_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    m.notificationControlPresent = NGAP_TRUE; /*Handover bug fixes*/ 

                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    notificationControl = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.\
                    notification_control;
            }

            /*fill max_packet_loss_rate_dl */
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.bitmask &
                    GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_DL_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    m.maximumPacketLossRateDLPresent = NGAP_TRUE; /*Handover bug fixes*/ 

                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    maximumPacketLossRateDL = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.max_packet_loss_rate_dl;

            }

            /*fill max_packet_loss_rate_ul */
            if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.bitmask &
                    GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_UL_PRESENT)
            {
                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    m.maximumPacketLossRateULPresent = NGAP_TRUE; /*Handover bug fixes*/ 

                p_qos_flow_setup_item->qosFlowLevelQosParameters.gBR_QosInformation.\
                    maximumPacketLossRateUL = 
                    p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                    qos_flow_level_qos_parameters.gbr_qos_info.\
                    max_packet_loss_rate_ul;
            }
        }

        /*encode reflectiveQosAttribute */
        if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.bitmask &
                QOS_FLOW_LEVEL_QOS_PARAM_REFLECTIVE_QOS_ATTRIBUTE_PRESENT)
        {
            p_qos_flow_setup_item->qosFlowLevelQosParameters.m.\
                reflectiveQosAttributePresent = NGAP_TRUE;

            p_qos_flow_setup_item->qosFlowLevelQosParameters.reflectiveQosAttribute =
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.reflective_qos_attribute.\
                reflective_qos_attribute;
        }

        /*encode additionalQosFlowInformation*/
        if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.bitmask &
                QOS_FLOW_LEVEL_QOS_PARAM_ADDITIONAL_QOS_FLOW_INFORMATION_PRESENT)
        {
            p_qos_flow_setup_item->qosFlowLevelQosParameters.m.\
                additionalQosFlowInformationPresent = NGAP_TRUE;

            p_qos_flow_setup_item->qosFlowLevelQosParameters.\
                additionalQosFlowInformation = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].\
                qos_flow_level_qos_parameters.additional_qos_flow_info.\
                additional_qos_flow_info;
        }

        /*encode e_RAB_ID*/
        if(p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].bitmask &
                QOS_FLOW_SETUP_REQ_LIST_ITEM_QOS_FLOW_ID_PRESENT)
        {
            p_qos_flow_setup_item->m.e_RAB_IDPresent = NGAP_TRUE;

            p_qos_flow_setup_item->e_RAB_ID = 
                p_ngap_local_qos_flow_setup_req_list->qos_flow_item[count].drb_id;
        }

        rtxDListAppendNode(p_ngap_asn_qos_flow_setup_req_list, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_setup_request_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_pdu_session_resource_setup_req_list
 * Outputs          : p_ngap_asn_pdu_session_resource_setup_req_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_pdu_session_resource_setup_request_list
(
 OSCTXT  *p_asn1_ctx,
 ngap_PDUSessionResourceSetupListCxtReq          
         *p_ngap_asn_pdu_session_resource_setup_req_list,    /* ASN BUFFER */
 ngap_pdu_session_resource_setup_request_list_t  
         *p_ngap_local_pdu_session_resource_setup_req_list   /* LOCAL STRUCTURE */
 )
{
    ngap_PDUSessionResourceSetupItemCxtReq   
        *p_pdu_session_resource_setup_item = NGAP_P_NULL;

    OSRTDListNode       
        *p_pdu_session_resource_setup_node = NGAP_P_NULL;
    ngap_return_et response                = NGAP_SUCCESS;
    UInt16 index                           = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_ngap_local_pdu_session_resource_setup_req_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is not present");
        response = NGAP_FAILURE;
    }

    for(index = NGAP_ZERO; index <
            p_ngap_local_pdu_session_resource_setup_req_list->count; 
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceSetupItemCxtReq,
                &p_pdu_session_resource_setup_node,
                &p_pdu_session_resource_setup_item);


        if((NGAP_P_NULL == p_pdu_session_resource_setup_node) ||
                (NGAP_P_NULL == p_pdu_session_resource_setup_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET
            (
             p_pdu_session_resource_setup_item, 
             NGAP_ZERO,
             sizeof(ngap_PDUSessionResourceSetupItemCxtReq)
            );

        /* Encode pDUSessionID*/
        p_pdu_session_resource_setup_item->pDUSessionID =
            p_ngap_local_pdu_session_resource_setup_req_list->\
            pdu_session_resource_setup_request_item[index].\
            pdu_session_id.pdu_session_id;

        /* Encode nas_pdu*/
        if(PDU_SESSION_RESOURCE_SETUP_REQUEST_ITEM_NAS_PDU_PRESENT &
                p_ngap_local_pdu_session_resource_setup_req_list->\
                pdu_session_resource_setup_request_item[index].bitmask)
        {
            p_pdu_session_resource_setup_item->nAS_PDU.numocts =
                p_ngap_local_pdu_session_resource_setup_req_list->\
                pdu_session_resource_setup_request_item[index].nas_pdu.num_string_len;

            p_pdu_session_resource_setup_item->nAS_PDU.data =
                (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, p_pdu_session_resource_setup_item->\
                        nAS_PDU.numocts);

            if(NGAP_P_NULL == p_pdu_session_resource_setup_item->nAS_PDU.data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMSET((void *)p_pdu_session_resource_setup_item->nAS_PDU.data,
                    NGAP_ZERO,
                    p_pdu_session_resource_setup_item->nAS_PDU.numocts);

            NGAP_MEMCPY
                (
                 (void *)p_pdu_session_resource_setup_item->nAS_PDU.data,
                 p_ngap_local_pdu_session_resource_setup_req_list->\
                 pdu_session_resource_setup_request_item[index].\
                 nas_pdu.string_data,
                 p_ngap_local_pdu_session_resource_setup_req_list->\
                 pdu_session_resource_setup_request_item[index].\
                 nas_pdu.num_string_len
                );
        }

        /* Encode s_nssai*/
        p_pdu_session_resource_setup_item->s_NSSAI.sST.numocts =
            NGAP_SST_OCTET_SIZE;

        NGAP_MEMCPY
            (
             p_pdu_session_resource_setup_item->s_NSSAI.sST.data,
             p_ngap_local_pdu_session_resource_setup_req_list->\
             pdu_session_resource_setup_request_item[index].s_nssai.sst,
             NGAP_SST_OCTET_SIZE
            );

        if(NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT &
                p_ngap_local_pdu_session_resource_setup_req_list->\
                pdu_session_resource_setup_request_item[index].s_nssai.bitmask)
        {

            p_pdu_session_resource_setup_item->s_NSSAI.m.sDPresent = 
                NGAP_TRUE;

            p_pdu_session_resource_setup_item->s_NSSAI.sD.numocts = 
                NGAP_SD_OCTET_SIZE;

            NGAP_MEMCPY
                (
                 p_pdu_session_resource_setup_item->s_NSSAI.sD.data,
                 p_ngap_local_pdu_session_resource_setup_req_list->\
                 pdu_session_resource_setup_request_item[index].s_nssai.sd,
                 NGAP_SD_OCTET_SIZE
                );
        }

        /* Encode pdu_session_resource_setup_request_transfer */
        p_pdu_session_resource_setup_item->\
            pDUSessionResourceSetupRequestTransfer.numocts = 
            NGAP_MAX_ASN1_BUF_LEN;

        p_pdu_session_resource_setup_item->\
            pDUSessionResourceSetupRequestTransfer.data = 
            rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_pdu_session_resource_setup_item->\
                pDUSessionResourceSetupRequestTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        response = ngap_encode_pdu_session_resource_setup_req_transfer
            (
             &p_pdu_session_resource_setup_item->\
             pDUSessionResourceSetupRequestTransfer,
             &p_ngap_local_pdu_session_resource_setup_req_list->\
             pdu_session_resource_setup_request_item[index].\
             pdu_session_resource_setup_request_transfer
            ); 

        /* Append to the list */
        rtxDListAppendNode
            (
             p_ngap_asn_pdu_session_resource_setup_req_list,
             p_pdu_session_resource_setup_node
            );
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name	: ngap_initial_context_setup_resp
 * Inputs           : p_initial_context_setup_resp - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	   NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION      : This function encodes INITIAL CONTEXT SETUP RESPONSE ASN message from the information 
 *				           provided in p_initial_context_setup_resp
 *****************************************************************************/
ngap_return_et ngap_initial_context_setup_resp
(
 ngap_initial_context_setup_response_t   *p_initial_context_setup_resp,  /* Input - Local Buffer */
 UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                       ngap_pdu;
    OSCTXT                              asn1_ctx;
    ngap_InitialContextSetupResponse    *p_ngap_initialContextSetupRes = NGAP_P_NULL;
    ngap_return_et                      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();	
    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_initialContextSetupRes = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitialContextSetupResponse);

        if(NGAP_P_NULL == p_ngap_initialContextSetupRes)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_initialContextSetup(&asn1_ctx, 
                ngap_pdu.u.successfulOutcome, p_ngap_initialContextSetupRes);

        /* Encode All IE's */

        /*Encoding IE1 - AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;

        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_initial_context_setup_resp->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupResponse_protocolIEs_1(&asn1_ctx,
                    &p_ngap_initialContextSetupRes->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /*Encode IE2 -  RAN_UE_NGAP_ID*/
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;

        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_initial_context_setup_resp->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupResponse_protocolIEs_2(&asn1_ctx,
                    &p_ngap_initialContextSetupRes->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - RAN_UE_NGAP_ID to NGAP PDU");
            break;
        }	

        /*Encode IE3 - PDU Session Resource Setup Response List*/

        if(INITIAL_CONTEXT_SETUP_RESPONSE_PDU_SESSION_RESOURCE_SETUP_RESPONSE_LIST_PRESENT &
                p_initial_context_setup_resp->bitmask)
        {
            ngap_PDUSessionResourceSetupListCxtRes  *p_value_ie3 = NGAP_P_NULL;
            OSRTDList                               initialContextSetupRes_IE3;

            rtxDListInit(&initialContextSetupRes_IE3);

            p_value_ie3 = &initialContextSetupRes_IE3;

            if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_setup_res_list(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_initial_context_setup_resp->\
                        pdu_session_resource_setup_response_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to encode IE3 - PDU Session Resource Setup Response List");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupResponse_protocolIEs_3(&asn1_ctx,
                        &p_ngap_initialContextSetupRes->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - PDU Session Resource Setup Response List");
                break;
            }
        }

        /*Encode IE4 -PDU Session Resource Failed to Setup List */
        if(INITIAL_CONTEXT_SETUP_RESPONSE_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_PRESENT &
                p_initial_context_setup_resp->bitmask)
        {
            ngap_PDUSessionResourceFailedToSetupListCxtRes *p_value_ie4 = NGAP_P_NULL;

            OSRTDList   initialContextSetupRes_IE4;

            rtxDListInit(&initialContextSetupRes_IE4);

            p_value_ie4 = &initialContextSetupRes_IE4;

            if(NGAP_FAILURE == 
                    ngap_encode_ie_pdu_session_resource_failed_to_setup_list(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_initial_context_setup_resp->\
                        pdu_session_resource_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to encode IE4 - PDU Session Resource Failed to Setup List");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupResponse_protocolIEs_4(&asn1_ctx,
                        &p_ngap_initialContextSetupRes->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - PDU Session Resource failed to setup List");
                break;
            }
        }

        /*Encode IE5 - Criticality Diagnostics */
        if(INITIAL_CONTEXT_SETUP_RESPONSE_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_initial_context_setup_resp->bitmask)
        {

            ngap_CriticalityDiagnostics     *p_value_ie5 = NGAP_P_NULL;

            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_initial_context_setup_resp->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE5 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_InitialContextSetupResponse_protocolIEs_5(&asn1_ctx,
                        &p_ngap_initialContextSetupRes->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE5 - PDU Session Resource failed to setup List");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for Initial Context Setup Response");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of Initial Context Setup Response Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);	
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_setup_res_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_pdu_session_resource_setup_res_list
 * Outputs          :   p_ngap_pdu_session_resource_setup_res_list 
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_pdu_session_resource_setup_res_list
(
 OSCTXT *p_asn1_ctx,
 ngap_PDUSessionResourceSetupListCxtRes
        *p_ngap_pdu_session_resource_setup_res_list,/*ASN buffer*/
 ngap_pdu_session_resource_setup_response_list_t
        *p_ngap_local_pdu_session_resource_setup_res_list /*Local Buffer*/
 )
{
    ngap_PDUSessionResourceSetupItemCxtRes
        *p_ngap_pdu_session_resource_setup_res_item = NGAP_P_NULL; 

    OSRTDListNode
        *p_ngap_pdu_session_resource_setup_res_node = NGAP_P_NULL;
    ngap_return_et response                         = NGAP_SUCCESS;
    UInt16 index                                    = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if((NGAP_ZERO == p_ngap_local_pdu_session_resource_setup_res_list->count))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is NULL");
        response = NGAP_FAILURE;
        return response;
    }

    /*Check if the count is less than 256*/
    if(NGAP_MAX_NO_OF_PDU_SESSION < 
            p_ngap_local_pdu_session_resource_setup_res_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
                "PDU Session setup response Item count exceeds the max of 256");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <  
            p_ngap_local_pdu_session_resource_setup_res_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceSetupItemCxtRes,
                &p_ngap_pdu_session_resource_setup_res_node,
                &p_ngap_pdu_session_resource_setup_res_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_resource_setup_res_node) || 
                (NGAP_P_NULL == p_ngap_pdu_session_resource_setup_res_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_resource_setup_res_item,
                NGAP_ZERO,sizeof(ngap_PDUSessionResourceSetupItemCxtRes));

        /*Encode pdu Session ID*/
        p_ngap_pdu_session_resource_setup_res_item->pDUSessionID = 
            p_ngap_local_pdu_session_resource_setup_res_list->\
            pdu_session_resource_setup_response_item[index].pdu_session_id.\
            pdu_session_id;

        p_ngap_pdu_session_resource_setup_res_item->\
            pDUSessionResourceSetupResponseTransfer.data =
            (OSOCTET *)rtxMemSysAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL == 
                p_ngap_pdu_session_resource_setup_res_item->\
                pDUSessionResourceSetupResponseTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_pdu_session_resource_setup_res_transfer(
                    &p_ngap_pdu_session_resource_setup_res_item->\
                    pDUSessionResourceSetupResponseTransfer,
                    &p_ngap_local_pdu_session_resource_setup_res_list->\
                    pdu_session_resource_setup_response_item[index].\
                    pdu_session_resource_setup_response_transfer
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of pDUSessionResourceSetupResponseTransfer Failed");
            response = NGAP_FAILURE;
            break;
        }

        /*Add node to the list*/
        rtxDListAppendNode(p_ngap_pdu_session_resource_setup_res_list,
                p_ngap_pdu_session_resource_setup_res_node );
    }
   
    RRC_NGAP_UT_TRACE_EXIT();
    return response; 
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_failed_to_setup_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_pdu_session_resource_failed_to_setup_list
 * Outputs          :   p_ngap_pdu_session_resource_failed_to_setup_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_pdu_session_resource_failed_to_setup_list
(
 OSCTXT *p_asn1_ctx,
 ngap_PDUSessionResourceFailedToSetupListCxtRes
        *p_ngap_pdu_session_resource_failed_to_setup_list,/*ASN buffer*/
 ngap_pdu_session_resource_failed_to_setup_list_t
        *p_ngap_local_pdu_session_resource_failed_to_setup_list /*Local Buffer*/
 )
{
    ngap_PDUSessionResourceFailedToSetupItemCxtRes  
        *p_ngap_pdu_session_resource_failed_to_setup_item;

    OSRTDListNode *p_ngap_pdu_session_resource_failed_to_setup_node 
                            = NGAP_P_NULL;
    ngap_return_et response = NGAP_SUCCESS;
    UInt16 index            = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if((NGAP_ZERO == p_ngap_local_pdu_session_resource_failed_to_setup_list->count))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is NULL");
        response = NGAP_FAILURE;
        return response;
    }

    /*Check if the count is less than 256*/
    if(NGAP_MAX_NO_OF_PDU_SESSION < 
            p_ngap_local_pdu_session_resource_failed_to_setup_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
                "PDU Session Failed to setup Item count exceeds the max of 256");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <  
            p_ngap_local_pdu_session_resource_failed_to_setup_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceFailedToSetupItemCxtRes,
                &p_ngap_pdu_session_resource_failed_to_setup_node,
                &p_ngap_pdu_session_resource_failed_to_setup_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_setup_node) || 
                (NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_setup_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_resource_failed_to_setup_item,
                NGAP_ZERO,sizeof(ngap_PDUSessionResourceFailedToSetupItemCxtRes));

        /*Encode pdu Session ID*/
        p_ngap_pdu_session_resource_failed_to_setup_item->pDUSessionID = 
            p_ngap_local_pdu_session_resource_failed_to_setup_list->\
            pdu_session_resource_failed_to_setup_item[index].pdu_session_id.\
            pdu_session_id;

        p_ngap_pdu_session_resource_failed_to_setup_item->\
            pDUSessionResourceSetupUnsuccessfulTransfer.data =
            (OSOCTET *)rtxMemSysAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_setup_item->\
                pDUSessionResourceSetupUnsuccessfulTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_pdu_srf_unsuccessful_transfer(
                    &p_ngap_pdu_session_resource_failed_to_setup_item->\
                    pDUSessionResourceSetupUnsuccessfulTransfer,
                    &p_ngap_local_pdu_session_resource_failed_to_setup_list->\
                    pdu_session_resource_failed_to_setup_item[index].\
                    pdu_session_resource_setup_unsuccessful_transfer
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode Pdu Session resource setup uncessful transfer\n");
            response = NGAP_FAILURE;
            break;
        }


        rtxDListAppendNode(p_ngap_pdu_session_resource_failed_to_setup_list,
                p_ngap_pdu_session_resource_failed_to_setup_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_failed_to_fail_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_pdu_session_resource_failed_to_fail_list
 * Outputs          :   p_ngap_pdu_session_resource_failed_to_fail_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_pdu_session_resource_failed_to_fail_list
(
 OSCTXT *p_asn1_ctx,
 ngap_PDUSessionResourceFailedToSetupListCxtFail
        *p_ngap_pdu_session_resource_failed_to_fail_list,/*ASN buffer*/
 ngap_pdu_session_resource_failed_to_setup_list_t
        *p_ngap_local_pdu_session_resource_failed_to_fail_list /*Local Buffer*/
 )
{
    ngap_PDUSessionResourceFailedToSetupItemCxtFail  
        *p_ngap_pdu_session_resource_failed_to_fail_item;

    OSRTDListNode *p_ngap_pdu_session_resource_failed_to_fail_node 
                            = NGAP_P_NULL;
    ngap_return_et response = NGAP_SUCCESS;
    UInt16 index            = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if((NGAP_ZERO == p_ngap_local_pdu_session_resource_failed_to_fail_list->count))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is NULL");
        response = NGAP_FAILURE;
    }

    /*Check if the count is less than 256*/
    if(NGAP_MAX_NO_OF_PDU_SESSION < 
            p_ngap_local_pdu_session_resource_failed_to_fail_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, 
                "PDU Session Failed to setup Item count exceeds the max of 256");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <  
            p_ngap_local_pdu_session_resource_failed_to_fail_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceFailedToSetupItemCxtFail,
                &p_ngap_pdu_session_resource_failed_to_fail_node,
                &p_ngap_pdu_session_resource_failed_to_fail_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_fail_node) || 
                (NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_fail_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_resource_failed_to_fail_item,
                NGAP_ZERO,sizeof(ngap_PDUSessionResourceFailedToSetupItemCxtFail));

        /*Encode pdu Session ID*/
        p_ngap_pdu_session_resource_failed_to_fail_item->pDUSessionID = 
            p_ngap_local_pdu_session_resource_failed_to_fail_list->\
            pdu_session_resource_failed_to_setup_item[index].pdu_session_id.\
            pdu_session_id;

        p_ngap_pdu_session_resource_failed_to_fail_item->\
            pDUSessionResourceSetupUnsuccessfulTransfer.data =
            (OSOCTET *)rtxMemSysAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL == p_ngap_pdu_session_resource_failed_to_fail_item->\
                pDUSessionResourceSetupUnsuccessfulTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_pdu_srf_unsuccessful_transfer(
                    &p_ngap_pdu_session_resource_failed_to_fail_item->\
                    pDUSessionResourceSetupUnsuccessfulTransfer,
                    &p_ngap_local_pdu_session_resource_failed_to_fail_list->\
                    pdu_session_resource_failed_to_setup_item[index].\
                    pdu_session_resource_setup_unsuccessful_transfer
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode Pdu Session resource fail uncessful transfer\n");
            response = NGAP_FAILURE;
            break;
        }


        rtxDListAppendNode(p_ngap_pdu_session_resource_failed_to_fail_list,
                p_ngap_pdu_session_resource_failed_to_fail_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}



/******************************************************************************
 * Function Name	: ngap_initial_context_setup_fail
 * Inputs           : p_initial_context_setup_fail - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes INITIAL CONTEXT SETUP FAIL ASN message from the information 
 *				          provided in p_initial_context_setup_fail
 *****************************************************************************/
ngap_return_et ngap_initial_context_setup_fail
(
 ngap_initial_context_setup_failure_t    *p_initial_context_setup_fail,  /* Input - Local Buffer */
 UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_InitialContextSetupFailure *p_ngap_InitialContextSetupFailure = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;
        ngap_pdu.u.unsuccessfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_InitialContextSetupFailure = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitialContextSetupFailure);

        if(NGAP_P_NULL == p_ngap_InitialContextSetupFailure)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break; 
        }

        /* Set the initiating message type to Initial context setup failure*/
        asn1SetTC_ngap_UnsuccessfulOutcome_initialContextSetup(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_ngap_InitialContextSetupFailure);

        /* Encoding of all IEs starts here*/

        /* Encode IE1 - AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
        value_ie1 = 
            (ngap_AMF_UE_NGAP_ID)p_initial_context_setup_fail->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupFailure_protocolIEs_1(&asn1_ctx,
                    &p_ngap_InitialContextSetupFailure->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE1 - AMF UE NGAP ID to NGAP PDU"); 
            break;
        }

        /* Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;

        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_initial_context_setup_fail->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupFailure_protocolIEs_2(&asn1_ctx,
                    &p_ngap_InitialContextSetupFailure->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE2 -RAN UE NGAP ID to NGAP PDU");
            break;
        }
        /*GQA - 1214 :start*/     
        /* Encode IE3 - resource failed to setup*/

        if(INITIAL_CONTEXT_SETUP_FAILURE_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_PRESENT &
               p_initial_context_setup_fail->bitmask )
        {
            ngap_PDUSessionResourceFailedToSetupListCxtFail *p_value_ie3  = NGAP_P_NULL;
            OSRTDList                                        isc_failureIE4;

            rtxDListInit(&isc_failureIE4);

            p_value_ie3 = &isc_failureIE4;

            if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_failed_to_fail_list(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_initial_context_setup_fail->pdu_session_resource_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encode IE3 - resource failed to setup");
                response = NGAP_FAILURE;
                break;
            }
            if(NGAP_ASN_OK !=asn1Append_ngap_InitialContextSetupFailure_protocolIEs_3(
                        &asn1_ctx,
                        &p_ngap_InitialContextSetupFailure->protocolIEs,p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3- resource failed to setup");        
                break;
            }
        }
        /*GQA - 1214 :end*/
        /* Encoding IE4 -  Cause */
        ngap_Cause *p_value_ie4 = NGAP_P_NULL;
        p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_initial_context_setup_fail->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4 - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != 
                asn1Append_ngap_InitialContextSetupFailure_protocolIEs_4(&asn1_ctx,
                    &p_ngap_InitialContextSetupFailure->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE4- Cause to NGAP PDU");
            break;
        }

        /* Encode IE4 - Criticality Diagnostic*/
        if(INITIAL_CONTEXT_SETUP_FAILURE_CRITICALITY_DIAGNOSTICS_PRESENT & 
                p_initial_context_setup_fail->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie5 = NGAP_P_NULL; 

            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_initial_context_setup_fail->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE5 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_InitialContextSetupFailure_protocolIEs_5(&asn1_ctx,
                        &p_ngap_InitialContextSetupFailure->protocolIEs, p_value_ie5))
            {   
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE5 - Criticality Diagnostics");
                break;
            }
        }

        /* ASN Encode Message */
        if(NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for Initial Context Setup failure");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of Initial Context Setup Failure Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);
            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name : ngap_ue_radio_capability_info_indication
 * Inputs        : p_ue_radio_cap_info_ind - Information from which ASN
 *                 message will be prepared
 * Outputs       : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                 p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns       : NGAP_SUCCESS - ASN encoding was successful
 *                 NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION   : This function encodes UE RADIO CAPABILITY INFO INDICATION
 *                 IND ASN message from the information provided in 
 *                 p_ue_radio_cap_info_ind
 *****************************************************************************/
ngap_return_et ngap_ue_radio_capability_info_indication
(
    ngap_ue_radio_capability_info_indication_t  *p_ue_radio_cap_info_ind,	/* Input - Local Buffer */
    UInt8                                       *p_asn_msg, 		        /* Output - ASN Encoded Buffer */
    UInt16                                      *p_asn_msg_len		        /* Output - ASN Encoded Buffer Length */
)
{
	ngap_NGAP_PDU                           ngap_pdu;
	OSCTXT                                  asn1_ctx;
	ngap_return_et                          response                             = NGAP_SUCCESS;
	ngap_UERadioCapabilityInfoIndication    *p_ngap_ue_radio_capability_info_ind = NGAP_P_NULL;

    UInt8 *p_ue_radio_access_cap_info_asn_msg   = NGAP_P_NULL;
    UInt16 ue_radio_access_cap_info_asn_msg_len = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_ue_radio_capability_info_ind  = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UERadioCapabilityInfoIndication);

        if(NGAP_P_NULL == p_ngap_ue_radio_capability_info_ind)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_uERadioCapabilityInfoIndication(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_ue_radio_capability_info_ind);

        /*  Encode IE's of Error Indication */

        /* Encoding IE1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;

        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_ue_radio_cap_info_ind->amf_ue_ngap_id_t;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UERadioCapabilityInfoIndication_protocolIEs_1(&asn1_ctx,
                    &p_ngap_ue_radio_capability_info_ind->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encoding IE2 - RAN_UE_NGAP_ID*/
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;

        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_ue_radio_cap_info_ind->ran_ue_ngap_id_t;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UERadioCapabilityInfoIndication_protocolIEs_2(&asn1_ctx,
                    &p_ngap_ue_radio_capability_info_ind->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - RAN_UE_NGAP_ID to NGAP PDU");
            break;
        }

        p_ue_radio_access_cap_info_asn_msg = (UInt8 *)rtxMemAllocZ(&asn1_ctx, NGAP_MAX_ASN1_BUF_LEN); 

        /* Encoding IE3 -  UE Radio access Capability information */
        rrc_encode_ue_radio_access_capability_info(p_ue_radio_cap_info_ind, \
                p_ue_radio_access_cap_info_asn_msg, \
                &ue_radio_access_cap_info_asn_msg_len);

        /* Encoding IE3 -  UE Radio Capability */
        ngap_UERadioCapability *p_value_ie3 = NGAP_P_NULL;

        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UERadioCapability);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;                
            break;
        }

        p_value_ie3->numocts = ue_radio_access_cap_info_asn_msg_len;

        p_value_ie3->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie3->numocts);

        if(NGAP_P_NULL == p_value_ie3->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMCPY((void *)p_value_ie3->data,
                p_ue_radio_access_cap_info_asn_msg,       
                ue_radio_access_cap_info_asn_msg_len);      

        if(NGAP_ASN_OK !=
                asn1Append_ngap_UERadioCapabilityInfoIndication_protocolIEs_3(&asn1_ctx,
                    &p_ngap_ue_radio_capability_info_ind->protocolIEs, p_value_ie3))
        { 
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3 - UE Radio Capability");
            break;
        }

        /*Encode IE4 - UE RADIO CAPABILITY FOR PAGING */

        if(NGAP_UE_RADIO_CAPABILITY_FOR_PAGING_PRESENT &
                p_ue_radio_cap_info_ind->bitmask)
        {
            ngap_UERadioCapabilityForPaging *p_value_ie4 = NGAP_P_NULL;

            p_value_ie4 = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_UERadioCapabilityForPaging);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ue_radio_capability_for_paging(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_ue_radio_cap_info_ind->ue_radio_capability_for_paging))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE4 - UE Radio Capability for Paging Failed");
                response = NGAP_FAILURE;
                break;
            }


            if(NGAP_ASN_OK !=
                    asn1Append_ngap_UERadioCapabilityInfoIndication_protocolIEs_4
                    (&asn1_ctx, &p_ngap_ue_radio_capability_info_ind->\
                     protocolIEs, p_value_ie4))
            { 
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - UE Radio Capability");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for UE Radio Capability Info Indication");

            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);

            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of UE Radio Capability info Indication Failed");

            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_ue_context_release_request
 * Inputs           : p_ue_context_release_request - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                         p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	: This function encodes UE CONTEXT RELEASE REQUEST ASN message from the information
 *				   provided in p_ue_context_release_request
 *****************************************************************************/
ngap_return_et  ngap_ue_context_release_request
(
 ngap_ue_context_release_request_t   *p_ue_context_release_request,  /* Input - Local Buffer */
 UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_UEContextReleaseRequest    *p_ngap_UEContextReleaseRequest = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_UEContextReleaseRequest = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UEContextReleaseRequest);

        if(NGAP_P_NULL == p_ngap_UEContextReleaseRequest)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to Initial context setup request */
        asn1SetTC_ngap_InitiatingMessage_uEContextReleaseRequest(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_UEContextReleaseRequest);

        /*Encoding of all the IEs starts here*/

        /* Encode IE1 - AMF UE NGAP ID*/   
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;
        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_ue_context_release_request->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseRequest_protocolIEs_1(&asn1_ctx,
                    &p_ngap_UEContextReleaseRequest->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE1 - AMF UE NGAP ID to NGAP PDU"); 
            break;
        }

        /* Encode IE2 - RAN UE NGAP ID */
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_ue_context_release_request->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseRequest_protocolIEs_2(&asn1_ctx,
                    &p_ngap_UEContextReleaseRequest->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to add IE2 -RAN UE NGAP ID to NGAP PDU"); 
            break;
        }

        /*Encode IE - PDU Session Resource List*/
        if(UE_CONTEXT_RELEASE_REQUEST_PDU_SESSION_RESOURCE_LIST_PRESENT &
                p_ue_context_release_request->bitmask)
        {

            ngap_PDUSessionResourceListCxtRelCpl    *p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, 
                    ngap_PDUSessionResourceListCxtRelCpl);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_list(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ue_context_release_request->pdu_session_resource_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE- PDU Session Resource List failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_UEContextReleaseRequest_protocolIEs_3(&asn1_ctx,
                        &p_ngap_UEContextReleaseRequest->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to add IE3 - PDU Session Resource List NGAP PDU"); 
                break;
            }
        }

        /* Encode IE4 - Cause*/
        ngap_Cause *p_value_ie4 = NGAP_P_NULL;
        p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_ue_context_release_request->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4 - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }
        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseRequest_protocolIEs_4(&asn1_ctx,
                    &p_ngap_UEContextReleaseRequest->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE4 - Cause to NGAP PDU");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for UE context release request");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of UE Context Release request Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_ue_context_release_command
 * Inputs           : p_ue_context_release_command - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes UE CONTEXT RELEASE COMMAND ASN message from the information 
 *				          provided in p_ue_context_release_command
 *****************************************************************************/
ngap_return_et  ngap_ue_context_release_command
(
 ngap_ue_context_release_command_t   *p_ue_context_release_command,  /* Input - Local Buffer */
 UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_UEContextReleaseCommand    *p_ngap_UEContextReleaseCommand = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }


        p_ngap_UEContextReleaseCommand = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UEContextReleaseCommand);

        if(NGAP_P_NULL == p_ngap_UEContextReleaseCommand)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to UE context release command */
        asn1SetTC_ngap_InitiatingMessage_uEContextRelease(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_UEContextReleaseCommand);

        /*Encoding starts here */

        /*Encode IE1 - UE NGAP IDs*/

        /* Allocate memory to the pointer type variable */
        ngap_UE_NGAP_IDs *p_value_ie1 = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UE_NGAP_IDs);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(p_ue_context_release_command->bitmask &
                UE_CONTEXT_REL_CMD_RAN_UE_NGAP_ID_PRESENT)
        {

            /* Assign value to t */
            p_value_ie1->t = T_ngap_UE_NGAP_IDs_uE_NGAP_ID_pair;

            /* Allocate memory to uE_NGAP_ID_pair pointer */
            p_value_ie1->u.uE_NGAP_ID_pair = rtxMemAllocTypeZ(&asn1_ctx, 
                    ngap_UE_NGAP_ID_pair);

            if(NGAP_P_NULL == p_value_ie1->u.uE_NGAP_ID_pair)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /* Copy value to aMF_UE_NGAP_ID */
            p_value_ie1->u.uE_NGAP_ID_pair->aMF_UE_NGAP_ID = 
                p_ue_context_release_command->amf_ue_ngap_id;

            /*copy value to rAN_UE_NGAP_ID */
            p_value_ie1->u.uE_NGAP_ID_pair->rAN_UE_NGAP_ID = 
                p_ue_context_release_command->ran_ue_ngap_id;
        }

        else
        {
            /* Assign value to t */
            p_value_ie1->t = T_ngap_UE_NGAP_IDs_aMF_UE_NGAP_ID;

            /* Copy value to aMF_UE_NGAP_ID */
            p_value_ie1->u.aMF_UE_NGAP_ID = 
                p_ue_context_release_command->amf_ue_ngap_id;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_UEContextReleaseCommand_protocolIEs_1(&asn1_ctx,
                    &p_ngap_UEContextReleaseCommand->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 to NGAP PDU");
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE2 -  Cause*/
        ngap_Cause *p_value_ie2 = NGAP_P_NULL;
        p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie2)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }	

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie2,
                    &p_ue_context_release_command->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2 - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseCommand_protocolIEs_2(&asn1_ctx,
                    &p_ngap_UEContextReleaseCommand->protocolIEs, p_value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2- Cause to NGAP PDU");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for Context Release Command");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of UL NAS Transport Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name	: ngap_ue_context_release_complete
 * Inputs          	: p_ue_context_release_complete - Information from which Asn message will be prepared
 * Outputs         	: p_asn_msg - Pointer to the buffer that is ASN encoded
 *                        p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns         	: NGAP_SUCCESS - ASN encoding was successful
 *                    	  NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes UE CONTEXT RELEASE COMPLETE ASN message from the information 
 *				          provided in p_ue_context_release_complete
 *****************************************************************************/
ngap_return_et  ngap_ue_context_release_complete
(
 ngap_ue_context_release_complete_t  *p_ue_context_release_complete, /* Input - Local Buffer */
 UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
 UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_UEContextReleaseComplete   *p_ngap_ue_context_rel_complete = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t=T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_ngap_ue_context_rel_complete = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UEContextReleaseComplete);

        if(NGAP_P_NULL == p_ngap_ue_context_rel_complete)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the successful outcome to ue context release complete*/
        asn1SetTC_ngap_SuccessfulOutcome_uEContextRelease(&asn1_ctx, 
                ngap_pdu.u.successfulOutcome, p_ngap_ue_context_rel_complete);

        /*Encoding of all IE's starts here*/

        /*Encode IE1 - AMF UE NGAP ID*/
        ngap_AMF_UE_NGAP_ID value_ie1 = NGAP_ZERO;

        value_ie1 = 
            (ngap_AMF_UE_NGAP_ID)p_ue_context_release_complete->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseComplete_protocolIEs_1(&asn1_ctx,
                    &p_ngap_ue_context_rel_complete->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /*Encode IE2 - RAN_UE_NGAP_ID*/

        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;
        value_ie2 = 
            (ngap_RAN_UE_NGAP_ID)p_ue_context_release_complete->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_UEContextReleaseComplete_protocolIEs_2(&asn1_ctx,
                    &p_ngap_ue_context_rel_complete->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE2 - RAN_UE_NGAP_ID to NGAP PDU");
            break;
        }	

        /*Encode IE3 - User Location Information */
        if(UE_CONTEXT_RELEASE_COMPLETE_USER_LOCATION_INFO_PRESENT &
                p_ue_context_release_complete->bitmask)
        {
            ngap_UserLocationInformation *p_value_ie3 = NGAP_P_NULL;
            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UserLocationInformation);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /* encoding the various members of the structure */
            if(NGAP_FAILURE == ngap_encode_user_location_info(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ue_context_release_complete->choice_user_location_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        " Encoding of IE3 - User Location Information Failed ");
                response = NGAP_FAILURE;
                break;
            } 
            if(NGAP_ASN_OK != 
                    asn1Append_ngap_UEContextReleaseComplete_protocolIEs_3(&asn1_ctx,
                        &p_ngap_ue_context_rel_complete->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - User Location Information to NGAP PDU");
                break;
            }
        }        

        /*Encode IE4 - Information on Recommended Cells and RAN Nodes for Paging*/

        /*Encode IE - PDU Session Resource List*/


        if (p_ue_context_release_complete->pdu_session_resource_item_t.count > NGAP_ZERO)
        {
            ngap_PDUSessionResourceListCxtRelCpl    *p_value_ie5 = NGAP_P_NULL;

            p_value_ie5 = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_PDUSessionResourceListCxtRelCpl);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_list(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_ue_context_release_complete->pdu_session_resource_item_t))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE- PDU Session Resource List failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_UEContextReleaseComplete_protocolIEs_5(&asn1_ctx,
                        &p_ngap_ue_context_rel_complete->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6 - PDU SEssion Resource List to NGAP PDU");
                break;
            }
        }
        /*Encode IE - Criticality Diagnostics*/
        if(UE_CONTEXT_RELEASE_COMPLETE_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_ue_context_release_complete->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie6 = NGAP_P_NULL;

            p_value_ie6 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie6)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie6,
                        &p_ue_context_release_complete->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE6 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_UEContextReleaseComplete_protocolIEs_6(&asn1_ctx,
                        &p_ngap_ue_context_rel_complete->protocolIEs, p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6 - Criticality Diagnostics");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for UE context Release");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of UE Context Release Complete Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_recommended_cells_for_paging
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_info_of_recomm_cells_for_paging
 * Outputs          :   p_ngap_asn_info_of_recomm_cells_for_paging
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_recommended_cells_for_paging
(
 OSCTXT                                  *p_asn1_ctx,
 ngap_RecommendedCellList                *p_ngap_asn_info_of_recomm_cells_for_paging,
 ngap_recommended_cells_for_paging_t     *p_ngap_local_info_of_recomm_cells_for_paging
 )
{
    ngap_RecommendedCellItem     *p_ngap_recomm_cell_for_paging_item = NGAP_P_NULL;
    OSRTDListNode                *p_recomm_cell_for_paging_node      = NGAP_P_NULL;
    ngap_return_et               response                            = NGAP_SUCCESS;
    UInt16                       index                               = NGAP_ZERO;
    RRC_NGAP_UT_TRACE_ENTER();

    /*Check if List is empty or not*/
    if(NGAP_ZERO == p_ngap_local_info_of_recomm_cells_for_paging->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    if(NGAP_MAX_NO_OF_RECOMMENDED_CELLS < 
            p_ngap_local_info_of_recomm_cells_for_paging->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds max value");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < 
            p_ngap_local_info_of_recomm_cells_for_paging->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_RecommendedCellItem,
                &p_recomm_cell_for_paging_node,
                &p_ngap_recomm_cell_for_paging_item);

        if((NGAP_P_NULL == p_recomm_cell_for_paging_node) ||
                (NGAP_P_NULL == p_ngap_recomm_cell_for_paging_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_recomm_cell_for_paging_item,
                NGAP_ZERO, sizeof(ngap_RecommendedCellItem));

        /*Encode nGRAN_CGI*/
        switch(p_ngap_local_info_of_recomm_cells_for_paging->\
                recommended_cell_item[index].ng_ran_cgi.choice_type)
        {
            case NGAP_NR_CGI:
            {
                p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.t = 
                    T_ngap_NGRAN_CGI_nR_CGI;

                p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.nR_CGI =
                    rtxMemAllocTypeZ(p_asn1_ctx, ngap_NR_CGI);

                if(NGAP_P_NULL == p_ngap_recomm_cell_for_paging_item->\
                        nGRAN_CGI.u.nR_CGI)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;    
                }
                else
                {
                    /*Encode pLMNIdentity*/

                    /*Set the value of numocts*/
                    p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                        pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES;

                    /*Copy the value of data*/
                    NGAP_MEMCPY
                        (
                         p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                         pLMNIdentity.data,
                         p_ngap_local_info_of_recomm_cells_for_paging->\
                         recommended_cell_item[index].ng_ran_cgi.nr_cgi.\
                         plmn_identity.plmn_id_bytes,
                         NGAP_PLMN_IDENTITY_MAX_BYTES
                        );

                    /*Encode nRCellIdentity*/

                    /*Set the value of numbits*/
                    p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                        nRCellIdentity.numbits = NGAP_NR_CELL_IDENTITY_NUMBITS;

                    /*Copy the value of data*/
                    NGAP_MEMCPY
                        (
                         p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.nR_CGI->\
                         nRCellIdentity.data,
                         p_ngap_local_info_of_recomm_cells_for_paging->\
                         recommended_cell_item[index].ng_ran_cgi.nr_cgi.\
                         nr_cell_identity,
                         NGAP_NR_CELL_IDENTITY_OCTET_SIZE
                        );
                }
                break;
            }

            case NGAP_EUTRA_CGI:
            {
                p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.t = 
                    T_ngap_NGRAN_CGI_eUTRA_CGI;

                p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI =
                    rtxMemAllocTypeZ(p_asn1_ctx, ngap_EUTRA_CGI);

                if(NGAP_P_NULL == 
                        p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }
                else
                {
                    /*Encode pLMNIdentity*/
                    /*Set the value of numocts*/
                    p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                        pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES;

                    /*Copy the value of data*/
                    NGAP_MEMCPY
                        (
                         p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         pLMNIdentity.data,
                         p_ngap_local_info_of_recomm_cells_for_paging->\
                         recommended_cell_item[index].ng_ran_cgi.eutra_cgi.\
                         plmn_identity.plmn_id_bytes,
                         NGAP_PLMN_IDENTITY_MAX_BYTES
                        );

                    /*Encode eUTRACellIdentity*/

                    /*Set the value of numbits*/
                    p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                        eUTRACellIdentity.numbits = NGAP_EUTRA_CELL_IDENTITY_NUMBITS;

                    /*Copy the value of data*/
                    NGAP_MEMCPY
                        (
                         p_ngap_recomm_cell_for_paging_item->nGRAN_CGI.u.eUTRA_CGI->\
                         eUTRACellIdentity.data,
                         p_ngap_local_info_of_recomm_cells_for_paging->\
                         recommended_cell_item[index].ng_ran_cgi.eutra_cgi.\
                         eutra_cell_identity,
                         NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE
                        );

                }
                break;
            }
            default:
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Value of choice type is invalid");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode - time_stayed_in_cell*/
        p_ngap_recomm_cell_for_paging_item->timeStayedInCell = 
            p_ngap_local_info_of_recomm_cells_for_paging->\
            recommended_cell_item[index].time_stayed_in_cell;

        /*Add node to the list*/
        rtxDListAppendNode(p_ngap_asn_info_of_recomm_cells_for_paging,
                p_recomm_cell_for_paging_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_recommended_ran_nodes_for_paging
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_info_of_recomm_ran_nodes_for_paging
 * Outputs          :   p_ngap_asn_info_of_recomm_ran_nodes_for_paging
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_recommended_ran_nodes_for_paging
(
 OSCTXT                                      *p_asn1_ctx,
 ngap_RecommendedRANNodeList                 *p_ngap_asn_info_of_recomm_ran_nodes_for_paging,
 ngap_recommended_ran_nodes_for_paging_t     *p_ngap_local_info_of_recomm_ran_nodes_for_paging
 )
{
    ngap_RecommendedRANNodeItem  *p_ngap_recomm_ran_nodes_for_paging_item = 
        NGAP_P_NULL;

    OSRTDListNode       *p_recomm_ran_node_for_paging_node  = NGAP_P_NULL;
    ngap_return_et      response                            = NGAP_SUCCESS;
    UInt16              index                               = NGAP_ZERO;
    RRC_NGAP_UT_TRACE_ENTER();


    /*Check if List is empty or not*/
    if(NGAP_ZERO == p_ngap_local_info_of_recomm_ran_nodes_for_paging->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    if(NGAP_MAX_NO_OF_RECOMMENDED_RAN_NODES < 
            p_ngap_local_info_of_recomm_ran_nodes_for_paging->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds Max value");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < 
            p_ngap_local_info_of_recomm_ran_nodes_for_paging->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_RecommendedRANNodeItem,
                &p_recomm_ran_node_for_paging_node,
                &p_ngap_recomm_ran_nodes_for_paging_item);

        if((NGAP_P_NULL == p_recomm_ran_node_for_paging_node) ||
                (NGAP_P_NULL == p_ngap_recomm_ran_nodes_for_paging_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_recomm_ran_nodes_for_paging_item,
                NGAP_ZERO,
                sizeof(ngap_RecommendedCellItem));

        switch(p_ngap_local_info_of_recomm_ran_nodes_for_paging->\
                recommended_ran_node_item[index].choice_type)
        {
            case NGAP_AMF_PAGING_TARGET_CHOICE_RAN_NODE:
            {
                p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.t = 
                    T_ngap_AMFPagingTarget_globalRANNodeID;

                p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.\
                    globalRANNodeID = 
                    rtxMemAllocTypeZ(p_asn1_ctx, ngap_GlobalRANNodeID);

                if(NGAP_P_NULL == p_ngap_recomm_ran_nodes_for_paging_item->\
                        aMFPagingTarget.u.globalRANNodeID)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                if(NGAP_FAILURE == ngap_encode_ie_global_ran_node_id(
                            p_asn1_ctx,
                            p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.\
                            globalRANNodeID,
                            &p_ngap_local_info_of_recomm_ran_nodes_for_paging->\
                            recommended_ran_node_item[index].global_ran_node_id))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "Encoding of IE1-Global RAN Node ID Failed");
                    response = NGAP_FAILURE;
                    break;
                }
                break;
            }

            case NGAP_AMF_PAGING_TARGET_CHOICE_RAN_TAI:
            {
                p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.tAI = 
                    rtxMemAllocTypeZ(p_asn1_ctx, ngap_TAI);

                if(NGAP_P_NULL == p_ngap_recomm_ran_nodes_for_paging_item->\
                        aMFPagingTarget.u.tAI)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.tAI->\
                    pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES;

                NGAP_MEMCPY
                    (
                     p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.tAI->\
                     pLMNIdentity.data,
                     p_ngap_local_info_of_recomm_ran_nodes_for_paging->\
                     recommended_ran_node_item[index].tai.plmn_identity.\
                     plmn_id_bytes,
                     NGAP_PLMN_IDENTITY_MAX_BYTES
                    );

                p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.tAI->\
                    tAC.numocts = NGAP_TAC_OCTET_SIZE;

                NGAP_MEMCPY
                    (
                     p_ngap_recomm_ran_nodes_for_paging_item->aMFPagingTarget.u.tAI->\
                     tAC.data,
                     p_ngap_local_info_of_recomm_ran_nodes_for_paging->\
                     recommended_ran_node_item[index].tai.tac.tac,
                     NGAP_TAC_OCTET_SIZE
                    );
                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_INFO, "Value of choice type is invalid");
                response = NGAP_FAILURE;
                break;
            }
        }/*End of switch*/

        rtxDListAppendNode(p_ngap_asn_info_of_recomm_ran_nodes_for_paging,
                p_recomm_ran_node_for_paging_node);
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_list
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_pdu_session_resource_list
 * Outputs          :   p_ngap_asn_pdu_session_resource_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_pdu_session_resource_list
(
 OSCTXT                                  *p_asn1_ctx,
 ngap_PDUSessionResourceListCxtRelCpl    *p_ngap_asn_pdu_session_resource_list,
 ngap_pdu_session_resource_list_t        *p_ngap_local_pdu_session_resource_list
 )
{
    ngap_PDUSessionResourceItemCxtRelCpl    *p_pdu_session_resource_list_item = 
        NGAP_P_NULL;

    OSRTDListNode       *p_pdu_session_resource_list_node = NGAP_P_NULL;
    ngap_return_et      response             = NGAP_SUCCESS;
    UInt16			    index                = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();


    if (NGAP_ZERO == p_ngap_local_pdu_session_resource_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    if(NGAP_MAX_NO_OF_PDU_SESSION < 
            p_ngap_local_pdu_session_resource_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "Count exceeds the NGAP_MAX_NO_OF_PDU_SESSION");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < 
            p_ngap_local_pdu_session_resource_list->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceItemCxtRelCpl,
                &p_pdu_session_resource_list_node,
                &p_pdu_session_resource_list_item);

        if((NGAP_P_NULL == p_pdu_session_resource_list_node) || 
                (NGAP_P_NULL == p_pdu_session_resource_list_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_pdu_session_resource_list_item, NGAP_ZERO, 
                sizeof(ngap_PDUSessionResourceItemCxtRelCpl));

        /*Encode - PDU Session ID */
        p_pdu_session_resource_list_item->pDUSessionID = 
            p_ngap_local_pdu_session_resource_list->pdu_session_id[index].\
            pdu_session_id.pdu_session_id;

        rtxDListAppendNode(p_ngap_asn_pdu_session_resource_list,
                p_pdu_session_resource_list_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_5g_s_tmsi
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_5g_s_tmsi
 * Outputs          :   p_ngap_asn_5g_s_tmsi
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_5g_s_tmsi
(
 OSCTXT              *p_asn1_ctx,
 ngap_FiveG_S_TMSI   *p_ngap_asn_5g_s_tmsi,
 ngap_5g_s_tmsi_t    *p_ngap_local_5g_s_tmsi
 )
{
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Encode IE - AMF Set Id */
    p_ngap_asn_5g_s_tmsi->aMFSetID.numbits = NGAP_AMF_SET_ID_NUMBITS;

    NGAP_MEMCPY (p_ngap_asn_5g_s_tmsi->aMFSetID.data,
            p_ngap_local_5g_s_tmsi->amf_set_id.amf_set_id,
            NGAP_AMF_SET_ID_OCTET_SIZE );

    /* Encode IE - AMF Pointer */
    p_ngap_asn_5g_s_tmsi->aMFPointer.numbits = NGAP_AMF_POINTER_NUMBITS;

    NGAP_MEMCPY (p_ngap_asn_5g_s_tmsi->aMFPointer.data,
            p_ngap_local_5g_s_tmsi->amf_pointer.amf_pointer,
            NGAP_AMF_POINTER_OCTET_SIZE );

    /* Encode IE - 5G-TMSI */
    p_ngap_asn_5g_s_tmsi->fiveG_TMSI.numocts = NGAP_5G_TMSI_OCTET_SIZE;

    NGAP_MEMCPY (p_ngap_asn_5g_s_tmsi->fiveG_TMSI.data,
            p_ngap_local_5g_s_tmsi->tmsi_5g,
            NGAP_5G_TMSI_OCTET_SIZE );

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/****************************************************************************
 * Function Name    : ngap_encode_source_to_target_amf_information
 * Inputs           : p_asn1_ctx
 *
 * Outputs          : p_ngap_local_source_to_target_amf_information
 *                    p_ngap_asn_source_to_target_amf_information
 *
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 *
 * Description      : This function fill ASN Structure using local structure 
******************************************************************************/
ngap_return_et  ngap_encode_source_to_target_amf_information
(
    OSCTXT                                         *p_asn1_ctx,
    ngap_SourceToTarget_AMFInformationReroute      *p_ngap_asn_source_to_target_amf_information,
    ngap_source_to_target_information_reroute_t    *p_ngap_local_source_to_target_amf_information
)
{
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    if(INITIAL_UE_MESSAGE_CONFIGURED_NSSAI &
            p_ngap_local_source_to_target_amf_information->bitmask )
    {  
        p_ngap_asn_source_to_target_amf_information->m.configuredNSSAIPresent = 
            NGAP_TRUE;

        /* Encode IE - Configured  NSSAI*/
        if(p_ngap_local_source_to_target_amf_information->conf_nssai.\
                num_string_len <= NGAP_CONFIGURED_NSSAI_OCTET_SIZE)
        {
            p_ngap_asn_source_to_target_amf_information->configuredNSSAI.numocts = 
                p_ngap_local_source_to_target_amf_information->conf_nssai.\
                num_string_len;

            NGAP_MEMCPY
                (
                 p_ngap_asn_source_to_target_amf_information->\
                     configuredNSSAI.data,
                 p_ngap_local_source_to_target_amf_information->conf_nssai.\
                     string_data,
                 p_ngap_local_source_to_target_amf_information->conf_nssai.\
                     num_string_len
                );
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "configuredNSSAI.numocts is Greater than max value %d",
                    NGAP_CONFIGURED_NSSAI_OCTET_SIZE);

            response = NGAP_FAILURE;
            return response;
        }
    }

    if(INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_PLMN & 
            p_ngap_local_source_to_target_amf_information->bitmask)
    {
        p_ngap_asn_source_to_target_amf_information->m.\
            rejectedNSSAIinPLMNPresent=NGAP_TRUE;

        /* Encode IE - Rejected NSSAI in PLMN */
        if(p_ngap_local_source_to_target_amf_information->\
                rej_nssai_plmn.num_string_len <=
                NGAP_REJECTED_NSSAI_IN_PLMN_OCTET_SIZE)
        {

            p_ngap_asn_source_to_target_amf_information->\
                rejectedNSSAIinPLMN.numocts=
                p_ngap_local_source_to_target_amf_information->rej_nssai_plmn.\
                num_string_len;

            NGAP_MEMCPY
                (
                 p_ngap_asn_source_to_target_amf_information->\
                    rejectedNSSAIinPLMN.data,
                 p_ngap_local_source_to_target_amf_information->\
                    rej_nssai_plmn.string_data,
                 p_ngap_local_source_to_target_amf_information->\
                    rej_nssai_plmn.num_string_len 
                );
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "rejectedNSSAIinPLMN.numocts is greater than max value %d",
                    NGAP_REJECTED_NSSAI_IN_PLMN_OCTET_SIZE);

            response = NGAP_FAILURE;
            return response;
        }
    }

    if(INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_TA & 
            p_ngap_local_source_to_target_amf_information->bitmask)
    {
        p_ngap_asn_source_to_target_amf_information->m.\
            rejectedNSSAIinTAPresent = NGAP_TRUE;

        /* Encode IE - Rejected NSSAI in TA */
        if(p_ngap_local_source_to_target_amf_information->\
                rej_nssai_ta.num_string_len <=
                NGAP_REJECTED_NSSAI_IN_TA_OCTET_SIZE)
        {
            p_ngap_asn_source_to_target_amf_information->rejectedNSSAIinTA.\
                numocts = p_ngap_local_source_to_target_amf_information->\
                rej_nssai_ta.num_string_len;

            NGAP_MEMCPY
                (p_ngap_asn_source_to_target_amf_information->\
                    rejectedNSSAIinTA.data,
                 p_ngap_local_source_to_target_amf_information->\
                    rej_nssai_ta.string_data,
                 p_ngap_local_source_to_target_amf_information->\
                    rej_nssai_ta.num_string_len
                );
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "rejectedNSSAIinTA.numocts is Greater than max value %d",
                    NGAP_REJECTED_NSSAI_IN_TA_OCTET_SIZE);

            response = NGAP_FAILURE;
            return response;
        }
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_tai_list_for_paging
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_tai_list_for_paging
 * Outputs          :   p_ngap_asn_tai_list_for_paging
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_tai_list_for_paging
(
 OSCTXT                      *p_asn1_ctx,
 ngap_TAIListForPaging       *p_ngap_asn_tai_list_for_paging,
 ngap_tai_list_for_paging_t  *p_ngap_local_tai_list_for_paging
 )
{
    ngap_TAIListForPagingItem   *p_tai_list_for_paging_item = NGAP_P_NULL;
    OSRTDListNode               *p_tai_list_for_paging_item_node = NGAP_P_NULL;
    ngap_return_et              response = NGAP_SUCCESS;
    UInt8                       count = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 item should be present */
    if (NGAP_ZERO == p_ngap_local_tai_list_for_paging->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No TAI List For Paging Present");
        response = NGAP_FAILURE;
    }

    for (count = NGAP_ZERO; 
            count < p_ngap_local_tai_list_for_paging->count;
            count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_TAIListForPagingItem,
                &p_tai_list_for_paging_item_node,
                &p_tai_list_for_paging_item);

        if ( (NGAP_P_NULL == p_tai_list_for_paging_item_node) || 
                (NGAP_P_NULL == p_tai_list_for_paging_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_tai_list_for_paging_item, 
                NGAP_ZERO, sizeof(ngap_TAIListForPagingItem));

        p_tai_list_for_paging_item->tAI.pLMNIdentity.numocts
            = NGAP_PLMN_IDENTITY_MAX_BYTES; 

        NGAP_MEMCPY
            (
             p_tai_list_for_paging_item->tAI.pLMNIdentity.data,
             p_ngap_local_tai_list_for_paging->tai_list_for_paging_item[count].\
             tai.plmn_identity.plmn_id_bytes,
             NGAP_PLMN_IDENTITY_MAX_BYTES
            );

        p_tai_list_for_paging_item->tAI.tAC.numocts = NGAP_TAC_OCTET_SIZE;

        NGAP_MEMCPY
            (
             p_tai_list_for_paging_item->tAI.tAC.data,
             p_ngap_local_tai_list_for_paging->tai_list_for_paging_item[count].\
             tai.tac.tac,
             NGAP_TAC_OCTET_SIZE
            );

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_ngap_asn_tai_list_for_paging,
                p_tai_list_for_paging_item_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ue_radio_capability_for_paging 
 * Inputs           : p_asn1_ctx
 *                      p_ngap_local_ue_radio_cap_for_paging
 * Outputs          : p_ngap_asn_ue_radio_cap_for_paging
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et  ngap_encode_ue_radio_capability_for_paging
(
 OSCTXT                                  *p_asn1_ctx,
 ngap_UERadioCapabilityForPaging         *p_ngap_asn_ue_radio_cap_for_paging,
 ngap_ue_radio_capability_for_paging_t   *p_ngap_local_ue_radio_cap_for_paging
 )
{
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    if(UE_RADIO_CAPABILITY_FOR_PAGING_OF_NR_PRESENT &
            p_ngap_local_ue_radio_cap_for_paging->bitmask)
    {

        p_ngap_asn_ue_radio_cap_for_paging->m.uERadioCapabilityForPagingOfNRPresent =
            NGAP_TRUE;

        p_ngap_asn_ue_radio_cap_for_paging->uERadioCapabilityForPagingOfNR.numocts =
            p_ngap_local_ue_radio_cap_for_paging->\
            ue_radio_capability_for_paging_of_nr.num_string_len;

        p_ngap_asn_ue_radio_cap_for_paging->uERadioCapabilityForPagingOfNR.data =
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, p_ngap_asn_ue_radio_cap_for_paging->\
                    uERadioCapabilityForPagingOfNR.numocts);

        if(NGAP_P_NULL ==
                p_ngap_asn_ue_radio_cap_for_paging->uERadioCapabilityForPagingOfNR.data)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        NGAP_MEMCPY
            (
             (void *)p_ngap_asn_ue_radio_cap_for_paging->\
             uERadioCapabilityForPagingOfNR.data,
             p_ngap_local_ue_radio_cap_for_paging->\
             ue_radio_capability_for_paging_of_nr.string_data,
             p_ngap_local_ue_radio_cap_for_paging->\
             ue_radio_capability_for_paging_of_nr.num_string_len
            );

    }

    /*Free memory after copy*/
    rrc_mem_free(p_ngap_local_ue_radio_cap_for_paging->\
                 ue_radio_capability_for_paging_of_nr.string_data);       

    if(UE_RADIO_CAPABILITY_FOR_PAGING_OF_EUTRA_PRESENT & 
            p_ngap_local_ue_radio_cap_for_paging->bitmask)
    {
        p_ngap_asn_ue_radio_cap_for_paging->m.\
            uERadioCapabilityForPagingOfEUTRAPresent = NGAP_TRUE;

        p_ngap_asn_ue_radio_cap_for_paging->uERadioCapabilityForPagingOfEUTRA.\
            numocts = 
            p_ngap_local_ue_radio_cap_for_paging->\
            ue_radio_capability_for_paging_of_eutra.num_string_len;

        /* Allocate memory to the data */
        p_ngap_asn_ue_radio_cap_for_paging->uERadioCapabilityForPagingOfEUTRA.data =
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, p_ngap_asn_ue_radio_cap_for_paging->\
                    uERadioCapabilityForPagingOfEUTRA.numocts);

        if(NGAP_P_NULL == p_ngap_asn_ue_radio_cap_for_paging->\
                uERadioCapabilityForPagingOfEUTRA.data)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        /* Copy the string_data into data */
        NGAP_MEMCPY
            (
             (void *)p_ngap_asn_ue_radio_cap_for_paging->\
             uERadioCapabilityForPagingOfEUTRA.data,
             p_ngap_local_ue_radio_cap_for_paging->\
             ue_radio_capability_for_paging_of_eutra.string_data,
             p_ngap_local_ue_radio_cap_for_paging->\
             ue_radio_capability_for_paging_of_eutra.num_string_len
            );
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_paging
 * Inputs           : p_ngap_paging - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes PAGING ASN message from the
 *				      information provided in p_ngap_paging
 *****************************************************************************/
ngap_return_et ngap_encode_paging
(
 ngap_paging_t       *p_ngap_paging, /* Input - Local Buffer */
 UInt8               *p_asn_msg, 	/* Output - ASN Encoded Buffer */
 UInt16              *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU       ngap_pdu;
    OSCTXT              asn1_ctx;
    ngap_Paging         *p_asn_ngap_paging = NGAP_P_NULL;
    ngap_return_et      response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NGAP Paging */
        p_asn_ngap_paging = rtxMemAllocTypeZ(&asn1_ctx, ngap_Paging);

        if(NGAP_P_NULL == p_asn_ngap_paging)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_paging(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_ngap_paging);

        /* Encode 7 IEs of NG Setup Request Message */

        /* Encode IE 1 - UE Paging Identity */
        ngap_UEPagingIdentity   *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UEPagingIdentity);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(p_ngap_paging->ue_paging_identity.bitmask & 
                UE_PAGING_IDENTITY_5G_S_TMSI_PRESENT)
        {

            p_value_ie1->t = T_ngap_UEPagingIdentity_fiveG_S_TMSI;

            p_value_ie1->u.fiveG_S_TMSI = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_FiveG_S_TMSI);

            if(NGAP_P_NULL == p_value_ie1->u.fiveG_S_TMSI)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_5g_s_tmsi(
                        &asn1_ctx,
                        p_value_ie1->u.fiveG_S_TMSI,
                        &p_ngap_paging->ue_paging_identity.tmsi))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE1 - UE Paging Identity Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_1(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, p_value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - UE Paging Identity Failed");
                break;
            }
        }

        /* Encode IE 2 - Paging DRX */
        if(p_ngap_paging->bitmask & NGAP_PAGING_PAGING_DRX_PRESENT)
        {    
            ngap_PagingDRX value_ie2 = NGAP_ZERO;
            value_ie2 = (ngap_PagingDRX)p_ngap_paging->paging_drx;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_2(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - UE Paging Identity Failed");
                break;
            }
        }

        /* Encode IE 3 - TAI List for Paging */
        ngap_TAIListForPaging   *p_value_ie3 = NGAP_P_NULL;

        OSRTDList               ngap_paging_ie_3;

        rtxDListInit(&ngap_paging_ie_3);

        p_value_ie3 = &ngap_paging_ie_3;

        if(NGAP_FAILURE == ngap_encode_ie_tai_list_for_paging(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_ngap_paging->tai_list_for_paging))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3-TAI List for Paging Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_Paging_protocolIEs_3(&asn1_ctx,
                    &p_asn_ngap_paging->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE3 - TAI List for Paging Failed");
            break;
        }

        /* Encode IE 4 - Paging Priority */
        if(p_ngap_paging->bitmask & NGAP_PAGING_PAGING_PRIORITY_PRESENT)
        {    
            ngap_PagingPriority value_ie4 = NGAP_ZERO;
            value_ie4 = (ngap_PagingPriority)p_ngap_paging->paging_priority;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_4(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - Paging Priority Failed");
                break;
            }
        }

        /* Encode IE 5 - UE Radio Capability for Paging */
        if(p_ngap_paging->bitmask &
                NGAP_PAGING_PAGING_UE_RADIO_CAPABILITY_FOR_PAGING_PRESENT)
        {
            ngap_UERadioCapabilityForPaging *p_value_ie5 = NGAP_P_NULL;

            p_value_ie5 = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_UERadioCapabilityForPaging);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ue_radio_capability_for_paging(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_ngap_paging->ue_radio_capability_for_paging))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE5 - UE Radio Capability for Paging Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_5(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE5 - UE Radio Capability for Paging Failed");
                break;
            }
        }

        /* Encode IE 6 - Paging Origin */
        if(p_ngap_paging->bitmask &
                NGAP_PAGING_PAGING_ORIGIN_PRESENT)
        {
            ngap_PagingOrigin value_ie6 = NGAP_ZERO;
            value_ie6 = (ngap_PagingOrigin)p_ngap_paging->paging_origin;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_6(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6 - Paging Origin");
                break;
            }
        }

        /* Encode IE 7 - Assistance Data for Paging */
        if(p_ngap_paging->bitmask &
                NGAP_PAGING_PAGING_ASSISTANCE_DATA_FOR_PAGING_PRESENT)
        {
            ngap_AssistanceDataForPaging *p_value_ie7 = NGAP_P_NULL;

            p_value_ie7 = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_AssistanceDataForPaging);

            if(NGAP_P_NULL == p_value_ie7)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(p_ngap_paging->assistance_data_for_paging.bitmask &
                    ASSISTANCE_DATA_FOR_PAGING_RECOMMENDED_CELLS_PRESENT)
            {
                p_value_ie7->m.assistanceDataForRecommendedCellsPresent =
                    NGAP_TRUE;

                if(NGAP_FAILURE == ngap_encode_ie_recommended_cells_for_paging(
                            &asn1_ctx,
                            &p_value_ie7->assistanceDataForRecommendedCells.\
                            recommendedCellsForPaging.recommendedCellList,
                            &p_ngap_paging->assistance_data_for_paging.\
                            assistance_data_for_recommended_cells.\
                            recommended_cells_for_paging))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, 
                            "Encoding of IE7 - Assistance Data for Paging");
                    response = NGAP_FAILURE;
                    break;
                }
            }

            if(p_ngap_paging->assistance_data_for_paging.bitmask &
                    ASSISTANCE_DATA_FOR_PAGING_PAGING_ATTEMPT_INFO_PRESENT)
            {
                p_value_ie7->m.pagingAttemptInformationPresent =
                    NGAP_TRUE;

                p_value_ie7->pagingAttemptInformation.pagingAttemptCount =
                    p_ngap_paging->assistance_data_for_paging.paging_attempt_info.\
                    paging_attempt_count;

                p_value_ie7->pagingAttemptInformation.intendedNumberOfPagingAttempts =
                    p_ngap_paging->assistance_data_for_paging.paging_attempt_info.\
                    intended_number_of_paging_attempts;

                if(p_ngap_paging->assistance_data_for_paging.paging_attempt_info.bitmask &
                        PAGING_ATTEMPT_INFO_NEXT_PAGING_AREA_SCOPE_PRESENT)
                {
                    p_value_ie7->pagingAttemptInformation.m.\
                        nextPagingAreaScopePresent = NGAP_TRUE;

                    p_value_ie7->pagingAttemptInformation.pagingAttemptCount =
                        p_ngap_paging->assistance_data_for_paging.\
                        paging_attempt_info.paging_attempt_count;
                }
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_Paging_protocolIEs_7(&asn1_ctx,
                        &p_asn_ngap_paging->protocolIEs, p_value_ie7))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE7 - Assistance Data for Paging");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for NGAP Paging");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NGAP Paging Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_setup_request
 * Inputs           : p_local_pdu_session_resource_setup_request - Local Structure
 *                    pointer thourgh which ASN pointer would be filled.
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes the PDU SESSION RESOURCE SETUP 
 *                    REQUEST message.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_setup_request
(
 ngap_pdu_session_resource_setup_request_t      *p_local_pdu_session_resource_setup_request,
 UInt8                                          *p_asn_msg,   /* Output - ASN Encoded Buffer */
 UInt16                                         *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                              ngap_pdu;
    OSCTXT                                     asn1_ctx;
    ngap_PDUSessionResourceSetupRequest        *p_asn_pdu_session_res_setup_req = NGAP_P_NULL;
    ngap_return_et                             response =  NGAP_FAILURE;

    NGAP_ASSERT(NGAP_P_NULL != p_local_pdu_session_resource_setup_request);

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_asn_pdu_session_res_setup_req = rtxMemAllocTypeZ(&asn1_ctx,ngap_PDUSessionResourceSetupRequest );

        if(NGAP_P_NULL == p_asn_pdu_session_res_setup_req)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_pDUSessionResourceSetup(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_pdu_session_res_setup_req );

        /* Encode 6  IEs of PDU SESSION RESOURCE SETUP REQUEST*/

        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID value_ie1;

        value_ie1 = p_local_pdu_session_resource_setup_request->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_1(&asn1_ctx,
                    &p_asn_pdu_session_res_setup_req->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */

        ngap_RAN_UE_NGAP_ID value_ie2;

        value_ie2 = p_local_pdu_session_resource_setup_request->ran_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_2(&asn1_ctx,
                    &p_asn_pdu_session_res_setup_req->protocolIEs, value_ie2 ) )
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /* Encode IE3 - RAN Paging Priority */

        if(PDU_SESSION_REQUEST_NGAP_RAN_PAGING_PRIORITY & 
                p_local_pdu_session_resource_setup_request->bitmask )
        {
            ngap_RANPagingPriority value_ie3 = NGAP_ZERO;

            value_ie3 = (ngap_RANPagingPriority)p_local_pdu_session_resource_setup_request->\
                        ran_paging_priority.ran_paging_priority;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_3(&asn1_ctx, 
                        &p_asn_pdu_session_res_setup_req->protocolIEs, value_ie3))

            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add  IE3 - RAN Paging Priority to NGAP PDU");
                break;
            }
        }

        /* Encode IE4 - NAS-PDU */
        if(PDU_SESSION_REQUEST_NGAP_NAS_PDU & 
                p_local_pdu_session_resource_setup_request->bitmask )
        { 
            ngap_NAS_PDU *p_value_ie4 = NGAP_P_NULL;
            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie4->numocts = p_local_pdu_session_resource_setup_request->nas_pdu.num_string_len;

            /*Allocate Memory to data pointer */
            p_value_ie4->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie4->numocts);

            if(NGAP_P_NULL == p_value_ie4->data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMCPY((void *)p_value_ie4->data, 
                    p_local_pdu_session_resource_setup_request->nas_pdu.string_data,
                    p_value_ie4->numocts);

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_4(&asn1_ctx, 
                        &p_asn_pdu_session_res_setup_req->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add  IE4 - NAS-PDU to NGAP PDU");
                break;
            }

        }
        /*ngap_encode_ie_pdu_session_resource_setup_request_list */

        ngap_PDUSessionResourceSetupListSUReq *p_value_ie5 = NGAP_P_NULL;

        p_value_ie5 = 
            rtxMemAllocTypeZ(&asn1_ctx,ngap_PDUSessionResourceSetupListSUReq);

        if(NGAP_P_NULL == p_value_ie5)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == 
                ngap_encode_ie_pdu_session_resource_setup_request_list(
                    &asn1_ctx,(ngap_PDUSessionResourceSetupListCxtReq *)p_value_ie5,
                    &p_local_pdu_session_resource_setup_request->\
                    pdu_session_resource_setup_request_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE5- PDU Session"\
                    " Resource Setup Request List Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_5(&asn1_ctx,
                    &p_asn_pdu_session_res_setup_req->protocolIEs, p_value_ie5))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE5 -  PDU Session"\
                    "Resource Setup Request List ");
            break;
        }

        /* Encode IE6 - UE Aggregate Maximum Bit Rate */
        if(PDU_SESSION_REQUEST_UE_AGGREGATE_MAXIMUM_BITRATE &
                p_local_pdu_session_resource_setup_request->bitmask)
        {
            ngap_UEAggregateMaximumBitRate *p_value_ie6 = NGAP_P_NULL;

            p_value_ie6  = 
                rtxMemAllocTypeZ(&asn1_ctx, ngap_UEAggregateMaximumBitRate);

            if(NGAP_P_NULL == p_value_ie6)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie6->uEAggregateMaximumBitRateDL = 
                p_local_pdu_session_resource_setup_request->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_dl.bit_rate;

            p_value_ie6->uEAggregateMaximumBitRateUL = 
                p_local_pdu_session_resource_setup_request->ue_aggregate_maximum_bit_rate.\
                ue_aggregate_maximum_bit_rate_ul.bit_rate;

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_PDUSessionResourceSetupRequest_protocolIEs_6(&asn1_ctx, 
                        &p_asn_pdu_session_res_setup_req->protocolIEs, p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE6- UE Aggregate Maximum Bit Rate to NGAP PDU");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for PDU Session Resource Setup Request");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of PDU Session Resource Setup Request");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_setup_response 
 * Inputs           : p_local_pdu_session_res_setup_response - Local Structure
 *                    pointer thourgh which ASN pointer would be filled.
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes the PDU SESSION RESOURCE SETUP 
 *                    RESPONSE message.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_setup_response
(
 ngap_pdu_session_resource_setup_response_t     *p_local_pdu_session_res_setup_response ,
 UInt8                                          *p_asn_msg,/* Output - ASN Encoded Buffer */
 UInt16                                         *p_asn_msg_len/* Output-ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_PDUSessionResourceSetupResponse   	*p_asn_pdu_session_res_setup_response = NGAP_P_NULL;
    ngap_return_et                          response = NGAP_FAILURE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Response */
        p_asn_pdu_session_res_setup_response =
            rtxMemAllocTypeZ(&asn1_ctx,ngap_PDUSessionResourceSetupResponse );

        if(NGAP_P_NULL == p_asn_pdu_session_res_setup_response)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_pDUSessionResourceSetup(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_asn_pdu_session_res_setup_response);

        /* Encode 6  IEs of PDU SESSION RESOURCE SETUP RESPONSE*/

        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID value_ie1;

        value_ie1 = p_local_pdu_session_res_setup_response->amf_ue_ngap_id;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceSetupResponse_protocolIEs_1(&asn1_ctx,
                    &p_asn_pdu_session_res_setup_response->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */

        ngap_RAN_UE_NGAP_ID value_ie2;

        value_ie2 = p_local_pdu_session_res_setup_response->ran_ue_ngap_id;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceSetupResponse_protocolIEs_2(&asn1_ctx,
                    &p_asn_pdu_session_res_setup_response->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /* Encode IE 3 - PDU_SESSION_RESOURCE_SETUP_LIST_SU_RES */

        if(NGAP_PDU_SESSION_RESOURCE_SETUP_LIST_SU_RES &
                p_local_pdu_session_res_setup_response->bitmask )
        {
            ngap_PDUSessionResourceSetupListSURes *p_value_ie3 = NGAP_P_NULL;

            OSRTDList                               pdu_session_response;

            rtxDListInit(&pdu_session_response);

            p_value_ie3 = &pdu_session_response;

            if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_setup_res_list(
                        &asn1_ctx,
                        (ngap_PDUSessionResourceSetupListCxtRes *)p_value_ie3,
                        &p_local_pdu_session_res_setup_response->\
                        pdu_session_resource_setup_response_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to encode IE3 - PDU Session Resource Setup Response List");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_PDUSessionResourceSetupResponse_protocolIEs_3(&asn1_ctx,
                        &p_asn_pdu_session_res_setup_response->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - PDU Session Resource Setup Response List");
                break;
            }
        }

        /* Encode IE 4 - PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_SU_REQ */

        if(NGAP_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_SU_RES &
                p_local_pdu_session_res_setup_response->bitmask ) 
        {
            ngap_PDUSessionResourceFailedToSetupListSURes *p_value_ie4 = NGAP_P_NULL;

            OSRTDList pduSessionResourceFailedToSetup;

            rtxDListInit(&pduSessionResourceFailedToSetup);

            p_value_ie4 = &pduSessionResourceFailedToSetup;

            if(NGAP_FAILURE == 
                    ngap_encode_ie_pdu_session_resource_failed_to_setup_list(
                        &asn1_ctx,
                        (ngap_PDUSessionResourceFailedToSetupListCxtRes *)p_value_ie4,
                        &p_local_pdu_session_res_setup_response->\
                        pdu_session_resource_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to encode IE4 - PDU Session Resource Failed to Setup List");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_PDUSessionResourceSetupResponse_protocolIEs_4(&asn1_ctx,
                        &p_asn_pdu_session_res_setup_response->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - PDU Session Resource failed to setup List");
                break;
            }
        }

        /* Encode IE 5 - Criticality Diagnostics */

        if(NGAP_PDU_SESSION_RESOURCE_CRITICALITY_DIGNOSTICS &
                p_local_pdu_session_res_setup_response->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie5 = NGAP_P_NULL; 
            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_local_pdu_session_res_setup_response->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE5-Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceSetupResponse_protocolIEs_5(&asn1_ctx,
                        &p_asn_pdu_session_res_setup_response->protocolIEs, p_value_ie5))
            {   
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE5 - Criticality Diagnostics");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for PDU SESSION RESOURCE SETUP RESPONSE");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of PDU SESSION RESOURCE SETUP RESPONSE Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_srf_unsuccessful_transfer
 * Inputs           : p_value - ASN Structure pointer thourgh which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE FAILED TO SETUP
 *                    UNSUCCESSFUL TRANSFER message.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_srf_unsuccessful_transfer
(
 OSDynOctStr         *p_value,
 ngap_pdu_session_resource_setup_unsuccessful_transfer_t *p_local
 )
{
    ngap_PDUSessionResourceSetupUnsuccessfulTransfer    *p_unsuccessful_transfer = NGAP_P_NULL;

    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }

    do
    {
        p_unsuccessful_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1,ngap_PDUSessionResourceSetupUnsuccessfulTransfer);

        if( NGAP_P_NULL == p_unsuccessful_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode choice cause group */

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx1,
                    &p_unsuccessful_transfer->cause,
                    &p_local->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE - Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        /*Encode Criticality Dignostic */

        if(NGAP_PSRSUT_CIRITCALITY_DIAGNOSTICS_PRESENT &
                p_local->bitmask)
        {
            p_unsuccessful_transfer->m.criticalityDiagnosticsPresent = NGAP_TRUE;

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx1,
                        &p_unsuccessful_transfer->criticalityDiagnostics,
                        &p_local->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE-Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for PDU session resource setup resp unsuccessfull transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_PDUSessionResourceSetupUnsuccessfulTransfer(&asn1_ctx1,
                    p_unsuccessful_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "FAILED: Decoding of PDU session resource setup Unsuccessful  transfer");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceSetupUnsuccessfulTransfer(&asn1_ctx1,
                    "PDU_SESSION_RESOURCE_SETUP_UNSUCESSFUL_TRANSFER_PDU",
                    p_unsuccessful_transfer);

            /* calculate asn encoded buffer length */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_rel_command
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    COMMAND message.
 *****************************************************************************/
ngap_return_et  ngap_encode_pdu_session_resource_rel_command
(
 ngap_pdu_session_resource_release_command_t *p_local_resource_release_command ,
 UInt8                                       *p_asn_msg,                              /* Output - ASN Encoded Buffer */
 UInt16                                      *p_asn_msg_len                           /* Output-ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_PDUSessionResourceReleaseCommand   *p_asn_pdu_session_res_rel_command = NGAP_P_NULL;
    ngap_return_et                          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to PDUSessionResourceReleaseCommand */

        p_asn_pdu_session_res_rel_command =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_PDUSessionResourceReleaseCommand);

        if(NGAP_P_NULL == p_asn_pdu_session_res_rel_command)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_pDUSessionResourceRelease(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_pdu_session_res_rel_command);

        /*Encode  5 IE of PDU SESSION RESOURCE RELEASE COMMAND  */

        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID   value_ie1;
        value_ie1 = p_local_resource_release_command->amf_ue_ngap_id;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseCommand_protocolIEs_1(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_command->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */

        ngap_RAN_UE_NGAP_ID    value_ie2;

        value_ie2 = p_local_resource_release_command->ran_ue_ngap_id;


        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseCommand_protocolIEs_2(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_command->protocolIEs, value_ie2 ) )
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }


        /* Encode IE3 - RAN Paging Priority */

        if(PDU_SESSION_RELEASE_COMMAND_RAN_PAGING_PRIORITY &
                p_local_resource_release_command->bitmask )
        {
            ngap_RANPagingPriority value_ie3 = NGAP_ZERO;


            value_ie3 = (ngap_RANPagingPriority)p_local_resource_release_command->\
                        ran_paging_priority.ran_paging_priority;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceReleaseCommand_protocolIEs_3(&asn1_ctx,
                        &p_asn_pdu_session_res_rel_command->protocolIEs, value_ie3))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add  IE3 - RAN Paging Priority to NGAP PDU");
                break;
            }

        }


        /* Encode IE4 - NAS-PDU */
        if(PDU_SESSION_RELEASE_COMMAND_NAS_PDU & p_local_resource_release_command->bitmask )
        {
            ngap_NAS_PDU *p_value_ie4 = NGAP_P_NULL;
            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie4->numocts = p_local_resource_release_command->nas_pdu.num_string_len;

            /*Allocate Memory to data pointer */
            p_value_ie4->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie4->numocts);

            if(NGAP_P_NULL == p_value_ie4->data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMCPY((void *)p_value_ie4->data,
                    p_local_resource_release_command->nas_pdu.string_data,
                    p_value_ie4->numocts);

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceReleaseCommand_protocolIEs_4(&asn1_ctx,
                        &p_asn_pdu_session_res_rel_command->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add  IE4 - NAS-PDU to NGAP PDU");
                break;
            }

        }
        /*Encode IE5 PDU SESSION RESOURCE TO RELEASE LIST RELEASE COMMAND */

        ngap_PDUSessionResourceToReleaseListRelCmd  *p_value_ie5 = NGAP_P_NULL;

        p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx,ngap_PDUSessionResourceToReleaseListRelCmd);


        if(NGAP_P_NULL == p_value_ie5)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE ==
                ngap_encode_ie_pdu_session_resource_release_command_list(
                    &asn1_ctx,p_value_ie5,
                    &p_local_resource_release_command->\
                    pdu_session_resource_to_release_list_rel_cmd))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE5-PDU SESSION RESOURCE TO RELEASE LIST RELEASE COMMAND FAILED ");
            response = NGAP_FAILURE;
            break;

        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseCommand_protocolIEs_5(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_command->protocolIEs, p_value_ie5))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE5 -  PDU Session RESOURCE REALEASE COMMAND LIST");
            break;
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for PDU Session Resource Release Command");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of PDU Session Resource Release Command");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }


    }while(0);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_release_command_list
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    COMMAND LIST message.
 *****************************************************************************/
ngap_return_et ngap_encode_ie_pdu_session_resource_release_command_list
(
 OSCTXT                                              *p_asn1_ctx,
 ngap_PDUSessionResourceToReleaseListRelCmd          *p_asn_pdu_session_resource_release_cmd,   /* ASN BUFFER */
 ngap_pdu_session_resource_to_release_list_rel_cmd_t *p_local_pdu_session_resource_release_cmd  /* LOCAL STRUCTURE */
 )
{
    ngap_PDUSessionResourceToReleaseItemRelCmd
        *p_pdu_session_resource_release_cmd_item = NGAP_P_NULL;
    OSRTDListNode
        *p_pdu_session_resource_release_cmd_node = NGAP_P_NULL;
    ngap_return_et  response    = NGAP_SUCCESS;
    UInt16          index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_pdu_session_resource_release_cmd->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is not present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <
            p_local_pdu_session_resource_release_cmd->count;
            index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceToReleaseItemRelCmd,
                &p_pdu_session_resource_release_cmd_node,
                &p_pdu_session_resource_release_cmd_item);

        if((NGAP_P_NULL == p_pdu_session_resource_release_cmd_node )||
                (NGAP_P_NULL == p_pdu_session_resource_release_cmd_item ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET
            (
             p_pdu_session_resource_release_cmd_item,
             NGAP_ZERO,
             sizeof(ngap_PDUSessionResourceToReleaseItemRelCmd)
            );

        /*Encode PDU SESSION ID */
        p_pdu_session_resource_release_cmd_item->pDUSessionID=\
                                                              p_local_pdu_session_resource_release_cmd->\
                                                              pdu_session_res_to_rel_list_release_cmd_item[index].\
                                                              pdu_session_id.pdu_session_id;

        /* Encode PDU Session Resource Release Command Transfer*/

        p_pdu_session_resource_release_cmd_item->\
            pDUSessionResourceReleaseCommandTransfer.numocts =
            NGAP_MAX_ASN1_BUF_LEN;

        p_pdu_session_resource_release_cmd_item->\
            pDUSessionResourceReleaseCommandTransfer.data =
            rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_pdu_session_resource_release_cmd_item->\
                pDUSessionResourceReleaseCommandTransfer.data )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        response = ngap_encode_pdu_session_resource_release_cmd_transfer
            (
             &p_pdu_session_resource_release_cmd_item->\
             pDUSessionResourceReleaseCommandTransfer,
             &p_local_pdu_session_resource_release_cmd->\
             pdu_session_res_to_rel_list_release_cmd_item[index].\
             pdu_session_res_to_rel_command_transfer
            );

        rtxDListAppendNode(p_asn_pdu_session_resource_release_cmd,
                p_pdu_session_resource_release_cmd_node );

    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_release_cmd_transfer
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    COMMAND TRANSFER message.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_release_cmd_transfer
(
 OSDynOctStr                                                 *p_value,
 ngap_pdu_session_resource_release_command_transfer_t        *p_local
 )
{
    ngap_PDUSessionResourceReleaseCommandTransfer      *p_pdu_session_res_rel_cmd_transfer = NGAP_P_NULL;

    OSCTXT                                              asn1_ctx1;
    ngap_return_et                                      response = NGAP_SUCCESS;
    UInt8                                               encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }
    do
    {
        p_pdu_session_res_rel_cmd_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1,ngap_PDUSessionResourceReleaseCommandTransfer);

        if(NGAP_P_NULL == p_pdu_session_res_rel_cmd_transfer )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        switch(p_local->choice_cause_group.choice_type)

        {
            case NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_radioNetwork;
                p_pdu_session_res_rel_cmd_transfer->cause.u.radioNetwork =
                    p_local->choice_cause_group.radio_network_layer_cause_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_transport;
                p_pdu_session_res_rel_cmd_transfer->cause.u.transport =
                    p_local->choice_cause_group.transport_layer_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_nas;
                p_pdu_session_res_rel_cmd_transfer->cause.u.nas =
                    p_local->choice_cause_group.nas_cause_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_protocol;
                p_pdu_session_res_rel_cmd_transfer->cause.u.protocol =
                    p_local->choice_cause_group.protocol_cause_event_id;
                break;
            }
            case NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_misc;
                p_pdu_session_res_rel_cmd_transfer->cause.u.misc =
                    p_local->choice_cause_group.miscellaneous_cause_event_id;
                break;

            }
            case NGAP_CAUSE_GROUP_CHOICE_INVALID_CAUSE:
            {
                p_pdu_session_res_rel_cmd_transfer->cause.t = T_ngap_Cause_choice_Extensions;
                break;
            }
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    p_value->numocts, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for PDU session resource release command transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_PDUSessionResourceReleaseCommandTransfer(&asn1_ctx1,
                    p_pdu_session_res_rel_cmd_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of PDU session resource release command transfer");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceReleaseCommandTransfer(
                    &asn1_ctx1,
                    "PDU_SESSION_RESOURCE_SETUP_UNSUCCESSFUL_TRANSFER_PDU",
                    p_pdu_session_res_rel_cmd_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_rel_resp
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    RESP message.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_rel_resp
(
 ngap_pdu_session_resource_release_response_t    *p_local_resource_release_respnse,
 UInt8                                          *p_asn_msg,           /* Output - ASN Encoded Buffer */
 UInt16                                         *p_asn_msg_len        /* Output-ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_PDUSessionResourceReleaseResponse  *p_asn_pdu_session_res_rel_response = NGAP_P_NULL;
    ngap_return_et                          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;
        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx,ngap_SuccessfulOutcome );

        if(NGAP_P_NULL ==  ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the successfull message type to PDUSessionResourceReleaseResponse */

        p_asn_pdu_session_res_rel_response =
            rtxMemAllocTypeZ(&asn1_ctx,ngap_PDUSessionResourceReleaseResponse);
        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        asn1SetTC_ngap_SuccessfulOutcome_pDUSessionResourceRelease(
                &asn1_ctx,
                ngap_pdu.u.successfulOutcome,
                p_asn_pdu_session_res_rel_response);

        /*Encode  5 IE of PDU SESSION RESOURCE RELEASE RESPONSE  */

        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID   value_ie1;
        value_ie1 = p_local_resource_release_respnse->amf_ue_ngap_id;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseResponse_protocolIEs_1(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_response->protocolIEs, value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */

        ngap_RAN_UE_NGAP_ID    value_ie2;

        value_ie2 = p_local_resource_release_respnse->ran_ue_ngap_id;


        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseResponse_protocolIEs_2(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_response->protocolIEs, value_ie2 ) )
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /*Encode IE 3 - PDU Session Resource Released List Rel Res */

        ngap_PDUSessionResourceReleasedListRelRes p_value_ie3;

        if(NGAP_FAILURE == ngap_encode_pdu_session_resource_release_response_list(
                    &asn1_ctx,
                    &p_value_ie3,
                    &p_local_resource_release_respnse->pdu_session_resource_release_response))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE3 - PDU SESSION RESOURCE RELEASE RESPONSE LIST FAILED");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_PDUSessionResourceReleaseResponse_protocolIEs_3(&asn1_ctx,
                    &p_asn_pdu_session_res_rel_response->protocolIEs, &p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE3 -PDU SESSION RESOURCE RELEASE RESPONSE LIST ");
            break;
        }
        /*Encode IE 4 - User Location Information*/

        if (NGAP_PDU_SR_RELEASE_RESPONSE_USER_LOCATION_INFO_PRESENT &
                p_local_resource_release_respnse->bitmask  )
        {
            ngap_UserLocationInformation    *p_value_ie4 = NGAP_P_NULL;
            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UserLocationInformation);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_user_location_info(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_local_resource_release_respnse->choice_user_location_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE4 - User Location Information Failed");

                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceReleaseResponse_protocolIEs_4(&asn1_ctx,
                        &p_asn_pdu_session_res_rel_response->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE4 - User Location Information to NGAP PDU");
                break;
            }
        }
        /*Encode IE 5 - Criticality Diagnostics */


        if (NGAP_PDU_SR_RELEASE_RESPONSE_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_local_resource_release_respnse->bitmask  )
        {
            ngap_CriticalityDiagnostics     *p_value_ie5 = NGAP_P_NULL;

            p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie5)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_local_resource_release_respnse->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE4 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_PDUSessionResourceReleaseResponse_protocolIEs_5(&asn1_ctx,
                        &p_asn_pdu_session_res_rel_response->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE$ - Criticality Diagnostics");
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Error Indication");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Error Indication Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_release_response_list
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    RESP LIST message.
 *****************************************************************************/
ngap_return_et  ngap_encode_pdu_session_resource_release_response_list
(
 OSCTXT                                              *p_asn1_ctx,
 ngap_PDUSessionResourceReleasedListRelRes           *p_asn_pdu_session_res_rel_response,
 ngap_pdu_session_resource_release_response_list_t   *p_local_pdu_session_res_rel_response
 )
{
    ngap_PDUSessionResourceReleasedItemRelRes
        *p_pdu_session_resource_release_response_item = NGAP_P_NULL;

    OSRTDListNode
        *p_pdu_session_resource_release_response_node = NGAP_P_NULL;
    ngap_return_et  response    = NGAP_SUCCESS;
    UInt16          index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_pdu_session_res_rel_response->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is not present");
        response = NGAP_FAILURE;
        return response;
    }

    rtxDListInit(p_asn_pdu_session_res_rel_response);

    for(index = NGAP_ZERO; index <
            p_local_pdu_session_res_rel_response->count;
            index++)
    {
        rtxDListAllocNodeAndData(
                p_asn1_ctx,
                ngap_PDUSessionResourceReleasedItemRelRes,
                &p_pdu_session_resource_release_response_node,
                &p_pdu_session_resource_release_response_item
                );

        if((NGAP_P_NULL == p_pdu_session_resource_release_response_node)||
                (NGAP_P_NULL== p_pdu_session_resource_release_response_item ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET
            (
             p_pdu_session_resource_release_response_item,
             NGAP_ZERO,
             sizeof(ngap_PDUSessionResourceReleasedItemRelRes)
            );

        /*Encode PDU SESSION ID */
        p_pdu_session_resource_release_response_item->pDUSessionID =
            p_local_pdu_session_res_rel_response->\
            pdu_session_resource_released_response[index].\
            pdu_session_id.pdu_session_id;

        /* Encode PDU Session Resource Release Response Transfer*/
        /*p_pdu_session_resource_release_response_item->\
          pDUSessionResourceReleaseResponseTransfer.numocts =
          NGAP_MAX_ASN1_BUF_LEN;*/

        p_pdu_session_resource_release_response_item->\
            pDUSessionResourceReleaseResponseTransfer.data =
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_pdu_session_resource_release_response_item->\
                pDUSessionResourceReleaseResponseTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        response = ngap_encode_pdu_session_resource_release_response_transfer(
                &p_pdu_session_resource_release_response_item->\
                pDUSessionResourceReleaseResponseTransfer,
                &p_local_pdu_session_res_rel_response->\
                pdu_session_resource_released_response[index].\
                pdu_session_resource_released_response_transfer);

        rtxDListAppendNode(p_asn_pdu_session_res_rel_response,
                p_pdu_session_resource_release_response_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/*******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_release_response_transfer
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    RESP TRANSFER message.
 *****************************************************************************/
ngap_return_et  ngap_encode_pdu_session_resource_release_response_transfer
(
 OSDynOctStr                                                 *p_value,
 ngap_pdu_session_resource_released_response_transfer_t      *p_local
 )
{
    ngap_PDUSessionResourceReleaseResponseTransfer  *p_pdu_session_res_rel_response_transfer = NGAP_P_NULL;
    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        return NGAP_FAILURE;
    }
    do
    {
        p_pdu_session_res_rel_response_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1,ngap_PDUSessionResourceReleaseResponseTransfer);

        if(NGAP_P_NULL == p_pdu_session_res_rel_response_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_pdu_session_res_rel_response_transfer->m.iE_ExtensionsPresent = NGAP_TRUE;

        if(NGAP_FAILURE == ngap_encode_ie_pdu_session_resource_release_response_list(
                    &asn1_ctx1,
                    &p_pdu_session_res_rel_response_transfer->iE_Extensions,
                    &p_local->secondary_rat_usage_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encodeing of pdu_session_res_rel_response_transfer_list failed");
            response = NGAP_FAILURE;
            break;

        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for pdu_session_res_rel_response_transfer_list ");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_PDUSessionResourceReleaseResponseTransfer(&asn1_ctx1,
                    p_pdu_session_res_rel_response_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of PDU session resource release response transfer");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_PDUSessionResourceReleaseResponseTransfer(
                    &asn1_ctx1,
                    "PDU_SESSION_RESOURCE_SETUP_RESOURCE_RELEASE_RESPONSE_TRANSFER_PDU",
                    p_pdu_session_res_rel_response_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*******************************************************************************
 * Function Name    : ngap_encode_ie_pdu_session_resource_release_response_list
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    RESP LIST message.
 *****************************************************************************/
ngap_return_et ngap_encode_ie_pdu_session_resource_release_response_list
(
 OSCTXT                                                               *p_asn1_ctx,
 ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions         *p_asn_res_transfer,
 ngap_secondary_rat_usage_information_t                               *p_local_res_transfer
 )
{
    ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions_element
        *p_asn_res_transfer_item = NGAP_P_NULL;
    OSRTDListNode           *p_asn_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16                  count    = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    rtxDListInit(p_asn_res_transfer);

    for (count = NGAP_ZERO; count < 1; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions_element,
                &p_asn_item_node,
                &p_asn_res_transfer_item
                );

        if((NGAP_P_NULL== p_asn_res_transfer_item )||
                (NGAP_P_NULL == p_asn_item_node ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            return response;
        }

        NGAP_MEMSET
            (
             p_asn_res_transfer_item,
             NGAP_ZERO,
             sizeof(ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions_element)
            );

        if((p_local_res_transfer->bitmask &
                    NGAP_PDU_SESSION_RESOURCE_RELEASE_PDU_SESSION_USAGE_REPORT_PRESENT) ||
                (p_local_res_transfer->bitmask &
                 NGAP_PDU_SESSION_RESOURCE_RELEASE_QOS_FLOW_USAGE_REPORT_PRESENT)
          )
        {
            p_asn_res_transfer_item->extensionValue.t =
                T214ngap___ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1;
        }
        else
        {
                p_asn_res_transfer_item->extensionValue.t =
                    T212ngap__UNDEF_;
        }
        if(p_asn_res_transfer_item->extensionValue.t !=
                T214ngap___ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1)
        {
            p_asn_res_transfer_item->\
                extensionValue.u.\
                _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1 =
                rtxMemAllocTypeZ(p_asn1_ctx, ngap_SecondaryRATUsageInformation);

            if(NGAP_P_NULL ==
                    p_asn_res_transfer_item->\
                    extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                return response;
            }

            /*Encode IE OF PDU SESSION USAGE REPORT PRESENT */
            if(p_local_res_transfer->bitmask &
                    NGAP_PDU_SESSION_RESOURCE_RELEASE_PDU_SESSION_USAGE_REPORT_PRESENT)
            {
                p_asn_res_transfer_item->\
                    extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                    m.pDUSessionUsageReportPresent = NGAP_TRUE;

                /* Encode RAT TYPE*/
                p_asn_res_transfer_item->\
                    extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                    pDUSessionUsageReport.rATType =
                    p_local_res_transfer->pdu_session_usage_report.rat_type;

                /* Encode PDU Session Timed Report List*/
                if(NGAP_FAILURE == ngap_encode_ie_timed_report_list
                        (   p_asn1_ctx,
                            &p_asn_res_transfer_item->\
                            extensionValue.u.\
                            _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                            pDUSessionUsageReport.pDUSessionTimedReportList,
                            &p_local_res_transfer->pdu_session_usage_report.timed_report
                        ))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "Encoding Failed for Timed report List");
                    response = NGAP_FAILURE;
                    return response;
                }
            }

            /*Encode IE OF QOS FLOW USAGE REPORT PRESENT */

            if(p_local_res_transfer->bitmask &
                    NGAP_PDU_SESSION_RESOURCE_RELEASE_QOS_FLOW_USAGE_REPORT_PRESENT)
            {
                p_asn_res_transfer_item->\
                    extensionValue.u.\
                    _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                    m.qosFlowsUsageReportListPresent = NGAP_TRUE;

                /*Encode qos Flows Usage Report List */

                if(NGAP_FAILURE == ngap_encode_ie_qos_flow_usage_report_list
                        (
                         p_asn1_ctx,
                         &p_asn_res_transfer_item->\
                         extensionValue.u.\
                         _ngap_PDUSessionResourceReleaseResponseTransfer_ExtIEs_1->\
                         qosFlowsUsageReportList,
                         &p_local_res_transfer->qos_flows_usage_report
                        ))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR,
                            "Failed to encode qos flow usage report list");
                    response = NGAP_FAILURE;
                    return response;
                }
            }
        }

        rtxDListAppendNode(p_asn_res_transfer, p_asn_item_node);
    } //end for

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/*******************************************************************************
 * Function Name    : ngap_encode_ie_qos_flow_usage_report_list
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    QOS FLOW USAGE message.
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_qos_flow_usage_report_list
(
 OSCTXT                              *p_asn1_ctx,
 ngap_QoSFlowsUsageReportList        *p_asn_qos_flow_list,
 ngap_qos_flows_usage_report_list    *p_local_qos_flow_list
 )
{
    ngap_QoSFlowsUsageReport_Item     *p_asn_qos_flow_list_item = NGAP_P_NULL;
    OSRTDListNode                     *p_qos_flow_list_item_node = NGAP_P_NULL;
    ngap_return_et                    response = NGAP_SUCCESS;
    UInt16                            count  = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if (NGAP_ZERO == p_local_qos_flow_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No Item in Qos flow list");
        response = NGAP_FAILURE;
    }
    for(count = NGAP_ZERO; count < p_local_qos_flow_list->count ; count++ )
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QoSFlowsUsageReport_Item,
                &p_qos_flow_list_item_node,
                &p_asn_qos_flow_list_item);

        if ((NGAP_P_NULL == p_qos_flow_list_item_node )||
                (NGAP_P_NULL== p_asn_qos_flow_list_item ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET(p_asn_qos_flow_list_item, NGAP_ZERO,
                sizeof(ngap_QoSFlowsUsageReport_Item));

        /*Encode qos_flow_identifier */
        p_asn_qos_flow_list_item->qosFlowIdentifier =
            p_local_qos_flow_list->qos_flow_usage_report_item[count].qos_flow_identifier.qos_flow_identifier;

        /*Encode rat type */
        p_asn_qos_flow_list_item->rATType =
            p_local_qos_flow_list->qos_flow_usage_report_item[count].rat_type;

        /*Encode Timed report List */
        if(NGAP_FAILURE == ngap_encode_ie_timed_report_list(p_asn1_ctx,
                    &p_asn_qos_flow_list_item->qoSFlowsTimedReportList,
                    &p_local_qos_flow_list->qos_flow_usage_report_item[count].\
                    timed_report))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding Failed for Timed report List");
            response = NGAP_FAILURE;
            break;
        }

        rtxDListAppendNode(p_asn_qos_flow_list,p_qos_flow_list_item_node);

    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/*******************************************************************************
 * Function Name    : ngap_encode_ie_timed_report_list
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes PDU SESSION RESOURCE RELEASE
 *                    TIMED REPORT message.
 *****************************************************************************/
ngap_return_et ngap_encode_ie_timed_report_list
(
 OSCTXT                      *p_asn1_ctx,
 ngap_VolumeTimedReportList  *p_asn_time_report_list,
 ngap_timed_report_list      *p_local_time_report_list
 )
{
    ngap_return_et                      response = NGAP_SUCCESS;
    ngap_VolumeTimedReport_Item         *p_asn_time_report_list_item = NGAP_P_NULL;
    OSRTDListNode                        *p_time_report_item_node = NGAP_P_NULL;
    UInt16                              count = NGAP_ZERO;

    if (NGAP_ZERO == p_local_time_report_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No Timed report List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for (count = NGAP_ZERO;
            count < p_local_time_report_list->count; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_VolumeTimedReport_Item,
                &p_time_report_item_node,
                &p_asn_time_report_list_item);

        if ( (NGAP_P_NULL == p_time_report_item_node) ||
                (NGAP_P_NULL == p_asn_time_report_list_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_asn_time_report_list_item,
                NGAP_ZERO, sizeof(ngap_VolumeTimedReport_Item));


        /*Encode all IE's*/

        p_asn_time_report_list_item->startTimeStamp.numocts =
            NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE;

        NGAP_MEMCPY
            (
             p_asn_time_report_list_item->startTimeStamp.data,
             p_local_time_report_list->timed_report_list_item[count].start_time_stamp,
             NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE
            );

        p_asn_time_report_list_item->endTimeStamp.numocts =
            NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE;

        NGAP_MEMCPY
            (
             p_asn_time_report_list_item->endTimeStamp.data,
             p_local_time_report_list->timed_report_list_item[count].end_time_stamp,
             NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE
            );

        p_asn_time_report_list_item->usageCountUL =
            p_local_time_report_list->timed_report_list_item[count].usage_count_uplink;

        p_asn_time_report_list_item->usageCountDL =
            p_local_time_report_list->timed_report_list_item[count].usage_count_downlink;

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_time_report_list, p_time_report_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/**************** Function for Testing purpose only starts here****************/

/*******************************************************************************
 * Function Name    : ngap_encode_ng_setup_fail_test
 * Inputs           : p_value - ASN Structure pointer through which needs to be
 *                    filled.
 * Outputs          : p_local - Local Structure Pointer to encode ASN pointer.
 *
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 *
 * DESCRIPTION	    : This function encodes NG SETUP FAIL message.
 *****************************************************************************/
ngap_return_et ngap_encode_ng_setup_fail_test
(
 ngap_setup_failure_t        *p_ng_setup_fail,
 UInt8                       *p_asn_msg,
 UInt16                      *p_asn_msg_len
 )
{
    ngap_NGAP_PDU           	ngap_pdu;
    OSCTXT                  	asn1_ctx;
    ngap_NGSetupFailure   	    *p_ngap_NGSetupFailure = NGAP_P_NULL;
    ngap_return_et          	response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;

        ngap_pdu.u.unsuccessfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to NG Setup Failure */
        p_ngap_NGSetupFailure = rtxMemAllocTypeZ(&asn1_ctx, ngap_NGSetupFailure);

        if(NGAP_P_NULL == p_ngap_NGSetupFailure)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_UnsuccessfulOutcome_nGSetup(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_ngap_NGSetupFailure);

        /* Encode 3 IEs of NG Setup Failure Message */


        /* Encode IE 2 - Time to Wait  */
        if(NG_SETUP_FAIL_TIME_TO_WAIT_PRESENT &
                p_ng_setup_fail->bitmask)
        {
            /* Encode IE 2 - Time to Wait  */
            ngap_TimeToWait_Root value_ie2 = ngap_v1s;

            value_ie2 = (ngap_TimeToWait_Root)p_ng_setup_fail->time_to_wait_event_id;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupFailure_protocolIEs_2(&asn1_ctx,
                        &p_ngap_NGSetupFailure->protocolIEs, value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - TimeToWait");
                break;
            }
        }

        /* Encode IE 1 - Cause */
        ngap_Cause *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie1)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_setup_fail->choice_cause_group)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_NGSetupFailure_protocolIEs_1(&asn1_ctx,
                    &p_ngap_NGSetupFailure->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - Cause");
            break;
        }

        /* Encode IE 3 - Criticality Diagnostics */
        if(NG_SETUP_FAIL_CRITICALITY_DIAGNOSTICS_PRESENT &
                p_ng_setup_fail->bitmask)
        {

            ngap_CriticalityDiagnostics     *p_value_ie3 = NGAP_P_NULL; 

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ng_setup_fail->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE3 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_NGSetupFailure_protocolIEs_3(&asn1_ctx,
                        &p_ngap_NGSetupFailure->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;
            }

        }    

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Ng setup Fail");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of NG Setup Failure Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}


/******************************************************************************
 * Function Name    : ngap_encode_handover_request
 * Inputs           : p_local_handover_req
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION      : This function encodes NGAP HO Request ASN message from the
 *                    information provided in p_local_handover_req
 *                    This messgae is sent from AMF to T-NG-RAN 
 ****************************************************************************/
ngap_return_et  ngap_encode_handover_request
(
    ngap_handover_request_t *p_local_handover_req,
    UInt8                   *p_asn_msg,
    UInt16                  *p_asn_msg_len
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_HandoverRequest    *p_ngap_HandoverRequest = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
           response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to Handover Request */
        p_ngap_HandoverRequest = rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverRequest);

        if(NGAP_P_NULL == p_ngap_HandoverRequest)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_handoverResourceAllocation(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_HandoverRequest);

        /*Encode all IE's*/

        /*Encode IE1 -ngap_AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID value_ie_1 = NGAP_ZERO;

        value_ie_1 = p_local_handover_req->amf_ue_ngap_id;

        if(NGAP_ASN_OK !=
              asn1Append_ngap_HandoverRequest_protocolIEs_1(&asn1_ctx,
                &p_ngap_HandoverRequest->protocolIEs, value_ie_1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /*Encode IE2 -ngap_HandoverType */
        ngap_HandoverType value_ie_2;

        value_ie_2 = p_local_handover_req->handover_type;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_2(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, value_ie_2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - ngap_HandoverType  to NGAP PDU");
            break;
        }

        /*Encode IE3 - ngap_Cause*/

        ngap_Cause *p_value_ie3 = NGAP_P_NULL;

        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_local_handover_req->choice_cause))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_3(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3 - Cause to NGAP PDU");
            break;
        }

        /*Encode IE4 - ngap_UEAggregateMaximumBitRate */

        ngap_UEAggregateMaximumBitRate *p_value_ie4 = NGAP_P_NULL;
        p_value_ie4  =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UEAggregateMaximumBitRate);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie4->uEAggregateMaximumBitRateDL =
            p_local_handover_req->ue_aggregate_maximum_bit_rate.\
            ue_aggregate_maximum_bit_rate_dl.bit_rate;

        p_value_ie4->uEAggregateMaximumBitRateUL =
            p_local_handover_req->ue_aggregate_maximum_bit_rate.\
            ue_aggregate_maximum_bit_rate_ul.bit_rate;

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_4(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE4 - UE Aggregate Maximum Bit Rate to NGAP PDU");
            break;
        }
      
       /*Encode IE6 - ngap_UESecurityCapabilities*/

        ngap_UESecurityCapabilities *p_value_ie6 = NGAP_P_NULL;

        p_value_ie6 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UESecurityCapabilities);

        if(NGAP_P_NULL == p_value_ie6)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_ue_security_capabilities(
                    &asn1_ctx,
                    p_value_ie6,
                    &p_local_handover_req->ue_security_capabilities))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE6 -  UE Security Capabilities Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_6(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie6))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE6 -  UE Security Capabilities to NGAP PDU");
            break;
        }

        /*Encode IE7 - ngap_SecurityContext*/

        ngap_SecurityContext *p_value_ie7;

        p_value_ie7 = rtxMemAllocTypeZ(&asn1_ctx, ngap_SecurityContext);

        if(NGAP_P_NULL == p_value_ie7)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie7->nextHopChainingCount =
            p_local_handover_req->security_context.next_hop_chaining_count;

        p_value_ie7->nextHopNH.numbits = NGAP_SECURITY_KEY_NUMBITS;//HandOver chnages

        NGAP_MEMCPY(p_value_ie7->nextHopNH.data,
                    p_local_handover_req->security_context.next_hop_nh.security_key,//HandOver changes
                    NGAP_SECURITY_KEY_OCTET_SIZE);

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_7(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie7))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE7 -  Security Context to NGAP PDU");
            break;
        }
        /*Enocode IE8 - ngap_NewSecurityContextInd*/

        if(NGAP_HANDOVER_REQUEST_NEW_SECURITY_CONTEXT_IND_PRESENT &
            p_local_handover_req->bitmask)
        {
            ngap_NewSecurityContextInd value_ie_8;

            value_ie_8 = p_local_handover_req->new_security_ctx_ind;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_8(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, value_ie_8))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE8 -  New Security Context Ind to NGAP PDU");
                break;
            }
        }

        /*Encode IE9 - ngap_NAS_PDU*/
        if(NGAP_HANDOVER_REQUEST_NAS_PDU_PRESENT &
                p_local_handover_req->bitmask)
        {
            ngap_NAS_PDU    *p_value_ie9 = NGAP_P_NULL;
            p_value_ie9 = rtxMemAllocTypeZ(&asn1_ctx, ngap_NAS_PDU);

            if(NGAP_P_NULL == p_value_ie9)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            p_value_ie9->numocts =
                p_local_handover_req->nas_pdu.num_string_len;

            p_value_ie9->data =
                (OSOCTET *)rtxMemAllocZ(&asn1_ctx , p_value_ie9->numocts);

            if(NGAP_FAILURE == p_value_ie9->data)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            NGAP_MEMCPY((void *)p_value_ie9->data ,
                    p_local_handover_req->nas_pdu.string_data,
                    p_value_ie9->numocts);


            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_9(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, p_value_ie9))//HandOver_changes
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE9 -  NAS PDU");
                break;
            }
        }

        /*Encode IE10 - ngap_PDUSessionResourceSetupListHOReq */
        ngap_PDUSessionResourceSetupListHOReq *p_value_ie10 = NGAP_P_NULL;
        OSRTDList                             ngap_HandoverRequestIEs_10;

        rtxDListInit(&ngap_HandoverRequestIEs_10);
        p_value_ie10 = &ngap_HandoverRequestIEs_10;

        if(NGAP_FAILURE == ngap_encode_pdu_session_res_setup_list_HO_req(
                            &asn1_ctx,
                            p_value_ie10,
                            &p_local_handover_req->pdu_session_res_setup_list_HO_req))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to encode PDU Session Resource Setup HO Req");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_10(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie10))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE10 -  PDU SESSION RESOURCE SETUP HO LIST");
            break;
        }

        /*Encode IE11 -ngap_AllowedNSSAI */

        ngap_AllowedNSSAI   *p_value_ie11 = NGAP_P_NULL;
        OSRTDList           ngap_HandoverRequestIEs_11;

        rtxDListInit(&ngap_HandoverRequestIEs_11);

        p_value_ie11 = &ngap_HandoverRequestIEs_11;

        if(NGAP_FAILURE == ngap_encode_ie_allowed_nssai(
                    &asn1_ctx,
                    p_value_ie11,
                    &p_local_handover_req->allowed_nssai_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE11 - Allowed NSSAI Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_11(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie11))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE11 - ngap_AllowedNSSAI");
            break;
        }
        /*Encode IE12-  ngap_TraceActivation*/
        if(NGAP_HANDOVER_REQUEST_TRACE_ACIVATION_PRESENT &
                p_local_handover_req->bitmask)
        {
            ngap_TraceActivation *p_value_ie12 = NGAP_P_NULL;

            p_value_ie12 = rtxMemAllocTypeZ(&asn1_ctx, ngap_TraceActivation);

            if(NGAP_P_NULL == p_value_ie12)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_trace_activation(
                                &asn1_ctx,
                                p_value_ie12,
                                &p_local_handover_req->trace_activation))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE12 - Trace Activation Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_12(&asn1_ctx,
                &p_ngap_HandoverRequest->protocolIEs, p_value_ie12))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE12 -  Trace Activation");
                break;
            }
        }


        /*Encode IE13 - ngap_MaskedIMEISV */
        if(NGAP_HANDOVER_REQUEST_MASKED_IMEISV_PRESENT &
                            p_local_handover_req->bitmask)//HandOver changes in pointer also in nas-pdu and guami
        {
            ngap_MaskedIMEISV *p_value_ie13;

            p_value_ie13 = rtxMemAllocTypeZ(&asn1_ctx, ngap_MaskedIMEISV);

            if(NGAP_P_NULL == p_value_ie13)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            p_value_ie13->numbits =
                NGAP_MASKED_IMEISV_NUMBITS;

            NGAP_MEMCPY(p_value_ie13->data, p_local_handover_req->\
                    masked_imeisv.masked_imeisv,
                    NGAP_MASKED_IMEISV_OCTET_SIZE);

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_13(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, p_value_ie13))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE13 -  ngap_MaskedIMEISV to NGAP PDU");
                break;
            }
        }

        /*Encode IE14 - ngap_SourceToTarget_TransparentContainer*/
        ngap_SourceToTarget_TransparentContainer *p_value_ie14 = NGAP_P_NULL;

        p_value_ie14 = rtxMemAllocTypeZ(&asn1_ctx, ngap_SourceToTarget_TransparentContainer);

        if(NGAP_P_NULL == p_value_ie14)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        } 

        p_value_ie14->data =  (OSOCTET *)rtxMemAllocZ(&asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_FAILURE == p_value_ie14->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
       /*Handover_changes_start*/ 
        if(NGAP_FAILURE == ngap_encode_src_to_trg_transparent_container(
                    p_value_ie14,
                    &p_local_handover_req->src_to_trg_transparent_container))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to encode Source to Target Transparent Container");
            response = NGAP_FAILURE;
            break;
        }
        /*Handover_changes_end*/
        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequest_protocolIEs_14(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie14))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE14 -  ngap_SourceToTarget_TransparentContainer");
            break;
        }

        /*Enocde IE15 - ngap_MobilityRestrictionList*/
        if(NGAP_HANDOVER_REQUEST_MOBILITY_RESTRICTION_LIST_PRESENT &
            p_local_handover_req->bitmask)
        {
            ngap_MobilityRestrictionList *p_value_ie15  = NGAP_P_NULL;

            p_value_ie15 = rtxMemAllocTypeZ(&asn1_ctx, ngap_MobilityRestrictionList);
            if(NGAP_P_NULL == p_value_ie15)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_mobitlity_restriction_list(
                          &asn1_ctx,
                          p_value_ie15,
                          &p_local_handover_req->mobility_restriction_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Failed to encode IE - ngap_MobilityRestrictionList");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_15(&asn1_ctx,
                       &p_ngap_HandoverRequest->protocolIEs, p_value_ie15))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                "Failed to Add IE15 -  ngap_MobilityRestrictionList");
                break;
            }
        }

        /*Encode IE16 - ngap_LocationReportingRequestType*/
        if(NGAP_HANDOVER_REQUEST_LOCATION_REPORTING_REQ_TYPE_PRESENT &
                p_local_handover_req->bitmask)
        {
            ngap_LocationReportingRequestType *p_value_ie16 = NGAP_P_NULL;

            p_value_ie16 = rtxMemAllocTypeZ(&asn1_ctx, ngap_LocationReportingRequestType);
            if(NGAP_P_NULL == p_value_ie16)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            /*fill eventType*/
            p_value_ie16->eventType = p_local_handover_req->location_reposrting_req_type.eventType;

            /*fill reportArea*/
            p_value_ie16->reportArea = p_local_handover_req->location_reposrting_req_type.report_area;

            /*fill areaOfInterestList*/
            if (NGAP_AREA_OF_LIST_PRESENT &
                    p_local_handover_req->location_reposrting_req_type.bitmask)
            {
                p_value_ie16->m.areaOfInterestListPresent = NGAP_TRUE;/*Handover bug fixes*/

            if(NGAP_FAILURE == ngap_encode_area_of_interest_list(
                           &asn1_ctx,
                           &p_value_ie16->areaOfInterestList,
                           &p_local_handover_req->location_reposrting_req_type.area_of_interest))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode Area of interest List");
                response = NGAP_FAILURE;
                break;
            }
            }/*Handover bug fixes*/

            /*fill locationReportingReferenceIDToBeCancelled*/
            
            if(NGAP_LOCATION_REPORTING_REFERENCE_ID_TO_BE_CANCELLED_PRESENT &
                    p_local_handover_req->location_reposrting_req_type.bitmask)
            {
                p_value_ie16->m.locationReportingReferenceIDToBeCancelledPresent = NGAP_TRUE;/*Handover bug fixes*/
            p_value_ie16->locationReportingReferenceIDToBeCancelled =
                p_local_handover_req->location_reposrting_req_type.location_reporting_ref_id_to_be_cancelled;
            }/*Handover bug fixes*/

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_16(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, p_value_ie16))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE16 -  ngap_LocationReportingRequestType");
                break;
            }

        }

       /*Encode IE17 - ngap_RRCInactiveTransitionReportRequest*/
        if(NGAP_HANDOVER_REQUEST_RRC_INACTIVE_TRANSITION_REPORT_REQ_PRESENT &
            p_local_handover_req->bitmask)
        {

            ngap_RRCInactiveTransitionReportRequest value_ie17;

            value_ie17 =
                p_local_handover_req->rrc_inactive_transition_report_req_t;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_17(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, value_ie17))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE17 -  ngap_RRCInactiveTransitionReportRequest");
                break;
            }

        }

        /*Encode IE18 - ngap_GUAMI*/
        ngap_GUAMI *p_value_ie18 = NGAP_P_NULL;
        p_value_ie18 = rtxMemAllocTypeZ(&asn1_ctx, ngap_GUAMI);

        if(NGAP_P_NULL == p_value_ie18)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_guami(
                    &asn1_ctx,
                    p_value_ie18,
                    &p_local_handover_req->guami))
        {   
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE18 -  GUAMI Failed");
            response = NGAP_FAILURE;
            break;
        }
        if(NGAP_ASN_OK != 
                asn1Append_ngap_HandoverRequest_protocolIEs_18(&asn1_ctx,
                    &p_ngap_HandoverRequest->protocolIEs, p_value_ie18))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IEi18 -  GUAMI ");
            break;
        }

        /*Encode IE-19 - ngap_RedirectionVoiceFallback*/
        if(NGAP_HANDOVER_REQUEST_REDIRECTION_VOICE_FALLBACK_PRESENT &
            p_local_handover_req->bitmask)
        {

            ngap_RedirectionVoiceFallback value_ie19;

            value_ie19 = p_local_handover_req->redirection_voice_fallback;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequest_protocolIEs_19(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, value_ie19))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE19 -  ngap_RedirectionVoiceFallback to NGAP_PDU");
                break;
            }
        }
        /*HandOver_changes_start */

        /*Encode IE-20 CN_Assisted_ran_tuning */ 

       if (NGAP_HANDOVER_CN_ASSISTED_RAN_TUNING_PRESENT &
                p_local_handover_req->bitmask) 
        {

            ngap_CNAssistedRANTuning    *p_value_ie;

            p_value_ie  = rtxMemAllocTypeZ(&asn1_ctx, ngap_CNAssistedRANTuning);

            if(NGAP_P_NULL == p_value_ie)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_cn_assisted_ran_tuning(
                        &asn1_ctx,
                        p_value_ie,
                        &p_local_handover_req->cn_assisted_ran_tuning))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE -  CN Assisted ran Tuning");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_HandoverRequest_protocolIEs_20(&asn1_ctx,
                        &p_ngap_HandoverRequest->protocolIEs, p_value_ie
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE - CNAssisted Tuning");
                break;
            }

        }

        /*HandOver chnages end */
        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Request");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Request Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
 
ngap_return_et ngap_encode_pdu_session_res_setup_list_HO_req
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupListHOReq       *p_asn_list,
    ngap_pdu_session_res_setup_list_HO_req_t    *p_local_list
)
{
    ngap_PDUSessionResourceSetupItemHOReq    *p_ngap_pdu_session_res_setup_HO_item = NGAP_P_NULL;
    OSRTDListNode                            *p_node = NGAP_P_NULL;
    ngap_return_et                           response = NGAP_SUCCESS;
    UInt16                                   index    = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceSetupItemHOReq,
                &p_node,
                &p_ngap_pdu_session_res_setup_HO_item);
        if((NGAP_P_NULL == p_ngap_pdu_session_res_setup_HO_item) ||
             (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_res_setup_HO_item,
                    NGAP_ZERO, sizeof(ngap_PDUSessionResourceSetupItemHOReq));

        /*Encode IE1- ngap_PDUSessionID*/
        p_ngap_pdu_session_res_setup_HO_item->pDUSessionID =
            p_local_list->pdu_session_res_setup_list_HO_req_item[index].\
            pdu_session_id;

        /*Encode IE2 - s_NSSAI*/
        p_ngap_pdu_session_res_setup_HO_item->s_NSSAI.sST.numocts =
                        NGAP_SST_OCTET_SIZE;

        NGAP_MEMCPY(p_ngap_pdu_session_res_setup_HO_item->s_NSSAI.sST.data,
            p_local_list->pdu_session_res_setup_list_HO_req_item[index].s_nssai.sst,
            NGAP_SST_OCTET_SIZE);

        if(NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT &
            p_local_list->pdu_session_res_setup_list_HO_req_item[index].s_nssai.bitmask)
        {
            p_ngap_pdu_session_res_setup_HO_item->s_NSSAI.m.sDPresent = NGAP_TRUE;

            p_ngap_pdu_session_res_setup_HO_item->s_NSSAI.sD.numocts =
                            NGAP_SD_OCTET_SIZE;

            NGAP_MEMCPY(p_ngap_pdu_session_res_setup_HO_item->s_NSSAI.sD.data,
                    p_local_list->pdu_session_res_setup_list_HO_req_item[index].s_nssai.sd,
                    NGAP_SD_OCTET_SIZE);
        }

        /*Encode IE3 - handoverRequestTransfer*/
        p_ngap_pdu_session_res_setup_HO_item->handoverRequestTransfer.numocts =
                                        NGAP_MAX_ASN1_BUF_LEN;

        p_ngap_pdu_session_res_setup_HO_item->handoverRequestTransfer.data =
            rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_ngap_pdu_session_res_setup_HO_item->handoverRequestTransfer.data )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

       if ( NGAP_FAILURE ==  ngap_encode_pdu_session_resource_setup_req_transfer(
                &p_ngap_pdu_session_res_setup_HO_item->\
                handoverRequestTransfer,
                &p_local_list->pdu_session_res_setup_list_HO_req_item[index].\
                handover_req_transfer
             ))
       {
           RRC_NGAP_TRACE(NGAP_ERROR,
                   "Failed to encode IE -PDU Session Resource Setup Request transfer ");
           response = NGAP_FAILURE;
           break;
       }

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}


ngap_return_et ngap_encode_mobitlity_restriction_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_MobilityRestrictionList            *p_asn_mobility_restriction_list,
    ngap_mobility_restriction_list_t        *p_local_mobility_restriction_list
)
{
    ngap_return_et              response = NGAP_SUCCESS;
    UInt8                       index    = NGAP_ZERO;


    RRC_NGAP_UT_TRACE_ENTER();

    /*Encode ngap_PLMNIdentity*/
    p_asn_mobility_restriction_list->servingPLMN.numocts =
       NGAP_PLMN_IDENTITY_MAX_BYTES;

    NGAP_MEMCPY(p_asn_mobility_restriction_list->servingPLMN.data,
                p_local_mobility_restriction_list->serving_plmn.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES);

    /*Encode ngap_EquivalentPLMNs*/
    if(NGAP_MOBILITY_RESTRICTION_EQUIVALENT_PLMN_PRESENT &
        p_local_mobility_restriction_list->bitmask)/*Handover bug fixes*/
    {
        p_asn_mobility_restriction_list->m.equivalentPLMNsPresent =
                                                        NGAP_TRUE;

        p_asn_mobility_restriction_list->equivalentPLMNs.n =
            p_local_mobility_restriction_list->equivalent_plmn.num_equivalent_plmn;/*Handover bug fixes*/
        for ( index = NGAP_ZERO; index < p_local_mobility_restriction_list->equivalent_plmn.num_equivalent_plmn; index++ )
        {
             p_asn_mobility_restriction_list->equivalentPLMNs.elem[index].numocts =
                           NGAP_PLMN_IDENTITY_MAX_BYTES;

             NGAP_MEMCPY
             (
                p_asn_mobility_restriction_list->equivalentPLMNs.\
                    elem[index].data,
                 p_local_mobility_restriction_list->equivalent_plmn.\
                    equivalent_plmn[index].plmn_identity.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES
                );/*Handover bug fixes*/
        }

    }

    /*Encode IE - RAT RESTRICTION*/
    if(NGAP_MOBILITY_RESTRICTION_RAT_RESTRICTION_PRESENT &
                p_local_mobility_restriction_list->bitmask)
    {
        p_asn_mobility_restriction_list->m.rATRestrictionsPresent =
                                                         NGAP_TRUE;/*Handover bug fixes*/
        if(NGAP_FAILURE == ngap_encode_rat_restriction_list(
                p_asn1_ctx,
                &p_asn_mobility_restriction_list->rATRestrictions,
                &p_local_mobility_restriction_list->rat_restriction))//HandOver changes
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode ngap_RATRestrictions");
            response= NGAP_FAILURE;
            return response;
        }

    }

    /*Encode IE - ngap_ForbiddenAreaInformation*/
    if(NGAP_MOBILITY_RESTRICTION_FORBIDDEN_AREA_INFO_PRESENT &
                p_local_mobility_restriction_list->bitmask)
    {
        p_asn_mobility_restriction_list->m.forbiddenAreaInformationPresent =
                                                         NGAP_TRUE;

        if(NGAP_FAILURE == ngap_encode_forbidden_area_info(
                p_asn1_ctx,
                &p_asn_mobility_restriction_list->forbiddenAreaInformation,
                &p_local_mobility_restriction_list->forbidden_area_information))//HandOver changes
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode ngap_ForbiddenAreaInformation");
            response= NGAP_FAILURE;
            return response;
        }
    }

    /*Encode IE - ngap_ServiceAreaInformation*/
    if(NGAP_MOBILITY_SERVING_AREA_INFO_PRESENT &
                p_local_mobility_restriction_list->bitmask)
    {
        p_asn_mobility_restriction_list->m.serviceAreaInformationPresent =
                                                         NGAP_TRUE;

        if(NGAP_FAILURE == ngap_encode_service_area_info(
                p_asn1_ctx,
                &p_asn_mobility_restriction_list->serviceAreaInformation,
                &p_local_mobility_restriction_list->service_area_information))//HandOver changes
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode ngap_ServiceAreaInformation");
            response= NGAP_FAILURE;
            return response;
        }
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et  ngap_encode_service_area_info
(
    OSCTXT                              *p_asn1_ctx,
    ngap_ServiceAreaInformation         *p_asn_service_area_info_list,
    ngap_service_area_information_t     *p_local_service_area_info_list
)
{
    ngap_ServiceAreaInformation_Item      *p_service_area_info_item = NGAP_P_NULL;
    OSRTDListNode                         *p_node = NGAP_P_NULL;
    ngap_return_et                        response = NGAP_SUCCESS;
    UInt8                                 index = NGAP_ZERO;
    UInt8                                 index1 = NGAP_ZERO;

    NGAP_ASSERT(NGAP_P_NULL != p_local_service_area_info_list)

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_service_area_info_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <
            p_local_service_area_info_list->count; index ++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_ServiceAreaInformation_Item,
                &p_node,
                &p_service_area_info_item);

        if ( (NGAP_P_NULL == p_node) ||
                (NGAP_P_NULL == p_service_area_info_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_service_area_info_item,
                NGAP_ZERO, sizeof(ngap_ServiceAreaInformation_Item));

        /*Encode IE - ngap_PLMNIdentity*/
        p_service_area_info_item->pLMNIdentity.numocts =
            NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY(p_service_area_info_item->pLMNIdentity.data,
                p_local_service_area_info_list->\
                service_area_information_item[index].\
                plmn_identity.plmn_id_bytes,
                NGAP_PLMN_IDENTITY_MAX_BYTES);

        /*Encode IE - ngap_AllowedTACs*/
        if(NGAP_SERVICE_AREA_INFO_ALLOWED_TAC_PRESENT &
                p_local_service_area_info_list->\
                service_area_information_item[index].bitmask)
        {
            p_service_area_info_item->m.allowedTACsPresent = NGAP_TRUE;/*Handover bug fixes*/                
            
            p_service_area_info_item->allowedTACs.n = 
                p_local_service_area_info_list->\
                service_area_information_item[index].allowed_tac.count;/*Handover bug fixes*/

            for(index1 = 0; index1 < p_service_area_info_item->allowedTACs.n; index1++)/*Handover Bug fixes*/
            {
                p_service_area_info_item->allowedTACs.elem[index1].numocts =
                    NGAP_TAC_OCTET_SIZE;

                NGAP_MEMCPY(p_service_area_info_item->allowedTACs.elem[index].data,
                        p_local_service_area_info_list->service_area_information_item[index].allowed_tac.\
                        tac_t[index].tac,
                        NGAP_TAC_OCTET_SIZE);/*Handover bug fixes*/
            }
        }

        /*Encode IE - ngap_NotAllowedTACs */
        if(NGAP_SERVICE_AREA_INFO_NOT_ALLOWED_TAC_PRESENT &
                p_local_service_area_info_list->\
                service_area_information_item[index].bitmask)
        {
            p_service_area_info_item->m.notAllowedTACsPresent = NGAP_TRUE;/*Handover bug fixes*/

            p_service_area_info_item->notAllowedTACs.n = 
            p_local_service_area_info_list->\
            service_area_information_item[index].not_allowed_tac.count;/*Handover bug fixes*/

            for(index1 = 0; index1 < p_service_area_info_item->notAllowedTACs.n ; index1++)/*Handover bug fixes*/
            {
                p_service_area_info_item->notAllowedTACs.elem[index1].numocts =
                    NGAP_TAC_OCTET_SIZE;

                NGAP_MEMCPY(p_service_area_info_item->notAllowedTACs.elem[index].data,
                        p_local_service_area_info_list->service_area_information_item[index].not_allowed_tac.\
                        tac_t[index].tac,
                        NGAP_TAC_OCTET_SIZE);
            }/*Handover bug fixes*/
        }

        rtxDListAppendNode(p_asn_service_area_info_list,  p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et ngap_encode_rat_restriction_list
(
    OSCTXT                  *p_asn1_ctx,
    ngap_RATRestrictions    *p_asn_rat_restriction_list,
    ngap_rat_restriction_t  *p_local_rat_restriction_list
)
{
    ngap_RATRestrictions_Item   *p_rat_restriction_item = NGAP_P_NULL;
    OSRTDListNode               *p_node = NGAP_P_NULL;
    ngap_return_et              response = NGAP_SUCCESS;
    UInt8                       index = NGAP_ZERO;

    NGAP_ASSERT(NGAP_P_NULL != p_local_rat_restriction_list)

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_rat_restriction_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <
                 p_local_rat_restriction_list->count; index ++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_RATRestrictions_Item,
                &p_node,
                &p_rat_restriction_item);

        if ( (NGAP_P_NULL == p_node) ||
                (NGAP_P_NULL == p_rat_restriction_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET((void *)p_rat_restriction_item,
                NGAP_ZERO, sizeof(ngap_RATRestrictions_Item));

        /*Encode IE - ngap_PLMNIdentity*/
        p_rat_restriction_item->pLMNIdentity.numocts =
          NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY((void *)p_rat_restriction_item->pLMNIdentity.data,
                    p_local_rat_restriction_list->rat_restriction_item[index].plmn_identity.plmn_id_bytes,
                    NGAP_PLMN_IDENTITY_MAX_BYTES);

        /*Encode IE - ngap_RATRestrictionInformation*/
        p_rat_restriction_item->rATRestrictionInformation.numbits = NGAP_EIGHT; /*Handover bug fixes*/
 //               NGAP_RAT_RESTRICTION_INFORMATION_SET_ID_OCTET_SIZE;

        p_rat_restriction_item->rATRestrictionInformation.data =
                (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, NGAP_ONE);

        if(NGAP_P_NULL == p_rat_restriction_item->rATRestrictionInformation.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

       /* NGAP_MEMSET((void *)p_rat_restriction_item->rATRestrictionInformation.data,
                    NGAP_ZERO, sizeof(ngap_RATRestrictionInformation));*/

        NGAP_MEMCPY((void *)p_rat_restriction_item->rATRestrictionInformation.data,
                    p_local_rat_restriction_list->rat_restriction_item[index].\
                    rat_restriction_information,
                    NGAP_RAT_RESTRICTION_INFORMATION_SET_ID_OCTET_SIZE);

        rtxDListAppendNode(p_asn_rat_restriction_list, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et  ngap_encode_forbidden_area_info
(
    OSCTXT                              *p_asn1_ctx,
    ngap_ForbiddenAreaInformation       *p_asn_forbidden_area_info_list,
    ngap_forbidden_area_information_t   *p_local_forbidden_area_info_list
)
{
    ngap_ForbiddenAreaInformation_Item    *p_forbidden_area_info_item = NGAP_P_NULL;
    OSRTDListNode                         *p_node = NGAP_P_NULL;
    ngap_return_et                        response = NGAP_SUCCESS;
    UInt8                                 index = NGAP_ZERO;
    UInt32                                index1 = NGAP_ZERO;

    NGAP_ASSERT(NGAP_P_NULL != p_local_forbidden_area_info_list)

    RRC_NGAP_UT_TRACE_ENTER();

    if(NGAP_ZERO == p_local_forbidden_area_info_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index <
                 p_local_forbidden_area_info_list->count; index ++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_ForbiddenAreaInformation_Item,
                &p_node,
                &p_forbidden_area_info_item);

        if ( (NGAP_P_NULL == p_node) ||
                (NGAP_P_NULL == p_forbidden_area_info_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_forbidden_area_info_item,
                NGAP_ZERO, sizeof(ngap_ForbiddenAreaInformation_Item));

        /*Encode IE - ngap_PLMNIdentity*/
        p_forbidden_area_info_item->pLMNIdentity.numocts =
          NGAP_PLMN_IDENTITY_MAX_BYTES;

        NGAP_MEMCPY(p_forbidden_area_info_item->pLMNIdentity.data,
                    p_local_forbidden_area_info_list->\
                    forbidden_area_information_item[index].\
                    plmn_identity.plmn_id_bytes,
                    NGAP_PLMN_IDENTITY_MAX_BYTES);

        /*Encode IE - ngap_ForbiddenTACs*/
        /*Handover bug fixes start*/
        p_forbidden_area_info_item->forbiddenTACs.n = 
            p_local_forbidden_area_info_list->forbidden_area_information_item[index].forbidden_tac.count;

        for(index1 = NGAP_ZERO; index1 < p_forbidden_area_info_item->forbiddenTACs.n; index1++)
        /*Handover bug fixes end*/
        {
            p_forbidden_area_info_item->forbiddenTACs.\
            elem[index1].numocts = NGAP_TAC_OCTET_SIZE;

            NGAP_MEMCPY
            (   p_forbidden_area_info_item->\
                forbiddenTACs.elem[index1].data,
                p_local_forbidden_area_info_list->\
                forbidden_area_information_item[index].\
                forbidden_tac.tac_t[index1].tac,
                NGAP_TAC_OCTET_SIZE
            );/*Handover bug fixes*/
        }

        rtxDListAppendNode(p_asn_forbidden_area_info_list, p_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;

}

ngap_return_et  ngap_encode_handover_prepartion_failure
(
    ngap_handover_preparation_failure_t     *p_local_ho_prep_failure,   /* Input - Local Buffer */
    UInt8                                   *p_asn_msg,                 /* Output - ASN Encoded Buffer */
    UInt16                                  *p_asn_msg_len              /*Output - ASN Encoded Buffer Length */
)
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_HandoverPreparationFailure         *p_asn_ho_prepartion_failure = NGAP_P_NULL;
    ngap_return_et                          response =  NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;

        ngap_pdu.u.unsuccessfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);

        if(NGAP_P_NULL ==  ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_asn_ho_prepartion_failure =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverPreparationFailure );

        if(NGAP_P_NULL == p_asn_ho_prepartion_failure )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }


        asn1SetTC_ngap_UnsuccessfulOutcome_handoverPreparation(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_asn_ho_prepartion_failure);


        /* Encode 4IEs of NGAP HANDOVER PREPARATION FAILURE */

        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID value_ie1;/*ASN HPF  IE1 ptr */

        value_ie1 = (ngap_AMF_UE_NGAP_ID)p_local_ho_prep_failure->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverPreparationFailure_protocolIEs_1(
                            &asn1_ctx,&p_asn_ho_prepartion_failure->protocolIEs, 
                            value_ie1
        ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */

        ngap_RAN_UE_NGAP_ID value_ie2;/*ASN HPF  IE2 ptr */

        value_ie2 = (ngap_RAN_UE_NGAP_ID)p_local_ho_prep_failure->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverPreparationFailure_protocolIEs_2(&asn1_ctx,
                            &p_asn_ho_prepartion_failure->protocolIEs, value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE 3 - Choice cause group  */
        ngap_Cause *p_value_ie3 = NGAP_P_NULL;

        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        
        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_local_ho_prep_failure->cause))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverPreparationFailure_protocolIEs_3(&asn1_ctx,
                    &p_asn_ho_prepartion_failure->protocolIEs, p_value_ie3))

        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3 - Cause");
            response = NGAP_FAILURE;
            break;
        }

        /* Encode IE 4 - Critically Dignostics */

        if(NGAP_HANDOVER_PREPRATON_FAILURE_CRITICALITY_DIGNOSTICS &
                p_local_ho_prep_failure->bitmask )

        {
            ngap_CriticalityDiagnostics  *p_value_ie4 = NGAP_P_NULL;

            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_local_ho_prep_failure->critically_dignostics))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE4 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverPreparationFailure_protocolIEs_4(&asn1_ctx,
                        &p_asn_ho_prepartion_failure->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - Criticality Diagnostics");
                response  = NGAP_FAILURE;
                break;
            }
        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Handover Preparation fail Failed");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
           RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for  Handover Preparation fail Failed");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of  Handover Preparation fail Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }


    }while(0);

    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

ngap_return_et ngap_encode_up_transport_layer_info
(
 ngap_UPTransportLayerInformation       *p_asn_msg,
 ngap_up_transport_layer_information_t  *p_local_msg
)
{
    OSCTXT                              asn1_ctx1;
    ngap_return_et                      response = NGAP_SUCCESS;

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }//HandOver changes

    do
    {
        p_asn_msg->u.gTPTunnel = 
            (ngap_GTPTunnel *)rtxMemAllocTypeZ(&asn1_ctx1, ngap_GTPTunnel);

        if(NGAP_P_NULL == p_asn_msg->u.gTPTunnel)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        switch(p_local_msg->choice_type)
        {
            case UP_TRANSPORT_LAYER_INFO_GP_TUNNEL:
            {
                p_asn_msg->t =
                    T_ngap_UPTransportLayerInformation_gTPTunnel;

                p_asn_msg->u.gTPTunnel->transportLayerAddress.\
                    numbits = NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                p_asn_msg->u.gTPTunnel->transportLayerAddress.\
                    data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

        if(NGAP_P_NULL ==
                        p_asn_msg->u.gTPTunnel->transportLayerAddress.data)
        {
                    NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
                    break;
        }
        
                NGAP_MEMCPY((void *)p_asn_msg->u.\
                        gTPTunnel->transportLayerAddress.data,
                        p_local_msg->gtp_tunnel.transport_layer_address,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                /*encode gtp_TEID*/
                p_asn_msg->u.gTPTunnel->gTP_TEID.numocts =
                    NGAP_GTP_TUNNEL_TEID;

                NGAP_MEMCPY
                    (
                     (void *)p_asn_msg->u.gTPTunnel->gTP_TEID.data,
                     &p_local_msg->gtp_tunnel.gtp_TEID,
                     NGAP_GTP_TUNNEL_TEID
                    );

                break;
            }

            default:
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Invalid choice for gtp Tunnel[%d]", 
                        p_local_msg->choice_type);

                response = NGAP_FAILURE;
                break;
            }
        }
    }while(0);

    return response;
}

ngap_return_et ngap_encode_data_fwding_resp_drb_list 
(
 OSCTXT                                 *p_asn1_ctx,
 ngap_DataForwardingResponseDRBList     *p_ngap_asn_list,
 nagp_data_fwding_response_drb_list_t   *p_local_list
)
{
    ngap_DataForwardingResponseDRBItem  *p_ngap_asn_item = NGAP_P_NULL;
    OSRTDListNode                       *p_asn_item_node = NGAP_P_NULL;
    ngap_return_et                      response         = NGAP_SUCCESS;
    UInt16			                    count            = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Atleast 1 item shall be present*/
    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No Data Fwding Resp DRB list present");
        response = NGAP_FAILURE;
    }

    for(count = NGAP_ZERO;
            count < p_local_list->count; 
            count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_DataForwardingResponseDRBItem,
                &p_asn_item_node,
                &p_ngap_asn_item);

        if((NGAP_P_NULL == p_asn_item_node) ||
                (NGAP_P_NULL == p_ngap_asn_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
    }

        NGAP_MEMSET(p_ngap_asn_item, NGAP_ZERO, sizeof(ngap_DataForwardingResponseDRBItem));
        
        /*encode drb_id*/
        p_ngap_asn_item->dRB_ID =
            p_local_list->data_fwding_resp_drb_item[count].\
            drb_id;

        /*Encode IE dLForwardingUP_TNLInformation*/
        if(NGAP_DL_FWDING_UP_TUNNEL_INFO_PRESENT &
                p_local_list->data_fwding_resp_drb_item[count].bitmask)
    {
            p_ngap_asn_item->m.dLForwardingUP_TNLInformationPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_up_transport_layer_info(
                    &p_ngap_asn_item->dLForwardingUP_TNLInformation,
                    &p_local_list->data_fwding_resp_drb_item[count].\
                    dl_fwding_up_tunnel_info))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode dLForwardingUP_TNLInformation");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode IE uLForwardingUP_TNLInformation*/
        if(NGAP_UL_FWDING_UP_TUNNEL_INFO_PRESENT &
                p_local_list->data_fwding_resp_drb_item[count].bitmask)
        {
            p_ngap_asn_item->m.uLForwardingUP_TNLInformationPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_up_transport_layer_info(
                    &p_ngap_asn_item->uLForwardingUP_TNLInformation,
                    &p_local_list->data_fwding_resp_drb_item[count].\
                    ul_fwding_up_tunnel_info))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode uLForwardingUP_TNLInformation");
            response = NGAP_FAILURE;
            break;
            }
        }

        rtxDListAppendNode(p_ngap_asn_list, p_asn_item_node);
    }
        
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et ngap_encode_qos_flow_to_be_fwd_list 
(
 OSCTXT                         *p_asn1_ctx,
 ngap_QosFlowToBeForwardedList  *p_ngap_asn_list,
 ngap_qos_flow_to_be_fwd_list_t *p_local_list
)
{
    ngap_QosFlowToBeForwardedItem   *p_ngap_asn_item = NGAP_P_NULL;
    OSRTDListNode                   *p_asn_item_node = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;
    UInt16			                count   = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Atleast 1 item shall be present*/
    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No QOS to be FWD list present");
        response = NGAP_FAILURE;
    }

    for(count = NGAP_ZERO;
            count < p_local_list->count; 
            count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowToBeForwardedItem,
                &p_asn_item_node,
                &p_ngap_asn_item);

        if((NGAP_P_NULL == p_asn_item_node) ||
                (NGAP_P_NULL == p_ngap_asn_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_asn_item, NGAP_ZERO, sizeof(ngap_QosFlowToBeForwardedItem));
        
        /*encode qosFlowIdentifier*/
        p_ngap_asn_item->qosFlowIdentifier  =
            p_local_list->qos_flow_usage_report_item[count].\
            qos_flow_identifier;

        rtxDListAppendNode(p_ngap_asn_list, p_asn_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et ngap_pdu_session_res_list_ho_command_transfer
(
 OSDynOctStr                *p_value,
 ho_command_transfer_t      *p_local
)
{
    ngap_HandoverCommandTransfer        *p_pdu_session_ho_cmd_transfer;
    OSCTXT                              asn1_ctx1;
    ngap_return_et                      response = NGAP_SUCCESS;
    UInt8                               encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_pdu_session_ho_cmd_transfer=
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_HandoverCommandTransfer);

        if(NGAP_P_NULL == p_pdu_session_ho_cmd_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE dLForwardingUP_TNLInformation*/
        if(NGAP_HO_COMMAND_TRANSFER_DL_FWDING_UP_TUNNEL_INFO_PRESENT &
                p_local->bitmask)
        {
            p_pdu_session_ho_cmd_transfer->m.dLForwardingUP_TNLInformationPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_up_transport_layer_info(
                        &p_pdu_session_ho_cmd_transfer->dLForwardingUP_TNLInformation,
                        &p_local->dl_fwding_up_tunnel_info))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode dLForwardingUP_TNLInformation");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode IE - qosFlowToBeForwardedList*/
        if(NGAP_HO_COMMAND_TRANSFER_QOS_FLOW_FORWARD_LIST_PRESENT &
                p_local->bitmask)
        {
            p_pdu_session_ho_cmd_transfer->m.qosFlowToBeForwardedListPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_qos_flow_to_be_fwd_list(
                        &asn1_ctx1,
                        &p_pdu_session_ho_cmd_transfer->qosFlowToBeForwardedList,
                        &p_local->qos_flow_fwd_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode qosFlowToBeForwardedList");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*Encode IE - dataForwardingResponseDRBList*/
        if(NGAP_HO_COMMAND_TRANSFER_DATA_FWDING_RESP_DRB_LIST_PRESENT &
                p_local->bitmask)
        {
            p_pdu_session_ho_cmd_transfer->m.dataForwardingResponseDRBListPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_data_fwding_resp_drb_list(
                        &asn1_ctx1,
                        &p_pdu_session_ho_cmd_transfer->dataForwardingResponseDRBList,
                        &p_local->data_fwding_resp_drb_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode dataForwardingResponseDRBList");
                response = NGAP_FAILURE;
                break;
            }
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Command Transfer");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != asn1PE_ngap_HandoverCommandTransfer( &asn1_ctx1,
                    p_pdu_session_ho_cmd_transfer))
        {
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Command Transfer Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverCommandTransfer(
                    &asn1_ctx1, 
                    "PDU_SESSION_HO_CMD_TRANSFER",
                    p_pdu_session_ho_cmd_transfer);

            encoded_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

ngap_return_et    ngap_encode_pdu_session_resource_handover_list
(
    OSCTXT                                          *p_asn1_ctx,
    /*ASN Buffer*/
    ngap_PDUSessionResourceHandoverList             *p_ngap_asn_pdu_session_res_list,
    /*Local Structure*/
    ngap_pdu_session_res_ho_list_t                  *p_ngap_local_pdu_session_res_list
)
{
    ngap_PDUSessionResourceHandoverItem
        *p_ngap_pdu_session_resource_handover_item = NGAP_P_NULL;/*ASN Item List */

    OSRTDListNode     *p_pdu_session_res_ho_node   =    NGAP_P_NULL;
    ngap_return_et                     response    =    NGAP_SUCCESS;
    UInt16                             index       =    NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Check if list is present or not*/

    if(NGAP_ZERO == p_ngap_local_pdu_session_res_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    if(NGAP_MAX_NO_OF_PDU_SESSION <
            p_ngap_local_pdu_session_res_list->count )
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"Value of count exceeds the max count of %d",
                NGAP_MAX_NO_OF_PDU_SESSION);

        response = NGAP_FAILURE;

        return response;
    }

    for(index = NGAP_ZERO ; index <
            p_ngap_local_pdu_session_res_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceHandoverItem,
                &p_pdu_session_res_ho_node,
                &p_ngap_pdu_session_resource_handover_item);
        if((NGAP_P_NULL == p_pdu_session_res_ho_node) ||
                (NGAP_P_NULL == p_ngap_pdu_session_resource_handover_item ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_resource_handover_item, NGAP_ZERO,
                sizeof(ngap_PDUSessionResourceHandoverItem ));

        /*Encode PDU Session ID*/

        p_ngap_pdu_session_resource_handover_item->pDUSessionID =
            p_ngap_local_pdu_session_res_list->\
            pdu_session_res_ho_item_list[index].pdu_session_id.pdu_session_id;

        /*Encode Handover Command Transfer*/

        p_ngap_pdu_session_resource_handover_item->handoverCommandTransfer.data =
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_ngap_pdu_session_resource_handover_item->handoverCommandTransfer.data)
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        response = 
            ngap_pdu_session_res_list_ho_command_transfer(
                    &p_ngap_pdu_session_resource_handover_item->\
                    handoverCommandTransfer,
                    &p_ngap_local_pdu_session_res_list->pdu_session_res_ho_item_list[index].\
                    handover_cmd_transfer);
        
         /*Append list to the node */
         rtxDListAppendNode(p_ngap_asn_pdu_session_res_list, p_pdu_session_res_ho_node );

    }
    
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et ngap_encode_pdu_session_res_to_rel_ho_list
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_PDUSessionResourceToReleaseListHOCmd       *p_asn_pdu_res_to_rel_list,
    ngap_pdu_session_res_to_rel_list_ho_cmd_t       *p_local_pdu_res_to_rel_list
)
{
    ngap_PDUSessionResourceToReleaseItemHOCmd
        *p_ngap_pdu_session_res_to_rel_item_ho_cmd     = NGAP_P_NULL;
    OSRTDListNode     *p_ue_resource_to_rel_item_node  = NGAP_P_NULL;
    ngap_return_et  response    =   NGAP_SUCCESS;
    UInt16          index       =   NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
    /*Check if list is present or not*/

    if(NGAP_ZERO ==
            p_local_pdu_res_to_rel_list->count )
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "List is empty");
        response = NGAP_FAILURE;
        return response;
    }

    if (NGAP_MAX_NO_OF_PDU_SESSION <
            p_local_pdu_res_to_rel_list->count  )
    {
        RRC_NGAP_TRACE(NGAP_ERROR,"Value of count exceeds the max count of %d",
                NGAP_MAX_NO_OF_PDU_SESSION);
        response = NGAP_FAILURE;
        return response;

    }

    for(index = NGAP_ZERO; index <
            p_local_pdu_res_to_rel_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_PDUSessionResourceToReleaseItemHOCmd,
                &p_ue_resource_to_rel_item_node,
                &p_ngap_pdu_session_res_to_rel_item_ho_cmd);


        if((NGAP_P_NULL == p_ue_resource_to_rel_item_node) ||
                    (NGAP_P_NULL == p_ngap_pdu_session_res_to_rel_item_ho_cmd))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET(p_ngap_pdu_session_res_to_rel_item_ho_cmd,
                NGAP_ZERO,
                sizeof( ngap_PDUSessionResourceToReleaseItemHOCmd));

        /* Encode IE of ngap_PDUSessionResourceToReleaseItemHOCmd*/
        
        p_ngap_pdu_session_res_to_rel_item_ho_cmd->pDUSessionID =
            p_local_pdu_res_to_rel_list->pdu_session_res_to_rel_item_ho_cmd_list[index].
            pdu_session_id.pdu_session_id;


        /*Encode handover preparation unsuccessful transfer */

        //HandOver_changes
        p_ngap_pdu_session_res_to_rel_item_ho_cmd->\
        handoverPreparationUnsuccessfulTransfer.numocts = 
                NGAP_MAX_ASN1_BUF_LEN;/*Handover bug fixes*/

        p_ngap_pdu_session_res_to_rel_item_ho_cmd->\
            handoverPreparationUnsuccessfulTransfer.data =
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL ==
                p_ngap_pdu_session_res_to_rel_item_ho_cmd->handoverPreparationUnsuccessfulTransfer.data)
        {

            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }
       if (NGAP_FAILURE == ngap_encode_handover_preparation_unsussessful_transfer(
                &p_ngap_pdu_session_res_to_rel_item_ho_cmd->\
                handoverPreparationUnsuccessfulTransfer,
                &p_local_pdu_res_to_rel_list->\
                pdu_session_res_to_rel_item_ho_cmd_list[index].\
                handover_prep_unsuccess_transfer))
       {
            RRC_NGAP_TRACE
            (NGAP_ERROR,
            "Encoding of Handover Preparation Unsuccessful Transfer Failed");
            response = NGAP_FAILURE;
            break;

       }

        /*Append list to the node */

        rtxDListAppendNode(p_asn_pdu_res_to_rel_list,
                p_ue_resource_to_rel_item_node);
    }

  RRC_NGAP_UT_TRACE_EXIT();
  return response;

}
/*HandOver_changes_start*/
ngap_return_et  ngap_encode_handover_preparation_unsussessful_transfer
(
    OSDynOctStr                                     *p_value,
    ngap_ho_preparation_unsuccessful_transfer_t     *p_local
)
{
    ngap_HandoverPreparationUnsuccessfulTransfer 
            *p_ho_preparation_unsuccessful_transfer = NGAP_P_NULL;


    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_ho_preparation_unsuccessful_transfer = 
            rtxMemAllocTypeZ(&asn1_ctx1 , ngap_HandoverPreparationUnsuccessfulTransfer );

        
        if(NGAP_P_NULL == p_ho_preparation_unsuccessful_transfer )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE Cause */
        
        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx1,
                    &p_ho_preparation_unsuccessful_transfer->cause,
                    &p_local->id_cause))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1,
                (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for handover Preparation unsuccessful transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PE_ngap_HandoverPreparationUnsuccessfulTransfer(&asn1_ctx1, 
                    p_ho_preparation_unsuccessful_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of HandoverPreparationUnsuccessfulTransfer Failed ");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverPreparationUnsuccessfulTransfer(
                    &asn1_ctx1,
                    "HandoverPreparationUnsuccessfulTransfer", 
                    p_ho_preparation_unsuccessful_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*HandOver_changes_end*/



/******************************************************************************
 * Function Name    : ngap_encode_handover_command 
 * Inputs           : p_ngap_local_ho_command - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Command ASN message from the
 *				      information provided in p_ngap_local_ho_command 
 *				      This messgae is successful response of HO REQUIRED and is 
 *				      send from AMF to S-NG-RAN 
 *****************************************************************************/
ngap_return_et ngap_encode_handover_command
(
    ngap_handover_command_t         *p_ngap_local_ho_command,/* Input - Local Buffer */
    UInt8                           *p_asn_msg,   /* Output - ASN Encoded Buffer */
    UInt16                          *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
)
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_HandoverCommand    *p_asn_ho_command = NGAP_P_NULL;
    ngap_return_et          response          = NGAP_FAILURE;

    NGAP_ASSERT(NGAP_P_NULL != p_ngap_local_ho_command);

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;
        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;

        }

        /* Set the successsfull outcome type to Handover Command */
        p_asn_ho_command = rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverCommand);

        if(NGAP_P_NULL == p_asn_ho_command)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_handoverPreparation(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_asn_ho_command );

        /*Encode 8 IEs of Handover Command */


        /* Encode IE 1 - AMF_UE_NGAP_ID */

        ngap_AMF_UE_NGAP_ID      value_ie1;/*ASN HOC  IE1 ptr */

        value_ie1 = p_ngap_local_ho_command->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCommand_protocolIEs_1(
                    &asn1_ctx,
                    &p_asn_ho_command->protocolIEs, 
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */
        ngap_RAN_UE_NGAP_ID    value_ie2;/*ASN HOC  IE2 ptr */

        value_ie2 = p_ngap_local_ho_command->ran_ue_ngap_id;


        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCommand_protocolIEs_2(&asn1_ctx,&p_asn_ho_command->protocolIEs, value_ie2 ) )
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /* Encode IE 3 - Handover type */

        ngap_HandoverType   value_ie3;/*ASN HOC  IE3 ptr */
        value_ie3 = p_ngap_local_ho_command->handover_type;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCommand_protocolIEs_3(&asn1_ctx,&p_asn_ho_command->protocolIEs, value_ie3  ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;

        }

        /*Encode IE 4 - NAS Security Parameters From NGRAN */

        ngap_NASSecurityParametersFromNGRAN *p_value_ie4 = NGAP_P_NULL; /*ASN HOC IE4 ptr */

        p_value_ie4 =  rtxMemAllocTypeZ(&asn1_ctx, ngap_NASSecurityParametersFromNGRAN );


        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        p_value_ie4->numocts =\
            p_ngap_local_ho_command->nas_sec_param_from_ngran.num_string_len;

        p_value_ie4->data = (OSOCTET *)rtxMemAllocZ(&asn1_ctx, p_value_ie4->numocts);

        if(NGAP_P_NULL == p_value_ie4->data )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        NGAP_MEMCPY
            (
             (void *)p_value_ie4->data,
             p_ngap_local_ho_command->nas_sec_param_from_ngran.string_data,
             p_ngap_local_ho_command->nas_sec_param_from_ngran.num_string_len
            );

       if(NGAP_ASN_OK != asn1Append_ngap_HandoverCommand_protocolIEs_4( &asn1_ctx,
                    &p_asn_ho_command->protocolIEs , p_value_ie4 ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,"Failed to Add IE1 - Global RAN Node Id to NGAP PDU");
            break;
        }

        /*Encode IEs 5 - PDU Session Resource Handover List */

        ngap_PDUSessionResourceHandoverList *p_value_ie5 = NGAP_P_NULL;

        OSRTDList  ngap_pdu_session_ie5;

        rtxDListInit(&ngap_pdu_session_ie5);

        p_value_ie5 =  &ngap_pdu_session_ie5;

        if (NGAP_FAILURE ==
                ngap_encode_pdu_session_resource_handover_list(
                    &asn1_ctx,
                    p_value_ie5,
                    &p_ngap_local_ho_command->pdu_session_ho_list ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encodeing of IE5 - PDU Session Resource Handover list Failed ");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverCommand_protocolIEs_5(&asn1_ctx,
                    &p_asn_ho_command->protocolIEs,p_value_ie5 ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE5 PDU Session Resource Handover list");
            break;

        }

        /*Encode IEs 6 - PDU Session Resource To Release List HO Cmd */
        if (HANDOVER_COMMAND_PDU_SESSION_RESOURCE_TO_RELEASE_LIST_HO_CMD &
                p_ngap_local_ho_command->bitmask)
        {

            ngap_PDUSessionResourceToReleaseListHOCmd  *p_value_ie6 = NGAP_P_NULL;

            OSRTDList pdu_session_res_to_rel_list;

            rtxDListInit(&pdu_session_res_to_rel_list );

            p_value_ie6  = &pdu_session_res_to_rel_list;

            if( NGAP_FAILURE ==
                    ngap_encode_pdu_session_res_to_rel_ho_list(
                        &asn1_ctx,
                        p_value_ie6,
                        &p_ngap_local_ho_command->pdu_session_res_to_rel_list_ho_cmd ))
            {
               RRC_NGAP_TRACE(NGAP_ERROR,
               " Encode of IEs 6 - PDU session resource to release handover list failed");
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverCommand_protocolIEs_6(&asn1_ctx,
                        &p_asn_ho_command->protocolIEs,p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to add IE 6 PDU session resource to release handover list");
                break;
            }
        }

        /*Encode IEs 7 - ngap Target To Source Transparent Container */
             
        ngap_TargetToSource_TransparentContainer *p_value_ie7 = NGAP_P_NULL;

        p_value_ie7 =
            rtxMemAllocTypeZ(&asn1_ctx,ngap_TargetToSource_TransparentContainer );

        if(NGAP_P_NULL == p_value_ie7)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        

        p_value_ie7->data =
            (OSOCTET *)rtxMemAllocZ(&asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_P_NULL == p_value_ie7->data )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        if (NGAP_FAILURE == ngap_encode_trg_to_src_ngran_transparent_container(
                             p_value_ie7,
                             &p_ngap_local_ho_command->trg_to_src_transparent_container))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to encode Target to Source Transparent Container");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCommand_protocolIEs_7( &asn1_ctx,
                    &p_asn_ho_command->protocolIEs , p_value_ie7 ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to Add IE7- Target to sOURCE TRANSPARENT CONTAINER");
            break;
        }

        /* Encode IE 8 - critically_dignostic*/

        if(HANDOVER_COMMAND_CRITICALITY_DIGNOSTICS &
                p_ngap_local_ho_command->bitmask )
        {
            ngap_CriticalityDiagnostics  *p_value_ie8 = NGAP_P_NULL;

            p_value_ie8 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie8)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie8,
                        &p_ngap_local_ho_command->critically_dignostic))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE8 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverCommand_protocolIEs_8(&asn1_ctx,
                        &p_asn_ho_command->protocolIEs, p_value_ie8))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE8 - Criticality Diagnostics");
                break;

            }
        }
    
        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Command");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Command Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/*Handover_changes_start*/
ngap_return_et ngap_encode_trg_to_src_ngran_transparent_container
(
    ngap_TargetToSource_TransparentContainer               *p_value,
    ngap_trg_ngran_to_src_ngran_transparent_container_t    *p_local
)
{
    ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer
                            *p_trg_to_src_ngran_container = NGAP_P_NULL;

    OSCTXT                              asn1_ctx1;
    ngap_return_et                      response = NGAP_SUCCESS;
    UInt8                               encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_trg_to_src_ngran_container =
            rtxMemAllocTypeZ(&asn1_ctx1 , 
                    ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer);
        if (NGAP_P_NULL == p_trg_to_src_ngran_container )
        {
            NGAP_SYSTEM_MEM_FAIL(); 
            response = NGAP_FAILURE;
            break;
        }

        /*Encode RRC_Container */

        p_trg_to_src_ngran_container->rRCContainer.numocts =
            p_local->rrc_container.num_string_len;

        p_trg_to_src_ngran_container->rRCContainer.data =
            (OSOCTET *)rtxMemAllocZ(&asn1_ctx1,
                    p_trg_to_src_ngran_container->rRCContainer.numocts);

        if (NGAP_P_NULL == p_trg_to_src_ngran_container->rRCContainer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMCPY
            ((void *)p_trg_to_src_ngran_container->rRCContainer.data,
             p_local->rrc_container.string_data,
             p_trg_to_src_ngran_container->rRCContainer.numocts
            );
        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1,
                    (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Command Transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer 
                (&asn1_ctx1, 
                 p_trg_to_src_ngran_container))
        {
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of TargetNGRANNode_ToSourceNGRANNode_TransparentContainer Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer(
                    &asn1_ctx1, 
                    "TargetNGRANNode_ToSourceNGRANNode_TransparentContainer",
                    p_trg_to_src_ngran_container);

            encoded_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }
    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
/*Handover_changes_end*/
/******************************************************************************
 * Function Name    : ngap_encode_ie_selected_tai 
 * Inputs           : 
 * Outputs          : 
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes EPS Tracking area used in Target id 
 *                    provided in HO Required.
 *****************************************************************************/
ngap_return_et  ngap_encode_ie_selected_tai
(
     OSCTXT                      *p_asn1_ctx,
     ngap_TAI                    *p_asn_ngap_tai,/*ASN Buffer */
     ngap_tai_t                  *p_local_ngap_tai/*Local Buffer */
)
{
    ngap_return_et              response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    p_asn_ngap_tai->pLMNIdentity.numocts = NGAP_PLMN_IDENTITY_MAX_BYTES;

    NGAP_MEMCPY(
            p_asn_ngap_tai->pLMNIdentity.data,
            p_local_ngap_tai->plmn_identity.plmn_id_bytes,
            NGAP_PLMN_IDENTITY_MAX_BYTES);

    p_asn_ngap_tai->tAC.numocts = NGAP_TAC_OCTET_SIZE;
    NGAP_MEMCPY(
            p_asn_ngap_tai->tAC.data,
            p_local_ngap_tai->tac.tac,
            NGAP_TAC_OCTET_SIZE);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;

}

/******************************************************************************
 * Function Name    : ngap_encode_target_id 
 * Inputs           : 
 * Outputs          : 
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes Target ID provided in HO Required.
 *****************************************************************************/
ngap_return_et  ngap_encode_target_id
(
    OSCTXT                          *p_asn1_ctx,
    ngap_TargetID                   *p_asn_target_id,/*ASN buffer */
    ngap_target_id_t                *p_local_target_id/*NGAP local buffer */

)
{
        ngap_return_et              response = NGAP_SUCCESS;//HandOver changes
        RRC_NGAP_UT_TRACE_ENTER();

        switch(p_local_target_id->choice_type)
        {
            case T_ngap_TargetID_targetRANNodeID:
            {
                /* Encode IE -Target RAN Node ID */
                p_asn_target_id->t = T_ngap_TargetID_targetRANNodeID;

                p_asn_target_id->u.targetRANNodeID =
                        rtxMemAllocTypeZ(p_asn1_ctx,ngap_TargetRANNodeID);

                if(NGAP_P_NULL == p_asn_target_id->u.targetRANNodeID)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

        NGAP_MEMSET(p_asn_target_id->u.targetRANNodeID,
                NGAP_ZERO, sizeof(ngap_TargetRANNodeID));/*Handover bug fixes */

                /*Set Extension Bits as False */

                p_asn_target_id->u.targetRANNodeID->m.iE_ExtensionsPresent = NGAP_FALSE;

                /*Encode Global Ran Node Id */

                if(NGAP_FAILURE ==  ngap_encode_ie_global_ran_node_id(p_asn1_ctx,
                            &p_asn_target_id->u.targetRANNodeID->globalRANNodeID,
                            &p_local_target_id->target_ran_node_id.global_ran_node_id))
                {
                   RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE-Global RAN Node ID Failed");
                    response = NGAP_FAILURE;
                    break;

                }

                /* Encode Selected Tai */

                if(NGAP_FAILURE == ngap_encode_ie_selected_tai(
                            p_asn1_ctx,
                            &p_asn_target_id->u.targetRANNodeID->selectedTAI,
                            &p_local_target_id->target_ran_node_id.selected_tai))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE-Selected Tai Failed");
                    response = NGAP_FAILURE;
                    break;
                }


                break;
            }
            case T_ngap_TargetID_targeteNB_ID:
            {
            RRC_NGAP_TRACE(NGAP_ERROR, "T_ngap_TargetID_targeteNB_ID currently not supported");
            response = NGAP_FAILURE;
            break;
        }
        default:
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Invalid TargetID Type[%d]", p_local_target_id->choice_type);
            response = NGAP_FAILURE;
                break;
            }
        }
        RRC_NGAP_UT_TRACE_EXIT();
        return response;
}

ngap_return_et ngap_encode_pdu_session_res_list_ho_required_transfer
(
 OSDynOctStr                            *p_value,
 ho_required_transfer_t                 *p_local 
)
{
    ngap_HandoverRequiredTransfer       *p_pdu_session_ho_rqd_transfer;
    OSCTXT                              asn1_ctx1;
    ngap_return_et                      response = NGAP_SUCCESS;
    UInt8                               encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_pdu_session_ho_rqd_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_HandoverRequiredTransfer);

        if(NGAP_P_NULL == p_pdu_session_ho_rqd_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE directForwardingPathAvailability*/
        if(HO_RQD_TRANSFER_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT & p_local->bitmask)
        {
            p_pdu_session_ho_rqd_transfer->m.directForwardingPathAvailabilityPresent = 
                NGAP_TRUE;

            p_pdu_session_ho_rqd_transfer->directForwardingPathAvailability = 
                p_local->direct_fwding_path_avail;
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Required Transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_HandoverRequiredTransfer (&asn1_ctx1, 
                    p_pdu_session_ho_rqd_transfer))
        {
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Request Transfer Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverRequiredTransfer(
                    &asn1_ctx1, 
                    "PDU_SESSION_HO_RQD_TRANSFER",
                    p_pdu_session_ho_rqd_transfer);

            encoded_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}


/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_res_list_ho_required 
 * Inputs           : 
 * Outputs          : 
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes PDU SEssion list in HO Required.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_res_list_ho_required
(
 OSCTXT                                     *p_asn1_ctx,
 ngap_PDUSessionResourceListHORqd           *p_asn_list,
 ngap_pdu_session_res_list_HO_rqd_t         *p_local_list
 )
{
    ngap_PDUSessionResourceItemHORqd    *p_ngap_pdu_session_res_ho_required_item = NGAP_P_NULL;
    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
 
    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx, 
                ngap_PDUSessionResourceItemHORqd,
                &p_node,
                &p_ngap_pdu_session_res_ho_required_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_res_ho_required_item) ||
                (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_res_ho_required_item,
                NGAP_ZERO, sizeof(ngap_PDUSessionResourceItemHORqd));

        /*Encode IE 1 - ngap_PDUSessionID*/
        p_ngap_pdu_session_res_ho_required_item->pDUSessionID = 
            p_local_list->pdu_session_res_list_HO_rqd_item[index].\
            pdu_session_id.pdu_session_id;

        /*Encode IE 2 - handoverRequiredTransfer*/
        p_ngap_pdu_session_res_ho_required_item->handoverRequiredTransfer.data =
            rtxMemAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_FAILURE ==
                p_ngap_pdu_session_res_ho_required_item->handoverRequiredTransfer.data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        response = 
            ngap_encode_pdu_session_res_list_ho_required_transfer(
                    &p_ngap_pdu_session_res_ho_required_item->\
                    handoverRequiredTransfer,
                    &p_local_list->pdu_session_res_list_HO_rqd_item[index].\
                    handover_rqd_transfer);

        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_node);
    }
    
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_handover_required 
 * Inputs           : p_local_ngap_handover_required - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Required ASN message from the
 *				      information provided in p_local_ngap_handover_required
 *				      This messgae is from S-NG-RAN to AMF
 *****************************************************************************/
ngap_return_et ngap_encode_handover_required
(
 ngap_handover_required_t   *p_local_ngap_handover_required,
 UInt8                      *p_asn_msg,   /* Output - ASN Encoded Buffer */
 UInt16                     *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
 )
{
    ngap_NGAP_PDU           ngap_pdu;
    OSCTXT                  asn1_ctx;
    ngap_HandoverRequired   *p_asn_ho_required = NGAP_P_NULL;
    ngap_return_et          response           = NGAP_FAILURE;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;
        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the successsfull outcome type to Handover Required */
        p_asn_ho_required = rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverRequired);

        if(NGAP_P_NULL == p_asn_ho_required)
       {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_handoverPreparation(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_ho_required );


        /* Encode 8 IEs of HAndover Required*/

        /* Encode IE 1 - AMF_UE_NGAP_ID */
        ngap_AMF_UE_NGAP_ID      value_ie1 =  NGAP_ZERO;

        value_ie1 = p_local_ngap_handover_required->amf_ue_ngap_id;

        if(NGAP_ASN_OK != 
                asn1Append_ngap_HandoverRequired_protocolIEs_1(
                    &asn1_ctx,
                    &p_asn_ho_required->protocolIEs, 
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */
        ngap_RAN_UE_NGAP_ID    value_ie2 = NGAP_ZERO;

        value_ie2 = p_local_ngap_handover_required->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverRequired_protocolIEs_2(
                    &asn1_ctx,
                    &p_asn_ho_required->protocolIEs, 
                    value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /* Encode IE 3 - Handover type */
        ngap_HandoverType   value_ie3 = NGAP_ZERO;

        value_ie3 = p_local_ngap_handover_required->handover_type;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverRequired_protocolIEs_3(
                    &asn1_ctx,
                    &p_asn_ho_required->protocolIEs, 
                    value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /* Encode IE 4 - Choice cause group*/
        ngap_Cause *p_value_ie4 = NGAP_P_NULL;
        
        p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie4)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie4,
                    &p_local_ngap_handover_required->id_cause))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE-Cause Failed");//HandOver changes
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequired_protocolIEs_4(&asn1_ctx,
                    &p_asn_ho_required->protocolIEs, p_value_ie4))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE4 - Cause");
            break;
        }

        /*Encode IE 5 -Target id  */
        ngap_TargetID *p_value_ie5 = NGAP_P_NULL;

        p_value_ie5 = rtxMemAllocTypeZ(&asn1_ctx, ngap_TargetID);

        if(NGAP_P_NULL == p_value_ie5)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_target_id(
                    &asn1_ctx,
                    p_value_ie5,
                    &p_local_ngap_handover_required->target_id))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE Target ID Failed");//HandOver changes
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequired_protocolIEs_5(&asn1_ctx,
                    &p_asn_ho_required->protocolIEs, p_value_ie5))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE5 - Target id");
            break;
        }

        /* Encode IE 6 - (O)ngap_DirectForwardingPathAvailability*/
        if(HO_REQUIRED_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT &
                p_local_ngap_handover_required->bitmask)
        {
            ngap_DirectForwardingPathAvailability value_ie6 = NGAP_ZERO;
            value_ie6 = (ngap_DirectForwardingPathAvailability)
                p_local_ngap_handover_required->direct_forwarding_path_availability;
    
            if(NGAP_ASN_OK != 
                    asn1Append_ngap_HandoverRequired_protocolIEs_6(&asn1_ctx,
                        &p_asn_ho_required->protocolIEs, value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE6 - ngap_DirectForwardingPathAvailability");
                break;
            }
        }

        /*Encode IE 7- ngap_PDUSessionResourceListHORqd*/ 
        ngap_PDUSessionResourceListHORqd    *p_value_ie7 = NGAP_P_NULL;
        OSRTDList                           ngap_HandoverRequiredIEs_7;

        rtxDListInit(&ngap_HandoverRequiredIEs_7);
        p_value_ie7 = &ngap_HandoverRequiredIEs_7;

        if(NGAP_FAILURE == ngap_encode_pdu_session_res_list_ho_required(
                    &asn1_ctx, p_value_ie7,
                    &p_local_ngap_handover_required->pdu_session_res_list_HO_rqd_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to encode PDU Session Resource List HO Reqiuired");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequired_protocolIEs_7(&asn1_ctx,
                    &p_asn_ho_required->protocolIEs, p_value_ie7))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE7 -  PDU SESSION RESOURCE HO LIST");
            break;
        }

        /*Encode IE 8- ngap_SourceToTarget_TransparentContainer*/
        ngap_SourceToTarget_TransparentContainer *p_value_ie8 = NGAP_P_NULL;
        p_value_ie8 = rtxMemAllocTypeZ(&asn1_ctx, ngap_SourceToTarget_TransparentContainer);

        if(NGAP_P_NULL == p_value_ie8)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        } 

       
        /*allocate memory*/
        p_value_ie8->data =
                (OSOCTET *)rtxMemAllocZ(&asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if(NGAP_FAILURE == p_value_ie8->data)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

       /*Handover_changes_start*/ 
        if(NGAP_FAILURE == ngap_encode_src_to_trg_transparent_container(
                    p_value_ie8,
                    &p_local_ngap_handover_required->src_to_trg_transparent_container))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to encode Source to Target Transparent Container");
            response = NGAP_FAILURE;
            break;
        }
        /*Handover_changes_end*/

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequired_protocolIEs_8( &asn1_ctx,
                    &p_asn_ho_required->protocolIEs, p_value_ie8))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE8 -  ngap_SourceToTarget_TransparentContainer");
            break;
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Required");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Request Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/*Handover_changes_start*/
ngap_return_et ngap_encode_src_to_trg_transparent_container
(
    ngap_SourceToTarget_TransparentContainer   *p_value,
    ngap_src_to_target_transparent_container_t *p_local
)
{
    ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
        *p_src_to_trg_container = NGAP_NULL;

    OSCTXT                              asn1_ctx1;
    ngap_return_et                      response = NGAP_SUCCESS;
    UInt32                              encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }
    do
    {
        p_src_to_trg_container  =
            rtxMemAllocTypeZ(&asn1_ctx1 ,
                    ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer);

        if(NGAP_P_NULL == p_src_to_trg_container )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        /*Encode_IE_RRCcontainer */
            p_src_to_trg_container->rRCContainer.numocts =
                p_local->src_to_trg_ngran_container.rrc_container.num_string_len;

            p_src_to_trg_container->rRCContainer.data =
                (OSOCTET *)rtxMemAllocZ(&asn1_ctx1, p_src_to_trg_container->rRCContainer.numocts);

            if(NGAP_P_NULL == p_src_to_trg_container->rRCContainer.data )
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }
            NGAP_MEMCPY
                ((void *)p_src_to_trg_container->rRCContainer.data,
                 p_local->src_to_trg_ngran_container.rrc_container.string_data,
                 p_src_to_trg_container->rRCContainer.numocts
                );

        /*Encode_IE_pDUSessionResourceInformationList*/
        if(NGAP_PDU_SESSION_RESOURCE_INFORAMTION_LIST &
                p_local->src_to_trg_ngran_container.bitmask )
        {
            if(NGAP_FAILURE == ngap_encode_pdu_session_resource_info_list(
                        &asn1_ctx1,
                        &p_src_to_trg_container->pDUSessionResourceInformationList,
                        &p_local->src_to_trg_ngran_container.pdu_session_resource_info_list
                        ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding Failed for IE - PDU SESSION RESOURCE INFORMATION LIST");
                response = NGAP_FAILURE;
                return response;
            }

            p_src_to_trg_container->m.pDUSessionResourceInformationListPresent = NGAP_TRUE;

        }
        /*Encode_IE_e_RABInformationList*/

        if(NGAP_E_RAB_INFORMATION_LIST &
                p_local->src_to_trg_ngran_container.bitmask )
        {
            p_src_to_trg_container->m.e_RABInformationListPresent = NGAP_TRUE;
            /*NOT Required in 5g_to_5g handover*/

        }
        /*Encode_IE_targetCell_ID*/

        if(NGAP_FAILURE == ngap_encode_ng_ran_cgi(
                    &asn1_ctx1,
                    &p_src_to_trg_container->targetCell_ID,
                    &p_local->src_to_trg_ngran_container.target_cell_id
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Could not encode NG RAN CGI");
            response = NGAP_FAILURE;
            break;

        }
        /*Encode_IE_indexToRFSP*/

        if(NGAP_INDEX_TO_RFSP &
                p_local->src_to_trg_ngran_container.bitmask )
        {
            p_src_to_trg_container->m.indexToRFSPPresent = NGAP_TRUE;

            p_src_to_trg_container->indexToRFSP =
                p_local->src_to_trg_ngran_container.index_to_rfsp;

        }
        /*Encode_IE_uEHistoryInformation*/

        if(NGAP_FAILURE == ngap_encode_ue_history_information(
                    &asn1_ctx1,
                    &p_src_to_trg_container->uEHistoryInformation,
                    &p_local->src_to_trg_ngran_container.ue_history_information
                    ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding Failed for IE - UE History Information");
            response = NGAP_FAILURE;
            return response;
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Required Transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
                (&asn1_ctx1, 
                 p_src_to_trg_container))
        {
            rtxErrPrint(&asn1_ctx1);
            
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of SourceNGRANNode_ToTargetNGRANNode_TransparentContainer Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer(NGAP_ASN,
                    (SInt8 *)"Source To Target NGRAN Container",
                    p_src_to_trg_container);

            encoded_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
ngap_return_et  ngap_encode_ue_history_information
(
    OSCTXT                                *p_asn1_ctx,
    ngap_UEHistoryInformation             *p_asn_value,
    ngap_ue_history_information_list_t    *p_local_value
)
{
    ngap_LastVisitedCellItem        *p_ngap_ue_history_item = NGAP_P_NULL;
    OSRTDListNode                   *p_node     = NGAP_P_NULL;
    ngap_return_et                  response    = NGAP_SUCCESS;
    UInt16                          count       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_local_value);

    if(NGAP_ZERO == p_local_value->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }
    for(count = NGAP_ZERO; count < p_local_value->count; count++)
    {

        rtxDListAllocNodeAndData(p_asn1_ctx, 
                ngap_LastVisitedCellItem,
                &p_node,
                &p_ngap_ue_history_item);

        if((NGAP_P_NULL == p_ngap_ue_history_item) ||
                (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_ue_history_item,
                NGAP_ZERO, sizeof(ngap_LastVisitedCellItem));
        /*Encode UE HISTORY INFORMATION ITEM */

        if ( p_local_value->ue_history_information_item[count].\
                last_visited_cell_information.choice_type ==
                ngap_LastVisitedCellInformation_nGRANCell )
        {
            RRC_NGAP_TRACE(NGAP_DETAILED,
                    "Encode nGRANCell in Ue History Info");

            p_ngap_ue_history_item->lastVisitedCellInformation.t = 
                T_ngap_LastVisitedCellInformation_nGRANCell;

            /*Encode Last Visited NGRAN Cell Information */

            /*AllocateMemory to ngap_LastVisitedNGRANCellInformation */
            p_ngap_ue_history_item->lastVisitedCellInformation.u.nGRANCell =
                rtxMemAllocTypeZ( p_asn1_ctx,
                        ngap_LastVisitedNGRANCellInformation);

            if (NGAP_P_NULL ==
                    p_ngap_ue_history_item->lastVisitedCellInformation.u.nGRANCell)
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to allocate memory to nGRANCell");   
                break;
            }
            /*Encode Global Cell Id */
            if(NGAP_FAILURE ==
                    ngap_encode_ng_ran_cgi
                    (p_asn1_ctx,
                     &p_ngap_ue_history_item->lastVisitedCellInformation.\
                     u.nGRANCell->globalCellID,
                     &p_local_value->ue_history_information_item[count].\
                     last_visited_cell_information.ng_ran_cell.global_cell_id
                    ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Encode Globel Cell Id ");
                response = NGAP_FAILURE;
                break;
            }
            /*Encode Cell Type */
            p_ngap_ue_history_item->lastVisitedCellInformation.\
                u.nGRANCell->cellType.cellSize =
                p_local_value->ue_history_information_item[count].\
                last_visited_cell_information.ng_ran_cell.cell_type;

            /*Encode IE Time uE Stayed In cell */

            p_ngap_ue_history_item->lastVisitedCellInformation.\
                u.nGRANCell->timeUEStayedInCell =
                p_local_value->ue_history_information_item[count].\
                last_visited_cell_information.ng_ran_cell.time_ue_stayed_in_cell;

            /*Encode IE timeUEStayedInCellEnhancedGranularity */
            if (TIME_UE_STAYED_IN_CELL_ENCHANCED_GRANULARITY &
                    p_local_value->ue_history_information_item[count].\
                    last_visited_cell_information.ng_ran_cell.bitmask)
            {
                p_ngap_ue_history_item->lastVisitedCellInformation.\
                    u.nGRANCell->m.timeUEStayedInCellEnhancedGranularityPresent = NGAP_TRUE;

                p_ngap_ue_history_item->lastVisitedCellInformation.\
                    u.nGRANCell->timeUEStayedInCellEnhancedGranularity  =
                    p_local_value->ue_history_information_item[count].\
                    last_visited_cell_information.ng_ran_cell.\
                    time_ue_stayed_in_cell_enchanced_granularity;

            }

            /*Encode IE HANDOVER Cause Value*/
            if (HO_CAUSE_VALUE &
                    p_local_value->ue_history_information_item[count].\
                    last_visited_cell_information.ng_ran_cell.bitmask)
            {
                p_ngap_ue_history_item->lastVisitedCellInformation.\
                    u.nGRANCell->m.hOCauseValuePresent = NGAP_TRUE;

                if (NGAP_FAILURE ==  ngap_encode_ie_cause(p_asn1_ctx,
                            &p_ngap_ue_history_item->lastVisitedCellInformation.\
                            u.nGRANCell->hOCauseValue,
                            &p_local_value->ue_history_information_item[count].\
                            last_visited_cell_information.ng_ran_cell.\
                            handover_cause_value))
                {
                    RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Cause Failed");
                    response = NGAP_FAILURE;
                    break;
                }
            }
        } /*UE History Information NGRan*/
        rtxDListAppendNode(p_asn_value, p_node);
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et ngap_encode_pdu_session_resource_info_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_PDUSessionResourceInformationList  *p_asn_list,
    ngap_pdu_session_resource_info_list_t   *p_local_list
)
{
    ngap_PDUSessionResourceInformationItem 
        *p_ngap_pdu_session_resource_info_item      = NGAP_P_NULL;

    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {

        rtxDListAllocNodeAndData(p_asn1_ctx, 
                ngap_PDUSessionResourceInformationItem,
                &p_node,
                &p_ngap_pdu_session_resource_info_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_resource_info_item) ||
                (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_resource_info_item,
                NGAP_ZERO, sizeof(ngap_PDUSessionResourceInformationItem));

        /*Encode IE 1 - ngap_PDUSessionID*/
        p_ngap_pdu_session_resource_info_item->pDUSessionID =
            p_local_list->pdu_session_resource_info_item[index].pdu_session_id.pdu_session_id;

        /*Encode IE 2 - qos_flow_info_list*/

        if(NGAP_FAILURE == ngap_encode_qos_flow_info_list(
                    p_asn1_ctx, 
                    &p_ngap_pdu_session_resource_info_item->\
                    qosFlowInformationList,
                    &p_local_list->pdu_session_resource_info_item[index].\
                    qos_flow_info_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Encode PDU Session Resource Info List");
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE 3 - dRBs To Qos Flows Mapping List */
        if(NGAP_DRB_TO_QOS_FLOW_MAPPING_LIST & 
                p_local_list->pdu_session_resource_info_item[index].bitmask)
        {
            p_ngap_pdu_session_resource_info_item->\
                m.dRBsToQosFlowsMappingListPresent = NGAP_TRUE;
            if (NGAP_FAILURE ==
                    ngap_encode_drb_to_qos_flow_mapping_list(
                        p_asn1_ctx,
                        &p_ngap_pdu_session_resource_info_item->\
                        dRBsToQosFlowsMappingList,
                        &p_local_list->pdu_session_resource_info_item[index].\
                        drb_to_qos_flow_mapping_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Encode dRBs To Qos Flows Mapping List");
                response = NGAP_FAILURE;
                break;
            }
        }
        rtxDListAppendNode(p_asn_list, p_node);                                                 
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et ngap_encode_drb_to_qos_flow_mapping_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_DRBsToQosFlowsMappingList          *p_asn_list,
    ngap_drb_to_qos_flow_mapping_list_t     *p_local_list
)
{
    ngap_DRBsToQosFlowsMappingItem  *p_drb_to_qos_flow_mapping_item = NGAP_P_NULL;
    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }
    for (index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_DRBsToQosFlowsMappingItem,
                &p_node,
                &p_drb_to_qos_flow_mapping_item);

        if((NGAP_P_NULL == p_drb_to_qos_flow_mapping_item )||(NGAP_P_NULL == p_node ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET(p_drb_to_qos_flow_mapping_item ,NGAP_ZERO,
                sizeof(ngap_DRBsToQosFlowsMappingItem));

        /*Encode IE drb_id */

        p_drb_to_qos_flow_mapping_item->dRB_ID =
            p_local_list->drb_to_qos_flow_mapping_item[index].drb_id;

        /*Encode IE associated_qos_flow_list*/
        if (NGAP_FAILURE ==ngap_encode_ie_additional_qos_flow_response_setup_list
                (p_asn1_ctx,
                 &p_drb_to_qos_flow_mapping_item->\
                 associatedQosFlowList,
                 &p_local_list->drb_to_qos_flow_mapping_item[index].\
                 associated_qos_flow_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed To Encode Qos Flow List ");
            response = NGAP_FAILURE;
            return response;
        }
        rtxDListAppendNode(p_asn_list , p_node);
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et ngap_encode_qos_flow_info_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_QosFlowInformationList         *p_asn_list,
    ngap_qos_flow_information_list_t    *p_local_list
)
{
    ngap_QosFlowInformationItem         *p_qos_flow_info_item = NGAP_P_NULL;
    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }
    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowInformationItem,
                &p_node,
                &p_qos_flow_info_item);

        if((NGAP_P_NULL == p_qos_flow_info_item) ||
                (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_qos_flow_info_item,
                NGAP_ZERO, sizeof(ngap_QosFlowInformationItem));

        /*Encode IE qos_flow_identifier*/

        p_qos_flow_info_item->qosFlowIdentifier =
            p_local_list->qos_flow_information_item[index].qos_flow_identifier;

        /*Encode IE dl_forwarding */
        if(NGAP_DL_FORWARDING &
                p_local_list->qos_flow_information_item[index].bitmask )
        {
            p_qos_flow_info_item->m.dLForwardingPresent = NGAP_TRUE;
            p_qos_flow_info_item->dLForwarding =
                p_local_list->qos_flow_information_item[index].dl_forwarding;
        }

        rtxDListAppendNode(p_asn_list , p_node);
    }
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}
/*Handover_changes_end*/
/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_admitted_list 
 * Inputs           : 
 * Outputs          : 
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes Successful PDU Session list being 
 *                    admitted at T-NG-RAN and is sent is in HO Req Ack.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_admitted_list
(
 OSCTXT                                     *p_asn1_ctx,
 ngap_PDUSessionResourceAdmittedList        *p_asn_list,
 ngap_ho_req_ack_pdu_session_res_adm_list_t *p_local_list
)
{
    ngap_PDUSessionResourceAdmittedItem *p_ngap_pdu_session_res_admitted_item = NGAP_P_NULL;
    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
 
    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx, 
                ngap_PDUSessionResourceAdmittedItem,
                &p_node,
                &p_ngap_pdu_session_res_admitted_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_res_admitted_item) ||
            (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_res_admitted_item,
                NGAP_ZERO, sizeof(ngap_PDUSessionResourceAdmittedItem));

        /*Encode IE 1 - ngap_PDUSessionID*/
        p_ngap_pdu_session_res_admitted_item->pDUSessionID = 
            p_local_list->pdu_session_res_adm_item[index].\
            pdu_session_id.pdu_session_id;

        /*Encode IE 2 - handoverRequestAcknowledgeTransfer*/

/*HandOver_code_change_start*/
        p_ngap_pdu_session_res_admitted_item->\
            handoverRequestAcknowledgeTransfer.data =
            (OSOCTET *)rtxMemSysAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if (NGAP_P_NULL ==
            p_ngap_pdu_session_res_admitted_item->\
            handoverRequestAcknowledgeTransfer.data )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        
        if (NGAP_FAILURE == ngap_encode_handover_request_acknowledge_transfer(
                &p_ngap_pdu_session_res_admitted_item->\
                handoverRequestAcknowledgeTransfer,
                &p_local_list->pdu_session_res_adm_item[index].\
                ho_request_ack_transfer))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Encoding of HandoverRequestAcknowledgeTransfer Failed");
            response = NGAP_FAILURE;
            break;

        }
/*HandOver_code_change_end */
        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_node);
    }
    
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*HandOver_code_changes_start*/


/******************************************************************************************
 *              ngap_encode_handover_request_acknowledge_transfer
 * ****************************************************************************************/
ngap_return_et ngap_encode_handover_request_acknowledge_transfer
(
    OSDynOctStr                              *p_value,
    ngap_ho_request_acknowledge_transfer_t   *p_local
)
{
    ngap_HandoverRequestAcknowledgeTransfer *p_ho_request_ack_transfer = NGAP_P_NULL;

    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_ho_request_ack_transfer = 
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_HandoverRequestAcknowledgeTransfer);

        if(NGAP_P_NULL == p_ho_request_ack_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE dl_ngu_up_tnl_information */

        if( NGAP_FAILURE == 
                ngap_encode_up_transport_layer_info(
                    &p_ho_request_ack_transfer->dL_NGU_UP_TNLInformation,
                    &p_local->dl_ngu_up_tnl_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to encode dL_NGU_UP_TNLInformation");
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE dl_forwarding_up_tnl_information*/

        if(HO_REQ_ACK_DL_FORWARDING_UP_TNL_INFORMATION_PRESENT  &
                p_local->bitmask)
        {
            p_ho_request_ack_transfer->m.dLForwardingUP_TNLInformationPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_up_transport_layer_info(
                        &p_ho_request_ack_transfer->dLForwardingUP_TNLInformation,
                        &p_local->dl_forwarding_up_tnl_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode dLForwardingUP_TNLInformation");
                response = NGAP_FAILURE;
                break;
            }
        }
        /*Encode IE security_result */

        if(p_local->bitmask &
                HO_REQ_ACK_SECURITY_RESULT_PRESENT)
        {
            p_ho_request_ack_transfer->m.securityResultPresent = RRC_TRUE;

            p_ho_request_ack_transfer->securityResult.integrityProtectionResult =
                p_local->security_result.integrity_protection_result;

            p_ho_request_ack_transfer->securityResult.confidentialityProtectionResult =
                p_local->security_result.confidentiality_protection_result;

        }

        /*Encode IE qos_flow_setup_response_list */

        if( NGAP_FAILURE == 
                ngap_encode_qos_flow_setup_response_list(
                    &asn1_ctx1,
                    &p_ho_request_ack_transfer->qosFlowSetupResponseList,
                    &p_local->qos_flow_setup_response_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to encode qos_flow_setup_response_list");
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE qos_flow_failed_to_setup_list */

        if(p_local->bitmask &
                HO_REQ_ACK_QOS_FLOW_FAILED_TO_SETUP_LIST_PRESENT)
        {
            p_ho_request_ack_transfer->m.qosFlowFailedToSetupListPresent = RRC_TRUE;

            if(NGAP_FAILURE == ngap_encode_qos_flow_failed_setup_list(
                        &asn1_ctx1,
                        &p_ho_request_ack_transfer->qosFlowFailedToSetupList,
                        &p_local->qos_flow_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of  QOS FLOW FAILED TO SET UP List failed");
                response = NGAP_FAILURE;
                break;
            }
        }
        /*Encode IE data_forwarding_response_drb_list */

        if(HO_REQ_ACK_DATA_FORWARDING_RESPONSE_DRB_LIST_PRESENT &
                p_local->bitmask)
        {
            p_ho_request_ack_transfer->m.dataForwardingResponseDRBListPresent = 
                NGAP_TRUE;

            if( NGAP_FAILURE == 
                    ngap_encode_data_fwding_resp_drb_list(
                        &asn1_ctx1,
                        &p_ho_request_ack_transfer->dataForwardingResponseDRBList,
                        &p_local->data_forwarding_response_drb_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to encode dataForwardingResponseDRBList");
                response = NGAP_FAILURE;
                break;
            }
        }
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK !=
                pu_setBuffer(&asn1_ctx1, (OSUINT8 *)p_value->data,
                    NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE)) 
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed pu_setBuffer for Handover Request Ackowledge transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK !=
                asn1PE_ngap_HandoverRequestAcknowledgeTransfer(&asn1_ctx1,
                    p_ho_request_ack_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of Handover Request Acknowledge transfer Failed"); 
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */

            ngap_asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer(NGAP_ASN, 
                    (SInt8 *)"Handover Request Acknowledge Transfer", 
                    p_ho_request_ack_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }
    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*****************************************************************************************
 *                  ngap_encode_additional_dl_up_tnl_info_for_ho_list
 * ***************************************************************************************/

ngap_return_et  ngap_encode_additional_dl_up_tnl_info_for_ho_list
(
    OSCTXT                                                   *p_asn1_ctx,
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions    *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t             *p_local
)
{
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions_element
        *p_asn_item = NGAP_P_NULL;

    OSRTDListNode           *p_asn_item_node = NGAP_P_NULL;
    ngap_return_et          response = NGAP_SUCCESS;
    UInt16                  count    = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    rtxDListInit(p_value);

    for (count = NGAP_ZERO; count < 1; count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions_element,
                &p_asn_item_node,
                &p_asn_item
                );

        if((NGAP_P_NULL== p_asn_item )||
                (NGAP_P_NULL == p_asn_item_node ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            return response;
        }

        NGAP_MEMSET
            (
             p_asn_item,
             NGAP_ZERO,
             sizeof(ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions_element)
            );

        /*Encode IE _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1 */
        if (p_local->bitmask & HO_REQ_ACK_ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_ITEM)
        {
            p_asn_item->extensionValue.t = 
                T159ngap___ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1;


            p_asn_item->extensionValue.u.\
                _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1 =
                rtxMemAllocTypeZ(p_asn1_ctx,ngap_AdditionalDLUPTNLInformationForHOList);

            if(NGAP_P_NULL ==
                    p_asn_item->extensionValue.u.\
                    _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                return response;
            }
            /*Encode IE ngap_AdditionalDLUPTNLInformationForHOList */

            if(NGAP_FAILURE == ngap_encode_additional_dl_up_tnl_info
                    (   p_asn1_ctx,
                        p_asn_item->\
                        extensionValue.u.\
                        _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_1,
                        p_local
                    ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "ngap_AdditionalDLUPTNLInformationForHOList");
                response = NGAP_FAILURE;
                return response;
            }
        }

        /*Encode IE up_transport_layer_information */

        if (p_local->bitmask & HO_REQ_ACK_TRANSFER_UP_TRANSPORT_LAYER_INFORMATION)
        {
            p_asn_item->extensionValue.t = 
               T159ngap___ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_2;


            p_asn_item->extensionValue.u.\
                _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_2 =
                rtxMemAllocTypeZ(p_asn1_ctx,ngap_UPTransportLayerInformation);

            if(NGAP_P_NULL ==
                    p_asn_item->extensionValue.u.\
                    _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_2)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                return response;
            }

            if(NGAP_FAILURE == ngap_encode_up_transport_layer_info 
                    (   p_asn_item->\
                        extensionValue.u.\
                        _ngap_HandoverRequestAcknowledgeTransfer_ExtIEs_2,
                        &p_local->up_transport_layer_information
                    ))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "up_transport_layer_information");
                response = NGAP_FAILURE;
                return response;
            }
        }
        rtxDListAppendNode(p_value ,p_asn_item_node );
    }//end for
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

ngap_return_et  ngap_encode_additional_dl_up_tnl_info
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_AdditionalDLUPTNLInformationForHOList      *p_asn_additional_dl_up_tnl_info,
    ngap_additional_dl_up_tnl_info_for_ho_list_t    *p_local
)
{
    ngap_AdditionalDLUPTNLInformationForHOItem       *p_asn_item = NGAP_P_NULL;
    OSRTDListNode                                    *p_asn_node = NGAP_P_NULL;

    ngap_return_et                    response = NGAP_SUCCESS;
    UInt16                            count  = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    if (NGAP_ZERO == p_local->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No Item in list");
        response = NGAP_FAILURE;
    }

    for(count = NGAP_ZERO; count < p_local->count ; count++ )
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AdditionalDLUPTNLInformationForHOItem,
                &p_asn_node,
                &p_asn_item);

        if ((NGAP_P_NULL == p_asn_node )||
                (NGAP_P_NULL== p_asn_item ))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }
        NGAP_MEMSET(p_asn_item, NGAP_ZERO,
                sizeof(ngap_AdditionalDLUPTNLInformationForHOItem));

        /*Encode IE additionalDL_NGU_UP_TNLInformation */


        if(NGAP_FAILURE == ngap_encode_up_transport_layer_info(
                    &p_asn_item->additionalDL_NGU_UP_TNLInformation,
                    &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                    up_transport_layer_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding Failed for additionalDL_NGU_UP_TNLInformation");
            response = NGAP_FAILURE;
            break;
        }
        /*Encode IE additionalQosFlowSetupResponseList */

        if(NGAP_FAILURE == ngap_encode_qos_flow_setup_response_list
                (p_asn1_ctx,
                 &p_asn_item->additionalQosFlowSetupResponseList,
                 &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                 qos_flow_list_with_data_forwarding))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding Failed for additionalQosFlowSetupResponseList");
            response = NGAP_FAILURE;
            break;
        }


        /*Encode IE additionalDLForwardingUPTNLInformation */

        if (ADDITIONAL_DL_FORWARDING_UP_TNL_INFORMATION &
                p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                bitmask)

        {
            p_asn_item->m.additionalDLForwardingUPTNLInformationPresent = NGAP_TRUE;

            if(NGAP_FAILURE == ngap_encode_up_transport_layer_info(
                        &p_asn_item->additionalDLForwardingUPTNLInformation,
                        &p_local->additional_dl_up_tnl_info_for_ho_list_item[count].\
                        additional_dl_forwarding_up_tnl_information))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding Failed for additionalDLForwardingUPTNLInformation");
                response = NGAP_FAILURE;
                break;
            }

        }

        rtxDListAppendNode(p_asn_additional_dl_up_tnl_info,p_asn_node);
    }
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/*****************************************************************************************
 *                   ngap_encode_qos_flow_setup_response_list
 * ***************************************************************************************/

ngap_return_et  ngap_encode_qos_flow_setup_response_list
(
    OSCTXT                                    *p_asn1_ctx,
    ngap_QosFlowListWithDataForwarding        *p_asn_list,
    ngap_qos_flow_list_with_data_forwarding   *p_local_list
)
{
    ngap_QosFlowItemWithDataForwarding *p_ngap_asn_item = NGAP_P_NULL;

    OSRTDListNode                       *p_asn_item_node = NGAP_P_NULL;
    ngap_return_et  response    =   NGAP_SUCCESS;
    UInt16			                    count   = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Atleast 1 item shall be present*/
    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR,
                "List is Null");
        response = NGAP_FAILURE;
    }

    for(count = NGAP_ZERO;
            count < p_local_list->count; 
            count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_QosFlowItemWithDataForwarding,
                &p_asn_item_node,
                &p_ngap_asn_item);

        if((NGAP_P_NULL == p_asn_item_node) ||
                (NGAP_P_NULL == p_ngap_asn_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_asn_item,
                NGAP_ZERO, sizeof(ngap_QosFlowItemWithDataForwarding));

        /*Encode IE ngap_QosFlowIdentifier */

        p_ngap_asn_item->qosFlowIdentifier  =
            p_local_list->qos_flow_item_with_data_forwading[count].\
            qos_flow_identifier.qos_flow_identifier;

        /*Encode IE dataForwardingAccepted */
        if (p_local_list->qos_flow_item_with_data_forwading[count].\
                bitmask & HO_REQ_ACK_TRANSFER_DATA_DORWARDING_ACCEPT )
        {
            p_ngap_asn_item->m.dataForwardingAcceptedPresent = NGAP_TRUE;

            p_ngap_asn_item->dataForwardingAccepted = 
                p_local_list->qos_flow_item_with_data_forwading[count].\
                data_forwading_accepted;
        }

        rtxDListAppendNode(p_asn_list, p_asn_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}




/*HandOver_code_changes_end*/

/******************************************************************************
 * Function Name    : ngap_encode_pdu_session_resource_failed_list 
 * Inputs           : 
 * Outputs          : 
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes failed PDU Session list not being 
 *                    admitted at T-NG-RAN and is sent is in HO Req Ack.
 *****************************************************************************/
ngap_return_et ngap_encode_pdu_session_resource_failed_list 
(
 OSCTXT                                         *p_asn1_ctx,
 ngap_PDUSessionResourceFailedToSetupListHOAck  *p_asn_list,
 ngap_ho_req_ack_pdu_session_res_fail_list_t    *p_local_list
)
{
    ngap_PDUSessionResourceFailedToSetupItemHOAck   *p_ngap_pdu_session_res_failed_item = NGAP_P_NULL;
    OSRTDListNode                       *p_node     = NGAP_P_NULL;
    ngap_return_et                      response    = NGAP_SUCCESS;
    UInt16                              index       = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();
 
    NGAP_ASSERT(NGAP_P_NULL != p_local_list);

    if(NGAP_ZERO == p_local_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(index = NGAP_ZERO; index < p_local_list->count; index++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx, 
                ngap_PDUSessionResourceFailedToSetupItemHOAck,
                &p_node,
                &p_ngap_pdu_session_res_failed_item);

        if((NGAP_P_NULL == p_ngap_pdu_session_res_failed_item) ||
            (NGAP_P_NULL == p_node))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_pdu_session_res_failed_item,
                NGAP_ZERO, sizeof(ngap_PDUSessionResourceFailedToSetupItemHOAck));

        /*Encode IE 1 - ngap_PDUSessionID*/
        p_ngap_pdu_session_res_failed_item->pDUSessionID = 
            p_local_list->pdu_session_res_failed_item[index].\
            pdu_session_id.pdu_session_id;

        /*Encode IE 2 - handoverResourceAllocationUnsuccessfulTransfer*/
      /*HandOver code changes */

        p_ngap_pdu_session_res_failed_item->\
            handoverResourceAllocationUnsuccessfulTransfer.data =
            (OSOCTET *)rtxMemSysAllocZ(p_asn1_ctx, NGAP_MAX_ASN1_BUF_LEN);

        if (NGAP_P_NULL ==
                p_ngap_pdu_session_res_failed_item->\
                handoverResourceAllocationUnsuccessfulTransfer.data )
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_handover_res_allocation_unsussessful_transfer(
            &p_ngap_pdu_session_res_failed_item->\
            handoverResourceAllocationUnsuccessfulTransfer,
                        &p_local_list->pdu_session_res_failed_item[index].\
                        ho_res_alloc_unsuccessful_transfer))
        {
            RRC_NGAP_TRACE
            (NGAP_ERROR,
            "Encoding of Handover Resource Allocation Unsuccessful Transfer Failed");
            response = NGAP_FAILURE;
            break;

        }

        /*HandOver_changes_end*/
        
        /* Add One TA Item to the Node */
        rtxDListAppendNode(p_asn_list, p_node);
    }
    
    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
/*HandOver_change_start*/

/******************************************************************************************
 
 *          ngap_encode_handover_res_allocation_unsussessful_transfer
 * ****************************************************************************************/
ngap_return_et ngap_encode_handover_res_allocation_unsussessful_transfer
(
    OSDynOctStr                                           *p_value,
    ngap_ho_resource_allocation_unsuccessful_transfer_t   *p_local
)
{
    ngap_HandoverResourceAllocationUnsuccessfulTransfer 
                        *p_ho_res_allocation_unsuccessful_transfer = NGAP_P_NULL;

    OSCTXT                                          asn1_ctx1;
    ngap_return_et                                  response = NGAP_SUCCESS;
    UInt8                                           encoded_asn_msg_len;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx1))
    {
        /* Silently Dropping Received ASN Mesage.
         * Not Sending Error Indication with Transfer Syntax Error
         * because ASN Init failure doesn't match the same.
         * */
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        p_ho_res_allocation_unsuccessful_transfer =
            rtxMemAllocTypeZ(&asn1_ctx1, ngap_HandoverResourceAllocationUnsuccessfulTransfer);

        if(NGAP_P_NULL == p_ho_res_allocation_unsuccessful_transfer)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Encode IE Cause */
        
        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx1,
                    &p_ho_res_allocation_unsuccessful_transfer->cause,
                    &p_local->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Cause Failed");
            response = NGAP_FAILURE;
            break;
        }
        /*Encode IE Criticality Dignostic*/
        if (HO_RESOURCE_ALLOCATION_UNSUCCESSFUL_TRANSFER_CRITICALITY_DIGNOSTICS &
             p_local->bitmask )
        {
            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx1,
                        &p_ho_res_allocation_unsuccessful_transfer->criticalityDiagnostics,
                        &p_local->criticality_dignostics))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of Criticality Diagnostics Failed");
                response = NGAP_FAILURE;
                break;
            }

            p_ho_res_allocation_unsuccessful_transfer->m.criticalityDiagnosticsPresent = NGAP_TRUE;
            /*Handover bug fixes*/

        }
        /*Set pointer of asn buffer in asn context*/
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx1,
                (OSUINT8 *)p_value->data, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for handover resource allocation unsuccessful transfer");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != 
                asn1PE_ngap_HandoverResourceAllocationUnsuccessfulTransfer(&asn1_ctx1, 
                    p_ho_res_allocation_unsuccessful_transfer))
        {
            /* Dropping Received Message */
            rtxErrPrint(&asn1_ctx1);
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of HandoverResourceAllocationUnsuccessfulTransfer Failed ");
            response = NGAP_FAILURE;

            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            asn1PrtToStrm_ngap_HandoverResourceAllocationUnsuccessfulTransfer(
                    &asn1_ctx1,
                    "HandoverResourceAllocationUnsuccessfulTransfer", 
                    p_ho_res_allocation_unsuccessful_transfer);

            /* calculate asn encoded buffer len */
            encoded_asn_msg_len = (UInt8)pe_GetMsgLen(&asn1_ctx1);

            /* update the length of the dynamic string */
            p_value->numocts = encoded_asn_msg_len;
        }
    }while(0);
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx1);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}



/*HandOver_changes_end*/
/******************************************************************************
 * Function Name    : ngap_encode_handover_req_ack
 * Inputs           : p_ngap_local_ho_req_ack - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Request Ack ASN message from the
 *				      information provided in p_ngap_local_ho_req_ack 
 *				      This messgae is successful response of HO Request and is 
 *				      send from T-NG-RAN to AMF
 *****************************************************************************/
ngap_return_et ngap_encode_ho_request_ack
(
 ngap_handover_req_ack_t    *p_ngap_local_ho_req_ack,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_HandoverRequestAcknowledge *p_asn_ho_req_ack = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;
        
        ngap_pdu.u.successfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*set successfull message type to Handover Request Ack*/
        p_asn_ho_req_ack = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverRequestAcknowledge);

        if(NGAP_P_NULL == p_asn_ho_req_ack)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_handoverResourceAllocation(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_asn_ho_req_ack);

        /*Encode all IEs of HO Req Ack*/

        /*Encode IE 1 - AMF_UE_NGAP_ID*/
        ngap_AMF_UE_NGAP_ID     value_ie1 = NGAP_ZERO;

        value_ie1 = p_ngap_local_ho_req_ack->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_1(
                    &asn1_ctx, 
                    &p_asn_ho_req_ack->protocolIEs,
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_RAN_UE_NGAP_ID */
        ngap_RAN_UE_NGAP_ID    value_ie2;/*ASN HOC  IE2 ptr */

        value_ie2 = p_ngap_local_ho_req_ack->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_2(
                    &asn1_ctx,
                    &p_asn_ho_req_ack->protocolIEs, 
                    value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE2 - ngap_RAN_UE_NGAP_ID  to NGAP PDU");
            break;
        }

        /*Encode IE 3 - PDU Session Resource Handover Admitted List*/
        ngap_PDUSessionResourceAdmittedList *p_value_ie3 = NGAP_P_NULL;

        OSRTDList ngap_pdu_session_ie3;

        rtxDListInit(&ngap_pdu_session_ie3);

        p_value_ie3 = &ngap_pdu_session_ie3;

        if(NGAP_FAILURE ==
                ngap_encode_pdu_session_resource_admitted_list(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_ngap_local_ho_req_ack->ho_req_ack_pdu_session_res_adm_list))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                            "Encodeing of IE3 - PDU Session Resource Handover "
                            "Admitted list Failed ");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_3(
                    &asn1_ctx,
                    &p_asn_ho_req_ack->protocolIEs,
                    p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE3 PDU Session Resource Handover Admitted list");
            break;
        }

        /*Encode IE 4 - (O) PDU Session Resource Handover Failed to Setup List*/
        if(HO_REQ_ACK_PDU_SESSION_FAILED_TO_SETUP_LIST_PRESENT &
                p_ngap_local_ho_req_ack->bitmask)
        {
            ngap_PDUSessionResourceFailedToSetupListHOAck *p_value_ie4 = NGAP_P_NULL;

            OSRTDList ngap_pdu_session_ie4;

            rtxDListInit(&ngap_pdu_session_ie4);

            p_value_ie4 = &ngap_pdu_session_ie4;

            if(NGAP_FAILURE ==
                    ngap_encode_pdu_session_resource_failed_list(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_ngap_local_ho_req_ack->ho_req_ack_pdu_session_res_fail_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encodeing of IE3 - PDU Session Resource Handover"
                        " Failed to Setup list Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_4(
                        &asn1_ctx,
                        &p_asn_ho_req_ack->protocolIEs,
                        p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE4 PDU Session Resource Handover "
                        "Failed to Setup list");
                break;
            }
        }

        /*Encode IEs 5 - ngap Target To Source Transparent Container */
        ngap_TargetToSource_TransparentContainer *p_value_ie5 = NGAP_P_NULL;

        p_value_ie5 =
            rtxMemAllocTypeZ(&asn1_ctx,ngap_TargetToSource_TransparentContainer );

        if(NGAP_P_NULL == p_value_ie5)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        
        p_value_ie5->data =
            (OSOCTET *)rtxMemAllocZ(&asn1_ctx, NGAP_MAX_ASN1_BUF_LEN );

        if(NGAP_P_NULL == p_value_ie5->data )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to allocate memory to data");
            response = NGAP_FAILURE;
            return response;
        }

        if (NGAP_FAILURE == ngap_encode_trg_to_src_ngran_transparent_container(
                             p_value_ie5,
                             &p_ngap_local_ho_req_ack->trg_to_src_transparent_container))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to encode Target to Source Transparent Container");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_5( 
                    &asn1_ctx,
                    &p_asn_ho_req_ack->protocolIEs,
                    p_value_ie5 ))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
            "Failed to Add IE5- Target to sOURCE TRANSPARENT CONTAINER");
            break;
        }

        /* Encode IE 6 - (O) critically_dignostic*/
        if(HO_REQ_ACK_CRITICAL_DIAGNOSTICS_PRESENT &
                p_ngap_local_ho_req_ack->bitmask )
        {
            ngap_CriticalityDiagnostics  *p_value_ie6 = NGAP_P_NULL;

            p_value_ie6 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie6)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie6,
                        &p_ngap_local_ho_req_ack->criticality_diagnostics))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE8 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }
            
            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverRequestAcknowledge_protocolIEs_6(
                        &asn1_ctx,
                        &p_asn_ho_req_ack->protocolIEs,
                        p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE6 - Criticality Diagnostics");
                break;

            }
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for HAndover Req Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of Handover Request Ack Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
    
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_handover_failure
 * Inputs           : p_ngap_local_ho_fail - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Failure ASN message from the
 *				      information provided in p_ngap_local_ho_fail. This messgae 
 *				      is failure response of HO Request and is send from T-NG-RAN 
 *				      to AMF
 *****************************************************************************/
ngap_return_et ngap_encode_handover_failure 
(
 ngap_handover_failure_t    *p_ngap_local_ho_fail,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_HandoverFailure *p_asn_ho_fail = NGAP_P_NULL;//HandOver changes
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;

        ngap_pdu.u.unsuccessfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*set unsuccessful message type to Handover Failure*/
        p_asn_ho_fail = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverFailure);//HandOver changes

        if(NGAP_P_NULL == p_asn_ho_fail)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_UnsuccessfulOutcome_handoverResourceAllocation(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_asn_ho_fail);//HandOver changes

        /*Encode all IEs of HO Failure*/

        /*Encode IE 1 - AMF_UE_NGAP_ID*/
        ngap_AMF_UE_NGAP_ID     value_ie1 = NGAP_ZERO;

        value_ie1 = p_ngap_local_ho_fail->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverFailure_protocolIEs_1(
                    &asn1_ctx, 
                    &p_asn_ho_fail->protocolIEs,
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 2 - ngap_Cause*/
        ngap_Cause              *p_value_ie2;/*ASN HOC  IE2 ptr */

        p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie2)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie2,
                    &p_ngap_local_ho_fail->choice_cause_group)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverFailure_protocolIEs_2(
                    &asn1_ctx,
                    &p_asn_ho_fail->protocolIEs, 
                    p_value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - Cause");
            break;
        }

        /* Encode IE 3 - (O) critically_dignostic*/
        if(HO_FAILURE_CRITICAL_DIAGNOSTICS_PRESENT &
                p_ngap_local_ho_fail->bitmask )
        {
            ngap_CriticalityDiagnostics  *p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ngap_local_ho_fail->criticality_diagnostics))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }
            
            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverFailure_protocolIEs_3(
                        &asn1_ctx,
                        &p_asn_ho_fail->protocolIEs,
                        p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;
            }
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Handover Failure");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of 'Handover Failure' Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
   
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_handover_notify
 * Inputs           : p_ngap_local_ho_notify - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Notify ASN message from the
 *				      information provided in p_ngap_local_ho_notify. This messgae 
 *				      is send from T-NG-RAN to AMF after rcving RRCReconfigComp from 
 *				      UE
 *****************************************************************************/
ngap_return_et ngap_encode_handover_notify
(
 ngap_handover_notify_t     *p_ngap_local_ho_notify,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_HandoverNotify             *p_asn_ho_notify = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage= 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*set initiating message type to Handover notify*/
        p_asn_ho_notify = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverNotify);

        if(NGAP_P_NULL == p_asn_ho_notify)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_handoverNotification(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_ho_notify);

        /*Encode all IEs of HO Notify*/

        /*Encode IE 1 - AMF_UE_NGAP_ID*/
        ngap_AMF_UE_NGAP_ID     value_ie1 = NGAP_ZERO;

        value_ie1 = p_ngap_local_ho_notify->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverNotify_protocolIEs_1(
                    &asn1_ctx, 
                    &p_asn_ho_notify->protocolIEs,
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /*Encode IE 2 - ran_ue_ngap_id*/
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;

        value_ie2 = p_ngap_local_ho_notify->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverNotify_protocolIEs_2(
                    &asn1_ctx, 
                    &p_asn_ho_notify->protocolIEs,
                    value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 3 - User Location Information */
        ngap_UserLocationInformation    *p_value_ie3 = NGAP_P_NULL;
        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_UserLocationInformation);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_user_location_info(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_ngap_local_ho_notify->choice_user_location_information))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Encoding of IE3 - User Location Information Failed");

            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverNotify_protocolIEs_3(
                    &asn1_ctx,
                    &p_asn_ho_notify->protocolIEs, 
                    p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed to Add IE3 - User Location Information to NGAP PDU");
            break;
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Handover Failure");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of 'Handover Failure' Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
   
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_handover_cancel
 * Inputs           : p_ngap_local_ho_cancel - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Cencel ASN message from the
 *				      information provided in p_ngap_local_ho_cancel. This messgae 
 *				      is send from S-NG-RAN to AMF for cancelling the ongoing HO 
 *				      request procedure.
 *****************************************************************************/
ngap_return_et ngap_encode_handover_cancel
(
 ngap_handover_cancel_t     *p_ngap_local_ho_cancel,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_HandoverCancel             *p_asn_ho_cancel = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage= 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL == ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*set initiating message type to Handover cancel*/
        p_asn_ho_cancel = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverCancel);

        if(NGAP_P_NULL == p_asn_ho_cancel)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_handoverCancel(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_asn_ho_cancel);

        /*Encode all IEs of HO cancel*/

        /*Encode IE 1 - AMF_UE_NGAP_ID*/
        ngap_AMF_UE_NGAP_ID     value_ie1 = NGAP_ZERO;

        value_ie1 = p_ngap_local_ho_cancel->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCancel_protocolIEs_1(
                    &asn1_ctx, 
                    &p_asn_ho_cancel->protocolIEs,
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /*Encode IE 2 - ran_ue_ngap_id*/
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;/*Handover bug fixes*/
        
        value_ie2 = p_ngap_local_ho_cancel->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCancel_protocolIEs_2(
                    &asn1_ctx, 
                    &p_asn_ho_cancel->protocolIEs,
                    value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 3 - Cause */
        ngap_Cause *p_value_ie3 = NGAP_P_NULL;
        p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_P_NULL == p_value_ie3)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie3,
                    &p_ngap_local_ho_cancel->choice_cause_group)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE3-Cause Failed");
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_HandoverCancel_protocolIEs_3(
                    &asn1_ctx,
                    &p_asn_ho_cancel->protocolIEs, 
                    p_value_ie3))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE3 - Cause");
            break;
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Handover Cancel");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of 'Handover Cancel' Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
   
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_handover_cancel_ack
 * Inputs           : p_ngap_local_ho_cancel_ack - 
 *                          Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes NGAP HO Cancel Ack ASN message from the
 *				      information provided in p_ngap_local_ho_cancel_ack. This 
 *				      messgae is send from AMF to S-NG-RAN in response to HO 
 *				      cancel procedure.
 *****************************************************************************/
ngap_return_et ngap_encode_handover_cancel_ack
(
 ngap_handover_cancel_ack_t *p_ngap_local_ho_cancel_ack,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                   ngap_pdu;
    OSCTXT                          asn1_ctx;
    ngap_HandoverCancelAcknowledge  *p_asn_ho_cancel_ack = NGAP_P_NULL;
    ngap_return_et                  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*set successful message type to Handover cancel Ack */
        p_asn_ho_cancel_ack = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_HandoverCancelAcknowledge);

        if(NGAP_P_NULL == p_asn_ho_cancel_ack)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_handoverCancel(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_asn_ho_cancel_ack);

        /*Encode all IEs of HO cancel Ack*/

        /*Encode IE 1 - AMF_UE_NGAP_ID*/
        ngap_AMF_UE_NGAP_ID     value_ie1 = NGAP_ZERO;

        value_ie1 = p_ngap_local_ho_cancel_ack->amf_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCancelAcknowledge_protocolIEs_1(
                    &asn1_ctx, 
                    &p_asn_ho_cancel_ack->protocolIEs,
                    value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /*Encode IE 2 - ran_ue_ngap_id*/
        ngap_RAN_UE_NGAP_ID value_ie2 = NGAP_ZERO;

        value_ie2 = p_ngap_local_ho_cancel_ack->ran_ue_ngap_id;

        if(NGAP_ASN_OK != asn1Append_ngap_HandoverCancelAcknowledge_protocolIEs_2(
                    &asn1_ctx, 
                    &p_asn_ho_cancel_ack->protocolIEs,
                    value_ie2))
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Failed to Add IE1 - AMF_UE_NGAP_ID to NGAP PDU");
            break;
        }

        /* Encode IE 3 - (O) critically_dignostic*/
        if(HO_CANCEL_ACK_CRITICAL_DIAGNOSTICS_PRESENT &
                p_ngap_local_ho_cancel_ack->bitmask )
        {
            ngap_CriticalityDiagnostics  *p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ngap_local_ho_cancel_ack->criticality_diagnostics))

            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }
            
            if(NGAP_ASN_OK !=
                    asn1Append_ngap_HandoverCancelAcknowledge_protocolIEs_3(
                        &asn1_ctx,
                        &p_asn_ho_cancel_ack->protocolIEs,
                        p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;
            }
        }

        /*ASN Encode message*/
        if(NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for Handover Cancel");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of 'Handover Cancel' Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }
    }while(0);
    
    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);
   
    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ran_config_update
 * Inputs           : p_ran_config_update - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes RAN CONFIGURATION UPDATE ASN message from the
 *	  	      information provided in p_ran_config_update
 *****************************************************************************/
ngap_return_et ngap_encode_ran_config_update
(
    ran_config_update_t	    *p_ran_config_update,  /* Input - Local Buffer */
    UInt8                   *p_asn_msg, 	       /* Output - ASN Encoded Buffer */
    UInt16                  *p_asn_msg_len	 	   /* Output - ASN Encoded Buffer Length */
)
{
    ngap_NGAP_PDU 		          ngap_pdu;
    OSCTXT                  	  asn1_ctx;
    ngap_RANConfigurationUpdate   *p_ngap_RANConfigurationUpdate = NGAP_P_NULL;
    ngap_return_et           	  response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to RAN CONFIGURATION UPDATE */
        p_ngap_RANConfigurationUpdate = rtxMemAllocTypeZ(&asn1_ctx, ngap_RANConfigurationUpdate);

        if(NGAP_P_NULL == p_ngap_RANConfigurationUpdate)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_rANConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_RANConfigurationUpdate);

        /* Encode 4 IEs of RAN CONFIG UPDATE Message */

        /* Encode IE 1 - RAN NODE NAME IE */
        if(RAN_CONFIG_UPDATE_RAN_NODE_NAME_PRESENT &
                p_ran_config_update->bitmask)
        {
            ngap_RANNodeName value_ie1 = NGAP_P_NULL;
            value_ie1 = (ngap_RANNodeName)p_ran_config_update->ran_node_name;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdate_protocolIEs_1(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate->protocolIEs, value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE1 - RAN Node Name ");
                break;
            }
        }

        /* Encode IE 2 - Supported TA List  */
        if(RAN_CONFIG_UPDATE_SUPPORTED_TA_LIST_PRESENT &
                p_ran_config_update->bitmask)
        {
            ngap_SupportedTAList	*p_value_ie2 = NGAP_P_NULL; 		
            OSRTDList               ranConfigUpdateIEs_2;

            rtxDListInit(&ranConfigUpdateIEs_2);
            p_value_ie2 = &ranConfigUpdateIEs_2;

            if(NGAP_FAILURE == ngap_encode_ie_supported_ta_list(
                        &asn1_ctx,
                        p_value_ie2,
                        &p_ran_config_update->supported_ta_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2-Supported TA List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdate_protocolIEs_2(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate->protocolIEs, p_value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE2 - Supported TA List ");
                break;
            }
        }
        /* Encode IE 3 - Default Paging DRX   */
        if(RAN_CONFIG_UPDATE_DEFAULT_PAGING_DRX_PRESENT &
                p_ran_config_update->bitmask)
        {
            ngap_PagingDRX value_ie3 = NGAP_ZERO;
            value_ie3 = (ngap_PagingDRX)p_ran_config_update->default_paging_drx;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdate_protocolIEs_3(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate->protocolIEs, value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - Default Paging DRX ");
                break;
            }
        }

        /* Encode IE 4 -Global RAN Node Id    */
        if(RAN_CONFIG_UPDATE_GLOBAL_RAN_NODE_ID_PRESENT &
                p_ran_config_update->bitmask)
        {
            ngap_GlobalRANNodeID *p_value_ie4 = NGAP_P_NULL;
            p_value_ie4 = rtxMemAllocTypeZ(&asn1_ctx, ngap_GlobalRANNodeID);

            if(NGAP_P_NULL == p_value_ie4)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_global_ran_node_id(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_ran_config_update->global_ran_node_id)
              )
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4-Global RAN Node ");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdate_protocolIEs_4(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE4 - Global RAN Node Id ");
                break;
            }
        }
        /* Encode IE 5 - NG-RAN TNL Association to Remove List */
        if(RAN_CONFIG_UPDATE_GLOBAL_RAN_NODE_ID_PRESENT &
                p_ran_config_update->bitmask)
        {
            ngap_NGRAN_TNLAssociationToRemoveList *p_value_ie5 = NGAP_P_NULL;
            OSRTDList                              ranConfigUpdateIEs_5;

            rtxDListInit(&ranConfigUpdateIEs_5);
            p_value_ie5 = &ranConfigUpdateIEs_5;

            if(NGAP_FAILURE == ngap_encode_ie_tnl_remove_list(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_ran_config_update->tnl_asso_remove_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE 5 - NG-RAN TNL Association to Remove List Failed");
                response=NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdate_protocolIEs_5(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate->protocolIEs,p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE5 - NG-RAN TNL Association to Remove List");
                break;
            }
        }
        /* ASN Encode Message */
        if (NGAP_ASN_OK !=
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for RAN CONFIG UPDATE");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of RAN CONFIG UPDATE Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/***************************************************************************************************
 * Function Name    : ngap_encode_ran_config_update_ack
 * Inputs           : p_ran_config_update_ack - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes RAN CONFIGURATION UPDATE ACK ASN message from the
 *	  	              information provided in p_ran_config_update_ack
 **************************************************************************************************/
ngap_return_et ngap_encode_ran_config_update_ack
(
    ran_config_update_ack_t *p_ran_config_update_ack,  /* Input - Local Buffer */
    UInt8                   *p_asn_msg, 	           /* Output - ASN Encoded Buffer */
    UInt16                  *p_asn_msg_len	 	       /* Output - ASN Encoded Buffer Length */
)
{
    ngap_NGAP_PDU 		                   ngap_pdu;
    OSCTXT                  	           asn1_ctx;
    ngap_RANConfigurationUpdateAcknowledge *p_ngap_RANConfigurationUpdate_ack = NGAP_P_NULL;
    ngap_RANConfigurationUpdateAcknowledge_protocolIEs_element *pElem         = NGAP_P_NULL;     
    ngap_return_et           	           response                           = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the successful outcome to RAN CONFIG UPDATE ACK*/
        p_ngap_RANConfigurationUpdate_ack = rtxMemAllocTypeZ(&asn1_ctx, ngap_RANConfigurationUpdateAcknowledge);

        if(NGAP_P_NULL == p_ngap_RANConfigurationUpdate_ack)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_SuccessfulOutcome_rANConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.successfulOutcome,  p_ngap_RANConfigurationUpdate_ack); 


        /*Encode IEs */

        /*Encode IE1 - */

        if(RAN_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT &
                p_ran_config_update_ack->bitmask)
        {

            ngap_CriticalityDiagnostics     *p_value_ie1 = NGAP_P_NULL;

            p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie1)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie1,
                        &p_ran_config_update_ack->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE1 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            pElem = rtxMemAllocType(&asn1_ctx,
                    ngap_RANConfigurationUpdateAcknowledge_protocolIEs_element);

            if(NGAP_P_NULL == pElem )
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            pElem->id = ASN1V_ngap_id_CriticalityDiagnostics;
            pElem->criticality = ngap_ignore;
            pElem->value.t = T47ngap___ngap_RANConfigurationUpdateAcknowledgeIEs_1;
            pElem->value.u._ngap_RANConfigurationUpdateAcknowledgeIEs_1 = 
                p_value_ie1; 
            if (NGAP_ZERO == rtxDListAppend (&asn1_ctx,
                        &p_ngap_RANConfigurationUpdate_ack->protocolIEs,
                        (void*)pElem))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - Criticality Diagnostics");
                break;
            }


            /* if(NGAP_ASN_OK != 
               To do:append)
               {
               RRC_NGAP_TRACE(NGAP_ERROR, 
               "Failed to Add IE1 - Criticality Diagnostics");
               break;
               }*/
        }
        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for RAN CONFIG UPDATE Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of RAN CONFIG UPDATE ACK  Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/****************************************************************************************************
 * Function Name    : ngap_encode_ran_config_update_fail
 * Inputs           : p_ran_config_update_fail - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes RAN CONFIGURATION UPDATE FAIL ASN message from the
 *	  	              information provided in p_ran_config_update_failure
 ***************************************************************************************************/
ngap_return_et ngap_encode_ran_config_update_fail
(
    ran_config_update_failure_t    *p_ng_ran_config_update_fail,
    UInt8                          *p_asn_msg,
    UInt16                         *p_asn_msg_len
)
{
    ngap_NGAP_PDU                      ngap_pdu;
    OSCTXT                             asn1_ctx;
    ngap_RANConfigurationUpdateFailure *p_ngap_RANConfigurationUpdateFailure = NGAP_P_NULL;
    ngap_return_et                     response                              = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do 
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;
        ngap_pdu.u.unsuccessfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);
        if(NGAP_P_NULL == ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to RAN Config Update Fail */
        p_ngap_RANConfigurationUpdateFailure = rtxMemAllocTypeZ(&asn1_ctx, 
                ngap_RANConfigurationUpdateFailure);
        if(NGAP_P_NULL == p_ngap_RANConfigurationUpdateFailure)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;        
        }

        asn1SetTC_ngap_UnsuccessfulOutcome_rANConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_ngap_RANConfigurationUpdateFailure);

        /* Encode 3 IEs of RAN CONFIG UPDATE FAILURE Message */
        /* Encode IE 1 - cause */

        ngap_Cause *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_ran_config_update_fail->choice_cause_group))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1-Cause Failed"); 
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_RANConfigurationUpdateFailure_protocolIEs_1(&asn1_ctx,
                    &p_ngap_RANConfigurationUpdateFailure->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - Cause");
            break; 
        }
        /* Encode IE 2 - Time to Wait  */
        if(RAN_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT &
                p_ng_ran_config_update_fail->bitmask)
        {
            ngap_TimeToWait_Root value_ie2 = ngap_v1s; 

            value_ie2 = (ngap_TimeToWait_Root)p_ng_ran_config_update_fail->\
                        time_to_wait_event_id;
            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdateFailure_protocolIEs_2(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdateFailure->protocolIEs, value_ie2))
            {            
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - TimeToWait");
                break;
            }
        }

        /* Encode IE 3 - Criticality Diagnostics */ 
        if(RAN_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT &
                p_ng_ran_config_update_fail->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie3 = NGAP_P_NULL;
            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;            
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ng_ran_config_update_fail->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3 - Criticality Diagnostics"); 
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_RANConfigurationUpdateFailure_protocolIEs_3(&asn1_ctx,
                        &p_ngap_RANConfigurationUpdateFailure->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;            
            }

        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for RAN CONFIG UPDATE  Fail");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of RAN CONFIG UPDATE Failure Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/**************************************************************************************************
 * Function Name    : ngap_encode_amf_configuration_update
 * Inputs           : p_ng_amf_config_update - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                      p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                      NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes AMF CONFIGURATION UPDATE ASN message from the
 *				      information provided in p_ng_amf_config_update
 **************************************************************************************************/
ngap_return_et ngap_encode_amf_configuration_update
(
    amf_config_update_t	       *p_ng_amf_config_update,     /* Input - Local Buffer */
    UInt8                      *p_asn_msg, 	                /* Output - ASN Encoded Buffer */
    UInt16                     *p_asn_msg_len	            /* Output - ASN Encoded Buffer Length */
)
{
    ngap_NGAP_PDU                       ngap_pdu;
    OSCTXT                              asn1_ctx;
    ngap_AMFConfigurationUpdate         *p_ngap_AMFConfigurationUpdate = NGAP_P_NULL;
    ngap_return_et                      response                       = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /* Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_initiatingMessage;

        ngap_pdu.u.initiatingMessage =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_InitiatingMessage);

        if(NGAP_P_NULL ==  ngap_pdu.u.initiatingMessage)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to amf configuration update */
        p_ngap_AMFConfigurationUpdate = rtxMemAllocTypeZ(&asn1_ctx, ngap_AMFConfigurationUpdate);

        if(NGAP_P_NULL == p_ngap_AMFConfigurationUpdate)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        asn1SetTC_ngap_InitiatingMessage_aMFConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.initiatingMessage, p_ngap_AMFConfigurationUpdate);

        /* Encode 7 IEs of AMF configuration update Message */ 

        /* Encode IE 1 - NGAP AMF-NAME */
        if(AMF_CONFIG_UPDATE_AMF_NAME & p_ng_amf_config_update->bitmask)
        {    
            ngap_AMFName p_value_ie1 = NGAP_P_NULL;
            p_value_ie1 = (ngap_AMFName)p_ng_amf_config_update->amf_name.amf_name;


            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_1(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - AMF Name to NGAP PDU");
                break;
            }
        }

        /* Encode IE 2 - Served GUAMI List */
        if(AMF_CONFIG_UPDATE_SERVED_GUAMI_LIST & p_ng_amf_config_update->bitmask)
        {
            ngap_ServedGUAMIList    *p_value_ie2 = NGAP_P_NULL;
            OSRTDList               ngAMFConfigUpdateIEs_2;

            rtxDListInit(&ngAMFConfigUpdateIEs_2);

            p_value_ie2 = &ngAMFConfigUpdateIEs_2;

            if(NGAP_FAILURE == ngap_encode_ie_served_guami_list(
                        &asn1_ctx,
                        p_value_ie2,
                        &p_ng_amf_config_update->served_guami_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE2-Served GUAMI List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_2(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - Served GUAMI list to NGAP PDU");
                break;
            }
        }
        /* Encode IE 3 - Relative AMF Capacity */

        if(AMF_CONFIG_UPDATE_RELATIVE_AMF_CAPACITY & p_ng_amf_config_update->bitmask)
        {    
            ngap_RelativeAMFCapacity value_ie3 = NGAP_ZERO;
            value_ie3 = (ngap_RelativeAMFCapacity)p_ng_amf_config_update->relative_amf_capacity;

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_3(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE3 - Relative AMF Capacity to NGAP PDU");
                break;
            }
        }
        /* Encode IE 4 - PLMN Support List */
        if(AMF_CONFIG_UPDATE_PLMN_SUPPORT_LIST & p_ng_amf_config_update->bitmask)
        {
            ngap_PLMNSupportList    *p_value_ie4 = NGAP_P_NULL;
            OSRTDList               ngAMFConfigUpdateIEs_4;

            rtxDListInit(&ngAMFConfigUpdateIEs_4);

            p_value_ie4 = &ngAMFConfigUpdateIEs_4;

            if(NGAP_FAILURE == ngap_encode_ie_plmn_support_list(
                        &asn1_ctx,
                        p_value_ie4,
                        &p_ng_amf_config_update->plmn_support_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE4- PLMN Supported List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_4(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie4))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE4 - PLMN Supported list to NGAP PDU");
                break;
            }
        }
        /* Encode IE 5 - AMF TNL Association to Add List */
        if(AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_ADD_LIST & 
                p_ng_amf_config_update->bitmask)
        {
            ngap_AMF_TNLAssociationToAddList    *p_value_ie5 = NGAP_P_NULL;
            OSRTDList                           ngAMFConfigUpdateIEs_5;

            rtxDListInit(&ngAMFConfigUpdateIEs_5);

            p_value_ie5 = &ngAMFConfigUpdateIEs_5;

            if(NGAP_FAILURE == ngap_encode_ie_amf_tnl_association_add_to_list(
                        &asn1_ctx,
                        p_value_ie5,
                        &p_ng_amf_config_update->association_add_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE5- ANF TNL Association Add to List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_5(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie5))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE5 - ANF TNL Association Add to List to NGAP PDU");
                break;
            }
        }
        /* Encode IE 6 - AMF TNL Association to Remove List */
        if(AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_REMOVE_LIST & 
                p_ng_amf_config_update->bitmask)
        {
            ngap_AMF_TNLAssociationToRemoveList    *p_value_ie6 = NGAP_P_NULL;
            OSRTDList                               ngAMFConfigUpdateIEs_6;

            rtxDListInit(&ngAMFConfigUpdateIEs_6);

            p_value_ie6 = &ngAMFConfigUpdateIEs_6;

            if(NGAP_FAILURE == ngap_encode_ie_amf_tnl_association_to_remove_list(
                        &asn1_ctx,
                        p_value_ie6,
                        &p_ng_amf_config_update->association_remove_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE6- AMF TNL Association to Remove List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_6(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie6))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE6 - AMF TNL Association to Remove List to NGAP PDU");
                break;
            }
        }
        /* Encode IE 7 - AMF TNL Association to update List */
        if(AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_UPDATE_LIST & 
                p_ng_amf_config_update->bitmask)
        {
            ngap_AMF_TNLAssociationToUpdateList    *p_value_ie7 = NGAP_P_NULL;
            OSRTDList                              ngAMFConfigUpdateIEs_7;

            rtxDListInit(&ngAMFConfigUpdateIEs_7);

            p_value_ie7 = &ngAMFConfigUpdateIEs_7;

            if(NGAP_FAILURE == ngap_encode_ie_amf_tnl_association_to_update_list(
                        &asn1_ctx,
                        p_value_ie7,
                        &p_ng_amf_config_update->association_update_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE7- AMF TNL Association to update List Failed");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdate_protocolIEs_7(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdate->protocolIEs, p_value_ie7))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE7 - AMF TNL Association to update List to NGAP PDU");
                break;
            }
        }
        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for AMF Configuration Update");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of AMF Configuration Update Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"AMF Configuration Update", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }


    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_amf_tnl_association_add_to_list
 * Inputs           : p_asn1_ctx
 *                    p_ngap_local_supported_ta_list
 * Outputs          : p_ngap_asn_supported_ta_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                      NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_amf_tnl_association_add_to_list
(
    OSCTXT			                    *p_asn1_ctx,
    ngap_AMF_TNLAssociationToAddList	*p_ngap_asn_amf_tnl_assoc,              /* ASN Buffer */
    amf_tnl_association_to_add_list_t   *p_ngap_local_amf_tnl_assoc_add_list    /* NGAP Local Buffer */
)
{
    ngap_AMF_TNLAssociationToAddItem    *p_ngap_amf_tnl_assoc_add_to_item  = NGAP_P_NULL;
    OSRTDListNode                       *p_amf_tnl_item_node               = NGAP_P_NULL;
    ngap_return_et                      response                           = NGAP_SUCCESS;
    UInt16			                    tnl_assoc_item_count               = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 AMF TNL Association add to list item should be present */
    if (NGAP_ZERO == p_ngap_local_amf_tnl_assoc_add_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No AMF TNL Association to add list Present");
        response = NGAP_FAILURE;
    }

    for (tnl_assoc_item_count = NGAP_ZERO; 
            tnl_assoc_item_count < p_ngap_local_amf_tnl_assoc_add_list->count;
            tnl_assoc_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AMF_TNLAssociationToAddItem,
                &p_amf_tnl_item_node,
                &p_ngap_amf_tnl_assoc_add_to_item);

        if ( (NGAP_P_NULL == p_amf_tnl_item_node) || 
                (NGAP_P_NULL == p_ngap_amf_tnl_assoc_add_to_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_amf_tnl_assoc_add_to_item, 
                NGAP_ZERO, sizeof(ngap_AMF_TNLAssociationToAddItem));

        /* AMF TNL Association Address */
        p_ngap_amf_tnl_assoc_add_to_item->aMF_TNLAssociationAddress.t = 
            T_ngap_CPTransportLayerInformation_endpointIPAddress;

        /* Allocate the memory for Transport layer address */
        p_ngap_amf_tnl_assoc_add_to_item->aMF_TNLAssociationAddress.u.endpointIPAddress = 
             rtxMemAllocTypeZ(p_asn1_ctx, ngap_TransportLayerAddress);

        p_ngap_amf_tnl_assoc_add_to_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data = 
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

        p_ngap_amf_tnl_assoc_add_to_item->aMF_TNLAssociationAddress.u.endpointIPAddress->numbits = 
            NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS; 

        NGAP_MEMCPY ((void *)p_ngap_amf_tnl_assoc_add_to_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data,
                p_ngap_local_amf_tnl_assoc_add_list->tnl_association_item[tnl_assoc_item_count].\
                tnl_association_address.endpoint_ip_address.transport_layer_address,
                NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

        /* TNL Association Usage */
        if(p_ngap_local_amf_tnl_assoc_add_list->tnl_association_item[tnl_assoc_item_count].\
                bitmask & TNL_ASSOCIATION_TO_ADD_LIST_USAGE_PRESENT)
        {
            p_ngap_amf_tnl_assoc_add_to_item->m.tNLAssociationUsagePresent = NGAP_TRUE;

            p_ngap_amf_tnl_assoc_add_to_item->tNLAssociationUsage = 
                p_ngap_local_amf_tnl_assoc_add_list->tnl_association_item[tnl_assoc_item_count].\
                association_usage;
        }

        /* TNL Address Weight Factor */
        p_ngap_amf_tnl_assoc_add_to_item->tNLAddressWeightFactor =
            p_ngap_local_amf_tnl_assoc_add_list->tnl_association_item[tnl_assoc_item_count].\
            weight_factor;

        /* Add One amf TNL associatio Item to the Node */
        rtxDListAppendNode(p_ngap_asn_amf_tnl_assoc, p_amf_tnl_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
/******************************************************************************
 * Function Name    : ngap_encode_ie_amf_tnl_association_to_remove_list
 * Inputs           : p_asn1_ctx
 *                    p_ngap_local_supported_ta_list
 * Outputs          : p_ngap_asn_supported_ta_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/

ngap_return_et ngap_encode_ie_amf_tnl_association_to_remove_list
(
  OSCTXT                              *p_asn1_ctx,
  ngap_AMF_TNLAssociationToRemoveList *p_ngap_asn_amf_tnl_assoc,              /* ASN Buffer */
  amf_tnl_association_remove_list_t   *p_ngap_local_amf_tnl_assoc_rem_list    /* NGAP Local Buffer */
)
{
    ngap_AMF_TNLAssociationToRemoveItem  *p_ngap_amf_tnl_assoc_to_rem_item  = NGAP_P_NULL;
    OSRTDListNode                        *p_amf_tnl_item_node               = NGAP_P_NULL;
    ngap_return_et                       response                           = NGAP_SUCCESS;
    UInt16			                     tnl_assoc_item_count               = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 AMF TNL Association add to list item should be present */
    if (NGAP_ZERO == p_ngap_local_amf_tnl_assoc_rem_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No AMF TNL Association to remove list Present");
        response = NGAP_FAILURE;
    }
    for (tnl_assoc_item_count = NGAP_ZERO; 
            tnl_assoc_item_count < p_ngap_local_amf_tnl_assoc_rem_list->count;
            tnl_assoc_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AMF_TNLAssociationToRemoveItem,
                &p_amf_tnl_item_node,
                &p_ngap_amf_tnl_assoc_to_rem_item);

        if ( (NGAP_P_NULL == p_amf_tnl_item_node) || 
                (NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_rem_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_amf_tnl_assoc_to_rem_item, 
                NGAP_ZERO, sizeof(ngap_AMF_TNLAssociationToRemoveItem));

        switch(p_ngap_local_amf_tnl_assoc_rem_list->\
                tnl_association_item[tnl_assoc_item_count].\
                tnl_association_address.choice)
        {
            case NGAP_TNL_ENDPOINT_IP_ADDR:
            {
                /* AMF TNL Association Address */
                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.t = 
                    T_ngap_CPTransportLayerInformation_endpointIPAddress;

                /* Allocate the memory for Transport layer address */
                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.endpointIPAddress =
                    rtxMemAllocTypeZ(p_asn1_ctx, ngap_TransportLayerAddress);

      if(NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_rem_item->\
            aMF_TNLAssociationAddress.u.endpointIPAddress)
      {
          NGAP_SYSTEM_MEM_FAIL();
          response = NGAP_FAILURE;
          break;
      }

     /* Allocate the memory for Transport layer address */
        p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.endpointIPAddress = 
            rtxMemAllocTypeZ(p_asn1_ctx, ngap_TransportLayerAddress);

        p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data = 
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

       if(NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_rem_item->\
           aMF_TNLAssociationAddress.u.endpointIPAddress->data)
       {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
       }

       p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.endpointIPAddress->numbits = 
           NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS; 


       NGAP_MEMCPY 
           ((void *)p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data,
            p_ngap_local_amf_tnl_assoc_rem_list->tnl_association_item[tnl_assoc_item_count].\
            tnl_association_address.endpoint_ip_address.transport_layer_address,
            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE
           );

       break;
            }

            case NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT:
            {
                /* Endpoint IP Address*/
                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.t = 
                    T_ngap_CPTransportLayerInformation_choice_Extensions;

                /* Allocate the memory for TNL Associations Transport layer Address */

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions =
                    rtxMemAllocTypeZ(p_asn1_ctx,
                            ngap_CPTransportLayerInformation_choice_Extensions);

                if(NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_rem_item->\
                    aMF_TNLAssociationAddress.u.choice_Extensions)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->id = ASN1V_ngap_id_EndpointIPAddressAndPort;

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->criticality = ngap_reject;

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->value.t =
                    T122ngap___ngap_CPTransportLayerInformation_ExtIEs_1;

                /* Allocate the memory for TNL Associations Transport layer Address
                 * for _ngap_CPTransportLayerInformation_ExtIEs_1*/

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.u.\
                  choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1 = 
                    rtxMemAllocTypeZ(p_asn1_ctx,
                            ngap_EndpointIPAddressAndPort);

                if(NGAP_P_NULL ==  p_ngap_amf_tnl_assoc_to_rem_item->\
                        aMF_TNLAssociationAddress.u.choice_Extensions->value.u.\
                        _ngap_CPTransportLayerInformation_ExtIEs_1)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1->\
                    endpointIPAddress.data =
                    (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,
                            NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                if(NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_rem_item->\
                        aMF_TNLAssociationAddress.u.choice_Extensions->value.u.\
                        _ngap_CPTransportLayerInformation_ExtIEs_1->\
                        endpointIPAddress.data)
                {
                    NGAP_SYSTEM_MEM_FAIL();
                    response = NGAP_FAILURE;
                    break;
                }

                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1->\
                    endpointIPAddress.numbits=
                    NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS;

                NGAP_MEMCPY(
                        (void *)p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                            u.choice_Extensions->value.u.\
                            _ngap_CPTransportLayerInformation_ExtIEs_1->\
                            endpointIPAddress.data,
                        p_ngap_local_amf_tnl_assoc_rem_list->\
                            tnl_association_item[tnl_assoc_item_count].\
                            tnl_association_address.endpoint_ip_address_and_port.\
                            endpoint_ip_address.transport_layer_address,
                        NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

                /*Port Number*/
                p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                    u.choice_Extensions->value.u.\
                    _ngap_CPTransportLayerInformation_ExtIEs_1->\
                    portNumber.numocts =
                    NGAP_PORT_NUMBER_OCTET_SIZE;

                NGAP_MEMCPY(
                        (void *)p_ngap_amf_tnl_assoc_to_rem_item->aMF_TNLAssociationAddress.\
                            u.choice_Extensions->value.u.\
                            _ngap_CPTransportLayerInformation_ExtIEs_1->portNumber.data,
                        p_ngap_local_amf_tnl_assoc_rem_list->\
                            tnl_association_item[tnl_assoc_item_count].\
                            tnl_association_address.endpoint_ip_address_and_port.\
                            port_number,
                        NGAP_PORT_NUMBER_OCTET_SIZE);
                break;
            }
        }
        /* Add One amf TNL associatio Item to the Node */
        rtxDListAppendNode(p_ngap_asn_amf_tnl_assoc, p_amf_tnl_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;


}
/******************************************************************************
 * Function Name    : ngap_encode_ie_amf_tnl_association_to_update_list
 * Inputs           : p_asn1_ctx
 *                    p_ngap_local_supported_ta_list
 * Outputs          : p_ngap_asn_supported_ta_list
 *                       
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 *                    
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_amf_tnl_association_to_update_list
( 
  OSCTXT                              *p_asn1_ctx,
  ngap_AMF_TNLAssociationToUpdateList *p_ngap_asn_amf_tnl_assoc,                 /* ASN Buffer */
  amf_tnl_association_update_list_t   *p_ngap_local_amf_tnl_assoc_update_list    /* NGAP Local Buffer */
 )
{
    ngap_AMF_TNLAssociationToUpdateItem  *p_ngap_amf_tnl_assoc_to_update_item  = NGAP_P_NULL;
    OSRTDListNode                        *p_amf_tnl_item_node               = NGAP_P_NULL;
    ngap_return_et                       response                           = NGAP_SUCCESS;
    UInt16			                     tnl_assoc_item_count               = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 AMF TNL Association add to list item should be present */
    if (NGAP_ZERO == p_ngap_local_amf_tnl_assoc_update_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No AMF TNL Association to update list Present");
        response = NGAP_FAILURE;
    }
    for (tnl_assoc_item_count = NGAP_ZERO; 
            tnl_assoc_item_count < p_ngap_local_amf_tnl_assoc_update_list->count;
            tnl_assoc_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AMF_TNLAssociationToUpdateItem,
                &p_amf_tnl_item_node,
                &p_ngap_amf_tnl_assoc_to_update_item);

        if ( (NGAP_P_NULL == p_amf_tnl_item_node) || 
                (NGAP_P_NULL == p_ngap_amf_tnl_assoc_to_update_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_amf_tnl_assoc_to_update_item, 
                NGAP_ZERO, sizeof(ngap_AMF_TNLAssociationToUpdateItem));

        /* AMF TNL Association Address */
        p_ngap_amf_tnl_assoc_to_update_item->aMF_TNLAssociationAddress.t = 
            T_ngap_CPTransportLayerInformation_endpointIPAddress;

        /* Allocate the memory for Transport layer address */
        p_ngap_amf_tnl_assoc_to_update_item->aMF_TNLAssociationAddress.u.endpointIPAddress = 
            rtxMemAllocTypeZ(p_asn1_ctx, ngap_TransportLayerAddress);

        p_ngap_amf_tnl_assoc_to_update_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data = 
            (OSOCTET *)rtxMemAllocZ(p_asn1_ctx,NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);

        p_ngap_amf_tnl_assoc_to_update_item->aMF_TNLAssociationAddress.u.endpointIPAddress->numbits = 
            NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS; 

        NGAP_MEMCPY ((void *)p_ngap_amf_tnl_assoc_to_update_item->aMF_TNLAssociationAddress.u.endpointIPAddress->data,
                p_ngap_local_amf_tnl_assoc_update_list->tnl_association_item[tnl_assoc_item_count].\
                tnl_association_address.endpoint_ip_address.transport_layer_address,
                NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE);
        /* TNL Association Usage */
        if( p_ngap_local_amf_tnl_assoc_update_list->tnl_association_item[tnl_assoc_item_count].\
                bitmask & TNL_ASSOCIATION_TO_UPDATE_USAGE_PRESENT)
        {
            p_ngap_amf_tnl_assoc_to_update_item->m.tNLAssociationUsagePresent = NGAP_TRUE;

            p_ngap_amf_tnl_assoc_to_update_item->tNLAssociationUsage = 
                p_ngap_local_amf_tnl_assoc_update_list->tnl_association_item[tnl_assoc_item_count].\
                association_usage;
        }

        /* TNL Address Weight Factor */
        if( p_ngap_local_amf_tnl_assoc_update_list->tnl_association_item[tnl_assoc_item_count].\
                bitmask & TNL_ASSOCIATION_TO_UPDATE_ADDRESS_WEIGHT_FACTOR_PRESENT)
        {
            p_ngap_amf_tnl_assoc_to_update_item->m.tNLAddressWeightFactorPresent = NGAP_TRUE;

            p_ngap_amf_tnl_assoc_to_update_item->tNLAddressWeightFactor =
                p_ngap_local_amf_tnl_assoc_update_list->tnl_association_item[tnl_assoc_item_count].\
                weight_factor;

        }

        /* Add One amf TNL associatio Item to the Node */
        rtxDListAppendNode(p_ngap_asn_amf_tnl_assoc, p_amf_tnl_item_node);
    }

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_association_failed_to_setup_list
 * Inputs           : p_asn1_ctx
 *                    p_ngap_local_amf_tnl_association_setup_item_t
 * Outputs          : p_ngap_amf_tnl_association_failed_to_setup_item_t
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_association_failed_to_setup_list
(
    OSCTXT                  *p_asn1_ctx,
    ngap_TNLAssociationList *p_ngap_tnl_association_failed_to_setup_list,   /* ASN Buffer */
    amf_tnl_association_failed_to_setup_list_t 
                         *p_ngap_local_tnl_association_failed_to_setup_list /* NGAP Local Buffer */
)
{
    ngap_TNLAssociationItem   *p_ngap_tnl_failed_to_setup_item  = NGAP_P_NULL; 
    OSRTDListNode             *tnl_setup_item_node              = NGAP_P_NULL;
    ngap_return_et            response                          = NGAP_SUCCESS;
    UInt16                    num_tnl_item_count                = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 tnl setup item should be present */
    if(NGAP_ZERO == p_ngap_local_tnl_association_failed_to_setup_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No TNL Remove List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(num_tnl_item_count = NGAP_ZERO;
            num_tnl_item_count < p_ngap_local_tnl_association_failed_to_setup_list->count;
            num_tnl_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_TNLAssociationItem,
                &tnl_setup_item_node,
                &p_ngap_tnl_failed_to_setup_item);

        if((NGAP_P_NULL == tnl_setup_item_node)||(NGAP_P_NULL == p_ngap_tnl_failed_to_setup_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_tnl_association_failed_to_setup_list,
                NGAP_ZERO, sizeof(ngap_TNLAssociationItem));

        /*filling IE AMF TNL Association Address*/
        response = ngap_fill_ip_add_and_port_info
            (
             p_asn1_ctx,
             &p_ngap_tnl_failed_to_setup_item->tNLAssociationAddress,
             &p_ngap_local_tnl_association_failed_to_setup_list->\
             tnl_association_setup_item[num_tnl_item_count].\
             tnl_association_address
            );

        if(NGAP_FAILURE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE - AMF TNL Association Address"); 
            response = NGAP_FAILURE;
            break;
        }

        /*filling IE Cause*/
        response = ngap_encode_ie_cause(
                p_asn1_ctx,
                &p_ngap_tnl_failed_to_setup_item->cause,
                &p_ngap_local_tnl_association_failed_to_setup_list->\
                tnl_association_setup_item[num_tnl_item_count].\
                choice_cause_group
                );
        if(NGAP_FAILURE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE- Cause"); 
            response = NGAP_FAILURE;
            break;
        }

        rtxDListAppendNode(p_ngap_tnl_association_failed_to_setup_list,
                tnl_setup_item_node);    
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/******************************************************************************
 * Function Name    : ngap_encode_ie_association_setup_list
 * Inputs           : p_asn1_ctx
 *                    p_ngap_local_amf_tnl_association_setup_item_t
 * Outputs          : p_ngap_amf_tnl_association_setup_item_t
 * Returns          : NGAP_SUCCESS - ASN preparation was successful
 *                    NGAP_FAILURE - ASN preparation was not successful
 * DESCRIPTION	    : This function fill ASN Structure using local structure 
 *****************************************************************************/
ngap_return_et ngap_encode_ie_association_setup_list
(
    OSCTXT                           *p_asn1_ctx,
    ngap_AMF_TNLAssociationSetupList *p_ngap_tnl_association_setup_list,       /* ASN Buffer */
    amf_tnl_association_setup_list_t *p_ngap_local_tnl_association_setup_list  /* NGAP Local Buffer */
)
{
    ngap_AMF_TNLAssociationSetupItem   *p_ngap_tnl_setup_item  = NGAP_P_NULL; 
    OSRTDListNode                      *tnl_setup_item_node     = NGAP_P_NULL;
    ngap_return_et                     response                = NGAP_SUCCESS;
    UInt16                             num_tnl_item_count      = NGAP_ZERO;

    RRC_NGAP_UT_TRACE_ENTER();

    /* At least 1 tnl setup item should be present */
    if(NGAP_ZERO == p_ngap_local_tnl_association_setup_list->count)
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "No TNL Remove List Present");
        response = NGAP_FAILURE;
        return response;
    }

    for(num_tnl_item_count = NGAP_ZERO;
            num_tnl_item_count < p_ngap_local_tnl_association_setup_list->count;
            num_tnl_item_count++)
    {
        rtxDListAllocNodeAndData(p_asn1_ctx,
                ngap_AMF_TNLAssociationSetupItem,
                &tnl_setup_item_node,
                &p_ngap_tnl_setup_item);

        if((NGAP_P_NULL == tnl_setup_item_node)||(NGAP_P_NULL == p_ngap_tnl_setup_item))
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        NGAP_MEMSET(p_ngap_tnl_association_setup_list,
                NGAP_ZERO, sizeof(ngap_AMF_TNLAssociationSetupItem));

        /*filling IE AMF TNL Association Address*/
        response = ngap_fill_ip_add_and_port_info
            (
             p_asn1_ctx,
             &p_ngap_tnl_setup_item->aMF_TNLAssociationAddress,
             &p_ngap_local_tnl_association_setup_list->\
             tnl_association_setup_item[num_tnl_item_count].\
             tnl_association_address
            );
        if(NGAP_FAILURE == response)
        {
            RRC_NGAP_TRACE(NGAP_ERROR,
                    "Encoding of IE - AMF TNL Association Address"); 
            response = NGAP_FAILURE;
            break;
        }

        rtxDListAppendNode(p_ngap_tnl_association_setup_list,
                tnl_setup_item_node);    
    }

    RRC_NGAP_UT_TRACE_EXIT();
    return response;
}

/***************************************************************************************************
 * Function Name    : ngap_encode_amf_config_update_ack
 * Inputs           : p_amf_config_update_ack - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes AMF CONFIGURATION UPDATE ACK ASN message from the
 *	  	              information provided in p_amf_config_update_ack
 ***************************************************************************************************/
ngap_return_et ngap_encode_amf_config_update_ack
(
    amf_config_update_ack_t    *p_ng_amf_config_update_ack,
    UInt8                      *p_asn_msg,
    UInt16                     *p_asn_msg_len
)
{
    ngap_NGAP_PDU                           ngap_pdu;
    OSCTXT                                  asn1_ctx;
    ngap_AMFConfigurationUpdateAcknowledge  *p_ngap_ngap_AMFConfigUpdateAck = 
        NGAP_P_NULL;
    ngap_return_et                          response = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));
        ngap_pdu.t = T_ngap_NGAP_PDU_successfulOutcome;

        ngap_pdu.u.successfulOutcome =
            rtxMemAllocTypeZ(&asn1_ctx, ngap_SuccessfulOutcome);

        if(NGAP_P_NULL == ngap_pdu.u.successfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /*Set the successful outcome to ng reset acknowledge*/
        p_ngap_ngap_AMFConfigUpdateAck = rtxMemAllocTypeZ(&asn1_ctx,
                ngap_AMFConfigurationUpdateAcknowledge);
        if(NGAP_P_NULL == p_ngap_ngap_AMFConfigUpdateAck)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;      
        }

        asn1SetTC_ngap_SuccessfulOutcome_aMFConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.successfulOutcome, p_ngap_ngap_AMFConfigUpdateAck);

        /* Encode IEs */

        /* Encode IE1 */
        if(AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_SETUP_PRESENT &
                p_ng_amf_config_update_ack->bitmask)
        {
            ngap_AMF_TNLAssociationSetupList      *p_value_ie1 = NGAP_P_NULL;
            OSRTDList                             ngAMFConfigUpdateAckIEs_1;

            rtxDListInit(&ngAMFConfigUpdateAckIEs_1);

            p_value_ie1 = &ngAMFConfigUpdateAckIEs_1;


            if(NGAP_P_NULL == p_value_ie1)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_association_setup_list(
                        &asn1_ctx,
                        p_value_ie1,
                        &p_ng_amf_config_update_ack->association_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE1 - Association setup list");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdateAcknowledge_protocolIEs_1(&asn1_ctx,
                        &p_ngap_ngap_AMFConfigUpdateAck->protocolIEs,
                        p_value_ie1))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1- Association setup list");
                break;
            }
        }
        /* Encode IE 2 - Association failed to setup list*/
        if(AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_FAILED_TO_SETUP_PRESENT &
                p_ng_amf_config_update_ack->bitmask)
        {
            ngap_TNLAssociationList             *p_value_ie2 = NGAP_P_NULL;

            OSRTDList                           ngAMFConfigUpdateAckIEs_2;

            rtxDListInit(&ngAMFConfigUpdateAckIEs_2);

            p_value_ie2 = rtxMemAllocTypeZ(&asn1_ctx,ngap_TNLAssociationList);


            if(NGAP_P_NULL == p_value_ie2)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;        
            }

            if(NGAP_FAILURE == ngap_encode_ie_association_failed_to_setup_list(
                        &asn1_ctx,
                        p_value_ie2,
                        &p_ng_amf_config_update_ack->association_failed_to_setup_list))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE2 - Association failed to setup list"); 
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdateAcknowledge_protocolIEs_2(&asn1_ctx,
                        &p_ngap_ngap_AMFConfigUpdateAck->protocolIEs, p_value_ie2))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE2 - Association failed to setup list");
                break;            
            }

        }


        /*Encode IE3 - Criticality Diagnostics */

        if(AMF_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT &
                p_ng_amf_config_update_ack->bitmask)
        {

            ngap_CriticalityDiagnostics     *p_value_ie3 = NGAP_P_NULL;

            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ng_amf_config_update_ack->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Encoding of IE3 - Criticality Diagnostics");
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK != 
                    asn1Append_ngap_AMFConfigurationUpdateAcknowledge_protocolIEs_3(&asn1_ctx,
                        &p_ngap_ngap_AMFConfigUpdateAck->protocolIEs,
                        p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR, 
                        "Failed to Add IE1 - Criticality Diagnostics");
                break;
            }
        }
        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer(&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed pu_setBuffer for AMF CONFIG UPDATE Ack");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of AMF CONFIG UPDATE ACK  Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (unsigned long)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}

/****************************************************************************************************
 * Function Name    : ngap_encode_amf_config_update_fail
 * Inputs           : p_amf_config_update_fail - Information from which Asn message will be prepared
 * Outputs          : p_asn_msg - Pointer to the buffer that is ASN encoded
 *                    p_asn_msg_len - Pointer to the length of ASN encoded msg
 * Returns          : NGAP_SUCCESS - ASN encoding was successful
 *                    NGAP_FAILURE - ASN encoding was not successful
 * DESCRIPTION	    : This function encodes AMF CONFIGURATION UPDATE ACK ASN message from the
 *	  	              information provided in p_amf_config_update_failure
 ***************************************************************************************************/
ngap_return_et ngap_encode_amf_config_update_fail
(
    amf_config_update_failure_t    *p_ng_amf_config_update_fail,
    UInt8                          *p_asn_msg,
    UInt16                         *p_asn_msg_len
)
{
    ngap_NGAP_PDU                      ngap_pdu;
    OSCTXT                             asn1_ctx;
    ngap_AMFConfigurationUpdateFailure *p_ngap_AMFConfigurationUpdateFailure = NGAP_P_NULL;
    ngap_return_et                     response                              = NGAP_SUCCESS;

    RRC_NGAP_UT_TRACE_ENTER();

    /*Init ASN.1 context */
    if(NGAP_ASN_OK != rtInitContext(&asn1_ctx))
    {
        RRC_NGAP_TRACE(NGAP_ERROR, "ASN Context Initialization Failed");
        response = NGAP_FAILURE;
        return response;
    }

    do 
    {
        NGAP_MEMSET(&ngap_pdu, NGAP_ZERO, sizeof(ngap_pdu));

        ngap_pdu.t = T_ngap_NGAP_PDU_unsuccessfulOutcome;
        ngap_pdu.u.unsuccessfulOutcome = 
            rtxMemAllocTypeZ(&asn1_ctx, ngap_UnsuccessfulOutcome);
        if(NGAP_P_NULL == ngap_pdu.u.unsuccessfulOutcome)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;
        }

        /* Set the initiating message type to AMF Config Update Fail */
        p_ngap_AMFConfigurationUpdateFailure = rtxMemAllocTypeZ(&asn1_ctx, 
                ngap_AMFConfigurationUpdateFailure);
        if(NGAP_P_NULL == p_ngap_AMFConfigurationUpdateFailure)
        {
            NGAP_SYSTEM_MEM_FAIL();
            response = NGAP_FAILURE;
            break;        
        }

        asn1SetTC_ngap_UnsuccessfulOutcome_aMFConfigurationUpdate(&asn1_ctx,
                ngap_pdu.u.unsuccessfulOutcome, p_ngap_AMFConfigurationUpdateFailure);

        /* Encode 3 IEs of AMF CONFIG UPDATE FAILURE Message */
        /* Encode IE 1 - cause */

        ngap_Cause *p_value_ie1 = NGAP_P_NULL;
        p_value_ie1 = rtxMemAllocTypeZ(&asn1_ctx, ngap_Cause);

        if(NGAP_FAILURE == ngap_encode_ie_cause(
                    &asn1_ctx,
                    p_value_ie1,
                    &p_ng_amf_config_update_fail->choice_cause_group)
          )
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of IE1-Cause Failed"); 
            response = NGAP_FAILURE;
            break;
        }

        if(NGAP_ASN_OK !=
                asn1Append_ngap_AMFConfigurationUpdateFailure_protocolIEs_1(&asn1_ctx,
                    &p_ngap_AMFConfigurationUpdateFailure->protocolIEs, p_value_ie1))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE1 - Cause");
            break; 
        }
        /* Encode IE 2 - Time to Wait  */
        if(AMF_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT &
                p_ng_amf_config_update_fail->bitmask)
        {
            ngap_TimeToWait_Root value_ie2 = ngap_v1s; 

            value_ie2 = (ngap_TimeToWait_Root)p_ng_amf_config_update_fail->\
                        time_to_wait_event_id;
            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdateFailure_protocolIEs_2(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdateFailure->protocolIEs, value_ie2))
            {            
                RRC_NGAP_TRACE(NGAP_ERROR, "Failed to Add IE2 - TimeToWait");
                break;
            }
        }

        /* Encode IE 3 - Criticality Diagnostics */ 
        if(AMF_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT &
                p_ng_amf_config_update_fail->bitmask)
        {
            ngap_CriticalityDiagnostics     *p_value_ie3 = NGAP_P_NULL;
            p_value_ie3 = rtxMemAllocTypeZ(&asn1_ctx, ngap_CriticalityDiagnostics);

            if(NGAP_P_NULL == p_value_ie3)
            {
                NGAP_SYSTEM_MEM_FAIL();
                response = NGAP_FAILURE;
                break;            
            }

            if(NGAP_FAILURE == ngap_encode_ie_criticality_diagnostics(
                        &asn1_ctx,
                        p_value_ie3,
                        &p_ng_amf_config_update_fail->criticality_diagnostics))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Encoding of IE3 - Criticality Diagnostics"); 
                response = NGAP_FAILURE;
                break;
            }

            if(NGAP_ASN_OK !=
                    asn1Append_ngap_AMFConfigurationUpdateFailure_protocolIEs_3(&asn1_ctx,
                        &p_ngap_AMFConfigurationUpdateFailure->protocolIEs, p_value_ie3))
            {
                RRC_NGAP_TRACE(NGAP_ERROR,
                        "Failed to Add IE3 - Criticality Diagnostics");
                break;            
            }

        }

        /* ASN Encode Message */
        if (NGAP_ASN_OK != 
                pu_setBuffer (&asn1_ctx, p_asn_msg, NGAP_MAX_ASN1_BUF_LEN, NGAP_TRUE))
        {
            RRC_NGAP_TRACE(NGAP_ERROR, 
                    "Failed pu_setBuffer for AMF CONFIG UPDATE  Fail");
            response = NGAP_FAILURE;
            break;
        }

        if (NGAP_ASN_OK != asn1PE_ngap_NGAP_PDU (&asn1_ctx, &ngap_pdu))
        {
            rtxErrPrint(&asn1_ctx);
            RRC_NGAP_TRACE(NGAP_ERROR, "Encoding of AMF CONFIG UPDATE Failure Failed");
            response = NGAP_FAILURE;
            break;
        }
        else
        {
            /* Print the NGAP PDU depending on Log Level */
            ngap_asn1PrtToStr_NGAP_PDU (NGAP_ASN, (SInt8 *)"NGAP_PDU", &ngap_pdu);

            *p_asn_msg_len = (UInt16)pe_GetMsgLen(&asn1_ctx);
            response = NGAP_SUCCESS;
        }

    }while(0);

    /* Free ASN1 context */
    rtFreeContext(&asn1_ctx);

    RRC_NGAP_UT_TRACE_EXIT();

    return response;
}
