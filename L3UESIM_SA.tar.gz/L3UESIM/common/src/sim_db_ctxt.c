/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * *
 * *  File Description : This file contains the send/recv functions
 * *                     to support use cases for x2sim and dusim
 * *                     .
 * *
 * ***************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include "lteTypes.h"
#include "sim_db_ctxt.h"
#include "sim_external_msg.h"
#include <stdlib.h>
#include <string.h>

int uesim_get_l2_ue_index(unsigned int imsi)
{
    unsigned char cell_index = 0;
    unsigned short ue_index = 0;

    decode_imsi(imsi , &cell_index , &ue_index);

    return (tcContext.cell_context[cell_index].ue_context[ue_index].l2_ue_context);
}

/*function to decode_imsi */
void decode_imsi( unsigned int imsi,unsigned char *cell_index,unsigned short *ue_index )
{
        *ue_index = imsi & 0xffff;
         imsi = imsi >> 24;
        *cell_index = imsi & 0xff;

}

/* Encode imsi */
bool encode_imsi(imsi_t* imsi , unsigned int cellid ,unsigned int ueid )
{
    *imsi = cellid;
    *imsi = *imsi << 24;
    *imsi = *imsi | ueid;
    return true;
}

/* function to allocate new imsi */

bool allocate_new_cell(unsigned char *cell_idx)
{
    static unsigned char start_idx = 0;
    unsigned char cell_id;

    cell_id = start_idx;

    do 
    {
        if (CELL_ACTIVE == tcContext.cell_context[cell_id].current_state)
        {
            fprintf(stderr,"CELL ALLOCATED %u \n\n", cell_id);
            *cell_idx = cell_id;
            start_idx = (++cell_id) % tcContext.num_of_cells_configured;
            return true;
        }
    }while(cell_id != start_idx);

    return false;
}

bool allocate_new_imsi(unsigned char cell_index, unsigned int* imsi,sim_activity_t* p_activity_node)
{
    bool flag = false;
    bool is_true = false;
    int ue_index_count =0;
    sim_activity_t *temp = NULL;
    sim_activity_t *head_amf = NULL;
    sim_activity_t *head_rrc = NULL;

    for(ue_index_count = 0 ; ue_index_count < MAX_SUPPORTED_UE_PER_CELL; ue_index_count++)
    {
        if(tcContext.cell_context[cell_index].ue_context[ue_index_count].inUse == false)
        {
            tcContext.cell_context[cell_index].ue_context[ue_index_count].inUse = true;
            /*PUE Changes start*/
            while(p_activity_node)
            {
                temp = (sim_activity_t*)malloc(sizeof(sim_activity_t));
                memcpy(temp, p_activity_node, sizeof(sim_activity_t));
                temp->next = NULL;
                is_true = is_amf_msg_node(temp);
                if(is_true)
                {
                    if(tcContext.cell_context[cell_index].ue_context[ue_index_count].amf_activities != NULL)
                    {
                        tcContext.cell_context[cell_index].ue_context[ue_index_count].amf_activities->next = temp;
                        tcContext.cell_context[cell_index].ue_context[ue_index_count].amf_activities = temp;
                    }
                    else
                    {

                        tcContext.cell_context[cell_index].ue_context[ue_index_count].amf_activities = temp;
                        head_amf = temp;
                    }
                } 
                else
                {
                    if(tcContext.cell_context[cell_index].ue_context[ue_index_count].activities != NULL)
                    {
                        tcContext.cell_context[cell_index].ue_context[ue_index_count].activities->next = temp;
                        tcContext.cell_context[cell_index].ue_context[ue_index_count].activities = temp;
                    }
                    else
                    {

                        tcContext.cell_context[cell_index].ue_context[ue_index_count].activities = temp;
                        head_rrc = temp;
                    }
                }
                p_activity_node = p_activity_node->next;
            }
            if (head_rrc)
            {
                tcContext.cell_context[cell_index].ue_context[ue_index_count].activities = head_rrc;
            }
            if (head_amf)
            {
                tcContext.cell_context[cell_index].ue_context[ue_index_count].amf_activities = head_amf;
            }

            /*PUE Changes end*/
            flag = true;
            break;
        }
    }
    if (true == flag)
    {

      encode_imsi(imsi , cell_index,ue_index_count);
      fprintf(stderr,"IMSI ALLOCATED 0x%x \n\n",*imsi);
    }

    return flag;
}

bool deallocate_imsi(unsigned int imsi)
{
    bool flag = true;
    unsigned char cell_index = 0;
    unsigned short ue_index  =   0;
   
    decode_imsi(imsi,&cell_index,&ue_index);  
   
    tcContext.cell_context[cell_index].ue_context[ue_index].inUse = false ;
    /*PUE Changes start*/
    tcContext.cell_context[cell_index].ue_context[ue_index].activities = NULL;
    /*PUE Changes end*/
    fprintf(stderr," UE [%d] deleted \n",ue_index);
    
   return flag;
}


/* This function deallocate imsi and return ue_context */
tc_ue_context_t*  get_ue_context(unsigned int imsi)
{
   unsigned short   ue_index    =0;
   unsigned char    cell_index  =0;

   decode_imsi(imsi,&cell_index,&ue_index);
   return &tcContext.cell_context[cell_index].ue_context[ue_index];


}

/*PUE changes start*/
bool is_amf_msg_node(sim_activity_t* p_activity_node)
{
    switch(p_activity_node->msg_id)
    {
        case NG_SETUP_REQUEST_ID:
        case NG_SETUP_RESPONSE_ID:
        case NG_SETUP_FAILURE_ID:
        case NG_ERROR_INDICATION_ID:
        case NG_SCTP_LINK_TRIGGER_ID:
        case NG_SCTP_LINK_STATUS_ID:
        case NG_INITIAL_UE_MSG_ID:
        case NG_INITIAL_CONTEXT_SETUP_REQ_ID:
        case NG_INITIAL_CONTEXT_SETUP_RESP_ID:
        case NG_INITIAL_CONTEXT_SETUP_FAIL_ID:
        case UE_RADIO_CAP_INFO_INDICATION_ID:
        case UE_CONTEXT_RELEASE_REQ_ID:
        case UE_CONTEXT_RELEASE_COMND_ID:
        case UE_CONTEXT_REL_COMPLETE_ID:
        case NG_RESET_ID:
        case NG_ACK_RESET_ID:
        case NG_DL_NAS_TRANSPORT_ID:
        case NG_UL_NAS_TRANSPORT_ID:
        case NG_DL_PCCH_PAGING_ID:
        case NG_PDU_SESSION_RESOURCE_SETUP_REQ_ID:
        case NG_PDU_SESSION_RESOURCE_SETUP_RESP_ID:
        case NG_PDU_SESSION_RESOURCE_SETUP_FAIL_ID:
        case NG_PDU_SESSION_RESOURCE_RELEASE_CMD_ID:
        case NG_PDU_SESSION_RESOURCE_RELEASE_RESP_ID:
        {
            return true;
        }
        default:
        {
            return false;
        }
    }//switch
}

unsigned short sim_get_rnti(unsigned int imsi)
{
    unsigned char cell_index = 0;
    unsigned short ue_index = 0;
    decode_imsi(imsi, &cell_index , &ue_index);
    return tcContext.cell_context[cell_index].ue_context[ue_index].rnti;
}

unsigned int uesim_generate_te_id(unsigned int imsi, unsigned int pdu_session_id)
{
    return (imsi | pdu_session_id << 16);
}


/*PUE changes end*/
