/******************************************************************************
 *
 * ARICENT - ngap_asn_common_wrapper.c
 *
 * Copyright (C) 2019 Aricent Inc . All Rights Reserved.
 *
 * File Name       : ngap_asn_common_wrapper.c
 * File Description: 
 ***************************************************************************/

#include "ngap_asn_enc_wrapper.h"
#include "ngap_asn_common_wrapper.h"
#include "ngap_tracing.h"
#include "ngap_utils.h"
#ifndef AMF_SIM_TESTING_ENABLE
#include "rrc_logging.h"
#else
#include "rrc_common_utils.h"
#endif

/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_NGAP_PDU
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                    readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_NGAP_PDU
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_NGAP_PDU   *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_NGAP_PDU(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "NGAP_PDU Info to be printed is missing");
        }
    }   

    return;
}

/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_PDUSessionResourceSetupRequestTransfer   *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "NGAP_PDUSessionResourceSetupRequestTransfer Info to be printed is missing");
        }
    }   

    return;
}

/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_PDUSessionResourceSetupResponseTransfer   *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "NGAP_PDUSessionResourceSetupResponseTransfer Info to be printed is missing");
        }
    }   

    return;
}
/*HandOver_code_changes_start*/

/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_HandoverCommandTransfer 
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_HandoverCommandTransfer 
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverCommandTransfer *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_HandoverCommandTransfer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "ngap_HandoverCommandTransfer Info to be printed is missing");
        }
    }   

    return;
}
/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer 
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer//HandOver changes
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverRequestAcknowledgeTransfer *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING, "ngap_HandoverRequestAcknowledgeTransfer Info to be printed is missing");
        }
    }   

    return;
}
/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_HandoverResourceAllocationUncessfulTransfer
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_HandoverResourceAllocationUnsuccessfulTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverResourceAllocationUnsuccessfulTransfer     *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_HandoverResourceAllocationUnsuccessfulTransfer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING,
            "HandoverResourceAllocationUncessfulTransferInfo to be printed is missing");
        }
    }   

    return;
}
/*HandOver_code_changes_end*/

/*Handover_changes_start*/

/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer 
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer 
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer  *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING,
            "ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer Info to be printed is missing");
        }
    }   

    return;
}
/******************************************************************************
 * Function Name    : ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer 
 * Inputs           : 
 * Outputs          : None
 * Returns          : None
 * DESCRIPTION      : This functions prints the encoded ASN buffer into 
 *                      readable format.
 *****************************************************************************/
void ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer  *pvalue
)
{
    SInt32  result  = NGAP_ZERO;
    SInt8   *pBuff  = NGAP_P_NULL;

    //if (ngap_get_log_level() >= log_level)
    {
        if((NGAP_P_NULL != name) && (NGAP_P_NULL != pvalue))
        {
#ifndef AMF_SIM_TESTING_ENABLE
            pBuff = rrc_mem_get(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
            pBuff = (SInt8*)malloc(NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif

            if(NGAP_P_NULL == pBuff)
            {
                NGAP_SYSTEM_MEM_FAIL();
                return;
            }

            result = asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer(

#ifndef AMF_SIM_TESTING_ENABLE
                    name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (SInt8 *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#else
                    (const char *)name, pvalue,
                    /* Converted to char* as required by ASN function */
                    (char *)pBuff,
                    NGAP_MAX_ASN1_BUF_LEN_PRINT);
#endif 

            if(NGAP_ZERO == result)
            {
                RRC_NGAP_TRACE((SInt32)log_level,"%s", pBuff);
            }
            else
            {
                RRC_NGAP_TRACE(NGAP_WARNING, "Buffer size for ASN needs to be increased");
            }

            rrc_mem_free(pBuff);
        }
        else
        {
            RRC_NGAP_TRACE(NGAP_WARNING,
            "ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer Info to be printed is missing");
        }
    }   

    return;
}
/*Handover_changes_end*/
