/******************************************************************************
*
*   FILE NAME:
*       rrc_msg_mgmt.c
*
*   DESCRIPTION:
*       This source file contains RRC messages management functions
*
*   DATE            AUTHOR      REFERENCE       REASON
*   02 Apr 2009     VasylN      ---------       Initial
*
*   Copyright (c) 2009, Aricent Inc. All Rights Reserved
*
******************************************************************************/
#include "rrc_msg_mgmt.h"
#include "rrc_common_utils.h"

/******************************************************************************
*   The format of the RRC API Header structure is following:
*           (In case of U16, HI is transmitted first)
*
*   U8  - version
*   U8  - from (HI)
*   U8  - from (LOW)
*   U8  - to (HI)
*   U8  - to (LOW)
*   U8  - api id (HI)
*   U8  - api id (LOW)
*   U8  - api size (HI)
*   U8  - api size (LOW)
*   10-16 bytes - spare
******************************************************************************/

/******************************************************************************
*   FUNCTION NAME: rrc_get_byte_from_header
*   INPUT        : U8 *p_header
*   OUTPUT       : None
*   RETURNS      : Byte
*   DESCRIPTION  : Function retreives byte from RRC header
******************************************************************************/
static U8
rrc_get_byte_from_header
(
    U8 *p_header /* RRC header */
)
{
    RRC_ASSERT(p_header != PNULL);

    return *p_header;
}

/******************************************************************************
*   FUNCTION NAME: rrc_get_word_from_header
*   INPUT        : U8 *p_header
*   OUTPUT       : None
*   RETURNS      : Word
*   DESCRIPTION  : Function retreives word from RRC header
******************************************************************************/
static U16
rrc_get_word_from_header
(
    U8 *p_header /* RRC header */
)
{
    U16 value = RRC_NULL;

    RRC_ASSERT(p_header != PNULL);

    value = (U16)(p_header[0] << 8 | p_header[1]);

    return value;
}

/******************************************************************************
*   FUNCTION NAME: rrc_get_version
*   INPUT        : void *p_header
*   OUTPUT       : None
*   RETURNS      : Header version
*   DESCRIPTION  : Function retreives version from RRC header
******************************************************************************/
U8
rrc_get_version
(
    void *p_header /* RRC header */
)
{
    RRC_ASSERT(p_header != PNULL);

    return(rrc_get_byte_from_header(&(((U8 *)p_header)[0])));
}

/******************************************************************************
*   FUNCTION NAME: rrc_get_src_module_id
*   INPUT        : void *p_header
*   OUTPUT       : None
*   RETURNS      : Source module Id
*   DESCRIPTION  : Function retreives source module Id from RRC header
******************************************************************************/
rrc_module_id_t
rrc_get_src_module_id
(
    void *p_header /* RRC header */
)
{
    RRC_ASSERT(p_header != PNULL);

    return((rrc_module_id_t)(rrc_get_word_from_header(&(((U8 *)p_header)[1]))));
}


/******************************************************************************
*   FUNCTION NAME: rrc_get_api_id
*   INPUT        : U8 *p_header
*   OUTPUT       : None
*   RETURNS      : API Id
*   DESCRIPTION  : Function retreives API Id from RRC header
******************************************************************************/
U16
rrc_get_api_id
(
    U8 *p_header /* RRC header */
)
{
    return(rrc_get_word_from_header(&(((U8 *)p_header)[5])));
}

/******************************************************************************
*   FUNCTION NAME: rrc_get_api_buf_size
*   INPUT        : U8 *p_header
*   OUTPUT       : None
*   RETURNS      : API buffer size
*   DESCRIPTION  : Function retreives API buffer size from RRC header
******************************************************************************/
U16
rrc_get_api_buf_size
(
    U8 *p_header /* RRC header */
)
{
    return(rrc_get_word_from_header(&(((U8 *)p_header)[7])));
}

/******************************************************************************
*   FUNCTION NAME: rrc_set_api_buf_size
*   INPUT        : U8 *p_header
*                  U16     api_buf_size
*   OUTPUT       : None
*   RETURNS      : API buffer size
*   DESCRIPTION  : Function set API buffer size in RRC header
******************************************************************************/
void rrc_set_api_buf_size
(
    U8      *p_header,      /* RRC header */
    U16     api_buf_size    /* API message size */
)
{
    /* api size (HI) */
    p_header[7] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[8] = (U8)(api_buf_size & 0x00FF);
}

/******************************************************************************
*   FUNCTION NAME: rrc_construct_api_header
*   INPUT        : U8 *p_header
*                  U8                  version_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs RRC header from given parameters
******************************************************************************/
void
rrc_construct_api_header
(
    U8                  *p_header,      /* RRC header */
    U8                  version_id,     /* API version Id */
    rrc_module_id_t     src_module_id,  /* Source module Id */
    rrc_module_id_t     dst_module_id,  /* Destination module Id */
    U16                 api_id,         /* API Id */
    U16                 api_buf_size    /* API buffer size */
)
{
    /* version */
    p_header[0] = version_id;

    /* from (HI) */
    p_header[1] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[2] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[3] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[4] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[5] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[6] = (U8)(api_id & 0x00FF);

    /* api size (HI) */
    p_header[7] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[8] = (U8)(api_buf_size & 0x00FF);

    /* spare bytes */
    p_header[9]     = 0x00;
    p_header[10]    = 0x00;
    p_header[11]    = 0x00;
    p_header[12]    = 0x00;
    p_header[13]    = 0x00;
    p_header[14]    = 0x00;
    p_header[15]    = 0x00;
}

/******************************************************************************
*   FUNCTION NAME: rrc_get_transaction_id
*   INPUT        : void *p_api
*   OUTPUT       : None
*   RETURNS      : API buffer size
*   DESCRIPTION  : Function retreives transaction_id from external API message
******************************************************************************/
U16
rrc_get_transaction_id
(
    void *p_api /* external API message */
)
{
    return(rrc_get_word_from_header((U8 *)p_api + RRC_API_HEADER_SIZE));
}

/******************************************************************************
*   FUNCTION NAME: rrc_construct_interface_api_header
*   INPUT        : U8                  *p_header
*                  U16                 transaction_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs interface api header from given parameters
******************************************************************************/
void
rrc_construct_interface_api_header
(
    U8                  *p_header,      /* RRC interface header */
    U16                 transaction_id, /* Interface transaction identifier */
    rrc_module_id_t     src_module_id,  /* Source module identifier */
    rrc_module_id_t     dst_module_id,  /* Destination module identifier */
    U16                 api_id,         /* API identifier */
    U16                 api_buf_size,   /* API buffer size */
    U8                  cell_index      /* cell index */
)
{
    /* transaction identifier (HI) */
    p_header[0] = (U8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (U8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[7] = (U8)(api_id & 0x00FF);

    /*size includes length of header*/
    api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE);

    /* api size (HI) */
    p_header[8] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (U8)(api_buf_size & 0x00FF);


    /* spare bytes */
    p_header[10] = (U8)((cell_index & 0xFF00) >> 8);
    p_header[11] = (U8)(cell_index & 0x00FF);
    p_header[12] = 0x00;
    p_header[13] = 0x00;
    p_header[14] = 0x00;
    /* cell index */
    p_header[15] = 0x00;

}


/******************************************************************************
*   FUNCTION NAME: rrc_construct_interface_api_header_two_cell_index
*   INPUT        : U8                  *p_header
*                  U16                 transaction_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs interface api header from given parameters
******************************************************************************/
void
rrc_construct_interface_api_header_two_cell_index
(
    U8                  *p_header,      /* RRC interface header */
    U16                 transaction_id, /* Interface transaction identifier */
    rrc_module_id_t     src_module_id,  /* Source module identifier */
    rrc_module_id_t     dst_module_id,  /* Destination module identifier */
    U16                 api_id,         /* API identifier */
    U16                 api_buf_size,   /* API buffer size */
    U8                  cell_index_1,      /* cell index 1 */
    U8                  cell_index_2      /* cell index 2 */
)
{
    /* transaction identifier (HI) */
    p_header[0] = (U8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (U8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[7] = (U8)(api_id & 0x00FF);

    /*size includes length of header*/
    api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE);

    /* api size (HI) */
    p_header[8] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (U8)(api_buf_size & 0x00FF);


    /* spare bytes */
    p_header[10] = 0x00;
    p_header[11] = 0x00;
    p_header[12] = 0x00;
    p_header[13] = 0x00;
    p_header[14] = (U8) (cell_index_1);
    /* cell index */
    p_header[15] = (U8) (cell_index_2);

}

/******************************************************************************
*   FUNCTION NAME: rrc_construct_oam_interface_api_header
*   INPUT        : U8                  *p_header
*                  U16                 transaction_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs interface api header from given parameters
******************************************************************************/
void
rrc_construct_oam_interface_api_header
(
    U8                  *p_header,      /* RRC interface header */
    U16                 transaction_id, /* Interface transaction identifier */
    rrc_module_id_t     src_module_id,  /* Source module identifier */
    rrc_module_id_t     dst_module_id,  /* Destination module identifier */
    U16                 api_id,         /* API identifier */
    U16                 api_buf_size    /* API buffer size */
)
{
    /* transaction identifier (HI) */
    p_header[0] = (U8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (U8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[7] = (U8)(api_id & 0x00FF);

    /*size includes length of header*/
    api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE);

    /* api size (HI) */
    p_header[8] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (U8)(api_buf_size & 0x00FF);

    /* spare bytes */
    p_header[10] = 0x00;
    p_header[11] = 0x00;
    p_header[12] = 0x00;
    p_header[13] = 0x00;
    p_header[14] = 0x00;
    p_header[15] = 0x00;

}


/******************************************************************************
*   FUNCTION NAME: rrc_construct_interface_api_header_2
*   INPUT        : U8                  *p_header
*                  U16                 transaction_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs interface api header from given parameters
******************************************************************************/
void
rrc_construct_interface_api_header_2
(
    U8                  *p_header,      /* RRC interface header */
    U16                 transaction_id, /* Interface transaction identifier */
    rrc_module_id_t     src_module_id,  /* Source module identifier */
    rrc_module_id_t     dst_module_id,  /* Destination module identifier */
    U16                 api_id,         /* API identifier */
    U16                 api_buf_size   /* API buffer size */
)
{
    /* transaction identifier (HI) */
    p_header[0] = (U8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (U8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[7] = (U8)(api_id & 0x00FF);

    /*size includes length of header*/
    //api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE);
    api_buf_size = (U16)(api_buf_size + RRC_API_INTERFACE_HEADER_CELL_INDEX);

    /* api size (HI) */
    p_header[8] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (U8)(api_buf_size & 0x00FF);


}
/******************************************************************************
*   FUNCTION NAME: rrc_construct_interface_api_header_3
*   INPUT        : U8                  *p_header
*                  U16                 transaction_id
*                  rrc_module_id_t     src_module_id
*                  rrc_module_id_t     dst_module_id
*                  U16                 api_id
*                  U16                 api_buf_size
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : Function constructs interface api header from given parameters
******************************************************************************/
void
rrc_construct_interface_api_header_3
(
    U8                  *p_header,      /* RRC interface header */
    U16                 transaction_id, /* Interface transaction identifier */
    rrc_module_id_t     src_module_id,  /* Source module identifier */
    rrc_module_id_t     dst_module_id,  /* Destination module identifier */
    U16                 api_id,         /* API identifier */
    U16                 api_buf_size,   /* API buffer size */
    U8                  cell_index     /* cell index */
)
{
    /* transaction identifier (HI) */
    p_header[0] = (U8)((transaction_id & 0xFF00) >> 8);

    /* transaction identifier (LOW) */
    p_header[1] = (U8)(transaction_id & 0x00FF);

    /* from (HI) */
    p_header[2] = (U8)((src_module_id & 0xFF00) >> 8);

    /* from (LOW) */
    p_header[3] = (U8)(src_module_id & 0x00FF);

    /* to (HI) */
    p_header[4] = (U8)((dst_module_id & 0xFF00) >> 8);

    /* to (LOW) */
    p_header[5] = (U8)(dst_module_id & 0x00FF);

    /* api id (HI) */
    p_header[6] = (U8)((api_id & 0xFF00) >> 8);

    /* api id (LOW) */
    p_header[7] = (U8)(api_id & 0x00FF);

    /*size includes length of header*/
    //api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE);
    api_buf_size = (U16)(api_buf_size + RRC_INTERFACE_API_HEADER_SIZE_2);

    /* api size (HI) */
    p_header[8] = (U8)((api_buf_size & 0xFF00) >> 8);

    /* api size (LOW) */
    p_header[9] = (U8)(api_buf_size & 0x00FF);

    /* api size (LOW) */
    p_header[10] = (U8)(cell_index);

}


/******************************************************************************
*   FUNCTION NAME: rrc_mem_get
*   INPUT        : rrc_size_t size
*   OUTPUT       : None
*   RETURNS      : Pointer to memory buffer or NULL in case of failure
*   DESCRIPTION  : This function returns memory buffer from memory pool.
*                  Function is used for general memory management purposes.
*
******************************************************************************/
void*
rrc_mem_get
(
    rrc_size_t size /* Size of buffer which will be allocated */
)
{
    void *p_buf = PNULL;
    p_buf = malloc(size);
    return p_buf;
}

/******************************************************************************
*   FUNCTION NAME: rrc_mem_free
*   INPUT        : void *p_buffer
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : This function frees memory buffer allocated in pool.
*                  Function is used for general memory management purposes.
******************************************************************************/
void
rrc_mem_free
(
    void *p_buffer /* Pointer to buffer which will be freed */
)
{
    free (p_buffer);
    p_buffer = NULL;
}

/******************************************************************************
*   FUNCTION NAME: rrc_msg_mem_get
*   INPUT        : rrc_size_t size
*   OUTPUT       : None
*   RETURNS      : Pointer to memory buffer or NULL in case of failure
*   DESCRIPTION  : This function returns memory buffer from memory pool.
*                  Function is used for messages management purposes.
******************************************************************************/
void*
rrc_msg_mem_get
(
    rrc_size_t size /* Size of buffer which will be allocated */
)
{
    void *p_buf = PNULL;
    return(p_buf);
}

/******************************************************************************
*   FUNCTION NAME: rrc_msg_mem_free
*   INPUT        : void *p_buffer
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : This function frees memory buffer allocated in pool.
*                  Function is used for messages management purposes.
******************************************************************************/
void
rrc_msg_mem_free
(
    void *p_buffer /* Pointer to buffer which will be freed */
)
{
}

/*****************************************************************************
 * Function Name  : memset_wrapper
 * Inputs         : 
 * Outputs        : 
 * Returns        : 
 * Description    : Wrapper function of memset
 ********************************************************************************/
void* memset_wrapper(void *s, S32 c, size_t n)
{
    return(void*)memset((void *)s, (int) c, (size_t) n);
}

/*****************************************************************************
 * Function Name  : l3_memcpy_wrapper
 * Inputs         : 
 * Outputs        : 
 * Returns        : 
 * Description    : Wrapper function of memcpy
 ********************************************************************************/
void* l3_memcpy_wrapper(void *dest, const void *src, size_t n)
{
    return(void *)memcpy((void *)dest, (const void *)src, (size_t)n);
}

/*****************************************************************************
 * Function Name  : memcmp_wrapper
 * Inputs         : 
 * Outputs        : 
 * Returns        : 
 * Description    : Wrapper function of memcmp
 ********************************************************************************/
S32 memcmp_wrapper(const void *s1, const void *s2, size_t n)
{
    return(S32) memcmp((const void *)s1, (const void *)s2, (size_t)n);
}


/******************************************************************************
*   FUNCTION NAME: rrc_send_message
*   INPUT        : void            *p_msg
*                  rrc_module_id_t dst_module
*   OUTPUT       : None
*   RETURNS      : None
*   DESCRIPTION  : This function is called by stack to Send a message to some external
*                  module.
*
******************************************************************************/
void
/*SPR 20172 Fix Start*/
rrc_send_message_ex
/*SPR 20172 Fix End*/
(
    void            *p_msg,     /* Message that will be passed */
    rrc_module_id_t dst_module  /* Module id for which message will be passed */
)
{
}


void set_cell_index(U8 cell_index)
{
}

