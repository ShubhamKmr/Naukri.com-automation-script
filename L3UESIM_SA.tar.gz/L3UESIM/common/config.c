
/* Fetch value of a particular node */
xmlChar* get_node_value(xmlDoc *doc, xmlNode* node) 
{
    xmlChar* key = NULL;

    key = xmlNodeListGetString(doc, node, 1);

    return key;
}


/* Fetch root element of doc */
xmlNode* get_root_element(xmlDoc* doc)
{
    xmlNode* root_element = NULL;

    root_element = xmlDocGetRootElement(doc);

    return root_element;
}


/* Read configuration file */
xmlDoc* read_file(const char* config_file)
{
    xmlDoc* doc = NULL;

    doc = xmlReadFile(config_file, NULL, 0);

    return doc;
}


sim_return_val_et populate_data(
       xmlDoc*  doc, 
       xmlNode* root_node) 
{
    xmlNode* cur_node = NULL;
    xmlChar* key      = NULL;

    for (cur_node = root_node; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, (const xmlChar *)"ip")))
            {
                key = get_param(doc, cur_node->xmlChildrenNode);
                printf("%s\n", key);

                /* TODO: Can add IPv4 address validation */

                strncpy((char*)ip_addr, (char*)key, MAX_IP_ADDRESS_LENGTH);
                xmlFree(key);
            }

            if ((!xmlStrcmp(cur_node->name, (const xmlChar *)"port")))
            {
                key = get_param(doc, cur_node->xmlChildrenNode);
                printf("%s\n", key);

                int port = atoi((char*)key);
                xmlFree(key);
            }

            if ((!xmlStrcmp(cur_node->name, (const xmlChar *)"protocol")))
            {
                key = get_param(doc, cur_node->xmlChildrenNode);
                printf("%s\n", key);

                unsigned short protoType = atoi((char*)key);
                xmlFree(key);
            }
        }

        populate_data(doc, cur_node->children);
    }
}


/* Read configuration specific to simulator configuration */
sim_return_val_et read_configuration()
{
    xmlDoc*  doc           = NULL;
    xmlNode* root_element  = NULL;
    char*    config_file[] = "sim_config.xml";

    /* Read XML configuration file */
    doc = read_file(config_file);
    if (NULL == doc)
    {
        LOG_TRACE("Failed to read XML doc\n");
        return;
    }

    /* Fetch root element of the XML doc */
    root_element = get_root_element(doc);
    if (NULL == root_element)
    {
        printf("XML document is empty\n");
    }

    /* Populate simulators configuration */
    populate_data(doc, root_element);

    xmlFreeDoc(doc);
    xmlCleanupParser();
}

