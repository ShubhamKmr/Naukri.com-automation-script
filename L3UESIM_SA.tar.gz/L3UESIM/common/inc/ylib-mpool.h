/****************************************************************************/
/**  Copyright (C) 2006 Aricent Inc . All Rights Reserved */
/****************************************************************************/
/**                                                                        **/
/** Common Stack Porting Library - Interface Definition                    **/
/**                                                                        **/
/****************************************************************************/

#ifndef _YLIB_MPOOL_H_
#define _YLIB_MPOOL_H_

#include "ylib.h" 
#include "cspl.h"

typedef    struct    qmpool {
    unsigned long    magic;
    unsigned int     size, nbuf, alloc;
    YLIST            chunks;
    YLIST            list;
    QLOCK            lock;
#ifdef MEM_DEBUG
        unsigned long   ref_ctr;
#endif
} qmpool;

typedef    struct    qmbuf {
    union {
        YLNODE    __header__;
        qmpool    *pool;
    } u;

    unsigned short    incarnation;
    unsigned char     allocated;
#ifdef MEM_DEBUG
        unsigned long ref_id;
#endif
} qmbuf;

typedef    struct    qmchunk {
    YLNODE          __header__;
    unsigned int    nbuf;
} qmchunk;

/** Memory Pool Management **************************************************/
QMPOOL         qvMpoolCreate( unsigned int size, unsigned int nbuf );
QMPOOL         qvMpoolCreateEx( unsigned int size, unsigned int nbuf, int *cErr);
void           qvMpoolDelete( QMPOOL Q );
int            qvMpoolExtend( QMPOOL Q, unsigned int nbuf );
int            qvMpoolExtendEx( QMPOOL Q, unsigned int nbuf, int *cErr);
unsigned int   qvMpoolSize( QMPOOL Q, unsigned int *p_alloc );
void           *qvMpoolAlloc(QMPOOL pool);
void           *qvMpoolAllocEx(QMPOOL pool, int *cErr);
void           qvMpoolFree(void *buffer);
unsigned short qvMpoolSequence( void *buffer );
unsigned int   qvMpoolIndex( QMPOOL Q, void *buffer);
unsigned int   qvMpoolIndexEx( QMPOOL Q, void *buffer, int *cErr);
void           *qvMpoolLocate( QMPOOL Q, unsigned int indexparam);
void           *qvMpoolLocateEx( QMPOOL Q, unsigned int indexparam, int *cErr);
void           *qvMpoolAllocSpecific( QMPOOL Q, unsigned int indexparam, unsigned short sequence );
void           *qvMpoolAllocSpecificEx( QMPOOL Q, unsigned int indexparam, unsigned short sequence, int *cErr);

#endif

