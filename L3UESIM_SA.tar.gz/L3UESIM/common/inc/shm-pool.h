/**************************************************************************
 *
 * ARICENT -
 *
 * Copyright (C) 2012 Aricent Inc. All Rights Reserved.
 *
 *************************************************************************
 *
 * File Name shm-pool.h
 *
 *************************************************************************
 *
 * File Description : This file contains the functions and structure 
 *                    that are used for shared message pool
 *
 *************************************************************************/

/******************************************************************/
#ifndef _SHM_POOL_H_
#define _SHM_POOL_H_

/******************************************************************/

#include <stdint.h>

intptr_t qvGetRelativeAddr(void *shmAddr, void *buffer);

void *qvGetPointer(void *shmAddr, intptr_t offset);

int qvShmPoolGetSize(unsigned int bufSize, unsigned int nbuf);

int qvShmCreatePool(void *shmAddr, unsigned int shmSize, unsigned int poolOffset, unsigned int size, unsigned int nbuf);

void * qvShmPoolAlloc(void *shmAddr, void *allocPool);

void qvShmPoolFree(void *shmAddr, void *buffer);

#endif /* _SHM_POOL_H_ */
