/******************************************************************************
*
*   FILE NAME:
*       l3_pdcp_intf.h
*
*   DESCRIPTION:
*       This file contains types used for representation of PDCP API inside L3.
*       This file is alligned with PDCP API document v1.7
*
*   DATE            AUTHOR      REFERENCE       REASON
*   07 Mar 2018     Rajesh      ---------       Initial
*
*   Copyright (c) 2018, Aricent Inc. All Rights Reserved
*
******************************************************************************/

#ifndef _L3_PDCP_INTF_H_
#define _L3_PDCP_INTF_H_

#include "gnb_defines.h"

/******************************************************************************
*   PDCP API Internal Representation
******************************************************************************/
/********************************************************************
 * L3 - PDCP APIs
 *******************************************************************/
#define RRC_PDCP_API_BASE                     0x0000

#define RRC_PDCP_CREATE_UE_ENTITY_REQ         (RRC_PDCP_API_BASE + 0)
#define PDCP_RRC_CREATE_UE_ENTITY_CNF         (RRC_PDCP_API_BASE + 1)
#define RRC_PDCP_DELETE_UE_ENTITY_REQ         (RRC_PDCP_API_BASE + 2)
#define PDCP_RRC_DELETE_UE_ENTITY_CNF         (RRC_PDCP_API_BASE + 3)
#define RRC_PDCP_RECONFIG_UE_ENTITY_REQ       (RRC_PDCP_API_BASE + 4)
#define PDCP_RRC_RECONFIG_UE_ENTITY_CNF       (RRC_PDCP_API_BASE + 5)
#define RRC_PDCP_SRB_DL_DATA_REQ              (RRC_PDCP_API_BASE + 6)
#define PDCP_RRC_SRB_DL_DATA_RESP             (RRC_PDCP_API_BASE + 7)
#define RRC_PDCP_SRB_UL_DATA_REQ              (RRC_PDCP_API_BASE + 8)
#define PDCP_RRC_SRB_UL_DATA_RESP             (RRC_PDCP_API_BASE + 9)
#define RRC_PDCP_SN_HFN_STATUS_REQ            (RRC_PDCP_API_BASE + 10)
#define PDCP_RRC_SN_HFN_STATUS_RESP           (RRC_PDCP_API_BASE + 11)
#define RRC_PDCP_SN_HFN_STATUS_IND            (RRC_PDCP_API_BASE + 12)
#define RRC_PDCP_DATA_BUFFER_STOP_IND         (RRC_PDCP_API_BASE + 13) 
#define RRC_PDCP_MAC_I_REQ                    (RRC_PDCP_API_BASE + 14)
#define PDCP_RRC_MAC_I_RESP                   (RRC_PDCP_API_BASE + 15)
#define RRC_PDCP_RE_ESTABLISH_UE_ENTITY_REQ   (RRC_PDCP_API_BASE + 16)
#define PDCP_RRC_RE_ESTABLISH_UE_ENTITY_CNF   (RRC_PDCP_API_BASE + 17)
#define RRC_PDCP_SUSPEND_UE_ENTITY_REQ        (RRC_PDCP_API_BASE + 18)
#define PDCP_RRC_SUSPEND_UE_ENTITY_CNF        (RRC_PDCP_API_BASE + 19)
#define RRC_PDCP_RESUME_UE_ENTITY_REQ         (RRC_PDCP_API_BASE + 20)
#define PDCP_RRC_RESUME_UE_ENTITY_CNF         (RRC_PDCP_API_BASE + 21)
#define RRC_PDCP_CHANGE_CRNTI_REQ             (RRC_PDCP_API_BASE + 22)
#define PDCP_RRC_CHANGE_CRNTI_CNF             (RRC_PDCP_API_BASE + 23)
#define PDCP_RRC_COUNT_WRAPAROUND_IND         (RRC_PDCP_API_BASE + 24)
#define PDCP_RRC_NOTIFY_INTEGRITY_FAILURE     (RRC_PDCP_API_BASE + 25)
#define RRC_PDCP_DRB_COUNT_MSB_REQ            (RRC_PDCP_API_BASE + 26)
#define PDCP_RRC_DRB_COUNT_MSB_RESP           (RRC_PDCP_API_BASE + 27)
#define RRC_PDCP_CELL_CONFIG_REQ              (RRC_PDCP_API_BASE + 28)
#define PDCP_RRC_CELL_CONFIG_RESP             (RRC_PDCP_API_BASE + 29)
#define RRC_PDCP_HO_PREP_INFO_REQ             (RRC_PDCP_API_BASE + 30)
#define PDCP_RRC_HO_PREP_INFO_RESP            (RRC_PDCP_API_BASE + 31)
#define PDCP_RRC_INACTIVE_UES_IND             (RRC_PDCP_API_BASE + 32)
/*Traffic Inactivity Timer Support changes Start*/
#define PDCP_RRC_TRAFFIC_INACTIVITY_IND       (RRC_PDCP_API_BASE + 33)
/*Traffic Inactivity Timer Support changes End*/
#define RRC_PDCP_PURGE_CELL_UES_REQ           (RRC_PDCP_API_BASE + 34)
#define PDCP_RRC_PURGE_CELL_UES_RESP          (RRC_PDCP_API_BASE + 35)
#define RRC_PDCP_CELL_DELETE_REQ              (RRC_PDCP_API_BASE + 36)
#define PDCP_RRC_CELL_DELETE_RESP             (RRC_PDCP_API_BASE + 37)
#define RRC_PDCP_DATA_VOLUME_REPORT_REQ       (RRC_PDCP_API_BASE + 38)
#define PDCP_RRC_DATA_VOLUME_REPORT_RESP      (RRC_PDCP_API_BASE + 39)
#define RRC_PDCP_CHANGE_CELL_REQ	          (RRC_PDCP_API_BASE + 40)
#define PDCP_RRC_CHANGE_CELL_RESP	          (RRC_PDCP_API_BASE + 41)
#define RRC_PDCP_MAX_API                      PDCP_RRC_CHANGE_CELL_RESP 


/*LC-DRB MAP changes start*/
/* This message is only required at UESIM (between L3SIM and PDCP-Adapter) */
#define RRC_ADAPTER_API_BASE                  RRC_PDCP_API_BASE + 500
#define RRC_PDCP_DRBID_LCID_MAP_IND           (RRC_ADAPTER_API_BASE + 0)
#define RRC_ADAPTER_MAX_API                    RRC_PDCP_DRBID_LCID_MAP_IND
/*LC-DRB MAP changes end*/

/******************************************************************************
 * L3 - PDCP TAGs
 *****************************************************************************/
#define RRC_PDCP_TAG_BASE                           0

#define RRC_PDCP_CREATE_SRB_ENTITY_TAG                     (RRC_PDCP_TAG_BASE + 0)
#define RRC_PDCP_CONFIGURE_SRB_INTEGRITY_PROTECTION_TAG    (RRC_PDCP_TAG_BASE + 1)
#define RRC_PDCP_CONFIGURE_DRB_INTEGRITY_PROTECTION_TAG    (RRC_PDCP_TAG_BASE + 2)
#define RRC_PDCP_CONFIGURE_SRB_CIPHERING_TAG               (RRC_PDCP_TAG_BASE + 3)
#define RRC_PDCP_CONFIGURE_DRB_CIPHERING_TAG               (RRC_PDCP_TAG_BASE + 4)
#define RRC_PDCP_CREATE_DRB_ENTITY_TAG                     (RRC_PDCP_TAG_BASE + 5)
#define RRC_PDCP_CONFIGURE_REORDERING_TIMER_TAG            (RRC_PDCP_TAG_BASE + 6)
#define RRC_PDCP_CONFIGURE_ROHC_TAG                        (RRC_PDCP_TAG_BASE + 7)
#define RRC_PDCP_CONFIGURE_DISCARD_TIMER_TAG               (RRC_PDCP_TAG_BASE + 8)
#define RRC_PDCP_CONFIGURE_STATUS_REPORT_REQUIRED_TAG      (RRC_PDCP_TAG_BASE + 9)
#define RRC_PDCP_HO_TRIGGERED_TAG                          (RRC_PDCP_TAG_BASE + 10)
#define RRC_PDCP_CREATE_SRB_ENTITY_ERROR_TAG               (RRC_PDCP_TAG_BASE + 11)
#define RRC_PDCP_CREATE_DRB_ENTITY_ERROR_TAG               (RRC_PDCP_TAG_BASE + 12)
#define RRC_PDCP_DELETE_SRB_ENTITY_TAG                     (RRC_PDCP_TAG_BASE + 13)
#define RRC_PDCP_DELETE_DRB_ENTITY_TAG                     (RRC_PDCP_TAG_BASE + 14)
#define RRC_PDCP_RECONFIG_DRB_ENTITY_TAG                   (RRC_PDCP_TAG_BASE + 15)
#define RRC_PDCP_DELETE_SRB_ENTITY_ERROR_TAG               (RRC_PDCP_TAG_BASE + 16)
#define RRC_PDCP_DELETE_DRB_ENTITY_ERROR_TAG               (RRC_PDCP_TAG_BASE + 17)
#define RRC_PDCP_RECONFIG_DRB_ENTITY_ERROR_TAG             (RRC_PDCP_TAG_BASE + 18)
#define RRC_PDCP_LC_SN_HFN_STATUS_TAG                      (RRC_PDCP_TAG_BASE + 19)
#define RRC_PDCP_UL_RECV_SN_TAG                            (RRC_PDCP_TAG_BASE + 20)
#define RRC_PDCP_MESSAGE_TAG                               (RRC_PDCP_TAG_BASE + 21)
#define RRC_PDCP_COUNT_WRAPAROUND_THRESHOLD_TAG            (RRC_PDCP_TAG_BASE + 22)
#define RRC_PDCP_RB_ENTITY_TAG                             (RRC_PDCP_TAG_BASE + 23)
#define RRC_PDCP_SRB_ENTITY_ERROR_TAG                      (RRC_PDCP_TAG_BASE + 24)
#define RRC_PDCP_DRB_ENTITY_ERROR_TAG                      (RRC_PDCP_TAG_BASE + 25)
#define RRC_PDCP_MSG_AUTHENTICATION_CODE_TAG               (RRC_PDCP_TAG_BASE + 26)
#define RRC_PDCP_DRB_COUNT_MSB_INFO_TAG                    (RRC_PDCP_TAG_BASE + 27)
#define RRC_PDCP_DRB_COUNT_MSB_UPLINK_TAG                  (RRC_PDCP_TAG_BASE + 28)
#define RRC_PDCP_DRB_COUNT_MSB_DOWNLINK_TAG                (RRC_PDCP_TAG_BASE + 29)
#define RRC_PDCP_LOSSY_HO_REQUIRED_TAG                     (RRC_PDCP_TAG_BASE + 30)
#define RRC_PDCP_MACI_REQ_TAG                              (RRC_PDCP_TAG_BASE + 31)
#define RRC_PDCP_MACI_RESP_TAG                             (RRC_PDCP_TAG_BASE + 32)
#define RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_TAG            (RRC_PDCP_TAG_BASE + 33)
#define RRC_PDCP_UE_INACTIVE_TIME_LAPSED_TAG               (RRC_PDCP_TAG_BASE + 34)
#define RRC_PDCP_UE_INACTIVE_TIME_REQ_TAG                  (RRC_PDCP_TAG_BASE + 35)
#define RRC_PDCP_UE_INACTIVE_TIME_RESP_TAG                 (RRC_PDCP_TAG_BASE + 36)
#define RRC_PDCP_INACTIVE_UE_INFO_TAG                      (RRC_PDCP_TAG_BASE + 37)
#define RRC_PDCP_MACI_HO_REQ_TAG                           (RRC_PDCP_TAG_BASE + 38)
#define RRC_PDCP_CONFIGURE_DC_BEARER_TYPE_TAG              (RRC_PDCP_TAG_BASE + 39)
#define RRC_PDCP_SCG_DATA_SPLIT_THRESHOLD_TAG              (RRC_PDCP_TAG_BASE + 40)
#define RRC_PDCP_UE_INFO_DRB_COUNT_REQ_TAG                 (RRC_PDCP_TAG_BASE + 41)
#define RRC_PDCP_UE_INFO_DRB_COUNT_RESP_TAG                (RRC_PDCP_TAG_BASE + 42)
#define RRC_PDCP_DELETE_UE_INFO_TAG                        (RRC_PDCP_TAG_BASE + 43)
#define RRC_PDCP_REQUESTED_MCG_BEARER_INFO_TAG             (RRC_PDCP_TAG_BASE + 44)
#define RRC_PDCP_CONFIGURE_DUPLICATION_TAG                 (RRC_PDCP_TAG_BASE + 45)
#define RRC_PDCP_CONFIGURE_PRIMARY_PATH_TAG                (RRC_PDCP_TAG_BASE + 46)
#define RRC_PDCP_DATA_VOLUME_REPORT_REQ_TAG                (RRC_PDCP_TAG_BASE + 47)
#define RRC_PDCP_DATA_VOLUME_REPORT_RESP_TAG               (RRC_PDCP_TAG_BASE + 48)
#define RRC_PDCP_FULL_CONFIG_TAG                           (RRC_PDCP_TAG_BASE + 49)
/*Traffic Inactivity Timer Support changes Start*/
#define RRC_PDCP_TRAFFIC_INACTIVITY_TIMER_TAG              (RRC_PDCP_TAG_BASE + 50)
/*Traffic Inactivity Timer Support changes End*/
#define RRC_PDCP_LONG_PDCP_SN_TAG                          (RRC_PDCP_TAG_BASE + 51)
#define RRC_PDCP_SDAP_CONFIG_TAG                           (RRC_PDCP_TAG_BASE + 52)
#define RRC_PDCP_MAX_TAG                                   RRC_PDCP_SDAP_CONFIG_TAG

typedef UInt16 rrc_response_t;
typedef UInt16 rrc_rnti_t;
typedef UInt16 rrc_rb_direction_t;

/* Enum values for PDCP RLC mode */
typedef enum
{
    PDCP_RLC_MODE_UM = 0,
    PDCP_RLC_MODE_AM
} rrc_pdcp_rlc_mode_et;

typedef enum {
    Infinity  = 0,
    MS10      = 10,
    MS20      = 20,
    MS30      = 30,
    MS40      = 40,
    MS50      = 50,
    MS60      = 60,
    MS75      = 75,
    MS100     = 100,
    MS150     = 150,
    MS200     = 200,
    MS250     = 250,
    MS300     = 300,
    MS500     = 500,
    MS750     = 750,
    MS1500    = 1500
} rrc_pdcp_discard_timer_values_et;

/* Enum values for PDCP discard timer */
#define RRC_PDCP_DISC_TIMER_MS_50       0
#define RRC_PDCP_DISC_TIMER_MS_100      1
#define RRC_PDCP_DISC_TIMER_MS_150      2
#define RRC_PDCP_DISC_TIMER_MS_300      3
#define RRC_PDCP_DISC_TIMER_MS_500      4
#define RRC_PDCP_DISC_TIMER_MS_750      5
#define RRC_PDCP_DISC_TIMER_MS_1500     6
#define RRC_PDCP_DISC_TIMER_MS_INFINITY 7

typedef enum {
    roms     = 0, 
    roms1    = 1, 
    roms2    = 2, 
    roms4    = 4, 
    roms5    = 5, 
    roms8    = 8, 
    roms10   = 10, 
    roms15   = 15, 
    roms20   = 20, 
    roms30   = 30, 
    roms40   = 40, 
    roms50   = 50, 
    roms60   = 60, 
    roms80   = 80, 
    roms100  = 100, 
    roms120  = 120, 
    roms140  = 140, 
    roms160  = 160, 
    roms180  = 180, 
    roms200  = 200, 
    roms220  = 220, 
    roms240  = 240, 
    roms260  = 260, 
    roms280  = 280, 
    roms300  = 300, 
    roms500  = 500, 
    roms750  = 750, 
    roms1000 = 1000, 
    roms1250 = 1250, 
    roms1500 = 1500, 
    roms1750 = 1750, 
    roms2000 = 2000, 
    roms2250 = 2250, 
    roms2500 = 2500, 
    roms2750 = 2750, 
    roms3000 = 3000
} rrc_pdcp_reorder_timer_values_et;

/* Values for data split threshold */
typedef enum {
    b0      = 0, 
    b100    = 100,
    b200    = 200,
    b400    = 400, 
    b800    = 800, 
    b1600   = 1600, 
    b3200   = 3200, 
    b6400   = 6400, 
    b12800  = 12800, 
    b25600  = 25600, 
    b51200  = 51200, 
    b102400 = 102400, 
    b204800 = 204800, 
    b409600 = 409600,
    b819200 = 819200,
    b1228800 = 1228800, 
    b1638400 = 1638400, 
    b2457600 = 2457600, 
    b3276800 = 3276800, 
    b4096000 = 4096000, 
    b4915200 = 4915200, 
    b5734400 = 5734400, 
    b6553600 = 6553600,
    binfinity = 0xFFFFFFFF
} rrc_pdcp_data_split_threshold_et;

/* Enum values for PDCP SN size */
#define RRC_PDCP_DL_SN_SIZE_12 12
#define RRC_PDCP_DL_SN_SIZE_18 18
#define RRC_PDCP_UL_SN_SIZE_12 12
#define RRC_PDCP_UL_SN_SIZE_18 18

/* Maximum size of SN, will be with 18 bits SN*/
#define MAX_DL_SN 262143
#define MAX_UL_SN 262143
/* Maximum size of HFN, will be with 12 bits SN, HFN will be 20 bits*/
#define MAX_DL_HFN 1048575
#define MAX_UL_HFN 1048575

#define RRC_MAX_INACTIVE_UES            10
#define RRC_PDCP_SECURITY_KEY_SIZE      16
#define MAX_NUM_COUNTER_CHECK_UE        75

/*NGAP_BASED_HO_START*/
#define MAX_NR_CELL_IDENTITY_OCTETS     5
/*NGAP_BASED_HO_STOP*/

typedef enum
{
    PDCP_FAILURE=0,
    PDCP_SUCCESS,
    PDCP_PARTIAL_SUCCESS
} rrc_pdcp_return_et;

/******************************************************************************
*   RRC_PDCP_CREATE_UE_ENTITY_REQ
******************************************************************************/
typedef struct _rrc_pdcp_config_reorder_timer_t
{
    UInt8  setup_config; /*^ M, 0, H, 0, 1 ^*/
    UInt16 reordering_timer; /*^ M, 0, N, 0, 0 ^*/ /* rrc_pdcp_reorder_timer_values_et */
} rrc_pdcp_config_reorder_timer_t;

#define RRC_PDCP_CONFIG_REORDERING_TIMER_PRESENT 0x01
typedef struct _rrc_pdcp_cr_srb_entity_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    drb_id_t                 srb_id; /*^ M, 0, B, 1, MAX_SRB ^*/
    
    rrc_pdcp_config_reorder_timer_t          config_reordering_timer;
    /*^ TLV, RRC_PDCP_CONFIGURE_REORDERING_TIMER_TAG, RRC_PDCP_CONFIG_REORDERING_TIMER_PRESENT ^*/

} rrc_pdcp_cr_srb_entity_t;

typedef struct _rrc_pdcp_config_rohc_t
{
    /*ROHC Changes start*/
    UInt16 profile_id; /*^ M, 0, N, 0, 0 ^*/
    /*ROHC Changes stop*/
    UInt16 max_cid;     /* default value is 15 */
} rrc_pdcp_config_rohc_t;

typedef struct _rrc_pdcp_config_disc_timer_t
{
    UInt16 disc_timer; /*^ M, 0, H, 0, 1500 ^*/ /* rrc_pdcp_discard_timer_values_et */
} rrc_pdcp_config_disc_timer_t;

typedef struct _rrc_pdcp_config_st_rep_required_t
{
    UInt8 st_rep_required; /*^ M, 0, H, 0, 1 ^*/  /* rrc_bool_et */
} rrc_pdcp_config_st_rep_required_t;

typedef struct _rrc_pdcp_scg_data_split_threshold_t
{
    UInt32 scg_data_split_threshold; /*^ M, 0, N, 0, 0 ^*/
} rrc_pdcp_scg_data_split_threshold_t;

typedef struct _rrc_pdcp_mcg_bearer_info_t
{
    UInt64 maxMbrBearerInfoInDl; 
    /*^ M, 0, N, 0, 500000000000 ^*/
    UInt64 maxGbrBearerInfoInDl;
    /*^ M, 0, N, 0, 500000000000 ^*/
} rrc_pdcp_mcg_bearer_info_t;

typedef struct _rrc_pdcp_config_primary_path_t
{
    UInt8           primary_path;
    /*^ M, 0, H, 0, 1 ^*/ 
} rrc_pdcp_config_primary_path_t;

/*Traffic Inactivity Timer Support changes Start*/
typedef struct _rrc_pdcp_traffic_inactivity_time_t
{
    UInt32          traffic_inactivity_timer;
    /*^ M, 0, H, 0, 4294967295 ^*/
} rrc_pdcp_traffic_inactivity_time_t;
/*Traffic Inactivity Timer Support changes End*/
#define RRC_PDCP_SCG_DATA_SPLIT_THRESHOLD_PRESENT           0x01
#define RRC_PDCP_REQUESTED_MCG_BEARER_INFO_PRESENT          0x02
#define RRC_PDCP_PRIMARY_PATH_PRESENT                       0x04
/*Traffic Inactivity Timer Support changes Start*/
#define RRC_PDCP_TRAFFIC_INACTIVITY_TIME_PRESENT            0x08
/*Traffic Inactivity Timer Support changes End*/
typedef struct _rrc_pdcp_dc_bearer_type_t
{
    bitmask_t                           optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    UInt8                                  dc_bearer_type; /*^ M, 0, H, 0, 3 ^*/ /* rrc_en_dc_bearer_type_et */
    rrc_pdcp_config_primary_path_t primary_path;
    /*^ TLV, RRC_PDCP_CONFIGURE_PRIMARY_PATH_TAG, RRC_PDCP_PRIMARY_PATH_PRESENT ^*/
    rrc_pdcp_scg_data_split_threshold_t dl_data_split_threshold;
    /*^ TLV, RRC_PDCP_SCG_DATA_SPLIT_THRESHOLD_TAG, RRC_PDCP_SCG_DATA_SPLIT_THRESHOLD_PRESENT ^*/
    rrc_pdcp_mcg_bearer_info_t dl_data_split_mcg_bearer_info;
    /*^ TLV, RRC_PDCP_REQUESTED_MCG_BEARER_INFO_TAG, RRC_PDCP_REQUESTED_MCG_BEARER_INFO_PRESENT ^*/
    /*Traffic Inactivity Timer Support changes Start*/
    rrc_pdcp_traffic_inactivity_time_t traffic_inactivity_timer;
    /*^ TLV, RRC_PDCP_TRAFFIC_INACTIVITY_TIMER_TAG, RRC_PDCP_TRAFFIC_INACTIVITY_TIME_PRESENT ^*/
    /*Traffic Inactivity Timer Support changes End*/

}rrc_pdcp_dc_bearer_type_t;

typedef struct _rrc_pdcp_duplication_t
{
    UInt8           duplication_act_deact;
    /*^ M, 0, H, 0, 1 ^*/ 
} rrc_pdcp_duplication_t;

typedef struct _rrc_pdcp_sdap_config_t
{
    UInt8           dl_sdap_header; /*^ M, 0, H, 0, 1 ^*/
    UInt8           ul_sdap_header; /*^ M, 0, H, 0, 1 ^*/
}rrc_pdcp_sdap_config_t;

#define RRC_PDCP_CONFIGURE_REORDERING_TIMER_PRESENT           0x01
#define RRC_PDCP_CR_DRB_CONFIG_ROHC_PRESENT                   0x02
#define RRC_PDCP_CR_DRB_CONFIG_DISC_TIMER_PRESENT             0x04
#define RRC_PDCP_CR_DRB_CONFIG_ST_REPORT_REQUIRED_PRESENT     0x08
#define RRC_PDCP_CR_DRB_CONFIG_UE_ST_REPORT_REQUIRED_PRESENT  0x10 
#define RRC_PDCP_DC_BEARER_TYPE_PRESENT                       0x20
#define RRC_PDCP_DUPLICATION_PRESENT                          0x40
#define RRC_PDCP_SDAP_CONFIG_PRESENT                          0x80

typedef struct _rrc_pdcp_cr_drb_entity_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    drb_id_t                drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    UInt16                         rlc_mode; 
                /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_rlc_mode_et */
    rrc_rb_direction_t      rb_direction; 
                /*^ M, 0, H, 0, 2 ^*/ /* rrc_rb_direction_et */
    UInt8                   snSizeDL; /*^ M, 0, B, 12, 18 ^*/
    UInt8                   snSizeUL; /*^ M, 0, B, 12, 18 ^*/
    UInt8                   qci; /*^ M, 0, H, 0, 255 ^*/
    UInt8                   out_of_order_delivery; /*^ M, 0, H, 0, 1 ^*/
    
    rrc_pdcp_config_reorder_timer_t          config_reordering_timer;
    /*^ TLV, RRC_PDCP_CONFIGURE_REORDERING_TIMER_TAG, RRC_PDCP_CONFIGURE_REORDERING_TIMER_PRESENT ^*/

    rrc_pdcp_config_rohc_t          config_rohc;
    /*^ TLV, RRC_PDCP_CONFIGURE_ROHC_TAG, RRC_PDCP_CR_DRB_CONFIG_ROHC_PRESENT ^*/

    rrc_pdcp_config_disc_timer_t    config_disc_timer;
    /*^ TLV, RRC_PDCP_CONFIGURE_DISCARD_TIMER_TAG, RRC_PDCP_CR_DRB_CONFIG_DISC_TIMER_PRESENT ^*/

    rrc_pdcp_config_st_rep_required_t st_rep_required;
    /*^ TLV, RRC_PDCP_CONFIGURE_STATUS_REPORT_REQUIRED_TAG, RRC_PDCP_CR_DRB_CONFIG_ST_REPORT_REQUIRED_PRESENT ^*/

    rrc_pdcp_dc_bearer_type_t dc_bearer_type;
    /*^ TLV, RRC_PDCP_CONFIGURE_DC_BEARER_TYPE_TAG, RRC_PDCP_DC_BEARER_TYPE_PRESENT ^*/

    rrc_pdcp_duplication_t    pdcp_duplication;
    /*^ TLV, RRC_PDCP_CONFIGURE_DUPLICATION_TAG, RRC_PDCP_DUPLICATION_PRESENT ^*/

    rrc_pdcp_sdap_config_t    sdap_config;
    /*^ TLV, RRC_PDCP_SDAP_CONFIG_TAG, RRC_PDCP_SDAP_CONFIG_PRESENT ^*/

} rrc_pdcp_cr_drb_entity_t;

typedef struct _rrc_pdcp_config_srb_int_t
{
    UInt16 algorithm_id; /*^ M, 0, H, 0, 3 ^*/ /* rrc_int_algorithm_et */
    UInt8  key[RRC_PDCP_SECURITY_KEY_SIZE];    /*^ M, 0, OCTET_STRING, FIXED ^*/
} rrc_pdcp_config_srb_int_t;

typedef struct _rrc_pdcp_config_srb_ciph_t
{
    UInt16 algorithm_id; /*^ M, 0, H, 0, 3 ^*/ /* rrc_ciph_algorithm_et */
    UInt8  key[RRC_PDCP_SECURITY_KEY_SIZE];    /*^ M, 0, OCTET_STRING, FIXED ^*/
} rrc_pdcp_config_srb_ciph_t;

typedef struct _rrc_pdcp_config_drb_int_t
{
    UInt16 algorithm_id; /*^ M, 0, H, 1, 3 ^*/ /* rrc_int_algorithm_et */
    UInt8  key[RRC_PDCP_SECURITY_KEY_SIZE];    /*^ M, 0, OCTET_STRING, FIXED ^*/
} rrc_pdcp_config_drb_int_t;

typedef struct _rrc_pdcp_config_drb_ciph_t
{
    UInt16 algorithm_id; /*^ M, 0, H, 0, 3 ^*/ /* rrc_ciph_algorithm_et */
    UInt8  key[RRC_PDCP_SECURITY_KEY_SIZE];    /*^ M, 0, OCTET_STRING, FIXED ^*/
} rrc_pdcp_config_drb_ciph_t;

typedef struct _rrc_ue_inactive_time_t
{
    UInt32   ue_inactive_time_val; /*^ M, 0, H, 0, 63 ^*/ /* rrc_ue_inactivity_time_et */
}rrc_ue_inactive_time_t;

#define RRC_PDCP_UE_INACTIVE_TIME_LAPSED_PRESENT   0x01
typedef struct _rrc_pdcp_ho_triggered_t
{
    bitmask_t            optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    UInt8 ho_trigger; /*^ M, 0, H, 0, 1^*/

    rrc_ue_inactive_time_t  rrc_ue_inactive_time_lapsed; 
    /*^ TLV, RRC_PDCP_UE_INACTIVE_TIME_LAPSED_TAG, RRC_PDCP_UE_INACTIVE_TIME_LAPSED_PRESENT ^*/
}rrc_pdcp_ho_triggered_t;

#define UECC_LLIM_MAX_BUF_LEN           1024
typedef struct _rrc_mac_i_msg_t
{
    drb_id_t             drb_id;
    rrc_rb_direction_t   rb_direction;
    counter_t            encoded_var_short_mac_i_data_length;
    /*^ M, 0, BUFFER_SIZE, NOT_PRESENT_IN_MESSAGE ^*/

    UInt8                encoded_var_short_mac_i[UECC_LLIM_MAX_BUF_LEN];
    /*^ M, 0, OCTET_STRING, LIMITED_TILL_THE_END ^*/

}rrc_mac_i_msg_t;

typedef struct _rrc_pdcp_ue_inactivity_timer_t
{
    UInt32     ue_inactive_time_config;
}rrc_pdcp_ue_inactivity_timer_t;

#define RRC_PDCP_CR_SRB_CONFIG_INT_PRESENT          0x01
#define RRC_PDCP_CR_SRB_CONFIG_CIPH_PRESENT         0x02
#define RRC_PDCP_CR_DRB_CONFIG_INT_PRESENT          0x04
#define RRC_PDCP_CR_DRB_CONFIG_CIPH_PRESENT         0x08
#define RRC_PDCP_HO_TRIGGER_PRESENT                 0x10
#define RRC_PDCP_CONFIG_MACI_REQ_PRESENT            0x20
#define RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_PRESENT 0x40

typedef struct _rrc_pdcp_cr_ue_entity_req_t
{
    bitmask_t                   optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    ue_index_t                  ue_index;
    rrc_rnti_t                      crnti;

    counter_t                   num_cr_srb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_srb_entity_t        cr_srb_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_SRB_ENTITY_TAG ^*/

    counter_t                   num_cr_drb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_drb_entity_t        cr_drb_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_DRB_ENTITY_TAG ^*/

    rrc_pdcp_config_srb_int_t           config_srb_integrity_protection;
    /*^ TLV, RRC_PDCP_CONFIGURE_SRB_INTEGRITY_PROTECTION_TAG, RRC_PDCP_CR_SRB_CONFIG_INT_PRESENT ^*/

    rrc_pdcp_config_srb_ciph_t      config_srb_ciphering;
    /*^ TLV, RRC_PDCP_CONFIGURE_SRB_CIPHERING_TAG, RRC_PDCP_CR_SRB_CONFIG_CIPH_PRESENT ^*/

    rrc_pdcp_config_drb_int_t           config_drb_integrity_protection;
    /*^ TLV, RRC_PDCP_CONFIGURE_DRB_INTEGRITY_PROTECTION_TAG, RRC_PDCP_CR_DRB_CONFIG_INT_PRESENT ^*/

    rrc_pdcp_config_drb_ciph_t      config_drb_ciphering;
    /*^ TLV, RRC_PDCP_CONFIGURE_DRB_CIPHERING_TAG, RRC_PDCP_CR_DRB_CONFIG_CIPH_PRESENT ^*/

    rrc_pdcp_ho_triggered_t         ho_triggered; 
    /*^ TLV, RRC_PDCP_HO_TRIGGERED_TAG, RRC_PDCP_HO_TRIGGER_PRESENT ^*/  

    rrc_mac_i_msg_t                 mac_i_req;
    /*^ TLV, RRC_PDCP_MACI_REQ_TAG, RRC_PDCP_CONFIG_MACI_REQ_PRESENT ^*/

    rrc_pdcp_ue_inactivity_timer_t  ue_inactivity_timer;
    /*^ TLV, RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_TAG, RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_PRESENT ^*/

} rrc_pdcp_cr_ue_entity_req_t; /*^ API, RRC_PDCP_CREATE_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_CREATE_UE_ENTITY_CNF
******************************************************************************/
typedef struct _rrc_pdcp_cr_srb_entity_error_t
{
    drb_id_t        lc_id; /*^ M, 0, B, 1, MAX_SRB ^*/
    rrc_response_t  response; /* 1:SUCCESS,
                                 771:Invalid LCID,
                                 772:RLC Mode or Direction out of rang
                                 enum rrc_pdcp_error_code_et */
} rrc_pdcp_cr_srb_entity_error_t;

typedef struct _rrc_pdcp_cr_drb_entity_error_t
{
    drb_id_t        drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_response_t  response; /* 1:SUCCESS,
                                 771:Invalid LCID,
                                 772:RLC Mode or Direction out of range 
                                 enum rrc_pdcp_error_code_et */
} rrc_pdcp_cr_drb_entity_error_t;

typedef struct _rrc_mac_i_t
{
    UInt32     mac_i;
}rrc_mac_i_t;

#define RRC_PDCP_CONFIG_MACI_RESP_PRESENT 0x01
typedef struct _pdcp_rrc_cr_ue_entity_cnf_t
{
    bitmask_t                   optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    ue_index_t                  ue_index;
    rrc_response_t                  response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t                   num_cr_srb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_srb_entity_error_t  cr_srb_error_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_SRB_ENTITY_ERROR_TAG ^*/

    counter_t                   num_cr_drb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_drb_entity_error_t  cr_drb_error_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_DRB_ENTITY_ERROR_TAG ^*/

    rrc_mac_i_t                         mac_i;
    /*^ TLV, RRC_PDCP_MACI_RESP_TAG, RRC_PDCP_CONFIG_MACI_RESP_PRESENT ^*/

} pdcp_rrc_cr_ue_entity_cnf_t; /*^ API, PDCP_RRC_CREATE_UE_ENTITY_CNF ^*/

/******************************************************************************
*   RRC_PDCP_DELETE_UE_ENTITY_REQ
******************************************************************************/
typedef struct _rrc_pdcp_del_ue_entity_req_t
{
    ue_index_t  ue_index;
} rrc_pdcp_del_ue_entity_req_t; /*^ API, RRC_PDCP_DELETE_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_DELETE_UE_ENTITY_CNF
******************************************************************************/
typedef struct _pdcp_rrc_del_ue_entity_cnf_t
{
    ue_index_t  ue_index;

    rrc_response_t  response;   /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */

} pdcp_rrc_del_ue_entity_cnf_t; /*^ API, PDCP_RRC_DELETE_UE_ENTITY_CNF ^*/

/******************************************************************************
*   RRC_PDCP_RECONFIG_UE_ENTITY_REQ
******************************************************************************/
#define RRC_PDCP_RCFG_CONFIGURE_REORDERING_TIMER_PRESENT        0x01
#define RRC_PDCP_RCFG_DRB_CONFIG_ROHC_PRESENT                   0x02
#define RRC_PDCP_RCFG_DRB_CONFIG_DISC_TIMER_PRESENT             0x04
#define RRC_PDCP_RCFG_DRB_CONFIG_ST_REPORT_REQUIRED_PRESENT     0x08
#define RRC_PDCP_RCFG_DRB_CONFIG_UE_ST_REPORT_REQUIRED_PRESENT  0x10
#define RRC_PDCP_RCFG_DUPLICATION_PRESENT                       0x20
#define RRC_PDCP_RECONFIG_SDAP_CONFIG_PRESENT                   0x40

typedef struct _rrc_pdcp_rcfg_drb_entity_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    drb_id_t                drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_rb_direction_t          rb_direction;
                /*^ M, 0, H, 0, 2 ^*/ /* rrc_rb_direction_et */
    rrc_pdcp_config_reorder_timer_t          config_reordering_timer;
    /*^ TLV, RRC_PDCP_CONFIGURE_REORDERING_TIMER_TAG, RRC_PDCP_RCFG_CONFIGURE_REORDERING_TIMER_PRESENT ^*/

    rrc_pdcp_config_rohc_t      config_rohc;
    /*^ TLV, RRC_PDCP_CONFIGURE_ROHC_TAG, RRC_PDCP_RCFG_DRB_CONFIG_ROHC_PRESENT ^*/

    rrc_pdcp_config_disc_timer_t    config_disc_timer;
    /*^ TLV, RRC_PDCP_CONFIGURE_DISCARD_TIMER_TAG, RRC_PDCP_RCFG_DRB_CONFIG_DISC_TIMER_PRESENT ^*/

    rrc_pdcp_config_st_rep_required_t st_rep_required;
    /*^ TLV, RRC_PDCP_CONFIGURE_STATUS_REPORT_REQUIRED_TAG, RRC_PDCP_RCFG_DRB_CONFIG_ST_REPORT_REQUIRED_PRESENT ^*/

    rrc_pdcp_dc_bearer_type_t dc_bearer_type;
    /*^ TLV, RRC_PDCP_CONFIGURE_DC_BEARER_TYPE_TAG, RRC_PDCP_DC_BEARER_TYPE_PRESENT ^*/

    rrc_pdcp_duplication_t    pdcp_duplication;
    /*^ TLV, RRC_PDCP_CONFIGURE_DUPLICATION_TAG, RRC_PDCP_RCFG_DUPLICATION_PRESENT ^*/

    rrc_pdcp_sdap_config_t    sdap_config;
    /*^ TLV, RRC_PDCP_SDAP_CONFIG_TAG, RRC_PDCP_SDAP_CONFIG_PRESENT ^*/
} rrc_pdcp_rcfg_drb_entity_t;

typedef struct _rrc_pdcp_del_srb_entity_t
{
    drb_id_t    srb_id; /*^ M, 0, B, 1, MAX_SRB ^*/
} rrc_pdcp_del_srb_entity_t;

typedef struct _rrc_pdcp_del_drb_entity_t
{
    drb_id_t drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
} rrc_pdcp_del_drb_entity_t;

typedef struct _rrc_pdcp_reconf_ue_entity_req_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/
     
    ue_index_t              ue_index;

    counter_t               num_cr_srb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_srb_entity_t    cr_srb_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_SRB_ENTITY_TAG ^*/

    counter_t               num_cr_drb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_drb_entity_t    cr_drb_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_DRB_ENTITY_TAG ^*/

    counter_t               num_reconfig_srb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    counter_t               num_reconfig_drb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rcfg_drb_entity_t  rcfg_drb_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RECONFIG_DRB_ENTITY_TAG ^*/

    rrc_pdcp_config_srb_int_t       config_srb_integrity_protection;
    /*^ TLV, RRC_PDCP_CONFIGURE_SRB_INTEGRITY_PROTECTION_TAG, RRC_PDCP_CR_SRB_CONFIG_INT_PRESENT ^*/
 
    rrc_pdcp_config_srb_ciph_t      config_srb_ciphering;
    /*^ TLV, RRC_PDCP_CONFIGURE_SRB_CIPHERING_TAG, RRC_PDCP_CR_SRB_CONFIG_CIPH_PRESENT ^*/

    rrc_pdcp_config_drb_int_t       config_drb_integrity_protection;
    /*^ TLV, RRC_PDCP_CONFIGURE_DRB_INTEGRITY_PROTECTION_TAG, RRC_PDCP_CR_DRB_CONFIG_INT_PRESENT ^*/
 
    rrc_pdcp_config_drb_ciph_t      config_drb_ciphering;
    /*^ TLV, RRC_PDCP_CONFIGURE_DRB_CIPHERING_TAG, RRC_PDCP_CR_DRB_CONFIG_CIPH_PRESENT ^*/

    counter_t               num_del_srb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_del_srb_entity_t   del_srb_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DELETE_SRB_ENTITY_TAG ^*/

    counter_t               num_del_drb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_del_drb_entity_t   del_drb_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DELETE_DRB_ENTITY_TAG ^*/

    rrc_mac_i_msg_t              mac_i_req;
    /*^ TLV, RRC_PDCP_MACI_REQ_TAG, RRC_PDCP_CONFIG_MACI_REQ_PRESENT ^*/

    rrc_pdcp_ue_inactivity_timer_t  ue_inactivity_timer; 
    /*^ TLV, RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_TAG, RRC_PDCP_UE_INACTIVITY_TIMER_CONFIG_PRESENT ^*/

} rrc_pdcp_reconf_ue_entity_req_t; /*^ API, RRC_PDCP_RECONFIG_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_RECONFIG_UE_ENTITY_CNF
******************************************************************************/
typedef struct _rrc_pdcp_del_srb_entity_error_t
{
    drb_id_t lc_id; /*^ M, 0, B, 1, MAX_SRB ^*/
    rrc_response_t  response; /* 1:SUCCESS,
                                 771:Invalid LCID 
                                 enum rrc_pdcp_error_code_et */
} rrc_pdcp_del_srb_entity_error_t;

typedef struct _rrc_pdcp_del_drb_entity_error_t
{
    drb_id_t    drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_response_t  response; /* 1:SUCCESS,
                                 771:Invalid LCID
                                 enum rrc_pdcp_error_code_et */
} rrc_pdcp_del_drb_entity_error_t;

typedef struct _rrc_pdcp_rcfg_drb_entity_error_t
{
    drb_id_t    drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_response_t  response; /* 1:SUCCESS,
                                 771:Invalid LCID,
                                 772:RLC Mode or Direction out of range
                                 enum rrc_pdcp_error_code_et */
} rrc_pdcp_rcfg_drb_entity_error_t;

#define RRC_PDCP_RECONFIG_MACI_RESP_PRESENT 0x01
typedef struct _pdcp_rrc_reconfig_ue_entity_cnf_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    ue_index_t                      ue_index;
    rrc_response_t                      response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t                       num_cr_srb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_srb_entity_error_t      cr_srb_error_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_SRB_ENTITY_ERROR_TAG ^*/

    counter_t                       num_cr_drb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_cr_drb_entity_error_t      cr_drb_error_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_CREATE_DRB_ENTITY_ERROR_TAG ^*/

    counter_t                       num_del_srb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_del_srb_entity_error_t    del_srb_error_entities[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DELETE_SRB_ENTITY_ERROR_TAG ^*/

    counter_t                       num_del_drb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_del_drb_entity_error_t    del_drb_error_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DELETE_DRB_ENTITY_ERROR_TAG ^*/

    counter_t                       num_rcfg_srb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    counter_t                       num_rcfg_drb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rcfg_drb_entity_error_t  rcfg_drb_error_entities[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RECONFIG_DRB_ENTITY_ERROR_TAG ^*/

    rrc_mac_i_t                         mac_i;
    /*^ TLV, RRC_PDCP_MACI_RESP_TAG, RRC_PDCP_RECONFIG_MACI_RESP_PRESENT ^*/

} pdcp_rrc_reconfig_ue_entity_cnf_t;
/*^ API, PDCP_RRC_RECONFIG_UE_ENTITY_CNF ^*/


/******************************************************************************
*   RRC_PDCP_SRB_DL_DATA_REQ
******************************************************************************/
typedef struct _rrc_pdcp_srb_dl_data_req_t
{
    ue_index_t         ue_index;
    drb_id_t           srb_id; /*^ M, 0, B, 1, 3 ^*/
    UInt8              p_buffer[0]; /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/
} rrc_pdcp_srb_dl_data_req_t; /*^ API, ONLY_PUP, RRC_PDCP_SRB_DL_DATA_REQ ^*/

/******************************************************************************
*   PDCP_RRC_SRB_DL_DATA_RESP
******************************************************************************/
typedef struct _pdcp_rrc_srb_dl_data_resp_t
{
    ue_index_t         ue_index;
    drb_id_t           srb_id; /*^ M, 0, B, 1, 3 ^*/
    rrc_response_t     response_code; /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */
    UInt8              p_buffer[0]; /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/
} pdcp_rrc_srb_dl_data_resp_t; /*^ API, ONLY_PUP, PDCP_RRC_SRB_DL_DATA_RESP ^*/

/******************************************************************************
*   RRC_PDCP_SRB_UL_DATA_REQ
******************************************************************************/
typedef struct _rrc_pdcp_srb_ul_data_req_t
{
    ue_index_t         ue_index;
    drb_id_t           srb_id; /*^ M, 0, B, 1, 3 ^*/
    UInt8              p_buffer[0]; /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/
} rrc_pdcp_srb_ul_data_req_t; /*^ API, ONLY_PUP, RRC_PDCP_SRB_UL_DATA_REQ ^*/

/******************************************************************************
*   PDCP_RRC_SRB_UL_DATA_RESP
******************************************************************************/
typedef struct _pdcp_rrc_srb_ul_data_resp_t
{
    ue_index_t       ue_index;
    drb_id_t        srb_id; /*^ M, 0, B, 1, 3 ^*/
    rrc_response_t  response_code; /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */
    UInt8           p_buffer[0]; /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/
} pdcp_rrc_srb_ul_data_resp_t; /*^ API, ONLY_PUP, PDCP_RRC_SRB_UL_DATA_RESP ^*/

/******************************************************************************
*   RRC_PDCP_SN_HFN_STATUS_REQ
******************************************************************************/
typedef struct _rrc_lossy_ho_required_t
{
    drb_id_t   drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
}rrc_lossy_ho_required_t;

typedef struct _rrc_long_pdcp_sn_supported_t
{
    UInt8   is_long_pdcp_sn_supported; /*^ M, 0, H, 0, 1 ^*/
}rrc_long_pdcp_sn_supported_t;

#define RRC_PDCP_LONG_PDCP_SN_TAG_PRESENT 0x01
typedef struct _rrc_pdcp_sn_hfn_status_req_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    ue_index_t                      ue_index;
    counter_t                       num_lossy_drb_entity; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    rrc_lossy_ho_required_t         lossy_ho_required[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_LOSSY_HO_REQUIRED_TAG ^*/
    rrc_long_pdcp_sn_supported_t    is_long_pdcp_sn_supported;
    /*^ TLV, RRC_PDCP_LONG_PDCP_SN_TAG, RRC_PDCP_LONG_PDCP_SN_TAG_PRESENT ^*/

}rrc_pdcp_sn_hfn_status_req_t; /*^ API, RRC_PDCP_SN_HFN_STATUS_REQ ^*/

/******************************************************************************
*   PDCP_RRC_SN_HFN_STATUS_RESP
******************************************************************************/
typedef struct _ul_rcv_sn_val_t
{
    counter_t            num_ul_rcv_sn;
    /*^ M, 0, BUFFER_SIZE, NOT_PRESENT_IN_MESSAGE ^*/

    UInt8    ul_rcv_sn[16384];
    /*^ M, 0, OCTET_STRING, LIMITED_TILL_THE_END ^*/
}ul_rcv_sn_val_t;

#define RRC_PDCP_UL_RECV_SN_PRESENT   0x01

typedef struct _rrc_lc_sn_hfn_status_t
{
    bitmask_t       optional_elems_present; 
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    drb_id_t            drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    UInt32              dl_sn_cnt;   /*^ M, 0, H, 0, MAX_DL_SN ^*/
    UInt32              dl_hfn_cnt;  /*^ M, 0, H, 0, MAX_DL_HFN ^*/
    UInt32              ul_sn_cnt;   /*^ M, 0, H, 0, MAX_UL_SN ^*/
    UInt32              ul_hfn_cnt;  /*^ M, 0, H, 0, MAX_UL_HFN ^*/
    ul_rcv_sn_val_t  ul_rcv_sn_val;
    /*^ TLV, RRC_PDCP_UL_RECV_SN_TAG, RRC_PDCP_UL_RECV_SN_PRESENT ^*/

}rrc_lc_sn_hfn_status_t;

typedef struct _pdcp_rrc_sn_hfn_status_resp_t
{
    ue_index_t           ue_index;
    rrc_response_t       response_code; 
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t            num_lc_sn_hfn_status;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_lc_sn_hfn_status_t   lc_sn_hfn_status[MAX_DRB];  
    /*^ TLV, SEQUENCE, RRC_PDCP_LC_SN_HFN_STATUS_TAG ^*/

}pdcp_rrc_sn_hfn_status_resp_t; /*^ API, PDCP_RRC_SN_HFN_STATUS_RESP ^*/


/******************************************************************************
*   RRC_PDCP_SN_HFN_STATUS_IND
******************************************************************************/
typedef struct _rrc_pdcp_sn_hfn_status_ind_t
{
    ue_index_t                    ue_index;
    
    counter_t                     num_lc_sn_hfn_status;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    rrc_lc_sn_hfn_status_t        lc_sn_hfn_status[MAX_DRB]; 
    /*^ TLV, SEQUENCE, RRC_PDCP_LC_SN_HFN_STATUS_TAG ^*/

}rrc_pdcp_sn_hfn_status_ind_t; /*^ API, RRC_PDCP_SN_HFN_STATUS_IND ^*/

/******************************************************************************
*   RRC_PDCP_DATA_BUFFER_STOP_IND
******************************************************************************/
typedef struct _rrc_pdcp_full_config
{
    UInt8              full_config;  /*^ M, 0, H, 0, 1 ^*/
}rrc_pdcp_full_config_t;

#define RRC_PDCP_FULL_CONFIG_TAG_PRESENT 0x01
typedef struct _rrc_pdcp_data_buffer_stop_ind_t
{
    bitmask_t               optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    ue_index_t           ue_index;

    rrc_pdcp_full_config_t   full_config;
    /*^ TLV, RRC_PDCP_FULL_CONFIG_TAG, RRC_PDCP_FULL_CONFIG_TAG_PRESENT ^*/
}rrc_pdcp_data_buffer_stop_ind_t; /*^ API, RRC_PDCP_DATA_BUFFER_STOP_IND ^*/


/******************************************************************************
*   RRC_PDCP_MAC_I_REQ
******************************************************************************/
#define MAX_NO_OF_MESSAGES   33
typedef struct _rrc_message_t
{
    /*NGAP_BASED_HO_START*/
    UInt8   cell_identity[MAX_NR_CELL_IDENTITY_OCTETS]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    /*NGAP_BASED_HO_STOP*/

    counter_t   encoded_var_short_mac_i_data_length;  
    /*^ M, 0, BUFFER_SIZE, NOT_PRESENT_IN_MESSAGE ^*/

    UInt8   encoded_var_short_mac_i[UECC_LLIM_MAX_BUF_LEN];  
    /*^ M, 0, OCTET_STRING, LIMITED_TILL_THE_END ^*/
    
}rrc_message_t;

typedef struct _rrc_pdcp_mac_i_req_t
{
    ue_index_t      ue_index;
    drb_id_t        drb_id; /*^ M, 0, N, 0, 0 ^*/
    rrc_rb_direction_t  rb_direction;
    counter_t       num_message; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_message_t       message[MAX_NO_OF_MESSAGES]; 
    /*^ TLV, SEQUENCE, RRC_PDCP_MESSAGE_TAG ^*/

}rrc_pdcp_mac_i_req_t; /*^ API, RRC_PDCP_MAC_I_REQ ^*/


/******************************************************************************
*   PDCP_RRC_MAC_I_RESP
******************************************************************************/

typedef struct _rrc_msg_authentication_code_t
{
    UInt8   cell_identity[4]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    rrc_response_t      response_code; 
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    UInt32                      mac_i;
}rrc_msg_authentication_code_t;

typedef struct _pdcp_rrc_mac_i_resp_t
{
    ue_index_t           ue_index;
    rrc_response_t           response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t             num_var_short_mac_i;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_msg_authentication_code_t  rrc_msg_authentication_code[MAX_NO_OF_MESSAGES]; 
    /*^ TLV, SEQUENCE, RRC_PDCP_MSG_AUTHENTICATION_CODE_TAG ^*/

}pdcp_rrc_mac_i_resp_t; /*^ API, PDCP_RRC_MAC_I_RESP ^*/

/******************************************************************************
*   RRC_PDCP_RE_ESTABLISH_UE_ENTITY_REQ
******************************************************************************/
/* RB entity, 1-3 for SRB and 4-32 for DRB */
typedef struct _rrc_pdcp_rb_entity_t
{
    UInt8      bearer_type; /*^ M, 0, H, 0, 1 ^*/
    drb_id_t   bearer_id  ; /*^ M, 0, B, MIN_SRB, MAX_DRB ^*/
} rrc_pdcp_rb_entity_t;

typedef struct _rrc_pdcp_re_establish_ue_entity_req_t
{
    ue_index_t                  ue_index;

    counter_t                   num_re_est_rb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rb_entity_t        re_est_rb_entities[MAX_RB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RB_ENTITY_TAG ^*/
} rrc_pdcp_re_establish_ue_entity_req_t; /*^ API, RRC_PDCP_RE_ESTABLISH_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_RE_ESTABLISH_UE_ENTITY_CNF
******************************************************************************/
typedef struct _rrc_pdcp_rb_entity_error_t
{
    drb_id_t    drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_response_t  response_code; /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */
} rrc_pdcp_rb_entity_error_t;

typedef struct _pdcp_rrc_re_establish_ue_entity_cnf_t
{
    ue_index_t                      ue_index;
    rrc_response_t                      response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t                       num_re_est_rb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rb_entity_error_t   re_est_srb_error[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_SRB_ENTITY_ERROR_TAG ^*/

    rrc_pdcp_rb_entity_error_t   re_est_drb_error[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DRB_ENTITY_ERROR_TAG ^*/

} pdcp_rrc_re_establish_ue_entity_cnf_t;
/*^ API, PDCP_RRC_RE_ESTABLISH_UE_ENTITY_CNF ^*/

/******************************************************************************
*   RRC_PDCP_SUSPEND_UE_ENTITY_REQ
******************************************************************************/

typedef struct _rrc_pdcp_suspend_ue_entity_req_t
{
    ue_index_t  ue_index;
    UInt8       suspend_complete_ue; /*^ M, 0, H, 0, 1 ^*/
    
    counter_t                   num_suspend_rb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    rrc_pdcp_rb_entity_t        suspend_rb_entities[MAX_RB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RB_ENTITY_TAG ^*/
} rrc_pdcp_suspend_ue_entity_req_t; /*^ API, RRC_PDCP_SUSPEND_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_SUSPEND_UE_ENTITY_CNF
******************************************************************************/

typedef struct _pdcp_rrc_suspend_ue_entity_cnf_t
{
    ue_index_t                      ue_index;
    rrc_response_t                  response_code; /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */
    
    counter_t                       num_re_est_srb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    rrc_pdcp_rb_entity_error_t      suspend_srb_error[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_SRB_ENTITY_ERROR_TAG ^*/

    counter_t                       num_re_est_drb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    rrc_pdcp_rb_entity_error_t      suspend_drb_error[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DRB_ENTITY_ERROR_TAG ^*/

} pdcp_rrc_suspend_ue_entity_cnf_t; /*^ API, PDCP_RRC_SUSPEND_UE_ENTITY_CNF ^*/

/******************************************************************************
*   RRC_PDCP_RESUME_UE_ENTITY_REQ
******************************************************************************/
typedef struct _rrc_pdcp_resume_ue_entity_req_t
{
    ue_index_t                  ue_index;

    UInt8                       resume_complete_ue;
    /*^ M, 0, H, 0, 1 ^*/

    rrc_rb_direction_t          resume_direction;
    /* rrc_rb_direction_et */

    counter_t                   num_resume_rb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rb_entity_t        resume_rb_entities[MAX_RB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RB_ENTITY_TAG ^*/
} rrc_pdcp_resume_ue_entity_req_t; /*^ API, RRC_PDCP_RESUME_UE_ENTITY_REQ ^*/

/******************************************************************************
*   PDCP_RRC_RESUME_UE_ENTITY_CNF
******************************************************************************/
typedef struct _pdcp_rrc_resume_ue_entity_cnf_t
{
    ue_index_t                      ue_index;
    rrc_response_t                  response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t                       num_resume_rb_entity_error;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rb_entity_error_t      resume_srb_error[MAX_SRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_SRB_ENTITY_ERROR_TAG ^*/

    rrc_pdcp_rb_entity_error_t      resume_drb_error[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DRB_ENTITY_ERROR_TAG ^*/

} pdcp_rrc_resume_ue_entity_cnf_t;
/*^ API, PDCP_RRC_RESUME_UE_ENTITY_CNF ^*/

/******************************************************************************
*  RRC_PDCP_CHANGE_CRNTI_REQ
******************************************************************************/
typedef struct _rrc_pdcp_change_crnti_req_t
{
    ue_index_t  ue_index;
    rrc_rnti_t      old_crnti;
    rrc_rnti_t      new_crnti;
} rrc_pdcp_change_crnti_req_t; /*^ API, RRC_PDCP_CHANGE_CRNTI_REQ ^*/

/******************************************************************************
* PDCP_RRC_CHANGE_CRNTI_CNF
******************************************************************************/
typedef struct _pdcp_rrc_change_crnti_cnf_t
{
    ue_index_t  ue_index;

    rrc_response_t  response;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

} pdcp_rrc_change_crnti_cnf_t; /*^ API, PDCP_RRC_CHANGE_CRNTI_CNF ^*/

/******************************************************************************
* PDCP_RRC_COUNT_WRAPAROUND_IND
******************************************************************************/
typedef struct _pdcp_rrc_count_wraparound_ind_t
{
    ue_index_t  ue_index;
} pdcp_rrc_count_wraparound_ind_t; /*^ API, PDCP_RRC_COUNT_WRAPAROUND_IND ^*/

/******************************************************************************
* PDCP_RRC_NOTIFY_INTEGRITY_FAILURE
******************************************************************************/
typedef struct _pdcp_rrc_notify_integrity_failure_t
{
    ue_index_t  ue_index;

    UInt8       bearer_type;
    /*^ M, 0, H, 0, 1 ^*/

    UInt8       rb_id;
    /*^ M, 0, B, MIN_SRB, MAX_DRB ^*/

}pdcp_rrc_notify_integrity_failure_t; /*^ API, PDCP_RRC_NOTIFY_INTEGRITY_FAILURE ^*/

/******************************************************************************
* RRC_PDCP_DRB_COUNT_MSB_REQ
******************************************************************************/

typedef struct _rrc_pdcp_ue_info_drb_count_req_t
{
    ue_index_t                      ue_index;
}rrc_pdcp_ue_info_drb_count_req;

typedef struct _rrc_pdcp_drb_count_msb_req_t
{
    counter_t            num_ue; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_ue_info_drb_count_req
                            ue_info_drb_count_req[MAX_NUM_COUNTER_CHECK_UE];
    /*^ TLV, SEQUENCE, RRC_PDCP_UE_INFO_DRB_COUNT_REQ_TAG ^*/
} rrc_pdcp_drb_count_msb_req_t; /*^ API, RRC_PDCP_DRB_COUNT_MSB_REQ ^*/

/******************************************************************************
* PDCP_RRC_DRB_COUNT_MSB_RESP
******************************************************************************/
typedef struct _rrc_pdcp_drb_count_msb_uplink_t 
{
    UInt32 count_MSB; /*^ M, 0, H, 0, MAX_UL_HFN ^*/
}rrc_pdcp_drb_count_msb_uplink;

typedef struct _rrc_pdcp_drb_count_msb_downlink_t
{
    UInt32 count_MSB; /*^ M, 0, H, 0, MAX_DL_HFN ^*/
}rrc_pdcp_drb_count_msb_downlink;

#define RRC_PDCP_DRB_COUNT_MSB_UPLINK_PRESENT    0x01
#define RRC_PDCP_DRB_COUNT_MSB_DOWNLINK_PRESENT    0x02
typedef struct _rrc_pdcp_drb_count_msb_info_t
{
    bitmask_t                   optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    drb_id_t                         drb_id; /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
    rrc_pdcp_drb_count_msb_uplink count_msb_uplink;
    /*^ TLV, RRC_PDCP_DRB_COUNT_MSB_UPLINK_TAG, RRC_PDCP_DRB_COUNT_MSB_UPLINK_PRESENT ^*/
    rrc_pdcp_drb_count_msb_downlink count_msb_downlink;
    /*^ TLV, RRC_PDCP_DRB_COUNT_MSB_DOWNLINK_TAG, RRC_PDCP_DRB_COUNT_MSB_DOWNLINK_PRESENT ^*/
}rrc_pdcp_drb_count_msb_info;

typedef struct _rrc_pdcp_ue_info_drb_count_resp_t
{
    ue_index_t     ueIndex;
    counter_t      num_cr_drb_entity;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_drb_count_msb_info drb_countMSB_info[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DRB_COUNT_MSB_INFO_TAG ^*/
}rrc_pdcp_ue_info_drb_count_resp;

typedef struct _pdcp_rrc_drb_count_msb_resp_t
{
    rrc_response_t  response;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t            num_ue; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_ue_info_drb_count_resp 
                             ue_info_drb_count_resp[MAX_NUM_COUNTER_CHECK_UE];
    /*^ TLV, SEQUENCE, RRC_PDCP_UE_INFO_DRB_COUNT_RESP_TAG ^*/

} pdcp_rrc_drb_count_msb_resp_t; /*^ API, PDCP_RRC_DRB_COUNT_MSB_RESP ^*/


/******************************************************************************
*   RRC_PDCP_CELL_CONFIG_REQ
******************************************************************************/
#define RRC_PDCP_COUNT_WRAPAROUND_THRESHOLD_PRESENT               0x01
typedef struct _pdcp_count_wrap_wround_thr_t
{
    UInt32   countWarparoundThreshold; /*^ M, 0, N, 0, 0 ^*/
}pdcp_count_wrap_wround_thr_t;


typedef struct _rrc_pdcp_config_cell_req_t
{
    bitmask_t                optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/

    UInt16                          maxUeNumber; /*^ M, 0, N, 0, 0 ^*/
    pdcp_count_wrap_wround_thr_t countWraparoundThresholdValue;
    /*^ TLV, RRC_PDCP_COUNT_WRAPAROUND_THRESHOLD_TAG, RRC_PDCP_COUNT_WRAPAROUND_THRESHOLD_PRESENT ^*/
} rrc_pdcp_config_cell_req_t; /*^ API, RRC_PDCP_CELL_CONFIG_REQ ^*/


/******************************************************************************
*   PDCP_RRC_CELL_CONFIG_RESP
******************************************************************************/
typedef struct _pdcp_rrc_config_cell_resp_t
{
    rrc_response_t  response;
    /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */
} pdcp_rrc_config_cell_resp_t; /*^ API, PDCP_RRC_CELL_CONFIG_RESP ^*/


/******************************************************************************
* RRC_PDCP_HO_PREP_INFO_REQ
******************************************************************************/

#define RRC_PDCP_MACI_MSG_REQ_PRESENT                   0x01
#define RRC_PDCP_HO_PREP_UE_INACTIVE_TIME_REQ_PRESENT   0x02
typedef struct _rrc_mac_i_msg_req_t
{
    drb_id_t                        drb_id;
    rrc_rb_direction_t              rb_direction;
    counter_t                       num_message; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_message_t                       message[MAX_NO_OF_MESSAGES]; 
    /*^ TLV, SEQUENCE, RRC_PDCP_MESSAGE_TAG ^*/
}rrc_mac_i_msg_req_t;

typedef struct _rrc_ue_inactivity_time_val_t
{
    UInt8                                  ue_inactive_time_val_flag;  /*^ M, 0, H, 0, 1 ^*/ /* rrc_bool_et */
}rrc_ue_inactivity_time_val_t;

typedef struct _rrc_pdcp_ho_prep_info_req_t
{
    bitmask_t                       optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/
     
    ue_index_t                      ue_index;

    rrc_mac_i_msg_req_t                 mac_i_msg_req;
    /*^ TLV, RRC_PDCP_MACI_HO_REQ_TAG, RRC_PDCP_MACI_MSG_REQ_PRESENT ^*/

    rrc_ue_inactivity_time_val_t              ue_inactive_time_val; 
    /*^ TLV, RRC_PDCP_UE_INACTIVE_TIME_REQ_TAG, RRC_PDCP_HO_PREP_UE_INACTIVE_TIME_REQ_PRESENT ^*/
} rrc_pdcp_ho_prep_info_req_t; /*^ API, RRC_PDCP_HO_PREP_INFO_REQ ^*/

/******************************************************************************
* PDCP_RRC_HO_PREP_INFO_RESP
******************************************************************************/

#define RRC_PDCP_HO_PREP_UE_INACTIVE_TIME_RESP_PRESENT      0x01
typedef struct _pdcp_rrc_ho_prep_info_resp_t
{
    bitmask_t                       optional_elems_present;
    /*^ M, 0, BITMASK, NOT_PRESENT_IN_MESSAGE ^*/
     
    ue_index_t                      ue_index;

    rrc_response_t                      response_code;
    /*^ M, 0, H, 0, 2 ^*/ /* rrc_pdcp_return_et */

    counter_t                       num_var_short_mac_i; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_msg_authentication_code_t       rrc_msg_authentication_code[MAX_NO_OF_MESSAGES]; 
    /*^ TLV,SEQUENCE, RRC_PDCP_MSG_AUTHENTICATION_CODE_TAG ^*/

    rrc_ue_inactive_time_t              ue_inactivity_time_resp; 
    /*^ TLV, RRC_PDCP_UE_INACTIVE_TIME_RESP_TAG, RRC_PDCP_HO_PREP_UE_INACTIVE_TIME_RESP_PRESENT ^*/
} pdcp_rrc_ho_prep_info_resp_t; /*^ API, PDCP_RRC_HO_PREP_INFO_RESP ^*/

/******************************************************************************
* PDCP_RRC_INACTIVE_UES_IND
******************************************************************************/

typedef struct _rrc_pdcp_inactive_ue_info_t
{
    ue_index_t   ue_index;
}rrc_pdcp_inactive_ue_info_t;

typedef struct _pdcp_rrc_inactive_ues_ind_t
{
    counter_t                 num_of_inactive_ue_counter;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_inactive_ue_info_t    inactive_ue_info[RRC_MAX_INACTIVE_UES];
    /*^ TLV, SEQUENCE, RRC_PDCP_INACTIVE_UE_INFO_TAG ^*/
} pdcp_rrc_inactive_ues_ind_t; /*^ API, PDCP_RRC_INACTIVE_UES_IND ^*/

/******************************************************************************
* RRC_PDCP_PURGE_CELL_UES_REQ
******************************************************************************/
typedef struct _rrc_pdcp_delete_ue_info_t
{
    ue_index_t          ue_index;
}rrc_pdcp_delete_ue_info_t;

typedef struct _rrc_pdcp_purge_cell_ues_req_t
{
    UInt8               delete_all_ue;
    /*^ M, 0, H, 0, 1 ^*/

    counter_t           num_delete_ue_counter; 
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_delete_ue_info_t 
                            delete_ue_info_req[MAX_NUM_PURGE_UE_IN_BATCH];
    /*^ TLV, SEQUENCE, RRC_PDCP_DELETE_UE_INFO_TAG ^*/

} rrc_pdcp_purge_cell_ues_req_t; /*^ API, RRC_PDCP_PURGE_CELL_UES_REQ ^*/

/******************************************************************************
 * PDCP_RRC_PURGE_CELL_UES_RESP
 ******************************************************************************/
typedef struct _pdcp_rrc_purge_cell_ues_resp_t
{
    rrc_response_t  response;
    /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */
} pdcp_rrc_purge_cell_ues_resp_t; /*^ API, PDCP_RRC_PURGE_CELL_UES_RESP ^*/

/******************************************************************************
 * RRC_PDCP_CELL_DELETE_REQ
 ******************************************************************************/
/* No Payload */

/******************************************************************************
 * PDCP_RRC_CELL_DELETE_RESP
 ******************************************************************************/
typedef struct _pdcp_rrc_cell_delete_resp_t
{
    rrc_response_t  response;
    /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */
} pdcp_rrc_cell_delete_resp_t; /*^ API, PDCP_RRC_CELL_DELETE_RESP ^*/
/******************************************************************************
* RRC_PDCP_DATA_VOLUME_REPORT_REQ
******************************************************************************/
typedef struct _rrc_pdcp_data_volume_report_req_t
{
    drb_id_t            drb_id;
    /*^ M, 0, B, MIN_DRB, MAX_RB ^*/
}rrc_pdcp_data_volume_report_req_t;
typedef struct _rrc_pdcp_data_report_req_t
{
    ue_index_t          ue_index;

    UInt8               report_complete_ue;
    /*^ M, 0, H, 0, 1 ^*/

    counter_t           num_secondary_data_volume_report;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_data_volume_report_req_t   drb_data_volume_req[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DATA_VOLUME_REPORT_REQ_TAG ^*/
}rrc_pdcp_data_report_req_t; /*^ API,RRC_PDCP_DATA_VOLUME_REPORT_REQ ^*/

/******************************************************************************
* PDCP_RRC_DATA_VOLUME_REPORT_RESP
******************************************************************************/
#define RRC_PDCP_MAX_USAGE_COUNT	18446744073709551615ULL

typedef struct _rrc_pdcp_data_volume_report_resp_t
{
	drb_id_t 		drb_id; 
	/*^ M, 0, B, MIN_DRB, MAX_RB ^*/
	UInt64			usage_count_ul; 
	/*^ M, 0, H, 0, RRC_PDCP_MAX_USAGE_COUNT ^*/
	UInt64			usage_count_dl; 
	/*^ M, 0, H, 0, RRC_PDCP_MAX_USAGE_COUNT ^*/
}rrc_pdcp_data_volume_report_resp_t;

typedef struct _rrc_pdcp_data_report_resp_t
{
    ue_index_t      ue_index;

    rrc_response_t      response;
    /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */

    counter_t           num_secondary_data_volume_report;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_data_volume_report_resp_t   drb_data_volume_report[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_DATA_VOLUME_REPORT_RESP_TAG ^*/
}rrc_pdcp_data_report_resp_t;/*^ API, PDCP_RRC_DATA_VOLUME_REPORT_RESP ^*/
/******************************************************************************
* RRC_PDCP_CHANGE_CELL_REQ
******************************************************************************/
typedef struct _rrc_pdcp_change_cell_req_t
{
    ue_index_t      ue_index;

    cell_index_t    new_cell_index;
}rrc_pdcp_change_cell_req_t;/*^ API, RRC_PDCP_CHANGE_CELL_REQ ^*/

/******************************************************************************
* PDCP_RRC_CHANGE_CELL_RESP
******************************************************************************/
typedef struct _pdcp_rrc_change_cell_resp_t
{
    ue_index_t        ue_index;

    rrc_response_t    response;
    /*^ M, 0, H, 0, 1 ^*/ /* rrc_pdcp_return_et */
}pdcp_rrc_change_cell_resp_t;/*^ API, PDCP_RRC_CHANGE_CELL_RESP ^*/
/*Traffic Inactivity Timer Support changes Start*/

/*LC-DRB MAP changes start*/
/******************************************************************************
* RRC_PDCP_DRBID_LCID_MAP_IND 
* This message is only required at UESIM (between L3SIM and PDCP-Adapter)
******************************************************************************/
#define DRB_LC_MAP_COUNT              29

typedef struct _drb_lc_map_info_t
{
	drb_id_t 		drb_id; 
	/*^ M, 0, B, MIN_DRB, MAX_RB ^*/
	drb_id_t 		lc_id; 
	/*^ M, 0, B, MIN_DRB, MAX_RB ^*/
} drb_lc_map_info_t;

typedef struct _rrc_pdcp_drbid_lcid_map_ind_t
{
    ue_index_t        ue_index;
    
    drb_id_t          drb_count;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/
    
    drb_lc_map_info_t   drb_lc_info[DRB_LC_MAP_COUNT]; 
    /*^ TLV, SEQUENCE, RRC_PDCP_INACTIVE_UE_INFO_TAG ^*/

}rrc_pdcp_drbid_lcid_map_ind_t;/*^ API, RRC_PDCP_DRBID_LCID_MAP_IND ^*/
/*LC-DRB MAP changes end*/
/******************************************************************************
* PDCP_RRC_TRAFFIC_INACTIVITY_IND
******************************************************************************/
typedef struct _pdcp_rrc_traffic_inactivity_ind_t
{
    ue_index_t              ue_index;

    counter_t               num_drb_list;
    /*^ M, 0, TLV_SEQUENCE_COUNTER, NOT_PRESENT_IN_MESSAGE ^*/

    rrc_pdcp_rb_entity_t    drb_id_list[MAX_DRB];
    /*^ TLV, SEQUENCE, RRC_PDCP_RB_ENTITY_TAG ^*/
} pdcp_rrc_traffic_inactivity_ind_t; /*^ API, PDCP_RRC_TRAFFIC_INACTIVITY_IND ^*/
/*Traffic Inactivity Timer Support changes End*/
#endif /* _L3_PDCP_INTF_H_ */

