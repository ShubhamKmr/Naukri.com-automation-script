/*******************************************************************************
 *                                                                             *
 * ARICENT -                                                                   *
 *                                                                             *
 * Copyright (C) 2018 Aricent Inc. All Rights Reserved.                        *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   FILE NAME: duoam_rlc_intf.h                                               *
 *                                                                             *
 *   DESCRIPTION: Definitions for Interface between the RLC layer and          *
 *                DUOAM stack entity at DU                                     *
 *                                                                             *
 *       DATE         AUTHOR       REFERENCE           REASON                  *
 *   --------------------------------------------------------------------------*
 *   08 June 2018    Chirantan    RLC API v0.3      Initial draft              *
 *                                                                             *
 *                                                                             *
 ******************************************************************************/

#ifndef _DUOAM_RLC_INTF_H_
#define _DUOAM_RLC_INTF_H_

/*******************************************************************************
 * Project Includes
 ****************************************************************************/
#include <cspl.h>
#include "gnb_types.h"
#include "du_types.h"
#include "gnb_defines.h"


/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Types
 ****************************************************************************/
/* RLC DUOAM API IDs */
#define DUOAM_RLC_MESSAGE_API_START            (0x0000)
#define RLC_DUOAM_INIT_IND                     (DUOAM_RLC_MESSAGE_API_START + 0)
#define DUOAM_RLC_PROVISIONING_REQ             (DUOAM_RLC_MESSAGE_API_START + 1)
#define RLC_DUOAM_PROVISIONING_RESP            (DUOAM_RLC_MESSAGE_API_START + 2)
#define DUOAM_RLC_CLEANUP_REQ                  (DUOAM_RLC_MESSAGE_API_START + 3)
#define RLC_DUOAM_CLEANUP_RESP                 (DUOAM_RLC_MESSAGE_API_START + 4)
#define DUOAM_RLC_PROC_SUP_REQ                 (DUOAM_RLC_MESSAGE_API_START + 5)
#define RLC_DUOAM_PROC_SUP_RESP                (DUOAM_RLC_MESSAGE_API_START + 6)
#define DUOAM_RLC_SET_LOG_LEVEL_IND            (DUOAM_RLC_MESSAGE_API_START + 7)
#define DUOAM_RLC_GET_LOG_LEVEL_REQ            (DUOAM_RLC_MESSAGE_API_START + 8)
#define RLC_DUOAM_GET_LOG_LEVEL_RESP           (DUOAM_RLC_MESSAGE_API_START + 9)
#define DUOAM_RLC_ENABLE_LOG_CATEGORY_IND      (DUOAM_RLC_MESSAGE_API_START + 10)
#define DUOAM_RLC_DISABLE_LOG_CATEGORY_REQ     (DUOAM_RLC_MESSAGE_API_START + 11)
#define DUOAM_RLC_GET_LOG_CATEGORY_REQ         (DUOAM_RLC_MESSAGE_API_START + 12)
#define RLC_DUOAM_GET_LOG_CATEGORY_RESP        (DUOAM_RLC_MESSAGE_API_START + 13)
#define DUOAM_RLC_GET_STATS_REQ                (DUOAM_RLC_MESSAGE_API_START + 14)
#define RLC_DUOAM_GET_STATS_RESP               (DUOAM_RLC_MESSAGE_API_START + 15)
#define DUOAM_RLC_RESET_STATS_REQ              (DUOAM_RLC_MESSAGE_API_START + 16)
#define RLC_DUOAM_RESET_STATS_RESP             (DUOAM_RLC_MESSAGE_API_START + 17)
#define DUOAM_RLC_GET_STATUS_REQ               (DUOAM_RLC_MESSAGE_API_START + 18)
#define RLC_DUOAM_GET_STATUS_RESP              (DUOAM_RLC_MESSAGE_API_START + 19)
#define DUOAM_RLC_CONFIG_PERF_STATS_REQ        (DUOAM_RLC_MESSAGE_API_START + 20)
#define RLC_DUOAM_CONFIG_PERF_STATS_RESP       (DUOAM_RLC_MESSAGE_API_START + 21)
#define RLC_DUOAM_UE_PERF_STATS_IND            (DUOAM_RLC_MESSAGE_API_START + 22)
#define DUOAM_RLC_GET_UE_PERF_STATS_REQ        (DUOAM_RLC_MESSAGE_API_START + 23)
#define RLC_DUOAM_GET_UE_PERF_STATS_RESP       (DUOAM_RLC_MESSAGE_API_START + 24)
#define DUOAM_RLC_GET_DEBUG_INFO_REQ           (DUOAM_RLC_MESSAGE_API_START + 25)
#define RLC_DUOAM_GET_DEBUG_INFO_RESP          (DUOAM_RLC_MESSAGE_API_START + 26)
#define RLC_MAX_DUOAM_API                      (RLC_DUOAM_GET_DEBUG_INFO_RESP)

/* Macros for MAX IP Address length */
/*  These macros can be moved to gnb_defines.h */
#define IPV4_ADDRESS_LENGTH     16
#define IPV6_ADDRESS_LENGTH     40
#define MAX_RLC_WORKER_THREADS  10

/*  This need to be moved to DU specific common file */
#define DU_MAX_UE_SUPPORTED       1205
#define MAX_DU_MANAGER_UE_INDEX   0xFFFF

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * RLC_DUOAM_INIT_IND API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */

/****************************************************************************
 * DUOAM_RLC_PROVISIONING_REQ API - Mandatory parameters structure definition
 ****************************************************************************/
typedef enum 
{
    RLC_GBR = 0,
    RLC_NGBR
} rlc_logical_channel_type_et;

/* possible time in milliseconds for timeout for reassembly */
typedef enum {
    rms0 = 0,
    rms5 = 5,
    rms10 = 10,
    rms15 = 15,
    rms20 = 20,
    rms25 = 25,
    rms30 = 30,
    rms35 = 35,
    rms40 = 40,
    rms45 = 45,
    rms50 = 50,
    rms55 = 55,
    rms60 = 60,
    rms65 = 65,
    rms70 = 70,
    rms75 = 75,
    rms80 = 80,
    rms85 = 85,
    rms90 = 90,
    rms95 = 95,
    rms100 = 100,
    rms110 = 110,
    rms120 = 120,
    rms130 = 130,
    rms140 = 140,
    rms150 = 150,
    rms160 = 160,
    rms170 = 170,
    rms180 = 180,
    rms190 = 190,
    rms200 = 200
} t_reassembly_timer_et;

/* possible byte size */
typedef enum {
    pbkb1=1,
    pbkb2=2,
    pbkb5=5,
    pbkb8=8,
    pbkb10=10,
    pbkb15=15,
    pbkb25 = 25,
    pbkb50 = 50,
    pbkb75 = 75,
    pbkb100 = 100,
    pbkb125 = 125,
    pbkb250 = 250,
    pbkb375 = 375,
    pbkb500 = 500,
    pbkb750 = 750,
    pbkb1000 = 1000,
    pbkb1250 = 1250,
    pbkb1500 = 1500,
    pbkb2000 = 2000,
    pbkb3000 = 3000,
    pbkB4000 = 4000,
    pbkB4500 = 4500,
    pbkB5000 = 5000,
    pbkB5500 = 5500,
    pbkB6000 = 6000,
    pbkB6500 = 6500,
    pbkB7000 = 7000,
    pbkB7500 = 7500,
    pbmB8 = 8000,
    pbmB9 = 9000,
    pbmB10 = 10000,
    pbmB11 = 11000,
    pbmB12 = 12000,
    pbmB13 = 13000,
    pbmB14 = 14000,
    pbmB15 = 15000,
    pbmB16 = 16000,
    pbmB17 = 17000,
    pbmB18 = 18000,
    pbmB20 = 20000,
    pbmB25 = 25000,
    pbmB30 = 30000,
    pbmB40 = 40000,
    pbkbinfinity = 40001
} t_pb_poll_byte_et;

/* possible size of PDU */
typedef enum {
    p_pdu4 = 4,
    p_pdu8 = 8,
    p_pdu16 = 16,
    p_pdu32 = 32,
    p_pdu64 = 64,
    p_pdu128 = 128,
    p_pdu256 = 256,
    p_pdu512 = 512,
    p_pdu1024 = 1024,
    p_pdu2048 = 2048,
    p_pdu4096 = 4096,
    p_pdu6144 = 6144,
    p_pdu8192 = 8192,
    p_pdu12288 = 12288,
    p_pdu16384 = 16384,
    p_pdu20480 = 20480,
    p_pdu24576 = 24576,
    p_pdu28672 = 28672,
    p_pdu32768 = 32768,
    p_pdu40960 = 40960,
    p_pdu49152 = 49152,
    p_pdu57344 = 57344,
    p_pdu65536 = 65536,
    p_pduInfinity = 65537
} t_poll_pdu_et ;


#if 0

typedef struct _communication_info_t
{
#define COMMUNICATION_INFO_IPV4_ADDR_PRESENT   0x01
#define COMMUNICATION_INFO_IPV6_ADDR_PRESENT   0x02

    /* Bitmask indicating presence of optional parameters */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Port to be used for communication */
    UInt16      port;
    /*^ M, 0, N, 0, 0 ^*/

    UInt8       ipv4_addr[IPV4_ADDRESS_LENGTH];
    /*^ O, COMMUNICATION_INFO_IPV4_ADDR_PRESENT, OCTET_STRING, FIXED ^*/

    UInt8       ipv6_addr[IPV6_ADDRESS_LENGTH];
    /*^ O, COMMUNICATION_INFO_IPV6_ADDR_PRESENT, OCTET_STRING, FIXED ^*/

} communication_info_t;
#endif

typedef struct _rlc_peer_comm_info_t
{
#define COMM_INFO_DATA_BUFFER_SIZE_PRESENT    0x01

    /* bitmask indicating the presence of optional fields */
    bitmask_t             bitmask;
    /*^ BITMASK ^*/

    /* Self IP/Port used by RLC */
    communication_info_t  self_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* Destination IP/Port used by RLC */
    communication_info_t  peer_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* Maximum Number of Bytes to be received */
    UInt16      data_buffer_size;
    /*^ O, COMM_INFO_DATA_BUFFER_SIZE_PRESENT , B, 1500, 65535 ^*/

} rlc_peer_comm_info_t;


typedef struct _rlc_communication_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t              bitmask;
    /*^ BITMASK ^*/

    /* IP/Port used by RLC for communication with DU Mgr */
    rlc_peer_comm_info_t   dumgr_comm_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* IP/Port used by RLC for communication with F1U */
    rlc_peer_comm_info_t   f1u_comm_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* IP/Port used by RLC for communication with MAC */
    rlc_peer_comm_info_t   mac_comm_info;
    /*^ M, 0, N, 0, 0 ^*/
    

} rlc_communication_info_t;


typedef struct _rlc_qos_qci_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t              bitmask;
    /*^ BITMASK ^*/

    /* QCI of the logical channel */
    UInt8                  qci;
    /*^ M, 0, H, 0, 255 ^*/

    /* Resource type of the logical channel GBR/NGBR
     * (rlc_logical_channel_type_et) */
    UInt8                  res_type;
    /*^ M, 0, H, 0, 1 ^*/

    /* Priority of the logical channel */
    UInt8                  priority;
    /*^ M, 0, B, 1, 9 ^*/

    /* Packet loss rate  */
    UInt8                  pktErrLossRate;
    /*^ M, 0, H, 0, 6 ^*/ 

    /* Packet delay budget of the logical channel (in msec) */
    UInt16                 pktDlyBdgt;
    /*^ M, 0, B, 50, 300 ^*/

} rlc_qos_qci_info_t;


typedef struct _rlc_qos_qci_info_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t             bitmask;
    /*^ BITMASK ^*/

    /* Number of QCIs in the list, currently QCI 1-9 are supported */
    UInt16                count;
    /*^ M, 0, B, 1, 256 ^*/

    /* Information for a specific QCI */
    rlc_qos_qci_info_t    rlcQosQciInfo[MAX_QCI];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_qos_qci_info_list_t;


typedef struct _duoam_rlc_provisioning_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* Log Level 
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG), 
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG), 
     * 64 (DETAILED ALL) 
     * If a higher level log level set, lower values will also be set. For
     * example if ERROR is set then FATAL will also be enabled */
    UInt8                     log_level;
    /*^ M, 0, H, 0, 127 ^*/

    /* Q_Size_factor of logical channel which used GBR type 
     * of resources. */
    UInt8                     qSizeFactorGBR;
    /*^ M, 0, B, 1, 6 ^*/

    /* Q_Size_factor of logical channel which used NGBR type 
     * of resources. */
    UInt8                     qSizeFactorNGBR;
    /*^ M, 0, N, 1, 6 ^*/

    /* Number of worker threads to be spawned in RLC */
    UInt8                     numWorkerThreads;
    /*^ M, 0, B, 1, MAX_RLC_WORKER_THREADS  ^*/

    /* Core Number of worker threads to be spawned in RLC */
    UInt8                     core_num_worker_thread;
    /*^ M, 0, N, 0, 0 ^*/

    /* Health status monitoring check interval (in sec) */
    UInt16                    healthMonitoringTimeInterval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt64                    log_category;
    /*^ M, 0, N, 0, 0 ^*/

    /* QCI table information elements */
    rlc_qos_qci_info_list_t   rlc_qos_qci_list;
    /*^ M, 0, N, 0, 0 ^*/

    /* Communication info (IP/Port) used by RLC for communication
     * with other modules in DU */
    rlc_communication_info_t  communicationInfo;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_rlc_provisioning_req_t;    /*^ API, DUOAM_RLC_PROVISIONING_REQ ^*/


/*******************************************************************************
 * RLC_DUOAM_PROVISIONING_RESP
 ******************************************************************************/
typedef struct _rlc_duoam_provisioning_resp_t
{
#define RLC_DUOAM_PROVISIONING_RESP_CAUSE_PRESENT  0x01

    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Response code */
    UInt8       response;
    /*^ M, 0, N, 0, 1 ^*/ 

    /* Cause indicating the reason for failure */
    UInt16       cause;
    /*^ O, RLC_DUOAM_PROVISIONING_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_duoam_provisioning_resp_t;    /*^ API, RLC_DUOAM_PROVISIONING_RESP ^*/


/****************************************************************************
 * DUOAM_RLC_CLEANUP_REQ API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * RLC_DUOAM_CLEANUP_RESP
 ******************************************************************************/
typedef struct _rlc_duoam_cleanup_resp_t
{
#define RLC_CLEANUP_FAIL_CAUSE_PRESENT  0x01

    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Response code */
    UInt16      response;
    /*^ M, 0, N, 0, 1 ^*/ 

   /* Error code, in case of failure, indicating reason for failure */
    UInt16               cause;
    /*^ O, RLC_CLEANUP_FAIL_CAUSE_PRESENT , N, 0, 0 ^*/

} rlc_duoam_cleanup_resp_t;    /*^ API, RLC_DUOAM_CLEANUP_RESP ^*/


/****************************************************************************
 * DUOAM_RLC_PROC_SUP_REQ API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/****************************************************************************
 * RLC_DUOAM_PROC_SUP_RESP API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * DUOAM_RLC_SET_LOG_LEVEL_IND API 
 ******************************************************************************/
typedef struct _duoam_rlc_set_log_level_ind_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG), 
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG), 
     * 64 (DETAILED ALL) */
    UInt8       log_level;
    /*^ M, 0, H, 0, 127 ^*/

} duoam_rlc_set_log_level_ind_t;    /*^ API, DUOAM_RLC_SET_LOG_LEVEL_IND ^*/


/*******************************************************************************
 * DUOAM_RLC_GET_LOG_LEVEL_REQ API 
 ******************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * RLC_DUOAM_GET_LOG_LEVEL_RESP API 
 ******************************************************************************/
typedef struct _rlc_duoam_get_log_level_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG), 
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG), 
     * 64 (DETAILED ALL) */
    UInt8       log_level;
    /*^ M, 0, H, 0, 127 ^*/

} rlc_duoam_get_log_level_resp_t;    /*^ API, RLC_DUOAM_GET_LOG_LEVEL_RESP ^*/


/*******************************************************************************
 *  DUOAM_RLC_ENABLE_LOG_CATEGORY_IND 
 ******************************************************************************/
typedef struct _duoam_rlc_enable_log_category_ind_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt64      log_category;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_rlc_enable_log_category_ind_t;   /*^ API, DUOAM_RLC_ENABLE_LOG_CATEGORY_IND ^*/


/*******************************************************************************
 *  DUOAM_RLC_DISABLE_LOG_CATEGORY_REQ 
 ******************************************************************************/
typedef struct _duoam_rlc_disable_log_category_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt64      log_category;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_rlc_disable_log_category_req_t;   /*^ API, DUOAM_RLC_DISABLE_LOG_CATEGORY_REQ ^*/


/****************************************************************************
 * DUOAM_RLC_GET_LOG_CATEGORY_REQ API 
 ****************************************************************************/
/* No Payload Required */


/****************************************************************************
 * RLC_DUOAM_GET_LOG_CATEGORY_RESP API 
 ****************************************************************************/
typedef struct _rlc_duoam_get_log_category_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    UInt64     log_category;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_duoam_get_log_category_resp_t;   /*^ API, RLC_DUOAM_GET_LOG_CATEGORY_RESP ^*/


/*******************************************************************************
 * DUOAM_RLC_GET_STATS_REQ 
 ******************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * RLC_DUOAM_GET_STATS_RESP  
 ******************************************************************************/
typedef struct _rlc_um_stat_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt32      rxUmdSduDiscarded;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      txUmdPdu;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      rxUmdPdu;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      rxUmdSduTxUL;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      rxIncompleteUmdSduDiscarded;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      rxUmdPduDropped;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      umdSduReceivedFromF1U;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      umdSduTransmittedToMac;
    /*^ M, 0, N, 0, 4294967295 ^*/

} rlc_um_stat_info_t;


typedef struct _rlc_am_stat_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt32      amdPduTransmitted;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      amdPduReceived;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      amdPduDropped;
    /*^ M, 0, N, 0, 4294967295 ^*/
    
    UInt32      amdIncompSduDiscard;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      amdSduReceivedFromF1U;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      amdSduTransmittedToF1U;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      amdSduDropped;
    /*^ M, 0, N, 0, 4294967295 ^*/
    
    UInt32      amdSduTransmitedToMac;
    /*^ M, 0, N, 0, 4294967295 ^*/

} rlc_am_stat_info_t;


typedef struct _rlc_ue_stats_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt16      crnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32      sduReceivedFromF1U;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      pduTransmittedToMac;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      sduTransmittedToF1U;
    /*^ M, 0, N, 0, 4294967295 ^*/

    UInt32      pduReceivedFromMac;
    /*^ M, 0, N, 0, 4294967295 ^*/

} rlc_ue_stats_t;


typedef struct _rlc_ue_stats_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    UInt16          num_UE;
    /*^ M, 0, N, 1, DU_MAX_UE_SUPPORTED ^*/

    rlc_ue_stats_t  rlcUeStats[DU_MAX_UE_SUPPORTED];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_ue_stats_info_t;


typedef struct _rlc_duoam_get_stats_resp_t
{
#define RLC_DUOAM_GET_STATS_RESP_CAUSE_PRESENT          0x01
#define RLC_DUOAM_GET_STATS_RESP_RLC_UM_STATS_PRESENT   0x02
#define RLC_DUOAM_GET_STATS_RESP_RLC_AM_STATS_PRESENT   0x04
#define RLC_DUOAM_GET_STATS_RESP_RLC_UE_STATS_PRESENT   0x08

    /* Bitmask indicating the presence of optional fields */
    bitmask_t             bitmask;
    /*^ BITMASK ^*/

    /* Reponse code */
    UInt8                 response;
    /*^ M, 0, N, 0, 1 ^*/

    /* Cause indicating reason for failure */
    UInt16                 cause;
    /*^ O, RLC_DUOAM_GET_STATS_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

    rlc_um_stat_info_t    lteUMStat;
    /*^ O, RLC_DUOAM_GET_STATS_RESP_RLC_UM_STATS_PRESENT, N, 0, 0 ^*/

    rlc_am_stat_info_t    lteAMStat;
    /*^ O, RLC_DUOAM_GET_STATS_RESP_RLC_AM_STATS_PRESENT, N, 0, 0 ^*/

    rlc_ue_stats_info_t   lteUEStat;
    /*^ O, RLC_DUOAM_GET_STATS_RESP_RLC_UE_STATS_PRESENT, N, 0, 0 ^*/

} rlc_duoam_get_stats_resp_t;   /*^ API,  RLC_DUOAM_GET_STATS_RESP ^*/


/*******************************************************************************
 * DUOAM_RLC_RESET_STATS_REQ 
 ******************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * RLC_DUOAM_RESET_STATS_RESP 
 ******************************************************************************/
typedef struct _rlc_duoam_reset_stats_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    UInt8          response;
    /*^ M, 0, N, 0, 1 ^*/

} rlc_duoam_reset_stats_resp_t;    /*^ API,  RLC_DUOAM_RESET_STATS_RESP ^*/


/*******************************************************************************
 * DUOAM_RLC_GET_STATUS_REQ 
 ******************************************************************************/
typedef struct _duoam_rlc_get_status_req_t
{
#define RLC_UE_STATUS_REQ_UE_INDEX_PRESENT   0x01

    /* Bitmask indicating the presence of optional fields */
    bitmask_t     bitmask;
    /*^ BITMASK ^*/

    ue_index_t    ue_index;
    /*^ O, RLC_UE_STATUS_REQ_UE_INDEX_PRESENT, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

} duoam_rlc_get_status_req_t;    /*^ API, DUOAM_RLC_GET_STATUS_REQ ^*/


/**************************************************************************
 * RLC_DUOAM_GET_STATUS_RESP 
 *************************************************************************/
typedef struct _rlc_tx_um_entity_status_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* This indicates the sequence number field length configured 
     * for a UM Tx entity. It can either be 6 or 12. */
    UInt8       snFieldLength;
    /*^ M, 0, B, 6, 12 ^*/

    /* txNext is the state variable which holds the value of the SN 
     * to be assigned for the next newly generated UMD PDU. It is 
     * initially set to 0, and is updated whenever the UM RLC entity 
     * delivers an UMD PDU with SN = VT(US). */
    UInt16      txNext;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_tx_um_entity_status_t;


typedef struct _rlc_rx_um_entity_status_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* It indicates the sequence number field length value 
     * configured for a UM Rx entity. It can either be 6 or 12. */
    UInt8       snFieldLength;
    /*^ M, 0, B, 6, 12 ^*/

    /* It indicates the reassembly time period
     * (t_reassembly_timer_et) */
    UInt8       tReassembly;
    /*^ M, 0, H, 0, 200 ^*/

    /* It indicates the state variable which holds the value of 
     * the SN of the earliest UMD PDU that is still considered 
     * for reordering. It is initially set to 0. */
    UInt16      rxNextReassembly;
    /*^ M, 0, N, 0, 0 ^*/

    /* It idicates the state variable which holds the value of 
     * the SN following the SN of the UMD PDU with the highest 
     * SN among received UMD PDU(s), and it serves as the higher 
     * edge of the reordering window. */
    UInt16      rxNextHighest;
    /*^ M, 0, N, 0, 0 ^*/

    /* rxTimerTrigger  is the state variable which holds the 
     * value of the SN following the SN of the UMD PDU which 
     * triggered tReassembly. It is initially set to NULL. */
    UInt16      rxTimerTrigger;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_rx_um_entity_status_t;


typedef struct _rlc_tx_am_entity_status_tT 
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Flag to indicate whether tRetransmit timer is running or
     * not. */
    UInt8       istRetransmitRunning;
    /*^ M, 0, H, 0, 1 ^*/

    /* It indicates the sequence number field length configured 
     * for a Tx entity. It can either be 12 or 18. */
    UInt8       snFieldLength;
    /*^ M, 0, B, 12, 18 ^*/

    /* It indicates threshold value for the entity to retransmit 
     * any AMD PDU. */
    UInt8       maxRetxThreshold;
    /*^ M, 0, B, 1, 32 ^*/

    /* It indicates the number of AMD PDUs sent since the most 
     * recent poll bit was transmitted. */
    UInt16      pduWithoutPoll;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates the state variable which holds the value of 
     * the SN of the next AMD PDU for which a positive acknowledgement 
     * is to be received in-sequence. */
    UInt32      txNextAck;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates state variable which holds the value of the 
     * txNextAck  + AM_Window_Size. */
    UInt32      vtMS;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates state variable which holds the value of the
     * TX_Next_Ack + (AM_Window_Size - 1) upon the most recent 
     * transmission of a RLC data PDU with the poll bit set to 1. */
    UInt32      pollSN;
    /*^ M, 0, N, 0, 0 ^*/

    /* pollPDU is used by the transmitting side of each AM RLC 
     * entity to trigger a poll for every pollPDU PDUs. */
    /* (t_poll_pdu_et) */
    UInt32      pollPDU;
    /*^ M, 0, N, 0, 0 ^*/

    /* pollByte is used by the transmitting side of each AM RLC 
     * entity to trigger a poll for every pollByte bytes. */
    /* (t_pb_poll_byte_et) */
    UInt32      pollByte;
    /*^ M, 0, N, 0, 0 ^*/

    /* txQueueSize indicates the queue load in the transmission 
     * buffer. */
    UInt32      txQueueSize;
    /*^ M, 0, N, 0, 4294967295 ^*/

    /* reTxQueueSize indicates the queue load in the retransmission 
     * buffer. */
    UInt32      reTxQueueSize;
    /*^ M, 0, N, 0, 4294967295 ^*/

    /* rxStatusPduSize indicates the size required by the status PDU */
    UInt32      rxStatusPduSize;
    /*^ M, 0, N, 0, 4294967295 ^*/

} rlc_tx_am_entity_status_t;


typedef struct _rlc_rx_am_entity_status_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* It indicates Rx Entity already triggered sending of 
     * STATUS PDU to Tx Entity */
    UInt8       sendStatusInd;
    /*^ M, 0, H, 0, 1 ^*/

    /* It indicates whether t-Reassembly timer is running 
     * or not. */
    UInt8       isRTimerRunning;
    /*^ M, 0, H, 0, 1 ^*/

    /* It indicates whether tStatusProhibit timer is running 
     * or not. */
    UInt8       isSPTimerRunning;
    /*^ M, 0, H, 0, 1 ^*/

    /* It indicates the sequence number field length configured 
     * for a Rx entity. It can either be 12 or 18. */
    UInt8       snFieldLength;
    /*^ M, 0, B, 12, 18 ^*/

    /* It indicates the state variable which holds the value of
     * the SN following the last in-sequence completely received 
     * AMD PDU. */
    UInt32      rxNext;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32      vrMR;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates the state variable which holds the value of the 
     * SN following the SN of the RLC data PDU which triggered 
     * t-Reordering. */
    UInt32      rxNextStatusTrigger;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates the state variable which holds the highest possible 
     * value of the SN which can be indicated by ACK_SN when a STATUS 
     * PDU needs to be constructed. */
    UInt32      rxHighestStatus;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates the state variable which holds the value of 
     * the SN following the SN of the RLC data PDU with the highest 
     * SN among received RLC data PDUs. */
    UInt32      rxNextHighestRcvd;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_rx_am_entity_status_t;


typedef struct _rlc_am_entity_status_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                      bitmask;
    /*^ BITMASK ^*/

    /* Status of AM transmit entity */
    rlc_tx_am_entity_status_t      txAMEntityStatus;
    /*^ M, 0, N, 0, 0 ^*/

    /* Status of AM receiving entity */
    rlc_rx_am_entity_status_t      rxAMEntityStatus;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_am_entity_status_t;


typedef struct _rlc_um_entity_status_t
{
#define RLC_TX_UM_ENTITY_STATUS_PRESENT    0x01
#define RLC_RX_UM_ENTITY_STATUS_PRESENT    0x02

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                      bitmask;
    /*^ BITMASK ^*/

    /* Status of UM transmit entity */
    rlc_tx_um_entity_status_t      txUMEntityStatus;
    /*^ O, RLC_TX_UM_ENTITY_STATUS_PRESENT , N, 0, 0 ^*/

    /* Status of UM receiving entity */
    rlc_rx_um_entity_status_t      rxUMEntityStatus;
    /*^ O, RLC_RX_UM_ENTITY_STATUS_PRESENT, N, 0, 0 ^*/

} rlc_um_entity_status_t;


typedef struct _rlc_ue_entity_status_t
{
#define RLC_AM_ENTITY_STATUS_PRESENT      0x01
#define RLC_UM_ENTITY_STATUS_PRESENT      0x02

    /* Bitmask indicating the presence of optional fields */ 
    bitmask_t                      bitmask;
    /*^ BITMASK ^*/

    UInt8                          lcId;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/ 

    /* Status of AM entity */
    rlc_am_entity_status_t         amEntityStatus;
    /*^ O, RLC_AM_ENTITY_STATUS_PRESENT, N, 0, 0 ^*/

    /* Status of UM entity */
    rlc_um_entity_status_t         umEntityStatus;
    /*^ O, RLC_UM_ENTITY_STATUS_PRESENT, N, 0, 0 ^*/

} rlc_ue_entity_status_t;


typedef struct _rlc_ue_entity_status_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                      bitmask;
    /*^ BITMASK ^*/

    /* Count of entities for which status is reported */
    UInt8                          numEntities;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* Status of each entity */
    rlc_ue_entity_status_t         rlcUeEntity[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_ue_entity_status_list_t;


typedef struct _rlc_ue_status_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/

    UInt16                          crnti;
    /*^ M, 0, N, 0, 0 ^*/

    rlc_ue_entity_status_list_t     entityList;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_ue_status_t;


typedef struct _rlc_ue_status_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    UInt16              num_UE;
    /*^ M, 0, N, 1, DU_MAX_UE_SUPPORTED ^*/

    rlc_ue_status_t     rlcUEStatus[DU_MAX_UE_SUPPORTED];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_ue_status_list_t;


typedef struct _rlc_duoam_get_status_resp_t
{
#define RLC_DUOAM_GET_STATUS_RESP_CAUSE_PRESENT            0x01
#define RLC_DUOAM_GET_STATUS_RESP_UE_STATUS_LIST_PRESENT   0x02

    /* Bitmask indicating the presence of optional fields */
    bitmask_t              bitmask;
    /*^ BITMASK ^*/

    UInt8                  response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Cause of failure */
    UInt16                  cause;
    /*^ O, RLC_DUOAM_GET_STATUS_RESP_CAUSE_PRESENT, N, 0, 0 ^*/
   
    rlc_ue_status_list_t   rlcUeStatusList;
    /*^ O, RLC_DUOAM_GET_STATUS_RESP_UE_STATUS_LIST_PRESENT, N, 0, 0 ^*/

} rlc_duoam_get_status_resp_t;   /*^ API, RLC_DUOAM_GET_STATUS_RESP ^*/


/*******************************************************************************
 * DUOAM_RLC_CONFIG_PERF_STATS_REQ 
 ******************************************************************************/
typedef struct _duoam_rlc_config_perf_stats_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* It indicates the duration for which PERF STATS need to be provided to
     * DUOAM. The duration range would be from 100 ms to 2000 ms. */ 
    UInt32         duration;
    /*^ M, 0, N, 0, 0 ^*/

    /* It indicates whether Periodic Reporting of PERF STATS is
     * enabled or disabled */
    UInt8          periodicReporting;
    /*^ M, 0, H, 0, 1 ^*/

    /* Bitmask indicating UE Perf Stats that will be reported to the DUOAM */
    UInt32         uePerfStatsToReportBitMap;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_rlc_config_perf_stats_req_t;   /*^ API, DUOAM_RLC_CONFIG_PERF_STATS_REQ ^*/


/*******************************************************************************
 * RLC_DUOAM_CONFIG_PERF_STATS_RESP 
 ******************************************************************************/
typedef struct _rlc_duoam_config_perf_stats_resp_t
{
#define RLC_DUOAM_CONFIG_PERF_STATS_RESP_CAUSE_PRESENT   0x01

    /* Bitmask indicating the presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* Response code i.e. NR_SUCCESS/NR_FAILURE */
    UInt8        response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Reason for failure */
    UInt16        cause;
    /*^ O, RLC_DUOAM_CONFIG_PERF_STATS_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_duoam_config_perf_stats_resp_t;  /*^ API, RLC_DUOAM_CONFIG_PERF_STATS_RESP ^*/


/*******************************************************************************
 * RLC_DUOAM_UE_PERF_STATS_IND 
 ******************************************************************************/
typedef struct rlc_rb_perf_stats_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t     bitmask;
    /*^ BITMASK ^*/

    UInt32        totalDlRLCUMSduTransmitted[MAX_LC];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} rlc_rb_perf_stats_t;


typedef struct _ue_ack_nack_perf_stats_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t     bitmask;
    /*^ BITMASK ^*/

    /* The total number of RLC ACK transmitted in the 
     * downlink direction. */
    UInt32        totalDLRLCAcks;
    /*^ M, 0, N, 0, 0 ^*/

    /* The total number of RLC ACK received in uplink 
     * direction */
    UInt32        totalULRLCAcks;
    /*^ M, 0, N, 0, 0 ^*/

    /* The total number of RLC NACK received in the uplink 
     * direction */
    UInt32        totalULRLCNacks;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_ue_ack_nack_perf_stats_t;


typedef struct _rlc_ue_perf_stats_t
{
#define RLC_UE_PERF_STATS_RB_STATS_PRESENT          0x01
#define RLC_UE_PERF_STATS_ACK_NACK_STATS_PRESENT    0x02

    bitmask_t                     bitmask;
    /*^ BITMASK ^*/
    
    ue_index_t                    ue_index;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32                        totalMaxRetxExceeded;
    /*^ M, 0, N, 0, 0 ^*/

    rlc_rb_perf_stats_t           rlcRbPerfStats;
    /*^ O, RLC_UE_PERF_STATS_RB_STATS_PRESENT, N, 0, 0 ^*/

    rlc_ue_ack_nack_perf_stats_t  ueAckNackPerfStats;
    /*^ O, RLC_UE_PERF_STATS_ACK_NACK_STATS_PRESENT, N, 0, 0 ^*/

} rlc_ue_perf_stats_t;


typedef struct _rlc_ue_perf_stats_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t            bitmask;
    /*^ BITMASK ^*/

    UInt32               count;
    /*^ M, 0, B, 1, DU_MAX_UE_SUPPORTED ^*/

    rlc_ue_perf_stats_t  rlcUePerfStats[DU_MAX_UE_SUPPORTED];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_ue_perf_stats_resp_t;


typedef struct _rlc_duoam_ue_perf_stats_ind_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* It indicates the duration (in msecs) for which PERF STATS need 
     * to be provided to DUOAM. */
    UInt32                    duration;
    /*^ M, 0, N, 0, 0 ^*/

    rlc_ue_perf_stats_resp_t  uePerfStatsResp;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_duoam_ue_perf_stats_ind_t;   /*^ API, RLC_DUOAM_UE_PERF_STATS_IND ^*/


/*******************************************************************************
 * DUOAM_RLC_GET_UE_PERF_STATS_REQ 
 ******************************************************************************/
typedef struct _duoam_rlc_get_ue_perf_stats_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* Flag to indicate if RLC have to reset the value of cumulative stats 
     * counters maintained since the last time the counters were reset. */
    UInt8          resetStats;
    /*^ M, 0, H, 0, 1 ^*/

    /* Bitmask to indicate which all stats need to be reported */
    UInt32         uePerfStatsToGetBitMap;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_rlc_get_ue_perf_stats_req_t;    /*^ API, DUOAM_RLC_GET_UE_PERF_STATS_REQ ^*/


/*******************************************************************************
 * RLC_DUOAM_GET_UE_PERF_STATS_RESP 
 ******************************************************************************/
typedef struct _rlc_duoam_get_ue_perf_stats_resp_t
{
#define RLC_DUOAM_GET_UE_PERF_STATS_RESP_CAUSE_PRESENT          0x01
#define RLC_DUOAM_GET_UE_PERF_STATS_RESP_DURATION_PRESENT       0x02
#define RLC_DUOAM_GET_UE_PERF_STATS_RESP_UE_PERF_STATS_PRESENT  0x04

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* Response code */
    UInt8                     response;
    /*^ M, 0, N, 0, 0 ^*/
   
    /* Cause of failure */
    UInt16                     cause;
    /*^ O,  RLC_DUOAM_GET_UE_PERF_STATS_RESP_CAUSE_PRESENT, N, 0, 0 ^*/
    
    /* It indicates the duration (in msec) for which PERF STATS need to be 
     * provided to DUOAM. */
    UInt32                    duration;
    /*^ O, RLC_DUOAM_GET_UE_PERF_STATS_RESP_DURATION_PRESENT, N, 0, 0 ^*/

    rlc_ue_perf_stats_resp_t  uePerfStatsResp;
    /*^ O, RLC_DUOAM_GET_UE_PERF_STATS_RESP_UE_PERF_STATS_PRESENT, N, 0, 0 ^*/

} rlc_duoam_get_ue_perf_stats_resp_t;   /*^ API, RLC_DUOAM_GET_UE_PERF_STATS_RESP ^*/


/*******************************************************************************
 * DUOAM_RLC_GET_DEBUG_INFO_REQ
 ******************************************************************************/
typedef struct _duoam_rlc_get_debug_info_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* This field informs the type of debugging information needed */
    /* Check Enum DebugInfoType */
    UInt8                     debugInfoType; 
    /*^ M, 0, B, 0, 1 ^*/ 

} duoam_rlc_get_debug_info_req_t;


/*******************************************************************************
 * RLC_DUOAM_GET_DEBUG_INFO_RESP
 ******************************************************************************/
typedef struct RlcPoolStatsT 
{
    /* Size of the buffer allocated in this pool */
    UInt32  bufSize; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Total number of Buffers in this pool */
    UInt32  numOfBuf; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Total number of Buffers allocated from this pool */
    UInt32  numOfAllocBuf; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Peak of Total number of Buffers allocated from
     * this pool during the system is running */
    UInt32  numOfPeakBuf; 
    /*^ M, 0, N, 0, 0 ^*/

} RlcPoolStats;


/* This structure provides the MEM POOL stats */
typedef struct RlcMemPoolStatsT 
{
    /* Stats for each pool */
    RlcPoolStats   stats[NVARPOOL]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} RlcMemPoolStats;

/* This structure provides the MSG POOL stats */
typedef struct RlcMsgPoolStatsT 
{
    /* Stats for each pool */
    RlcPoolStats   stats[NVARPOOL]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    /* QPCTL stats */
    RlcPoolStats   qpctlStats; 
    /*^ M, 0, N, 0, 0 ^*/

    /* QMSG stats */
    RlcPoolStats   qmsgStats; 
    /*^ M, 0, N, 0, 0 ^*/

} RlcMsgPoolStats;


typedef struct _rlc_duoam_get_debug_info_resp
{
#define RLC_DUOAM_GET_DEBUG_INFO_RESP_MEM_POOL_STATS_PRESENT    0x01
#define RLC_DUOAM_GET_DEBUG_INFO_RESP_MSG_POOL_STATS_PRESENT    0x02

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/

    /* Memory Pool Stats */
    RlcMemPoolStats            csplMemPoolStats;
    /*^ O, RLC_DUOAM_GET_DEBUG_INFO_RESP_MEM_POOL_STATS_PRESENT, N, 0, 0  ^*/

    /* Message Pool Stats */
    RlcMsgPoolStats            csplMsgPoolStats;
    /*^ O, RLC_DUOAM_GET_DEBUG_INFO_RESP_MSG_POOL_STATS_PRESENT, N, 0, 0  ^*/

} rlc_duoam_get_debug_info_resp_t;


#endif
