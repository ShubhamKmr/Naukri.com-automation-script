/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name: ylib-squeue.h
 *
 ****************************************************************************
 *
 *  File Description : Header file for non buffered Queue 
 *
 ****************************************************************************/


#ifndef _YLIB_SQUEUE_H_
#define _YLIB_SQUEUE_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include    "gnb_defines.h"
#include    "sync_wrapper.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/
#define MAX_SIZE 0xFFFFFFFF

#define NUM_SEM 1

/****************************************************************************
 * Exported Variables
 ****************************************************************************/
typedef struct nrSNode_t {
    struct nrSNode_t *next;
} NR_SNODE;

typedef struct s_queue_t {
#ifdef UE_SIM_TESTING
    void  *padding1;
    void  *padding2;
#endif
    volatile void *head;
    volatile void *tail;
    volatile UInt64 headcount;
    volatile UInt64 tailcount;
    NR_SEM sem_lock;
} NR_SQUEUE;

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void     sQueueInit(NR_SQUEUE *queue_p);
void     sQueueDeInit(NR_SQUEUE *queue_p);
UInt64   sQueueCount(const NR_SQUEUE *queue_p);
void     printSQueue(NR_SQUEUE *queue_p);
NR_SNODE *popNode(NR_SQUEUE *queue_p);
UInt8    pushNode(NR_SQUEUE *queue_p, NR_SNODE *node_p);
NR_SNODE *getFirstNode(NR_SQUEUE *queue_p);
NR_SNODE *getNextNode(const NR_SNODE *node_p);

#endif
