/*******************************************************************************
 *                                                                             *
 * ARICENT -                                                                   *
 *                                                                             *
 * Copyright (C) 2018 Aricent Inc. All Rights Reserved.                        *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   FILE NAME: intf.h                                               *
 *                                                                             *
 *   DESCRIPTION: Definitions for Interface between the MAC layer and          *
 *                DU Manager stack entity at DU                                *
 *                                                                             *
 *       DATE                      REFERENCE                                   *
 *   --------------------------------------------------------------------------*
 *   23 June 2018                 MAC API v0.1                                 *
 *                                                                             *
 *                                                                             *
 *******************************************************************************/

#ifndef _DUMGR_MAC_INTF_H_
#define _DUMGR_MAC_INTF_H_

/*******************************************************************************
 * Project Includes
 ****************************************************************************/
#include "du_comm_intf_defn.h"
/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Project Constants
 ****************************************************************************/
/* DUMGR - MAC API IDs */
#define DUMGR_MAC_MESSAGE_API_START             0x0000 // TBD
#define DUMGR_MAC_CELL_CONFIG_REQ               (DUMGR_MAC_MESSAGE_API_START + 0)
#define MAC_DUMGR_CELL_CONFIG_RESP              (DUMGR_MAC_MESSAGE_API_START + 1)
#define DUMGR_MAC_CELL_START_REQ                (DUMGR_MAC_MESSAGE_API_START + 2)
#define MAC_DUMGR_CELL_START_RESP               (DUMGR_MAC_MESSAGE_API_START + 3)
#define DUMGR_MAC_CELL_STOP_REQ                 (DUMGR_MAC_MESSAGE_API_START + 4)
#define MAC_DUMGR_CELL_STOP_RESP                (DUMGR_MAC_MESSAGE_API_START + 5)
#define DUMGR_MAC_CELL_DELETE_REQ               (DUMGR_MAC_MESSAGE_API_START + 6)
#define MAC_DUMGR_CELL_DELETE_RESP              (DUMGR_MAC_MESSAGE_API_START + 7)
#define DUMGR_MAC_CREATE_UE_ENTITY_REQ          (DUMGR_MAC_MESSAGE_API_START + 8)
#define MAC_DUMGR_CREATE_UE_ENTITY_RESP         (DUMGR_MAC_MESSAGE_API_START + 9)
#define DUMGR_MAC_RECONFIG_UE_ENTITY_REQ        (DUMGR_MAC_MESSAGE_API_START + 10)
#define MAC_DUMGR_RECONFIG_UE_ENTITY_RESP       (DUMGR_MAC_MESSAGE_API_START + 11)
#define DUMGR_MAC_DELETE_UE_ENTITY_REQ          (DUMGR_MAC_MESSAGE_API_START + 12)
#define MAC_DUMGR_DELETE_UE_ENTITY_RESP         (DUMGR_MAC_MESSAGE_API_START + 13)
#define DUMGR_MAC_RACH_RESOURCE_REQ             (DUMGR_MAC_MESSAGE_API_START + 14)
#define MAC_DUMGR_RACH_RESOURCE_RESP            (DUMGR_MAC_MESSAGE_API_START + 15)
#define DUMGR_MAC_RACH_RESOURCE_REL_IND         (DUMGR_MAC_MESSAGE_API_START + 16)
#define DUMGR_MAC_RESET_UE_ENTITY_REQ           (DUMGR_MAC_MESSAGE_API_START + 17)
#define MAC_DUMGR_RESET_UE_ENTITY_RESP          (DUMGR_MAC_MESSAGE_API_START + 18)
#define DUMGR_MAC_CELL_RECONFIG_REQ             (DUMGR_MAC_MESSAGE_API_START + 19)
#define MAC_DUMGR_CELL_RECONFIG_RESP            (DUMGR_MAC_MESSAGE_API_START + 20)
#define DUMGR_MAC_PURGE_CELL_UES_REQ            (DUMGR_MAC_MESSAGE_API_START + 21)
#define MAC_DUMGR_PURGE_CELL_UES_RESP           (DUMGR_MAC_MESSAGE_API_START + 22)
#define MAC_DUMGR_UL_CCCH_MSG_IND               (DUMGR_MAC_MESSAGE_API_START + 23)
#define DUMGR_MAC_DL_CCCH_MSG_IND               (DUMGR_MAC_MESSAGE_API_START + 24)
#define MAC_DUMGR_SI_MSG_IND                    (DUMGR_MAC_MESSAGE_API_START + 25)
#define MAC_DUMGR_UE_SYNC_IND                   (DUMGR_MAC_MESSAGE_API_START + 26)
#define MAC_DUMGR_PERIODIC_STATS_IND            (DUMGR_MAC_MESSAGE_API_START + 27)
#define DUMGR_MAC_PCCH_MSG_IND                  (DUMGR_MAC_MESSAGE_API_START + 28)
#define MAC_DUMGR_SFN_SLOT_IND                  (DUMGR_MAC_MESSAGE_API_START + 29)
#define MAC_DUMGR_SFN_ERR_IND                   (DUMGR_MAC_MESSAGE_API_START + 30)
#define MAC_DUMGR_BEAM_SWITCH_IND               (DUMGR_MAC_MESSAGE_API_START + 31)
#define DUMGR_MAC_MESSAGE_API_END               (MAC_DUMGR_BEAM_SWITCH_IND)
/* DUMGR_MAC_MESSAGE_API_END + 1 = MAC_MAC_SCELL_ADD_REQ
   DUMGR_MAC_MESSAGE_API_END + 1 = MAC_MAC_SCELL_DEL_REQ
   DUMGR_MAC_MESSAGE_API_END + 1 = MAC_MAC_SCELL_RECONF_REQ 
   are used internally in MAC
*/

typedef enum {
    RACH_BFR = 0,
    TCI_SWITCH = 1
}beam_cause_et;
typedef UInt8 beam_cause_t;

/****************************************************************************
 * Project Structures
 ****************************************************************************/
/******************************************************************************
 *  API: DUMGR_MAC_CELL_CONFIG_REQ
*******************************************************************************/

typedef struct _dumgr_mac_cell_config_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/

    cell_init_params_t              cell_init_params;
    /*^ M, 0, N, 0, 0 ^*/

    phy_layer_params_t              phy_layer_params;
    /*^ M, 0, N, 0, 0 ^*/

    mac_layer_params_t              mac_layer_params;
    /*^ M, 0, N, 0, 0 ^*/

    phy_vendor_specific_params_t      phy_vendor_specific_params;
    /*^ M, 0, N, 0, 0 ^*/
} dumgr_mac_cell_config_req_t; /*^ API, DUMGR_MAC_CELL_CONFIG_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_CELL_CONFIG_RESP
*******************************************************************************/
typedef struct _mac_dumgr_cell_config_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/
#define MAC_CELL_CONFIG_FAIL_CAUSE_PRESENT     0x0001
    UInt16                          responseCode;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                          cause;
    /*^ O, MAC_CELL_CONFIG_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
} mac_dumgr_cell_config_resp_t; /*^ API, MAC_DUMGR_CELL_CONFIG_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_CELL_RECONFIG_REQ
*******************************************************************************/

#define MAC_CELL_RECONFIG_CELL_INIT_PARAMS              0x01
#define MAC_CELL_RECONFIG_PHY_LAYER_PARAMS              0x02
#define MAC_CELL_RECONFIG_MAC_LAYER_PARAMS              0x04
#define MAC_CELL_RECONFIG_PHY_VENDOR_SPECIFIC_PARAMS    0x08

typedef struct _dumgr_mac_cell_reconfig_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/

    reconfig_cell_init_params_t              cell_init_params;
    /*^ O, MAC_CELL_RECONFIG_CELL_INIT_PARAMS, N, 0, 0 ^*/

    reconfig_phy_layer_params_t              phy_layer_params;
    /*^ O, MAC_CELL_RECONFIG_PHY_LAYER_PARAMS, N, 0, 0 ^*/

    reconfig_mac_layer_params_t              mac_layer_params;
    /*^ O, MAC_CELL_RECONFIG_MAC_LAYER_PARAMS, N, 0, 0 ^*/

    reconfig_phy_vendor_specific_params_t      phy_vendor_specific_params;
    /*^ O, MAC_CELL_RECONFIG_PHY_VENDOR_SPECIFIC_PARAMS, N, 0, 0 ^*/
} dumgr_mac_cell_reconfig_req_t; /*^ API, DUMGR_MAC_CELL_RECONFIG_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_CELL_RECONFIG_RESP
*******************************************************************************/
typedef struct _mac_dumgr_cell_reconfig_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/
#define MAC_CELL_RECONFIG_FAIL_CAUSE_PRESENT     0x0001
    UInt16                              responseCode;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                               cause;
    /*^ O, MAC_CELL_RECONFIG_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
} mac_dumgr_cell_reconfig_resp_t; /*^ API, MAC_DUMGR_CELL_RECONFIG_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_CELL_START_REQ
*******************************************************************************/
typedef struct _dumgr_mac_cell_start_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/
#define MAC_PHY_CELL_ID_PRESENT   0x0001

    /* Indicates reconfiguration of physical cell identity from CU.
     * Reference 38.473 section 8.2.3, 8.2.4, 8.2.5 */
    nr_pci_t                              phy_cell_id;
    /*^ O, MAC_PHY_CELL_ID_PRESENT, H, 0, 1007 ^*/

} dumgr_mac_cell_start_req_t; /*^ API, DUMGR_MAC_CELL_START_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_CELL_START_RESP
*******************************************************************************/
typedef struct _mac_dumgr_cell_start_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/
#define MAC_CELL_START_FAIL_CAUSE_PRESENT     0x0001
    UInt16                              responseCode;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                               cause;
    /*^ O, MAC_CELL_START_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
} mac_dumgr_cell_start_resp_t; /*^ API, MAC_DUMGR_CELL_START_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_CELL_STOP_REQ
*******************************************************************************/
typedef struct _dumgr_mac_cell_stop_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/

} dumgr_mac_cell_stop_req_t; /*^ API, DUMGR_MAC_CELL_STOP_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_CELL_STOP_RESP
*******************************************************************************/
typedef struct _mac_dumgr_cell_stop_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask;
    /*^ BITMASK ^*/
#define MAC_CELL_STOP_FAIL_CAUSE_PRESENT     0x0001
    UInt16                              responseCode;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                              cause;
    /*^ O, MAC_CELL_STOP_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
} mac_dumgr_cell_stop_resp_t; /*^ API, MAC_DUMGR_CELL_STOP_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_CELL_DELETE_REQ
********************************************************************************/
typedef struct _dumgr_mac_cell_delete_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/
}dumgr_mac_cell_delete_req_t; /*^ API, DUMGR_MAC_CELL_DELETE_REQ ^*/

/*******************************************************************************
 *  API: MAC_DUMGR_CELL_DELETE_RESP
*****************************************************************************/
typedef struct  _mac_dumgr_cell_delete_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/
#define MAC_CELL_DELETE_FAIL_CAUSE_PRESENT     0x0001
    UInt16                              responseCode;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                               cause;
    /*^ O, MAC_CELL_DELETE_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
}mac_dumgr_cell_delete_resp_t; /*^ API, MAC_DUMGR_CELL_DELETE_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_RACH_RESOURCE_REQ
*******************************************************************************/

    
typedef struct _dumgr_mac_rach_resource_req_t
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/
#define MAC_CFRA_SSB_RESOURCE_PRESENT     0x0001

   /* ue_index is the index allocated by DU-Manager and shared between 
    *  all Layer 2 DU modules */
   ue_index_t  ue_index;
   /*^ M, 0, H, 0, 65534 ^*/

   cfra_ssb_index_t cfra_ssb_index;
   /*^ O, MAC_CFRA_SSB_RESOURCE_PRESENT, N, 0, 0 ^*/
}dumgr_mac_rach_resource_req_t; /*^ API, DUMGR_MAC_RACH_RESOURCE_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_RACH_RESOURCE_RESP
*******************************************************************************/
typedef struct _mac_dumgr_rach_resource_resp_t 
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t   bitmask;
  /*^ BITMASK ^*/
#define  MAC_CFRA_RNTI_PRESENT 					0x0001
#define  MAC_CFRA_RESOURCE_PRESENT 				0x0002
#define  MAC_RACH_RES_RESP_FAIL_CAUSE_PRESENT	0x0004

  /* ue_index is the index allocated by DU-Manager and shared between 
   *  all Layer 2 DU modules */
  ue_index_t  ue_index;
  /*^ M, 0, H, 0, 65534 ^*/

  /* Success or Failure NR_FAILURE=0 ,NR_SUCCESS=1 */
  UInt16  response;
  /*^ M, 0, H, 0, 1 ^*/


  /* rnti allocated for the UE for which context is to be created. This parameter is mandatorily present if response is NR_SUCCESS */
  UInt16 rnti;
  /*^ O, MAC_CFRA_RNTI_PRESENT, B, 1, 65519 ^*/

  /*Structure List of the CRFA resources*/
  /* ! Reference 3GPP TS 38.331 CFRA. Only 1 CFRA resource will be allocated in current release
   * Mac will try to allocate CFRA for the best ssb-index (first in list received from DU-MGR)
   * If no CFRA present for the best ssb-index, then allocation will be attempted for the next ssb-index in the received list is used
   * This parameter is mandatorily present in current release if response is NR_SUCCESS ! */
  cfra_resource_info_t cfra_resource_info;
  /*^ O, MAC_CFRA_RESOURCE_PRESENT, N, 0, 0 ^*/

  /* An error code, in case of NR_FAILURE, indicating reason for failure*/

  UInt16 cause;	
  /*^ O, MAC_RACH_RES_RESP_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
}mac_dumgr_rach_resource_resp_t; /*^ API, MAC_DUMGR_RACH_RESOURCE_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_RACH_RESOURCE_REL_IND
*******************************************************************************/
typedef struct _dumgr_mac_rach_resource_rel_ind_t
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t   bitmask;
  /*^ BITMASK ^*/

  /*0 - MAX_DU_MANAGER_UE_INDEX-1, ue_index is the index allocated by DU-Manager and shared between all Layer 2 modules */
  ue_index_t  ue_index;
  /*^ M, 0, H, 0, 65534 ^*/
}dumgr_mac_rach_resource_rel_ind_t; /*^ API, DUMGR_MAC_RACH_RESOURCE_REL_IND ^*/

/******************************************************************************
 *  API: DUMGR_MAC_RESET_UE_ENTITY_REQ
*******************************************************************************/

typedef struct _dumgr_mac_reset_ue_entity_req
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t   bitmask;
  /*^ BITMASK ^*/

  /*0 - MAX_DU_MANAGER_UE_INDEX-1, ue_index is the index allocated by DU-Manager and shared between all Layer 2 modules */
  ue_index_t  ue_index;
  /*^ M, 0, H, 0, 65534 ^*/
}dumgr_mac_reset_ue_entity_req; /*^ API, DUMGR_MAC_RESET_UE_ENTITY_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_RESET_UE_ENTITY_RESP
*******************************************************************************/

typedef struct _mac_dumgr_reset_ue_entity_resp
{
#define MAC_RESET_UE_FAIL_CAUSE_PRESENT    0x0001
  /* Bitmask indicating the presence of optional fields */
  bitmask_t   bitmask;
  /*^ BITMASK ^*/

  /*0 - MAX_DU_MANAGER_UE_INDEX-1, ue_index is the index allocated by DU-Manager and shared between all Layer 2 modules */
  ue_index_t  ue_index;
  /*^ M, 0, H, 0, 65534 ^*/

  /* Success or Failure NR_FAILURE=0 ,NR_SUCCESS=1 */
  UInt16  response;
  /*^ M, 0, H, 0, 1 ^*/
  UInt16 cause;
  /*^ O, MAC_RESET_UE_FAIL_CAUSE_PRESENT , N, 0, 0 ^*/

}mac_dumgr_reset_ue_entity_resp; /*^ API, MAC_DUMGR_RESET_UE_ENTITY_RESP ^*/	

/******************************************************************************
 *  API: DUMGR_MAC_DELETE_UE_ENTITY_REQ
*******************************************************************************/
typedef struct _dumgr_mac_delete_ue_entity_req_t
{
	/* To inform optional parameter presence */
	bitmask_t	bitmask;		
	/*^ BITMASK ^*/

	/* ue_index is the index allocated by DU-Manager for rnti and shared between all Layer 2 modules */
	ue_index_t	ue_index;
	/*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/ 

}dumgr_mac_delete_ue_entity_req_t; /*^ API, DUMGR_MAC_DELETE_UE_ENTITY_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_DELETE_UE_ENTITY_RESP
*******************************************************************************/

typedef struct _mac_dumgr_delete_ue_entity_resp_t
{
#define MAC_DELETE_UE_FAIL_CAUSE_PRESENT    0x0001
  
  /* To inform optional parameter presence */
  bitmask_t  bitmask;
  /*^ BITMASK ^*/

  /* ue_index is the index allocated by DU Manager for rnti and shared between all Layer 2 modules. */
  ue_index_t ue_index;
  /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

  /*0  NR_FAILURE; 1  NR_SUCCESS	response is the response of the operation performed over the specified Context. */
  UInt16	response;
  /*^ M, 0, H, 0, 1 ^*/
  
  /* error code, in case of failure, indicating reason for failure */
  UInt16        cause;
  /*^ O, MAC_DELETE_UE_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
   
}mac_dumgr_delete_ue_entity_resp_t; /*^ API, MAC_DUMGR_DELETE_UE_ENTITY_RESP ^*/	

/******************************************************************************
 *  API: DUMGR_MAC_PURGE_UES_REQ
*******************************************************************************/

typedef struct __mac_delete_ue_entity_req_t
{
  /* To inform optional parameter presence */
  bitmask_t  bitmask;
  /*^ BITMASK ^*/

  /* ue_index is the index allocated by DU-Manager for rnti and shared between all Layer 2 modules */
  ue_index_t  ue_index;
  /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

}mac_delete_ue_entity_req_t;

typedef struct _dumgr_mac_delete_ue_list_t
{
  /* Bitmask for specifying presence of optional fields */
  bitmask_t  bitmask;
  /*^ BITMASK ^*/

  UInt16                      num_delete_ue_counter;
  /*^ M, 0, B, 1, MAX_NUM_DU_PURGE_UE_IN_BATCH ^*/

  mac_delete_ue_entity_req_t    delete_ue_info_req[MAX_NUM_DU_PURGE_UE_IN_BATCH];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} dumgr_mac_delete_ue_list_t;


typedef struct _dumgr_mac_purge_cell_ues_req_t
{
#define DUMGR_MAC_DELETE_UE_LIST_PRESENT  0x0001
  /* Bitmask for specifying presence of optional fields */
  bitmask_t  bitmask;
  /*^ BITMASK ^*/

  UInt8      delete_all_ue;
  /*^ M, 0, H, 0, 1 ^*/

  dumgr_mac_delete_ue_list_t    delete_entity_list;
  /*^ O, DUMGR_MAC_DELETE_UE_LIST_PRESENT ^*/

}dumgr_mac_purge_cell_ues_req_t; /*^ API, DUMGR_MAC_PURGE_CELL_UES_REQ ^*/

/*******************************************************************************
 *  *    API: MAC_DUMGR_PURGE_CELL_UES_RESP
 *   *******************************************************************************/
typedef struct mac_dumgr_purge_cell_ues_resp_t
{
   /* Bitmask for specifying presence of optional fields */
   bitmask_t  bitmask;
   /*^ BITMASK ^*/
#define MAC_DUMGR_PURGE_CELL_UES_CAUSE_PRESENT   0x01   

   /* Response of request i.e. SUCCESS/FAILURE */
   UInt16     responseCode;
   /*^ M, 0, H, 0, 1 ^*/

   /* Cause code in case of Failure */
   UInt16      cause;
   /*^ O, MAC_DUMGR_PURGE_CELL_UES_CAUSE_PRESENT, N, 0, 0 ^*/

}mac_dumgr_purge_cell_ues_resp_t; /*^ API, MAC_DUMGR_PURGE_CELL_UES_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_CREATE_UE_ENTITY_REQ
*******************************************************************************/
typedef struct _mac_create_ue_entity_req_t
{
  /* To inform optional parameter presence */
  bitmask_t       bitmask;
  /*^ BITMASK ^*/
#define MAC_CREATE_LC_PRESENT 0x0001

  /*ue_index is the index allocated for RNTI and shared between DU modules */
  ue_index_t      ue_index;
  /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

  /* This contains all information required for creation of UE context for UL and DL */
  add_ue_info_t   add_ue_info;
  /*^ M, 0, N, 0, 0 ^*/

  /* It shall be present for creating LCs. */
  create_lc_req_list_t	create_lc;	 
  /*^ M, 0, N, 0, 0 ^*/ 

  /* Location of UE: 0: cell_center or 1: cell_edge */ /* Current release supports only cell_center */
  UInt8           ue_location;
  /*^ M, 0, H, 0, 1 ^*/

  rlc_config_create_req_t rlc_lower_create_req;
  /*^ M, 0, N, 0, 0 ^*/
}mac_create_ue_entity_req_t; /*^ API, DUMGR_MAC_CREATE_UE_ENTITY_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_CREATE_UE_ENTITY_RESP
*******************************************************************************/
typedef struct _mac_create_ue_entity_resp_t
{
  /* To inform optional parameter presence */
  bitmask_t  bitmask;
  /*^ BITMASK ^*/
#define MAC_CREATE_UE_FAIL_CAUSE_PRESENT     0x0001

  /* ue_index is the index allocated for RNTI */
  ue_index_t ue_index;
  /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

  /* NR_FAILURE=0; NR_SUCCESS=1; NR_PARTIAL_SUCCESS=2 response will be either SUCCESS, Partial SUCCESS 
   * or an error code, in case of failure, indicating the reason for failure */
  UInt16     response;
  /*^ M, 0, H, 0, 2 ^*/

  /* will be present in the message for the LCs if there is failure (responseCode is NR_PARTIAL_SUCCESS) 
   * in creation of logical channels for the UE */
  UInt16        cause;
  /*^ O, MAC_CREATE_UE_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/ 
}mac_create_ue_entity_resp_t; /*^ API, MAC_DUMGR_CREATE_UE_ENTITY_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_RECONFIG_UE_ENTITY_REQ
*******************************************************************************/
typedef struct _dumgr_mac_reconfig_ue_entity_req_t
{
#define MAC_RECONFIG_UE_INFO_PRESENT     0x0001
#define MAC_RECONFIG_LC_REQ_PRESENT      0x0002
#define MAC_RECONFIG_RLC_LOWER_RECONFIG_LC_REQ_PRESENT    0x0004 
#define MAC_RECONFIG_CRNTI_PRESENT    0x0008
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
    
   /* ue_index is the index allocated for RNTI */
   ue_index_t    ue_index;
   /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

   /* Change of CRNTI during re-establishment procedure */
   UInt16     rnti ;
   /*^ O, MAC_RECONFIG_CRNTI_PRESENT, B, 1, 65519 ^*/

   /* This contains all information required for reconfiguration of UE context for UL and DL */
   mac_reconfigure_ue_info_t    mac_reconfigure_ue_info;
   /*^ O, MAC_RECONFIG_UE_INFO_PRESENT, N, 0, 0 ^*/

   /* Logical Channels to be created, reconfigured or deleted for the UE */
   mac_reconfigure_lc_req_t     mac_reconfigure_lc_req;
   /*^ O, MAC_RECONFIG_LC_REQ_PRESENT, N, 0, 0 ^*/

   rlc_config_create_req_t      rlc_lower_create_req;
   /*^ O, MAC_RECONFIG_RLC_LOWER_RECONFIG_LC_REQ_PRESENT, N, 0, 0 ^*/

}dumgr_mac_reconfig_ue_entity_req_t; /*^ API, DUMGR_MAC_RECONFIG_UE_ENTITY_REQ ^*/

/******************************************************************************
 *  API: MAC_DUMGR_RECONFIG_UE_ENTITY_RESP
*******************************************************************************/
typedef struct _mac_dumgr_reconfig_ue_entity_resp_t
{
#define MAC_RECONFIG_UE_FAIL_CAUSE_PRESENT    0x0001
#define MAC_RECONFIG_CREATE_LC_FAIL_LIST_PRESENT 0x0002
#define MAC_RECONFIG_DELETE_LC_FAIL_LIST_PRESENT 0x0004
#define MAC_RECONFIG_RECONF_LC_FAIL_LIST_PRESENT 0x0008

    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

   /* ue_index is the index allocated for RNTI */
   ue_index_t    ue_index;
   /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/
 
   /* response is the response of the operation performed over the specified Context */
   UInt16     response;
   /*^ M, 0, H, 0, 2 ^*/

   /* An error code, in case of failure, indicating reason for failure */
   UInt16    cause;
   /*^ O, MAC_RECONFIG_UE_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/

   /* Logical channel Id’s failed to create */
   lc_fail_list_t    create_lc_fail_list;
   /*^ O, MAC_RECONFIG_CREATE_LC_FAIL_LIST_PRESENT, N, 0, 0 ^*/

   /* Logical channel Id’s failed to delete */
   lc_fail_list_t    delete_lc_fail_list;
   /*^ O, MAC_RECONFIG_DELETE_LC_FAIL_LIST_PRESENT, N, 0, 0 ^*/

   /* Logical channel Id’s failed to reconfigure */
   lc_fail_list_t    reconfig_lc_fail_list;
   /*^ O, MAC_RECONFIG_RECONF_LC_FAIL_LIST_PRESENT, N, 0, 0 ^*/
}mac_dumgr_reconfig_ue_entity_resp_t;  /*^ API, MAC_DUMGR_RECONFIG_UE_ENTITY_RESP ^*/

/******************************************************************************
 *  API: DUMGR_MAC_PURGE_CELL_UES_REQ
*******************************************************************************/
typedef struct _mac_delete_ue_entity_t
{
	/* To inform optional parameter presence */
	bitmask_t	bitmask;		
	/*^ BITMASK ^*/

	/* ue_index is the index allocated by DU-Manager for rnti and shared between all Layer 2 modules */
	ue_index_t	ue_index;
	/*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/  

}mac_delete_ue_entity_t; 

/******************************************************************************
 *  API: MAC_DUMGR_UL_CCCH_MSG_IND
*******************************************************************************/
typedef struct mac_dumgr_ul_ccch_msg_ind_t
{
   /* To inform optional parameter presence */
   bitmask_t   bitmask;
   /*^ BITMASK ^*/

   /* RNTI allocated by MAC to the UE */
   UInt16    rnti;
   /*^ M, 0, B, 1, 65519 ^*/

   UInt8    lc_id;
   /*^ M, 0, H, 0, 52 ^*/

   /* Length of the CCCH message buffer */
   UInt8    msg_len;
   /*^ M, 0, H, 0, 8 ^*/

   /* CCCH message buffer sent by UE */
   UInt8    ccch_msg[MAX_UL_CCCH_MSG_SIZE];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}mac_dumgr_ul_ccch_msg_ind_t; /*^ API, MAC_DUMGR_UL_CCCH_MSG_IND ^*/

/******************************************************************************
 *  API: DUMGR_MAC_DL_CCCH_MSG_IND
 *******************************************************************************/ 
typedef struct dumgr_mac_dl_ccch_msg_ind_t
{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* RNTI allocated by MAC to the UE */
    UInt16    rnti;
    /*^ M, 0, B, 1, 65519 ^*/

    /* To inform if message to be sent in Setup or Reject  */
    UInt8    msg_type;
    /*^ M, 0, H, 0, 1 ^*/

   /* Length of the CCCH message buffer */
   UInt16    msg_len;
   /*^ M, 0, B, 2, 512 ^*/
  
   /* CCCH message buffer sent by UE */
   UInt8    ccch_msg[MAX_DL_CCCH_MSG_SIZE];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}dumgr_mac_dl_ccch_msg_ind_t; /*^ API, DUMGR_MAC_DL_CCCH_MSG_IND ^*/

/******************************************************************************
 *  API: MAC_DUMGR_SI_MSG_IND
 ********************************************************************************/
typedef struct _mac_dumgr_si_msg_ind_t

{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt16          si_msg_len;
    /*^ M, 0, B, 1, MAX_SIB_LENGTH ^*/

    /* ASN encoded PDU. MSB->LSB of first byte correspond to bit0 to bit7
     *      * The same bit order applies to the subsequent bytes.*/
    UInt8           si_msg_buf[MAX_SIB_LENGTH];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}mac_dumgr_si_msg_ind_t; /*^ API, MAC_DUMGR_SI_MSG_IND ^*/
    
/******************************************************************************
 *  API: MAC_DUMGR_PERIODIC_STATS_IND
 *******************************************************************************/ 
typedef struct mac_dumgr_periodic_stats_ind_t
{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Count of Users for which periodic Sinr report is sent*/
    UInt8 ue_count;
    /*^ M, 0, H, 0, MAX_BATCH_SIZE ^*/

    /* Structure for PL, Pusch/Pucch Sinr*/
    mac_ue_stats_t mac_ue_stats[MAX_BATCH_SIZE];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}mac_dumgr_periodic_stats_ind_t; /*^ API, MAC_DUMGR_PERIODIC_STATS_IND ^*/

/***************************************************************************
 * API: MAC_DUMGR_UE_SYNC_IND
 * ***********************************************************************/
typedef struct _mac_dumgr_ue_sync_ind_t
{
     /* To inform optional parameter presence */
     bitmask_t   bitmask;
     /*^ BITMASK ^*/

     /* RNTI allocated by MAC to the UE */
     UInt16      rnti;
     /*^ M, 0, B, 1, 65519 ^*/

     UInt8      ssb_index;
     /*^ M, 0, H, 0, 63 ^*/

     /*ue_index is the index allocated for RNTI and shared between DU modules */
     ue_index_t  ue_index;
     /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

     /* UE sync status at MAC */
     UInt8    sync_status;
     /*^ M , 0, H, 0, 4 ^*/
}mac_dumgr_ue_sync_ind_t; /*^ API, MAC_DUMGR_UE_SYNC_IND ^*/
 
/**********************************************************************************
 * API: DUMGR_MAC_PCCH_MSG_IND
 * *******************************************************************************/
typedef struct _dumgr_mac_pcch_msg_ind_t
{
#define SHORT_MSG_PRESENT 0x0001
#define PCCH_MSG_PRESENT  0x0002
     /* To inform optional parameter presence */
     bitmask_t     bitmask;
     /*^ BITMASK ^*/

     /* Paging SFN for sending the Paging message*/
     UInt16        paging_frame;
     /*^ M, 0, H, 0, 1023 ^*/

     /* Paging Occasion depending on the ns value configured 
      * in PCCH-Config during cell configuration.
      * 0 for ns = 1,2,4
      * 1 for ns = 2,4
      * 2 for ns = 4
      * 3 for ns = 4 */
     UInt8          paging_occasion;
     /*^ M, 0, H, 0, 3 ^*/

     /*This value will be 1 in case of regular paging. 
     In case of Short Message paging(TBD) it will be > 1 */
     UInt16         num_repetition;
     /*^ M, 0, H, 0, 1 ^*/

     /*To inform if message to be sent with P-RNTI. 
      * Only 1 is supported in current release */
     UInt8          paging_msg_type;
     /*^ M, 0, H, 0, 1 ^*/

     /*Bitmap as per Reference 3GPP 38.331 Section 6.5. 
     Not supported in current release */
     UInt8           short_message;
     /*^ O, SHORT_MSG_PRESENT, N, 0, 0 ^*/

     pcch_message_t   pcch_message;
     /*^ O, PCCH_MSG_PRESENT, N, 0, 0 ^*/
}dumgr_mac_pcch_msg_ind_t; /*^ API, DUMGR_MAC_PCCH_MSG_IND ^*/

/******************************************************************************
 * API: MAC_DUMGR_SFN_SLOT_IND
 * **************************************************************************/
typedef struct _mac_dumgr_sfn_slot_ind_t
{
    /* To inform optional parameter presence */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* Current SFN value of the cell */
    UInt16       sfn;
    /*^ M, 0, H, 0, 1023 ^*/

    /* Current Slot of the cell 
     * Currently max scs 120 kHz is supported.*/
    UInt16       slot;
     /*^ M, 0, H, 0, 79 ^*/
}mac_dumgr_sfn_slot_ind_t; /*^ API, MAC_DUMGR_SFN_SLOT_IND ^*/

/*****************************************************************************
 * API: MAC_DUMGR_SFN_ERR_IND
 * **************************************************************************/
typedef struct _mac_dumgr_sfn_err_ind_t
{
     /* To inform optional parameter presence */
     bitmask_t    bitmask;
     /*^ BITMASK ^*/

     /* Current SFN value */
     UInt16      current_sfn;
      /*^ M, 0, H, 0, 1023 ^*/
}mac_dumgr_sfn_err_ind_t; /*^ API, MAC_DUMGR_SFN_ERR_IND ^*/ 

/*****************************************************************************
 * API: MAC_DUMGR_BEAM_SWITCH_IND
 * **************************************************************************/
typedef struct _mac_dumgr_beam_switch_ind_t
{
     /* To inform optional parameter presence */
     bitmask_t    bitmask;
     /*^ BITMASK ^*/
 
     /* 0 - MAX_DU_MANAGER_UE_INDEX-1,ue_index is the index allocated by DU-Manager and 
       shared between all Layer 2 modules */
     ue_index_t    ue_index;
     /*^ M,  0,  H, 0, 65535 ^*/   

     /*Index of the beam on which UE switched */
     UInt8         beam_index;
     /*^ M,  0,  H, 0, 127 ^*/

     /*Cause indicating the beam switch trigger */
     beam_cause_t         cause;
     /*^M, 0, H, 0, 1 ^*/
}mac_dumgr_beam_switch_ind_t; /*^ API, MAC_DUMGR_BEAM_SWITCH_IND ^*/

#endif   /* _DUMGR_MAC_INTF_H_ */
