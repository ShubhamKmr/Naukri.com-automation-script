/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_asn_enc_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ***************************************************************************/
#ifndef _NGAP_ASN_COMMON_WRAPPER_H_
#define _NGAP_ASN_COMMON_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include "ngap_asn_enc_wrapper.h"
#include "ngap_types.h"
#include "ngap_utils.h"
#include "ngap_intf_mgmnt.h"
#include "ngap_tracing.h"
#ifndef AMF_SIM_TESTING_ENABLE
#include "rrc_logging.h"
#endif

/****************************************************************************
 * Common Definitions
 ****************************************************************************/

#define NGAP_ASN_OK				       0 /* ASN_OK i.e. 0 return by ASN libraries in case of Success */
#define NGAP_MAX_ASN1_BUF_LEN	       8192
#define NGAP_MAX_ASN1_BUF_LEN_PRINT    60000

/* NGAP-Constants - 38.413, Section 9.4.3 */
typedef enum
{
    ngap_id_AMFConfigurationUpdate = 0,
    ngap_id_AMFStatusIndication,
    ngap_id_CellTrafficTrace,
    ngap_id_DeactivateTrace,
    ngap_id_DownlinkNASTransport,
    ngap_id_DownlinkNonUEAssociatedNRPPaTransport,
    ngap_id_DownlinkRANConfigurationTransfer,
    ngap_id_DownlinkRANStatusTransfer,
    ngap_id_DownlinkUEAssociatedNRPPaTransport,
    ngap_id_ErrorIndication,
    ngap_id_HandoverCancel,
    ngap_id_HandoverNotification,
    ngap_id_HandoverPreparation,
    ngap_id_HandoverResourceAllocation,
    ngap_id_InitialContextSetup,
    ngap_id_InitialUEMessage,
    ngap_id_LocationReportingControl,
    ngap_id_LocationReportingFailureIndication,
    ngap_id_LocationReport,
    ngap_id_NASNonDeliveryIndication,
    ngap_id_NGReset,
    ngap_id_NGSetup,
    ngap_id_OverloadStart,
    ngap_id_OverloadStop,
    ngap_id_Paging,
    ngap_id_PathSwitchRequest,
    ngap_id_PDUSessionResourceModify,
    ngap_id_PDUSessionResourceModifyIndication,
    ngap_id_PDUSessionResourceRelease,
    ngap_id_PDUSessionResourceSetup,
    ngap_id_PDUSessionResourceNotify,
    ngap_id_PrivateMessage,
    ngap_id_PWSCancel,
    ngap_id_PWSFailureIndication,
    ngap_id_PWSRestartIndication,
    ngap_id_RANConfigurationUpdate,
    ngap_id_RerouteNASRequest,
    ngap_id_RRCInactiveTransitionReport,
    ngap_id_TraceFailureIndication,
    ngap_id_TraceStart,
    ngap_id_UEContextModification,
    ngap_id_UEContextRelease,
    ngap_id_UEContextReleaseRequest,
    ngap_id_UERadioCapabilityCheck,
    ngap_id_UERadioCapabilityInfoIndication,
    ngap_id_UETNLABindingRelease,
    ngap_id_UplinkNASTransport,
    ngap_id_UplinkNonUEAssociatedNRPPaTransport,
    ngap_id_UplinkRANConfigurationTransfer,
    ngap_id_UplinkRANStatusTransfer,
    ngap_id_UplinkUEAssociatedNRPPaTransport,
    ngap_id_WriteReplaceWarning,
    ngap_id_InvalidProcedureCode

} ngap_procedure_et;

/* NGAP Messages - 38.413, Section 9.2 */
typedef enum
{
    NGAP_PDU_SESSION_RESOURCE_SETUP_REQUEST = 0,
    NGAP_PDU_SESSION_RESOURCE_SETUP_RESPONSE,
    NGAP_PDU_SESSION_RESOURCE_RELEASE_COMMAND,
    NGAP_PDU_SESSION_RESOURCE_RELEASE_RESPONSE,
    NGAP_PDU_SESSION_RESOURCE_MODIFY_REQUEST,
    NGAP_PDU_SESSION_RESOURCE_MODIFY_RESPONSE,
    NGAP_PDU_SESSION_RESOURCE_NOTIFY,
    NGAP_PDU_SESSION_RESOURCE_MODIFY_INDICATION,
    NGAP_PDU_SESSION_RESOURCE_MODIFY_CONFIRM,
    NGAP_INITIAL_CONTEXT_SETUP_REQUEST,
    NGAP_INITIAL_CONTEXT_SETUP_RESPONSE,
    NGAP_INITIAL_CONTEXT_SETUP_FAILURE,
    NGAP_UE_CONTEXT_RELEASE_REQUEST,
    NGAP_UE_CONTEXT_RELEASE_COMMAND,
    NGAP_UE_CONTEXT_RELEASE_COMPLETE,
    NGAP_UE_CONTEXT_MODIFICATION_REQUEST,
    NGAP_UE_CONTEXT_MODIFICATION_RESPONSE,
    NGAP_UE_CONTEXT_MODIFICATION_FAILURE,
    NGAP_RRC_INACTIVE_TRANSITION_REPORT,
    NGAP_HANDOVER_REQUIRED,
    NGAP_HANDOVER_COMMAND,
    NGAP_HANDOVER_PREPARATION_FAILURE,
    NGAP_HANDOVER_REQUEST,
    NGAP_HANDOVER_REQUEST_ACKNOWLEDGE,
    NGAP_HANDOVER_FAILURE,
    NGAP_HANDOVER_NOTIFY,
    NGAP_PATH_SWITCH_REQUEST,
    NGAP_PATH_SWITCH_REQUEST_ACKNOWLEDGE,
    NGAP_PATH_SWITCH_REQUEST_FAILURE,
    NGAP_HANDOVER_CANCEL,
    NGAP_HANDOVER_CANCEL_ACKNOWLEDGE,
    NGAP_UPLINK_RAN_STATUS_TRANSFER,
    NGAP_DOWNLINK_RAN_STATUS_TRANSFER,
    NGAP_PAGING,
    NGAP_INITIAL_UE_MESSAGE,
    NGAP_DOWNLINK_NAS_TRANSPORT,
    NGAP_UPLINK_NAS_TRANSPORT,
    NGAP_NAS_NON_DELIVERY_INDICATION,
    NGAP_REROUTE_NAS_REQUEST,
    NGAP_NG_SETUP_REQUEST,
    NGAP_NG_SETUP_RESPONSE,
    NGAP_NG_SETUP_FAILURE,
    NGAP_RAN_CONFIGURATION_UPDATE,
    NGAP_RAN_CONFIGURATION_UPDATE_ACKNOWLEDGE,
    NGAP_RAN_CONFIGURATION_UPDATE_FAILURE,
    NGAP_AMF_CONFIGURATION_UPDATE,
    NGAP_AMF_CONFIGURATION_UPDATE_ACKNOWLEDGE,
    NGAP_AMF_CONFIGURATION_UPDATE_FAILURE,
    NGAP_AMF_STATUS_INDICATION,
    NGAP_NG_RESET,
    NGAP_NG_RESET_ACKNOWLEDGE,
    NGAP_ERROR_INDICATION,
    NGAP_OVERLOAD_START,
    NGAP_OVERLOAD_STOP,
    NGAP_UPLINK_RAN_CONFIGURATION_TRANSFER,
    NGAP_DOWNLINK_RAN_CONFIGURATION_TRANSFER,
    NGAP_WRITE_REPLACE_WARNING_REQUEST,
    NGAP_WRITE_REPLACE_WARNING_RESPONSE,
    NGAP_PWS_CANCEL_REQUEST,
    NGAP_PWS_CANCEL_RESPONSE,
    NGAP_PWS_RESTART_INDICATION,
    NGAP_PWS_FAILURE_INDICATION,
    NGAP_DOWNLINK_UE_ASSOCIATED_NRPPA_TRANSPORT,
    NGAP_UPLINK_UE_ASSOCIATED_NRPPA_TRANSPORT,
    NGAP_DOWNLINK_NON_UE_ASSOCIATED_NRPPA_TRANSPORT,
    NGAP_UPLINK_NON_UE_ASSOCIATED_NRPPA_TRANSPORT,
    NGAP_TRACE_START,
    NGAP_TRACE_FAILURE_INDICATION,
    NGAP_DEACTIVATE_TRACE,
    NGAP_CELL_TRAFFIC_TRACE,
    NGAP_LOCATION_REPORTING_CONTROL,
    NGAP_LOCATION_REPORTING_FAILURE_INDICATION,
    NGAP_LOCATION_REPORT,
    NGAP_UE_TNLA_BINDING_RELEASE_REQUEST,
    NGAP_UE_RADIO_CAPABILITY_INFO_INDICATION,
    NGAP_UE_RADIO_CAPABILITY_CHECK_REQUEST,
    NGAP_UE_RADIO_CAPABILITY_CHECK_RESPONSE,
    NGAP_MAX_AMF_API
    
} ngap_amf_api_et;

void ngap_asn1PrtToStr_NGAP_PDU
(
      UInt32         log_level,
      SInt8          *name,
      ngap_NGAP_PDU  *pvalue
);

void ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupRequestTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_PDUSessionResourceSetupRequestTransfer   *pvalue
);

void ngap_asn1PrtToStr_ngap_PDUSessionResourceSetupResponseTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_PDUSessionResourceSetupResponseTransfer   *pvalue
);

void ngap_asn1PrtToStr_ngap_HandoverCommandTransfer 
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverCommandTransfer *pvalue
);

void ngap_asn1PrtToStr_ngap_HandoverResourceAllocationUnsuccessfulTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverResourceAllocationUnsuccessfulTransfer     *pvalue
);

void ngap_asn1PrtToStr_ngap_HandoverRequestAcknowledgeTransfer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_HandoverRequestAcknowledgeTransfer *pvalue
);
/*Handover_changes_start*/

void ngap_asn1PrtToStr_ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer 
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_TargetNGRANNode_ToSourceNGRANNode_TransparentContainer  *pvalue
);

void ngap_asn1PrtToStr_ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
(
    UInt32		    log_level,
    SInt8          	*name,
    ngap_SourceNGRANNode_ToTargetNGRANNode_TransparentContainer  *pvalue
);
/*Handover_changes_end*/
#endif  /* _NGAP_ASN_COMMON_WRAPPER_H_ */
