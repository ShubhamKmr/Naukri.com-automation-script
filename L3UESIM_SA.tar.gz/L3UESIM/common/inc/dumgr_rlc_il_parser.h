/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2018 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file dumgr_rlc_il_parser.h contains the prototypes 
 *                     of DUMGR-RLC interface message parsing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _DUMGR_RLC_IL_PARSER_H_
#define _DUMGR_RLC_IL_PARSER_H_

#include "gnb_defines.h"
#include "dumgr_rlc_intf.h"

gnb_return_t
gnb_il_parse_dumgr_rlc_cell_config_req
(
    dumgr_rlc_cell_config_req_t *p_dumgr_rlc_cell_config_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_cell_config_resp
(
    rlc_dumgr_cell_config_resp_t *p_rlc_dumgr_cell_config_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_cell_delete_resp
(
    rlc_dumgr_cell_delete_resp_t *p_rlc_dumgr_cell_delete_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_purge_cell_ues_req
(
    dumgr_rlc_purge_cell_ues_req_t *p_dumgr_rlc_purge_cell_ues_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_purge_cell_ues_resp
(
    rlc_dumgr_purge_cell_ues_resp_t *p_rlc_dumgr_purge_cell_ues_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_create_ue_entity_req
(
    dumgr_rlc_create_ue_entity_req_t *p_dumgr_rlc_create_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_create_ue_entity_resp
(
    rlc_dumgr_create_ue_entity_resp_t *p_rlc_dumgr_create_ue_entity_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_reconfig_ue_entity_req
(
    dumgr_rlc_reconfig_ue_entity_req_t *p_dumgr_rlc_reconfig_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_reconfig_ue_entity_resp
(
    rlc_dumgr_reconfig_ue_entity_resp_t *p_rlc_dumgr_reconfig_ue_entity_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_delete_ue_entity_req
(
    dumgr_rlc_delete_ue_entity_req_t *p_dumgr_rlc_delete_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_delete_ue_entity_resp
(
    rlc_dumgr_delete_ue_entity_resp_t *p_rlc_dumgr_delete_ue_entity_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_srb_dl_data_ind
(
    dumgr_rlc_srb_dl_data_ind_t *p_dumgr_rlc_srb_dl_data_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_srb_ul_data_ind
(
    rlc_dumgr_srb_ul_data_ind_t *p_rlc_dumgr_srb_ul_data_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_re_establish_ue_entity_req
(
    dumgr_rlc_re_establish_ue_entity_req_t *p_dumgr_rlc_re_establish_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_re_establish_ue_entity_resp
(
    dumgr_rlc_re_establish_ue_entity_resp_t *p_dumgr_rlc_re_establish_ue_entity_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_dumgr_rlc_re_establish_ue_entity_complete_ind
(
    dumgr_rlc_re_establish_ue_entity_complete_ind_t *p_dumgr_rlc_re_establish_ue_entity_complete_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_re_establish_ue_entity_complete_resp
(
    rlc_dumgr_re_establish_ue_entity_complete_resp_t *p_rlc_dumgr_re_establish_ue_entity_complete_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rlc_dumgr_ue_max_retx_ind
(
    rlc_dumgr_ue_max_retx_ind_t *p_rlc_dumgr_ue_max_retx_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

#endif /* _DUMGR_RLC_IL_PARSER_H_ */
