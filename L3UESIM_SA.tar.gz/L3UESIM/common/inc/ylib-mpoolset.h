/****************************************************************************/
/**  Copyright (C) 2006 Aricent Inc . All Rights Reserved */
/****************************************************************************/
/**                                                                        **/
/** Common Stack Porting Library - Interface Definition                    **/
/**                                                                        **/
/****************************************************************************/

#ifndef _YLIB_MPOOLSET_H_
#define _YLIB_MPOOLSET_H_




QMPOOLSET    qvMsgPoolSetCreate(QPOOLSETTUNING *t, int *cErr);
void         *qvMsgPoolSetAlloc(QMPOOLSET *rpd, unsigned int size,unsigned int *psize, int *cErr);
unsigned int qvMsgPoolSetExtend(QMPOOLSET *rpd, QPOOLSETTUNING *t, int *cErr);
unsigned int qvMsgPoolSetDelete( QMPOOLSET *rpd, int *cErr);
unsigned int qvMsgPoolSetSize(QMPOOLSET *rpd, QPOOLSETTUNINGINFO *t, int *cErr);

#endif

