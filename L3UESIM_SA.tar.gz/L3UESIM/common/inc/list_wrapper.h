/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name : list_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : Consists the implementation of lists functionality 
 *
 ****************************************************************************/


#ifndef _LIST_WRAPPER_H_
#define _LIST_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include "ylib.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/* This is needed to create a user defined list. An object of this needs to 
   be passed to the intialization function of the list. */
typedef YLIST NR_LIST;

/* This is the anchor of the entry to be made in the list. This object should
   be part of every node that is created to be inserted into a list. */
typedef YLNODE NR_LIST_NODE;

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    listInit(NR_LIST *pList);
UInt32  listCount(const NR_LIST *pList);
void    listDeleteNode(NR_LIST *pList, NR_LIST_NODE *pNode);
void    listInsertNode(NR_LIST *pList, NR_LIST_NODE *pNode);
void    listPushNode(NR_LIST *pList, NR_LIST_NODE *pNode);
NR_LIST_NODE* listPopNode(NR_LIST *pList);
NR_LIST_NODE *getListNode(const NR_LIST *pList, UInt32 nodeNum);
NR_LIST_NODE *getNextListNode(const NR_LIST_NODE *pNode);
NR_LIST_NODE *getFirstListNode(const NR_LIST *pList);
NR_LIST_NODE *getLastListNode(const NR_LIST *pList);
NR_LIST_NODE *getPrevListNode(const NR_LIST_NODE *pNode);
void listWalk(const NR_LIST *pList, void (*walker) (NR_LIST_NODE *, void *), void * pValue);
UInt32 printList(const NR_LIST* list_p);
void listInsertNodeAtHead(NR_LIST *pList, NR_LIST_NODE *pNode);
void listInsertNodeBefore(NR_LIST *pList, NR_LIST_NODE *pSrcNode,
    NR_LIST_NODE *pNode);
void listInsertNodeAfter(NR_LIST *pList, NR_LIST_NODE *pSrcNode,
                         NR_LIST_NODE *pNode);

#endif
