/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2018 Aricent.
 *
 ****************************************************************************
 *
 *  File Description : For HMAC-SHA-256 Algo
 *
 ****************************************************************************/

#ifndef HMAC_SHA256_H
#define HMAC_SHA256_H

/****************************************************************************
 * Inculdes
 ****************************************************************************/

#include "gnb_common_utils.h"

/****************************************************************************
 * Public defines
 ****************************************************************************/

#define SHA_256_DIGEST_LEN 32
#define SHA_256_CHUNK_LEN  64

/****************************************************************************
 * Public types definitions
 ****************************************************************************/

typedef struct
{
    UInt32 length;
    UInt32 total_length;
    UInt8  chunk[2*SHA_256_CHUNK_LEN];
    UInt32 h[8];
} sha_256_state;

typedef struct
{
    UInt8 inner_padding[SHA_256_CHUNK_LEN];
    UInt8 outer_padding[SHA_256_CHUNK_LEN];

    sha_256_state state_inner;
    sha_256_state state_outer;

    /* for reinit */
    sha_256_state state_inner_reinit;
    sha_256_state state_outer_reinit;
} hmac_sha_256_state;

/****************************************************************************
 * Public functions definitions
 ****************************************************************************/

void sha_256_algo(const UInt8 *msg,UInt32 length,UInt8 *digest);
void sha_256_initialize(sha_256_state *state);
void sha_256_update_state(sha_256_state *state,const UInt8 *msg,UInt32 length);
void sha_256_finish(sha_256_state *state,UInt8 *digest);

void hmac_sha_256_initialize
(
    hmac_sha_256_state *state,
    UInt8 *key,
    UInt32 key_length
);

void hmac_sha_256_reinitialize(hmac_sha_256_state *state);

void hmac_sha_256_update_state
(
    hmac_sha_256_state *state,
    UInt8 *msg,
    UInt32 msg_length
);

void hmac_sha_256_finish
(
    hmac_sha_256_state *state,
    UInt8 *mac,
    UInt32 mac_length
);

void hmac_sha_256_algo
(
    UInt8 *key,
    UInt32 key_length,
    UInt8 *msg,
    UInt32 msg_length,
    UInt8 *mac,
    UInt32 mac_length
);

#endif /* HMAC_SHA256_H */
