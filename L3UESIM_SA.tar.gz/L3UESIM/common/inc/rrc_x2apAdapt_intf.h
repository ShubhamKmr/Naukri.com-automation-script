/******************************************************************************
*
*   FILE NAME   : 
*
*   DESCRIPTION : This file Interface API for X2AP/ADPT
*
*   DATE            AUTHOR         REFERENCE       REASON
*   08-JAN-2018    Richa Sagar     ---------      5G Development Changes
*
*   Copyright (c) 2018, Aricent Inc. All Rights Reserved
*
******************************************************************************/
#ifndef _X2AP_ADPT_INFT_H_ 
#define _X2AP_ADPT_INFT_H_
#include "rrc_defines.h"

/********************************************************************
 * X2AP - ADPT APIs
 *******************************************************************/
#define ADPT_L3S_MENB_CONFIG_PARAM_NTF          0x00008075
#define ADPT_PRTIF_SCTP_LINK_STATUS_NTF         0x00008015 
#define ADPT_PRTIF_X2_SEND_IND                  0x00008024 
#define ADPT_PRTIF_X2_RECV_NTF                  0x00008025 
#define ADPT_PRTIF_X2_LINK_STATUS_NTF           0x00008035 

#define MAX_MENB_COUNT 128 
#define RRC_ONE 1 
typedef enum
{
    RRC_ADPT_MME = 0,
    RRC_ADPT_ENB,
    RRC_ADPT_OPS,
    RRC_ADPT_SERVER,
    RRC_ADPT_GNB
} rrc_adpt_node_kind_et; /* Only "1:eNB" will be set */

typedef enum
{
    RRC_ADPT_UP = 0,
    RRC_ADPT_DOWN , /* Down is not supported. This will be used for X2 Release and X2 removal in future release */
} rrc_adpt_link_status_et; 

typedef enum
{
    RRC_ADPT_UE_ASSOC = 0,
    RRC_ADPT_UE_ASSOC_1,
    RRC_ADPT_UE_ASSOC_2,
    RRC_ADPT_UE_ASSOC_3,
    RRC_ADPT_UE_ASSOC_4,
    RRC_ADPT_UE_ASSOC_5,
    RRC_ADPT_UE_ASSOC_6,
    RRC_ADPT_UE_ASSOC_7,
    RRC_ADPT_UE_ASSOC_8,
    RRC_ADPT_UE_ASSOC_9,
    RRC_ADPT_UE_ASSOC_10,

} rrc_adpt_x2ap_stream_id_et; 

typedef enum
{
    RRC_ADPT_UE_ASSOCIATED = 0,
    RRC_ADPT_NON_UE_ASSOCIATED
} rrc_adpt_x2ap_msg_kind_et; 


typedef struct
{
    U16      node_kind;     /*^ M,0,H,0,4 ^*/ /* rrc_adpt_node_kind_et */
    U16      node_num;      /*^ M,0,H,0,127 ^*/
    U32      enb_id;        /*^ M,0,N,0,0 ^*/
}rrc_adpt_meNB_config_param_t;


/******************************************************************************
                        ADPT_L3S_MENB_CONFIG_PARAM_NTF
******************************************************************************/
typedef struct
{
    U32                            node_count;      /*^ M,0,H,0,128 ^*/ 
    rrc_adpt_meNB_config_param_t            meNB_config_param[MAX_MENB_COUNT]; /*^ M,0,OCTET_STRING,VARIABLE ^*/
}adpt_l3s_menb_config_param_ntf_t; /*^ API, ADPT_L3S_MENB_CONFIG_PARAM_NTF ^*/

/******************************************************************************
                        ADPT_PRTIF_SCTP_LINK_STATUS_NTF
******************************************************************************/
typedef struct _adpt_prtif_sctp_link_status_ntf_t
{
  
    U16      node_kind;       /*^ M,0,H,0,4 ^*/ /* rrc_adpt_node_kind_et */
    U16      node_num;        /*^ M,0,H,0,127 ^*/
    U16      link_status;     /*^ M,0,H,0,1 ^*/ /*rrc_adpt_link_status_et */
    U16      stream_count;    /*^ M,0,B,1,11 ^*/

}adpt_prtif_sctp_link_status_ntf_t; /*^ API, ADPT_PRTIF_SCTP_LINK_STATUS_NTF ^*/

/******************************************************************************
                        ADPT_PRTIF_X2_SEND_IND
******************************************************************************/
typedef struct
{
  
    U16      node_kind;        /*^ M,0,H,0,4 ^*/ /* rrc_adpt_node_kind_et */
    U16      node_num;         /*^ M,0,H,0,127 ^*/
    U16      stream_id;     /*^ M,0,H,0,1 ^*/ /* rrc_adpt_x2ap_stream_id_et */
    U16      x2ap_msg_len;     /*^ M,0,N,0,0 ^*/
    U8       x2ap_msg[RRC_ONE];       /*^ M,0,OCTET_STRING,VARIABLE ^*/

}adpt_prtif_x2_send_ind_t; /*^ API, ADPT_PRTIF_X2_SEND_IND ^*/

/******************************************************************************
                        ADPT_PRTIF_X2_RECV_NTF
******************************************************************************/
typedef struct
{
  
    U16      node_kind;        /*^ M,0,H,0,4 ^*/ /* rrc_adpt_node_kind_et */
    U16      node_num;         /*^ M,0,H,0,127 ^*/
    U16      dummy;            /*^ M, 0, NOT_PRESENT_IN_MESSAGE ^*/
    U16      x2ap_msg_len;     /*^ M,0,N,0,0 ^*/
    U8       x2ap_msg[RRC_ONE];      /*^ M,0,OCTET_STRING,VARIABLE ^*/

}adpt_prtif_x2_recv_ntf_t; /*^ API, ADPT_PRTIF_X2_RECV_NTF ^*/

/******************************************************************************
                        ADPT_PRTIF_X2_LINK_STATUS_NTF
******************************************************************************/
typedef struct
{
  
    U16      node_kind;       /*^ M,0,H,0,4 ^*/ /* rrc_adpt_node_kind_et */
    U16      node_num;        /*^ M,0,H,0,127 ^*/
    U16      link_status;     /*^ M,0,H,0,1 ^*/ /*rrc_adpt_link_status_et */
    U16      dummy;           /*^ M, 0, NOT_PRESENT_IN_MESSAGE ^*/

}adpt_prtif_x2_link_status_ntf_t; /*^ API, ADPT_PRTIF_X2_LINK_STATUS_NTF ^*/




/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/


#endif /*_X2AP_ADPT_INFT_H_*/
