
/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name time_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : Header file for lteTime functions wrapper APIs 
 *
 ****************************************************************************/

#ifndef _TIME_WRAPPER_H__
#define _TIME_WRAPPER_H__

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "ylib.h"

/****************************************************************************
 * Exported Types
 ****************************************************************************/
typedef YTIME_T NR_TIME_T;

/****************************************************************************
* Function Name  : nrGetSystemTime
* Inputs         : None
* Outputs        : NR_TIME_T - time structure
* Returns        : NR_TIME_T - current system time
* Description    : This function returns current system time
****************************************************************************/
NR_TIME_T nrGetSystemTime(void);
/****************************************************************************
* Function Name  : nrTimeDiff
* Inputs         : const NR_TIME_T* ptm_one - pointer to time structure
*                  const NR_TIME_T* ptm_two - pointer to time structure
* Outputs        : 
* Returns        : SInt32 - difference between two timestamps (milliseconds)
* Description    : This function calculates difference between two timestamps
****************************************************************************/
SInt32 nrTimeDiff(const NR_TIME_T* ptm_one, const NR_TIME_T* ptm_two);

/****************************************************************************
* Function Name  : nrTimeAdd 
* Inputs         : const NR_TIME_T* ptm_one - pointer to time structure
*                  SInt32 msec - time in milliseconds
* Outputs        : 
* Returns        : NR_TIME_T - new time value
* Description    : This function add millisecond time value to NR_TIME_T
*                   structure and returns new time structure
****************************************************************************/
NR_TIME_T nrTimeAdd (const NR_TIME_T* ptm, SInt32 msec);

#endif /* _TIME_WRAPPER_H__ */
