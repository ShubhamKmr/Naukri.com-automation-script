/****************************************************************************/
/**  Copyright (C) 2006 Aricent Inc . All Rights Reserved */
/****************************************************************************/
/**                                                                        **/
/** Common Stack Porting Library - Interface Definition                    **/
/**                                                                        **/
/****************************************************************************/

#ifndef    _YLIB_MSGPOOL_H_
#define    _YLIB_MSGPOOL_H_

#include <ylib.h>
#include <cspl.h>

#define    LOGGER_MODULE_ID    999
#define    LOGGER_API_SIZE     6
#define    __BUFMAGIC          0xACE12E92
#define    __POOLMAGIC         0xCA98362D

/** Library Initialization **************************************************/
void       qvMsgPoolInit( const QSYSOP *op, unsigned int num_qmsg_buf, unsigned int num_qpctl_buf);
void       qvMsgPoolInitEx( const QSYSOP *op,unsigned int num_qmsg_buf, unsigned int num_qpctl_buf, int *cErr);
#define  print_buffer_from_ZBC(fromZBuffer,count) print_Buffer_from_ZBC(fromZBuffer,count,__func__, __LINE__)
void       print_Buffer_from_ZBC (const void *fromZBuffer, unsigned int count, const char *func, unsigned int line);
QDRIVER    qvNewDriver( void );
QDRIVER    qvNewDriverEx(int *cErr);
QDRIVER    qvDriverStart(QDRIVER driver, void (*wakeupfn)(void *), void *arg);
#define    qvDriver(w,a)    (qvDriverStart(qvNewDriver(),(w),(a)))

/** Memory Pool Management **************************************************/

/* Task common memory pools *************************************************/

/** Constants **/

typedef    struct    qmpool {
    unsigned long    magic;
    unsigned int    size, nbuf, alloc;
    YLIST        chunks;
    YLIST        list;

    QLOCK        lock;
#ifdef MEM_DEBUG
        unsigned long   ref_ctr;
#endif
} qmpool;

typedef    struct    qmbuf {
    union {
        YLNODE    __header__;
        qmpool    *pool;
    } u;

    unsigned short    incarnation;
    unsigned char    allocated;
#ifdef MEM_DEBUG
        unsigned long   ref_id;
#endif
} qmbuf;

typedef    struct    qmchunk {
    YLNODE    __header__;
    unsigned int    nbuf;
} qmchunk;

typedef struct qmpoolsetContext {
    unsigned int    magic;
    unsigned int    opt;
        unsigned int    npools;
        QMPOOL          alloc[MAX_POOLS];
        QLOCK           lock ;

}qmpoolset ;

/** Message Buffer Management ***********************************************/
unsigned short int qv_msg_construct_io_vec(const void *buffer,  struct iovec *vec, unsigned short num_segments);
#ifdef DPDK_NR_INT
void* qv_msg_construct(const void *buffer,void **payload,unsigned short *i);
#endif
QMPOOL    qvZMsgPoolCreate( unsigned int attrsize, unsigned int nbuf );
QMPOOL    qvZMsgPoolCreateEx( unsigned int attrsize, unsigned int nbuf, int *cErr);
unsigned int qvZMsgPoolSize( QMPOOL Q, unsigned int *p_alloc );
int    qvZMsgPoolExtend( QMPOOL Q, unsigned int nbuf );
int    qvZMsgPoolExtendEx( QMPOOL Q, unsigned int nbuf, int *cErr);
#ifdef CSPL_LEAK_DEBUG_LITE
void    *qvZMsgAlloc(QMPOOL pool, unsigned int headroom, unsigned int tailroom, unsigned int attrsize,  const char *func, int line);
void    *qvZMsgAllocEx(QMPOOL pool, unsigned int headroom, unsigned int tailroom, unsigned int attrsize, int *cErr,  const char *func, int line);
void    qvZMsgFree(void *buffer, const char* func, int line);
#define    qvZMsgAllocBySize(size)            qvZMsgAlloc(0,0,0,(size),__func__, __LINE__)
#else
void    *qvZMsgAlloc(QMPOOL pool, unsigned int headroom, unsigned int tailroom, unsigned int attrsize);
void    *qvZMsgAllocEx(QMPOOL pool, unsigned int headroom, unsigned int tailroom, unsigned int attrsize, int *cErr);
void    qvZMsgFree(void *buffer);
#define    qvZMsgAllocBySize(size)            qvZMsgAlloc(0,0,0,(size))
#endif

void         qvCleanupMsgPool(void);
unsigned int qvZMsgSize(const void *buffer, unsigned int *attrsize);

#define    qvZMsgAllocFromPool(pool)        qvZMsgAlloc((pool),0,0,0)
#define    qvZMsgAllocFromPoolEx(pool, cErr)    qvZMsgAllocEx((pool),0,0,0, cErr)
#define    qvZMsgAllocBySizeEx(size, cErr)        qvZMsgAllocEx(0,0,0,(size), cErr)


#ifdef CSPL_LEAK_DEBUG_LITE
unsigned char    *qvZMsgReserveEx(void *buffer, int where, unsigned int count, int *cErr,  const char *func, int line);
#else
unsigned char    *qvZMsgReserveEx(void *buffer, int where, unsigned int count, int *cErr);
#endif

#ifdef CSPL_LEAK_DEBUG_LITE
unsigned char    *qvZMsgInsertEx(void *buffer, int where, unsigned char *data,
        unsigned int count, int *cErr,  const char *func, int line);

unsigned char    
    *qvZMsgInsertExternal(void *buffer, int where, unsigned char *data, 
        unsigned int count, 
        void (*freefn)(void *, void *), void *freearg,  const char *func, int line);
#else
unsigned char    *qvZMsgInsertEx(void *buffer, int where, unsigned char *data,
        unsigned int count, int *cErr);

unsigned char    
    *qvZMsgInsertExternal(void *buffer, int where, unsigned char *data, 
        unsigned int count, 
        void (*freefn)(void *, void *), void *freearg);
#endif


#ifdef CSPL_LEAK_DEBUG_LITE
int    qvZMsgRemoveEx(void *buffer, int where, unsigned int count, int *cErr, const char *func, int line);
#else
int    qvZMsgRemoveEx(void *buffer, int where, unsigned int count, int *cErr);
#endif
int    qvZMsgExtract(const void *buffer, int where, unsigned char *data, unsigned int count);
int    qvZMsgExtractEx(const void *buffer, int where, unsigned char *data, unsigned int count, int *cErr);
#ifdef CSPL_LEAK_DEBUG_LITE
void    *qvZMsgCloneEx(const void *buffer, int *cErr,  const char *func, int line);
#else
void    *qvZMsgCloneEx(const void *buffer, int *cErr);
#endif
#ifdef CSPL_LEAK_DEBUG_LITE
void    *qvZMsgCopyEx(void *tobuffer, const void *frombuffer, unsigned int attrsize, int *cErr,  const char *func, int line);
#else
void    *qvZMsgCopyEx(void *tobuffer, const void *frombuffer, unsigned int attrsize, int *cErr);
#endif
#ifdef CSPL_LEAK_DEBUG_LITE
void    *qvZMsgSplitEx(void *frombuffer, unsigned int offset, void *tobuffer, int *cErr,  const char *func, int line);
#else
void    *qvZMsgSplitEx(void *frombuffer, unsigned int offset, void *tobuffer, int *cErr);
#endif

#ifdef CSPL_LEAK_DEBUG_LITE
void    *qvZMsgJoinEx(void *buffer, void *append, int *cErr,  const char *func, int line);
unsigned char   *qvMsgReserveHeadTailRoomEx(void *buffer, int where, unsigned int count, int *cErr, const char *func, int line);
unsigned char   *qvMsgReserveHeadTailRoom(void *buffer, int where, unsigned int count,  const char *func, int line);
#else
void    *qvZMsgJoinEx(void *buffer, void *append, int *cErr);
unsigned char   *qvMsgReserveHeadTailRoomEx(void *buffer, int where, unsigned int count, int *cErr);
unsigned char   *qvMsgReserveHeadTailRoom(void *buffer, int where, unsigned int count);
#endif
unsigned int qvZMsgSegCount( const void *buffer );
void    *qvZMsgSegNext( const void *buffer, void *last, QSEGMENT *segment );
void qvMsgPoolStats( void );
void    *qvMsgJoinAndFree(void *buffer, void *append);
void    *qvMsgJoinAndFreeEx(void *buffer, void *append, int *cErr);
QMPOOL qvMsgPoolForSize(unsigned int size);
unsigned int qvMsgPoolGetUsagePercentage(void);
void qvMsgPoolGetIfUsageHigh(unsigned int usage_high, unsigned int usage_low, unsigned int pctl_high, unsigned int pctl_low, unsigned char* usage);
int qvMsgLocate( void *buffer, int where, unsigned char **pLocation);
int getZMsgPoolStatsInShm(unsigned int poolIndex, unsigned int *allocBuf, unsigned int *peakAllocBuf );
int getZQpctlPoolStatsInShm( unsigned int *allocBuf, unsigned int *peakAllocBuf );
int getZQMsgPoolStatsInShm( unsigned int *allocBuf, unsigned int *peakAllocBuf );
unsigned int getZQMessageSize( void );
unsigned int getZQpctlSize( void );
void qvPrintLeakedMsgBuf( void );
void qvPrintAllocBuf (void);
void qvPrintCurrentBt (void);

#endif

