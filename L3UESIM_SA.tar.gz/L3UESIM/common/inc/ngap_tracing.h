/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2018 Aricent.
 *
 ****************************************************************************
 *
 *  $Id: ngap_tracing.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ***************************************************************************/
#ifndef _NGAP_TRACING_H_
#define _NGAP_TRACING_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#ifndef AMF_SIM_TESTING_ENABLE
#include "gnb_common_utils.h"
#include "ngap_global_ctx.h"
#endif

/****************************************************************************
 * Exported Includes
 ****************************************************************************/
#ifdef AMF_SIM_TESTING_ENABLE
#include "gnb_defines.h"
#include "lteTypes.h"
#endif

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/
extern const SInt8 *rrc_ngap_log_facility_name;

void ngap_set_log_level(UInt8 new_log_level);

extern UInt8 get_ngap_log_level_from_oam_log_level
(
    UInt8 oam_log_level
);

#define NGAP_FATAL       	GNB_FATAL
#define NGAP_ERROR       	GNB_ERROR
#define NGAP_WARNING     	GNB_WARNING
#define NGAP_INFO        	GNB_INFO
#define NGAP_BRIEF       	GNB_BRIEF
#define NGAP_DETAILED    	GNB_DETAILED
#define NGAP_ASN          	GNB_DETAILED
#define NGAP_DETAILEDALL  	GNB_DETAILEDALL


#ifndef AMF_SIM_TESTING_ENABLE
#define RRC_NGAP_TRACE(log_level, format, ...) \
    GNB_LOG(rrc_ngap_log_facility_name, log_level, format, ##__VA_ARGS__)
#else
#define RRC_NGAP_TRACE(log_level, format, ...) \
    printf(format, ##__VA_ARGS__)
#endif
/* If RRC_DEBUG is enabled */
#ifdef RRC_DEBUG

#define RRC_NGAP_UT_TRACE_ENTER()    RRC_NGAP_TRACE(GNB_DETAILED,\
    "Entering function: %s, in file: %s \n",__FUNCTION__,__FILE__)

#define RRC_NGAP_UT_TRACE_EXIT()     RRC_NGAP_TRACE(GNB_DETAILED,\
    "Exiting function: %s, in file: %s \n",__FUNCTION__,__FILE__)

#else

#define RRC_NGAP_UT_TRACE_ENTER()
#define RRC_NGAP_UT_TRACE_EXIT()

#endif /* RRC_DEBUG */

#endif /* _NGAP_TRACING_H_ */
