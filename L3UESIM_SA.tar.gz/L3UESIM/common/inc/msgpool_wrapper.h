/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name msgpool_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : Header file for msgpool library wrapper APIs 
 *
 ****************************************************************************
 ****************************************************************************/

#ifndef _MSGPOOL_WRAPPER_H
#define _MSGPOOL_WRAPPER_H

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "ylib-msgpool.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Types
 ****************************************************************************/
typedef void        *MSGPOOL;
typedef QSEGMENT     MSGSEGMENT;
/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    initMsgPool(UInt32 num_qmsg_buf, UInt32 num_qpctl_buf, UInt32 msg_poolSize[NVARPOOL]);

#define msgPoolCreate(blockSize,nBuf) qvZMsgPoolCreateEx(blockSize, nBuf, 0)
#define msgPoolSize(mPool,p_alloc) (mPool?qvZMsgPoolSize(mPool, p_alloc): 0)
#define msgSize(buffer,blockSize) (buffer?qvZMsgSize(buffer, blockSize): 0)

#define msgAllocAndReserve(headroom,tailroom,blockSize) \
        qvMsgAllocAndReserve(headroom, tailroom, blockSize)

#ifdef CSPL_LEAK_DEBUG_LITE

#define msgInsertExternal(buffer,where,data,count,freefn,freearg) qvZMsgInsertExternal(buffer,where,data,count,freefn,freearg,__func__,__LINE__)

#define msgAlloc(pool,headroom,tailroom,blockSize) \
        qvZMsgAllocEx(pool, headroom, tailroom, blockSize, 0, __func__, __LINE__)

#define msgFree(buffer) (buffer?qvZMsgFree(buffer,__func__, __LINE__):(void)0)

#define msgReserve(buffer,where,count) \
        (buffer?qvZMsgReserveEx(buffer, where, count, 0,__func__, __LINE__): 0)
#define msgInsert(buffer,where,data,count) \
        ((buffer&& data) ? qvZMsgInsertEx(buffer, where, data, count, 0, __func__, __LINE__): PNULL)
#define msgRemove(buffer,where,count) \
        (buffer?qvZMsgRemoveEx(buffer, where, count, 0,__func__, __LINE__): 0)

#define msgReserveHeadTailRoom(buffer,where,count) \
        (buffer?qvMsgReserveHeadTailRoomEx(buffer, where, count, 0,__func__,__LINE__): 0)

#define msgClone(buffer) (buffer ? qvZMsgCloneEx(buffer, 0,__func__, __LINE__) : PNULL)

#define msgCopy(tobuffer,frombuffer,blockSize) \
        ((tobuffer && frombuffer) ? \
                    qvZMsgCopyEx(tobuffer, frombuffer, blockSize, 0, __func__, __LINE__) : PNULL)
#define msgSplit(buffer,offset,tobuffer) \
        ((buffer && tobuffer) ? \
                    qvZMsgSplitEx(buffer, offset, tobuffer, 0, __func__, __LINE__):PNULL)
#define msgJoin(buffer,append) \
        ((buffer && append) ? qvZMsgJoinEx(buffer, append, 0, __func__, __LINE__): PNULL)

#else

#define msgInsertExternal(buffer,where,data,count,freefn,freearg) qvZMsgInsertExternal(buffer,where,data,count,freefn,freearg)
#define msgAlloc(pool,headroom,tailroom,blockSize) \
        qvZMsgAllocEx(pool, headroom, tailroom, blockSize, 0)

#define msgFree(buffer) (buffer?qvZMsgFree(buffer):(void)0)

#define msgReserve(buffer,where,count) \
        (buffer?qvZMsgReserveEx(buffer, where, count, 0): 0)

#define msgInsert(buffer,where,data,count) \
        ((buffer&& data) ? qvZMsgInsertEx(buffer, where, data, count, 0): PNULL)

#define msgRemove(buffer,where,count) \
        (buffer?qvZMsgRemoveEx(buffer, where, count, 0): 0)

#define msgReserveHeadTailRoom(buffer,where,count) \
        (buffer?qvMsgReserveHeadTailRoomEx(buffer, where, count, 0): 0)

#define msgClone(buffer) (buffer ? qvZMsgCloneEx(buffer, 0) : PNULL)

#define msgCopy(tobuffer,frombuffer,blockSize) \
        ((tobuffer && frombuffer) ? \
                    qvZMsgCopyEx(tobuffer, frombuffer, blockSize, 0) : PNULL)
#define msgSplit(buffer,offset,tobuffer) \
        ((buffer && tobuffer) ? qvZMsgSplitEx(buffer, offset, tobuffer, 0):PNULL)
#define msgJoin(buffer,append) \
        ((buffer && append) ? qvZMsgJoinEx(buffer, append, 0): PNULL)

#endif

int qvMsgReplBytesInBuffer( const void *buffer, int where,
        unsigned int numOfBytes, unsigned char *data, int *cErr );

#define msgReplaceBytes(buffer,where,numOfBytes,data)\
    ((buffer && data) ? qvMsgReplBytesInBuffer(buffer, where, numOfBytes, data, 0): 0)

#define msgExtract(buffer,where,data,count) \
        ((buffer && data) ? qvZMsgExtract(buffer, where, data, count): 0)

#define msgLocate(buffer,where,data) ((buffer) ? qvMsgLocate(buffer, where, data): 0)
#define msgSegCount(buffer) (buffer ? qvZMsgSegCount(buffer):0)
#define msgSegNext(buffer,last,segment) (buffer?qvZMsgSegNext(buffer, last, segment):PNULL)
#define msg_construct_io_vec(buffer,io_vec,num_segments) (buffer?qv_msg_construct_io_vec(buffer, io_vec,num_segments):0)
#define getMsgPoolStats qvMsgPoolStats
#define resetMsgPoolPeakVal qvResetMsgPoolPeakVal
#define cleanupMsgPool qvCleanupMsgPool
#define msgJoinAndFree(buffer,append) ((buffer && append) ? qvMsgJoinAndFreeEx(buffer, append, 0): PNULL)
#ifdef DPDK_NR_INT
#define dpdk_msg_construct(buffer,payload,num_segments) (buffer?qv_msg_construct(buffer,payload,num_segments):PNULL)
#endif

#define msgPoolExtend(blockSize,nBuf)\
{\
    QMPOOL  msgPool;\
    msgPool=qvMsgPoolForSize(blockSize);\
    if(!msgPool)\
    {\
       nrPanic("Message pool for size %d not present\n",blockSize);\
    }\
    else if(!qvZMsgPoolExtend(msgPool,nBuf))\
    {\
        nrPanic("Failed to extend pool for size%d\n",blockSize);\
    }\
}

#ifdef SHM_ENABLED
void freeShmMemory(void * ptr1, void * ptr2 );
typedef struct
{
    /*write index, can only be updated by sending side after sending a message*/
    unsigned int nWriteIdx;

    /*read index, can only be updated by receiving side after received a message,
      no messages when nWriteIdx = nReadIdx*/
    unsigned int nReadIdx;

    /*in each message, the 1st 4 byte is length, remaining bytes are payload*/
    /* Variable length and payload field:
       Each PDUData block includes:
       1)UWORD32 nLen: message length
       2)UWORD8 pMsg[nLen]: message payload

       |-|---|-|-|---|-------|---|-------------|---------------|
       Byte         |0|...|3|4|...|3+nLen|....| ... ...     |ring counter-1|
       |--------|------------|---|-----------------------------|
       pMsgBuf     |nLen- |ringSize |.....    | ... ... |
       |--------|------------|---|-----------------------------|
*/
    unsigned char pMsgBuf[1];
}memory_header_s1;
#endif


#endif /* _MSGPOOL_WRAPPER_H */
