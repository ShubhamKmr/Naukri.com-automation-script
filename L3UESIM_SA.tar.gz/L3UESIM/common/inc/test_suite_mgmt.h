/***************************************************************************
 * *
 * *  ARICENT -
 * *
 * *  Copyright (c) 2018 Aricent.
 * *
 * ****************************************************************************
 * *
 * *  File Description : This file contains the prototypes/definitions for
 * *                     detecting any other message received at stack 
 * *                     than expected in Add_suite
 * *
 * *
 * ***************************************************************************/

#ifndef _TEST_SUITE_MGMT_H_
#define _TEST_SUITE_MGMT_H_

#include<semaphore.h>

#if 0
extern int receiving_message;

int detect_unexpected_msg_received(int apiId);
int detect_unexpected_message(int api_id);
int search_in_list_expected_msgs(int api_id);

void debug_print_test_suite();
void add_to_tail(int apiId);
msg_list_node_t* fetch_rcv_token();
void remove_from_head();
msg_list_t* construct_msg_list();
void destruct_msg_list();
int init_msg_list();
char* test_print_helper_add_suite(int id);
#endif
/*PUE Changes*/
typedef struct _sim_activity_t
{
    /*Message Type S or R*/
    unsigned char    msg_type;
    
    /*Message Id i.e API ID*/
    unsigned int     msg_id;

    /*File Name of xml file*/
    char             xml[256];

    /*Waiting time for response*/
    unsigned int     delay_sec;

    /*Address of next node*/
    struct _sim_activity_t *next;

}sim_activity_t;


#if 0
typedef struct _sim_test_trans_node_t
{
    /*Activity List*/
    sim_activity_t *act_list;

    /*right link*/
    struct _sim_test_trans_node_t *next;

    /*Left Link*/
    struct _sim_test_trans_node_t *prev;

}sim_test_trans_node_t;
#endif


typedef struct _sim_test_case_node_t
{
    /*First part of test case i.e Test Suite Name*/
    char *TEST_ID;

    /*count of nu of nodes to make based on repetetion count in test suite*/
    int node_count;

    /*Activity List*/
    sim_activity_t *act_list;
    sim_activity_t *x2_act_list;
    sim_activity_t *amf_act_list;

    /*right connection*/
    struct _sim_test_case_node_t *next;

    /*lft connection*/
    struct _sim_test_case_node_t *prev;

    /*Semaphore */
    sem_t sem;


}sim_test_case_node_t;
/*PUE Changes*/
#endif
