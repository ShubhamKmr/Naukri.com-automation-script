/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name thread_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 *
 ****************************************************************************/

#ifndef _THREAD_WRAPPER_H_
#define _THREAD_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
/****************************************************************************
 * Exported Includes
 ****************************************************************************/
#include "gnb_types.h"
#include "cspl.h"

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Function Name  : threadCleanupPush 
 * Inputs         : routine - address of function
 *                  arg - argument to routine.
 * Outputs        : None.
 * Returns        : None.
 * Variables      : None.
 * Description    : threadCleanupPush installs the routine function with
 *                  argument arg as a cleanup handler. From this point on
 *                  to the matching pthread_cleanup_pop,the function routine
 *                  will be called with arguments arg when the thread
 *                  terminates .
 *                 
 ****************************************************************************/
#define threadCleanupPush(routine, arg)\
                pthread_cleanup_push(routine,arg)


/****************************************************************************
 * Function Name  : threadCleanupPop 
 * Inputs         : execute- Non Zero: it also executes the handler
 *                           0       : the handler is only removed but 
 *                                     not executed.
 * Outputs        : None.
 * Returns        : None.
 * Variables      : None.
 * Description    : threadCleanupPop removes the most recently installed 
 *                  cleanup handler.
 ****************************************************************************/
#define threadCleanupPop(arg)\
                pthread_cleanup_pop(arg)


#define THREAD_TO_BIND_SET_SHARED_CORE_NO(threadId,bitmap) {\
    UInt16 bitMap = bitmap;\
    cpu_set_t cpuSetSch; \
    CPU_ZERO(&cpuSetSch);\
    UInt8 i=0;\
    for(i=1;i<=32;i++)\
    { \
        if(bitMap & (1 << (i - 1))) \
        CPU_SET((i-1) ,&cpuSetSch);\
    }\
    if (pthread_setaffinity_np(threadId,sizeof(cpuSetSch),&cpuSetSch)) \
    { \
        nrPanic("Set affinity failed"); \
    } \
}
/* Macro for Shared Thread  Binding */
#define PROCESS_TO_BIND_SET_SHARED_CORE_NO(pid,bitmap) {\
        UInt16 bitMap = bitmap;\
        cpu_set_t cpuSetSch;\
        CPU_ZERO(&cpuSetSch);\
        UInt8 i = 0;\
        for(i=1;i<=32;i++)\
        {\
            if(bitMap & (1 << (i - 1))) \
            CPU_SET((i-1) ,&cpuSetSch);\
        }\
        if (-1 == sched_setaffinity_wrapper(pid,sizeof(cpuSetSch),&cpuSetSch)) \
        { \
                    nrPanic("Set affinity failed"); \
        } \
}


/* Macro for Thread Binding */
#define THREAD_TO_BIND_SET_CORE_NO(threadId,corenum) {\
    cpu_set_t cpuSetSch; \
    int temp_coreNum = 0; \
    temp_coreNum = corenum; \
    CPU_ZERO(&cpuSetSch);\
    CPU_SET(temp_coreNum ,&cpuSetSch); \
    if (pthread_setaffinity_np(threadId,sizeof(cpuSetSch),&cpuSetSch)) \
    { \
        nrPanic("Set affinity failed"); \
    } \
}

#define THREAD_TO_BIND_GET_CORE_NO(threadId) {\
    cpu_set_t cpuSetSch; \
    int j = 0; \
    CPU_ZERO(&cpuSetSch);\
    if (pthread_getaffinity_np(threadId,sizeof(cpuSetSch),&cpuSetSch)) \
    { \
        nrPanic("Get affinity failed"); \
    } \
    else \
    {\
       for (j = 0; j < CPU_SETSIZE; j++)\
        {\
            if (CPU_ISSET(j, &cpuSetSch))\
            {\
                /* NR_LOG(LOG_INFO,PNULL, "Thread %lu Binded on VCPU %d\n",threadId, j); */\
            }\
        }\
    } \
}


#define PROCESS_TO_BIND_SET_CORE_NO(pid,corenum) {\
    cpu_set_t cpuSetSch; \
    int coreNum = 0; \
    CPU_ZERO(&cpuSetSch);\
    coreNum = corenum ; \
    CPU_SET(coreNum ,&cpuSetSch); \
    if (-1 == sched_setaffinity_wrapper(pid,sizeof(cpuSetSch),&cpuSetSch)) \
    { \
        nrPanic("Set affinity failed"); \
    } \
}
#define PROCESS_TO_BIND_GET_CORE_NO(pid,corenum) {\
    cpu_set_t cpuSetSch; \
    int coreNum = 0; \
    CPU_ZERO(&cpuSetSch);\
    coreNum = corenum ; \
    CPU_SET(coreNum ,&cpuSetSch); \
    if (-1 == sched_getaffinity(pid,sizeof(cpuSetSch),&cpuSetSch)) \
    { \
        nrPanic("Get affinity failed"); \
    } \
}

#define MAX_THREAD_NAME_LEN 20

/****************************************************************************
 * Exported Types
 ****************************************************************************/
enum
{
    /* thread is created in the joinable state */
    THREAD_CREATE_JOINABLE = PTHREAD_CREATE_JOINABLE, 
    /* thread is created in the detached state */
    THREAD_CREATE_DETACHED = PTHREAD_CREATE_DETACHED, 
    /* default state */
    THREAD_DEFAULT_STATE = THREAD_CREATE_JOINABLE 
};


enum
{
    /* regular,  non-realtime  scheduling */
    THREAD_SCHED_OTHER = SCHED_OTHER, 
    /* realtime,  round robin*/
    THREAD_SCHED_RR = SCHED_RR, 
    /* realtime, first-in first-out*/
    THREAD_SCHED_FIFO = SCHED_FIFO, 
    /* default scheduling*/
    THREAD_SCHED_DEFAULT = THREAD_SCHED_OTHER 
};


enum
{
    /* scheduling parameters for the newly created thread are determined by schedpolicy 
     and priority*/
    THREAD_EXPLICIT_SCHED = PTHREAD_EXPLICIT_SCHED, 
    /* Inherited  from  the  parent  thread*/
    THREAD_INHERIT_SCHED = PTHREAD_INHERIT_SCHED, 
    /* default inheritance of scheduling parameters*/
    THREAD_INHERIT_SCHED_DEFAULT = PTHREAD_EXPLICIT_SCHED 
};


enum
{
    /* threads contend for CPU time with all processes running on the machine*/
    THREAD_SCOPE_SYSTEM = PTHREAD_SCOPE_SYSTEM, 
    /* threads contend for CPU time only between the threads of the running process */
    THREAD_SCOPE_PROCESS = PTHREAD_SCOPE_PROCESS, 
    /* default thread scope */
    THREAD_SCOPE_DEFAULT = PTHREAD_SCOPE_SYSTEM
};


enum
{
    /*cancel state - enable /disable*/
    THREAD_CANCEL_ENABLE = PTHREAD_CANCEL_ENABLE,
    THREAD_CANCEL_DISABLE = PTHREAD_CANCEL_DISABLE
};
enum
{
    /* cancel type deferred /asynchronous*/
    THREAD_CANCEL_DEFERRED = PTHREAD_CANCEL_DEFERRED,
    THREAD_CANCEL_ASYNCHRONOUS = PTHREAD_CANCEL_ASYNCHRONOUS
};

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/

/****************************************************************************
 *  function(): Description.
 *      Creates a new thread.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/
SInt32  threadCreate(ULong32 *tId, SInt32 detachState, 
        SInt32    schedPol, SInt32 priority, SInt32 inheritSched, SInt32 scope,
        SInt8* threadName,void * (*func)(void *), void *arg);

/****************************************************************************
 *  function(): Description.
 *      Waits for other thread to finish.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/

void    threadJoin(ULong32 tId, void **status);


/****************************************************************************
 *  function(): Description.
 *      Thread Exit API.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/
void    threadExit(void *retVal);


/****************************************************************************
 *  function(): Description.
 *      Detaches the thread from the parent thread.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/
void    threadDetach(ULong32 tId);


/****************************************************************************
 *  function(): Description.
 *      Returns the identifier for the current thread.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/
ULong32    threadSelf(void);


/****************************************************************************
 *  function(): Description.
 *      Cancels the execution of thread with tId as thread identifier.
 *
 *  Parameters:
 *
 *  Return values:
 *
 ****************************************************************************/
SInt32    threadCancel(ULong32 tId);

/****************************************************************************
 * Function Name  : pthread_setcancelstate
 * Inputs         : state - enable /disabled.
 * Outputs        : None.
 * Returns        : 0 on success, Error code on failure.
 * Variables      : None.
 * Description    : The function  changes  the  cancellation  state  for the
 *                  calling thread -- that is, whether cancellation requests 
 *                  are ignored or not.
 ****************************************************************************/
SInt32 threadSetCancelState(UInt32 state, SInt32* oldState);


/****************************************************************************
 * Function Name  : threadSetCancelType 
 * Inputs         : state - deferred/asynchronous.
 * Outputs        : None.
 * Returns        : 0 on success, Error code on failure.
 * Variables      : None.
 * Description    : threadSetCancelType changes the type of responses 
 *                  to cancellation requests for the calling thread: 
 *                  asynchronous  (immediate)  or  deferred.
 *                 
 ****************************************************************************/
SInt32 threadSetCancelType(UInt32 state, SInt32* oldState);

/****************************************************************************
 * Function Name  : threadSetRtPriority
 * Inputs         : policy - policy to set
 *                  priority - priority to set.
 * Outputs        : None.
 * Returns        : 0 on success, Error code on failure.
 * Variables      : None.
 * Description    : This function sets the realtime priority and policy for the
 *                  calling thread.
 *                 
 ****************************************************************************/
SInt32 threadSetRtPriority(int policy, int priority);
SInt32 threadKill(ULong32 thread, SInt32 sig);
SInt32 threadEqual(ULong32 tId1, ULong32 tId2);
#endif  
