/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2014 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file l3_pdcp_il_parser.h contains the prototypes 
 *                     of RRC-PDCP interface message parsing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _l3_PDCP_IL_PARSER_H_
#define _l3_PDCP_IL_PARSER_H_

#include "gnb_defines.h"
#include "l3_pdcp_intf.h"

gnb_return_t
gnb_il_parse_rrc_pdcp_cr_ue_entity_req
(
    rrc_pdcp_cr_ue_entity_req_t *p_rrc_pdcp_cr_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_cr_ue_entity_cnf
(
    pdcp_rrc_cr_ue_entity_cnf_t *p_pdcp_rrc_cr_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_del_ue_entity_req
(
    rrc_pdcp_del_ue_entity_req_t *p_rrc_pdcp_del_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_del_ue_entity_cnf
(
    pdcp_rrc_del_ue_entity_cnf_t *p_pdcp_rrc_del_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_reconf_ue_entity_req
(
    rrc_pdcp_reconf_ue_entity_req_t *p_rrc_pdcp_reconf_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_reconfig_ue_entity_cnf
(
    pdcp_rrc_reconfig_ue_entity_cnf_t *p_pdcp_rrc_reconfig_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_srb_dl_data_req
(
    rrc_pdcp_srb_dl_data_req_t *p_rrc_pdcp_srb_dl_data_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_srb_dl_data_resp
(
    pdcp_rrc_srb_dl_data_resp_t *p_pdcp_rrc_srb_dl_data_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_srb_ul_data_req
(
    rrc_pdcp_srb_ul_data_req_t *p_rrc_pdcp_srb_ul_data_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_srb_ul_data_resp
(
    pdcp_rrc_srb_ul_data_resp_t *p_pdcp_rrc_srb_ul_data_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_sn_hfn_status_req
(
    rrc_pdcp_sn_hfn_status_req_t *p_rrc_pdcp_sn_hfn_status_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_sn_hfn_status_resp
(
    pdcp_rrc_sn_hfn_status_resp_t *p_pdcp_rrc_sn_hfn_status_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_sn_hfn_status_ind
(
    rrc_pdcp_sn_hfn_status_ind_t *p_rrc_pdcp_sn_hfn_status_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_data_buffer_stop_ind
(
    rrc_pdcp_data_buffer_stop_ind_t *p_rrc_pdcp_data_buffer_stop_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_mac_i_req
(
    rrc_pdcp_mac_i_req_t *p_rrc_pdcp_mac_i_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_mac_i_resp
(
    pdcp_rrc_mac_i_resp_t *p_pdcp_rrc_mac_i_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_re_establish_ue_entity_req
(
    rrc_pdcp_re_establish_ue_entity_req_t *p_rrc_pdcp_re_establish_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_re_establish_ue_entity_cnf
(
    pdcp_rrc_re_establish_ue_entity_cnf_t *p_pdcp_rrc_re_establish_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_suspend_ue_entity_req
(
    rrc_pdcp_suspend_ue_entity_req_t *p_rrc_pdcp_suspend_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_suspend_ue_entity_cnf
(
    pdcp_rrc_suspend_ue_entity_cnf_t *p_pdcp_rrc_suspend_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_resume_ue_entity_req
(
    rrc_pdcp_resume_ue_entity_req_t *p_rrc_pdcp_resume_ue_entity_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_resume_ue_entity_cnf
(
    pdcp_rrc_resume_ue_entity_cnf_t *p_pdcp_rrc_resume_ue_entity_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_change_crnti_req
(
    rrc_pdcp_change_crnti_req_t *p_rrc_pdcp_change_crnti_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_change_crnti_cnf
(
    pdcp_rrc_change_crnti_cnf_t *p_pdcp_rrc_change_crnti_cnf,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_count_wraparound_ind
(
    pdcp_rrc_count_wraparound_ind_t *p_pdcp_rrc_count_wraparound_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_notify_integrity_failure
(
    pdcp_rrc_notify_integrity_failure_t *p_pdcp_rrc_notify_integrity_failure,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_drb_count_msb_req
(
    rrc_pdcp_drb_count_msb_req_t *p_rrc_pdcp_drb_count_msb_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_drb_count_msb_resp
(
    pdcp_rrc_drb_count_msb_resp_t *p_pdcp_rrc_drb_count_msb_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_config_cell_req
(
    rrc_pdcp_config_cell_req_t *p_rrc_pdcp_config_cell_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_config_cell_resp
(
    pdcp_rrc_config_cell_resp_t *p_pdcp_rrc_config_cell_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_ho_prep_info_req
(
    rrc_pdcp_ho_prep_info_req_t *p_rrc_pdcp_ho_prep_info_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_ho_prep_info_resp
(
    pdcp_rrc_ho_prep_info_resp_t *p_pdcp_rrc_ho_prep_info_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_inactive_ues_ind
(
    pdcp_rrc_inactive_ues_ind_t *p_pdcp_rrc_inactive_ues_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_purge_cell_ues_req
(
    rrc_pdcp_purge_cell_ues_req_t *p_rrc_pdcp_purge_cell_ues_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_purge_cell_ues_resp
(
    pdcp_rrc_purge_cell_ues_resp_t *p_pdcp_rrc_purge_cell_ues_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_cell_delete_resp
(
    pdcp_rrc_cell_delete_resp_t *p_pdcp_rrc_cell_delete_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_data_report_req
(
    rrc_pdcp_data_report_req_t *p_rrc_pdcp_data_report_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_data_report_resp
(
    rrc_pdcp_data_report_resp_t *p_rrc_pdcp_data_report_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_change_cell_req
(
    rrc_pdcp_change_cell_req_t *p_rrc_pdcp_change_cell_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_change_cell_resp
(
    pdcp_rrc_change_cell_resp_t *p_pdcp_rrc_change_cell_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_rrc_pdcp_drbid_lcid_map_ind
(
    rrc_pdcp_drbid_lcid_map_ind_t *p_rrc_pdcp_drbid_lcid_map_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_pdcp_rrc_traffic_inactivity_ind
(
    pdcp_rrc_traffic_inactivity_ind_t *p_pdcp_rrc_traffic_inactivity_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

#endif /* _l3_PDCP_IL_PARSER_H_ */
