/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) Aricent.
 *
 ****************************************************************************
 *
 *  $Id: lteTypes.h,v 1.1.1.1.16.3 2010/10/25 10:48:04 gur23971 Exp $
 *
 ****************************************************************************
 *
 *  File Description : It contains the common types.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 *
 * $Log: lteTypes.h,v $
 * Revision 1.1.1.1.16.3  2010/10/25 10:48:04  gur23971
 * warning removed
 *
 * Revision 1.1.1.1.16.2  2010/10/25 09:11:47  gur22055
 * warning removal for multiple declaration
 *
 * Revision 1.1.1.1.16.1  2010/09/29 16:00:32  gur20491
 * updated for data types
 *
 * Revision 1.1.1.1  2010/02/11 04:51:26  cm_intel
 * eNB framework for intel
 *
 * Revision 1.5.2.1  2009/06/09 11:24:46  gur19140
 * first wave of Integration
 *
 * Revision 1.6  2009/05/06 05:39:22  gur20548
 * pdcp common merged with lte common
 *
 * Revision 1.5  2009/04/10 17:22:38  gur18569
 * merged with optmization changes
 *
 * Revision 1.4  2008/10/22 12:41:44  gur11912
 * fixed for performance changes
 *
 * Revision 1.3  2008/09/09 04:55:14  gur11974
 * Added types UChar,UDouble32 and PNULL.
 *
 * Revision 1.2  2008/08/25 10:04:35  ssinghal
 * Template applied and minor changes done
 *
 *
 *
 *
 ****************************************************************************/

#ifndef INCLUDED_LTE_TYPES_H
#define INCLUDED_LTE_TYPES_H

/****************************************************************************
 * Project Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Includes
 ****************************************************************************/



/****************************************************************************
 * Exported Definitions
 ****************************************************************************/
/****************************************************************************
 * Exported Types
 ****************************************************************************/
typedef signed int     Int;
typedef unsigned char   UInt8;
typedef unsigned short  UInt16;
typedef unsigned int    UInt32;
typedef unsigned long    ULong32;
typedef unsigned long long   UInt64;
typedef unsigned char   UChar8;
typedef  char   	SInt8;
typedef char            Char8;
typedef signed short    SInt16;
typedef signed int      SInt32;
typedef signed long long     SInt64;
typedef float           UDouble32;
typedef double          UDouble64;

typedef unsigned long   U32Long;
typedef signed long     S32Long;
typedef unsigned long long  U64;
typedef unsigned int    U32;
typedef unsigned short  U16;
typedef unsigned char   U8;
typedef signed int      S32;
typedef signed short    S16;
typedef signed char     S8;


#ifndef _PNULL_
#define _PNULL_
#define PNULL NULL
#endif /*_PNULL_*/
/* SPR 19288 change start */
/* SPR 20688 fix start*/
#ifdef FSL_SEC_ENGINE
typedef UInt32 tickType_t;
#else
/* SPR 15909 fix start */
typedef UInt64 tickType_t;
/* SPR 15909 fix end */
#endif
/* SPR 20688 fix end*/
/* SPR 19288 change end */
/* +- SPR 17777 */
#define LTE_GCC_UNUSED_PARAM(param) (void)param;
/* +- SPR 17777 */


#define LTE_FALSE                             0
#define LTE_TRUE                              1 

#define LTE_LOG_CRITICAL                      0
#define LTE_LOG_ERROR                         1
#define LTE_LOG_WARNING                       2
#define LTE_LOG_INFO                          3
#define LTE_LOG_BRIEF                         4
#define LTE_LOG_DETAILED                      5
#define LTE_LOG_DETAILEDALL                   6

#define LTE_L2_LOG_INVALID                    0
#define LTE_L2_LOG_NONE                       LTE_L2_LOG_INVALID
#define LTE_L2_LOG_CRITICAL                   (LTE_LOG_CRITICAL + 1)    /*1*/
#define LTE_L2_LOG_ERROR                      (2 * LTE_L2_LOG_CRITICAL) /*2*/
#define LTE_L2_LOG_WARNING                    (2 * LTE_L2_LOG_ERROR)    /*4*/
#define LTE_L2_LOG_INFO                       (2 * LTE_L2_LOG_WARNING)  /*8*/
#define LTE_L2_LOG_BRIEF                      (2 * LTE_L2_LOG_INFO)     /*16*/
#define LTE_L2_LOG_DETAILED                   (2 * LTE_L2_LOG_BRIEF)    /*32*/
#define LTE_L2_LOG_DETAILEDALL                (2 * LTE_L2_LOG_DETAILED) /*64*/

/* SPR 20874 start */
#define SPS_QCI     1 
/* SPR 20874 end */
/* SPR 9381 changes start */
/* SPR 14759 Start */
#ifdef TDD_CONFIG
#define MAX_UL_UE_SCHEDULED ((32 > (2*MAX_UE_SUPPORTED)) ? ((2*MAX_UE_SUPPORTED)):32)
/* SPR 14759 End */
#else
/* SPR 22099 Fix + */
#ifdef INTEL_COMMON
#define MAX_UL_UE_SCHEDULED ((8 > MAX_UE_SUPPORTED) ? MAX_UE_SUPPORTED:8)
#else
#define MAX_UL_UE_SCHEDULED ((16 > MAX_UE_SUPPORTED) ? MAX_UE_SUPPORTED:16)
#endif 
#endif 
#ifdef INTEL_COMMON
#define MAX_DL_UE_SCHEDULED ((8 > MAX_UE_SUPPORTED) ? MAX_UE_SUPPORTED:8)
#else
#define MAX_DL_UE_SCHEDULED ((16 > MAX_UE_SUPPORTED) ? MAX_UE_SUPPORTED:16)
#endif 
/* SPR 22099 Fix - */
/* SPR 9381 changes end */

/* SPR 16116 fix start */
#define MAX_TOP_SCHEDULABLE_UE_LIST_SIZE (MAX_DL_UE_SCHEDULED*2)
/* SPR 16116 fix end */
#ifdef DEBUG_STATS
#define LC_1_MAX_DATA 32
#define LC_2_MAX_DATA 32
#define LC_3_MAX_DATA 1024
#define MAX_DATA_BYTES 16
typedef struct pduUlDebugInfoT
{
    UInt8 strorePduDataLC1[LC_1_MAX_DATA][MAX_DATA_BYTES];
    UInt8 strorePduDataLC2[LC_2_MAX_DATA][MAX_DATA_BYTES];
    UInt8 strorePduDataLC3[LC_3_MAX_DATA][MAX_DATA_BYTES];
    UInt32 tick1[LC_1_MAX_DATA];
    UInt32 tick2[LC_2_MAX_DATA];
    UInt32 tick3[LC_3_MAX_DATA];
    UInt16 lc1Idex;
    UInt16 lc2Idex;
    UInt16 lc3Idex;
}pduUlDebugInfo;
#endif

/* CA changes start */
typedef UInt8 RrcCellIndex;
typedef UInt8 InternalCellIndex;
typedef UInt8 ServingCellIndex;
#ifdef BROADCOM_CA_INT
#ifdef BRCM_DEBUG_STATS
#define MAX_NUM_UE_DEBUG 34

typedef struct pduDlDebugInfoT
{
    UInt8 strorePduDataLC[LC_3_MAX_DATA][MAX_DATA_BYTES];
    UInt32 tick[LC_3_MAX_DATA];
    UInt16 lcIdex;
}pduDlDebugInfo;
#endif

/* Following macro denotes GTP header + offset length */
#define GTP_HDR_OFFSET_LENGTH 0x48

/* Following macros define the region from which BRCM shared memory needs to be
 * allocated */
#define PDCP_AREA_IDX UL_AREA_IDX
#define MAC_AREA_IDX  UL_AREA_IDX

/* Following macros define the various mailbox ports */
#define PDCP_MAILBOX_PORT 11
#define OAM_MAILBOX_PORT  15
#define RRC_MAILBOX_PORT  17
#define MAC_MAILBOX_PORT  25
#define GTPU_MAILBOX_PORT 27
/* These PIDs are mapped to RRC dst IDs*/
/* PID for L2 interface with RRC */
#define PID_RRC_PDCP 5
#define PID_RRC_RLC  6
#define PID_RRC_MAC  7
#define PID_RRC_PHY  8
/* PID for L2 interface with OAM */
#define PID_OAM_PDCP 2
#define PID_OAM_RLC  9
#define PID_OAM_MAC  10
/* PID for L2 interface with RRM */
#define PID_RRM_MAC  13
#define PID_RRM_PDCP 14
/* PID for communication between PDCP and Packet Relay */
#define PID_GTPU     22
#define PID_FREE 99
#define PID_INVALID 0
/*+ SPR 18399*/
#define NMM_MAILBOX_PORT 30
#define MAILBOX_SON_PORT_SIZE 3000 
#define PID_NMM_SNIFFER_MSG 25
/*- SPR 18399*/


/* 2 bytes for len & 2 for PID*/
#define MB_HDR 4
#define MAX_ELEM_PRC_COPY 256
/*SPR 17771 start*/
#define MAX_BUFFER_SIZE_FOR_PDU 2020
/*SPR 17771 end*/ 
#define MAX_MULTI_PDU_COUNT 50
#define MAX_PDU_IN_FREE_LIST 50
#define PDCP_GTPUAPP_MAILBOX_SIZE 20*1024
#define MAX_NUM_PDU_IN_UL 5
#define MAILBOX_PORT_SIZE 1024*5 /* SPR21135 +- */
#define MAX_NUM_CIPHER_PDU 32
#define MAX_NUM_DCIPHER_PDU 32
#define MAX_NUM_SDU_FOR_DMA 32
#define MAC_MAILBOX_PORT_SIZE 1024*10

/* SPR 19310 +- */

#define MAILBOX_REF_MSG_SIZE 8
#define OAM_MAILBOX_SOCK_PORT 60002
#define RRM_MAILBOX_SOCK_PORT 60001
#define RRC_MAILBOX_SOCK_PORT 60003

typedef struct MailBoxHdr_t
{
    UInt16 pId;
    UInt16 bufLen;
    UInt8* buf_ptr;
}MailBoxHdr;

#define MAX_MB_MSG_SIZE 1024*7
#define MAX_FREE_PDU_COUNT 32
#define MAX_MAIL_BUFF_SIZE MAX_MB_MSG_SIZE-4

typedef struct MultiPdu_T{
    UInt8* mbuf_p;
    UInt16 mbuf_len;
}MultiPdu;

typedef struct Hdr_T{
    MultiPdu mPdu;
    UInt8 msgId;
}PduHdr;
typedef struct MailBufT
{
    UInt16 pId;
    UInt16 bufLen;
    UInt8 buffer[MAX_MAIL_BUFF_SIZE];
}MailBuf;

typedef struct MailPDU_T
{
    UInt32 bufLen;
    UInt8 *buf_p;
}MailPDU;

typedef struct MailBufferT
{
    UInt16 pId;
    UInt16 numPDU;
    MailPDU pdu[MAX_PDU_IN_FREE_LIST];
}MailBuffer;
#endif
/* Maximum number of Cells supported in Layer 2 */
/* spr 24900 changes start */
//#define MAX_NUM_CELL        2
/* spr 24900 changes end */
#define MAX_NUM_FD_CONTAINER 2
/* Maximum number of Secondary Cells supported in Layer 2 */
#define MAX_NUM_SCELL       1
#define MAX_NUM_PCELL       1
#define MAX_FREQ_BAND_INDICATOR         64
#define MAX_EARFCN                   65535
#define PCELL_SERV_CELL_IX  0
#define MAX_SCELLS          7
#define MAX_SERVCELL ((MAX_NUM_PCELL)+(MAX_SCELLS))
//#define INVALID_CELL_INDEX  0xFF
/* Ue specific APIs use this cellIndex */
/* + SPR 10767 Fix */
//#define API_HEADER_DO_NOT_CARE_CELL_INDEX  0xff
/* - SPR 10767 Fix */
/* External Cell Index can be from 0...7 */
#ifdef CRAN_RLC_PDCP_SPLIT 
#define MAX_RRC_CELL_INDEX  ((MAX_NUM_L2_INSTANCE * MAX_NUM_CELL )-1)
#else
#define MAX_RRC_CELL_INDEX  7
#endif
/* External Cell Index can be from 0...1 */
#define MAX_INTERNAL_CELL_INDEX  (MAX_NUM_CELL -1)
#ifdef CRAN_RLC_PDCP_SPLIT
#define MAX_INTERNAL_CELL_INDEX_PDCP ((MAX_NUM_L2_INSTANCE * MAX_NUM_CELL )-1)
#endif
/* e.g 11110000 for  numBits = 4 */
#define GETMASK_LEFT_ALIGNED(numBits) ((~(~0U >> (numBits))))
/* e.g 00001111 for  numBits = 4 */
#define GETMASK_RIGHT_ALIGNED(numBits) ((~(~0U << (numBits))))   

/* set given range of bits in Byte to zero*/
#define ZERO_BYTE_FIELD(byte,sBitN,numBits) ((byte) &= ~(GETMASK_RIGHT_ALIGNED(numBits) << (sBitN)))
/* set given range of bits to value */
#define SET_BYTE_FIELD(byte,value,sBitN,numBits) (ZERO_BYTE_FIELD(byte,sBitN,numBits), ((byte) |= ((value) & GETMASK_RIGHT_ALIGNED(numBits)) << (sBitN)) )

//#define MAX_QCI                  9
/* following number will represent number of UEs in 
 * one batch while reporting throughput KPI */
#define MAX_UE_PER_BATCH         10
#define MAX_SPS_INTERVALS        16
#define SPS_INTERVAL_LIST        16
#define MAX_LCID_THP             8
#define MAX_LOGICAL_CHANNEL      11
#define MAX_NUMBER_OF_LOGICAL_CHANNEL      MAX_LOGICAL_CHANNEL
#ifdef CRAN_RLC_PDCP_SPLIT
#define MAX_NUM_L2_INSTANCE    6
#else
#define MAX_NUM_L2_INSTANCE    3
#endif

/*SPR 22325 Start*/

#ifdef INTEL_COMMON
#define MAX_UE_SUPPORTED       128
#elif HIGH_SCALABILITY_L2_MAX_UE
#define MAX_UE_SUPPORTED       1210
#elif HIGH_SCALABILITY_L3_MAX_UE
#define MAX_UE_SUPPORTED       3630
#else
//#define MAX_UE_SUPPORTED       260
#endif

/*SPR 22325 End*/


#define MAX_CQI_INDEX 16

/****************************************************************************
 * Exported Constants
 ****************************************************************************/
#define MAX_UINT32_VALUE  ((UInt32)4294967295U)

/* SPR 18122 Changes Start */
#define DIVIDE_BY_TWO(x) ((x) >> 1)
#define DIVIDE_BY_FOUR(x) ((x) >> 2)
#define DIVIDE_BY_EIGHT(x) ((x) >> 3)
#define DIVIDE_BY_SIXTEEN(x) ((x) >> 4)
#define DIVIDE_BY_THIRTY_TWO(x) ((x) >> 5)
#define DIVIDE_BY_SIXTY_FOUR(x) ((x) >> 6)
#define DIVIDE_BY_1024(x) ((x) >> 10)

#define MULTIPLY_BY_TWO(x) ((x) << 1)
#define MULTIPLY_BY_FOUR(x) ((x) << 2)
#define MULTIPLY_BY_EIGHT(x) ((x) << 3)
#define MULTIPLY_BY_SIXTEEN(x) ((x) << 4)
#define MULTIPLY_BY_ONEZEROTWOFOUR(x) ((x) << 10)
#define MODULO(x,d) ((x)&(d-1))
/* SPR 20636 Changes Start */
#ifdef INTEL_COMMON
/* SPR 21494 Start */
#define DIVIDE_BY_AGGR_LBL_TWO(x) ((x) >> 1)
#define DIVIDE_BY_AGGR_LBL_FOUR(x) ((x) >> 2)
#define DIVIDE_BY_AGGR_LBL_EIGHT(x) ((x) >> 3)
#define MULTIPLY_BY_AGGR_LBL_TWO(x) ((x) << 1)
#define MULTIPLY_BY_AGGR_LBL_FOUR(x) ((x) << 2)
#define MULTIPLY_BY_AGGR_LBL_EIGHT(x) ((x) << 3)
/* SPR 21494 End */
#endif
#ifdef __x86_64__
#define ADDR UInt64
#else
#define ADDR UInt32
#endif
/* SPR 20636 Changes End */
/* SPR 18122 Changes End */
#define MAX_SFN_VALUE         1024  /*As per 36.331 SFN is of 10 bits*/
#define MAX_SFN MAX_SFN_VALUE
#define MAX_SUBFRAME 10
#define MAX_SUB_FRAME MAX_SUBFRAME
#define MAX_SF_VALUE  MAX_SUBFRAME
#define NUM_OF_SFN_BITS  10 
#define NUM_OF_SF_BITS    4

#define LTE_GET_U16BIT(p_buff)                                        \
    ((UInt16)(*(p_buff) << 8) |                                        \
        (UInt16)(*(p_buff + 1)))

/* to read a 24 bit value starting at the location p_buff */
#define LTE_GET_U24BIT(p_buff)                                        \
    ((UInt32)(*(p_buff) << 16) |                                       \
        (UInt32)(*(p_buff + 1) << 8) |                                 \
        (UInt32)(*(p_buff + 2)))

/* to read a 32 bit value starting at the location p_buff */
#define LTE_GET_U32BIT(p_buff)                                        \
    ((UInt32)(*(p_buff) << 24) |                                       \
        (UInt32)(*(p_buff + 1) << 16) |                                \
        (UInt32)(*(p_buff + 2) << 8) |                                 \
        (UInt32)(*(p_buff + 3)))
/* to read a 40 bit value starting at the location p_buff */
#define LTE_GET_U40BIT(p_buff)                                        \
        (((UInt64)(*(p_buff)) << 32) |                                       \
        (UInt64)(*(p_buff + 1) << 24) |                                \
        (UInt64)(*(p_buff + 2) << 16) |                                 \
        (UInt64)(*(p_buff + 3) << 8) |                                \
        (UInt64)(*(p_buff + 4)))

/* to read a 64 bit value starting at the location p_buff */

#define LTE_GET_U64BIT(p_buff)                                        \
        ((UInt64)(*(p_buff) << 56) |                                       \
                 (UInt64)(*(p_buff + 1) << 48) |                                \
                 (UInt64)(*(p_buff + 2) << 40) |                                 \
                 (UInt64)(*(p_buff + 3) << 32) |                                \
                 (UInt64)(*(p_buff + 4) << 24) |                                \
                 (UInt64)(*(p_buff + 5) << 16) |                                \
                 (UInt64)(*(p_buff + 6) << 8) |                                \
                 (UInt64)(*(p_buff + 7)))

/* macros to set U16bit, U24bit, and U32bit values onto buffer */
/* p_buff must be typecast to a (U8bit *) before using these macros */

/* to write a 16 bit value starting from the location p_buff */
#define LTE_SET_U16BIT(p_buff, val)                                   \
    do {                                                               \
        *(p_buff) = (UInt8)((val) >> 8) ;                              \
        *(p_buff + 1) = (UInt8)(val);                                  \
    } while (0)

/* to write a 24 bit value starting from the location p_buff */
#define LTE_SET_U24BIT(p_buff, val)                                   \
    do {                                                               \
        *(p_buff) = (UInt8)((val) >> 16);                              \
        *(p_buff + 1) = (UInt8)((val) >> 8);                           \
        *(p_buff + 2) = (UInt8)(val);                                  \
    } while (0)

/* to write a 32 bit value starting from the location p_buff */
#define LTE_SET_U32BIT(p_buff, val)                                   \
    do {                                                               \
        *(p_buff) = (UInt8)((val) >> 24);                              \
        *(p_buff + 1) = (UInt8)((val) >> 16);                          \
        *(p_buff + 2) = (UInt8)((val) >> 8);                           \
        *(p_buff + 3) = (UInt8)(val);                                  \
    } while (0)

/* to write a 64 bit value starting from the location p_buff */
#define LTE_SET_U64BIT(p_buff, val)                                   \
    do {                                                               \
        *(p_buff) = (UInt8)((val) >> 56);                              \
        *(p_buff + 1) = (UInt8)((val) >> 48);                          \
        *(p_buff + 2) = (UInt8)((val) >> 40);                           \
        *(p_buff + 3) = (UInt8)((val) >> 32);                           \
        *(p_buff + 4) = (UInt8)((val) >> 24);                           \
        *(p_buff + 5) = (UInt8)((val) >> 16);                           \
        *(p_buff + 6) = (UInt8)((val) >> 8);                           \
        *(p_buff + 7) = (UInt8)(val);                                  \
    } while (0)

/****************************************************************************
 * Exported Variables
 ****************************************************************************/
 
/****************************************************************************
 * Exported Functions
 ****************************************************************************/

#endif  /* INCLUDED_LTE_TYPES_H */
