#ifndef _ASN_COMMON_TYPES_H_
#define _ASN_COMMON_TYPES_H_

typedef struct _OSDynOctStr {
    unsigned int numocts;                     			//DONE
    unsigned char data[256];						//DONE
}_OSDynOctStr;

typedef struct _OSDynOctStr_1 {
    unsigned int numocts;                     			//DONE
    unsigned char data[10240];						//DONE
}_OSDynOctStr_1;


typedef struct _ASN1OpenType{                
    unsigned int numocts;
    unsigned char data[256];
}_ASN1OpenType;


typedef struct
{
    unsigned int     n;
    unsigned char    elem[11];
} _DRB_ToReleaseList;


typedef struct _SCellToReleaseList_r10 {
   unsigned int n;
   unsigned char elem[4];
} _SCellToReleaseList_r10;

typedef struct _PowerCoordinationInfo_r12 {
   unsigned char p_MeNB_r12;
   unsigned char p_SeNB_r12;
   unsigned char powerControlMode_r12;
} _PowerCoordinationInfo_r12;

typedef struct _MeasGapConfig_setup_gapOffset {
   int t;
   union {      
      unsigned char gp0;      
      unsigned char gp1;      
      _ASN1OpenType extElem1;
   } u;
} _MeasGapConfig_setup_gapOffset;

typedef struct _MeasGapConfig_setup {
   _MeasGapConfig_setup_gapOffset gapOffset;
} _MeasGapConfig_setup;

typedef struct _MeasGapConfig {
   int t;
   union {      
      _MeasGapConfig_setup setup;
   } u;
} _MeasGapConfig;

#endif // _ASN_COMMON_TYPES_H__
