/*******************************************************************************
 *                                                                             *
 * ARICENT -                                                                   *
 *                                                                             *
 * Copyright (C) 2018 Aricent Inc. All Rights Reserved.                        *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   FILE NAME: dumgr_rlc_intf.h                                               *
 *                                                                             *
 *   DESCRIPTION: Definitions for Interface between the RLC layer and          *
 *                DU Manager stack entity at DU                                *
 *                                                                             *
 *       DATE         AUTHOR       REFERENCE           REASON                  *
 *   --------------------------------------------------------------------------*
 *   11 June 2018    Eshant       RLC API v0.1      Initial draft              *
 *                                                                             *
 *                                                                             *
 *******************************************************************************/

#ifndef _DUMGR_RLC_INTF_H_
#define _DUMGR_RLC_INTF_H_

/*******************************************************************************
 * Project Includes
 ****************************************************************************/
#include "gnb_defines.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/
/* DUMGR - RLC API IDs */
#define DUMGR_RLC_MESSAGE_API_START        0x0000

#define DUMGR_RLC_CELL_CONFIG_REQ                        (DUMGR_RLC_MESSAGE_API_START + 0)
#define RLC_DUMGR_CELL_CONFIG_RESP                       (DUMGR_RLC_MESSAGE_API_START + 1)
#define DUMGR_RLC_CREATE_UE_ENTITY_REQ                   (DUMGR_RLC_MESSAGE_API_START + 2)
#define RLC_DUMGR_CREATE_UE_ENTITY_RESP                  (DUMGR_RLC_MESSAGE_API_START + 3)
#define DUMGR_RLC_RECONFIG_UE_ENTITY_REQ                 (DUMGR_RLC_MESSAGE_API_START + 4)
#define RLC_DUMGR_RECONFIG_UE_ENTITY_RESP                (DUMGR_RLC_MESSAGE_API_START + 5)
#define DUMGR_RLC_DELETE_UE_ENTITY_REQ                   (DUMGR_RLC_MESSAGE_API_START + 6)
#define RLC_DUMGR_DELETE_UE_ENTITY_RESP                  (DUMGR_RLC_MESSAGE_API_START + 7)
#define DUMGR_RLC_SRB_DL_DATA_IND                        (DUMGR_RLC_MESSAGE_API_START + 8)
#define RLC_DUMGR_SRB_UL_DATA_IND                        (DUMGR_RLC_MESSAGE_API_START + 9)
#define DUMGR_RLC_RE_ESTABLISH_UE_ENTITY_REQ             (DUMGR_RLC_MESSAGE_API_START + 10)
#define RLC_DUMGR_RE_ESTABLISH_UE_ENTITY_RESP            (DUMGR_RLC_MESSAGE_API_START + 11)
#define DUMGR_RLC_RE_ESTABLISH_UE_ENTITY_COMPLETE_IND    (DUMGR_RLC_MESSAGE_API_START + 12)
#define RLC_DUMGR_RE_ESTABLISH_UE_ENTITY_COMPLETE_RESP   (DUMGR_RLC_MESSAGE_API_START + 13)
#define DUMGR_RLC_CELL_DELETE_REQ                        (DUMGR_RLC_MESSAGE_API_START + 14)  
#define RLC_DUMGR_CELL_DELETE_RESP                       (DUMGR_RLC_MESSAGE_API_START + 15)
#define DUMGR_RLC_PURGE_CELL_UES_REQ                     (DUMGR_RLC_MESSAGE_API_START + 16) 
#define RLC_DUMGR_PURGE_CELL_UES_RESP                    (DUMGR_RLC_MESSAGE_API_START + 17) 
#define RLC_DUMGR_UE_MAX_RETX_IND                        (DUMGR_RLC_MESSAGE_API_START + 18) 

#define DUMGR_RLC_MESSAGE_API_END                        (RLC_DUMGR_UE_MAX_RETX_IND)


/* Macros */
#define MAX_DU_MANAGER_UE_INDEX    0xFFFF
#define MAX_UE_PER_CELL            1500
#define RNTI_MAX_VALUE             65535
#define RLC_NO_ACTION              0
#define RLC_FREEZE                 1


/* Enums: Refer 38.331 RLC-Config IE */
/* possible values of retramsmission for polling timer */
typedef enum {
    prms5 = 5,
    prms10 = 10,
    prms15 = 15,
    prms20 = 20,
    prms25 = 25,
    prms30 = 30,
    prms35 = 35,
    prms40 = 40,
    prms45 = 45,
    prms50 = 50,
    prms55 = 55,
    prms60 = 60,
    prms65 = 65,
    prms70 = 70,
    prms75 = 75,
    prms80 = 80,
    prms85 = 85,
    prms90 = 90,
    prms95 = 95,
    prms100 = 100,
    prms105 = 105,
    prms110 = 110,
    prms115 = 115,
    prms120 = 120,
    prms125 = 125,
    prms130 = 130,
    prms135 = 135,
    prms140 = 140,
    prms145 = 145,
    prms150 = 150,
    prms155 = 155,
    prms160 = 160,
    prms165 = 165,
    prms170 = 170,
    prms175 = 175,
    prms180 = 180,
    prms185 = 185,
    prms190 = 190,
    prms195 = 195,
    prms200 = 200,
    prms205 = 205,
    prms210 = 210,
    prms215 = 215,
    prms220 = 220,
    prms225 = 225,
    prms230 = 230,
    prms235 = 235,
    prms240 = 240,
    prms245 = 245,
    prms250 = 250,
    prms300 = 300,
    prms350 = 350,
    prms400 = 400,
    prms450 = 450,
    prms500 = 500,
    prms800 = 800,
    prms1000 = 1000,
    prms2000 = 2000,
    prms4000 = 4000
} t_poll_retransmit;

/* possible values for maximum retransmission threshold for AM PDUs */
typedef enum {
    t1 = 1,
    t2 = 2,
    t3 = 3,
    t4 = 4,
    t6 = 6,
    t8 = 8,
    t16 = 16,
    t32 = 32
} max_retx_threshold; 

typedef enum {
    spms0 = 0,
    spms5 = 5,
    spms10 = 10,
    spms15 = 15,
    spms20 = 20,
    spms25 = 25,
    spms30 = 30,
    spms35 = 35,
    spms40 = 40,
    spms45 = 45,
    spms50 = 50,
    spms55 = 55,
    spms60 = 60,
    spms65 = 65,
    spms70 = 70,
    spms75 = 75,
    spms80 = 80,
    spms85 = 85,
    spms90 = 90,
    spms95 = 95,
    spms100 = 100,
    spms105 = 105,
    spms110 = 110,
    spms115 = 115,
    spms120 = 120,
    spms125 = 125,
    spms130 = 130,
    spms135 = 135,
    spms140 = 140,
    spms145 = 145,
    spms150 = 150,
    spms155 = 155,
    spms160 = 160,
    spms165 = 165,
    spms170 = 170,
    spms175 = 175,
    spms180 = 180,
    spms185 = 185,
    spms190 = 190,
    spms195 = 195,
    spms200 = 200,
    spms205 = 205,
    spms210 = 210,
    spms215 = 215,
    spms220 = 220,
    spms225 = 225,
    spms230 = 230,
    spms235 = 235,
    spms240 = 240,
    spms245 = 245,
    spms250 = 250,
    spms300 = 300,
    spms350 = 350,
    spms400 = 400,
    spms450 = 450,
    spms500 = 500,
    spms800 = 800,
    spms1000 = 1000,
    spms1200 = 1200,
    spms1600 = 1600,
    spms2000 = 2000,
    spms2400 = 2400
} t_sp_status_prohibit; 

/* possible time in milliseconds for timeout for reassembly */
typedef enum {
    rems0 = 0,
    rems5 = 5,
    rems10 = 10,
    rems15 = 15,
    rems20 = 20,
    rems25 = 25,
    rems30 = 30,
    rems35 = 35,
    rems40 = 40,
    rems45 = 45,
    rems50 = 50,
    rems55 = 55,
    rems60 = 60,
    rems65 = 65,
    rems70 = 70,
    rems75 = 75,
    rems80 = 80,
    rems85 = 85,
    rems90 = 90,
    rems95 = 95,
    rems100 = 100,
    rems110 = 110,
    rems120 = 120,
    rems130 = 130,
    rems140 = 140,
    rems150 = 150,
    rems160 = 160,
    rems170 = 170,
    rems180 = 180,
    rems190 = 190,
    rems200 = 200
} t_reassembly;

/* possible size of Poll Bytes */
typedef enum
{   
    pkb1     =  1,
    pkb2     =  2,
    pkb5     =  5,
    pkb8     =  8,
    pkb10    =  10,
    pkb15    =  15,
    pkb25    =  25,
    pkb50    =  50,
    pkb75    =  75,
    pkb100   =  100,
    pkb125   =  125,
    pkb250   =  250,
    pkb375   =  375,
    pkb500   =  500,
    pkb750   =  750,
    pkb1000  =  1000,
    pkb1250  =  1250,
    pkb1500  =  1500,
    pkb2000  =  2000,
    pkb3000  =  3000,
    pkb4000  =  4000,
    pkb4500  =  4500,
    pkb5000  =  5000,
    pkb5500  =  5500,
    pkb6000  =  6000,
    pkb6500  =  6500,
    pkb7000  =  7000,
    pkb7500  =  7500,
    pkb8000  =  8000,
    pkb9000  =  9000,
    pkb10000 =  10000,
    pkb11000 =  11000,
    pkb12000 =  12000,
    pkb13000 =  13000,
    pkb14000 =  14000,
    pkb15000 =  15000,
    pkb16000 =  16000,
    pkb17000 =  17000,
    pkb18000 =  18000,
    pkb20000 =  20000,
    pkb25000 =  25000,
    pkb30000 =  30000,
    pkb40000 =  40000,
    pByteInfinity = 40001
}t_poll_byte_et;

/* possible size of Poll PDU */
typedef enum {
    ppdu4 = 4,
    ppdu8 = 8,
    ppdu16 = 16,
    ppdu32 = 32,
    ppdu64 = 64,
    ppdu128 = 128,
    ppdu256 = 256,
    ppdu512 = 512,
    ppdu1024 = 1024,
    ppdu2048 = 2048,
    ppdu4096 = 4096,
    ppdu6144 = 6144,
    ppdu8192 = 8192,
    ppdu12288 = 12288,
    ppdu16384 = 16384,
    ppdu20480 = 20480,
    ppdu24576 = 24576,
    ppdu28672 = 28672,
    ppdu32768 = 32768,
    ppdu40960 = 40960,
    ppdu49152 = 49152,
    ppdu57344 = 57344,
    ppdu65536 = 65536,
    ppduInfinity = 65537
} t_poll_pdu ;

/*******************************************************************************
 *  API: DUMGR_RLC_CELL_CONFIG_REQ
 ******************************************************************************/
typedef struct _dumgr_rlc_cell_config_req_t
{
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    /* Number of UEs supported in this cell */
    UInt16     num_UEs;
    /*^ M, 0, B, 1, MAX_UE_PER_CELL ^*/
    
    /* AM and UM bearer sum should not be more than MAX_LC */
    /* Number of AM LC's supported per UE in this cell. 
     * This field is used for memory estimation only */
    UInt8      num_am_lc_per_ue;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* Number of UM LC's supported per UE in this cell
     * This field is used for memory estimation only */
    UInt8      num_um_lc_per_ue;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* 18 bit SN support
     * This field is used for memory estimation only */
    UInt8      is_18bit_sn_support;
    /*^ M, 0, H, 0, 1 ^*/

} dumgr_rlc_cell_config_req_t;  /*^ API, DUMGR_RLC_CELL_CONFIG_REQ ^*/

/*******************************************************************************
 *  API: RLC_DUMGR_CELL_CONFIG_RESP
 ******************************************************************************/
typedef struct _rlc_dumgr_cell_config_resp_t
{
#define RLC_DUMGR_CELL_CONFIG_RESP_CAUSE_PRESENT   0x01

    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    /* Response of request i.e. SUCCESS/FAILURE */
    UInt8      response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Cause code in case of Failure */
    UInt16     cause;
    /*^ O, RLC_DUMGR_CELL_CONFIG_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_dumgr_cell_config_resp_t; /*^ API, RLC_DUMGR_CELL_CONFIG_RESP ^*/



/*******************************************************************************
 *    API: DUMGR_RLC_CELL_DELETE_REQ
 *******************************************************************************/
/* No Payload Required */


/*******************************************************************************
 *    API: RLC_DUMGR_CELL_DELETE_RESP
 *******************************************************************************/
typedef struct rlc_dumgr_cell_delete_resp_t
{
#define RLC_DUMGR_CELL_DELETE_RESP_CAUSE_PRESENT   0x01
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    /* Response of request i.e. SUCCESS/FAILURE */
    UInt8      response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Cause code in case of Failure */
    UInt16     cause;
    /*^ O, RLC_DUMGR_CELL_DELETE_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_dumgr_cell_delete_resp_t; /*^ API, RLC_DUMGR_CELL_DELETE_RESP ^*/

/*******************************************************************************
 *    API: DUMGR_RLC_PURGE_CELL_UES_REQ
 *******************************************************************************/

typedef struct _dumgr_rlc_delete_ue_info_t
{
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    ue_index_t          ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

}dumgr_rlc_delete_ue_info_t;

typedef struct _dumgr_rlc_delete_ue_list_t
{
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    UInt16                      num_delete_ue_counter;
    /*^ M, 0, B, 1, MAX_NUM_DU_PURGE_UE_IN_BATCH ^*/

    dumgr_rlc_delete_ue_info_t  delete_ue_info_req[MAX_NUM_DU_PURGE_UE_IN_BATCH];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} dumgr_rlc_delete_ue_list_t;

typedef struct _dumgr_rlc_purge_cell_ues_req_t
{
#define DUMGR_RLC_UE_DELETE_LIST_PRESENT   0x01
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    UInt8                         delete_all_ue;
    /*^ M, 0, H, 0, 1 ^*/

    dumgr_rlc_delete_ue_list_t    delete_ue_list;
    /*^ O, DUMGR_RLC_UE_DELETE_LIST_PRESENT ^*/

} dumgr_rlc_purge_cell_ues_req_t; /*^ API, DUMGR_RLC_PURGE_CELL_UES_REQ ^*/


/*******************************************************************************
 *    API: RLC_DUMGR_PURGE_CELL_UES_RESP
 *******************************************************************************/
typedef struct rlc_dumgr_purge_cell_ues_resp_t
{
#define RLC_DUMGR_PURGE_CELL_UES_CAUSE_PRESENT   0x01
 /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    /* Response of request i.e. SUCCESS/FAILURE */
    UInt8      response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Cause code in case of Failure */
    UInt16     cause;
    /*^ O, RLC_DUMGR_PURGE_CELL_UES_CAUSE_PRESENT, N, 0, 0 ^*/

}rlc_dumgr_purge_cell_ues_resp_t; /*^ API, RLC_DUMGR_PURGE_CELL_UES_RESP ^*/



/*******************************************************************************
 *  API: DUMGR_RLC_CREATE_UE_ENTITY_REQ
 ******************************************************************************/

typedef struct _create_entity_tx_um_config_t
{
#define CREATE_ENTITY_TX_UM_CONFIG_QCI_INFO_PRESENT              0x0001
#define CREATE_ENTITY_TX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT      0x0002

    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* SN Length. Here checking low and high value of SN. 
     * Exact value shall be checked in code. */
    UInt8          sn_field_length;
    /*^ M, 0, B, 6, 12 ^*/

    UInt16          qci;
    /*^ O, CREATE_ENTITY_TX_UM_CONFIG_QCI_INFO_PRESENT, H, 0, MAX_QCI ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_tx;
    /*^ O, CREATE_ENTITY_TX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} create_entity_tx_um_config_t;


typedef struct _create_entity_rx_um_config_t
{
#define CREATE_ENTITY_RX_UM_CONFIG_QCI_INFO_PRESENT              0x0001
#define CREATE_ENTITY_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT      0x0002

    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* Here checking low and high value of SN. Exact value shall 
     * be checked in code. */
    UInt8          sn_field_length;
    /*^ M, 0, B, 6, 12 ^*/
    
    /* (t_reassembly) */
    UInt8          tReassembly;
    /*^ M, 0, H, 0, 200 ^*/

    UInt16          qci;
    /*^ O, CREATE_ENTITY_RX_UM_CONFIG_QCI_INFO_PRESENT, H, 0, MAX_QCI ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_rx;
    /*^ O, CREATE_ENTITY_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} create_entity_rx_um_config_t;


typedef struct _create_entity_tx_rx_um_config_t
{
#define CREATE_ENTITY_TX_RX_UM_CONFIG_QCI_INFO_PRESENT              0x0001
#define CREATE_ENTITY_TX_RX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT      0x0002
#define CREATE_ENTITY_TX_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT      0x0004

    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* Here checking low and high value of SN. Exact value shall 
     * be checked in code. */
    UInt8          sn_field_length_tx;
    /*^ M, 0, B, 6, 12 ^*/

    /* Here checking low and high value of SN. Exact value shall 
     * be checked in code. */
    UInt8          sn_field_length_rx;
    /*^ M, 0, B, 6, 12 ^*/
    
    /* (t_reassembly) */
    UInt8          tReassembly;
    /*^ M, 0, H, 0, 200 ^*/

    UInt16          qci;
    /*^ O, CREATE_ENTITY_TX_RX_UM_CONFIG_QCI_INFO_PRESENT, H, 0, MAX_QCI ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_tx;
    /*^ O, CREATE_ENTITY_TX_RX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_rx;
    /*^ O, CREATE_ENTITY_TX_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} create_entity_tx_rx_um_config_t;


typedef struct _create_entity_tx_rx_am_config_t
{
#define CREATE_ENTITY_TX_RX_AM_CONFIG_QCI_INFO_PRESENT              0x0001
#define CREATE_ENTITY_TX_RX_AM_CONFIG_TX_BIT_RATE_INFO_PRESENT      0x0002
#define CREATE_ENTITY_TX_RX_AM_CONFIG_RX_BIT_RATE_INFO_PRESENT      0x0004

    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* Here checking low and high value of SN. Exact value shall be 
     * checked in code. */
    UInt8          sn_field_length;
    /*^ M, 0, B, 12, 18 ^*/
    
    /* (t_reassembly) */
    UInt8          tReassembly;
    /*^ M, 0, H, 0, 200 ^*/
    
    /* (t_poll_retransmit) */
    UInt16         tPollRetransmission;
    /*^ M, 0, B, 5, 4000 ^*/

    /* (t_poll_byte_et) */
    UInt16         poll_byte;
    /*^ M, 0, B, 1, 40001 ^*/

    /* (max_retx_threshold) */
    UInt16         max_re_tx_thrsh_ld;
    /*^ M, 0, B, 1, 32 ^*/
    
    /* (t_sp_status_prohibit) */
    UInt16         t_status_prohibit;
    /*^ M, 0, H, 0, 2400 ^*/

    /* (t_poll_pdu) */
    UInt32         poll_pdu;
    /*^ M, 0, B, 4, 65537 ^*/

    UInt16          qci;
    /*^ O, CREATE_ENTITY_TX_RX_AM_CONFIG_QCI_INFO_PRESENT, H, 0, MAX_QCI ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_tx;
    /*^ O, CREATE_ENTITY_TX_RX_AM_CONFIG_TX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_rx;
    /*^ O, CREATE_ENTITY_TX_RX_AM_CONFIG_RX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} create_entity_tx_rx_am_config_t;


typedef struct _rlc_ue_bit_rate_info_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    /* DL Aggregate Bitrate (AMBR) for non-GBR bearer */
    UInt64           bit_rate_tx;
    /*^ M, 0, N, 0, 0 ^*/

    /* UL Aggregate Bitrate (AMBR) for non-GBR bearer */
    UInt64           bit_rate_rx;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_ue_bit_rate_info_t;


typedef struct _rlc_create_entity_list_elem_t
{
#define CREATE_ENTITY_TX_UM_CONFIG_PRESENT         0x0001
#define CREATE_ENTITY_RX_UM_CONFIG_PRESENT         0x0002
#define CREATE_ENTITY_TX_RX_UM_CONFIG_PRESENT      0x0004
#define CREATE_ENTITY_TX_RX_AM_CONFIG_PRESENT      0x0008

    /* Bitmask indicating the presence of optional fields.
     * NOTE: For a particular entity, only one of the below
     * four configurations shall be present. */
    bitmask_t                           bitmask;
    /*^ BITMASK ^*/

    UInt8                               lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    create_entity_tx_um_config_t        tx_um_config;
    /*^ O, CREATE_ENTITY_TX_UM_CONFIG_PRESENT ^*/

    create_entity_rx_um_config_t        rx_um_config;
    /*^ O, CREATE_ENTITY_RX_UM_CONFIG_PRESENT ^*/

    create_entity_tx_rx_um_config_t     tx_rx_um_config;
    /*^ O, CREATE_ENTITY_TX_RX_UM_CONFIG_PRESENT ^*/

    create_entity_tx_rx_am_config_t     tx_rx_am_config;
    /*^ O, CREATE_ENTITY_TX_RX_AM_CONFIG_PRESENT ^*/

} rlc_create_entity_list_elem_t;


typedef struct _rlc_create_entity_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    UInt8          count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    rlc_create_entity_list_elem_t 
                   create_entity_elem[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_create_entity_list_t;


typedef struct _dumgr_rlc_create_ue_entity_req_t
{
#define CREATE_UE_ENTITY_REQ_CREATE_ENTITY_LIST_PRESENT   0x0001
#define CREATE_UE_ENTITY_REQ_UE_BIT_RATE_INFO_PRESENT     0x0002

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask;
    /*^ BITMASK ^*/

    UInt16                              ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    UInt16                              rnti;
    /*^ M, 0, B, 1, RNTI_MAX_VALUE ^*/

    rlc_create_entity_list_t            create_entity_list;
    /*^ O, CREATE_UE_ENTITY_REQ_CREATE_ENTITY_LIST_PRESENT ^*/

    /* AMBR bitrate for non-GBR bearers */
    rlc_ue_bit_rate_info_t              rlc_ue_bit_rate_info;
    /*^ O, CREATE_UE_ENTITY_REQ_UE_BIT_RATE_INFO_PRESENT ^*/

} dumgr_rlc_create_ue_entity_req_t; /*^ API, DUMGR_RLC_CREATE_UE_ENTITY_REQ ^*/


/******************************************************************************
 *   RLC_DUMGR_CREATE_UE_ENTITY_RESP
 ******************************************************************************/
typedef struct _rlc_create_entity_fail_list_elem_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* dumgr_rlc_error_code_et */
    UInt16           cause;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_create_entity_fail_list_elem_t;


typedef struct _rlc_create_entity_fail_list_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            count;
    /*^ M, 0, B, 1, MAX_LC ^*/

    rlc_create_entity_fail_list_elem_t   
                     create_entity_fail_elem[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_create_entity_fail_list_t;


typedef struct _rlc_dumgr_create_ue_entity_resp_t
{
#define CREATE_UE_ENTITY_RESP_CAUSE_PRESENT                0x01
#define CREATE_UE_ENTITY_RESP_ENTITY_FAILED_LIST_PRESENT   0x02

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t      ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Response for request i.e. SUCCESS/PARTIAL_SUCCESS/FAILURE */
    UInt8           response;
    /*^ M, 0, H, 0, 2 ^*/

    /* Cause for failure */
    UInt16          cause;
    /*^ O, CREATE_UE_ENTITY_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

    /* List of LCs failed to be created. */
    rlc_create_entity_fail_list_t      
                    create_entity_fail_list;
    /*^ O, CREATE_UE_ENTITY_RESP_ENTITY_FAILED_LIST_PRESENT  ^*/

} rlc_dumgr_create_ue_entity_resp_t; /*^ API, RLC_DUMGR_CREATE_UE_ENTITY_RESP ^*/


/*******************************************************************************
 *   API: DUMGR_RLC_RECONFIG_UE_ENTITY_REQ
 ******************************************************************************/

typedef struct _reconfig_entity_tx_um_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_tx;
    /*^ M, 0, H, 0, 4000000000000 ^*/

} reconfig_entity_tx_um_config_t;


typedef struct _reconfig_entity_rx_um_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64       bit_rate_rx;
    /*^ M, 0, H, 0, 4000000000000 ^*/

} reconfig_entity_rx_um_config_t;


typedef struct _reconfig_entity_tx_rx_um_config_t
{
#define RECONFIG_ENTITY_TX_RX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT      0x0001
#define RECONFIG_ENTITY_TX_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT      0x0002

    /* Bitmask indicating the presence of optional fields */
    bitmask_t      bitmask;
    /*^ BITMASK ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_tx;
    /*^ O, RECONFIG_ENTITY_TX_RX_UM_CONFIG_TX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64         bit_rate_rx;
    /*^ O, RECONFIG_ENTITY_TX_RX_UM_CONFIG_RX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} reconfig_entity_tx_rx_um_config_t;


typedef struct _reconfig_entity_tx_rx_am_config_t
{
#define RECONFIG_ENTITY_TX_RX_AM_CONFIG_TX_BIT_RATE_INFO_PRESENT       0x0001
#define RECONFIG_ENTITY_TX_RX_AM_CONFIG_RX_BIT_RATE_INFO_PRESENT       0x0002

    /* Bitmask indicating the presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* DL Guaranteed Bitrate for GBR bearer */
    UInt64       bit_rate_tx;
    /*^ O, RECONFIG_ENTITY_TX_RX_AM_CONFIG_TX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

    /* UL Guaranteed Bitrate for GBR bearer */
    UInt64       bit_rate_rx;
    /*^ O, RECONFIG_ENTITY_TX_RX_AM_CONFIG_RX_BIT_RATE_INFO_PRESENT, H, 0, 4000000000000 ^*/

} reconfig_entity_tx_rx_am_config_t;


typedef struct _rlc_reconfig_entity_list_elem_t
{
#define RECONFIG_ENTITY_TX_RX_AM_CONFIG_PRESENT   0x01
#define RECONFIG_ENTITY_TX_RX_UM_CONFIG_PRESENT   0x02
#define RECONFIG_ENTITY_RX_UM_CONFIG_PRESENT      0x04
#define RECONFIG_ENTITY_TX_UM_CONFIG_PRESENT      0x08

    /* Bitmask indicating presence of optional fields.
     * NOTE: For a particular entity, only one of the below
     * four configurations shall be present. */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    UInt8        lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    reconfig_entity_tx_rx_am_config_t
                 reconfig_tx_rx_am_config;
    /*^ O, RECONFIG_ENTITY_TX_RX_AM_CONFIG_PRESENT, N, 0, 0 ^*/

    reconfig_entity_tx_rx_um_config_t
                 reconfig_tx_rx_um_config;
    /*^ O, RECONFIG_ENTITY_TX_RX_UM_CONFIG_PRESENT, N, 0, 0 ^*/

    reconfig_entity_rx_um_config_t
                 reconfig_rx_um_config;
    /*^ O, RECONFIG_ENTITY_RX_UM_CONFIG_PRESENT, N, 0, 0 ^*/

    reconfig_entity_tx_um_config_t
                 reconfig_tx_um_config;
    /*^ O, RECONFIG_ENTITY_TX_UM_CONFIG_PRESENT, N, 0, 0 ^*/

} rlc_reconfig_entity_list_elem_t;


typedef struct _rlc_reconfig_entity_list_t
{
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    UInt8        count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    rlc_reconfig_entity_list_elem_t 
                 entity_list_elem[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_reconfig_entity_list_t;


typedef struct _rlc_delete_entity_list_t
{
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    UInt8        count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    UInt8        lc_id[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_delete_entity_list_t;


typedef struct _dumgr_rlc_reconfig_ue_entity_req_t
{
#define RECONFIG_UE_ENTITY_REQ_CREATE_ENTITY_LIST_PRESENT         0x0001
#define RECONFIG_UE_ENTITY_REQ_DELETE_ENTITY_LIST_PRESENT         0x0002
#define RECONFIG_UE_ENTITY_REQ_RECONFIG_ENTITY_LIST_PRESENT       0x0004
#define RECONFIG_UE_ENTITY_REQ_UE_BIT_RATE_INFO_PRESENT           0x0008

    /* Bitmask indicating presence of optional fields */
    bitmask_t                           bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t                          ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    rlc_create_entity_list_t            create_entity_list;
    /*^ O, RECONFIG_UE_ENTITY_REQ_CREATE_ENTITY_LIST_PRESENT ^*/

    rlc_delete_entity_list_t            delete_entity_list;
    /*^ O, RECONFIG_UE_ENTITY_REQ_DELETE_ENTITY_LIST_PRESENT ^*/

    rlc_reconfig_entity_list_t          reconfig_entity_list;
    /*^ O, RECONFIG_UE_ENTITY_REQ_RECONFIG_ENTITY_LIST_PRESENT ^*/

    /* AMBR bitrate for non-GBR bearers */
    rlc_ue_bit_rate_info_t              rlc_ue_bit_rate_info;
    /*^ O, RECONFIG_UE_ENTITY_REQ_UE_BIT_RATE_INFO_PRESENT ^*/

} dumgr_rlc_reconfig_ue_entity_req_t; /*^ API, DUMGR_RLC_RECONFIG_UE_ENTITY_REQ ^*/


/*******************************************************************************
 *   API: RLC_DUMGR_RECONFIG_UE_ENTITY_RESP 
 ******************************************************************************/
typedef struct _rlc_reconfig_entity_fail_list_elem_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* dumgr_rlc_error_code_et */
    UInt16           cause;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_reconfig_entity_fail_list_elem_t;


typedef struct _rlc_reconfig_entity_fail_list_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            count;
    /*^ M, 0, B, 1, MAX_LC ^*/

    rlc_reconfig_entity_fail_list_elem_t   
                     reconfig_entity_fail_elem[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_reconfig_entity_fail_list_t;


typedef struct _rlc_delete_entity_fail_list_elem_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* dumgr_rlc_error_code_et */
    UInt16           cause;
    /*^ M, 0, N, 0, 0 ^*/

} rlc_delete_entity_fail_list_elem_t;


typedef struct _rlc_delete_entity_fail_list_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            count;
    /*^ M, 0, B, 1, MAX_LC ^*/

    rlc_delete_entity_fail_list_elem_t   
                     delete_entity_fail_elem[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} rlc_delete_entity_fail_list_t;


typedef struct _rlc_dumgr_reconfig_ue_entity_resp_t
{
#define RECONFIG_UE_ENTITY_RESP_CAUSE_PRESENT                        0x01
#define RECONFIG_UE_ENTITY_RESP_CREATE_ENTITY_FAILED_LIST_PRESENT    0x02
#define RECONFIG_UE_ENTITY_RESP_RECONFIG_ENTITY_FAILED_LIST_PRESENT  0x04
#define RECONFIG_UE_ENTITY_RESP_DELETE_ENTITY_FAILED_LIST_PRESENT    0x08

    /* Bitmask indicating presence of optional fields */
    bitmask_t                          bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t                         ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Response code i.e. SUCCESS/PARTIAL_SUCCESS/FAILURE */
    UInt8                              response;
    /*^ M, 0, H, 0, 2 ^*/

    /* Cause indicating reason for failure */
    UInt16                             cause;
    /* O, RECONFIG_UE_ENTITY_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

    /* List of LCs failed to be created. */
    rlc_create_entity_fail_list_t      create_entity_fail_list;
    /*^ O, RECONFIG_UE_ENTITY_RESP_CREATE_ENTITY_FAILED_LIST_PRESENT  ^*/

    /* List of LCs failed to be reconfigured. */
    rlc_reconfig_entity_fail_list_t    reconfig_entity_fail_list;
    /*^ O, RECONFIG_UE_ENTITY_RESP_RECONFIG_ENTITY_FAILED_LIST_PRESENT  ^*/

    /* List of LCs failed to be deleted. */
    rlc_delete_entity_fail_list_t      delete_entity_fail_list;
    /*^ O, RECONFIG_UE_ENTITY_RESP_DELETE_ENTITY_FAILED_LIST_PRESENT  ^*/

} rlc_dumgr_reconfig_ue_entity_resp_t;  /*^ API, RLC_DUMGR_RECONFIG_UE_ENTITY_RESP ^*/


/*******************************************************************************
 *   API: DUMGR_RLC_DELETE_UE_ENTITY_REQ
 ******************************************************************************/
typedef struct _dumgr_rlc_delete_ue_entity_req_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t   ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

} dumgr_rlc_delete_ue_entity_req_t; /*^ API, DUMGR_RLC_DELETE_UE_ENTITY_REQ ^*/


/*******************************************************************************
 *   API: RLC_DUMGR_DELETE_UE_ENTITY_RESP 
 ******************************************************************************/
typedef struct _rlc_dumgr_delete_ue_entity_resp_t
{
#define DELETE_UE_ENTITY_RESP_CAUSE_PRESENT    0x01

    /* Bitmask indicating presence of optional fields */
    bitmask_t     bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t    ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Response code i.e. SUCCESS/FAILURE */
    UInt8         response;
    /*^ M, 0, H, 0, 1 ^*/

    /* Cause indicating reason for failure */
    UInt16        cause;
    /* O, DELETE_UE_ENTITY_RESP_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_dumgr_delete_ue_entity_resp_t;  /*^ API, RLC_DUMGR_DELETE_UE_ENTITY_RESP ^*/


/*******************************************************************************
 *   API: DUMGR_RLC_SRB_DL_DATA_IND
 ******************************************************************************/
typedef struct _dumgr_rlc_srb_dl_data_ind_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t   ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Logical channel identifier */
    UInt8        lc_id;
    /*^ M, 0, B, 1, 3 ^*/

    /* Data buffer (Max size can be of 9k bytes) */
    UInt8        dataBuffer[0];
    /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/

} dumgr_rlc_srb_dl_data_ind_t;  /*^ API, DUMGR_RLC_SRB_DL_DATA_IND ^*/


/*******************************************************************************
 *   API: RLC_DUMGR_SRB_UL_DATA_IND 
 ******************************************************************************/
typedef struct _rlc_dumgr_srb_ul_data_ind_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /* Unique UE identifier */
    ue_index_t   ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Logical channel identifier */
    UInt8        lc_id;
    /*^ M, 0, B, 1, 3 ^*/

    /* Data buffer (Max size can be of 9k bytes) */
    UInt8        dataBuffer[0];
    /*^ M, 0, OCTET_STRING, TILL_THE_END ^*/

} rlc_dumgr_srb_ul_data_ind_t;  /*^ API, RLC_DUMGR_SRB_UL_DATA_IND ^*/

typedef struct _dumgr_rlc_entity_lc_id_error_t
{
    /* Logical channel identifier */
    UInt8                               lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* dumgr_rlc_error_code_et */
    UInt16                              cause;
    /*^ M, 0, N, 0, 0 ^*/

} dumgr_rlc_entity_lc_id_error_t;

typedef struct _rlc_re_establish_error_entity_list_t
{
    /* Bitmask indicating presence of optional fields */
    bitmask_t        bitmask;
    /*^ BITMASK ^*/

    UInt8            count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    dumgr_rlc_entity_lc_id_error_t error_entities[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
} rlc_re_establish_error_entity_list_t;

typedef struct _dumgr_rlc_entity_lcid_t
{
#define                     DUMGR_RLC_LC_STATE_PRESENT    0x01
    /* Bitmask indicating presence of optional fields */
    bitmask_t                          bitmask;
    /*^ BITMASK ^*/

    /* Logical channel identifier */
    UInt8                               lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/
    
    /* Re-establish state RLC_NO_ACTION=0 or RLC_FREEZE=1 */
    UInt8                                state;
    /* O, DELETE_UE_ENTITY_RESP_CAUSE_PRESENT, B, RLC_NO_ACTION, RLC_FREEZE ^*/

} dumgr_rlc_entity_lcid_t;

/******************************************************************************
*   RLC_RE_ESTABLISH_UE_ENTITY_REQ
******************************************************************************/
typedef struct _dumgr_rlc_re_establish_ue_entity_req_t
{

    UInt16                              ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Logical Id count*/
    UInt8                               count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    dumgr_rlc_entity_lcid_t             entity_lcids[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} dumgr_rlc_re_establish_ue_entity_req_t; /*^ API, DUMGR_RLC_RE_ESTABLISH_UE_ENTITY_REQ ^*/


/******************************************************************************
*   RLC_RE_ESTABLISH_UE_ENTITY_CNF
******************************************************************************/
typedef struct _dumgr_rlc_re_establish_ue_entity_resp_t
{
    #define RLC_DUMGR_RE_ESTABLISH_RESP_ERROR_ENTITIES_PRESENT   0x01
 
    bitmask_t                           bitmask;
    /*^ BITMASK ^*/
    UInt16                              ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Response code i.e. SUCCESS/FAILURE/PARTIAL_FAILURE */
    UInt8                              response;
    /*^ M, 0, H, 0, 2 ^*/

    /* List of LCs failed to be created. */
    rlc_re_establish_error_entity_list_t
                    reestablish_error_entity_list;
    /*^ O, RLC_DUMGR_RE_ESTABLISH_RESP_ERROR_ENTITIES_PRESENT ^*/
} dumgr_rlc_re_establish_ue_entity_resp_t; /*^ API, RLC_DUMGR_RE_ESTABLISH_UE_ENTITY_RESP ^*/

/******************************************************************************
*   DUMGR_RLC_RE_ESTABLISH_UE_ENTITY_COMPLETE_IND
******************************************************************************/
typedef struct _dumgr_rlc_re_establish_ue_entity_complete_ind_t
{

    UInt16                              ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Logical Id count*/
    UInt8                               count;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    dumgr_rlc_entity_lcid_t             entity_lcids[MAX_LC];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} dumgr_rlc_re_establish_ue_entity_complete_ind_t; /*^ API, DUMGR_RLC_RE_ESTABLISH_UE_ENTITY_COMPLETE_IND ^*/

/******************************************************************************
*   RLC_DUMGR_RE_ESTABLISH_UE_ENTITY_COMPLETE_RESP
******************************************************************************/
typedef struct _rlc_dumgr_re_establish_ue_entity_complete_resp_t
{
#define RLC_DUMGR_RE_ESTABLISH_COMPLETE_CAUSE_PRESENT   0x01
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    UInt16     ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Response of request i.e. SUCCESS/FAILURE */
    UInt8      response;
    /*^ M, 0, H, 0, 1 ^*/
    
    /* dumgr_rlc_error_code_et */
    UInt16     cause;
    /*^ M, RLC_DUMGR_RE_ESTABLISH_COMPLETE_CAUSE_PRESENT, N, 0, 0 ^*/

} rlc_dumgr_re_establish_ue_entity_complete_resp_t; /*^ API, RLC_DUMGR_RE_ESTABLISH_UE_ENTITY_COMPLETE_RESP ^*/

/******************************************************************************
 * *   RLC_DUMGR_UE_MAX_RETX_IND
 * ******************************************************************************/
typedef struct _rlc_dumgr_ue_max_retx_ind_t
{
    /* Bitmask for specifying presence of optional fields */
    bitmask_t  bitmask;
    /*^ BITMASK ^*/

    UInt16     ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Logical Id count*/
    UInt8      lc_id;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

} rlc_dumgr_ue_max_retx_ind_t; /*^ API, RLC_DUMGR_UE_MAX_RETX_IND ^*/

#endif  /* _DUMGR_RLC_INTF_H_ */
