/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2014 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file duoam_mac_il_parser.h contains the prototypes 
 *                     of DUOAM-MAC interface message parsing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _DUOAM_MAC_IL_PARSER_H_
#define _DUOAM_MAC_IL_PARSER_H_

#include "gnb_defines.h"
#include "duoam_mac_intf.h"

gnb_return_t
gnb_il_parse_duoam_mac_provisioning_req
(
    duoam_mac_provisioning_req_t *p_duoam_mac_provisioning_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_provisioning_resp
(
    mac_duoam_provisioning_resp_t *p_mac_duoam_provisioning_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_cleanup_resp
(
    mac_duoam_cleanup_resp_t *p_mac_duoam_cleanup_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_set_log_level_ind
(
    duoam_mac_set_log_level_ind_t *p_duoam_mac_set_log_level_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_get_log_level_resp
(
    mac_duoam_get_log_level_resp_t *p_mac_duoam_get_log_level_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_enable_log_category_ind
(
    duoam_mac_enable_log_category_ind_t *p_duoam_mac_enable_log_category_ind,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_disable_log_category_req
(
    duoam_mac_disable_log_category_req_t *p_duoam_mac_disable_log_category_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_get_log_category_resp
(
    mac_duoam_get_log_category_resp_t *p_mac_duoam_get_log_category_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_get_debug_info_req
(
    duoam_mac_get_debug_info_req_t *p_duoam_mac_get_debug_info_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_get_debug_info_resp
(
    mac_duoam_get_debug_info_resp_t *p_mac_duoam_get_debug_info_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_scheduler_params_req
(
    duoam_mac_scheduler_params_req_t *p_duoam_mac_scheduler_params_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_scheduler_params_resp
(
    mac_duoam_scheduler_params_resp_t *p_mac_duoam_scheduler_params_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_duoam_mac_precoding_params_req
(
    duoam_mac_precoding_params_req_t *p_duoam_mac_precoding_params_req,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

gnb_return_t
gnb_il_parse_mac_duoam_precoding_params_resp
(
    mac_duoam_precoding_params_resp_t *p_mac_duoam_precoding_params_resp,
    UInt8  *p_src,
    SInt32 length_left,
    SInt32 *p_length_read
);

#endif /* _DUOAM_MAC_IL_PARSER_H_ */
