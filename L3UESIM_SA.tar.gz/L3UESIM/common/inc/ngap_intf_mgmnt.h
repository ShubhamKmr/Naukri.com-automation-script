/*******************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 *******************************************************************************
 *
 *  $Id: ngap_intf_mgmnt.h
 *
 *******************************************************************************
 *
 *  File Description : 
 *
 ******************************************************************************/

#ifndef _NGAP_INTF_MGMNT_H_
#define _NGAP_INTF_MGMNT_H_

/*******************************************************************************
 * Project Includes
 ******************************************************************************/
#include "gnb_defines.h"
#include "rrc_ngap_cu_common_def.h"
#include "rrc_ngap_common_def.h"
#include "ngap_types.h"

#define NGAP_MAX_MNC_OCTET_SIZE		                            3
#define NGAP_MIN_MNC_OCTET_SIZE 	                            2
#define NGAP_MCC_OCTET_SIZE		                                3
#define NGAP_GNB_ID_MAX_NUMBITS                                 32
#define NGAP_AMF_REGION_ID_NUMBITS                              8 
#define NGAP_AMF_SET_ID_NUMBITS                                 10 
#define NGAP_AMF_POINTER_NUMBITS                                6 
#define NGAP_EUTRA_CELL_IDENTITY_NUMBITS	                    28  /* To Support 28 bits */
#define NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE	                    4   /* To Support 28 bits */
#define NGAP_TIME_STAMP_OCTET_SIZE		                        4   /* To Support 4 OCTET STRING */
#define NGAP_NR_CELL_IDENTITY_NUMBITS                           36  /* To Support 36 bits */
#define NGAP_PORT_NUMBER_OCTET_SIZE		                        2   /* To Support 2 bits */
#define NGAP_CONFIGURED_NSSAI_OCTET_SIZE                        128 /*To Support 128 bytes*/
#define NGAP_REJECTED_NSSAI_IN_PLMN_OCTET_SIZE                  32
#define NGAP_REJECTED_NSSAI_IN_TA_OCTET_SIZE                    32

//#ifndef IPv6_USE
#define NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS                    160 /* To support 1-160  */
#define NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE                 20  /* To Support bits 1-160 */

#define NGAP_TRANSPORT_LAYER_ADDRESS_IPV6_NUMBITS               128 /* To support 1-128  */
#define NGAP_TRANSPORT_LAYER_ADDRESS_IPV6_OCTET_SIZE            16  /* To Support bits 1-16 */

#define NGAP_TRANSPORT_LAYER_ADDRESS_IPV4_NUMBITS               32 /* To support 1-32  */
#define NGAP_TRANSPORT_LAYER_ADDRESS_IPV4_OCTET_SIZE            4  /* To Support bits 1-4 */
//#else
//#define NGAP_TRANSPORT_LAYER_ADDRESS_NUMBITS                    32 /* To support 1-160  */
//#define NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE                 4  /* To Support bits 1-160 */
//#endif

#define NGAP_RAT_RESTRICTION_INFORMATION_SET_ID_OCTET_SIZE      1   /* To Support 8 bits */
#define NGAP_UE_IDENTITY_INDEX_VALUE_OCTET_SIZE                 2   /* To Support 10 bits */
#define NGAP_PERIODIC_REGISTRATION_UPDATE_TIMER_OCTET_SIZE      1   /* To Support 8 bits */
#define NGAP_NR_ENCRYPTION_ALGORITHM_NUMBITS                    16  /* To support 16 bits */
#define NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS          16  /* To support 16 bits */
#define NGAP_EUTRA_ENCRYPTION_ALGORITHM_NUMBITS                 16  /* To support 16 bits */
#define NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_NUMBITS       16  /* To Support 16 bits */
#define NGAP_SECURITY_KEY_NUMBITS                               256 /* To Support 256 bits */
#define NGAP_NG_RAN_TRACE_ID_OCTET_SIZE                         8   /* To Support 8 bits */ //HandOver changes
#define NGAP_INTERFACE_TO_TRACE_OCTET_SIZE                      1   /* To Support 8 bits */
#define NGAP_INTERFACE_TO_TRACE_NUMBITS                         8   /* To Support 8 bits */
#define NGAP_MASKED_IMEISV_OCTET_SIZE                           8   /* To Support 64 bits */
#define NGAP_MASKED_IMEISV_NUMBITS                              64  /* To support 64 bits*/
#define NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE                 16
#define NGAP_MAX_NO_OF_TNL_ASSOCIATIONS                         32
#define NGAP_MAX_NO_OF_TAI_FOR_INACTIVE                         16  //HandOver changes
#define NGAP_MAX_NO_OF_FORB_TACS				4096 /*Handover bug fixes*/
#define NGAP_MAX_NO_OF_ALLOWED_AREAS	                    	16/*Handover bug fixes*/
/*******************************************************************************
 * Exported Includes
 ******************************************************************************/


/*******************************************************************************
 * IE Defination
 ******************************************************************************/


typedef struct
{
#define NGAP_AMF_PAGING_TARGET_CHOICE_RAN_NODE	0x01
#define NGAP_AMF_PAGING_TARGET_CHOICE_RAN_TAI	0x02

    /* Choice Type for AMF Paging Target */
    UInt8	choice_type;

    union
    {
    
    	/* Global RAN Node Id */
	    ngap_global_ran_node_id_t   global_ran_node_id;
    
	    /* TAI */
	    ngap_tai_t                  tai;
    
    };

} ngap_recommended_ran_node_item_t;

typedef struct
{
#define NGAP_MAX_NO_OF_RECOMMENDED_RAN_NODES     16

    UInt8                               count;

    /* Recommended RAN Node List */
    ngap_recommended_ran_node_item_t    recommended_ran_node_item[NGAP_MAX_NO_OF_RECOMMENDED_RAN_NODES];

} ngap_recommended_ran_nodes_for_paging_t;

typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;

    /* E-UTRA Cell Identity */
    UInt8                   eutra_cell_identity[NGAP_EUTRA_CELL_IDENTITY_OCTET_SIZE];

} ngap_eutra_cgi_t;

typedef struct
{
#define NGAP_NR_CGI     0x01
#define NGAP_EUTRA_CGI  0x02

    UInt8               choice_type;
    union
    {
        /* NR CGI */
        ngap_nr_cgi_t       nr_cgi;

        /* E-UTRA CGI */
        ngap_eutra_cgi_t    eutra_cgi;
    };

} ngap_ng_ran_cgi_t;

typedef struct
{

    /* NG-RAN CGI */
    ngap_ng_ran_cgi_t   ng_ran_cgi;

    /* Time Stayed in Cell */
    UInt16              time_stayed_in_cell;

} ngap_recommended_cell_item_t;

typedef struct
{
#define NGAP_MAX_NO_OF_RECOMMENDED_CELLS     16
    
    UInt8                           count;
    /* Recommended Cell List */
    ngap_recommended_cell_item_t    recommended_cell_item[NGAP_MAX_NO_OF_RECOMMENDED_CELLS];

} ngap_recommended_cells_for_paging_t;

typedef struct
{

    /* Recommended Cells for Paging */
    ngap_recommended_cells_for_paging_t     recommended_cells_for_paging;

    /* Recommended RAN Nodes for Paging */
    ngap_recommended_ran_nodes_for_paging_t recommended_ran_nodes_for_paging;

} ngap_info_on_recommended_cells_and_ran_nodes_for_paging_t;

typedef struct
{

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t   amf_ue_ngap_id_t;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t   ran_ue_ngap_id_t;
    
} ngap_ue_ngap_id_pair_t;       

typedef struct
{

#define UE_RADIO_CAPABILITY_FOR_PAGING_OF_NR_PRESENT	0x01
#define UE_RADIO_CAPABILITY_FOR_PAGING_OF_EUTRA_PRESENT 0x02

    UInt16	bitmask;

	/* UE Radio Capability for Paging of NR */
	ngap_dynamic_string_t	ue_radio_capability_for_paging_of_nr;

	/* UE Radio Capability for Paging of E-UTRA */
	ngap_dynamic_string_t	ue_radio_capability_for_paging_of_eutra;

} ngap_ue_radio_capability_for_paging_t;

typedef enum
{

    SUBSEQUENT_STATE_TRANSITION_REPORT,
    SINGLE_RRC_CONNECTED_STATE_REPORT,
    CANCEL_REPORT

} ngap_rrc_inactive_transition_report_request_et;

typedef enum
{

    EMERGENCY_FALLBACK_REQUESTED

} ngap_emergency_fallback_request_indicator_et;

typedef enum
{

    TARGET_5GC,
    TARGET_EPC

} ngap_emergency_service_target_cn_et;

typedef struct
{

    /* Emergency Fallback Request Indicator */
    ngap_emergency_fallback_request_indicator_et    emergency_fallback_request_indicator_event_id;

    /* Emergency Service Target CN */
    ngap_emergency_service_target_cn_et             emergency_service_target_cn_event_id;

} ngap_emergency_fallback_indicator_t;

typedef struct
{

    UInt8   masked_imeisv[NGAP_MASKED_IMEISV_OCTET_SIZE];

} ngap_masked_imeisv_t;

/* UE Radio Capability */
typedef struct
{

    ngap_dynamic_string_t   ue_radio_capability;

} ngap_ue_radio_capability_t;

/*UE Radio Capability Info Indication */
typedef struct
{
#define NGAP_UE_RADIO_CAPABILITY_FOR_PAGING_PRESENT     0x01
    
    UInt32                                  bitmask;
    
    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                   amf_ue_ngap_id_t;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                   ran_ue_ngap_id_t;

    /*UE RADIO CAPABILITY*/
    ngap_ue_radio_capability_t              ue_radio_capability;

    /*UE RADIO CAPABILITY FOR PAGING*/
    ngap_ue_radio_capability_for_paging_t   ue_radio_capability_for_paging;

}ngap_ue_radio_capability_info_indication_t;

typedef struct
{

    UInt8   transport_layer_address[NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE];

} ngap_transport_layer_address_t;

typedef enum
{

    MINIMUM,
    MEDIUM,
    MAXIMUM,
    MINIMUM_WITHOUT_VENDOR_SPECIFIC_EXTENSION,
    MAXIMUM_WITHOUT_VENDOR_SPECIFIC_EXTENSION

} ngap_trace_depth_et;

typedef struct
{

    /* NG-RAN Trace ID */
    UInt8                           ng_ran_trace_id[NGAP_NG_RAN_TRACE_ID_OCTET_SIZE];

    /* Interfaces to Trace */
    UInt8                           interfaces_to_trace[NGAP_INTERFACE_TO_TRACE_OCTET_SIZE];

    /* Trace Depth */
    ngap_trace_depth_et             trace_depth_event_id;

    /* Trace Collection Entity IP Address */
    ngap_transport_layer_address_t  ip_address;

} ngap_trace_activation_t;

typedef struct
{
    UInt8               count;/*Handover bug fixes*/
    /* TAC */
    ngap_tac_t          tac_t[NGAP_MAX_NO_OF_ALLOWED_AREAS];/*Handover bug fixes*/

} ngap_allowed_tac_t;

typedef struct
{
    UInt8           count;/*Handover bug fixes*/
    /* TAC */
    ngap_tac_t      tac_t[NGAP_MAX_NO_OF_ALLOWED_AREAS];/*Handover bug fixes*/

} ngap_not_allowed_tac_t;

typedef struct
{
#define NGAP_SERVICE_AREA_INFO_ALLOWED_TAC_PRESENT          0x01
#define NGAP_SERVICE_AREA_INFO_NOT_ALLOWED_TAC_PRESENT      0x02
    
    UInt8                   bitmask;

    /* PLMN Identity */ 
    ngap_plmn_identity_t    plmn_identity;

    /* Allowed TAC */
    ngap_allowed_tac_t      allowed_tac;
 
    /* Not Allowed TAC */
    ngap_not_allowed_tac_t  not_allowed_tac;

}ngap_service_area_information_item_t;

typedef struct{
    
    UInt8                                   count;

    ngap_service_area_information_item_t    service_area_information_item[NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE];
    
}ngap_service_area_information_t;


typedef struct
{

   UInt8                   count;  /*Handover bug fixes*/

    /* TAC */
   ngap_tac_t  tac_t[NGAP_MAX_NO_OF_FORB_TACS]; /*Handover bug fixes*/
    
} ngap_forbidden_tac_t; 

typedef struct
{
    /* PLMN Identity */ 
    ngap_plmn_identity_t    plmn_identity;

    /* Forbidden TACs */
    ngap_forbidden_tac_t    forbidden_tac;/*Handover bug fixes*/

}ngap_forbidden_area_info_list_item_t;

typedef struct
{
    UInt8                                    count;

    ngap_forbidden_area_info_list_item_t     forbidden_area_information_item[NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE];

} ngap_forbidden_area_information_t;



typedef struct{

    /* PLMN Identity */ 
    ngap_plmn_identity_t    plmn_identity;

    /* RAT Restriction Information */
    UInt8                   rat_restriction_information[NGAP_RAT_RESTRICTION_INFORMATION_SET_ID_OCTET_SIZE];
 
}ngap_rat_restriction_list_item_t;

typedef struct
{
   UInt8                                count;

    ngap_rat_restriction_list_item_t    rat_restriction_item[NGAP_MAX_NO_OF_EQUIVALENT_PLMN_PLUS_ONE];

} ngap_rat_restriction_t;

typedef struct
{

    /* PLMN Identity */ 
    ngap_plmn_identity_t    plmn_identity;

} ngap_equivalent_plmn_t;


typedef struct
{

    UInt32      index_to_rat_frequency_priority;

} ngap_index_to_rat_frequency_priority_t;

/*Handover bug fixes start*/
typedef struct
{
#define NGAP_MAX_NO_OF_EQUIVALENT_PLMN	        15

    UInt8                               num_equivalent_plmn;

    /* Equivalent PLMNs */
    ngap_equivalent_plmn_t              equivalent_plmn[NGAP_MAX_NO_OF_EQUIVALENT_PLMN];
}ngap_equivalent_plmn_item_t;
/*Handover bug fixes stop*/

typedef struct
{
#define NGAP_MOBILITY_RESTRICTION_EQUIVALENT_PLMN_PRESENT       0x01 // HandOver changes
#define NGAP_MOBILITY_RESTRICTION_RAT_RESTRICTION_PRESENT       0x02
#define NGAP_MOBILITY_RESTRICTION_FORBIDDEN_AREA_INFO_PRESENT   0x04//change
#define NGAP_MOBILITY_SERVING_AREA_INFO_PRESENT                 0x08//change

    UInt8                               bitmask;

    /* Serving PLMN */
    ngap_plmn_identity_t	            serving_plmn;
    
    ngap_equivalent_plmn_item_t         equivalent_plmn;/*Handover bug fixes*/

    /* RAT Restriction */
    ngap_rat_restriction_t              rat_restriction;//HandOver changes

    /* Forbidden Area Information */
    ngap_forbidden_area_information_t   forbidden_area_information;//HandOver chANGES

    /* Service Area Information */
    ngap_service_area_information_t     service_area_information; //HandOver chnages

} ngap_mobility_restriction_list_t;

typedef struct
{

    UInt16  ran_paging_priority;

} ngap_ran_paging_priority_t;

/* Allowed S-NSSAI Item */
typedef struct
{

    /* S-NSSAI */
    ngap_s_nssai_t  s_nssai;

} ngap_allowed_s_nssai_item_t;

/* Allowed S-NSSAI List */
typedef struct
{
#define NGAP_MAX_NO_OF_ALLOWED_NSSAI_LIST_ITEMS     8

    /* count of S-NSSAI items */
    UInt8                      count;

    /* Allowed S-NSSAI Item */
    ngap_allowed_s_nssai_item_t allowed_s_nssai_item[NGAP_MAX_NO_OF_ALLOWED_NSSAI_LIST_ITEMS];

} ngap_allowed_nssai_list_t;

typedef enum
{

    NGAP_UE_CONTEXT_REQUESTED

} ngap_ue_context_request_et;

typedef struct
{

    UInt8   time_stamp[NGAP_TIME_STAMP_OCTET_SIZE];

} ngap_time_stamp_t;

typedef struct
{
#define NGAP_EUTRA_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT    0x01
#define NGAP_EUTRA_USER_LOCATION_INFO_PSCELL_INFO_PRESENT        0x02

    UInt32              bitmask;

    /* TAI */
    ngap_tai_t          tai;

    /* E-UTRA CGI */
    ngap_eutra_cgi_t    eutra_cgi;

    /* Age of Location */
    ngap_time_stamp_t   age_of_location;
    
    /*Pscell information*/
    ngap_ng_ran_cgi_t   pscell_info;

} ngap_eutra_user_location_information_t;

typedef struct
{
#define NGAP_NR_USER_LOCATION_INFO_AGE_OF_LOCATION_PRESENT    0x01

    UInt32              bitmask;

    /* TAI */
    ngap_tai_t          tai;

    /* NR UTRA CGI */
    ngap_nr_cgi_t       nr_cgi;

    /* Age of Location */
    ngap_time_stamp_t   age_of_location;

} ngap_nr_user_location_information_t;

typedef struct
{
#define NGAP_N3IWF_USER_LOCATION_INFO_PORT_NUMBER_PRESENT    0x01

    UInt32                          bitmask;

    /* IP Address */
    ngap_transport_layer_address_t  ip_address;

    /* Port Number */
    UInt8                           port_number[NGAP_PORT_NUMBER_OCTET_SIZE];

} ngap_n3iwf_user_location_information_t;

/* User Location Information */
typedef struct
{
#define NGAP_USER_LOCATION_INFO_CHOICE_EUTRA_USER_LOCATION_INFORMATION	0x01
#define NGAP_USER_LOCATION_INFO_CHOICE_NR_USER_LOCATION_INFORMATION     0x02
#define NGAP_USER_LOCATION_INFO_CHOICE_N3IWF_USER_LOCATION_INFORMATION  0x04

    /* Choice Type for UE NGAP Id */
    UInt8	choice_type;

    /* E-UTRA USER LOCATION INFORMATION */
    ngap_eutra_user_location_information_t      eutra_user_location_information;

    /* NR USER LOCATION INFORMATION */
    ngap_nr_user_location_information_t         nr_user_location_information;

    /* N3IWF USER LOCATION INFORMATION */
    ngap_n3iwf_user_location_information_t      n3iwf_user_location_information;

} ngap_choice_user_location_information_t;

typedef struct
{
#define NGAP_RESET_ALL                                  0x01
#define NGAP_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST   0x02

    UInt8                                           choice_type;

    /* CHOICE Reset Type - NG Interface */
    ngap_reset_all_et                               reset_all_event_id;

    /* Part of NG Interface */
    ngap_ue_associated_logical_ng_connection_list_t ue_associated_logical_ng_connection_list;

} ngap_reset_type;  

/* Time to Wait */
typedef enum
{

    SECOND_1,
    SECOND_2,
    SECOND_5,
    SECOND_10,
    SECOND_20,
    SECOND_60

} ngap_time_to_wait_et;

/* PLMN Support List */
typedef ngap_broadcast_plmn_list_t ngap_plmn_support_list_t;

/* Supported TA List Elements */
typedef struct
{
    /* tac */
    UInt8	                    tac[NGAP_TAC_OCTET_SIZE];

    /* Broadcast PLMN List */
    ngap_broadcast_plmn_list_t	ngap_broadcast_plmn_list;

} ngap_supported_ta_list_element_t;

/* Supported TA List */
typedef struct
{
#define NG_SETUP_REQ_MAX_NO_OF_TAC	256

    /* Count of Supported TA List */
    UInt16	                            ta_count;

    /* Supported TA List */
    ngap_supported_ta_list_element_t	supported_ta[NG_SETUP_REQ_MAX_NO_OF_TAC];
    
} ngap_supported_ta_list_t;

typedef struct
{

    UInt8   transport_layer_address[NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE];	

}endpoint_ip_address_t;

typedef struct
{
   endpoint_ip_address_t                endpoint_ip_address;
   
   UInt8                                port_number[NGAP_PORT_NUMBER_OCTET_SIZE];

}endpoint_ip_address_and_port_t;

/*AMF TNL Association Address*/
typedef struct
{
#define NGAP_TNL_ENDPOINT_IP_ADDR           0x01
#define NGAP_TNL_ENDPOINT_IP_ADD_AND_PORT   0x02

    /*Endpoint-IP-address*/
    UInt8                               choice;

    endpoint_ip_address_t		        endpoint_ip_address;
    
    endpoint_ip_address_and_port_t		endpoint_ip_address_and_port;

}amf_tnl_association_address_t; 
typedef struct
{
#define NGAP_TNL_ASSOCIATION_ADDRESS_AT_AMF_PRESENT 0x01

    UInt8                           bitmask;

    amf_tnl_association_address_t   transport_layer_addr;

    amf_tnl_association_address_t   transport_layer_at_amf;

}ngap_tnl_association_remove_element_item_t;

/* NG-RAN TNL Association to Remove List */
typedef struct
{
#define NG_SETUP_MAX_NO_OF_TNL_ASSOCIATION  32

    /* Count of TNL Associations Remove List*/
    UInt16                                  tnl_count;

    /*  NG-RAN TNL Association to Remove List */
    ngap_tnl_association_remove_element_item_t   tnl_association[NG_SETUP_MAX_NO_OF_TNL_ASSOCIATION];

} ngap_tnl_association_remove_list_t;

typedef struct
{
    
    ngap_recommended_cells_for_paging_t     recommended_cells_for_paging;

} ngap_assistance_data_for_recommended_cells_t;

typedef enum
{

    NEXT_PAGING_AREA_SCOPE_SAME,
    NEXT_PAGING_AREA_SCOPE_CHANGED

} ngap_next_paging_area_scope_et;

typedef struct
{
#define PAGING_ATTEMPT_INFO_NEXT_PAGING_AREA_SCOPE_PRESENT    0X01

    UInt8                           bitmask;

    /* Paging Attempt Count */
    UInt8                           paging_attempt_count;

    /* Intended Number of Paging Attempts */
    UInt8                           intended_number_of_paging_attempts;

    /* Next Paging Area Scope */
    ngap_next_paging_area_scope_et  next_paging_area_scope;

} ngap_paging_attempt_info_t;

typedef struct
{
#define ASSISTANCE_DATA_FOR_PAGING_RECOMMENDED_CELLS_PRESENT    0X01
#define ASSISTANCE_DATA_FOR_PAGING_PAGING_ATTEMPT_INFO_PRESENT  0X02

    UInt8                                           bitmask;

    /* Assistance Data for Recommended Cells */
    ngap_assistance_data_for_recommended_cells_t    assistance_data_for_recommended_cells;

    /* Paging Attempt Information */
    ngap_paging_attempt_info_t                      paging_attempt_info;

} ngap_assistance_data_for_paging_t;

/*******************************************************************************
 *   UE RETENTION INFORMATION
 *******************************************************************************/
typedef enum
{
    NGAP_UES_RETAINED

}ngap_ue_retention_info_et;

/*******************************************************************************
 * NG SETUP REQUEST
 ******************************************************************************/

typedef struct
{
#define NG_SETUP_REQ_RAN_NODE_NAME_ID_PRESENT     0x01
#define NG_SETUP_REQ_UE_RETENTION_INFO_PRESENT    0x02

    UInt32		                bitmask;

    /* Global RAN Node Id */
    ngap_global_ran_node_id_t	global_ran_node_id;

    /* RAN Node Name Length */
    UInt8			            ran_node_name_length;

    /* RAN Node Name */
    UInt8			            ran_node_name[NGAP_MAX_RAN_NODE_NAME_LENGTH];

    /* Supported TA List */
    ngap_supported_ta_list_t    supported_ta_list;

    /* Default Paging DRX */
    default_paging_drx_et		default_paging_drx;
   
    /* UE Retention Information */
    ngap_ue_retention_info_et   ue_retention_info;

} ngap_setup_request_t;


/*******************************************************************************
 *  * NG SETUP RESPONSE
 ******************************************************************************/
typedef struct
{
#define NG_SETUP_RES_CRITICALITY_DIAGNOSTICS_PRESENT     0x01
#define NG_SETUP_RES_UE_RETENTION_INFO_PRESENT           0x02

    UInt32                          bitmask;

    /* AMF Name */
    ngap_amf_name_t                 amf_name;

    /* Served GUAMI List */
    ngap_served_guami_list_t        served_guami_list;

    /* Relative AMF Capacity */
    UInt8                           relative_amf_capacity;

    /* PLMN Support List */
    ngap_plmn_support_list_t        plmn_support_list;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t  criticality_diagnostics;
    
    /* UE Retention Information */
    ngap_ue_retention_info_et       ue_retention_info;

} ngap_setup_response_t;

/*******************************************************************************
 * NG SETUP FAILURE
 ******************************************************************************/

typedef struct
{
#define NG_SETUP_FAIL_TIME_TO_WAIT_PRESENT                0x01
#define NG_SETUP_FAIL_CRITICALITY_DIAGNOSTICS_PRESENT     0x02

    UInt32                          bitmask;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

    /* Time to Wait */
    ngap_time_to_wait_et            time_to_wait_event_id;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t  criticality_diagnostics;

} ngap_setup_failure_t;


/*******************************************************************************
 * NG RESET
 ******************************************************************************/

typedef struct
{

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;
    
    /* ngap reset type*/
    ngap_reset_type                 reset_type;

} ngap_reset_t;


/*******************************************************************************
 * NG RESET ACKNOWLEDGE
 ******************************************************************************/

typedef struct
{
#define NG_RESET_ACK_UE_ASSOCIATED_LOGICAL_NG_CONNECTION_LIST_PRESENT   0x01
#define NG_RESET_ACK_CRITICALITY_DIAGNOSTICS_PRESENT                    0x02

    UInt32                                          bitmask;

    /* UE-Associated Logical NG-Connection List */
    ngap_ue_associated_logical_ng_connection_list_t ue_associated_logical_ng_connection_list;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t                  criticality_diagnostics;

} ngap_reset_acknowledge_t;

/*******************************************************************************
 * RAN CONGIGURATION UPDATE
 ******************************************************************************/
typedef struct
{
#define RAN_CONFIG_UPDATE_RAN_NODE_NAME_PRESENT          0x01
#define RAN_CONFIG_UPDATE_SUPPORTED_TA_LIST_PRESENT      0x02
#define RAN_CONFIG_UPDATE_DEFAULT_PAGING_DRX_PRESENT     0x04
#define RAN_CONFIG_UPDATE_GLOBAL_RAN_NODE_ID_PRESENT     0x08
#define RAN_CONFIG_UPDATE_TNL_ASSOCIATION_LIST_PRESENT   0x10
	UInt32		                bitmask;
 
	/* RAN Node Name Length */
	UInt8			            ran_node_name_length;

	/* RAN Node Name */
	UInt8			            ran_node_name[NGAP_MAX_RAN_NODE_NAME_LENGTH];

	/* Supported TA List */
	ngap_supported_ta_list_t    supported_ta_list;

	/* Default Paging DRX */
	default_paging_drx_et		default_paging_drx;
	
    /* Global RAN Node Id */
	ngap_global_ran_node_id_t	        global_ran_node_id;

    /* NG-RAN TNL Association to Remove List */
    ngap_tnl_association_remove_list_t  tnl_asso_remove_list; 

}ran_config_update_t;

typedef struct
{
#define RAN_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT 0x01

    UInt8                          bitmask;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t criticality_diagnostics;

}ran_config_update_ack_t;

typedef struct
{
#define RAN_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT     0x01
#define RAN_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT 0x02

    UInt8                           bitmask;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

    /* Time to Wait */
    ngap_time_to_wait_et            time_to_wait_event_id;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t criticality_diagnostics;

}ran_config_update_failure_t;

/*AMF_CONFIGURATION_UPADTE_CHANGES_START */
/*******************************************************************************
 * AMF CONFIGURATION UPDATE
 ******************************************************************************/
typedef enum
{
    TNL_ASSOCIATION_IS_USED_ONLY_FOR_UE_ASSOCIATED_SIGNALLING,
    TNL_ASSOCIATION_IS_USED_FOR_NON_UE_ASSOCIATED_SIGNALLING,
    TNL_ASSOCIATION_IS_USED_ONLY_FOR_BOTH

}tnl_association_usage_et;

/*CP Transport Layer Information*/ 
#if 0 
typedef struct
{

    UInt8   transport_layer_address[NGAP_TRANSPORT_LAYER_ADDRESS_OCTET_SIZE];	

}endpoint_ip_address_t;

/*AMF TNL Association Address*/
typedef struct
{
    /*Endpoint-IP-address*/
    endpoint_ip_address_t		endpoint_ip_address;

}amf_tnl_association_address_t; 
#endif

/*AMF TNL Association to update item */
typedef struct
{	
	#define TNL_ASSOCIATION_TO_UPDATE_USAGE_PRESENT		            0x01
	#define TNL_ASSOCIATION_TO_UPDATE_ADDRESS_WEIGHT_FACTOR_PRESENT	0x02

	/* count */
	UInt32 					                    bitmask;

	/*AMF TNL Association Address*/
	amf_tnl_association_address_t		        tnl_association_address;

	/*TNL Association Usage*/
	tnl_association_usage_et			        association_usage;

	/*TNL Address Weight Factor */	
	UInt8		                                weight_factor;
 	
}amf_tnl_association_to_update_item_t; 

/*AMF TNL Association to update list */
typedef struct
{
    /* count */
    UInt16					                count;

    /*AMF TNL Association to Add List */
    amf_tnl_association_to_update_item_t	tnl_association_item[NGAP_MAX_NO_OF_TNL_ASSOCIATIONS];

}amf_tnl_association_update_list_t; 

typedef struct
{
#define TNL_ASSOCIATION_IE_EXTENSION_PRESENT                        0x01
#define TNL_ASSOCIATION_TRANSPORT_LAYER_ADDRESS_NG_RAN_AMF_PRESENT  0x02

	UInt8                            bitmask;
    
    /*AMF TNL Association Address*/
	amf_tnl_association_address_t   tnl_association_address;

    /* TNL Association Transport Layer Address NG-RAN*/
    amf_tnl_association_address_t    tnl_association_transport_layer_address_ng_ran_amf;

}amf_tnl_association_to_remove_item_t;

/*AMF TNL Association to Remove list */
typedef struct
{
    /* count */
    UInt16					                count;

    /*AMF TNL Association to Add List */
    amf_tnl_association_to_remove_item_t	tnl_association_item[NGAP_MAX_NO_OF_TNL_ASSOCIATIONS];

}amf_tnl_association_remove_list_t; 

/*AMF TNL Association to Add ITEM */
typedef struct
{
#define TNL_ASSOCIATION_TO_ADD_LIST_USAGE_PRESENT		0x01

    /* count */
    UInt32 					                bitmask;

    /*AMF TNL Association Address*/
    amf_tnl_association_address_t		    tnl_association_address;

    /*TNL Association Usage*/
    tnl_association_usage_et			    association_usage;

    /*TNL Address Weight Factor */	
    UInt8		                            weight_factor;

}amf_tnl_association_to_add_item_t; 

/*AMF TNL Association to Add LIST  */
typedef struct
{
    /* count */
    UInt16					            count;

    /*AMF TNL Association to Add List */
    amf_tnl_association_to_add_item_t	tnl_association_item[NGAP_MAX_NO_OF_TNL_ASSOCIATIONS];

}amf_tnl_association_to_add_list_t;
typedef struct
{
#define AMF_CONFIG_UPDATE_AMF_NAME                              0x01
#define AMF_CONFIG_UPDATE_SERVED_GUAMI_LIST                     0x02
#define AMF_CONFIG_UPDATE_RELATIVE_AMF_CAPACITY                 0x04
#define AMF_CONFIG_UPDATE_PLMN_SUPPORT_LIST                     0x08
#define AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_ADD_LIST       0x10
#define AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_REMOVE_LIST    0x20
#define AMF_CONFIG_UPDATE_AMF_TNL_ASSOCIATION_TO_UPDATE_LIST    0x40
    UInt32		                                    bitmask;

    /* AMF Name */
    ngap_amf_name_t                                 amf_name;

    /* Served GUAMI List */
    ngap_served_guami_list_t                        served_guami_list;

    /* Relative AMF Capacity */
    UInt8                                           relative_amf_capacity;

    /* PLMN Support List */
    ngap_plmn_support_list_t                        plmn_support_list;

    /*AMF TNL Association to Add List */
    amf_tnl_association_to_add_list_t               association_add_list;

    /*AMF TNL Association to Remove List */
    amf_tnl_association_remove_list_t               association_remove_list;

    /*AMF TNL Association to update List */
    amf_tnl_association_update_list_t               association_update_list;

}amf_config_update_t;

/*AMF_CONFIGURATION_UPADTE_CHANGES_END */

typedef struct
{
    /*AMF TNL Association Address*/
    amf_tnl_association_address_t		    tnl_association_address;

}amf_tnl_association_setup_item_t;

typedef struct
{
    UInt16                           count;

    /*AMF TNL Association Setup Item*/
    amf_tnl_association_setup_item_t   tnl_association_setup_item[NGAP_MAX_NO_OF_TNL_ASSOCIATIONS];

}amf_tnl_association_setup_list_t;

typedef struct
{

    /*AMF TNL Association Address*/
    amf_tnl_association_address_t   tnl_association_address;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

}tnl_association_item_t;

typedef struct
{
    UInt16                      count;

    /*TNL Association Item*/
    tnl_association_item_t      tnl_association_setup_item[NGAP_MAX_NO_OF_TNL_ASSOCIATIONS];

}amf_tnl_association_failed_to_setup_list_t;

typedef struct
{
#define AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_SETUP_PRESENT           0x01
#define AMF_CONFIGURATION_UPDATE_ACK_TNL_ASSOCIATION_FAILED_TO_SETUP_PRESENT 0x02
#define AMF_CONFIGURATION_UPDATE_ACK_CRITICALITY_DIAG_PRESENT                0x04
    UInt8                                          bitmask;

    /* AMF TNL Association Setup List */
    amf_tnl_association_setup_list_t               association_setup_list;

    /*AMF TNL Association Failed to Setup List */
    amf_tnl_association_failed_to_setup_list_t     association_failed_to_setup_list;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t                 criticality_diagnostics;

}amf_config_update_ack_t;

typedef struct
{
#define AMF_CONFIGURATION_UPDATE_FAIL_TIME_TO_WAIT_PRESENT     0x01
#define AMF_CONFIGURATION_UPDATE_FAIL_CRITICALITY_DIAG_PRESENT 0x02

    UInt8                           bitmask;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

    /* Time to Wait */
    ngap_time_to_wait_et            time_to_wait_event_id;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t criticality_diagnostics;

}amf_config_update_failure_t;

/*******************************************************************************
 * ERROR INDICATION
 ******************************************************************************/

typedef struct
{
#define ERROR_INDICATION_AMF_UE_NGAP_ID_PRESENT             0x01
#define ERROR_INDICATION_RAN_UE_NGAP_ID_PRESENT             0x02
#define ERROR_INDICATION_CAUSE_PRESENT                      0x04
#define ERROR_INDICATION_CRITICALITY_DIAGNOSTICS_PRESENT    0x08

    UInt32                          bitmask;
    
    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t           amf_ue_ngap_id_t;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t           ran_ue_ngap_id_t;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t  criticality_diagnostics;

} ngap_error_indication_t;


/*******************************************************************************
 * INITIAL UE MESSAGE 
 ******************************************************************************/

typedef struct
{
#define INITIAL_UE_MESSAGE_CONFIGURED_NSSAI                     0x01     
#define INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_PLMN               0x02
#define INITIAL_UE_MESSAGE_REJECTED_NSSAI_IN_TA                 0x04

    UInt32                                       bitmask;
    
    /* Configured  NSSAI */
    ngap_dynamic_string_t                        conf_nssai;

    /* Rejected NSSAI in PLMN */
    ngap_dynamic_string_t                        rej_nssai_plmn;

    /* Rejected NSSAI in TA */
    ngap_dynamic_string_t                        rej_nssai_ta;

}ngap_source_to_target_information_reroute_t;

typedef struct
{
#define INITIAL_UE_MESSAGE_5G_S_TMSI_PRESENT                            0x01
#define INITIAL_UE_MESSAGE_AMF_SET_ID_PRESENT                           0x02
#define INITIAL_UE_MESSAGE_UE_CONTEXT_REQUEST_PRESENT                   0x04
#define INITIAL_UE_MESSAGE_ALLOWED_NSSAI_PRESENT                        0x08
#define INITIAL_UE_MESSAGE_SOURCE_TO_TARGET_AMF_INFO_REROUTE_PRESENT    0x10 

    UInt32                                       bitmask;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                   ran_ue_ngap_id;

    /* NAS-PDU */
    ngap_dynamic_string_t                   nas_pdu;

    /* User Location Information */
    ngap_choice_user_location_information_t choice_user_location_information; 

    /* RRC Establishment Cause */
    ngap_rrc_establishment_cause_et      	rrc_establishment_cause;

    /* 5G-S-TMSI */
    ngap_5g_s_tmsi_t                        tmsi;

    /* AMF Set Id */
    ngap_amf_set_id_t                       amf_set_id;
    
    /* UE Context Request */
    ngap_ue_context_request_et              ue_context_request_event_id;

    /* Allowed NSSI */
    ngap_allowed_nssai_list_t                    allowed_nssai_list;

    /* Source to Target AMF Information Reroute  */
    ngap_source_to_target_information_reroute_t  source_to_target_information_reroute;

} ngap_initial_ue_message_t;


/*******************************************************************************
 * DOWNLINK NAS TRANSPORT 
 ******************************************************************************/

typedef struct
{
#define DL_NAS_TRANSPORT_OLD_AMF_PRESENT                                    0x01
#define DL_NAS_TRANSPORT_RAN_PAGING_PRIORITY_PRESENT                        0x02
#define DL_NAS_TRANSPORT_MOBILITY_RESTRICTION_LIST_PRESENT                  0x04
#define DL_NAS_TRANSPORT_INDEX_TO_RAT_FREQUENCY_SELECTION_PRIORITY_PRESENT  0x08
#define DL_NAS_TRANSPORT_UE_AGGREGATE_MAXIMUM_BIT_RATE_PRESENT              0x10
#define DL_NAS_TRANSPORT_ALLOWED_NSSAI_PRESENT                              0x20
    
    UInt32                                  bitmask;
    
    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                   amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                   ran_ue_ngap_id;

    /* AMF Name */
    ngap_amf_name_t                         amf_name;

    /* RAN Paging Priority */
    ngap_ran_paging_priority_t              ran_paging_priority;

    /* NAS-PDU */
    ngap_dynamic_string_t                   nas_pdu;
   
    /* Mobility Restriction List */
    ngap_mobility_restriction_list_t        mobility_restriction_list;

    /* Index To RAT Frequency Selection Priority */
    ngap_index_to_rat_frequency_priority_t  index_to_rat_frequency_priority;

    /* UE Aggregate Maximum Bit Rate */
    ngap_ue_aggregate_maximum_bit_rate_t    ue_aggregate_maximum_bit_rate;

    /* Allowed NSSI */
    ngap_allowed_nssai_list_t               allowed_nssai_list;

} ngap_downlink_nas_transport_t;


/*******************************************************************************
 * UPLINK NAS TRANSPORT 
 ******************************************************************************/

typedef struct
{

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                   amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                   ran_ue_ngap_id;

    /* NAS-PDU */
    ngap_dynamic_string_t                   nas_pdu;

    /* User Location Information */
    ngap_choice_user_location_information_t choice_user_location_information;

} ngap_uplink_nas_transport_t;


/*******************************************************************************
 * NAS NON DELIVERY INDICATION 
 ******************************************************************************/

typedef struct
{

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t       amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t       ran_ue_ngap_id;

    /* NAS-PDU */
    ngap_dynamic_string_t       nas_pdu;

    /* Cause */
    ngap_choice_cause_group_t   choice_cause_group;

} ngap_nas_non_delivery_indication_t;


/*******************************************************************************
 * UE CONTEXT RELEASE REQUEST
 ******************************************************************************/

typedef struct
{
#define UE_CONTEXT_RELEASE_REQUEST_PDU_SESSION_RESOURCE_LIST_PRESENT	0x01

    UInt16                              bitmask;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t       		amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t       		ran_ue_ngap_id;

	/* PDU Session Resource List  */
	ngap_pdu_session_resource_list_t	pdu_session_resource_list;

    /* Cause */
    ngap_choice_cause_group_t   		choice_cause_group;

} ngap_ue_context_release_request_t;


/*******************************************************************************
 * UE CONTEXT RELEASE COMMAND
 ******************************************************************************/

typedef struct
{
#define UE_CONTEXT_REL_CMD_RAN_UE_NGAP_ID_PRESENT   0x01

    /* Bitmask for RAN UE NGAP Id */
    UInt8                       bitmask;

    /* AMF UE NGAP ID */
    ngap_ran_ue_ngap_id_t       ran_ue_ngap_id;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t       amf_ue_ngap_id;

    /* Cause */
    ngap_choice_cause_group_t   choice_cause_group;

} ngap_ue_context_release_command_t;


/*******************************************************************************
 * UE CONTEXT RELEASE COMPLETE
 ******************************************************************************/

typedef struct
{
#define UE_CONTEXT_RELEASE_COMPLETE_USER_LOCATION_INFO_PRESENT                                  0x01
#define UE_CONTEXT_RELEASE_COMPLETE_INFO_ON_RECOMMENDED_CELLS_AND_RAN_NODES_FOR_PAGING_PRESENT  0x02
#define UE_CONTEXT_RELEASE_COMPLETE_CRITICALITY_DIAGNOSTICS_PRESENT                             0x04

    UInt32                                                      bitmask;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                                       amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                                       ran_ue_ngap_id;

    /* User Location Information */
    ngap_choice_user_location_information_t                     choice_user_location_information; 

    /* Information on Recommended Cells and RAN Nodes for Paging */
    ngap_info_on_recommended_cells_and_ran_nodes_for_paging_t   info_on_recommended_cells_and_ran_nodes_for_paging;

    /* PDU Session Resource List */
    ngap_pdu_session_resource_list_t                            pdu_session_resource_item_t;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t                              criticality_diagnostics;

} ngap_ue_context_release_complete_t;


typedef enum
{
    NGAP_REDIRECTION_VOICE_FALLBACK_POSSIBLE,
    NGAP_REDIRECTION_VOICE_FALLBACK_NOT_POSSIBLE

}ngap_redirection_voice_fallback_et;


typedef enum
{
    NGAP_SUBSCRIPTION_INFORMATION,
    NGAP_STATISTICS

}ngap_source_of_ue_activity_behaviour_info_et;

typedef struct
{
#define NGAP_CNAssisted_EXPECTED_ACTIVITY_PERIOD_PRESENT                        0x01
#define NGAP_CNAssisted_EXPECTED_IDLE_PERIOD_PRESENT                            0x02
#define NGAP_CNAssisted_EXPECTED_SOURCE_OF_UE_ACTIVITY_BEHAVIOUR_INFORMATION    0x03

   UInt8                                            bitmask;
   
   UInt32                                           expected_activity_period;

   UInt32                                           expected_idle_period;

   ngap_source_of_ue_activity_behaviour_info_et     source_of_ue_activity_behaviour_info;

}ngap_expected_ue_activity_behaviour_t;

typedef enum
{
    NGAP_SEC15,
    NGAP_SEC30,
    NGAP_SEC60,
    NGAP_SEC90,
    NGAP_SEC120,
    NGAP_SEC180,
    NGAP_LONG_TIME

}ngap_expected_ho_interval_et;

typedef enum
{
    NGAP_STATIONARY,
    NGAP_MOBILE

}ngap_expected_ue_mobility_et;

typedef struct
{
#define NGAP_CNAssisted_TIME_STAYED_IN_CELL_PRESENT     0x01
    
    UInt8                   bitmask;

    ngap_ng_ran_cgi_t       ran_cgi;

    UInt16                  time_stayed_in_cell;

}ngap_expected_moving_trajectory_item_t;

typedef struct
{
#define NGAP_EXPECTED_MOVING_TRAJECTORY_ITEM    16

    UInt8                   count;

    ngap_expected_moving_trajectory_item_t  expected_moving_trajectory_item[NGAP_EXPECTED_MOVING_TRAJECTORY_ITEM];

}ngap_expected_moving_trajectory_list_t;

typedef struct
{
#define NGAP_CNAssisted_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT  0x01
#define NGAP_CNAssisted_EXPECTED_HO_INTERVAL_PRESENT            0x02
#define NGAP_CNAssisted_EXPECTED_UE_MOBILITY_PRESENT            0x04 /*Handover bug fixes*/
#define NGAP_CNAssisted_EXPECTED_MOVING_TRAJECTORY_PRESENT      0x08 /*Handover bug fixes*/

    UInt8                                       bitmask;

    ngap_expected_ue_activity_behaviour_t       expected_ue_activity_behaviour;
    
    ngap_expected_ho_interval_et                expected_ho_interval;

    ngap_expected_ue_mobility_et                expected_ue_mobility;

    ngap_expected_moving_trajectory_list_t      expected_moving_trajectory;

}ngap_expected_ue_bhaviour_t;

typedef struct
{
#define NGAP_CNAssisted_EXPECTED_UE_BEHAVIOUR_PRESENT   0x01
    
    UInt8                           bitmask;

    ngap_expected_ue_bhaviour_t     expected_ue_behaviour;

}ngap_CNAssisted_ran_tuning_t;


typedef enum{

    NGAP_DIRECT,
    NGAP_CHANGE_OF_SERVE_CELL,
    NGAP_UE_PRESENCE_IN_AREA_OF_INTEREST,
    NGAP_STOP_CHANGE_OF_SERVE_CELL,
    NGAP_STOP_UE_PRESENCE_IN_AREA_OF_INTEREST,
    NGAP_CANCEL_LOCATION_REPORTING_FOR_THE_UE

}ngap_event_type_et;

typedef enum {
    NGAP_CELL
}ngap_report_area_et;

typedef enum {
    NGAP_INCLUDE_PSCell
} ngap_additional_location_information_et;

typedef struct
{
    ngap_tai_t          tai;

}ngap_area_of_interest_tai_item_t;

typedef struct
{
#define NGAP_AREA_OF_INTEREST_TAI_LIST_COUNT    16

    UInt8               count;

    ngap_area_of_interest_tai_item_t    tai[NGAP_AREA_OF_INTEREST_TAI_LIST_COUNT];

}ngap_area_of_interest_tai_list_t;

typedef struct
{
    ngap_ng_ran_cgi_t       ngran_cgi;

}ngap_area_of_interest_cell_item_t;


typedef struct
{
#define NGAP_AREA_OF_INTEREST_CELL_ITEM_COUNT   256

    UInt8                               count;

    ngap_area_of_interest_cell_item_t   ngap_area_of_interest_cell_item[NGAP_AREA_OF_INTEREST_CELL_ITEM_COUNT];

}ngap_area_of_interest_cell_list_t;

typedef struct{

   ngap_global_ran_node_id_t    global_ran_node_id; 

}ngap_area_of_interest_ran_node_item_t;

typedef struct
{
#define NGAP_AREA_OF_INTEREST_RAN_NODE_MAX_COUNT    64

    UInt8                                   count;

    ngap_area_of_interest_ran_node_item_t   area_of_interest_ran_node_item[NGAP_AREA_OF_INTEREST_RAN_NODE_MAX_COUNT];

}ngap_area_of_interest_ran_node_list_t;


typedef struct
{
#define NGAP_AREA_OF_INTEREST_TAI_LIST_PRESENT      0x01
#define NGAP_AREA_OF_INTEREST_CELL_LIST_PRESENT     0x02
#define NGAP_AREA_OF_INTEREST_RAN_NODE_LIST_PRESENT 0x04 /*Handover bug fixes*/
    
    
    UInt8                                   bitmask;
    
    ngap_area_of_interest_tai_list_t        area_of_interest_tai_list;

    ngap_area_of_interest_cell_list_t       area_of_interest_cell_list;
    
    ngap_area_of_interest_ran_node_list_t   area_of_interest_ran_node_list;

}ngap_area_of_interest_t;

typedef struct{

    ngap_area_of_interest_t     area_of_interest;

    UInt32                      location_reporting_ref_id;

}ngap_area_of_interest_list_item_t;

typedef struct{

#define NGAP_AREA_INTEREST_MAX_COUNT    64

    UInt8                                   count;

    ngap_area_of_interest_list_item_t       area_of_interest_list_item[NGAP_AREA_INTEREST_MAX_COUNT];

}ngap_area_of_interest_list_t;


typedef struct {

#define NGAP_AREA_OF_LIST_PRESENT                                       0x01
#define NGAP_LOCATION_REPORTING_REFERENCE_ID_TO_BE_CANCELLED_PRESENT    0x02
#define NGAP_ADDITIONAL_LOCATION_INFORMATION_PRESENT                    0x04
    UInt8                           bitmask;

    ngap_event_type_et              eventType;
    
    ngap_report_area_et             report_area;

    ngap_area_of_interest_list_t    area_of_interest;

    UInt32                                      location_reporting_ref_id_to_be_cancelled;
    
    ngap_additional_location_information_et     additional_location_information;

}ngap_location_reporting_req_type_t;

typedef struct
{

#define NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_ACTIVITY_BEHAVIOUR_PRESENT   0x01
#define NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_HO_INTERVAL_PRESENT             0x02
#define NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_MOBILITY_PRESENT             0x04
#define NGAP_EXPECTED_UE_BEHAVIOUR_EXPECTED_UE_MOVING_TRAJECTORY            0x08//HandOver changes

#define NGAP_MAX_NO_OF_CELLS_UE_MOVING_TRAJECTORY                           16

    UInt32                                      bitmask;


    /* Expected UE Activity Behaviour */
    ngap_expected_ue_activity_behaviour_t       expected_ue_activity_behaviour;

    /* Expected HO INTERVAL */
    ngap_expected_ho_interval_et                expected_ho_interval_event_id;

    /* Expected UE MOBILITY */
    ngap_expected_ue_mobility_et                expected_ue_mobility_event_id;

    /* Expected UE Moving Trajectory */
    ngap_expected_moving_trajectory_list_t      expected_moving_trajectory;//HandOver changes

} ngap_expected_ue_behaviour_t;

typedef struct
{

    /* TAI */
    ngap_tai_t  tai;

} ngap_tai_list_for_rrc_inactive_item_t;

typedef enum
{

    MICO_MODE_INDICATION_TRUE

} ngap_mico_mode_indication_et;
/*HandOver_code_changes_start */
typedef struct
{
     UInt8                                  count;

    /* TAI List for RRC Inactive */
    ngap_tai_list_for_rrc_inactive_item_t   tai_list_for_rrc_inactive_item[NGAP_MAX_NO_OF_TAI_FOR_INACTIVE];

}ngap_tai_list_for_inactive_t;

/*HandOver_code_changes_end */

typedef struct
{
#define NGAP_CORE_NETWORK_ASSISTANCE_INFO_UE_SPECIFIC_DRX_PRESENT       0x01
#define NGAP_CORE_NETWORK_ASSISTANCE_INFO_MICO_MODE_INDICATION_PRESENT  0x02
#define NGAP_CORE_NETWORK_ASSISTANCE_INFO_EXPECTED_UE_BEHAVIOUR_PRESENT 0x04

    UInt32                                  bitmask;

    /* UE Identity Index Value  */
    UInt8                                   ue_identity_index_value[NGAP_UE_IDENTITY_INDEX_VALUE_OCTET_SIZE];

    /* UE Specific DRX */
    default_paging_drx_et                   paging_drx_event_id;

    /* Periodic Registration Update Timer */
    UInt8                                   periodic_registration_update_timer[NGAP_PERIODIC_REGISTRATION_UPDATE_TIMER_OCTET_SIZE];
    
    /* MICO Mode Indication */
    ngap_mico_mode_indication_et            mico_mode_indication_event_id;

    /* TAI List for RRC Inactive */
    
    ngap_tai_list_for_inactive_t              tai_list_for_inactive;

    /* Expected UE Behaviour */
    ngap_expected_ue_behaviour_t            expected_ue_behaviour;

} ngap_core_network_assistance_info_for_inactive_t;



/*******************************************************************************
 * INITIAL CONTEXT SETUP REQUEST 
 ******************************************************************************/

typedef struct
{
#define INITIAL_CONTEXT_SETUP_REQUEST_OLD_AMF_PRESENT                                   0x0001
#define INITIAL_CONTEXT_SETUP_REQUEST_UE_AGGR_MAX_BIT_RATE_PRESENT                      0x0002
#define INITIAL_CONTEXT_SETUP_REQUEST_CORE_NETWORK_ASSISTANCE_INFO_PRESENT              0x0004
#define INITIAL_CONTEXT_SETUP_REQUEST_PDU_SESSION_RESOURCE_SETUP_REQUEST_LIST_PRESENT   0x0008
#define INITIAL_CONTEXT_SETUP_REQUEST_TRACE_ACTIVATION_PRESENT                          0x0010
#define INITIAL_CONTEXT_SETUP_REQUEST_MOBILITY_RESTRICTION_LIST_PRESENT                 0x0020
#define INITIAL_CONTEXT_SETUP_REQUEST_UE_RADIO_CAPABILITY_PRESENT                       0x0040
#define INITIAL_CONTEXT_SETUP_REQUEST_INDEX_TO_RAT_FREQUENCY_SELECTION_PRIORITY_PRESENT	0x0080
#define INITIAL_CONTEXT_SETUP_REQUEST_MASKED_IMEISV_PRESENT                             0x0100
#define INITIAL_CONTEXT_SETUP_REQUEST_NAS_PDU_PRESENT                                   0x0200
#define INITIAL_CONTEXT_SETUP_REQUEST_EMERGENCY_FALLBACK_INDICATOR_PRESENT              0x0400
#define INITIAL_CONTEXT_SETUP_REQUEST_RRC_INACTIVE_TRANSITION_REPORT_REQUEST_PRESENT    0x0800
#define INITIAL_CONTEXT_SETUP_REQUEST_UE_RADIO_PAGING_CAPABILITY_PRESENT                0x1000
#define INITIAL_CONTEXT_SETUP_REQUEST_REDIRECTION_VOICE_FALLBACK_PRESENT                0x2000
#define INITIAL_CONTEXT_SETUP_REQUEST_LOCATION_REPORTING_REQUEST_TYPE_PRESENT           0x4000
#define INITIAL_CONTEXT_SETUP_REQUEST_CNASSITED_RAN_TUNING_PRESENT                      0x8000
    
    UInt32                                              bitmask;
    
    /* Count of PDU Session Resource Setup Request List */
    UInt8                                               count;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                               amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                               ran_ue_ngap_id;

    /* Old AMF */
    ngap_amf_name_t                                     amf_name;
    
    /* UE Aggregate Maximum Bit Rate */
    /* Guarded By PDU Session Resource Setup List's bitmask */
    ngap_ue_aggregate_maximum_bit_rate_t                ue_aggregate_maximum_bit_rate;

    /* Core Network Assistance Information */
    ngap_core_network_assistance_info_for_inactive_t    core_network_assistance_info;

    /* GUAMI */
    ngap_guami_t                                        guami;

    /* PDU Session Resource Setup Request List */
	ngap_pdu_session_resource_setup_request_list_t  	pdu_session_resource_setup_request_list;

    /* Allowed NSSI */
    ngap_allowed_nssai_list_t                           allowed_nssai_list;

    /* UE Security Capabilities */
    ngap_ue_security_capabilities_t                     ue_security_capabilities;

    /* Security Key */
    ngap_security_key_t                                 security_key;

    /* Trace Activation */
    ngap_trace_activation_t                             tarce_activation;
    
    /* Mobility Restriction List */
    ngap_mobility_restriction_list_t                    mobility_restriction_list;

    /* UE Radio Capability */
    ngap_ue_radio_capability_t                          ue_radio_capability;

    /* Index To RAT Frequency Selection Priority */
    ngap_index_to_rat_frequency_priority_t              index_to_rat_frequency_priority;

    /* Masked IMEISV */
    ngap_masked_imeisv_t                                masked_imeisv;

    /* NAS-PDU */
    ngap_dynamic_string_t                               nas_pdu;
   
    /* Emergency Fallback Indicator */
    ngap_emergency_fallback_indicator_t                 emergency_fallback_indicator;

    /* RRC Inactive Transition Report Request */
    ngap_rrc_inactive_transition_report_request_et      rrc_inactive_transition_report_request_event_id;

	/* UE Radio Capability for Paging */
	ngap_ue_radio_capability_for_paging_t			    ue_radio_capability_for_paging;

   /* Redirection Voice Fallback */
    ngap_redirection_voice_fallback_et                  redirection_voice_fallback;
   
   /*LocaionReportingRequestType*/
    ngap_location_reporting_req_type_t                  location_reporting_Req_type;
    
    /*CNAssisted RAN Tuning*/
    ngap_CNAssisted_ran_tuning_t                        can_assisted_ran_tuning;

} ngap_initial_context_setup_request_t;


/*******************************************************************************
 * INITIAL CONTEXT SETUP RESPONSE 
 ******************************************************************************/

typedef struct
{
#define INITIAL_CONTEXT_SETUP_RESPONSE_PDU_SESSION_RESOURCE_SETUP_RESPONSE_LIST_PRESENT		0x01
#define INITIAL_CONTEXT_SETUP_RESPONSE_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_PRESENT	0x02
#define INITIAL_CONTEXT_SETUP_RESPONSE_CRITICALITY_DIAGNOSTICS_PRESENT     					0x04

    UInt32                                              bitmask;
  
    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t                               amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t                               ran_ue_ngap_id;

    /* PDU Session Resource Setup Response List */
	ngap_pdu_session_resource_setup_response_list_t		pdu_session_resource_setup_response_list;

    /* PDU Session Resource Failed to Setup List */
	ngap_pdu_session_resource_failed_to_setup_list_t	pdu_session_resource_failed_to_setup_list;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t                      criticality_diagnostics;

} ngap_initial_context_setup_response_t;


/*******************************************************************************
 * INITIAL CONTEXT SETUP FAILURE 
 ******************************************************************************/

typedef struct
{
#define INITIAL_CONTEXT_SETUP_FAILURE_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_PRESENT	0x01
#define INITIAL_CONTEXT_SETUP_FAILURE_CRITICALITY_DIAGNOSTICS_PRESENT     				0x02

    UInt32                          bitmask;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t           amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t           ran_ue_ngap_id;

    /* Cause */
    ngap_choice_cause_group_t       choice_cause_group;

    /* PDU Session Resource Failed to Setup List */
	ngap_pdu_session_resource_failed_to_setup_list_t	pdu_session_resource_failed_to_setup_list;

    /* Criticality Diagnostics */
    ngap_criticality_diagnostics_t  criticality_diagnostics;

} ngap_initial_context_setup_failure_t;


/*******************************************************************************
 * PAGING 
 ******************************************************************************/

typedef struct
{
#define NGAP_PAGING_PAGING_DRX_PRESENT                              0x001
#define NGAP_PAGING_PAGING_PRIORITY_PRESENT                         0x002
#define NGAP_PAGING_PAGING_UE_RADIO_CAPABILITY_FOR_PAGING_PRESENT   0x004
#define NGAP_PAGING_PAGING_ASSISTANCE_DATA_FOR_PAGING_PRESENT       0x008
#define NGAP_PAGING_PAGING_ORIGIN_PRESENT                           0x010

    UInt8                                   bitmask;

    /* UE Paging Identity */
    ngap_ue_paging_identity_t               ue_paging_identity;

    /* Paging DRX */
    default_paging_drx_et                   paging_drx;

    /* TAI List for Paging */
    ngap_tai_list_for_paging_t              tai_list_for_paging;

    /* Paging Priority */
    ngap_paging_priority_et                 paging_priority;

    /* UE Radio Capability for Paging */
    ngap_ue_radio_capability_for_paging_t   ue_radio_capability_for_paging;

    /* Assistance Data for Paging */
    ngap_assistance_data_for_paging_t       assistance_data_for_paging;

    /* Paging Origin */
    ngap_paging_origin_et                   paging_origin;

} ngap_paging_t;

/*****************************************************************************
 * PDU SESSION RESOURCE SETUP REQUEST 
 ****************************************************************************/
typedef struct
{
#define PDU_SESSION_REQUEST_NGAP_RAN_PAGING_PRIORITY      0x01
#define PDU_SESSION_REQUEST_NGAP_NAS_PDU                  0x02
#define PDU_SESSION_REQUEST_UE_AGGREGATE_MAXIMUM_BITRATE  0x04

     UInt32                                          bitmask;
   
     /*AMF_UE_NGAP_ID */
     ngap_amf_ue_ngap_id_t                          amf_ue_ngap_id; 

   
     /*RAN_UE_NGAP_ID*/
     ngap_ran_ue_ngap_id_t                          ran_ue_ngap_id;
   
     /*RAN PAGING PRIORITY */
     ngap_ran_paging_priority_t                       ran_paging_priority;
        
     /*NAS PDU */
     ngap_dynamic_string_t                            nas_pdu;

     /*PDU SESSION RESOURCE SETUP LIST SU REQUEST */
     ngap_pdu_session_resource_setup_request_list_t   pdu_session_resource_setup_request_list;

     /*UE AGGREGATE MAXIMUM BITRATE */
     ngap_ue_aggregate_maximum_bit_rate_t             ue_aggregate_maximum_bit_rate;

}ngap_pdu_session_resource_setup_request_t;

/*****************************************************************************
 * PDU SESSION RESOURCE SETUP RESPONSE 
 ****************************************************************************/
typedef struct
{
#define NGAP_PDU_SESSION_RESOURCE_SETUP_LIST_SU_RES            0x01
#define NGAP_PDU_SESSION_RESOURCE_FAILED_TO_SETUP_LIST_SU_RES  0X02
#define NGAP_PDU_SESSION_RESOURCE_CRITICALITY_DIGNOSTICS       0x04


    UInt32                                           bitmask;

    /*AMF_UE_NGAP_ID */

    UInt64                                            amf_ue_ngap_id; 

    /*RAN_UE_NGAP_ID*/

    UInt64                                            ran_ue_ngap_id;

    /*PDU_SESSION_RESOURCE_SETUP_LIST_SU_RES */

    ngap_pdu_session_resource_setup_response_list_t   pdu_session_resource_setup_response_list;

    /*PDU_SESSION_RESOURCE_FAILED_TO SETUP_LIST_SU_LIST */

    ngap_pdu_session_resource_failed_to_setup_list_t  pdu_session_resource_failed_to_setup_list;

    /*CRITICALITY_DIAGNOSTICS */

    ngap_criticality_diagnostics_t                    criticality_diagnostics;          

}ngap_pdu_session_resource_setup_response_t;

typedef struct
{
#define NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE     4
#define NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_NUMBITS        32


    UInt8                                  start_time_stamp[NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE];

    UInt8                                  end_time_stamp[NGAP_PDU_SESSION_RESOURCE_REL_RES_TIME_STAMP_OCTET_SIZE];

    UInt64                                 usage_count_uplink;

    UInt64                                 usage_count_downlink;

}ngap_timed_report_list_item_t;

typedef struct
{
#define NGAP_MAX_NO_OF_TIME_REPORTING_PERIOD    2

    UInt8                           count;

    ngap_timed_report_list_item_t   timed_report_list_item[NGAP_MAX_NO_OF_TIME_REPORTING_PERIOD];
}ngap_timed_report_list;

typedef enum
{
    NR,
    E_UTRA
}ngap_rat_type_et;

typedef struct
{
    ngap_rat_type_et          rat_type;

    ngap_timed_report_list    timed_report;

}ngap_pdu_session_usage_report_t;

typedef struct
{
    UInt32   qos_flow_identifier;

}ngap_qos_flow_identifier_t;

typedef struct
{
    ngap_qos_flow_identifier_t  qos_flow_identifier;

    ngap_rat_type_et            rat_type;

    ngap_timed_report_list      timed_report;

}ngap_qos_flow_usage_report_item_t;

typedef struct
{
    UInt8                               count;

    ngap_qos_flow_usage_report_item_t   qos_flow_usage_report_item[NGAP_MAX_NO_OF_QOS_FLOWS];

}ngap_qos_flows_usage_report_list;


typedef struct
{
#define NGAP_PDU_SESSION_RESOURCE_RELEASE_PDU_SESSION_USAGE_REPORT_PRESENT  0x01

#define NGAP_PDU_SESSION_RESOURCE_RELEASE_QOS_FLOW_USAGE_REPORT_PRESENT     0x02

    UInt32                                  bitmask;

    ngap_pdu_session_usage_report_t         pdu_session_usage_report;

    ngap_qos_flows_usage_report_list        qos_flows_usage_report;

}ngap_secondary_rat_usage_information_t;

typedef struct
{
    ngap_secondary_rat_usage_information_t      secondary_rat_usage_information;

}ngap_pdu_session_resource_released_response_transfer_t;

typedef struct
{
    ngap_pdu_session_id_t                                        pdu_session_id;

    ngap_pdu_session_resource_released_response_transfer_t       pdu_session_resource_released_response_transfer;

}ngap_pdu_session_resource_released_response_item_t;

typedef struct
{
    UInt8                                               count;

    ngap_pdu_session_resource_released_response_item_t  pdu_session_resource_released_response[NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE];

}ngap_pdu_session_resource_release_response_list_t;

typedef struct
{
#define NGAP_PDU_SR_RELEASE_RESPONSE_USER_LOCATION_INFO_PRESENT 0x01
#define NGAP_PDU_SR_RELEASE_RESPONSE_CRITICALITY_DIAGNOSTICS_PRESENT 0x02

    UInt32                                                 bitmask;

    /*AMF_UE_NGAP_ID */

    UInt64                                                  amf_ue_ngap_id;


    /*RAN_UE_NGAP_ID*/

    UInt32                                                ran_ue_ngap_id;

    /*PDU Session Resource Released List Rel  Res */

    ngap_pdu_session_resource_release_response_list_t      pdu_session_resource_release_response;

    /*User Location Information */

    ngap_choice_user_location_information_t                choice_user_location_information;


    /*Criticality Diagnostics */

    ngap_criticality_diagnostics_t                         criticality_diagnostics;


}ngap_pdu_session_resource_release_response_t;

typedef struct
{
    ngap_choice_cause_group_t       choice_cause_group;

}ngap_pdu_session_resource_release_command_transfer_t;

typedef struct
{
    ngap_pdu_session_id_t   pdu_session_id;

    ngap_pdu_session_resource_release_command_transfer_t
        pdu_session_res_to_rel_command_transfer;

}pdu_session_resource_to_release_item_t;

typedef struct
{
    UInt8                                       count;

    pdu_session_resource_to_release_item_t      pdu_session_res_to_rel_list_release_cmd_item[NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE];

}ngap_pdu_session_resource_to_release_list_rel_cmd_t;

typedef struct
{
#define PDU_SESSION_RELEASE_COMMAND_RAN_PAGING_PRIORITY  0x02
#define PDU_SESSION_RELEASE_COMMAND_NAS_PDU              0x03

    UInt32                                                 bitmask;

    /*AMF_UE_NGAP_ID */
    UInt64                                                 amf_ue_ngap_id;

    /*RAN_UE_NGAP_ID*/
    UInt32                                                 ran_ue_ngap_id;

    /*RAN PAGING PRIORITY */
    ngap_ran_paging_priority_t                             ran_paging_priority;

    /*NAS PDU */
    ngap_dynamic_string_t                                  nas_pdu;

    /*PDU SESSION RESOURCE TO RELEASE LIST RELEASE COMMAND */
    ngap_pdu_session_resource_to_release_list_rel_cmd_t    pdu_session_resource_to_release_list_rel_cmd;

}ngap_pdu_session_resource_release_command_t;


/*******************************************************************************
 * RRC_INACTIVE_TRANSITION_REPORT_REQUEST
 ******************************************************************************/
typedef enum
{
    NGAP_HO_SUBSEQUENT_STATE_TRANSITION_REPORT,
    NGAP_HO_SINGLE_RRC_CONNECTED_STATE_REPORT,
    NGAP_CANCEL_REPORT

}ngap_rrc_inactive_transition_report_req_et;

/*******************************************************************************
 *PDU SESSION RESOURCE SETUP LIST HANDOVER REQUEST ITEM
 ******************************************************************************/
typedef struct
{
    UInt8                pdu_session_id;

    ngap_s_nssai_t       s_nssai;

    ngap_pdu_session_resource_setup_request_transfer_list_t  handover_req_transfer;//HandOver changes

}ngap_pdu_session_res_setup_list_HO_req_item_t;

/*******************************************************************************
 *PDU SESSION RESOURCE SETUP LIST HANDOVER REQUEST
 ******************************************************************************/
typedef struct
{
    UInt8                                           count;

    ngap_pdu_session_res_setup_list_HO_req_item_t
                       pdu_session_res_setup_list_HO_req_item[NGAP_MAX_NO_OF_PDU_SESSION];

}ngap_pdu_session_res_setup_list_HO_req_t;

/*******************************************************************************
 *NEW SECURITY CONTEXT IND
 ******************************************************************************/
typedef enum
{
   NGAP_SECURITY_CTX_NGAP_TRUE

}ngap_new_security_ctx_ind_et;

/*******************************************************************************
 *SECURITY CONTEXT
 ******************************************************************************/
typedef struct
{

    UInt8               next_hop_chaining_count;

    ngap_security_key_t  next_hop_nh;//HandOver changes

}ngap_security_context_t;

/*******************************************************************************
 * HANDOVER TYPE ENUM
 ******************************************************************************/
typedef enum
{
    NGAP_INTRA5GS,
    NGAP_FIVEGS_TO_EPS,
    NGAP_EPS_TO_5GS

}ngap_handover_type_et;
/*Handover_changes_start*/

/*************************NGAP_CELL_SIZE*********************************/

/*****************************************************************************
 * NGAP_Last_Visited_NGRAN_Cell_Information
 * ***************************************************************************/

typedef struct{
#define TIME_UE_STAYED_IN_CELL_ENCHANCED_GRANULARITY 0x01
#define HO_CAUSE_VALUE                               0x02

    UInt8                           bitmask;

    ngap_ng_ran_cgi_t               global_cell_id;

    nr_cell_type_et                 cell_type;

    UInt16                          time_ue_stayed_in_cell;

    UInt16                          time_ue_stayed_in_cell_enchanced_granularity;

    ngap_choice_cause_group_t       handover_cause_value;   

}ngap_last_visited_ngran_cell_information_t;


/******************************************************************************
 * NGAP_LAST_VISITED_CELL_INFORMATION
 * ****************************************************************************/

typedef struct{

#define ngap_LastVisitedCellInformation_nGRANCell   1    
#define ngap_LastVisitedCellInformation_eUTRANCell  2
#define ngap_LastVisitedCellInformation_uTRANCell   3
#define ngap_LastVisitedCellInformation_gERANCell   4

    UInt8                                            choice_type;

    ngap_last_visited_ngran_cell_information_t       ng_ran_cell;

    // ngap_last_visited_eutran_cell_information_t      eut_ran_cell;

    // ngap_last_visited_utran_cell_information_t       ut_ran_cell;

    // ngap_last_visited_geran_cell_information_t       ge_ran_cell;

}ngap_last_visited_cell_information_t;

/******************************************************************************
 * NGAP_UE_History_Information_Item
 * ****************************************************************************/

typedef struct{

    ngap_last_visited_cell_information_t    last_visited_cell_information;

}ngap_ue_history_information_item_t;

/*******************************************************************************
 * NGAP_UE_HISTORY_INFORMATION_LIST
 * ****************************************************************************/

typedef struct{
#define MAXIMUM_CELL_IN_UE_HISTORY_INFORMATION  16

    UInt8                                     count;

    ngap_ue_history_information_item_t        ue_history_information_item[MAXIMUM_CELL_IN_UE_HISTORY_INFORMATION];

}ngap_ue_history_information_list_t;


/************************NGAP_DL_FORWARDING_ET**********************************/

typedef enum{
    NGAP_DL_FORWARDING_PROPOSED
}nagap_dl_forwarding_et;
/******************************NGAP_UL_FORWARDING_ET******************************/

typedef enum{
    NGAP_UL_FORWARDING_PROPOSED
}nagap_ul_forwarding_et;

/*******************************************************************************
 * NGAP_QOS_FLOW_INFORAMATION_ITEM
 * *****************************************************************************/

typedef struct{

#define NGAP_DL_FORWARDING      0x01
#define NGAP_UL_FORWARDING      0x02
    
    UInt8                     bitmask;

    UInt8                     qos_flow_identifier; 

    nagap_dl_forwarding_et    dl_forwarding;

    nagap_ul_forwarding_et    ul_forwarding;

}ngap_qos_flow_information_item_t;

/*******************************************************************************
 * NGAP_QOS_FLOW_INFORAMATION_LIST
 * *****************************************************************************/

typedef struct{

    UInt8                              count;


    ngap_qos_flow_information_item_t   qos_flow_information_item[NGAP_MAX_NO_OF_QOS_FLOWS];

}ngap_qos_flow_information_list_t;

/********************************************************************************
 * NGAP_DRB_TO_QOS_FLOW_MAPPING_ITEM
 * ******************************************************************************/

typedef struct{

    UInt8                          drb_id;

    ngap_associated_flow_list_t    associated_qos_flow_list;

}ngap_drb_to_qos_flow_mapping_item_t;

/********************************************************************************
 * NGAP_DRB_TO_QOS_FLOW_MAPPING_LIST
 * ******************************************************************************/

typedef struct{

    UInt8                                 count;

    ngap_drb_to_qos_flow_mapping_item_t   drb_to_qos_flow_mapping_item[MAX_DRB];

}ngap_drb_to_qos_flow_mapping_list_t;

/********************************************************************************
 * NGAP_PDU_SESSION_RESOURCE_INFORMATION_ITEM
 ********************************************************************************/

typedef struct{
 
#define NGAP_DRB_TO_QOS_FLOW_MAPPING_LIST   0X01

    UInt8                                bitmask;

    ngap_pdu_session_id_t                pdu_session_id;

    ngap_qos_flow_information_list_t     qos_flow_info_list;

    ngap_drb_to_qos_flow_mapping_list_t  drb_to_qos_flow_mapping_list;

}ngap_pdu_session_resource_info_item_t;



/********************************************************************************
 *  NGAP_PDU_SESSION_RESOURCE_INFORMATION_LIST
 * *****************************************************************************/
typedef struct{

    UInt8                                  count;

    ngap_pdu_session_resource_info_item_t  pdu_session_resource_info_item[NGAP_MAX_NO_OF_PDU_SESSION];

}ngap_pdu_session_resource_info_list_t;

#if 0
/****************************************************************************
 *NGAP_E_RAB_INFORMATION_ITEM
 * **************************************************************************/

typedef struct{

    UInt8                     e_rab_id;

    nagap_dl_forwarding_et    dl_forwarding;

}ngap_e_rab_information_item_t;

/*****************************************************************************
 *  NGAP_E_RAB_INFORAMTION_LIST
 * ***************************************************************************/

typedef struct{
#define NGAP_MAX_NO_E_RAB  256

    UInt8                              count;

    ngap_e_rab_information_item_t      e_rab_information_item[NGAP_MAX_NO_E_RAB];

}ngap_e_rab_information_list_t;

#endif

/*******************************************************************************
 *  SourceNGRANNode_ToTargetNGRANNode_TransparentContainer
 * *****************************************************************************/

typedef struct{

#define NGAP_PDU_SESSION_RESOURCE_INFORAMTION_LIST  0X01
#define NGAP_E_RAB_INFORMATION_LIST                 0X02
#define NGAP_INDEX_TO_RFSP                          0X04

    UInt8                                    bitmask;

    ngap_dynamic_string_t                    rrc_container;

    ngap_pdu_session_resource_info_list_t    pdu_session_resource_info_list;

    /* For inter-system handovers to 5G - currently not in use*/

    /*ngap_e_rab_information_list_t          e_rab_information_list;*/

    ngap_ng_ran_cgi_t                        target_cell_id;/*pre_define*/

    UInt16                                   index_to_rfsp;

    ngap_ue_history_information_list_t       ue_history_information;

}ngap_src_ngran_to_target_ngran_trans_container_t;

/*******************************************************************************
 *                  Source To Target-Transparent Container 
 * *****************************************************************************/

typedef struct{

    ngap_src_ngran_to_target_ngran_trans_container_t    src_to_trg_ngran_container;

}ngap_src_to_target_transparent_container_t;
/*Handover_changes_end*/
/*******************************************************************************
 * HANDOVER REQUEST
 ******************************************************************************/
typedef struct
{
#define NGAP_HANDOVER_REQUEST_CORE_NETWORK_ASSISTANCE_INFO_PRESENT          0x01
#define NGAP_HANDOVER_REQUEST_NEW_SECURITY_CONTEXT_IND_PRESENT              0x02
#define NGAP_HANDOVER_REQUEST_NAS_PDU_PRESENT                               0x04
#define NGAP_HANDOVER_REQUEST_TRACE_ACIVATION_PRESENT                       0x08
#define NGAP_HANDOVER_REQUEST_MASKED_IMEISV_PRESENT                         0x10
#define NGAP_HANDOVER_REQUEST_MOBILITY_RESTRICTION_LIST_PRESENT             0x20
#define NGAP_HANDOVER_REQUEST_LOCATION_REPORTING_REQ_TYPE_PRESENT           0x40
#define NGAP_HANDOVER_REQUEST_RRC_INACTIVE_TRANSITION_REPORT_REQ_PRESENT    0x80
#define NGAP_HANDOVER_REQUEST_REDIRECTION_VOICE_FALLBACK_PRESENT            0x100
#define NGAP_HANDOVER_CN_ASSISTED_RAN_TUNING_PRESENT                        0x200//HandOver chang
    UInt16                                                      bitmask;

    ngap_amf_ue_ngap_id_t                                       amf_ue_ngap_id;

    ngap_handover_type_et                                       handover_type;

    ngap_choice_cause_group_t                                   choice_cause;

    ngap_ue_aggregate_maximum_bit_rate_t                        ue_aggregate_maximum_bit_rate;

    ngap_core_network_assistance_info_for_inactive_t            core_network_assistance_info;

    ngap_ue_security_capabilities_t                             ue_security_capabilities;

    ngap_security_context_t                                     security_context;

    ngap_new_security_ctx_ind_et                                new_security_ctx_ind;

    ngap_dynamic_string_t                                       nas_pdu;

    ngap_pdu_session_res_setup_list_HO_req_t                    pdu_session_res_setup_list_HO_req;

    ngap_allowed_nssai_list_t                                   allowed_nssai_list;

    ngap_trace_activation_t                                     trace_activation;

    ngap_masked_imeisv_t                                        masked_imeisv;

    ngap_src_to_target_transparent_container_t                 src_to_trg_transparent_container;/*Handover_changes*/

    ngap_mobility_restriction_list_t                            mobility_restriction_list;//HandOver_changes

    ngap_location_reporting_req_type_t                          location_reposrting_req_type;

    ngap_rrc_inactive_transition_report_req_et                  rrc_inactive_transition_report_req_t;

    ngap_guami_t                                                guami;

    ngap_redirection_voice_fallback_et                          redirection_voice_fallback;

    ngap_CNAssisted_ran_tuning_t                                cn_assisted_ran_tuning;//HandOver changes

}ngap_handover_request_t;


/*handover_changes*/

/*****************************************************************************
 * HANDOVER PREPARATION FAILURE
 ****************************************************************************/

typedef struct
{
#define NGAP_HANDOVER_PREPRATON_FAILURE_CRITICALITY_DIGNOSTICS 0X02

    UInt32                                     bitmask;
    /*AMF_UE_NGAP_ID */
    ngap_amf_ue_ngap_id_t                      amf_ue_ngap_id;

    /*RAN_UE_NGAP_ID*/
    ngap_ran_ue_ngap_id_t                      ran_ue_ngap_id;

    /*cause*/
    ngap_choice_cause_group_t                  cause;

    /*critically dignostcic */

    ngap_criticality_diagnostics_t             critically_dignostics;

}ngap_handover_preparation_failure_t;
/*HandOver_changes_start*/

/*****************************************************************************
 *          HANDOVER PREPARATION UNCESSFUL TRANSFER
 * ***************************************************************************/

typedef struct
{
     ngap_choice_cause_group_t    id_cause; 

}ngap_ho_preparation_unsuccessful_transfer_t;

/*HandOver_changes_end */

/*****************************************************************************
 * HANDOVER COMMAND PDU SESSION RES TO RELEASE ITEM HO COMMAND LIST
 ****************************************************************************/
typedef struct
{
    ngap_pdu_session_id_t            pdu_session_id;

    ngap_ho_preparation_unsuccessful_transfer_t   handover_prep_unsuccess_transfer;//HandOver changes

}ngap_pdu_session_res_to_rel_item_ho_cmd_list_t;

/*****************************************************************************
 * HANDOVER COMMAND PDU SESSION RES TO RELEASE ITEM HO LIST
 ****************************************************************************/

typedef struct
{
    UInt8                                               count;

    ngap_pdu_session_res_to_rel_item_ho_cmd_list_t  
        pdu_session_res_to_rel_item_ho_cmd_list[NGAP_MAX_NO_OF_PDU_SESSION];

}ngap_pdu_session_res_to_rel_list_ho_cmd_t;

typedef struct{
    UInt32                      qos_flow_identifier; 
}ngap_qos_flow_fwd_item_t;

typedef struct{
    UInt8                           count;

    ngap_qos_flow_fwd_item_t        qos_flow_usage_report_item[NGAP_MAX_NO_OF_QOS_FLOWS];
}ngap_qos_flow_to_be_fwd_list_t;

typedef struct{
#define NGAP_DL_FWDING_UP_TUNNEL_INFO_PRESENT   0x01
#define NGAP_UL_FWDING_UP_TUNNEL_INFO_PRESENT   0x02
    UInt8                                       bitmask;

    UInt8                                       drb_id;

    ngap_up_transport_layer_information_t       dl_fwding_up_tunnel_info;
    
    ngap_up_transport_layer_information_t       ul_fwding_up_tunnel_info;
}nagp_data_fwding_response_drb_item_t;

typedef struct{
    UInt8                                   count;

    nagp_data_fwding_response_drb_item_t    data_fwding_resp_drb_item[MAX_DRB]; 

}nagp_data_fwding_response_drb_list_t;

typedef struct{
#define NGAP_HO_COMMAND_TRANSFER_DL_FWDING_UP_TUNNEL_INFO_PRESENT       0x01
#define NGAP_HO_COMMAND_TRANSFER_QOS_FLOW_FORWARD_LIST_PRESENT          0x02
#define NGAP_HO_COMMAND_TRANSFER_DATA_FWDING_RESP_DRB_LIST_PRESENT      0x04
#define NGAP_HO_COMMAND_TRANSFER_ADD_DL_FWDING_UP_TUNNEL_INFO_PRESENT   0x08
#define NGAP_HO_COMMAND_TRANSFER_UL_FWDING_UP_TUNNEL_INFO_PRESENT       0x10

    UInt32                                      bitmask;

    ngap_up_transport_layer_information_t       dl_fwding_up_tunnel_info;

    ngap_qos_flow_to_be_fwd_list_t              qos_flow_fwd_list;

    nagp_data_fwding_response_drb_list_t        data_fwding_resp_drb_list;

    ngap_dl_qos_flow_per_TNL_info_list_t        additional_dl_fwding_up_tunnel_info;

    ngap_up_transport_layer_information_t       ul_fwding_up_tunnel_info;
}ho_command_transfer_t;

/*****************************************************************************
 * HANDOVER COMMAND PDU SESSION RES HO ITEM LIST
 ****************************************************************************/
typedef struct
{
    ngap_pdu_session_id_t            pdu_session_id;

    ho_command_transfer_t           handover_cmd_transfer;

}ngap_pdu_session_res_ho_item_list_t;


/*****************************************************************************
 * HANDOVER COMMAND PDU SESSION RES HO LIST
 ****************************************************************************/
typedef struct
{
    UInt8                                      count;

    ngap_pdu_session_res_ho_item_list_t pdu_session_res_ho_item_list[NGAP_MAX_NO_OF_PDU_SESSION];

}ngap_pdu_session_res_ho_list_t;

/*Handover_changes_start*/
typedef struct{
    ngap_dynamic_string_t   rrc_container;
}ngap_trg_ngran_to_src_ngran_transparent_container_t;
/*Handover_changes_end*/

/*****************************************************************************
 * HANDOVER COMMAND
 ****************************************************************************/

typedef struct
{
#define HANDOVER_COMMAND_PDU_SESSION_RESOURCE_TO_RELEASE_LIST_HO_CMD  0X01
#define HANDOVER_COMMAND_CRITICALITY_DIGNOSTICS                       0X02

    UInt32                                    bitmask;

    /*AMF-UE-NGAP-ID*/
    ngap_amf_ue_ngap_id_t                      amf_ue_ngap_id;

    /*RAN-UE-NGAP-ID */
    ngap_ran_ue_ngap_id_t                      ran_ue_ngap_id;

    /* HANDOVER TYPE */
    ngap_handover_type_et                     handover_type;

    /*NAS Security Parameters From NGRAN */
    ngap_dynamic_string_t                      nas_sec_param_from_ngran;

    /* PDU Session Resource Handover List*/
    ngap_pdu_session_res_ho_list_t             pdu_session_ho_list;

    /*PDU Session Resource To Release List HO Cmd */
    ngap_pdu_session_res_to_rel_list_ho_cmd_t  pdu_session_res_to_rel_list_ho_cmd;

    /*target_to_source_transparent_container */
    ngap_trg_ngran_to_src_ngran_transparent_container_t   trg_to_src_transparent_container;//Handover_changes

    /*critically dignostcic*/
    ngap_criticality_diagnostics_t              critically_dignostic;

}ngap_handover_command_t;


/*****************************************************************************
 * NGAP HANDOVER EPS TAI  ID
 ****************************************************************************/
typedef struct
{
#define NGAP_HANDOVER_REQUIRED_EPS_TAC_DATA 2

    ngap_plmn_identity_t    pLMNIdentity;

    UInt8                   ePS_TAC[NGAP_HANDOVER_REQUIRED_EPS_TAC_DATA];

}ngap_eps_tai_t;


/*****************************************************************************
 * NGAP HANDOVER TARGET ENB  ID
 ****************************************************************************/
typedef struct
{
    global_ng_enb_id_t                   globalENB_ID;

    ngap_eps_tai_t                       selected_eps_tai;

}ngap_target_enb_id_t;

/*****************************************************************************
 * NGAP HANDOVER TARGET RAN_NODE ID
 ****************************************************************************/
typedef struct
{
    ngap_global_ran_node_id_t            global_ran_node_id;

    ngap_tai_t                           selected_tai;

}ngap_target_ran_node_id_t;

/*******************************************************************************
 * NGAP HANDOVER TARGET ID
 ******************************************************************************/
typedef struct{
#define T_ngap_TargetID_targetRANNodeID 1
#define T_ngap_TargetID_targeteNB_ID    2
/*Handover bug fixes*/
    UInt32                              choice_type;

    ngap_target_ran_node_id_t            target_ran_node_id;

    ngap_target_enb_id_t                 targeteNB_ID;
}ngap_target_id_t;

/*******************************************************************************
 * NGAP DIRECT FORWARDING PATH AVAILABILITY
 ******************************************************************************/

typedef enum
{
    NGAP_HANDOVER_REQUIRED_DIRECT_PATH_AVAILABLE
}ngap_DirectForwardingPathAvailability_et;

typedef struct {
#define HO_RQD_TRANSFER_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT 0x01
    UInt32                                      bitmask;

    ngap_DirectForwardingPathAvailability_et    direct_fwding_path_avail;
    /*^ O, HO_RQD_TRANSFER_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT, N, 0, 0 ^*/

}ho_required_transfer_t;

/*****************************************************************************
 * NGAP HANDOVER PDU SESSION RESOURCE LIST HO REQUIRED ITEM
 ****************************************************************************/

typedef struct
{
    ngap_pdu_session_id_t        pdu_session_id;

    ho_required_transfer_t      handover_rqd_transfer;

}ngap_pdu_session_res_list_HO_rqd_item_t;


/*****************************************************************************
 * NGAP HANDOVER PDU SESSION RESOURCE LIST
 ****************************************************************************/

typedef struct
{
    UInt8           count;

    ngap_pdu_session_res_list_HO_rqd_item_t     
        pdu_session_res_list_HO_rqd_item[NGAP_MAX_NO_OF_PDU_SESSION];
}ngap_pdu_session_res_list_HO_rqd_t;

/*****************************************************************************
 * HANDOVER REQUIRED
 ****************************************************************************/
typedef struct
{
#define HO_REQUIRED_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT 0x01

    UInt32                                    bitmask;
    
    /* AMF-UE-NGAP-ID*/
    ngap_amf_ue_ngap_id_t                     amf_ue_ngap_id;

    /*RAN-UE-NGAP-ID*/
    ngap_ran_ue_ngap_id_t                     ran_ue_ngap_id;

    /*HandoverType */
    ngap_handover_type_et                     handover_type;

    /* id-Cause*/
    ngap_choice_cause_group_t                 id_cause;

    /* target_id */
    ngap_target_id_t                           target_id;

    /*Direct Forwarding Path Availability */
    ngap_DirectForwardingPathAvailability_et  direct_forwarding_path_availability;
    /*^ O, HO_REQUIRED_DIRECT_FORWARDING_PATH_AVAILABILITY_PRESENT, N, 0, 0 ^*/

    /*PDU Session Resource List HO Rqd */
    ngap_pdu_session_res_list_HO_rqd_t        pdu_session_res_list_HO_rqd_list;

    /*Source To Target-Transparent Container */
    ngap_src_to_target_transparent_container_t  src_to_trg_transparent_container;/*Measurement*/ /*Handover_changes*/

}ngap_handover_required_t;


/*HandOver_changes_start*/

/******************************************************************************
 *                      NGAP DATA FORWARDING ACCEPTED
 * ****************************************************************************/

typedef enum
{
    NGAP_DATA_FORWARDING_ACCEPTED

}ngap_data_forwarding_accepted_et;

/*********************************************************************************
 *                      NGAP QOS FLOW ITEM WITH DATA FORWARDING
 * ********************************************************************************/

typedef struct
{
    #define HO_REQ_ACK_TRANSFER_DATA_DORWARDING_ACCEPT 0x01

    UInt32                                    bitmask;

    ngap_qos_flow_fwd_item_t                qos_flow_identifier;

    ngap_data_forwarding_accepted_et        data_forwading_accepted;

}ngap_qos_flow_item_with_data_forwarding;
/**********************************************************************************
 *                      NGAP QOS FLOW LIST WITH DATA FORWARDING
 * ********************************************************************************/

typedef struct
{
        UInt8                                       count;

        ngap_qos_flow_item_with_data_forwarding     qos_flow_item_with_data_forwading[NGAP_MAX_NO_OF_QOS_FLOWS];
 
}ngap_qos_flow_list_with_data_forwarding;

/********************************************************************************
 *              ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_LIST_ITEM
 * ******************************************************************************/
typedef struct
{
#define ADDITIONAL_DL_FORWARDING_UP_TNL_INFORMATION         0x01
    
    UInt32                                                  bitmask;

    ngap_up_transport_layer_information_t                   up_transport_layer_information;

    ngap_qos_flow_list_with_data_forwarding                 qos_flow_list_with_data_forwarding;

    ngap_up_transport_layer_information_t                   additional_dl_forwarding_up_tnl_information;

}ngap_additional_dl_up_tnl_info_for_ho_list_item;


/*********************************************************************************
 *                      ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_LIST
 *********************************************************************************/
typedef struct
{
   #define HO_REQ_ACK_ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_ITEM                     0X01
   #define HO_REQ_ACK_TRANSFER_UP_TRANSPORT_LAYER_INFORMATION                   0X02
   #define MAXIMUM_NO_OF_CONNECTIVITY_FOR_A_UE_MINUS_ONE    3

   UInt8                bitmask;
   UInt8                count;

   ngap_additional_dl_up_tnl_info_for_ho_list_item     additional_dl_up_tnl_info_for_ho_list_item[MAXIMUM_NO_OF_CONNECTIVITY_FOR_A_UE_MINUS_ONE];//different

   ngap_up_transport_layer_information_t               up_transport_layer_information;
}ngap_additional_dl_up_tnl_info_for_ho_list_t;

/*********************************************************************************
 *                      NGAP HANDOVER REQUEST ACKNOWLEDGE TRANSFER
 * *******************************************************************************/

typedef struct
{
#define HO_REQ_ACK_DL_FORWARDING_UP_TNL_INFORMATION_PRESENT    0x01
#define HO_REQ_ACK_SECURITY_RESULT_PRESENT                     0x02
#define HO_REQ_ACK_QOS_FLOW_FAILED_TO_SETUP_LIST_PRESENT       0x04
#define HO_REQ_ACK_DATA_FORWARDING_RESPONSE_DRB_LIST_PRESENT   0x08
#define HO_REQ_ACK_ADDITIONAL_DL_UP_TNL_INFO_FOR_HO_LIST       0x10

    UInt32                                        bitmask;
                            
    ngap_up_transport_layer_information_t         dl_ngu_up_tnl_information;

    ngap_up_transport_layer_information_t         dl_forwarding_up_tnl_information;

    ngap_security_result_t                        security_result;

    ngap_qos_flow_list_with_data_forwarding       qos_flow_setup_response_list;//different

    ngap_qos_flow_list_t                          qos_flow_failed_to_setup_list;

    nagp_data_fwding_response_drb_list_t          data_forwarding_response_drb_list;

    //ngap_additional_dl_up_tnl_info_for_ho_list_t  additional_dl_up_tnl_info_for_ho_list;//new

}ngap_ho_request_acknowledge_transfer_t;

/*HandOver_changes_end*/

/*****************************************************************************
 * NGAP PDU SESSION RES ADMITTED ITEM HO REQ ACK 
 ****************************************************************************/
typedef struct {
    ngap_pdu_session_id_t       pdu_session_id;

    ngap_ho_request_acknowledge_transfer_t       ho_request_ack_transfer;  //HandOver changes in data type
}ngap_ho_req_ack_pdu_session_res_adm_item_t;

/*****************************************************************************
 * NGAP PDU SESSION RES ADMITTED LIST HO REQ ACK 
 ****************************************************************************/
typedef struct {
    UInt8           count;

    ngap_ho_req_ack_pdu_session_res_adm_item_t 
        pdu_session_res_adm_item[NGAP_MAX_NO_OF_PDU_SESSION];
}ngap_ho_req_ack_pdu_session_res_adm_list_t;
/*HandOver_changes_start */
/*******************************************************************************
 *              NGAP HANDOVER RESOURCE ALLOCATION UNSUCCESSFUL TRANSFER
 * ******************************************************************************/

typedef struct
{
#define HO_RESOURCE_ALLOCATION_UNSUCCESSFUL_TRANSFER_CRITICALITY_DIGNOSTICS   0X01

    UInt32                                      bitmask;
   
    ngap_choice_cause_group_t                   choice_cause_group;

    ngap_criticality_diagnostics_t              criticality_dignostics;

}ngap_ho_resource_allocation_unsuccessful_transfer_t;

/*****************************************************************************
 * NGAP PDU SESSION RES FAILED ITEM HO REQ ACK 
 ****************************************************************************/
typedef struct {
    ngap_pdu_session_id_t       pdu_session_id;

    ngap_ho_resource_allocation_unsuccessful_transfer_t   ho_res_alloc_unsuccessful_transfer; //HandOver changes 
}ngap_ho_req_ack_pdu_session_res_fail_item_t;


/*HandOver_changes_end*/
/*****************************************************************************
 * NGAP PDU SESSION RES FAILED LIST HO REQ ACK 
 ****************************************************************************/
typedef struct {
    UInt8           count;

    ngap_ho_req_ack_pdu_session_res_fail_item_t
        pdu_session_res_failed_item[NGAP_MAX_NO_OF_PDU_SESSION];
}ngap_ho_req_ack_pdu_session_res_fail_list_t;

/*****************************************************************************
 * HANDOVER REQUEST ACKNOWLEDGE
 ****************************************************************************/
typedef struct {
#define HO_REQ_ACK_PDU_SESSION_FAILED_TO_SETUP_LIST_PRESENT 0x01
#define HO_REQ_ACK_CRITICAL_DIAGNOSTICS_PRESENT             0x02

    UInt32                                      bitmask;

    ngap_amf_ue_ngap_id_t                       amf_ue_ngap_id;

    ngap_ran_ue_ngap_id_t                       ran_ue_ngap_id;

    ngap_ho_req_ack_pdu_session_res_adm_list_t  ho_req_ack_pdu_session_res_adm_list;//list has been updated

    ngap_ho_req_ack_pdu_session_res_fail_list_t ho_req_ack_pdu_session_res_fail_list; //list has been updated
    /*^ O, HO_REQ_ACK_PDU_SESSION_FAILED_TO_SETUP_LIST_PRESENT , N, 0, 0 ^*/

    ngap_trg_ngran_to_src_ngran_transparent_container_t  trg_to_src_transparent_container;//Handover_changes
    
    ngap_criticality_diagnostics_t             criticality_diagnostics; //HandOver changes 
    /*^ O, HO_REQ_ACK_CRITICAL_DIAGNOSTICS_PRESENT , N, 0, 0 ^*/
}ngap_handover_req_ack_t;

/*****************************************************************************
 * HANDOVER FAILURE 
 ****************************************************************************/
typedef struct {
#define HO_FAILURE_CRITICAL_DIAGNOSTICS_PRESENT 0x01
    UInt32                                      bitmask;

    ngap_amf_ue_ngap_id_t                       amf_ue_ngap_id;

    ngap_choice_cause_group_t                   choice_cause_group;

    ngap_criticality_diagnostics_t              criticality_diagnostics; //HandOver changes
    /*^ O, HO_FAILURE_CRITICAL_DIAGNOSTICS_PRESENT, N, 0, 0 ^*/
}ngap_handover_failure_t;

/*****************************************************************************
 * HANDOVER NOTIFY 
 ****************************************************************************/
typedef struct {
    ngap_amf_ue_ngap_id_t                       amf_ue_ngap_id;

    ngap_ran_ue_ngap_id_t                       ran_ue_ngap_id;
    
    ngap_choice_user_location_information_t     choice_user_location_information;
}ngap_handover_notify_t;


/*****************************************************************************
 * HANDOVER CANCEL 
 ****************************************************************************/
typedef struct {
    ngap_amf_ue_ngap_id_t                       amf_ue_ngap_id;

    ngap_ran_ue_ngap_id_t                       ran_ue_ngap_id;
    
    ngap_choice_cause_group_t                   choice_cause_group;
}ngap_handover_cancel_t;


/*****************************************************************************
 * HANDOVER CANCEL ACKNOWLEDGE 
 ****************************************************************************/
typedef struct {
#define HO_CANCEL_ACK_CRITICAL_DIAGNOSTICS_PRESENT  0x01
    UInt32                                      bitmask;

    ngap_amf_ue_ngap_id_t                       amf_ue_ngap_id;

    ngap_ran_ue_ngap_id_t                       ran_ue_ngap_id;
    
    ngap_criticality_diagnostics_t              criticality_diagnostics;//HandOver changes
    /*^ O, HO_CANCEL_ACK_CRITICAL_DIAGNOSTICS_PRESENT, N, 0, 0 ^*/
}ngap_handover_cancel_ack_t;

/*handover_changes*/

/****************************************************************************
 * SERVED_CELL_INFO_LIST
 ***************************************************************************/

/* Served Cell Information */
typedef struct served_cell_information
{
    /* cell index */
    cell_index_t                       cell_index;

    /* TAC - to be present if is_du_deleted==FALSE */
    UInt8                              tac[NGAP_TAC_OCTET_SIZE];

    /* Broadcast PLMN List
    *  F1AP specification defined upto 6 Broadcast PLMN.
    *  Present if is_du_deleted==FALSE */
    ngap_broadcast_plmn_list_t         broadcast_plmn_list;

    /* NR CGI */
    ngap_nr_cgi_t                      nr_cgi;

} served_cell_information_t;

typedef struct
{
    /* Count of Served Cell Information */
    UInt8                             cell_count;

    /* Cell Information */
    served_cell_information_t         served_cell_info[MAX_NUM_SUPPORTED_PLMN_LIST];

} served_cell_information_list_t;

#endif /* _NGAP_INTF_MGMNT_H_ */
