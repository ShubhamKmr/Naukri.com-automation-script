/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_asn_dec_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ***************************************************************************/
#ifndef _NGAP_ASN_DEC_WRAPPER_H_
#define _NGAP_ASN_DEC_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include "ngap_asn_enc_dec_3gpp.h"
#include "rrc_defines.h"
#include "rtxsrc/rtxCommon.h"
#include "ngap_intf_mgmnt.h"
#include "ngap_asn_common_wrapper.h"

#ifdef AMF_SIM_TESTING_ENABLE
#include "ngap_types.h"
#else
#include "ngap_global_ctx.h"
#endif
#define NGAP_IE_PRESENT         1

typedef enum
{
    OCCURANCE,
    INVALID_VALUE,
    WRONG_ORDER,
    DATA_MISSING
} ngap_map_updation_const_et;

typedef struct
{
    ngap_bool_et send_err_indication_reject_ie_present;
    ngap_bool_et send_err_indication_ignore_ie_present;
    ngap_bool_et send_err_indication_notify_ie_present;
} ngap_error_ind_bool_t;

typedef struct
{
    UInt8			        order_num;
    UInt16                  ie_id;
    ngap_Presence_Root   	presence;
    ngap_Criticality_Root   criticality;
    UInt8                   occurances;
    UInt8                   invalid_value_present;
    UInt8                   wrong_order;
    UInt8                   data_missing;

} ngap_message_map_t;

typedef struct
{
#define NGAP_MAX_IES_IN_MESSAGE     22 /* The maximum IEs in any one message is 19 */

    UInt8			    max_count;
    UInt8               successful_outcome_present;
    UInt8               unsuccessful_outcome_present;
    UInt16              bitmask;
    UInt32      	    amf_ue_ngap_id;
    UInt32      	    ran_ue_ngap_id;
    ngap_message_map_t  msg_map[NGAP_MAX_IES_IN_MESSAGE];

} ngap_message_data_t;

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

/* This function do ASN decoding of message NG SETUP REQUEST using information 
 * passed as argument. */

ngap_return_et ngap_decode_ng_setup_req
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_setup_request_t	*p_ng_setup_req	/* Output - Local Buffer */
);

ngap_return_et ng_setup_req_internal_dec
(
    OSCTXT			        *p_asn1_ctx,            /* Input: ASN1 Context to be used */
    ngap_NGSetupRequest     *p_asn_ng_setup_req,    /* Input: Received ASN Buffer */
    ngap_setup_request_t    *p_local_ng_setup_req   /* Output: Local Message Structure */
);

ngap_return_et ng_setup_resp_internal_dec
(
    OSCTXT                  *p_asn1_ctx,            /* Input: ASN1 Context to be used */
    ngap_NGSetupResponse    *p_asn_ng_setup_resp,   /* Input: Received ASN Buffer */
    ngap_setup_response_t   *p_local_ng_setup_resp  /* Output: Local Message Structure */
);

ngap_return_et ng_setup_failure_internal_dec
(
    OSCTXT                  *p_asn1_ctx,                /* Input: ASN1 Context to be used */
    ngap_NGSetupFailure     *p_asn_ng_setup_failure,    /* Input: Received ASN Buffer */
    ngap_setup_failure_t    *p_local_ng_setup_failure   /* Output: Local Message Structure */
);

ngap_return_et validate_and_fill_ie_value
(
    ngap_message_data_t *p_ie_order_map,
    UInt32              order_index,
    UInt16              id,
    void                *p_value,
    void                *p_local
);


ngap_return_et ngap_update_message_map
(
    ngap_message_data_t		    *p_ie_order_map,
    ngap_map_updation_const_et  update_type,
    UInt32                      order_index,
    UInt16                      id
);


void ngap_add_to_err_ind_ie_list
(
    ngap_criticality_diagnostics_ie_list_t  *p_ie_list,
    ngap_Criticality		                ie_criticality,
    ngap_ProtocolIE_ID                      ie_id,
    UInt16                                  *p_index,
    ngap_error_ind_bool_t                   *p_send_error_indication,
    ngap_bool_et                            is_missing
);

ngap_return_et parse_ngap_message_map
(
    OSCTXT			                        *p_asn1_ctx,
    ngap_message_data_t                     *p_msg_map,
    ngap_criticality_diagnostics_ie_list_t	*p_ie_list,
    UInt16                                  *p_index_to_update,
    ngap_error_ind_bool_t                   *p_send_error_indication,
    UInt8                                   proc_code,
    ngap_error_indication_t                 *p_error_indication
);


void fill_criticality_diagnostics_ie_list
(
    ngap_criticality_diagnostics_ie_list_t   *p_err_ind_ie_list,
    ngap_criticality_diagnostics_ie_list_t   *p_ie_list
);

ngap_map_updation_const_et validate_and_fill_global_ran_node_id
(
    ngap_GlobalRANNodeID        *p_gb_ran_node_id, /* ASN Buffer */
    ngap_global_ran_node_id_t   *p_local           /* Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_choice_cause_group
(                                                          
    ngap_Cause                  *p_cause,/* ASN Buffer */
    ngap_choice_cause_group_t   *p_local /* Local Buffer */
);  

ngap_map_updation_const_et validate_and_fill_criticality_diagnostics 
(
    ngap_CriticalityDiagnostics      *p_value, /* ASN Buffer */
    ngap_criticality_diagnostics_t   *p_local  /* Local Buffer */
);

ngap_map_updation_const_et  validate_and_fill_served_guami_list
(
    ngap_ServedGUAMIList        *p_value,/* ASN Buffer */
    ngap_served_guami_list_t    *p_local /* Local Buffer */
);

ngap_map_updation_const_et  validate_and_fill_supported_ta_list
(
    ngap_SupportedTAList        *p_value, /* ASN Buffer */ 
    ngap_supported_ta_list_t    *p_local  /* Local Buffer */
);

ngap_map_updation_const_et  validate_and_fill_broadcast_plmn_list
(
    ngap_BroadcastPLMNList      *p_value, /* ASN Buffer */ 
    ngap_broadcast_plmn_list_t  *p_local  /* Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_broadcast_tnl_association_to_add_list 
(
    ngap_AMF_TNLAssociationToAddList      *p_value, /* ASN Buffer */ 
    amf_tnl_association_to_add_list_t     *p_local  /* Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_tnl_association_to_remove_list 
(
    ngap_AMF_TNLAssociationToRemoveList   *p_value, /* ASN Buffer */ 
    amf_tnl_association_remove_list_t     *p_local  /* Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_broadcast_tnl_association_to_update_list 
(
    ngap_AMF_TNLAssociationToUpdateList   *p_value, /* ASN Buffer */ 
    amf_tnl_association_update_list_t     *p_local  /* Local Buffer */
);

ngap_map_updation_const_et  validate_and_fill_slice_support_list
(
    ngap_SliceSupportList           *p_value, /* ASN Buffer */
    ngap_tai_slice_support_list_t   *p_local  /* Local Buffer */
);

ngap_return_et ngap_decode_error_ind
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_error_indication_t *p_error_ind,   /* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_get_asn_msg_type
(
     void                *p_asn_msg,
     UInt32              asn_msg_len,
     ngap_amf_api_et     *ep_type,
     UInt8               *is_rcv_msg_correct
);

ngap_return_et ngap_decode_ng_setup_resp
(
    UInt8                   *p_asn_msg,         /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,        /* Input - ASN Encoded Buffer Length */
    ngap_setup_response_t   *p_ng_setup_resp,   /* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ng_dl_nas_transport__internal_dec
(
    OSCTXT                          *p_asn1_ctx,               /* Input: ASN1 Context to be used */
    ngap_DownlinkNASTransport       *p_asn_dl_nas_transport,   /* Input: Received ASN Buffer */
    ngap_downlink_nas_transport_t   *p_local_dl_nas_transport  /* Output: Local Message Structure */
);

ngap_return_et ng_nas_non_delivery_ind_internal_dec
(
    OSCTXT                                *p_asn1_ctx,                  /* Input: ASN1 Context to be used */
    ngap_NASNonDeliveryIndication         *p_asn_nas_non_delivery_ind,  /* Input: Received ASN Buffer */
    ngap_nas_non_delivery_indication_t    *p_local_nas_non_delivery_ind /* Output: Local Message Structure */
);

ngap_return_et ng_error_ind_internal_dec
(
     OSCTXT                  *p_asn1_ctx,       /* Input: ASN! Context to be used */
     ngap_ErrorIndication    *p_asn_error_ind,  /*Input: Received ASN buffer */
     ngap_error_indication_t *p_local_error_ind /*Output : Local Message Structure*/
);

ngap_return_et ng_initial_ue_message_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_InitialUEMessage       *p_asn_initial_ue_msg,
    ngap_initial_ue_message_t   *p_local_initial_ue_msg
);

ngap_return_et ng_initial_context_setup_res_internal_dec
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_InitialContextSetupResponse        *p_asn_ng_initial_context_setup_resp,
    ngap_initial_context_setup_response_t   *p_local_ng_initial_context_setup_resp
);
ngap_map_updation_const_et validate_and_fill_pdu_session_resource_setup_res_list
(
    ngap_PDUSessionResourceSetupListCxtRes            *p_value,
    ngap_pdu_session_resource_setup_response_list_t   *p_local
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_failed_to_setup
(
    ngap_PDUSessionResourceFailedToSetupListCxtRes      *p_value,
    ngap_pdu_session_resource_failed_to_setup_list_t    *p_local
);

ngap_map_updation_const_et validate_and_fill_ue_ngap_ids
(
    ngap_UE_NGAP_IDs    *p_value,
    ngap_ue_context_release_command_t *p_local
);
ngap_return_et ng_reset_ack_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_NGResetAcknowledge     *p_asn_ng_reset_ack,
    ngap_reset_acknowledge_t    *p_local_ng_reset_ack
);

ngap_map_updation_const_et validate_ue_associated_logical_ng_connection_list
(
    ngap_UE_associatedLogicalNG_connectionList      *p_value,
    ngap_ue_associated_logical_ng_connection_list_t *p_local
);

ngap_return_et ng_reset_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_NGReset                *p_asn_ng_reset,
    ngap_reset_t                *p_local_ng_reset
);

ngap_map_updation_const_et validate_reset_type
(
    ngap_ResetType  *p_value,
    ngap_reset_type *p_local
);

ngap_return_et ue_context_release_complete_internal_dec
(
    OSCTXT                              *p_asn1_ctx,
    ngap_UEContextReleaseComplete       *p_ngap_asn_ue_context_rel_complete,
    ngap_ue_context_release_complete_t  *p_ngap_local_ue_context_rel_complete
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_list
(
    ngap_PDUSessionResourceListCxtRelCpl    *p_value,
    ngap_pdu_session_resource_list_t        *p_local
);

ngap_map_updation_const_et validate_and_fill_ie_info_on_recomm_cells_and_ran_nodes_for_paging
(
    ngap_InfoOnRecommendedCellsAndRANNodesForPaging             *p_value,
    ngap_info_on_recommended_cells_and_ran_nodes_for_paging_t   *p_local
);

ngap_map_updation_const_et validate_and_fill_recomm_cells_for_paging
(
    ngap_RecommendedCellList            *p_value,
    ngap_recommended_cells_for_paging_t *p_local
);

ngap_map_updation_const_et  validate_and_fill_recomm_ran_nodes_for_paging
(
    ngap_RecommendedRANNodeList             *p_value,
    ngap_recommended_ran_nodes_for_paging_t *p_local

);

ngap_return_et ngap_decode_ue_radio_capability_info_ind
(
    UInt8                                       *p_asn_msg, 
    UInt16                                      asn_msg_len,
    ngap_ue_radio_capability_info_indication_t  *p_ue_radio_cap_info_info_ind
);

ngap_return_et ue_radio_capability_info_ind_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_UERadioCapabilityInfoIndication        *p_ngap_asn_ue_radio_cap_info_ind,
    ngap_ue_radio_capability_info_indication_t  *p_ngap_local_ue_radio_cap_info_ind
);

ngap_map_updation_const_et validate_and_fill_ie_ue_radio_cap_for_paging
(
    ngap_UERadioCapabilityForPaging         *p_value,
    ngap_ue_radio_capability_for_paging_t   *p_local
);

ngap_map_updation_const_et validate_and_fill_ie_ue_ngap_id_pair
(
    ngap_UE_NGAP_IDs                    *p_value,
    ngap_ue_context_release_command_t   *p_local
);

ngap_map_updation_const_et  validate_ie_reset_type
(
    ngap_ResetType          *p_value, 
    ngap_reset_type         *p_local

);
ngap_return_et ng_initial_context_setup_req_internal_dec
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_InitialContextSetupRequest         *p_ngap_init_context_setup_req,
    ngap_initial_context_setup_request_t    *p_ngap_local_init_context_setup_req
);

ngap_return_et ng_ue_context_release_command_internal_dec
(
    OSCTXT                              *p_asn1_ctx,
    ngap_UEContextReleaseCommand        *p_ngap_ue_context_release_command,
    ngap_ue_context_release_command_t   *p_ngap_local_ue_context_release_command
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_failed_to_setup_list_ctx_fail
(
     ngap_PDUSessionResourceFailedToSetupListCxtFail    *p_value,
     ngap_pdu_session_resource_failed_to_setup_list_t    *p_local
);

ngap_return_et ngap_decode_initial_context_setup_req
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_request_t    *p_initial_ctx_setup_req,/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_decode_dl_nas_transport
(
    UInt8			                *p_asn_msg,	        /* Input - ASN Encoded Buffer */
    UInt16                          asn_msg_len,	    /* Input - ASN Encoded Buffer Length */
    ngap_downlink_nas_transport_t   *p_dl_nas_transport,/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_decode_ue_context_release_command
(
    UInt8			                    *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_command_t   *p_ue_context_release_command,/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_decode_ng_reset
(
    UInt8			        *p_asn_msg,	   /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,   /* Input - ASN Encoded Buffer Length */
    ngap_reset_t            *p_ng_reset,   /* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);
ngap_map_updation_const_et validate_and_fill_ie_guami
(
    ngap_GUAMI      *p_value,
    ngap_guami_t    *p_local
);

ngap_map_updation_const_et validate_and_fill_ie_ue_security_capabilities
(
    ngap_UESecurityCapabilities     *p_value,
    ngap_ue_security_capabilities_t *p_local
);
ngap_map_updation_const_et validate_and_fill_ie_security_key
(
    ngap_SecurityKey        *p_value,
    ngap_security_key_t     *p_local
);
ngap_map_updation_const_et validate_and_fill_ie_pdu_session_resource_setup_req_list
(
    ngap_PDUSessionResourceSetupListCxtReq          *p_value,
    ngap_pdu_session_resource_setup_request_list_t  *p_local
);

ngap_return_et ngap_decode_ng_setup_failure
(
    UInt8                   *p_asn_msg,         /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,        /* Input - ASN Encoded Buffer Length */
    ngap_setup_failure_t    *p_ng_setup_failure,/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_req_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local
);

ngap_map_updation_const_et  ng_pdu_session_res_setup_req_transfer_internal_dec
(
    OSCTXT                                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupRequestTransfer                 *p_asn_list,
    ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local_list
);

ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_res_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_response_transfer_t         *p_local
);

ngap_return_et ng_pdu_session_res_setup_res_transfer_internal_dec
(
    OSCTXT                                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupResponseTransfer                *p_asn_list,
    ngap_pdu_session_resource_setup_response_transfer_t         *p_local_list
);

ngap_map_updation_const_et ngap_decode_pdu_session_resource_setup_unsuccessful_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t     *p_local
);

ngap_return_et ng_pdu_session_res_setup_unsuccessful_transfer_internal_dec
(
    OSCTXT                                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupUnsuccessfulTransfer            *p_value_list,
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t     *p_local_list
);

ngap_map_updation_const_et validate_and_fill_ul_ngu_up_TNL_info
(
    ngap_UPTransportLayerInformation             *p_value,
    ngap_up_transport_layer_information_t        *p_local
);

ngap_map_updation_const_et validate_and_fill_ul_ngu_up_TNL_info_list
(
    ngap_UPTransportLayerInformationList         *p_value,
    ngap_up_transport_layer_information_list_t   *p_local
);

ngap_map_updation_const_et validate_and_fill_security_ind
(
    ngap_SecurityIndication                 *p_value,
    security_indication_t                   *p_local
);

ngap_map_updation_const_et validate_and_fill_qos_flow_setup_req_list
(
    ngap_QosFlowSetupRequestList            *p_value,
    qos_flow_setup_req_list_t               *p_local
);

ngap_map_updation_const_et validate_and_fill_qos_params
(
    ngap_QosFlowLevelQosParameters          *p_value,
    qos_flow_level_qos_parameters_t         *p_local
);

ngap_map_updation_const_et ngap_decode_qos_flow_TNL_info
(
    ngap_QosFlowPerTNLInformation           *p_value,
    ngap_dl_qos_flow_per_TNL_info_t         *p_local
);

ngap_map_updation_const_et ngap_decode_qos_flow_TNL_info_list
(
    ngap_QosFlowPerTNLInformationList       *p_value,
    ngap_dl_qos_flow_per_TNL_info_list_t    *p_local
);

ngap_map_updation_const_et ngap_decode_associated_flow_list
(
    ngap_AssociatedQosFlowList              *p_asn_list,
    ngap_associated_flow_list_t             *p_local_list
);

ngap_map_updation_const_et ngap_decode_qos_failed_to_setup_list
(
    ngap_QosFlowListWithCause               *p_asn_list,
    ngap_qos_flow_list_t                    *p_local_list
);

ngap_map_updation_const_et ngap_decode_cause
(
    ngap_Cause                  *p_value,
    ngap_choice_cause_group_t   *p_local
);

ngap_map_updation_const_et ngap_decode_criticality_diagnostics
(
    ngap_CriticalityDiagnostics     *p_value,
    ngap_criticality_diagnostics_t  *p_local
);

ngap_return_et ngap_decode_ng_reset_ack
(
    UInt8			            *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_reset_acknowledge_t    *p_ng_reset_ack,/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_decode_initial_ue_message
(
    UInt8                       *p_asn_msg,             /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,            /* Input - ASN Encoded Buffer Length */
    ngap_initial_ue_message_t   *p_initial_ue_message   /* Output - Local Buffer */
);

ngap_return_et ngap_decode_ue_context_release_req
(
    UInt8                               *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_request_t   *p_ue_context_release_req   /* Output - Local Buffer */
);

ngap_return_et ngap_decode_initial_context_setup_resp
(
    UInt8                                   *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_response_t   *p_initial_ctx_setup_resp   /* Output - Local Buffer */
);
ngap_return_et ngap_decode_ue_context_release_complete
(
    UInt8                               *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                              asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    ngap_ue_context_release_complete_t  *p_ue_context_release_complete   /* Output - Local Buffer */
);

ngap_return_et ngap_decode_initial_context_setup_fail
(
    UInt8                                   *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    ngap_initial_context_setup_failure_t    *p_initial_ctx_setup_fail   /* Output - Local Buffer */
);

ngap_return_et amf_get_asn_msg_type
(
    void                *p_asn_msg,
    UInt32              asn_msg_len,
    ngap_amf_api_et     *ep_type,
    UInt8               *is_rcv_msg_correct
);

ngap_return_et ngap_decode_paging
(
    UInt8			        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_paging_t           *p_ngap_paging,	/* Output - Local Buffer */
#ifndef AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context  /* AMF Context */
#else
    void                    *p_amf_context      /* AMF Context */
#endif
);

ngap_return_et ngap_paging_internal_dec
(
    OSCTXT			*p_asn1_ctx,         /* Input: ASN1 Context to be used */
    ngap_Paging     *p_asn_ngap_paging,  /* Input: Received ASN Buffer */
    ngap_paging_t   *p_local_ngap_paging /* Output: Local Message Structure */
);

ngap_map_updation_const_et  validate_and_fill_tai_list_for_paging
(
    ngap_TAIListForPaging       *p_value, /* ASN Buffer */ 
    ngap_tai_list_for_paging_t  *p_local  /* Local Buffer */
);

ngap_map_updation_const_et  validate_and_fill_assistance_data_for_paging
(
    ngap_AssistanceDataForPaging        *p_value, /* ASN Buffer */ 
    ngap_assistance_data_for_paging_t   *p_local  /* Local Buffer */
);


ngap_return_et ngap_decode_pdu_session_resource_setup_response
(
    UInt8                                       *p_asn_msg,                                    /* Input - ASN Encoded Buffer*/
    UInt16                                      asn_msg_len,                                   /* Input-ASN Encoded Buffer Length*/
    ngap_pdu_session_resource_setup_response_t  *p_local_pdu_session_resource_setup_response   /*Output -Local Buffer  */
);

ngap_return_et ngap_internal_decode_pdu_session_resource_setup_response
(
       OSCTXT                                            *p_asn1_ctx,
       ngap_PDUSessionResourceSetupResponse              *p_asn_pdu_session_resource_setup_resp,
       ngap_pdu_session_resource_setup_response_t        *p_local_pdu_session_resource_setup_resp
);

ngap_return_et  ngap_internal_decode_pdu_session_resource_setup_request
(
       OSCTXT                                            *p_asn1_ctx,
       ngap_PDUSessionResourceSetupRequest               *p_asn_pdu_session_resource_setup_req,
       ngap_pdu_session_resource_setup_request_t         *p_local_pdu_session_resource_setup_req

);

ngap_return_et  ngap_decode_pdu_session_resource_setup_request
(
    UInt8                                       *p_asn_msg,/* Input - ASN Encoded Buffer */
    UInt16                                      asn_msg_len,/* Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_setup_request_t   *p_local_pdu_session_res_setup_req
                                                    /* Output - Local Buffer */
);

ngap_return_et ngap_decode_ul_nas_transport
(
    UInt8                   *p_asn_msg,     /* Input - ASN Encoded Buffer */
    UInt16                  asn_msg_len,    /* Input - ASN Encoded Buffer Length */
    ngap_uplink_nas_transport_t *p_ul_nas_transport /* Output - Local Buffer */
);

ngap_return_et  ngap_decode_pdu_sr_release_command
(
    UInt8                                       *p_asn_msg,/* Input - ASN Encoded Buffer */
    UInt16                                      asn_msg_len,/* Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_release_command_t *p_local_pdu_session_res_rel_cmd
);

ngap_map_updation_const_et  ngap_decode_pdu_sr_release_cmd_transfer
(
    OSDynOctStr                                             *p_value,
    ngap_pdu_session_resource_release_command_transfer_t    *p_local
);

ngap_map_updation_const_et  validate_and_fill_pdu_session_resource_release_command
(
    ngap_PDUSessionResourceToReleaseListRelCmd            *p_value,
    ngap_pdu_session_resource_to_release_list_rel_cmd_t   *p_local
);


ngap_return_et ngap_internal_decode_pdu_session_resource_release_command
(
   OSCTXT                                            *p_asn1_ctx,
   ngap_PDUSessionResourceReleaseCommand             *p_asn_pdu_session_res_rel_cmd,
   ngap_pdu_session_resource_release_command_t       *p_local_pdu_session_res_rel_cmd
);

ngap_map_updation_const_et  decode_ie_timed_report_list
(
    ngap_VolumeTimedReportList      *p_value,
    ngap_timed_report_list          *p_local
);

ngap_map_updation_const_et  decdode_ie_qos_flow_usage_report
(
    ngap_QoSFlowsUsageReportList        *p_value,
    ngap_qos_flows_usage_report_list    *p_local
);

ngap_map_updation_const_et  ngap_decode_secondary_rat_information
(
   ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions    *p_value,
   ngap_secondary_rat_usage_information_t                          *p_local
);

ngap_map_updation_const_et  ngap_decode_pdu_srr_response_transfer
(
    OSDynOctStr                                             *p_value,
    ngap_pdu_session_resource_released_response_transfer_t  *p_local
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_release_response
(
    ngap_PDUSessionResourceReleasedListRelRes               *p_value,
    ngap_pdu_session_resource_release_response_list_t       *p_local
);

ngap_return_et  ngap_internal_decode_pdu_session_resource_release_response
(
    OSCTXT                                           *p_asn1_ctx,
    ngap_PDUSessionResourceReleaseResponse           *p_asn_pdu_session_sr_resp,
    ngap_pdu_session_resource_release_response_t     *p_local_pdu_session_sr_resp
);

ngap_return_et  ngap_decode_pdu_session_resource_release_response
(
    UInt8                                        *p_asn_msg,                              /*Input - ASN Encoded Buffer */
    UInt16                                       asn_msg_len,                             /*Input-ASN Encoded Buffer Length */
    ngap_pdu_session_resource_release_response_t *p_local_pdu_session_res_rel_resp        /* Output - Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_location_reporting_req_type
(
    ngap_LocationReportingRequestType   *p_value,
    ngap_location_reporting_req_type_t  *p_local
);

ngap_map_updation_const_et validate_and_fill_cn_assisted_ran_tuning
(
    ngap_CNAssistedRANTuning        *p_value,

    ngap_CNAssisted_ran_tuning_t    *p_local
);

ngap_map_updation_const_et ng_handover_request_internal_dec
(
    OSCTXT                  *p_asn1_ctx,
    ngap_HandoverRequest    *p_asn_ho_req,
    ngap_handover_request_t *p_local_ho_req
);

ngap_return_et ngap_decode_pdu_session_resource_setup_response
(
    UInt8                                       *p_asn_msg,/* Input - ASN Encoded Buffer*/
    UInt16                                      asn_msg_len,/* Input-ASN Encoded Buffer Length*/
    ngap_pdu_session_resource_setup_response_t  *p_local_pdu_session_resource_setup_response
                                                    /*Output -Local Buffer  */
);

ngap_return_et ran_config_update_internal_dec
(
    OSCTXT                      *p_asn1_ctx,                 /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdate *p_asn_ran_config_update,    /* Input: Received ASN Buffer */
    ran_config_update_t         *p_local_ran_config_update   /* Output: Local Message Structure */
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_HO_required_list
(
       ngap_PDUSessionResourceListHORqd      *p_value,
       ngap_pdu_session_res_list_HO_rqd_t    *p_local
);


ngap_map_updation_const_et ngap_decode_handover_required_transfer
(
    OSDynOctStr                 *p_value,
    ho_required_transfer_t      *p_local
);

ngap_map_updation_const_et validate_and_fill_pdu_session_resource_setup_ho_request_list
(
       ngap_PDUSessionResourceSetupListHOReq      *p_value,
       ngap_pdu_session_res_setup_list_HO_req_t    *p_local
);

ngap_map_updation_const_et validate_and_fill_src_to_target_transparent_container 
(
     ngap_SourceToTarget_TransparentContainer *p_value,
     ngap_src_to_target_transparent_container_t                   *p_local
 );


ngap_map_updation_const_et validate_and_fill_SelectedTai
(
     ngap_TAI            *p_value,
     ngap_tai_t          *p_local

);

ngap_map_updation_const_et  validate_and_fill_TargetID
(
     ngap_TargetID           *p_value,
     ngap_target_id_t        *p_local
);

ngap_return_et ngap_decode_handover_required
(
UInt8                                  *p_asn_msg,     /* Input - ASN Encoded Buffer */
UInt16                                 asn_msg_len,    /* Input - ASN Encoded Buffer Length */
ngap_handover_required_t               *p_handover_required,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et ngap_handover_required_internal_dec
(
 OSCTXT                         *p_asn1_ctx,
 ngap_HandoverRequired          *p_asn_handover_required,
 ngap_handover_required_t       *p_local_handover_required
 );

ngap_return_et ngap_decode_handover_command
(
    
    UInt8			            *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_command_t     *p_local_handover_command,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et  ngap_handover_command_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_HandoverCommand        *p_ngap_asn_handover_cmd,
    ngap_handover_command_t     *p_ngap_local_handover_cmd
);


ngap_map_updation_const_et validate_and_fill_nas_security_parameter_from_ngran 
(
       ngap_NASSecurityParametersFromNGRAN   *p_value,
       ngap_dynamic_string_t                 *p_local
);

ngap_map_updation_const_et valiate_and_fill_pdu_session_resource_handover_list
(
    ngap_PDUSessionResourceHandoverList     *p_value,
    ngap_pdu_session_res_ho_list_t          *p_local
);


ngap_map_updation_const_et ngap_decode_handover_command_transfer
(
     ho_command_transfer_t    *p_local,
     OSDynOctStr              *p_value
);

ngap_map_updation_const_et decode_ngap_qos_flow_fwd_list 
(
    ngap_QosFlowToBeForwardedList       *p_asn_qos_flow_fwd_list,
    ngap_qos_flow_to_be_fwd_list_t      *p_local_qos_flow_fwd_list
);

ngap_map_updation_const_et  decode_ngap_data_fwding_resp_drb_list
(
    ngap_DataForwardingResponseDRBList      *p_asn_data_fwd_resp_drb_list,
    nagp_data_fwding_response_drb_list_t    *p_local_p_asn_data_fwd_resp_drb_list
);

ngap_map_updation_const_et validate_and_fill_target_to_src_transparent_container 
(
       ngap_TargetToSource_TransparentContainer   *p_value,
       ngap_trg_ngran_to_src_ngran_transparent_container_t   *p_local/*Handover_changes*/
);

ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceToReleaseListHOCmd
(
    ngap_PDUSessionResourceToReleaseListHOCmd  *p_value,
    ngap_pdu_session_res_to_rel_list_ho_cmd_t  *p_local
);

ngap_map_updation_const_et ngap_decode_handover_prepration_unsuccessful_transfer
(
    ngap_ho_preparation_unsuccessful_transfer_t *p_local,
    OSDynOctStr                                 *p_value
);

ngap_return_et ngap_decode_handover_preparation_failure
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_preparation_failure_t  *p_local_ho_preparation_failure,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et  ngap_handover_preparation_failure_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverPreparationFailure             *p_ngap_asn_ho_preparation_failure,
    ngap_handover_preparation_failure_t         *p_ngap_local_ho_preparation_failure
);

ngap_return_et ngap_decode_handover_failure
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_failure_t          *p_local_ho_failure,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);


ngap_return_et  ngap_handover_failure_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverFailure                        *p_ngap_asn_ho_failure,
    ngap_handover_failure_t                     *p_ngap_local_ho_failure
);


ngap_return_et ngap_decode_handover_notify
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_notify_t              *p_local_ho_notify,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et  ngap_handover_notify_internal_dec
(
    OSCTXT                         *p_asn1_ctx,
    ngap_HandoverNotify            *p_ngap_asn_ho_notify,
    ngap_handover_notify_t         *p_ngap_local_ho_notify
);

ngap_return_et ngap_decode_handover_cancel
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_cancel_t          *p_local_ho_cancel,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et  ngap_handover_cancel_internal_dec
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_HandoverCancel                        *p_ngap_asn_ho_cancel,
    ngap_handover_cancel_t                     *p_ngap_local_ho_cancel
);

ngap_return_et ngap_decode_handover_cancel_acknowledge
(
    UInt8			                     *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                               asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_cancel_ack_t          *p_local_ho_cancel_ack,
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et  ngap_handover_cancel_acknowledge_internal_dec
(
    OSCTXT                                     *p_asn1_ctx,
    ngap_HandoverCancelAcknowledge             *p_ngap_asn_ho_cancel_ack,
    ngap_handover_cancel_ack_t                 *p_ngap_local_ho_cancel_ack
);

ngap_return_et ngap_decode_handover_request_acknowledge 
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_req_ack_t         *p_local_handover_req_ack,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);

ngap_return_et ngap_handover_request_ack_internal_dec 
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_HandoverRequestAcknowledge         *p_ngap_asn_ho_req_ack,
    ngap_handover_req_ack_t                 *p_ngap_local_ho_req_ack
);

ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceAdmittedList
    (
        ngap_PDUSessionResourceAdmittedList           *p_value,
        ngap_ho_req_ack_pdu_session_res_adm_list_t    *p_local
    );

ngap_map_updation_const_et ngap_decode_ho_request_ack_transfer
(
    OSDynOctStr                                  *p_value,
    ngap_ho_request_acknowledge_transfer_t       *p_local
);

ngap_map_updation_const_et ngap_decode_additional_dl_up_tnl_info_for_ho_list
(
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions       *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t                *p_local
);

ngap_map_updation_const_et validate_and_fill_additional_dl_up_tnl_info_for_ho_list_item
(
    ngap_AdditionalDLUPTNLInformationForHOList      *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t    *p_local
);

ngap_map_updation_const_et  ngap_decode_qos_flow_setup_response_list
(
    ngap_QosFlowListWithDataForwarding          *p_value,
    ngap_qos_flow_list_with_data_forwarding     *p_local
);

ngap_map_updation_const_et  validate_and_fill_PDUSessionResourceFailedToSetupListHOAck
     (
        ngap_PDUSessionResourceFailedToSetupListHOAck * p_value,
        ngap_ho_req_ack_pdu_session_res_fail_list_t *  p_local
     );


ngap_map_updation_const_et validate_and_fill_ho_resource_allocation_unsuccessful_transfer
(
 OSDynOctStr                                             *p_value,
 ngap_ho_resource_allocation_unsuccessful_transfer_t     *p_local
);

ngap_return_et ngap_decode_handover_request
(
    UInt8			                        *p_asn_msg,	    /* Input - ASN Encoded Buffer */
    UInt16                                  asn_msg_len,	/* Input - ASN Encoded Buffer Length */
    ngap_handover_request_t                 *p_local_handover_request,/* Output - Local Buffer */
#ifndef  AMF_SIM_TESTING_ENABLE
    ngap_amf_global_context *p_amf_context      /* AMF Context */ 
#else
    void                    *p_amf_context      /* AMF Context */ 
#endif
);


ngap_return_et  ngap_handover_request_internal_dec
(
    OSCTXT                      *p_asn1_ctx,
    ngap_HandoverRequest        *p_asn_handover_request,
    ngap_handover_request_t     *p_local_handover_request
);

ngap_map_updation_const_et  validate_and_fill_CoreNetworkAssistanceInformationForInactive
(
    ngap_CoreNetworkAssistanceInformationForInactive *p_value,
    ngap_core_network_assistance_info_for_inactive_t *p_local
);


ngap_map_updation_const_et validate_and_fill_expexted_ue_behaviour
(
    ngap_expected_ue_behaviour_t *p_local,
    ngap_ExpectedUEBehaviour     *p_value
);

ngap_map_updation_const_et  validate_and_fill_tai_list_for_incative
(
    ngap_TAIListForInactive       *p_value, /* ASN Buffer */ 
    ngap_tai_list_for_inactive_t  *p_local  /* Local Buffer */
);

ngap_map_updation_const_et validate_and_fill_security_context
 (
    ngap_SecurityContext *p_value,
    ngap_security_context_t *p_local
 );

ngap_map_updation_const_et validate_and_fill_trace_activation
(
 ngap_TraceActivation     *p_value,
 ngap_trace_activation_t  *p_local
);

ngap_map_updation_const_et  validate_and_fill_mobility_restriction_list
(
 ngap_MobilityRestrictionList * p_value,
 ngap_mobility_restriction_list_t * p_local
 );

ngap_map_updation_const_et ngap_decode_rat_restriction_information_list
(
    ngap_rat_restriction_t      *p_local,
    ngap_RATRestrictions        *p_value
);

ngap_map_updation_const_et ngap_decode_forbidden_area_information
(
   ngap_forbidden_area_information_t *p_local,
   ngap_ForbiddenAreaInformation     *p_value
);

ngap_map_updation_const_et  ngap_decode_service_area_information
(
    ngap_service_area_information_t     *p_local,
    ngap_ServiceAreaInformation         *p_value
);

ngap_return_et ng_amf_config_update_internal_dec
(
 OSCTXT                      *p_asn1_ctx,               /* Input: ASN1 Context to be used */
 ngap_AMFConfigurationUpdate *p_asn_amf_config_update,  /* Input: Received ASN Buffer */
 amf_config_update_t         *p_local_amf_config_update /* Output: Local Message Structure */
);
/*Handover_changes_start*/

ngap_map_updation_const_et ngap_decode_qos_flow_info_list
(
   ngap_QosFlowInformationList            *p_value,
   ngap_qos_flow_information_list_t       *p_local
);

ngap_map_updation_const_et ngap_decode_drb_to_qos_flow_mapping_list
(
   ngap_DRBsToQosFlowsMappingList           *p_value,
   ngap_drb_to_qos_flow_mapping_list_t      *p_local
);
ngap_map_updation_const_et ngap_decode_pdu_session_resource_info_list
(
   ngap_PDUSessionResourceInformationList    *p_value,
   ngap_pdu_session_resource_info_list_t     *p_local
);
ngap_map_updation_const_et ngap_decode_ue_history_information
(
    ngap_UEHistoryInformation               *p_value,
    ngap_ue_history_information_list_t      *p_local
);
/*Handover_changes_end*/

ngap_return_et ngap_decode_ran_config_update_ack
(
    UInt8                       *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    ran_config_update_ack_t     *p_ran_config_update_ack    /* Output - Local Buffer */
);

ngap_return_et ran_config_update_ack_internal_dec
(
    OSCTXT                                 *p_asn1_ctx,                    /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdateAcknowledge *p_asn_ran_config_update_ack,   /* Input: Received ASN Buffer */
    ran_config_update_ack_t                *p_local_ran_config_update_ack  /* Output: Local Message Structure */
);

ngap_return_et ngap_decode_ran_config_update_failure
(
    UInt8                       *p_asn_msg,                      /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,                     /* Input - ASN Encoded Buffer Length */
    ran_config_update_failure_t *p_ran_config_update_failure     /* Output - Local Buffer */
);

ngap_return_et ran_config_update_failure_internal_dec
(
    OSCTXT                             *p_asn1_ctx,                        /* Input: ASN1 Context to be used */
    ngap_RANConfigurationUpdateFailure *p_asn_ran_config_update_failure,   /* Input: Received ASN Buffer */
    ran_config_update_failure_t        *p_local_ran_config_update_failure  /* Output: Local Message Structure */
);

ngap_return_et ngap_decode_amf_config_update_ack
(
    UInt8                       *p_asn_msg,                 /* Input - ASN Encoded Buffer */
    UInt16                      asn_msg_len,                /* Input - ASN Encoded Buffer Length */
    amf_config_update_ack_t     *p_amf_config_update_ack    /* Output - Local Buffer */
);

ngap_return_et amf_config_update_ack_internal_dec
(
    OSCTXT                                 *p_asn1_ctx,                    /* Input: ASN1 Context to be used */
    ngap_AMFConfigurationUpdateAcknowledge *p_asn_amf_config_update_ack,   /* Input: Received ASN Buffer */
    amf_config_update_ack_t                *p_local_amf_config_update_ack  /* Output: Local Message Structure */
);

ngap_return_et ngap_decode_amf_config_update_failure
(
    UInt8                       *p_asn_msg,                     /* Input - ASN Encoded Buffer */
    UInt16                       asn_msg_len,                   /* Input - ASN Encoded Buffer Length */
    amf_config_update_failure_t *p_amf_config_update_failure    /* Output - Local Buffer */
);

ngap_return_et amf_config_update_failure_internal_dec
(
    OSCTXT                             *p_asn1_ctx,                        /* Input: ASN1 Context to be used */
    ngap_AMFConfigurationUpdateFailure *p_asn_amf_config_update_failure,   /* Input: Received ASN Buffer */
    amf_config_update_failure_t        *p_local_amf_config_update_failure  /* Output: Local Message Structure */
);

ngap_map_updation_const_et validate_and_fill_tnl_association_setup_list
(
    ngap_AMF_TNLAssociationSetupList  *p_value,
    amf_tnl_association_setup_list_t  *p_local
);

ngap_map_updation_const_et validate_and_fillassociation_failed_to_setup_list
(
    ngap_TNLAssociationList                       *p_value,
    amf_tnl_association_failed_to_setup_list_t    *p_local
);

ngap_return_et ngap_decode_ng_amf_config_update
(
    UInt8			     *p_asn_msg,	         /* Input - ASN Encoded Buffer */
    UInt16               asn_msg_len,	         /* Input - ASN Encoded Buffer Length */
    amf_config_update_t  *p_ng_amf_config_update /* Output - Local Buffer */
);

#endif  /* _NGAP_ASN_DEC_WRAPPER_H_ */
