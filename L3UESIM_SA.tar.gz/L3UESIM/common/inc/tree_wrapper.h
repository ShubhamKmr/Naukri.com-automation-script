/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name tree_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ****************************************************************************
 *
 *
 *
 ****************************************************************************/
#ifndef _TREE_WRAPPER_H_
#define _TREE_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "ylib.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/* This is needed to create a user defined tree. An object of this needs to 
   be passed to the intialization function of the tree. */
typedef YTREE NR_TREE;

/* This is the anchor of the entry to be made in the tree. This object should
   be part of every node that is created to be inserted into a tree. */
typedef YTNODE NR_TREE_NODE;

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    treeInit(NR_TREE *pTree, SInt32 (*compare)(const void *, const void *), const void *(*key)(const NR_TREE_NODE *) );
UInt32  treeCount(const NR_TREE *pTree);
void    treeDeleteNode(NR_TREE *pTree, NR_TREE_NODE *pNode);
void    treeInsertNode(NR_TREE *pTree, NR_TREE_NODE *pNode);
NR_TREE_NODE *getTreeNode(const NR_TREE *pTree, const void* pItem);
NR_TREE_NODE *getNextTreeNode(const NR_TREE_NODE *pNode, UInt32 order);
NR_TREE_NODE *getFirstTreeNode(const NR_TREE *pTree, UInt32 order);
NR_TREE_NODE *getLastTreeNode(const NR_TREE *pTree, UInt32 order);
NR_TREE_NODE *getPrevTreeNode(const NR_TREE_NODE *pNode, UInt32 order);
void    treeWalk(NR_TREE *pTree, void (*walker)(NR_TREE_NODE *, void *), void * pValue);
void    treeDelete(NR_TREE *pTree, void (*walker)(NR_TREE_NODE *, void *), void * pValue);
UInt32 printTree(const NR_TREE* tree_p);

#endif
