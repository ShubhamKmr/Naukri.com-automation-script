/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2014 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file l3_pdcp_il_composer.h contains the prototypes 
 *                     of RRC-PDCP interface message composing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _l3_PDCP_IL_COMPOSER_H_
#define _l3_PDCP_IL_COMPOSER_H_

#include "gnb_defines.h"
#include "l3_pdcp_intf.h"
#include "gnb_msg_mgmt.h"

gnb_length_t
gnb_il_get_rrc_pdcp_cr_ue_entity_req_len
(
    rrc_pdcp_cr_ue_entity_req_t *p_rrc_pdcp_cr_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_cr_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_cr_ue_entity_req_t *p_rrc_pdcp_cr_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_cr_ue_entity_cnf_len
(
    pdcp_rrc_cr_ue_entity_cnf_t *p_pdcp_rrc_cr_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_cr_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_cr_ue_entity_cnf_t *p_pdcp_rrc_cr_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_del_ue_entity_req_len
(
    rrc_pdcp_del_ue_entity_req_t *p_rrc_pdcp_del_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_del_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_del_ue_entity_req_t *p_rrc_pdcp_del_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_del_ue_entity_cnf_len
(
    pdcp_rrc_del_ue_entity_cnf_t *p_pdcp_rrc_del_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_del_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_del_ue_entity_cnf_t *p_pdcp_rrc_del_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_reconf_ue_entity_req_len
(
    rrc_pdcp_reconf_ue_entity_req_t *p_rrc_pdcp_reconf_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_reconf_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_reconf_ue_entity_req_t *p_rrc_pdcp_reconf_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_reconfig_ue_entity_cnf_len
(
    pdcp_rrc_reconfig_ue_entity_cnf_t *p_pdcp_rrc_reconfig_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_reconfig_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_reconfig_ue_entity_cnf_t *p_pdcp_rrc_reconfig_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_srb_dl_data_req_len
(
    rrc_pdcp_srb_dl_data_req_t *p_rrc_pdcp_srb_dl_data_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_srb_dl_data_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_srb_dl_data_req_t *p_rrc_pdcp_srb_dl_data_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_srb_dl_data_resp_len
(
    pdcp_rrc_srb_dl_data_resp_t *p_pdcp_rrc_srb_dl_data_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_srb_dl_data_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_srb_dl_data_resp_t *p_pdcp_rrc_srb_dl_data_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_srb_ul_data_req_len
(
    rrc_pdcp_srb_ul_data_req_t *p_rrc_pdcp_srb_ul_data_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_srb_ul_data_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_srb_ul_data_req_t *p_rrc_pdcp_srb_ul_data_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_srb_ul_data_resp_len
(
    pdcp_rrc_srb_ul_data_resp_t *p_pdcp_rrc_srb_ul_data_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_srb_ul_data_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_srb_ul_data_resp_t *p_pdcp_rrc_srb_ul_data_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_sn_hfn_status_req_len
(
    rrc_pdcp_sn_hfn_status_req_t *p_rrc_pdcp_sn_hfn_status_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_sn_hfn_status_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_sn_hfn_status_req_t *p_rrc_pdcp_sn_hfn_status_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_sn_hfn_status_resp_len
(
    pdcp_rrc_sn_hfn_status_resp_t *p_pdcp_rrc_sn_hfn_status_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_sn_hfn_status_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_sn_hfn_status_resp_t *p_pdcp_rrc_sn_hfn_status_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_sn_hfn_status_ind_len
(
    rrc_pdcp_sn_hfn_status_ind_t *p_rrc_pdcp_sn_hfn_status_ind
);

gnb_return_t
gnb_il_compose_rrc_pdcp_sn_hfn_status_ind
(
    UInt8  **pp_buffer,
    rrc_pdcp_sn_hfn_status_ind_t *p_rrc_pdcp_sn_hfn_status_ind
);

gnb_length_t
gnb_il_get_rrc_pdcp_data_buffer_stop_ind_len
(
    rrc_pdcp_data_buffer_stop_ind_t *p_rrc_pdcp_data_buffer_stop_ind
);

gnb_return_t
gnb_il_compose_rrc_pdcp_data_buffer_stop_ind
(
    UInt8  **pp_buffer,
    rrc_pdcp_data_buffer_stop_ind_t *p_rrc_pdcp_data_buffer_stop_ind
);

gnb_length_t
gnb_il_get_rrc_pdcp_mac_i_req_len
(
    rrc_pdcp_mac_i_req_t *p_rrc_pdcp_mac_i_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_mac_i_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_mac_i_req_t *p_rrc_pdcp_mac_i_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_mac_i_resp_len
(
    pdcp_rrc_mac_i_resp_t *p_pdcp_rrc_mac_i_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_mac_i_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_mac_i_resp_t *p_pdcp_rrc_mac_i_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_re_establish_ue_entity_req_len
(
    rrc_pdcp_re_establish_ue_entity_req_t *p_rrc_pdcp_re_establish_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_re_establish_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_re_establish_ue_entity_req_t *p_rrc_pdcp_re_establish_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_re_establish_ue_entity_cnf_len
(
    pdcp_rrc_re_establish_ue_entity_cnf_t *p_pdcp_rrc_re_establish_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_re_establish_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_re_establish_ue_entity_cnf_t *p_pdcp_rrc_re_establish_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_suspend_ue_entity_req_len
(
    rrc_pdcp_suspend_ue_entity_req_t *p_rrc_pdcp_suspend_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_suspend_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_suspend_ue_entity_req_t *p_rrc_pdcp_suspend_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_suspend_ue_entity_cnf_len
(
    pdcp_rrc_suspend_ue_entity_cnf_t *p_pdcp_rrc_suspend_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_suspend_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_suspend_ue_entity_cnf_t *p_pdcp_rrc_suspend_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_resume_ue_entity_req_len
(
    rrc_pdcp_resume_ue_entity_req_t *p_rrc_pdcp_resume_ue_entity_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_resume_ue_entity_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_resume_ue_entity_req_t *p_rrc_pdcp_resume_ue_entity_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_resume_ue_entity_cnf_len
(
    pdcp_rrc_resume_ue_entity_cnf_t *p_pdcp_rrc_resume_ue_entity_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_resume_ue_entity_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_resume_ue_entity_cnf_t *p_pdcp_rrc_resume_ue_entity_cnf
);

gnb_length_t
gnb_il_get_rrc_pdcp_change_crnti_req_len
(
    rrc_pdcp_change_crnti_req_t *p_rrc_pdcp_change_crnti_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_change_crnti_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_change_crnti_req_t *p_rrc_pdcp_change_crnti_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_change_crnti_cnf_len
(
    pdcp_rrc_change_crnti_cnf_t *p_pdcp_rrc_change_crnti_cnf
);

gnb_return_t
gnb_il_compose_pdcp_rrc_change_crnti_cnf
(
    UInt8  **pp_buffer,
    pdcp_rrc_change_crnti_cnf_t *p_pdcp_rrc_change_crnti_cnf
);

gnb_length_t
gnb_il_get_pdcp_rrc_count_wraparound_ind_len
(
    pdcp_rrc_count_wraparound_ind_t *p_pdcp_rrc_count_wraparound_ind
);

gnb_return_t
gnb_il_compose_pdcp_rrc_count_wraparound_ind
(
    UInt8  **pp_buffer,
    pdcp_rrc_count_wraparound_ind_t *p_pdcp_rrc_count_wraparound_ind
);

gnb_length_t
gnb_il_get_pdcp_rrc_notify_integrity_failure_len
(
    pdcp_rrc_notify_integrity_failure_t *p_pdcp_rrc_notify_integrity_failure
);

gnb_return_t
gnb_il_compose_pdcp_rrc_notify_integrity_failure
(
    UInt8  **pp_buffer,
    pdcp_rrc_notify_integrity_failure_t *p_pdcp_rrc_notify_integrity_failure
);

gnb_length_t
gnb_il_get_rrc_pdcp_drb_count_msb_req_len
(
    rrc_pdcp_drb_count_msb_req_t *p_rrc_pdcp_drb_count_msb_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_drb_count_msb_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_drb_count_msb_req_t *p_rrc_pdcp_drb_count_msb_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_drb_count_msb_resp_len
(
    pdcp_rrc_drb_count_msb_resp_t *p_pdcp_rrc_drb_count_msb_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_drb_count_msb_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_drb_count_msb_resp_t *p_pdcp_rrc_drb_count_msb_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_config_cell_req_len
(
    rrc_pdcp_config_cell_req_t *p_rrc_pdcp_config_cell_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_config_cell_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_config_cell_req_t *p_rrc_pdcp_config_cell_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_config_cell_resp_len
(
    pdcp_rrc_config_cell_resp_t *p_pdcp_rrc_config_cell_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_config_cell_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_config_cell_resp_t *p_pdcp_rrc_config_cell_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_ho_prep_info_req_len
(
    rrc_pdcp_ho_prep_info_req_t *p_rrc_pdcp_ho_prep_info_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_ho_prep_info_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_ho_prep_info_req_t *p_rrc_pdcp_ho_prep_info_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_ho_prep_info_resp_len
(
    pdcp_rrc_ho_prep_info_resp_t *p_pdcp_rrc_ho_prep_info_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_ho_prep_info_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_ho_prep_info_resp_t *p_pdcp_rrc_ho_prep_info_resp
);

gnb_length_t
gnb_il_get_pdcp_rrc_inactive_ues_ind_len
(
    pdcp_rrc_inactive_ues_ind_t *p_pdcp_rrc_inactive_ues_ind
);

gnb_return_t
gnb_il_compose_pdcp_rrc_inactive_ues_ind
(
    UInt8  **pp_buffer,
    pdcp_rrc_inactive_ues_ind_t *p_pdcp_rrc_inactive_ues_ind
);

gnb_length_t
gnb_il_get_rrc_pdcp_purge_cell_ues_req_len
(
    rrc_pdcp_purge_cell_ues_req_t *p_rrc_pdcp_purge_cell_ues_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_purge_cell_ues_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_purge_cell_ues_req_t *p_rrc_pdcp_purge_cell_ues_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_purge_cell_ues_resp_len
(
    pdcp_rrc_purge_cell_ues_resp_t *p_pdcp_rrc_purge_cell_ues_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_purge_cell_ues_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_purge_cell_ues_resp_t *p_pdcp_rrc_purge_cell_ues_resp
);

gnb_length_t
gnb_il_get_pdcp_rrc_cell_delete_resp_len
(
    pdcp_rrc_cell_delete_resp_t *p_pdcp_rrc_cell_delete_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_cell_delete_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_cell_delete_resp_t *p_pdcp_rrc_cell_delete_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_data_report_req_len
(
    rrc_pdcp_data_report_req_t *p_rrc_pdcp_data_report_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_data_report_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_data_report_req_t *p_rrc_pdcp_data_report_req
);

gnb_length_t
gnb_il_get_rrc_pdcp_data_report_resp_len
(
    rrc_pdcp_data_report_resp_t *p_rrc_pdcp_data_report_resp
);

gnb_return_t
gnb_il_compose_rrc_pdcp_data_report_resp
(
    UInt8  **pp_buffer,
    rrc_pdcp_data_report_resp_t *p_rrc_pdcp_data_report_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_change_cell_req_len
(
    rrc_pdcp_change_cell_req_t *p_rrc_pdcp_change_cell_req
);

gnb_return_t
gnb_il_compose_rrc_pdcp_change_cell_req
(
    UInt8  **pp_buffer,
    rrc_pdcp_change_cell_req_t *p_rrc_pdcp_change_cell_req
);

gnb_length_t
gnb_il_get_pdcp_rrc_change_cell_resp_len
(
    pdcp_rrc_change_cell_resp_t *p_pdcp_rrc_change_cell_resp
);

gnb_return_t
gnb_il_compose_pdcp_rrc_change_cell_resp
(
    UInt8  **pp_buffer,
    pdcp_rrc_change_cell_resp_t *p_pdcp_rrc_change_cell_resp
);

gnb_length_t
gnb_il_get_rrc_pdcp_drbid_lcid_map_ind_len
(
    rrc_pdcp_drbid_lcid_map_ind_t *p_rrc_pdcp_drbid_lcid_map_ind
);

gnb_return_t
gnb_il_compose_rrc_pdcp_drbid_lcid_map_ind
(
    UInt8  **pp_buffer,
    rrc_pdcp_drbid_lcid_map_ind_t *p_rrc_pdcp_drbid_lcid_map_ind
);

gnb_length_t
gnb_il_get_pdcp_rrc_traffic_inactivity_ind_len
(
    pdcp_rrc_traffic_inactivity_ind_t *p_pdcp_rrc_traffic_inactivity_ind
);

gnb_return_t
gnb_il_compose_pdcp_rrc_traffic_inactivity_ind
(
    UInt8  **pp_buffer,
    pdcp_rrc_traffic_inactivity_ind_t *p_pdcp_rrc_traffic_inactivity_ind
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_cr_ue_entity_req
(
    rrc_pdcp_cr_ue_entity_req_t  *p_rrc_pdcp_cr_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_cr_ue_entity_cnf
(
    pdcp_rrc_cr_ue_entity_cnf_t  *p_pdcp_rrc_cr_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_del_ue_entity_req
(
    rrc_pdcp_del_ue_entity_req_t  *p_rrc_pdcp_del_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_del_ue_entity_cnf
(
    pdcp_rrc_del_ue_entity_cnf_t  *p_pdcp_rrc_del_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_reconf_ue_entity_req
(
    rrc_pdcp_reconf_ue_entity_req_t  *p_rrc_pdcp_reconf_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_reconfig_ue_entity_cnf
(
    pdcp_rrc_reconfig_ue_entity_cnf_t  *p_pdcp_rrc_reconfig_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_sn_hfn_status_req
(
    rrc_pdcp_sn_hfn_status_req_t  *p_rrc_pdcp_sn_hfn_status_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_sn_hfn_status_resp
(
    pdcp_rrc_sn_hfn_status_resp_t  *p_pdcp_rrc_sn_hfn_status_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_sn_hfn_status_ind
(
    rrc_pdcp_sn_hfn_status_ind_t  *p_rrc_pdcp_sn_hfn_status_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_data_buffer_stop_ind
(
    rrc_pdcp_data_buffer_stop_ind_t  *p_rrc_pdcp_data_buffer_stop_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_mac_i_req
(
    rrc_pdcp_mac_i_req_t  *p_rrc_pdcp_mac_i_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_mac_i_resp
(
    pdcp_rrc_mac_i_resp_t  *p_pdcp_rrc_mac_i_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_re_establish_ue_entity_req
(
    rrc_pdcp_re_establish_ue_entity_req_t  *p_rrc_pdcp_re_establish_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_re_establish_ue_entity_cnf
(
    pdcp_rrc_re_establish_ue_entity_cnf_t  *p_pdcp_rrc_re_establish_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_suspend_ue_entity_req
(
    rrc_pdcp_suspend_ue_entity_req_t  *p_rrc_pdcp_suspend_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_suspend_ue_entity_cnf
(
    pdcp_rrc_suspend_ue_entity_cnf_t  *p_pdcp_rrc_suspend_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_resume_ue_entity_req
(
    rrc_pdcp_resume_ue_entity_req_t  *p_rrc_pdcp_resume_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_resume_ue_entity_cnf
(
    pdcp_rrc_resume_ue_entity_cnf_t  *p_pdcp_rrc_resume_ue_entity_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_change_crnti_req
(
    rrc_pdcp_change_crnti_req_t  *p_rrc_pdcp_change_crnti_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_change_crnti_cnf
(
    pdcp_rrc_change_crnti_cnf_t  *p_pdcp_rrc_change_crnti_cnf,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_count_wraparound_ind
(
    pdcp_rrc_count_wraparound_ind_t  *p_pdcp_rrc_count_wraparound_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_notify_integrity_failure
(
    pdcp_rrc_notify_integrity_failure_t  *p_pdcp_rrc_notify_integrity_failure,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_drb_count_msb_req
(
    rrc_pdcp_drb_count_msb_req_t  *p_rrc_pdcp_drb_count_msb_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_drb_count_msb_resp
(
    pdcp_rrc_drb_count_msb_resp_t  *p_pdcp_rrc_drb_count_msb_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_config_cell_req
(
    rrc_pdcp_config_cell_req_t  *p_rrc_pdcp_config_cell_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_config_cell_resp
(
    pdcp_rrc_config_cell_resp_t  *p_pdcp_rrc_config_cell_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_ho_prep_info_req
(
    rrc_pdcp_ho_prep_info_req_t  *p_rrc_pdcp_ho_prep_info_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_ho_prep_info_resp
(
    pdcp_rrc_ho_prep_info_resp_t  *p_pdcp_rrc_ho_prep_info_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_inactive_ues_ind
(
    pdcp_rrc_inactive_ues_ind_t  *p_pdcp_rrc_inactive_ues_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_purge_cell_ues_req
(
    rrc_pdcp_purge_cell_ues_req_t  *p_rrc_pdcp_purge_cell_ues_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_purge_cell_ues_resp
(
    pdcp_rrc_purge_cell_ues_resp_t  *p_pdcp_rrc_purge_cell_ues_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_cell_delete_resp
(
    pdcp_rrc_cell_delete_resp_t  *p_pdcp_rrc_cell_delete_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_data_report_req
(
    rrc_pdcp_data_report_req_t  *p_rrc_pdcp_data_report_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_data_report_resp
(
    rrc_pdcp_data_report_resp_t  *p_rrc_pdcp_data_report_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_change_cell_req
(
    rrc_pdcp_change_cell_req_t  *p_rrc_pdcp_change_cell_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_change_cell_resp
(
    pdcp_rrc_change_cell_resp_t  *p_pdcp_rrc_change_cell_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_rrc_pdcp_drbid_lcid_map_ind
(
    rrc_pdcp_drbid_lcid_map_ind_t  *p_rrc_pdcp_drbid_lcid_map_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_pdcp_il_send_pdcp_rrc_traffic_inactivity_ind
(
    pdcp_rrc_traffic_inactivity_ind_t  *p_pdcp_rrc_traffic_inactivity_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    cell_index_t           cell_index,
    pup_send_callback      send_callback
);

#endif /* _l3_PDCP_IL_COMPOSER_H_ */
