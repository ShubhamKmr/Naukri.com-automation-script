/****************************************************************************
 *
 *  ALTRAN -
 *
 *  Copyright (C) 2019 Altran . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name: ylib-lqueue.h
 *
 ****************************************************************************
 *
 *  File Description : Header file for Queue, 
 *                     This queue performs semaphore lock/unlock operation for
 *                     each Push/Pop operation on queue. This queue is 
 *                     effective in thread synchronization and can be used in 
 *                     any scenario and regardless of number of consumer/
 *                     producers but requires more CPU due to semaphore 
 *                     operation with every operation. This queue uses singly
 *                     linked list data structure model.
 *
 ****************************************************************************/


#ifndef _YLIB_LQUEUE_H_
#define _YLIB_LQUEUE_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include    "gnb_defines.h"
#include    "sync_wrapper.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/
#define NUM_SEM 1

/****************************************************************************
 * Exported Variables
 ****************************************************************************/
typedef struct nrLNode_t {
    struct nrLNode_t *next;
} NR_LNODE;

typedef struct l_queue_t {
    NR_LNODE *head; /* used to pop node */
    NR_LNODE *tail; /* used to push node */
    UInt32 count;
    NR_SEM sem_lock;
} NR_LQUEUE;

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void     lQueueInit(NR_LQUEUE *queue_p);
void     lQueueDeInit(NR_LQUEUE *queue_p);
UInt32   lQueueCount(const NR_LQUEUE *queue_p);
void     printLQueue(NR_LQUEUE *queue_p);
NR_LNODE *lPopNode(NR_LQUEUE *queue_p);
UInt8    lPushNode(NR_LQUEUE *queue_p, NR_LNODE *node_p);
NR_LNODE *getFirstLNode(NR_LQUEUE *queue_p);
NR_LNODE *getNextLNode(const NR_LNODE *node_p);

#endif
