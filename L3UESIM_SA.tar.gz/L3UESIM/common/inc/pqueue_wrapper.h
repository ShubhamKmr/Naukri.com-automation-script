/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2012 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name pqueue_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 *
 ****************************************************************************/


#ifndef _PQUEUE_WRAPPER_H_
#define _PQUEUE_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include    "ylib.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/* This is needed to create a user defined priority queue. An object of this 
   needs to be passed to the intialization function of the priority queue. */
typedef YSQUEUE NR_PQUEUE;

/* This is the anchor of the entry to be made in the priority queue. 
   This object should be part of every node that is created to be inserted 
   into priority queue. */
typedef YSNODE NR_PQUEUE_NODE;

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    pqInit(NR_PQUEUE *, SInt32 (*)(const NR_PQUEUE_NODE *) );
UInt32  pqCount(const NR_PQUEUE *);
NR_PQUEUE_NODE *pqPopHead( NR_PQUEUE * );
void    pqPushTail( NR_PQUEUE *, NR_PQUEUE_NODE * );

#endif
