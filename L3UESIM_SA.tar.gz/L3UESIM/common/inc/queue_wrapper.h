/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2006 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name queue_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ****************************************************************************/

#ifndef _QUEUE_WRAPPER_H_
#define _QUEUE_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "ylib.h"
#include    "sync_wrapper.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Types
 ****************************************************************************/

/* This is needed to create a user defined queue. An object of this needs to 
   be passed to the intialization function of the queue. */
typedef YLIST NR_QUEUE;

/* This is the anchor of the entry to be made in the queue. This object 
   is part of every node that is created to be inserted into a queue. */
typedef YLNODE NR_QUEUE_NODE;


/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/
void    queueInit(NR_QUEUE *pList);
void    delQueueNode(NR_QUEUE *pList,NR_QUEUE_NODE *pNode);
UInt32  queueCount(const NR_QUEUE *pList);
NR_QUEUE_NODE  *getQueueNode(NR_QUEUE *pList);
void    enQueue(NR_QUEUE *pList, NR_QUEUE_NODE *pNode);
NR_QUEUE_NODE  *deQueue(NR_QUEUE *pList);
NR_QUEUE_NODE *getLastQueueNode(const NR_QUEUE *pList);
NR_QUEUE_NODE  *getPrevQueueNode(NR_QUEUE_NODE *pNode);
NR_QUEUE_NODE  *getNextQueueNode(NR_QUEUE *pList, NR_QUEUE_NODE *pNode);
void queueInsertBefore(YLIST *pList, YLNODE *pNext, YLNODE *pNode);
void queueInsertAfter(YLIST *pList, YLNODE *pNext, YLNODE *pNode);
NR_QUEUE_NODE *getFirstQueueNode( NR_QUEUE *pList);

#endif
