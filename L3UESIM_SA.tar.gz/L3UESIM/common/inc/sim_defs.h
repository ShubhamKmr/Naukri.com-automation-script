typedef enum
{
    UESIM_ID = 0,
    S1SIM_ID = 1,
    X2SIM_ID = 2,
    DUSIM_ID = 3,
    NRADAPTSIM_ID = 4,
    RRMSIM_ID = 5,
    AMFSIM_ID = 6,
    MAXSIM_ID
} proto_sim_id_et;

#define sim_debug_abort(){\
exit(0);\
}

