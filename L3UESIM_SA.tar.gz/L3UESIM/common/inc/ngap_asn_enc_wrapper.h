/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_asn_enc_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ***************************************************************************/
#ifndef _NGAP_ASN_ENC_WRAPPER_H_
#define _NGAP_ASN_ENC_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include "ngap_asn_enc_dec_3gpp.h"
#include "rrc_defines.h"
#include "rtxsrc/rtxCommon.h"
#include "ngap_intf_mgmnt.h"
#ifndef AMF_SIM_TESTING_ENABLE
#include "ngap_global_ctx.h"
#else
#include "ngap_types.h"
#endif

/****************************************************************************
 * Exported Includes
 ****************************************************************************/



/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

/****************************************************************************
 * Exported Types
 ****************************************************************************/

#define MAX_ASN_EP_ID 140

typedef enum {
    NGAP_NG_SETUP_REQ = MAX_ASN_EP_ID,
    INVALID_NGAP_EP
}ngap_ep_et;


/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

/* This function do ASN encoding of message NG SETUP REQUEST using information 
 * passed as argument. */
ngap_return_et ngap_encode_ng_setup_req
(
    ngap_setup_request_t*   p_ng_setup_req,
    UInt8*                  p_asn_msg,
    UInt16*                 p_asn_msg_len
);

ngap_return_et ngap_encode_ie_global_ran_node_id
(
    OSCTXT					    *p_asn1_ctx,
    ngap_GlobalRANNodeID		*p_ngap_asn_gb_ran_node_id,
    ngap_global_ran_node_id_t  	*p_ngap_local_gb_ran_node_id
);

ngap_return_et ngap_encode_ie_supported_ta_list
(
    OSCTXT					    *p_asn1_ctx,
    ngap_SupportedTAList		*p_ngap_asn_supported_ta_list,
    ngap_supported_ta_list_t  	*p_ngap_local_supported_ta_list
);

ngap_return_et ngap_encode_ie_plmn_list
(
    OSCTXT					    *p_asn1_ctx,
    ngap_BroadcastPLMNList		*p_ngap_asn_supported_plmn_list,
    ngap_broadcast_plmn_list_t  *p_ngap_local_supported_plmn_list
);

ngap_return_et ngap_encode_ie_served_guami_list
(
    OSCTXT					    *p_asn1_ctx,
    ngap_ServedGUAMIList		*p_ngap_served_guami_list,      /* ASN Buffer */
    ngap_served_guami_list_t  	*p_ngap_local_served_guami_list /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_ie_plmn_support_list
(
    OSCTXT					    *p_asn1_ctx,
    ngap_PLMNSupportList		*p_ngap_plmn_support_list,      /* ASN Buffer */
    ngap_plmn_support_list_t  	*p_ngap_local_plmn_support_list /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_ie_criticality_diagnostics
(
    OSCTXT                          *p_asn1_ctx,
    ngap_CriticalityDiagnostics     *p_ngap_criticality_diagnostics_item, /* ASN Buffer */
    ngap_criticality_diagnostics_t  *p_ngap_local_criticality_diagnostics /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_ng_setup_resp
(
    ngap_setup_response_t       *p_ng_setup_resp,
    UInt8                       *p_asn_msg,
    UInt16                      *p_asn_msg_len
);

ngap_return_et ngap_encode_ie_cause
(
    OSCTXT					    *p_asn1_ctx,
    ngap_Cause      		    *p_ngap_asn_cause,  /* ASN Buffer */
    ngap_choice_cause_group_t  	*p_ngap_local_cause /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_ng_setup_fail
(
    ngap_setup_failure_t        *p_ng_setup_fail,
    UInt8                       *p_asn_msg,
    UInt16                      *p_asn_msg_len
);

ngap_return_et ngap_encode_initial_ue_message
(
    ngap_initial_ue_message_t	*p_initial_ue_msg,	/* Input - Local Buffer */
    UInt8                       *p_asn_msg, 		/* Output - ASN Encoded Buffer */
    UInt16                      *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_user_location_info
(
    OSCTXT					                *p_asn1_ctx,
    ngap_UserLocationInformation            *p_ngap_asn_user_location_info,
    ngap_choice_user_location_information_t *p_ngap_local_user_location_info
);

ngap_return_et ngap_encode_ie_allowed_nssai
(
    OSCTXT					    *p_asn1_ctx,
    ngap_AllowedNSSAI           *p_ngap_asn_allowed_nssai_list,
    ngap_allowed_nssai_list_t   *p_ngap_allowed_nssai_list
);

ngap_return_et ngap_encode_ng_reset
(
    ngap_reset_t    *p_ng_reset,	/* Input - Local Buffer */
    UInt8           *p_asn_msg, 	/* Output - ASN Encoded Buffer */
    UInt16          *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ng_reset_acknowledge
(
    ngap_reset_acknowledge_t    *p_ngap_reset_acknowledge,  /* Input - Local Buffer */
    UInt8                       *p_asn_msg, 		        /* Output - ASN Encoded Buffer */
    UInt16                      *p_asn_msg_len		        /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_error_indication
(
    ngap_error_indication_t     *p_error_ind,	/* Input - Local Buffer */
    UInt8                       *p_asn_msg, 	/* Output - ASN Encoded Buffer */
    UInt16                      *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_dl_nas_transport
(
    ngap_downlink_nas_transport_t   *p_dl_nas_transport,/* Input - Local Buffer */
    UInt8                           *p_asn_msg, 		/* Output - ASN Encoded Buffer */
    UInt16                          *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ul_nas_transport
(
    ngap_uplink_nas_transport_t *p_ul_nas_transport,/* Input - Local Buffer */
    UInt8                       *p_asn_msg, 		/* Output - ASN Encoded Buffer */
    UInt16                      *p_asn_msg_len		/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_nas_non_delivery_ind
(
    ngap_nas_non_delivery_indication_t  *p_nas_non_delivery_ind,/* Input - Local Buffer */
    UInt8                               *p_asn_msg, 		    /* Output - ASN Encoded Buffer */
    UInt16                              *p_asn_msg_len		    /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_initial_context_setup_req
(
    ngap_initial_context_setup_request_t    *p_initial_context_setup_req,   /* Input - Local Buffer */
    UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_initial_context_setup_resp
(
    ngap_initial_context_setup_response_t   *p_initial_context_setup_resp,  /* Input - Local Buffer */
    UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_initial_context_setup_fail
(
    ngap_initial_context_setup_failure_t    *p_initial_context_setup_fail,  /* Input - Local Buffer */
    UInt8                                   *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                                  *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_ue_context_release_request
(
    ngap_ue_context_release_request_t   *p_ue_context_release_request,  /* Input - Local Buffer */
    UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_ue_context_release_command
(
    ngap_ue_context_release_command_t   *p_ue_context_release_command,  /* Input - Local Buffer */
    UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_ue_context_release_complete
(
    ngap_ue_context_release_complete_t  *p_ue_context_release_complete, /* Input - Local Buffer */
    UInt8                               *p_asn_msg, 		            /* Output - ASN Encoded Buffer */
    UInt16                              *p_asn_msg_len		            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_encode_ie_pdu_session_resource_setup_res_list
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_PDUSessionResourceSetupListCxtRes          *p_ngap_pdu_session_resource_setup_res_list,/*ASN buffer*/
    ngap_pdu_session_resource_setup_response_list_t *p_ngap_local_pdu_session_resource_setup_res_list /*Local Buffer*/
);

ngap_return_et  ngap_encode_ie_pdu_session_resource_failed_to_fail_list
(
     OSCTXT *p_asn1_ctx,
     ngap_PDUSessionResourceFailedToSetupListCxtFail  *p_ngap_pdu_session_resource_failed_to_fail_list,/*ASN buffer*/
     ngap_pdu_session_resource_failed_to_setup_list_t *p_ngap_local_pdu_session_resource_failed_to_fail_list /*Local Buffer*/
);

ngap_return_et  ngap_encode_ie_pdu_session_resource_failed_to_setup_list
(
    OSCTXT                                              *p_asn1_ctx,
    ngap_PDUSessionResourceFailedToSetupListCxtRes      *p_ngap_pdu_session_resource_failed_to_setup_list,/*ASN buffer*/
    ngap_pdu_session_resource_failed_to_setup_list_t    *p_ngap_local_pdu_session_resource_failed_to_setup_list /*Local Buffer*/
);

ngap_return_et ng_initial_context_release_command_internal_dec
(
     OSCTXT                             *p_asn1_ctx,
     ngap_UEContextReleaseCommand       *p_ngap_ue_context_release_command,
     ngap_ue_context_release_command_t  *p_ngap_local_ue_context_release_command
);

ngap_return_et ngap_encode_ie_choice_reset_type
(
    OSCTXT		        *p_asn1_ctx,
    ngap_ResetType      *p_ngap_asn_reset_type,
    ngap_reset_type     *p_ngap_local_reset_type
);

ngap_return_et ngap_encode_ie_ue_associated_logical_ng_connection_list
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_UE_associatedLogicalNG_connectionList      *p_ngap_asn_ue_associated_logical_ng_connection_list,
    ngap_ue_associated_logical_ng_connection_list_t *p_ngap_local_ue_associated_logical_ng_connection_list
);

ngap_return_et  ngap_encode_ie_recommended_cells_for_paging
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_RecommendedCellList                    *p_ngap_asn_info_of_recomm_cells_for_paging,
    ngap_recommended_cells_for_paging_t         *p_ngap_local_info_of_recomm_cells_for_paging
);


ngap_return_et  ngap_encode_ie_recommended_ran_nodes_for_paging
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_RecommendedCellList                    *p_ngap_asn_info_of_recomm_ran_nodes_for_paging,
    ngap_recommended_ran_nodes_for_paging_t     *p_ngap_local_info_of_recomm_ran_nodes_for_paging
);

ngap_return_et  ngap_encode_ie_pdu_session_resource_list
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_PDUSessionResourceListCxtRelCpl        *p_ngap_asn_pdu_session_resource_list,
    ngap_pdu_session_resource_list_t            *p_ngap_local_pdu_session_resource_list
);

ngap_return_et ngap_ue_radio_capability_info_indication
(
    ngap_ue_radio_capability_info_indication_t  *p_ue_radio_cap_info_ind,	/* Input - Local Buffer */
    UInt8                                       *p_asn_msg, 		        /* Output - ASN Encoded Buffer */
    UInt16                                      *p_asn_msg_len		        /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ie_pdu_session_resource_setup_request_list
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_PDUSessionResourceSetupListCxtReq          *p_ngap_asn_pdu_session_resource_setup_req_list,/* ASN BUFFER */
    ngap_pdu_session_resource_setup_request_list_t  *p_ngap_local_pdu_session_resource_setup_req_list /* LOCAL STRUCTURE */
);

ngap_return_et ngap_encode_ie_qos_flow_setup_list
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_QosFlowSetupRequestList                    *p_ngap_asn_qos_flow_setup_req_list,
    qos_flow_setup_req_list_t                       *p_ngap_local_qos_flow_setup_req_list
);


ngap_return_et ngap_encode_pdu_session_resource_setup_req_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_request_transfer_list_t     *p_local
);

ngap_return_et ngap_encode_pdu_session_resource_setup_res_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_response_transfer_t         *p_local
);

ngap_return_et ngap_encode_pdu_session_resource_setup_unsuccessful_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t     *p_local
);

ngap_return_et ngap_encode_criticality_diagnostics_ie_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_CriticalityDiagnostics_IE_List     *p_ngap_asn_ies_criticality_diagnostics,
    ngap_criticality_diagnostics_ie_list_t  *p_local_ngap_criticality_diagnostics_ie_list
);

 ngap_return_et ngap_encode_qos_flow_failed_setup_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_QosFlowListWithCause               *p_ngap_asn_qos_flow_failed_setup_list,
    ngap_qos_flow_list_t                    *p_local_qos_flow_failed_to_setup_list
);
 
 ngap_return_et ngap_encode_ie_qos_flow_response_setup_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_AssociatedQosFlowList              *p_ngap_asn_associated_qos_flow_list,
    ngap_associated_flow_list_t             *p_ngap_local_associated_qos_flow_list
);

ngap_return_et ngap_encode_ie_qos_flow_response_setup_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_AssociatedQosFlowList              *p_ngap_asn_associated_qos_flow_list,
    ngap_associated_flow_list_t             *p_ngap_local_associated_qos_flow_list
);

ngap_return_et ngap_encode_paging
(
    ngap_paging_t       *p_ngap_paging, /* Input - Local Buffer */
    UInt8               *p_asn_msg, 	/* Output - ASN Encoded Buffer */
    UInt16              *p_asn_msg_len	/* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_encode_5g_s_tmsi
(
    OSCTXT              *p_asn1_ctx,
    ngap_FiveG_S_TMSI   *p_ngap_asn_5g_s_tmsi,
    ngap_5g_s_tmsi_t    *p_ngap_local_5g_s_tmsi
);

ngap_return_et  ngap_encode_ie_tai_list_for_paging
(
    OSCTXT                      *p_asn1_ctx,
    ngap_TAIListForPaging       *p_ngap_asn_tai_list_for_paging,
    ngap_tai_list_for_paging_t  *p_ngap_local_tai_list_for_paging
);

ngap_return_et  ngap_encode_ue_radio_capability_for_paging
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_UERadioCapabilityForPaging         *p_ngap_asn_ue_radio_cap_for_paging,
    ngap_ue_radio_capability_for_paging_t   *p_ngap_local_ue_radio_cap_for_paging
);

ngap_return_et ngap_encode_ie_addnl_up_transport_layer_info_list
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_UPTransportLayerInformationList        *p_addnl_up_transport_layer_information,
    ngap_up_transport_layer_information_list_t  *p_additional_up_layer_info
);

ngap_return_et ngap_encode_ie_addnl_qos_flow_tnl_info
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_QosFlowPerTNLInformationList           *p_asn_addnl_qos_flow_tnl_info_list,
    ngap_dl_qos_flow_per_TNL_info_list_t        *p_local_addnl_qos_flow_tnl_info_list
);

ngap_return_et ngap_encode_pdu_session_resource_setup_request
(
    ngap_pdu_session_resource_setup_request_t      *p_local_pdu_session_resource_setup_request,
    UInt8                                          *p_asn_msg,   /* Output - ASN Encoded Buffer */
    UInt16                                         *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_pdu_session_resource_setup_response
(
    ngap_pdu_session_resource_setup_response_t     *p_local_pdu_session_res_setup_response ,
    UInt8                                          *p_asn_msg,/* Output - ASN Encoded Buffer */
    UInt16                                         *p_asn_msg_len/* Output-ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_pdu_srf_unsuccessful_transfer
(
    OSDynOctStr         *p_value,
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t *p_local
);

ngap_return_et  ngap_encode_pdu_session_resource_rel_command
(
    ngap_pdu_session_resource_release_command_t     *p_local_resource_release_command ,
    UInt8                                          *p_asn_msg,/* Output - ASN Encoded Buffer */
    UInt16                                         *p_asn_msg_len/* Output-ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ie_pdu_session_resource_release_command_list
(
    OSCTXT                                              *p_asn1_ctx,
    ngap_PDUSessionResourceToReleaseListRelCmd          *p_asn_pdu_session_resource_release_cmd,
                                                               /* ASN BUFFER */
    ngap_pdu_session_resource_to_release_list_rel_cmd_t *p_local_pdu_session_resource_release_cmd /* LOCAL STRUCTURE */
);

ngap_return_et ngap_encode_pdu_session_resource_release_cmd_transfer
(
      OSDynOctStr                                                 *p_value,
      ngap_pdu_session_resource_release_command_transfer_t        *p_local
);

ngap_return_et ngap_encode_pdu_session_resource_rel_resp
(
    ngap_pdu_session_resource_release_response_t    *p_local_resource_release_respnse,
    UInt8                                          *p_asn_msg,/* Output - ASN Encoded Buffer */
    UInt16                                         *p_asn_msg_len/* Output-ASN Encoded Buffer Length */
);

ngap_return_et  ngap_encode_pdu_session_resource_release_response_list
(
    OSCTXT                                              *p_asn1_ctx,
    ngap_PDUSessionResourceReleasedListRelRes           *p_asn_pdu_session_res_rel_response,
    ngap_pdu_session_resource_release_response_list_t   *p_local_pdu_session_res_rel_response
);

ngap_return_et  ngap_encode_pdu_session_resource_release_response_transfer
(
    OSDynOctStr                                                 *p_value,
    ngap_pdu_session_resource_released_response_transfer_t      *p_local
);

ngap_return_et  ngap_encode_ie_pdu_session_resource_release_response_list
(
   OSCTXT                                                               *p_asn1_ctx,
   ngap_PDUSessionResourceReleaseResponseTransfer_iE_Extensions         *p_asn_res_transfer,
   ngap_secondary_rat_usage_information_t                               *p_local_res_transfer
);

/*Handover_changes_start*/
ngap_return_et ngap_encode_handover_required
(
 ngap_handover_required_t   *p_local_ngap_handover_required,
 UInt8                      *p_asn_msg,   /* Output - ASN Encoded Buffer */
 UInt16                     *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
);

ngap_return_et  ngap_encode_ie_qos_flow_usage_report_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_QoSFlowsUsageReportList        *p_asn_qos_flow_list,
    ngap_qos_flows_usage_report_list    *p_local_qos_flow_list
);

ngap_return_et  ngap_encode_ie_timed_report_list
(
    OSCTXT                      *p_asn1_ctx,
    ngap_VolumeTimedReportList  *p_asn_time_report_list,
    ngap_timed_report_list      *p_local_time_report_list
);

ngap_return_et ngap_encode_ng_ran_cgi
(
    OSCTXT              *p_asn1_ctx,
    ngap_NGRAN_CGI      *p_asn_ng_ran_cgi,
    ngap_ng_ran_cgi_t   *p_local_ng_ran_cgi
);

ngap_return_et  ngap_encode_handover_request/* Handover_changes*/
(
    ngap_handover_request_t *p_local_handover_req,
    UInt8                   *p_asn_msg,
    UInt16                  *p_asn_msg_len
);

ngap_return_et ngap_encode_pdu_session_res_setup_list_HO_req
(
    OSCTXT                                      *p_asn1_ctx,
    ngap_PDUSessionResourceSetupListHOReq       *p_asn_list,
    ngap_pdu_session_res_setup_list_HO_req_t    *p_local_list
);

ngap_return_et ngap_encode_area_of_inetrest_list
(
    OSCTXT                          *p_asn1_ctx,
    ngap_AreaOfInterestList         *p_asn_list,
    ngap_area_of_interest_list_t    *p_local_list
);

ngap_return_et ngap_encode_area_of_interest_tai_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_AreaOfInterestTAIList          *p_asn_area_of_intrst_tai_list,
    ngap_area_of_interest_tai_list_t    *p_local_area_of_intrst_tai_list
);

ngap_return_et ngap_encode_area_of_interest_cell_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_AreaOfInterestCellList         *p_asn_area_of_intrst_cell_list,
    ngap_area_of_interest_cell_list_t   *p_local_area_of_intrst_cell_list
);

ngap_return_et ngap_encode_ng_ran_cgi
(
    OSCTXT              *p_asn1_ctx,
    ngap_NGRAN_CGI      *p_asn_ng_ran_cgi,
    ngap_ng_ran_cgi_t   *p_local_ng_ran_cgi
);
ngap_return_et ngap_encode_area_of_interest_ran_node_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_AreaOfInterestRANNodeList          *p_asn_ran_node_list,
    ngap_area_of_interest_ran_node_list_t   *p_local_ran_node_list
);

ngap_return_et ngap_encode_mobitlity_restriction_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_MobilityRestrictionList            *p_asn_mobility_restriction_list,
    ngap_mobility_restriction_list_t        *p_local_mobility_restriction_list
);

ngap_return_et ngap_encode_rat_restriction_list
(
    OSCTXT                  *p_asn1_ctx,
    ngap_RATRestrictions    *p_asn_rat_restriction_list,
    ngap_rat_restriction_t  *p_local_rat_restriction_list
);

ngap_return_et  ngap_encode_forbidden_area_info
(
    OSCTXT                              *p_asn1_ctx,
    ngap_ForbiddenAreaInformation       *p_asn_forbidden_area_info_list,
    ngap_forbidden_area_information_t    *p_local_forbidden_area_info_list
);

ngap_return_et  ngap_encode_service_area_info
(
    OSCTXT                              *p_asn1_ctx,
    ngap_ServiceAreaInformation         *p_asn_service_area_info_list,
    ngap_service_area_information_t     *p_locap_service_area_info_list
);

/*handover_changes*/
ngap_return_et  ngap_encode_handover_prepartion_failure
(
    ngap_handover_preparation_failure_t     *p_local_ho_prep_failure,/* Input - Local Buffer */
    UInt8                                   *p_asn_msg,      /* Output - ASN Encoded Buffer */
    UInt16                                  *p_asn_msg_len   /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_handover_command
(
     ngap_handover_command_t         *p_ngap_local_ho_command,/* Input - Local Buffer */
     UInt8                           *p_asn_msg,   /* Output - ASN Encoded Buffer */
     UInt16                          *p_asn_msg_len/* Output - ASN Encoded Buffer Length */
);
/*handover_changes*/

/*RAN CONFIGURATION UPDATE*/

ngap_return_et ngap_encode_ran_config_update
(
    ran_config_update_t     *p_ran_config_update,  /* Input - Local Buffer */
    UInt8                   *p_asn_msg,            /* Output - ASN Encoded Buffer */
    UInt16                  *p_asn_msg_len         /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ran_config_update_ack
(
    ran_config_update_ack_t *p_ran_config_update_ack,  /* Input - Local Buffer */
    UInt8                   *p_asn_msg,                /* Output - ASN Encoded Buffer */
    UInt16                  *p_asn_msg_len             /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ran_config_update_fail
(
    ran_config_update_failure_t    *p_ng_ran_config_update_fail,
    UInt8                          *p_asn_msg,
    UInt16                         *p_asn_msg_len
);

/*AMF CONFIGURATION UPDATE */
ngap_return_et ngap_encode_ie_association_failed_to_setup_list
(
    OSCTXT                  *p_asn1_ctx,
    ngap_TNLAssociationList *p_ngap_tnl_association_failed_to_setup_list,                           /* ASN Buffer */
    amf_tnl_association_failed_to_setup_list_t *p_ngap_local_tnl_association_failed_to_setup_list   /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_ie_association_setup_list
(
    OSCTXT                           *p_asn1_ctx,
    ngap_AMF_TNLAssociationSetupList *p_ngap_tnl_association_setup_list,          /* ASN Buffer */
    amf_tnl_association_setup_list_t *p_ngap_local_tnl_association_setup_list     /* NGAP Local Buffer */
);

ngap_return_et ngap_encode_amf_config_update_ack
(
    amf_config_update_ack_t    *p_ng_amf_config_update_ack,
    UInt8                      *p_asn_msg,
    UInt16                     *p_asn_msg_len
);

ngap_return_et ngap_encode_amf_config_update_fail
(
    amf_config_update_failure_t    *p_ng_amf_config_update_fail,
    UInt8                          *p_asn_msg,
    UInt16                         *p_asn_msg_len
);

ngap_return_et ngap_encode_amf_configuration_update
(
    amf_config_update_t	       *p_ng_amf_config_update,     /* Input - Local Buffer */
    UInt8                      *p_asn_msg, 	                /* Output - ASN Encoded Buffer */
    UInt16                     *p_asn_msg_len	            /* Output - ASN Encoded Buffer Length */
);

ngap_return_et ngap_encode_ie_amf_tnl_association_add_to_list
(
    OSCTXT			                    *p_asn1_ctx,
    ngap_AMF_TNLAssociationToAddList	*p_ngap_asn_amf_tnl_assoc,              /* ASN Buffer */
    amf_tnl_association_to_add_list_t   *p_ngap_local_amf_tnl_assoc_add_list    /* NGAP Local Buffer */
);
ngap_return_et ngap_encode_ie_amf_tnl_association_to_remove_list
(
    OSCTXT			                    *p_asn1_ctx,
    ngap_AMF_TNLAssociationToRemoveList	*p_ngap_asn_amf_tnl_assoc,              /* ASN Buffer */
    amf_tnl_association_remove_list_t   *p_ngap_local_amf_tnl_assoc_rem_list    /* NGAP Local Buffer */
);
ngap_return_et ngap_encode_ie_amf_tnl_association_to_update_list
(
 OSCTXT                              *p_asn1_ctx,
 ngap_AMF_TNLAssociationToUpdateList *p_ngap_asn_amf_tnl_assoc,                 /* ASN Buffer */
 amf_tnl_association_update_list_t   *p_ngap_local_amf_tnl_assoc_update_list    /* NGAP Local Buffer */
);

ngap_return_et  ngap_encode_additional_dl_up_tnl_info
(
    OSCTXT                                          *p_asn1_ctx,
    ngap_AdditionalDLUPTNLInformationForHOList      *p_asn_additional_dl_up_tnl_info,
    ngap_additional_dl_up_tnl_info_for_ho_list_t    *p_local
);

ngap_return_et ngap_encode_up_transport_layer_info
(
 ngap_UPTransportLayerInformation       *p_asn_msg,
 ngap_up_transport_layer_information_t  *p_local_msg
);

ngap_return_et  ngap_encode_additional_dl_up_tnl_info_for_ho_list
(
    OSCTXT                                                   *p_asn1_ctx,
    ngap_HandoverRequestAcknowledgeTransfer_iE_Extensions    *p_value,
    ngap_additional_dl_up_tnl_info_for_ho_list_t             *p_local
);

ngap_return_et ngap_encode_handover_request_acknowledge_transfer
(
    OSDynOctStr                              *p_value,
    ngap_ho_request_acknowledge_transfer_t   *p_local
);

ngap_return_et  ngap_encode_qos_flow_setup_response_list
(
    OSCTXT                                    *p_asn1_ctx,
    ngap_QosFlowListWithDataForwarding        *p_asn_list,
    ngap_qos_flow_list_with_data_forwarding   *p_local_list
);

ngap_return_et ngap_encode_handover_res_allocation_unsussessful_transfer
(
    OSDynOctStr                                           *p_value,
    ngap_ho_resource_allocation_unsuccessful_transfer_t   *p_local
);

ngap_return_et ngap_encode_ie_cn_assisted_ran_tuning
(
 OSCTXT                          *p_asn1_ctx,
 ngap_CNAssistedRANTuning        *p_value,
 ngap_CNAssisted_ran_tuning_t    *p_local
);

ngap_return_et  ngap_encode_handover_preparation_unsussessful_transfer
(
    OSDynOctStr                                     *p_value,
    ngap_ho_preparation_unsuccessful_transfer_t     *p_local
);
/*Handover_changes_start*/
ngap_return_et ngap_encode_ho_request_ack
(
 ngap_handover_req_ack_t    *p_ngap_local_ho_req_ack,
 UInt8                      *p_asn_msg,
 UInt16                     *p_asn_msg_len
);
ngap_return_et  ngap_encode_ue_history_information
(
    OSCTXT                                *p_asn1_ctx,
    ngap_UEHistoryInformation             *p_asn_value,
    ngap_ue_history_information_list_t    *p_local_value
);
ngap_return_et ngap_encode_pdu_session_resource_info_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_PDUSessionResourceInformationList  *p_asn_list,
    ngap_pdu_session_resource_info_list_t   *p_local_list
);

ngap_return_et ngap_encode_drb_to_qos_flow_mapping_list
(
    OSCTXT                                  *p_asn1_ctx,
    ngap_DRBsToQosFlowsMappingList          *p_asn_list,
    ngap_drb_to_qos_flow_mapping_list_t     *p_local_list
);

ngap_return_et ngap_encode_qos_flow_info_list
(
    OSCTXT                              *p_asn1_ctx,
    ngap_QosFlowInformationList         *p_asn_list,
    ngap_qos_flow_information_list_t    *p_local_list
);

ngap_return_et ngap_encode_trg_to_src_ngran_transparent_container
(
    ngap_TargetToSource_TransparentContainer               *p_value,
    ngap_trg_ngran_to_src_ngran_transparent_container_t    *p_local
);
ngap_return_et ngap_encode_src_to_trg_transparent_container
(
    ngap_SourceToTarget_TransparentContainer   *p_value,
    ngap_src_to_target_transparent_container_t *p_local
);
/*Handover_changes_end*/
/*********Function prototypes for function for testing purpose************/
ngap_return_et ngap_encode_ng_setup_fail_test
(
 ngap_setup_failure_t        *p_ng_setup_fail,
 UInt8                       *p_asn_msg,
 UInt16                      *p_asn_msg_len
 );
ngap_return_et  ngap_encode_source_to_target_amf_information
(
 OSCTXT                                         *p_asn1_ctx,
 ngap_SourceToTarget_AMFInformationReroute      *p_ngap_asn_source_to_target_amf_information,
 ngap_source_to_target_information_reroute_t    *p_ngap_local_source_to_target_amf_information
 );

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

#endif  /* _NGAP_ASN_ENC_WRAPPER_H_ */
