/*******************************************************************************
*
*   FILE NAME:
*       gnb_defines.h
*
*   DESCRIPTION:
*       This file contains common types used across gNB layers.
*
*   DATE            AUTHOR      REFERENCE       REASON
*   09 Mar 2018     Chirantan   ---------       Initial
*
*   Copyright (c) 2018, Aricent Inc. All Rights Reserved
*
*******************************************************************************/

#ifndef _GNB_DEFINES_H_
#define _GNB_DEFINES_H_
#include "gnb_composer_parser.h"

#define GNB_VERSION_ID          0x01
#define GNB_MAX_THREADS 12
#define DEFAULT_GNB_LOG_FILE    "gnb_main.log"

#define PNULL               NULL
#define GNB_NULL            0
#define MODULO_TWO(x)            ((x) & 1)
#define MODULO_FOUR(x)           ((x) & 3)
#define MODULO_EIGHT(x)          ((x) & 7)
#define MODULO_TEN(x)            ((x) % 10)
#define MODULO_SIXTEEN(x)        ((x) & 15)
#define MODULO_ONEZEROTWOFOUR(x) ((x) & 1023)

#define DIVIDE_BY_TWO(x) ((x) >> 1)
#define DIVIDE_BY_FOUR(x) ((x) >> 2)
#define DIVIDE_BY_EIGHT(x) ((x) >> 3)
#define DIVIDE_BY_SIXTEEN(x) ((x) >> 4)
#define DIVIDE_BY_THIRTY_TWO(x) ((x) >> 5)
#define DIVIDE_BY_SIXTY_FOUR(x) ((x) >> 6)
#define DIVIDE_BY_1024(x) ((x) >> 10)
#define DIVIDE_BY_4096(x) ((x) >> 12)

#define MULTIPLY_BY_TWO(x) ((x) << 1)
#define MULTIPLY_BY_FOUR(x) ((x) << 2)
#define MULTIPLY_BY_EIGHT(x) ((x) << 3)
#define MULTIPLY_BY_SIXTEEN(x) ((x) << 4)
#define MULTIPLY_BY_ONEZEROTWOFOUR(x) ((x) << 10)
#define MODULO(x,d) ((x)&(d-1))

/* Find the minimum of two numbers */
#define MIN_TWO_NUM(A,B) ((A) < (B) ? (A) : (B) )
/* Find the maximum of two numbers */
#define MAX_TWO_NUM(A,B) ((A) > (B) ? (A) : (B) )

#if defined(__x86_64__) || defined(__aarch64__)
#define ADDR UInt64
#else
#define ADDR UInt32
#endif

#define STATIC static

/* This is for debugging only as the 1024 SFN wrap very early and 
 * makes it difficult to map the logs*/
#define MAX_SFN_24BITS (0x1000000)

/*******************************************************************************
 * MODULE IDs DEFINITION
 ******************************************************************************/
/* CU Module ID */
#define OAM_MODULE_ID     01  /* OAM Module ID     */
#define RRM_MODULE_ID     02  /* RRM Module ID     */
#define L3_MODULE_ID      03  /* L3 Module ID      */
#define SON_MODULE_ID     04  /* SON Module ID     */
#define PDCP_MODULE_ID    05  /* PDCP Module ID    */
#define NGU_MODULE_ID     06  /* NGU/X2U Module ID */
#define F1U_MODULE_ID     07  /* CU F1U Module ID  */


/* DU Module ID */
#ifdef MAC_TEST_MODE
#define MAX_DU_MODULE     8
#else
#define MAX_DU_MODULE     6
#endif

#define DU_MODULE_ID_BASE 20
#define DUOAM_MODULE_ID   20  /* DU OAM Module ID     */
#define DUMGR_MODULE_ID   21  /* DU Manager Module ID */
#define MAC_MODULE_ID     22  /* MAC Module ID        */
#define RLC_MODULE_ID     23  /* RLC Module ID        */
#define DUF1U_MODULE_ID   24  /* DU F1U Module ID     */
#define DUPHY_MODULE_ID   25  /* DU PHY MODULE ID */

#define GNB_MAX_EXTERNAL_MODULE_ID (DUPHY_MODULE_ID + 1)

#define DUCLI_MODULE_ID    26  /* DU CLI MODULE ID */

#define NR_ZERO		     0
#define NR_ONE		     1
#define NR_TWO		     2
#define NR_THREE	     3
#define NR_FOUR		     4
#define NR_FIVE		     5
#define NR_SIX		     6
#define NR_SEVEN	     7
#define NR_EIGHT	     8
#define NR_NINE	 	     9
#define NR_TEN		     10
#define NR_ELEVEN	     11
#define NR_TWELVE	     12
#define NR_THIRTEEN	     13
#define NR_FOURTEEN	     14
#define NR_FIFTEEN	     15
#define NR_TWENTY	     20
#define NR_THIRTY	     30
#define NR_THIRTY_TWO	 32
#define NR_FOURTY	     40
#ifdef FAPI_10_01
#define NR_SIXTY_FOUR    64
#endif

#define NR_FAILURE           0
#define NR_SUCCESS           1
#define NR_PARTIAL_FAILURE   2

#define NR_FALSE             0
#define NR_TRUE              1 

/* Header length of API header used between modules */
#define GNB_INTERFACE_API_HEADER_SIZE           16

/* Maximum radio bearers in one UE Context */
#define MIN_SRB             (01) /* SRB1,2,3...not includes SRB0 */
#define MAX_SRB             (03) /* SRB1,2,3...not includes SRB0 */
#define MIN_DRB             (1) /* DRB 1 - 32 */
#define MAX_DRB             (32) /* DRB 1 - 32 */
#define MAX_RB              (MAX_SRB + MAX_DRB) /* Max RB excluding SRB0 */

/* TG SIM changes start*/
#define MAX_QFI             64
#define MAX_PDU_SESSION     256
/* TG SIM changes end*/

#define MAX_SUPPORTED_DRB    16
#define DEFAULT_DRB_PER_UE   4

/* Maximum logical channels in one UE Context */
#define MIN_LC              (01)
#define MAX_LC              (32)

#define MAX_SUPPORTED_LC    (16)

#define MAX_DU_UE_SUPPORTED    128
#define MAX_NUM_CELL_PER_DU                 4

#define MAX_NUM_SCELL_PER_DU                (MAX_NUM_CELL_PER_DU - 1)

#ifdef FJT_L3
#define MAX_UE_SUPPORTED    12000
#else
#define MAX_UE_SUPPORTED    3000
#endif

/*MAX UE in a batch for PURGE*/

/*MAX UE in a batch for PURGE*/
/* Multi UECC Changes Start */
#define MAX_NUM_PURGE_UE_IN_BATCH 12000
#define MAX_NUM_DU_PURGE_UE_IN_BATCH 128
/* Multi UECC Changes End */
#define MAX_NUM_TRANSACTION_ID       65536
#define MAX_EARFCN                   65535
#define MAX_QCI                      256

#define MAX_UINT32_VALUE  ((UInt32)4294967295U)
#define MAX_UINT64_VALUE  ((UInt64)0xFFFFFFFFFFFFFFFFU)

/* macros to define the MTU buffers */
#define MIN_MTU_SIZE_BUFFER       1500
#define MAX_MTU_SIZE_BUFFER       9000

/* The number of buffers are derived from the calculation based 
 * on 5 Gbps DL and 500 Mbps UL throughput requirements
 * Buffering of Discard Timer - 1500 ms
 * PDCP Reordering Timer - 3000 ms 
 *
 * DL Packets = 
 * ( 5 Gbps throughput / 1500 bytes packet ) * 1000 Discard Timer
 *
 * UL Packets = 
 * ( 500 Mbps throughput / 1500 bytes packet ) * 1000 Reordering Timer 
 *
 * NUM_MTU_BUFFERS = DL Packets + UL Packets */
#ifdef X86_TESTING
#ifdef MEM_CHECK_DOUBLE_FREE
#define NUM_MTU_BUFFERS           50
#else
#define NUM_MTU_BUFFERS           100000
#endif
#define NUM_MTU_BUFFERS_1500      100000
#else
#define NUM_MTU_BUFFERS           100000
#define NUM_MTU_BUFFERS_1500      460000
#endif

#define MSG_POOL_HIGH_WATERMARK         70
#define MSG_POOL_LOW_WATERMARK          60
#define MEM_POOL_HIGH_WATERMARK         70
#define MEM_POOL_LOW_WATERMARK          60

#define SOCKET_ERROR (-1)

/* UDP buffer size of 65,507 bytes (65,535 − 8 bytes UDP header − 
 * 20 bytes IP header, assuming no IP extension headers) */
#define MAX_SOCKET_BUFFER_SIZE    65507 

#ifndef NR_UESIM_TESTING
/* For DL throughput of 2 Gbps and 500 ms holding capacity*/
#define MAX_DU_DL_THROUGHPUT_BYTES  125000000
#define MAX_DU_UL_THROUGHPUT_BYTES  6250000 
#else
#define MAX_DU_DL_THROUGHPUT_BYTES  6250000
#define MAX_DU_UL_THROUGHPUT_BYTES  125000000 
#endif


#define MAX_CONTROL_BUFFERS      10

#define GNB_INVALID_LOG          0x00    /*Bitmask: 0000 0000*/
#define GNB_FATAL                0x01    /*Bitmask: 0000 0001*/
#define GNB_ERROR                0x02    /*Bitmask: 0000 0010*/
#define GNB_WARNING              0x04    /*Bitmask: 0000 0100*/
#define GNB_INFO                 0x08    /*Bitmask: 0000 1000*/
#define GNB_BRIEF                0x10    /*Bitmask: 0001 0000*/
#define GNB_DETAILED             0x20    /*Bitmask: 0010 0000*/
#define GNB_DETAILEDALL          0x40    /*Bitmask: 0100 0000*/
#define GNB_HEXDUMP              0x08    /*Bitmask: 0000 1000*/ /* Currently mapped to GNB_INFO, In future, new log level will be defined */

#define ALL_LOG_LEVEL            ( GNB_FATAL | GNB_ERROR | GNB_WARNING |  GNB_INFO | GNB_BRIEF | GNB_DETAILED | GNB_DETAILEDALL )

#define GNB_ASN                 GNB_BRIEF
#define GNB_PROTOCOL_EVENT      GNB_DETAILED

#define IPV4_FLAG 1
#define IPV6_FLAG 2
#define IPV4_ADDR_SIZE 4
#define IPV6_ADDRESS_LENGTH       40
#define IPV4_ADDRESS_LENGTH       16 

#define API_HEADER_TRANSID_OFFSET   0
#define API_HEADER_SOURCEID_OFFSET  2
#define API_HEADER_DESTID_OFFSET    4
#define API_HEADER_MSGID_OFFSET     6
#define API_HEADER_MSGLEN_OFFSET    8
#define API_HEADER_CELL_ID_NIL      0

#define API_HEADER_CELL_INDEX_OFFSET 10

#define API_RRC_HEADER_RESERVE_1BYTE_OFFSET   11
#define API_RRC_HEADER_RESERVE_4BYTE_OFFSET   12


#define API_HEADER_PADDING_OFFSET   10
#define API_RRC_HEADER_CELL_INDEX_OFFSET   10
#define API_RRM_HEADER_CELL_INDEX_OFFSET   10
#define API_OAM_HEADER_CELL_INDEX_OFFSET   10

#define API_HEADER_API_ID_OFFSET    6

#define CELL_INDEX_OFFSET_INR(msg_p)   msg_p += 1

#define INVALID_CELL_INDEX           65535

#ifndef AMF_SIM_TESTING_ENABLE
#define MAX_NUM_CELL                 32
#endif

#define API_HEADER_DO_NOT_CARE_CELL_INDEX  INVALID_CELL_INDEX

#define NR_GCC_UNUSED_PARAM(param) (void)param;

#define MAX_DUM_UE_INDEX 255
#define NR_MAX_PRB       275
/*GQA-1188 Changes*/
#define MAX_SSB_POWER    50
#define MIN_SSB_POWER    -60
/*GQA-1188 Changes*/

#define CONVERT_MBPS_TO_BPS    DIVIDE_BY_EIGHT( 1000*1000 )
#define BYTES_PER_SEC_TO_KILO_BITS_PER_SEC  125

#define NR_GET_U16BIT(p_buff)  ((UInt16)(*(p_buff) << 8) | (UInt16)(*(p_buff + 1)))

/* to read a 24 bit value starting at the location p_buff */
#define NR_GET_U24BIT(p_buff)  ((UInt32)(*(p_buff) << 16) | (UInt32)(*(p_buff + 1) << 8) | (UInt32)(*(p_buff + 2)))

/* to read a 32 bit value starting at the location p_buff */
#define NR_GET_U32BIT(p_buff)  ((UInt32)(*(p_buff) << 24) | (UInt32)(*(p_buff + 1) << 16) | (UInt32)(*(p_buff + 2) << 8) | (UInt32)(*(p_buff + 3)))

/* to read a 40 bit value starting at the location p_buff */
#define NR_GET_U40BIT(p_buff) (((UInt64)(*(p_buff)) << 32) | (UInt64)(*(p_buff + 1) << 24) | (UInt64)(*(p_buff + 2) << 16) | (UInt64)(*(p_buff + 3) << 8) | (UInt64)(*(p_buff + 4)))

/* to read a 64 bit value starting at the location p_buff */

#define NR_GET_U64BIT(p_buff) ((UInt64)(*(p_buff) << 56) | (UInt64)(*(p_buff + 1) << 48) | (UInt64)(*(p_buff + 2) << 40) | (UInt64)(*(p_buff + 3) << 32) | (UInt64)(*(p_buff + 4) << 24) | (UInt64)(*(p_buff + 5) << 16) | (UInt64)(*(p_buff + 6) << 8) |   (UInt64)(*(p_buff + 7)))

/* macros to set U16bit, U24bit, and U32bit values onto buffer */
/* p_buff must be typecast to a (U8bit *) before using these macros */

/* to write a 16 bit value starting from the location p_buff */
#define NR_SET_U16BIT(p_buff, val)  *(p_buff) = (UInt8)((val) >> 8);    *(p_buff + 1) = (UInt8)(val);

/* to write a 24 bit value starting from the location p_buff */
#define NR_SET_U24BIT(p_buff, val)  *(p_buff) = (UInt8)((val) >> 16); *(p_buff + 1) = (UInt8)((val) >> 8); *(p_buff + 2) = (UInt8)(val);

/* to write a 32 bit value starting from the location p_buff */
#define NR_SET_U32BIT(p_buff, val)  *(p_buff) = (UInt8)((val) >> 24); *(p_buff + 1) = (UInt8)((val) >> 16); *(p_buff + 2) = (UInt8)((val) >> 8);  *(p_buff + 3) = (UInt8)(val);

/* to write a 64 bit value starting from the location p_buff */
#define NR_SET_U64BIT(p_buff, val)  *(p_buff) = (UInt8)((val) >> 56); *(p_buff + 1) = (UInt8)((val) >> 48); *(p_buff + 2) = (UInt8)((val) >> 40); *(p_buff + 3) = (UInt8)((val) >> 32); *(p_buff + 4) = (UInt8)((val) >> 24); *(p_buff + 5) = (UInt8)((val) >> 16); *(p_buff + 6) = (UInt8)((val) >> 8); *(p_buff + 7) = (UInt8)(val);

/*Wiresect Changes*//*Done*/
/*******************************************************************************
 * Common Enums
 ******************************************************************************/
typedef enum _gnb_debug_type_et
{
    /* Mem Pool Statistics */
    GET_DEBUG_INFO_MEM_STATS,

    /* Message Pool Statistics */
    GET_DEBUG_INFO_MSG_STATS

}gnb_debug_type_et;

/* Enum defining DC bearer type information */
typedef enum dc_bearer_e
{
    /* SCG_BEARER: when PDCP and RLC/MAC is present in Secondary Node, 
     * SgNB only, SN TERMINATED bearer. SCG bearer shall be used as default */
    SCG_BEARER          = 0,
    /* MCG_SPLIT_BEARER: when PDCP is present in Master Node only, 
     * RLC/MAC is present in Secondary Node, may present in Master Node
     * MN TERMINATED bearer */
    MCG_SPLIT_BEARER    = 1,
    /* SCG_SPLIT_BEARER: when PDCP is present in Secondary Node, SgNB only, 
     * RLC/MAC is present in both Secondary Node and Master Node.
     * SN TERMINATED bearer */
    SCG_SPLIT_BEARER    = 2,
    /* MCG_BEARER: when PDCP is present in Secondary Node and 
     * RLC/MAC is present in Master Node only.
     * SN TERMINATED bearer */
    MCG_BEARER          = 3,
    MAX_DC_BEARER       = 4,
    INVALID_DC_BEARER   = 255
}dc_bearer;

#endif   /* _GNB_DEFINES_H_ */
