/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2012 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name : ylib-cqueue.h
 *
 ****************************************************************************
 *
 *  File Description : Header file for Circular Queue 
 *
 ****************************************************************************
 ****************************************************************************/
#ifndef _YLIB_CQUEUE_H_
#define _YLIB_CQUEUE_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "gnb_defines.h"
#include    "sync_wrapper.h"
#include    "mempool_wrapper.h"
//#include    "log.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/


/****************************************************************************
 * Exported Variables
 ****************************************************************************/
typedef struct nrCnode_t
{
    #define CIRC_VALID   0xBADFACE
    #define CIRC_INVALID 0xFEEDBAC
    #define PENDING      0x0DDF00D
    int valid; /* validity =CIRC_VALID,CIRC_INVALID, PENDING */
    void *data;
}NR_CNODE;

typedef struct circ_queue_t
{
#if defined(__x86_64__) || defined(__aarch64__)
    long long int head;
    long long int tail;
#else
    int head;
    int tail;
#endif
    int count;
    int max; /* should always be 2^n - 1 */
    NR_CNODE *ring;
} CIRCQUEUE;

#define MAX_NODES 512
#define MAX_NODES_SEG_PDU_IND 10
#define MAX_NODES_TO_DISCARD 4096

/****************************************************************************/
/****************************************************************************
 * Exported Functions
 ****************************************************************************/

#define circQInit(list,maxNodes) _circQInit (list,maxNodes,__func__, __LINE__)
//UInt32 _circQInit(CIRCQUEUE *list, UInt32 maxNodes, UInt8 *func, UInt32 *line);
UInt32 _circQInit(CIRCQUEUE *list, UInt32 maxNodes, const SInt8 *func, UInt32 line);

UInt32 circQInitAfterCellSetup(CIRCQUEUE *list, UInt32 maxNodes);

UInt32 pushNodeCircQ(CIRCQUEUE *queue_p, void *data);
UInt32 popNodeCircQ(CIRCQUEUE *queuue_p, void **outData);
UInt32 circQueueCount(CIRCQUEUE *list);
UInt32 delNodeCircQ (CIRCQUEUE *list, UInt32 index);
UInt32 circQDeInit (CIRCQUEUE *list);
SInt32 qLinearSearch (CIRCQUEUE *list, UInt32 (*compare)(void *, void* ), void *arg);
UInt32 circQReInit(CIRCQUEUE *list, UInt32 maxNodes);
UInt32 getNodeCircQ(CIRCQUEUE *list, void **outData); 
UInt32 getNextNodeCircQ(CIRCQUEUE *list, void **outData ,UInt32 *index); 
/****************************************************************************/

#endif /* _YLIB_CQUEUE_H_ */
