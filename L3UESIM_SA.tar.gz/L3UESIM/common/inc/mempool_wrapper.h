/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name mempool_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ****************************************************************************
 *
 ****************************************************************************/

#ifndef _MEMPOOL_WRAPPER_H
#define _MEMPOOL_WRAPPER_H

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include "cspl.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    initMemPool(void);

/*****************************************************************************
 * Function Name  : freeMemoryBuffer
 * Description    : This funtion frees Memory (memPool) Buffer 
 ****************************************************************************/
void freeMemoryBuffer(void * ptr1, void * ptr2);

#define getMemPoolStats qvPoolStats

#define createAndReturnMemPool(blockSize,nBuf) \
    qvPoolCreateAndReturn(blockSize, nBuf)

#ifdef MEM_CHECK_DOUBLE_FREE
#define getMemFromPool(size,pSize) malloc(size)
#else
#define getMemFromPool(size,pSize) qvAllocEx(size, pSize, 0,__func__,__LINE__)
#endif

#define allocateMemFromPool(pool) qvPoolAlloc(pool,__func__,__LINE__)

#ifdef MEM_CHECK_DOUBLE_FREE
#define get_memory_user_data(pool_buffer_p,max_pool_size,size) malloc(size)
#else
#define get_memory_user_data(pool_buffer_p,max_pool_size,size) \
    allocMemFromNamedPool(pool_buffer_p,max_pool_size,size,__func__,__LINE__)
#endif

#ifdef MEM_CHECK_DOUBLE_FREE
#define freeMemPool(p) free(p)
#else
#define freeMemPool(p) qvFree(p,__func__,__LINE__)
#endif


#if defined (MEM_LEAK_DEBUG)
#define createMemPool(blockSize,nBuf) \
            if((nBuf > 0) && (blockSize > 0)) 
            
#else
#define createMemPool(blockSize,nBuf) qvPoolCreate(blockSize,nBuf,__func__,__LINE__)
#endif

#define getMemFromSys(size) qvSysMalloc(size)
#define freeMemSys(p) qvSysFree(p)

#define freeMemPoolAndReturn(pool) \
        if (PNULL != (pool)) \
        {\
            qvAllFreeFromMemPool(pool);\
            pool = PNULL;\
        }

#define nameContextPoolDelete(p) (deletePool((p)->pool))
#define nameContextFree   qvPoolFree

#endif /* _MEMPOOL_WRAPPER_H */
