/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_utils.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *  
 ***************************************************************************/
#ifndef _NGAP_UTILS_H_
#define _NGAP_UTILS_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include "ngap_tracing.h"


/****************************************************************************
 * MACRO DEFINITIONS
 ****************************************************************************/

/* Macros for Generic Use System Functions */
#ifndef AMF_SIM_TESTING_ENABLE 
#define NGAP_MEMSET				    memset_wrapper
#define NGAP_MEMCPY                 memcpy_wrapper
#define NGAP_MEMCMP                 memcmp_wrapper
#else
#define NGAP_MEMSET				    memset
#define NGAP_MEMCPY                 memcpy
#define NGAP_MEMCMP                 memcmp
#endif

#define NGAP_MEMMOVE                memmove
#define NGAP_STRNCMP(X,Y,Z)         strncmp((const char*)X,(const char*)Y,Z)
#define NGAP_STRCMP(X,Y)            strcmp((const char*)X,(const char*)Y)
#define NGAP_STRCAT(X,Y)            strcat((char*)X,(char*)Y)
#define NGAP_STRNCAT(X,Y,Z)         strncat((char*)X,(const char*)Y,Z)
#define NGAP_STRTOK(X,Y)            strtok((char*)X,(const char*)Y)
#define NGAP_STRCPY(X,Y)            strcpy((char*)X,(const char*)Y)
#define NGAP_STRNCPY(X,Y,Z)         strncpy((char*)X,(const char*)Y,Z)
#define NGAP_STRLEN(X)              strlen((const char*)X)

#define INVALID_VALUE_RAN_AMF_NGAP_UEID     0xFFFFFFFFFFFF
/*NGAP_CONTEXT_CHANGES_START*/
#define INVALID_VALUE_RAN_NGAP_UEID         0xFFFF
/*NGAP_CONTEXT_CHANGES_STOP*/

#ifndef AMF_SIM_TESTING_ENABLE 
#define NGAP_ASSERT(exp) GNB_ASSERT(exp)

#define NGAP_SYSTEM_MEM_FAIL()\
do\
{\
    RRC_NGAP_TRACE(NGAP_FATAL, "SYSTEM ERROR: MEMORY ALLOCATION FAILED")\
}\
while(0)

#else
#define NGAP_SYSTEM_MEM_FAIL()\
    printf("SYSTEM ERROR: MEMORY ALLOCATION FAILED")
#endif

#ifdef AMF_SIM_TESTING_ENABLE
#ifdef NGAP_DEBUG
void ngap_assert
(
 void* file,
 U32 line,
 void* expression
 );
#define NGAP_ASSERT(exp) (void)((exp) || (ngap_assert(__FILE__,__LINE__,#exp),0))
#else
#define NGAP_ASSERT(exp)
#endif
#endif

#define NGAP_MSG_SEND_FAILURE(dest_mod_id, msg_name)\
    do\
{\
    RRC_NGAP_TRACE(NGAP_FATAL, "FAILED to Send Message [%s] To Module [%s]", msg_name, dest_mod_id)\
}\
while(0)


extern const SInt8 *NGAP_FSM_STATES_NAMES[];

extern const SInt8 *AMF_FSM_STATES_NAMES[];


#define NGAP_FSM_NAME           "NGAP_FSM"
#define AMF_FSM_NAME            "AMF_FSM"

#define GET_NGAP_FSM_CURRENT_STATE(p_ngap_gb_ctx)  (p_ngap_gb_ctx->current_ngap_state)

#define GET_AMF_FSM_CURRENT_STATE(p_amf_context)  (p_amf_context->current_amf_state)

#define SET_NGAP_FSM_STATE_TRACE(fsm_name, state_name, new_state) \
    RRC_NGAP_TRACE(NGAP_INFO, "[%s] UPDATING NGAP STATE FROM OLD STATE [%s] TO NEW STATE [%s]", \
            fsm_name,state_name,new_state)
            
#define SET_NGAP_FSM_STATE(p_ngap_gb_ctx, new_state) \
    do \
{ \
    SET_NGAP_FSM_STATE_TRACE(NGAP_FSM_NAME, \
            NGAP_FSM_STATES_NAMES[GET_NGAP_FSM_CURRENT_STATE(p_ngap_gb_ctx)], NGAP_FSM_STATES_NAMES[new_state]); \
    p_ngap_gb_ctx->current_ngap_state = new_state; \
} \
while (0)

#define SET_AMF_FSM_STATE_TRACE(fsm_name, state_name, new_state, p_amf_context) \
    RRC_NGAP_TRACE(NGAP_INFO, "[%s] UPDATING AMF [%d] STATE FROM OLD STATE [%s] TO NEW STATE [%s]", \
            fsm_name, p_amf_context->amf_id, state_name, new_state)
            
#define SET_AMF_FSM_STATE(p_amf_context, new_state) \
    do \
{ \
    SET_AMF_FSM_STATE_TRACE(AMF_FSM_NAME, \
            AMF_FSM_STATES_NAMES[GET_AMF_FSM_CURRENT_STATE(p_amf_context)], AMF_FSM_STATES_NAMES[new_state], \
            p_amf_context); \
    p_amf_context->current_amf_state = new_state; \
} \
while (0)

#define PRINT_CURRENT_NGAP_STATE(p_ngap_gb_ctx)\
    RRC_NGAP_TRACE(NGAP_INFO, "CURRENT NGAP STATE [%s]",\
            NGAP_FSM_STATES_NAMES[GET_NGAP_FSM_CURRENT_STATE(p_ngap_gb_ctx)]) 

#define PRINT_CURRENT_AMF_STATE(p_amf_context)\
    RRC_NGAP_TRACE(NGAP_INFO, "CURRENT AMF [%d] STATE [%s]",\
            p_amf_context->amf_id,\
            AMF_FSM_STATES_NAMES[GET_AMF_FSM_CURRENT_STATE(p_amf_context)])


UInt32 ngap_get_sd_from_header(UInt8 *p_header);
UInt32 ngap_get_sctp_sd(UInt32 *p_header);
UInt16 ngap_get_stream_id_from_header(UInt8 *p_header);
UInt16 ngap_get_stream_id(UInt16 *p_header);

#ifndef AMF_SIM_TESTING_ENABLE 
void ngap_set_sd_in_header
(
     UInt8  *p_header,
     UInt32 value
);

void ngap_set_sctp_sd
(
    UInt32  *p_header ,
    SInt32  value
);

void ngap_set_stream_from_header
(
    UInt8   *p_header,
    UInt16  value
);

void ngap_set_sctp_stream
(
    UInt16  *p_header,
    UInt16  value
);

/*NGAP_CONTEXT_CHANGES_START*/
ngap_ue_context_t* allocate_ngap_ue_context
(
    ngap_global_context_t   *p_ngap_gb_ctx,
    ue_index_t              ue_index,
    UInt32                  ran_ueid,
    UInt64                  amf_ueid 
);

UInt16 get_ran_ueid_using_ue_index(
        ngap_global_context_t   *p_ngap_gb_ctx, 
        ue_index_t              ue_index);

void ngap_create_ue_index_search_tree(
        ngap_global_context_t   *p_ngap_gb_ctx,
        ue_index_t              ue_index,
        UInt32                  ran_ueid
        );

ngap_ue_context_t*  get_ue_context_with_ran_id
(
    ngap_global_context_t   *p_ngap_gb_ctx,
    UInt32                  ran_ueid
);
/*NGAP_CONTEXT_CHANGES_STOP*/

UInt32  allocate_ran_ue_ngap_id
(
    ngap_global_context_t   *p_ngap_gb_ctx
);

void free_ran_ue_ngap_id
(
    ngap_global_context_t   *p_ngap_gb_ctx,  
    UInt32                  ran_ueid
);

ngap_return_et init_ran_ue_ngap_id_context 
(
    ngap_global_context_t   *p_ngap_gb_ctx
);

ngap_du_context_t *get_ngap_du_context_cell_index
(
    ngap_global_context_t   *p_ngap_gb_ctx,
    cell_index_t            cell_index
);

ngap_return_et init_ngap_ue_context 
(
    ngap_global_context_t   *p_ngap_gb_ctx
);

rrc_return_et ngap_rrc_send_internal_msg
(
    gnb_module_id_t     dst_module_id,  /* Destination module identifier */
    UInt16              api_id,         /* API Id */
    UInt16              msg_size,       /* Size of message (payload) */
    void                *p_msg          /* Message specific info (payload) */
);

ngap_amf_global_context*  get_amf_context_with_amf_id
(
    ngap_global_context_t   *p_ngap_gb_ctx, 
    UInt8                   amf_id
);

ue_index_t get_ue_index_with_ngap_ids
(
    ngap_global_context_t   *p_ngap_gb_ctx, 
    UInt32                  ran_ueid,
    UInt64                  amf_ueid
);

ngap_ue_context_t*  get_ue_context_with_ngap_ids
(
    ngap_global_context_t   *p_ngap_gb_ctx, 
    UInt32                  ran_ueid,
    UInt64                  amf_ueid 
);

ngap_ue_context_t*  get_ue_context_with_ue_index
(
    ngap_global_context_t   *p_ngap_gb_ctx, 
    ue_index_t              ue_index
);

void ngap_get_sctp_ip_addr( UInt8 *p_header );

void free_ngap_ue_context
(
    ngap_global_context_t   *p_ngap_gb_ctx, 
    ue_index_t              ue_index
);

ngap_return_et
rrc_update_amf_ngap_id_search_tree(
        ngap_global_context_t   *p_ngap_gb_ctx,
        ngap_ue_context_t       *p_ngap_ue_ctx,
        UInt64                  amf_ueid
);

#endif
#endif  /* _NGAP_UTILS_H_  */
