/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_types.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *  
 ***************************************************************************/
#ifndef _NGAP_TYPES_H_
#define _NGAP_TYPES_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/

/****************************************************************************
 * MACRO DEFINITIONS
 ****************************************************************************/

/* Macros for Numeric Numbers */
#define NGAP_ZERO					            0 
#define NGAP_ONE                                1
#define NGAP_TWO					            2
#define NGAP_THREE                              3
#define NGAP_FOUR					            4
#define NGAP_FIVE                   	        5
#define NGAP_SIX                                6
#define NGAP_SEVEN                              7
#define NGAP_EIGHT                              8
#define NGAP_NINE		              	        9

#define NGAP_P_NULL                             ((void*)0)
#define NGAP_NULL                               0


#define INVALID_VAL_ONE_BYTE                    0xFF
#define INVALID_VAL_TWO_BYTE                    0xFFFF
#define INVALID_VAL_FOUR_BYTE                   0xFFFFFFFF

#define MAX_AMF_SUPPORTED                       3
#define MAX_AMF_SCTP_ASSOCIATION_SUPPORTED      1
#define MAX_AMF_SCTP_STREAMS_SUPPORTED          2
#define MAX_NUM_SUPPORTED_PLMN_LIST             2

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/

typedef enum
{
    NG_LINK_DOWN,
    NG_LINK_UP,
    NG_LINK_UP_ONGOING,
    NG_NOT_INITITATED
} ng_link_status_et;

typedef enum
{
    NGAP_FALSE,
    NGAP_TRUE
} ngap_bool_et;

typedef enum
{
    NGAP_FAILURE,
    NGAP_SUCCESS,
    NGAP_PARTIAL_SUCCESS
} ngap_return_et;

/* NGAP Stack States */
typedef enum
{
    NGAP_IDLE_ST = NGAP_ZERO,
    M2AP_W_SCTP_CONNECT_SUCCESS_ST,
    NGAP_NOT_ACTIVE_ST,
    NGAP_W_SCTP_CONN_RECOVERY_ST,
    NGAP_W_NG_SETUP_RESP_ST,
    NGAP_NG_SETUP_FAIL_ST,	
    NGAP_ACTIVE_ST,
    NGAP_MAX_ST
} ngap_state_et;

typedef enum
{
    NGAP_AMF_IDLE_ST,
    NGAP_AMF_SCTP_CONN_ONGOING_ST,
    NGAP_AMF_SCTP_CONN_ACTIVE_ST,
    NGAP_AMF_SETUP_ONGOING_ST,
    NGAP_AMF_SETUP_FAIL_ST,
    NGAP_AMF_ACTIVE_ST,
    NGAP_AMF_RAN_CONFIG_UPDATE_ONGOING_ST,
    NGAP_AMF_RAN_CONFIG_UPDATE_FAIL_ST,
    NGAP_AMF_INVALID_ST
} ngap_amf_state_et;

typedef enum
{
    NGAP_EV_INVALID = NGAP_ZERO,
    NGAP_EV_INIT_TIMER_EXPIRY,
    NGAP_EV_OAM_NGAP_PROV_REQ,
    NGAP_EV_SCTP_SHUTDOWN,
    NGAP_EV_SCTP_CONN_FAILURE_IND,
    NGAP_EV_SCTP_CONN_RECOV_IND,
    NGAP_EV_SCTP_CONN_RECOV_TIMER_EXP,
    NGAP_EV_W_SCTP_CONNECT_TIMER_EXPIRY,
    NGAP_EV_SCTP_ASSOC_UP,
    NGAP_EV_SCTP_ASSOC_DOWN,
    NGAP_EV_NG_SETUP_RESP,
    NGAP_EV_NG_SETUP_FAILURE,
    NGAP_EV_NG_SETUP_RESP_TIMER_EXPIRY,
    NGAP_EV_NG_SETUP_TIME_TO_WAIT_TIMER_EXPIRY_IND,
    NGAP_EV_ERROR_IND,
    NGAP_EV_RESET_ACK_FROM_AMF,
    NGAP_EV_GNB_RESET_GUARD_TIMER_EXPIRY,
    NGAP_EV_MAX
} ngap_event_et;

typedef enum
{
    NGAP_INVALID_PROC = NGAP_ZERO,
    NGAP_INIT_PROC,
    NGAP_PROVISIONING_PROC,
    NGAP_NG_SETUP_PROC,
    NGAP_RESET_PROC,
    NGAP_SERVICE_DOWN_INTERNAL_PROC,
    INVALID_NGAP_PROC
} ngap_curr_ongoing_procedure_et;

typedef enum
{
    AMF_INVALID_PROC = NGAP_ZERO,
    AMF_NG_SETUP_PROC,
    AMF_RESET_PROC,
    AMF_RAN_CONFIG_UPD_PROC,
    AMF_CONFIG_UPD_PROC,
    AMF_SERVICE_DOWN_INTERNAL_PROC,
    INVALID_AMF_PROC
} ngap_curr_ongoing_amf_procedure_et;


#endif  /* _NGAP_TYPES_H_  */
