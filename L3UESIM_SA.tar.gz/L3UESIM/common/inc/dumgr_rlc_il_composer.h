/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2018 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file dumgr_rlc_il_composer.h contains the prototypes 
 *                     of DUMGR-RLC interface message composing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _DUMGR_RLC_IL_COMPOSER_H_
#define _DUMGR_RLC_IL_COMPOSER_H_

#include "gnb_defines.h"
#include "dumgr_rlc_intf.h"
#include "gnb_msg_mgmt.h"

gnb_length_t
gnb_il_get_dumgr_rlc_cell_config_req_len
(
    dumgr_rlc_cell_config_req_t *p_dumgr_rlc_cell_config_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_cell_config_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_cell_config_req_t *p_dumgr_rlc_cell_config_req
);

gnb_length_t
gnb_il_get_rlc_dumgr_cell_config_resp_len
(
    rlc_dumgr_cell_config_resp_t *p_rlc_dumgr_cell_config_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_cell_config_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_cell_config_resp_t *p_rlc_dumgr_cell_config_resp
);

gnb_length_t
gnb_il_get_rlc_dumgr_cell_delete_resp_len
(
    rlc_dumgr_cell_delete_resp_t *p_rlc_dumgr_cell_delete_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_cell_delete_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_cell_delete_resp_t *p_rlc_dumgr_cell_delete_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_purge_cell_ues_req_len
(
    dumgr_rlc_purge_cell_ues_req_t *p_dumgr_rlc_purge_cell_ues_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_purge_cell_ues_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_purge_cell_ues_req_t *p_dumgr_rlc_purge_cell_ues_req
);

gnb_length_t
gnb_il_get_rlc_dumgr_purge_cell_ues_resp_len
(
    rlc_dumgr_purge_cell_ues_resp_t *p_rlc_dumgr_purge_cell_ues_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_purge_cell_ues_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_purge_cell_ues_resp_t *p_rlc_dumgr_purge_cell_ues_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_create_ue_entity_req_len
(
    dumgr_rlc_create_ue_entity_req_t *p_dumgr_rlc_create_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_create_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_create_ue_entity_req_t *p_dumgr_rlc_create_ue_entity_req
);

gnb_length_t
gnb_il_get_rlc_dumgr_create_ue_entity_resp_len
(
    rlc_dumgr_create_ue_entity_resp_t *p_rlc_dumgr_create_ue_entity_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_create_ue_entity_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_create_ue_entity_resp_t *p_rlc_dumgr_create_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_reconfig_ue_entity_req_len
(
    dumgr_rlc_reconfig_ue_entity_req_t *p_dumgr_rlc_reconfig_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_reconfig_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_reconfig_ue_entity_req_t *p_dumgr_rlc_reconfig_ue_entity_req
);

gnb_length_t
gnb_il_get_rlc_dumgr_reconfig_ue_entity_resp_len
(
    rlc_dumgr_reconfig_ue_entity_resp_t *p_rlc_dumgr_reconfig_ue_entity_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_reconfig_ue_entity_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_reconfig_ue_entity_resp_t *p_rlc_dumgr_reconfig_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_delete_ue_entity_req_len
(
    dumgr_rlc_delete_ue_entity_req_t *p_dumgr_rlc_delete_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_delete_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_delete_ue_entity_req_t *p_dumgr_rlc_delete_ue_entity_req
);

gnb_length_t
gnb_il_get_rlc_dumgr_delete_ue_entity_resp_len
(
    rlc_dumgr_delete_ue_entity_resp_t *p_rlc_dumgr_delete_ue_entity_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_delete_ue_entity_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_delete_ue_entity_resp_t *p_rlc_dumgr_delete_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_srb_dl_data_ind_len
(
    dumgr_rlc_srb_dl_data_ind_t *p_dumgr_rlc_srb_dl_data_ind
);

gnb_return_t
gnb_il_compose_dumgr_rlc_srb_dl_data_ind
(
    UInt8  **pp_buffer,
    dumgr_rlc_srb_dl_data_ind_t *p_dumgr_rlc_srb_dl_data_ind
);

gnb_length_t
gnb_il_get_rlc_dumgr_srb_ul_data_ind_len
(
    rlc_dumgr_srb_ul_data_ind_t *p_rlc_dumgr_srb_ul_data_ind
);

gnb_return_t
gnb_il_compose_rlc_dumgr_srb_ul_data_ind
(
    UInt8  **pp_buffer,
    rlc_dumgr_srb_ul_data_ind_t *p_rlc_dumgr_srb_ul_data_ind
);

gnb_length_t
gnb_il_get_dumgr_rlc_re_establish_ue_entity_req_len
(
    dumgr_rlc_re_establish_ue_entity_req_t *p_dumgr_rlc_re_establish_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_rlc_re_establish_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_rlc_re_establish_ue_entity_req_t *p_dumgr_rlc_re_establish_ue_entity_req
);

gnb_length_t
gnb_il_get_dumgr_rlc_re_establish_ue_entity_resp_len
(
    dumgr_rlc_re_establish_ue_entity_resp_t *p_dumgr_rlc_re_establish_ue_entity_resp
);

gnb_return_t
gnb_il_compose_dumgr_rlc_re_establish_ue_entity_resp
(
    UInt8  **pp_buffer,
    dumgr_rlc_re_establish_ue_entity_resp_t *p_dumgr_rlc_re_establish_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_rlc_re_establish_ue_entity_complete_ind_len
(
    dumgr_rlc_re_establish_ue_entity_complete_ind_t *p_dumgr_rlc_re_establish_ue_entity_complete_ind
);

gnb_return_t
gnb_il_compose_dumgr_rlc_re_establish_ue_entity_complete_ind
(
    UInt8  **pp_buffer,
    dumgr_rlc_re_establish_ue_entity_complete_ind_t *p_dumgr_rlc_re_establish_ue_entity_complete_ind
);

gnb_length_t
gnb_il_get_rlc_dumgr_re_establish_ue_entity_complete_resp_len
(
    rlc_dumgr_re_establish_ue_entity_complete_resp_t *p_rlc_dumgr_re_establish_ue_entity_complete_resp
);

gnb_return_t
gnb_il_compose_rlc_dumgr_re_establish_ue_entity_complete_resp
(
    UInt8  **pp_buffer,
    rlc_dumgr_re_establish_ue_entity_complete_resp_t *p_rlc_dumgr_re_establish_ue_entity_complete_resp
);

gnb_length_t
gnb_il_get_rlc_dumgr_ue_max_retx_ind_len
(
    rlc_dumgr_ue_max_retx_ind_t *p_rlc_dumgr_ue_max_retx_ind
);

gnb_return_t
gnb_il_compose_rlc_dumgr_ue_max_retx_ind
(
    UInt8  **pp_buffer,
    rlc_dumgr_ue_max_retx_ind_t *p_rlc_dumgr_ue_max_retx_ind
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_cell_config_req
(
    dumgr_rlc_cell_config_req_t  *p_dumgr_rlc_cell_config_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_cell_config_resp
(
    rlc_dumgr_cell_config_resp_t  *p_rlc_dumgr_cell_config_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_cell_delete_resp
(
    rlc_dumgr_cell_delete_resp_t  *p_rlc_dumgr_cell_delete_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_purge_cell_ues_req
(
    dumgr_rlc_purge_cell_ues_req_t  *p_dumgr_rlc_purge_cell_ues_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_purge_cell_ues_resp
(
    rlc_dumgr_purge_cell_ues_resp_t  *p_rlc_dumgr_purge_cell_ues_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_create_ue_entity_req
(
    dumgr_rlc_create_ue_entity_req_t  *p_dumgr_rlc_create_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_create_ue_entity_resp
(
    rlc_dumgr_create_ue_entity_resp_t  *p_rlc_dumgr_create_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_reconfig_ue_entity_req
(
    dumgr_rlc_reconfig_ue_entity_req_t  *p_dumgr_rlc_reconfig_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_reconfig_ue_entity_resp
(
    rlc_dumgr_reconfig_ue_entity_resp_t  *p_rlc_dumgr_reconfig_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_delete_ue_entity_req
(
    dumgr_rlc_delete_ue_entity_req_t  *p_dumgr_rlc_delete_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_delete_ue_entity_resp
(
    rlc_dumgr_delete_ue_entity_resp_t  *p_rlc_dumgr_delete_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_srb_dl_data_ind
(
    dumgr_rlc_srb_dl_data_ind_t  *p_dumgr_rlc_srb_dl_data_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_srb_ul_data_ind
(
    rlc_dumgr_srb_ul_data_ind_t  *p_rlc_dumgr_srb_ul_data_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_re_establish_ue_entity_req
(
    dumgr_rlc_re_establish_ue_entity_req_t  *p_dumgr_rlc_re_establish_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_re_establish_ue_entity_resp
(
    dumgr_rlc_re_establish_ue_entity_resp_t  *p_dumgr_rlc_re_establish_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_rlc_re_establish_ue_entity_complete_ind
(
    dumgr_rlc_re_establish_ue_entity_complete_ind_t  *p_dumgr_rlc_re_establish_ue_entity_complete_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_re_establish_ue_entity_complete_resp
(
    rlc_dumgr_re_establish_ue_entity_complete_resp_t  *p_rlc_dumgr_re_establish_ue_entity_complete_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_rlc_dumgr_ue_max_retx_ind
(
    rlc_dumgr_ue_max_retx_ind_t  *p_rlc_dumgr_ue_max_retx_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

#endif /* _DUMGR_RLC_IL_COMPOSER_H_ */
