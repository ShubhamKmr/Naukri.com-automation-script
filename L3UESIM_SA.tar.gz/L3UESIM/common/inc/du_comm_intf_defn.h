/*******************************************************************************
 *                                                                             *
 * ARICENT -                                                                   *
 *                                                                             *
 * Copyright (C) 2018 Aricent Inc. All Rights Reserved.                        *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   FILE NAME: du_comm_intf_defn.h                                            *
 *                                                                             *
 *   DESCRIPTION: Definitions of internal structures used in interface API     *
 *                structures                                                   *
 *                                                                             *
 *       DATE                      REFERENCE                                   *
 *   --------------------------------------------------------------------------*
 *   23 June 2018                 MAC API v0.1                                 *
 *                                                                             *
 *                                                                             *
 *******************************************************************************/

#ifndef _DU_COMM_INTF_DEFN_H_
#define _DU_COMM_INTF_DEFN_H_

/*******************************************************************************
 * Project Includes
 ****************************************************************************/
#include "gnb_defines.h"
#include "du_types.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/
#define MAX_MIB_LENGTH                      10
#define MAX_SIB_LENGTH                      372    //2976 bits (Refer Section 5.1.3.2 of TS 38.214)
#define MAX_SIB1_LENGTH                     372    /* 2976 bits (Refer Section 5.1.3.2 of TS 38.214) */

/* In current release only one BWP is supported. */
#define MAX_BWP_COUNT                       1
#define MAX_CORESET_BWP_COUNT               3
#define SYMBOLS_IN_SLOT                     14
#define MAX_CORESET_COUNT                   11
#define MAX_COMMON_CORESET                  4
#define MAX_SEARCH_SPACE_COMMON_COUNT       4
#define MAX_SEARCH_SPACE_BWP_COUNT          10
#define MAX_SEARCH_SPACE_COUNT              40
#define MAX_DEFAULT_DL_ALLOCATION_COUNT     16
#define MAX_DL_ALLOCATION_COUNT             16
#define MAX_UL_ALLOCATION_COUNT             16
#define MAX_AGGREGATION_LEVELS              5 
#define MAX_CC_REGION                       2 
#define MAX_CCE_COUNT                       56 
#define MAX_RATE_MATCH_PATTERNS             4
#define MAX_RATE_MATCH_PATTERNS_PER_GROUP   8
#define RESOURCE_BLOCKS_INDEX               9
#define TWO_SLOTS_SYMBOLS                   2
#define MAX_SLOT_PERIODICITY                5
#define MAX_BETA_OFFSETS                    4
#define MAX_SR_CONFIG_PER_CELL_GROUP        8
#define MAX_NUM_PUCCH_RESOURCE_SETS         4
#define MAX_NUM_PUCCH_RESOURCES             128
#define MAX_NUM_SR_RESOURCES                8
#define MAX_SR_RESOURCES                    8
#define MAX_NUM_TAGS                        4
#define MAX_OLPC_TUPLE                      4
#define MAX_SSB_RESOURCES                   64
#define MAX_RATE_MTH_PATTERNS               (MAX_RATE_MATCH_PATTERNS - 1)
#define MAX_LC_COUNT                        32     
#define MAX_NUM_TAGS                        4     
#define MAX_NO_PUCCH_RESOURCE_SETS          4
#define MAX_NO_PUCCH_RESOURCES              128
#define MAX_NUM_HARQ_RESOURCES              128
#define MAX_NUM_PUCCH_RESOURCE_PER_SET      32 
#define MAX_PUCCH_RESOURCE_SETS             (MAX_NO_PUCCH_RESOURCE_SETS - 1)
#define MAX_PUCCH_RESOURCES                 (MAX_NO_PUCCH_RESOURCES - 1)
#define MAX_SR_RESOURCES_ID                 (MAX_SR_RESOURCES - 1)
#define MAX_UL_ACK_INDEX                    8
#define MAX_DU_MANAGER_UE_INDEX             0xFFFF
#define MIN_VAL_RNTI                        1
#define MAX_VAL_RNTI                        65519
#define MAX_IDX_PHYSICAL_RESOURCE_BLOCKS    274 
#define MAX_POSSIBLE_SLOTS_PER_RADIO_FRAME  80
#define MAX_SINR_AL_MCS_ROW_COUNT           10
#define MAX_SR_RELEASE_LIST                 8
#define NR_MAX_RB                           273
#define MAX_UL_CCCH_MSG_SIZE                8
#define MAX_DL_CCCH_MSG_SIZE                512
/*moved from mac_rlcl_intf.h*/
#define MAX_LC_ID                           32
#define MAX_NUM_P0_PUSCH_ALPHA_SETS         2
#define MAX_BATCH_SIZE                      25
/*19.4.19*/
#define MAX_NUM_ALPHA 8
#define MAX_NUM_PATHLOSS_TO_SINR_COUNT 10
#define MAX_NUM_DELTA_SINR_TO_TPC_MAP_COUNT 4
#define MAX_NUM_DELTA_BLER_TO_TPC_MAP_COUNT 4
/*19.4.19*/
#define MAX_NUM_PUSCH_RL_RS 4
#define MAX_NUM_PUCCH_RL_RS 4
#define MAX_PUSCH_RL_RS (MAX_NUM_PUSCH_RL_RS - 1)
#define MAX_PUCCH_RL_RS (MAX_NUM_PUCCH_RL_RS - 1)
#define MAX_P0_PUSCH_ALPHA_SETS (MAX_NUM_P0_PUSCH_ALPHA_SETS - 1)
#define MAX_NUM_P0_PUCCH_SETS               8

#define NR_QI_THRESHOLD4_4                  3
#define NR_QI_THRESHOLD8_8                  7
#define MAX_UE_TYPES                        3   
#define MAX_MCS_INDEX                       31
#define MAX_SINR_VALUE                      255
#define SINR_TO_ARRAY_INDEX                 256
#define MAX_DCI_CATEGORY                     3
#define MAX_CQI                              16
#define MAX_PO_PER_FRAME                    4
#define MAX_MSG_LEN                       255
#define MAX_MCS_INDEX_ARRAY               29 

#define MAX_NUM_NZP_CSI_RS_RESOURCES 192
#define MAX_NUM_NZP_CSI_RS_RESOURCE_PER_SET 64 
#define MAX_NUM_NZP_CSI_RS_RESOURCE_SET 64
#define MAX_NZP_RES_SETS_PER_CONFIG 16 
#define MAX_NUM_CSI_RESOURCE_CONFIG 112 
#define MAX_NUM_CSI_REPORT_CONFIG 48 
#define MAX_NUM_ZP_CSI_RS_RESOURCE 16

#define MAX_TCI_STATE_PDCCH 64
#define MAX_TCI_STATE_PDSCH 128
#define MAX_CSI_SSB_RES_SETS_PER_CONFIG 1
#define MAX_NUM_CSI_SSB_RESOURCE_SET 64
#define MAX_NUM_TXRU           4
#define MAX_SPATIAL_RELATIONINFO   8
#define MAX_PTRS_CONFIG_FREQ_DENSITY   2
#define MAX_PTRS_CONFIG_TIME_DENSITY   3
#define MAX_PTRS_CONFIG_SAMPLE_DENSITY 5

/*duoam_mac pmi precoder macros*/
#define MAX_NUM_PORTS  8
#define MAX_NUM_LAYERS  4
#define MAX_PMI_COUNT  2023

 
typedef UInt8              nr_bwp_count_t;
typedef UInt16             nr_rb_t;
typedef UInt32             nr_absolute_freq_t;
typedef UInt8              nr_coreset_id_t;
typedef UInt8              nr_search_space_id_t;
/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Project Constants
 ****************************************************************************/

/****************************************************************************
 * Project Structures
 ****************************************************************************/
/******************************************************************************
 *  API: DUMGR_MAC_CELL_CONFIG_REQ
*******************************************************************************/
/*19.4.19*/
/*
typedef enum {
    ALPHA_VALUE_0   = 0,
    ALPHA_VALUE_0_4 = 1,
    ALPHA_VALUE_0_5 = 2,
    ALPHA_VALUE_0_6 = 3,
    ALPHA_VALUE_0_7 = 4,
    ALPHA_VALUE_0_8 = 5,
    ALPHA_VALUE_0_9 = 6,
    ALPHA_VALUE_1   = 7
}alpha_t;
typedef UInt8 alpha_t;
*/
/*19.4.19*/
typedef enum 
{
    PUSCH_POWER_CNTRL_TWO_PUSCH_PC_ADJUSTMENT_STATES_ONE_STATES_1,
    PUSCH_POWER_CNTRL_TWO_PUSCH_PC_ADJUSTMENT_STATES_TWO_STATES_1
} pusch_power_cntrl_two_pusch_pc_adjustment_states_et;

typedef enum 
{
   PUCCH_POWER_CNTRL_TWO_PUCCH_PC_ADJUSTMENT_STATES_ONE_STATES,
   PUCCH_POWER_CNTRL_TWO_PUCCH_PC_ADJUSTMENT_STATES_TWO_STATES
} pucch_power_cntrl_two_pucch_pc_adjustment_states_et;

typedef enum {
    DUPLEX_MODE_FDD = 0,
    DUPLEX_MODE_TDD = 1 
}duplex_mode_et;
typedef UInt8 duplexing_mode_t;

typedef enum
{
    DOT5EVENPRB,
    DOT5ODDPRB,
    ONE,
    THREE
} nzp_csi_rs_resource_density_et;

typedef enum {
    NZP_CSI_RS_REOURCE_APERIODIC,
    NZP_CSI_RS_REOURCE_SEMI_PERSISTENT,
    NZP_CSI_RS_REOURCE_PERIODIC
}csi_rs_resource_type_et;

typedef enum {
    NZP_CSI_RS_REPETITION_ON,
    NZP_CSI_RS_REPETITION_OFF
}csi_rs_repetition_et;

typedef enum {
    NZP_DB_MINUS_8,
    NZP_DB_MINUS_7,
    NZP_DB_MINUS_6,
    NZP_DB_MINUS_5,
    NZP_DB_MINUS_4,
    NZP_DB_MINUS_3,
    NZP_DB_MINUS_2,
    NZP_DB_MINUS_1,
    NZP_DB_0,
    NZP_DB_1,
    NZP_DB_2,
    NZP_DB_3,
    NZP_DB_4,
    NZP_DB_5,
    NZP_DB_6,
    NZP_DB_7,
    NZP_DB_8,
    NZP_DB_9,
    NZP_DB_10,
    NZP_DB_11,
    NZP_DB_12,
    NZP_DB_13,
    NZP_DB_14,
    NZP_DB_15
} power_control_offset_et;

typedef enum {
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS4,   
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS5,   
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS8,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS10,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS16,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS20,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS32,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS40,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS64,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS80,  
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS160, 
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS320, 
    NZP_CSI_RESOURCE_PERIODICITY_AND_OFFSET_SLOTS640 
}csi_rs_periodicity_et;

typedef enum
{
    CYCLIC_PREFIX_NORMAL   = 0,
    CYCLIC_PREFIX_EXTENDED = 1
}nr_cyclic_prefix_et;
typedef UInt8 nr_cyclic_prefix_t;

typedef enum
{
    NR_FFT_SIZE_512        = 512,
    NR_FFT_SIZE_1024       = 1024,
    NR_FFT_SIZE_2048       = 2048,
    NR_FFT_SIZE_4096       = 4096
}nr_phy_fft_size_et;
typedef UInt16  nr_phy_fft_size_t;

typedef enum{
    DMRS_MAPPING_TYPEA     = 0,
    DMRS_MAPPING_TYPEB     = 1 
}dmrs_mapping_type_et;
typedef UInt8 dmrs_mapping_type_t;

typedef enum{
    DMRS_TYPEA_POS2    = 2,
    DMRS_TYPEA_POS3    = 3 
}dmrs_typeA_pos_et;
typedef UInt8 dmrs_typeA_pos_t;

typedef enum{
    DMRS_ADDITIONAL_POS0    = 0,
    DMRS_ADDITIONAL_POS1    = 1,
    DMRS_ADDITIONAL_POS2    = 2,
    DMRS_ADDITIONAL_POS3    = 3,
}dmrs_additional_pos_et;
typedef enum
{
    AGGR_LEVEL_1 = 0,
    AGGR_LEVEL_2,
    AGGR_LEVEL_4,
    AGGR_LEVEL_8,
    AGGR_LEVEL_16
}cce_aggr_level_et;
typedef UInt8 cce_aggr_level_t;

typedef enum{
    SAME_AS_REG_BUNDLE = 0,
    ALL_CONTIGUOUS_RBS = 1 
}crset_precoder_granularity_et;
typedef UInt8 crset_precoder_granularity_t;

typedef enum{
    NON_INTERLEAVED_CCE_REG_MAPPING    = 0,
    INTERLEAVED_CCE_REG_MAPPING        = 1
}crset_cce_reg_mapping_type_et;
typedef UInt8 crset_cce_reg_mapping_type_t;

typedef enum{
    CCE_REG_SIZE_N2    = 0,
    CCE_REG_SIZE_N4    = 1,
    CCE_REG_SIZE_N6    = 2
}interleaved_cce_reg_size_et;
typedef UInt8 interleaved_cce_reg_size_t;

typedef enum{
    PRACH_MSG1_FDM_ONE    = 0,
    PRACH_MSG1_FDM_TWO    = 1,
    PRACH_MSG1_FDM_FOUR   = 2,
    PRACH_MSG1_FDM_EIGHT  = 3
}prach_msg1_fdm_et;
typedef UInt8 prach_msg1_fdm_t;

typedef enum{
    PRACH_UNRESTRICTED_SET       = 0,
    PRACH_RESTRICTED_SET_TYPE_A  = 1,
    PRACH_RESTRICTED_SET_TYPE_B  = 2
}prach_restrict_set_et;
typedef UInt8 prach_restrict_set_t;

typedef enum{
    RAR_WINDOW_SIZE_SLOT_1     = 1,
    RAR_WINDOW_SIZE_SLOT_2     = 2,
    RAR_WINDOW_SIZE_SLOT_4     = 4,
    RAR_WINDOW_SIZE_SLOT_8     = 8,
    RAR_WINDOW_SIZE_SLOT_10    = 10,
    RAR_WINDOW_SIZE_SLOT_20    = 20,
    RAR_WINDOW_SIZE_SLOT_40    = 40,
    RAR_WINDOW_SIZE_SLOT_80    = 80,
}ra_rsp_window_size_et;
typedef UInt8 ra_rsp_window_size_t;


typedef enum{
    RA_MSG3_SIZE_GRPA_B56     = 56,
    RA_MSG3_SIZE_GRPA_B144    = 144,
    RA_MSG3_SIZE_GRPA_B208    = 208,
    RA_MSG3_SIZE_GRPA_B256    = 256,
    RA_MSG3_SIZE_GRPA_B282    = 282,
    RA_MSG3_SIZE_GRPA_B480    = 480,
    RA_MSG3_SIZE_GRPA_B640    = 640,
    RA_MSG3_SIZE_GRPA_B800    = 800,
    RA_MSG3_SIZE_GRPA_B1000   = 1000
}ra_msg3_size_grpA_et;
typedef UInt16     ra_msg3_size_grpA_t;

typedef enum
{
    MSG_PWR_OFFSET_GRPB_SF8   = 0,
    MSG_PWR_OFFSET_GRPB_SF16  = 1,
    MSG_PWR_OFFSET_GRPB_SF24  = 2,
    MSG_PWR_OFFSET_GRPB_SF32  = 3,
    MSG_PWR_OFFSET_GRPB_SF40  = 4,
    MSG_PWR_OFFSET_GRPB_SF48  = 5,
    MSG_PWR_OFFSET_GRPB_SF56  = 6,
    MSG_PWR_OFFSET_GRPB_SF64  = 7
}msg_pwr_offset_grpB_et;

typedef UInt8    msg_pwr_offset_grpB_t;

typedef enum
{
    N_TA_OFFSET_0         = 0,
    N_TA_OFFSET_N25600    = 1,
    N_TA_OFFSET_N39936    = 2
}n_ta_offset_et;

typedef UInt8    n_ta_offset_t;  

typedef enum{
    RA_CONT_RES_TIMER_SF8     = 8,
    RA_CONT_RES_TIMER_SF16    = 16,
    RA_CONT_RES_TIMER_SF24    = 24,
    RA_CONT_RES_TIMER_SF32    = 32,
    RA_CONT_RES_TIMER_SF40    = 40,
    RA_CONT_RES_TIMER_SF48    = 48,
    RA_CONT_RES_TIMER_SF56    = 56,
    RA_CONT_RES_TIMER_SF64    = 64 
}ra_cont_res_timer_et;
typedef UInt8      ra_cont_res_timer_t;

typedef enum{
    SSB_PER_RACH_OCC_ONE_EIGHTH     = 0,
    SSB_PER_RACH_OCC_ONE_FOURTH     = 1,
    SSB_PER_RACH_OCC_ONE_HALF       = 2,
    SSB_PER_RACH_OCC_ONE            = 3,
    SSB_PER_RACH_OCC_TWO            = 4,
    SSB_PER_RACH_OCC_FOUR           = 5,
    SSB_PER_RACH_OCC_EIGHT          = 6,
    SSB_PER_RACH_OCC_SIXTEEN        = 7
}ssb_per_rach_occ_et;
typedef UInt8 ssb_per_rach_occ_t;

typedef enum{
    NR_SCS_KHZ_15  = 0,
    NR_SCS_KHZ_30  = 1,
    NR_SCS_KHZ_60  = 2,
    NR_SCS_KHZ_120 = 3,
    NR_SCS_KHZ_240 = 4,
    NR_SCS_MAX
}nr_scs_et;
typedef UInt8 nr_scs_t;

typedef enum{
    SSB_PERIODICITY_5MS    = 0,
    SSB_PERIODICITY_10MS   = 1,
    SSB_PERIODICITY_20MS   = 2,
    SSB_PERIODICITY_40MS   = 3,
    SSB_PERIODICITY_80MS   = 4,
    SSB_PERIODICITY_160MS  = 5
}ssb_periodicity_et;
typedef UInt8 ssb_periodicity_t;

typedef enum{
    SSB_BURST_PATTERN_CASE_A = 0,
    SSB_BURST_PATTERN_CASE_B = 1,
    SSB_BURST_PATTERN_CASE_C = 2,
    SSB_BURST_PATTERN_CASE_D = 3,
    SSB_BURST_PATTERN_CASE_E = 4,
}ssb_burst_pattern_et;
typedef UInt8 ssb_burst_pattern_t;

typedef enum{
    TRANSMISSION_PERIODICITY_0P5_MS   = 0,
    TRANSMISSION_PERIODICITY_0P625_MS = 1,
    TRANSMISSION_PERIODICITY_1_MS     = 2,
    TRANSMISSION_PERIODICITY_1P25_MS  = 3,
    TRANSMISSION_PERIODICITY_2_MS     = 4,
    TRANSMISSION_PERIODICITY_2P5_MS   = 5,
    TRANSMISSION_PERIODICITY_5_MS     = 6,
    TRANSMISSION_PERIODICITY_10_MS    = 7
}tdd_dl_ul_transmission_periodicity_et;
typedef UInt8 tdd_dl_ul_transmission_periodicity_t;

typedef enum{
    PDCCH_MON_SLOT_PERIODICITY_1     = 1,
    PDCCH_MON_SLOT_PERIODICITY_2     = 2,
    PDCCH_MON_SLOT_PERIODICITY_4     = 4,
    PDCCH_MON_SLOT_PERIODICITY_5     = 5,
    PDCCH_MON_SLOT_PERIODICITY_8     = 8,
    PDCCH_MON_SLOT_PERIODICITY_10    = 10,
    PDCCH_MON_SLOT_PERIODICITY_16    = 16,
    PDCCH_MON_SLOT_PERIODICITY_20    = 20,
    PDCCH_MON_SLOT_PERIODICITY_40    = 40,
    PDCCH_MON_SLOT_PERIODICITY_80    = 80,
    PDCCH_MON_SLOT_PERIODICITY_160   = 160,
    PDCCH_MON_SLOT_PERIODICITY_320   = 320,
    PDCCH_MON_SLOT_PERIODICITY_640   = 640,
    PDCCH_MON_SLOT_PERIODICITY_1280  = 1280,
    PDCCH_MON_SLOT_PERIODICITY_2560  = 2560
}pdcch_mon_slot_periodicity_et;
typedef UInt16  pdcch_mon_slot_periodicity_t;

typedef enum{
    PDCCH_CANDIDATES_N0     = 0,
    PDCCH_CANDIDATES_N1     = 1,
    PDCCH_CANDIDATES_N2     = 2,
    PDCCH_CANDIDATES_N3     = 3,
    PDCCH_CANDIDATES_N4     = 4,
    PDCCH_CANDIDATES_N5     = 5,
    PDCCH_CANDIDATES_N6     = 6,
    PDCCH_CANDIDATES_N8     = 7
}nr_pdcch_candidates_et;
typedef UInt16  nr_pdcch_candidates_t;

typedef enum{
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_2 = 2,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_4 = 4,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_5 = 5,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_8 = 8,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_10 = 10,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_20 = 20,
    PDSCH_RATE_MATCH_SLOT_PERIODICITY_40 = 40
}pdsch_rate_match_slot_periodicity_et;
typedef UInt8   pdsch_rate_match_slot_periodicity_t;

typedef enum{
    PDSCH_XO_H0 = 0,
    PDSCH_XO_H6 = 6,
    PDSCH_XO_H12 = 12,
    PDSCH_XO_H18 = 18
}pdsch_x_over_head_et;
typedef UInt8 pdsch_x_over_head_t;

typedef enum{
    PDSCH_VRB_TO_PRB_INTERLEAVER_N2 = 2,
    PDSCH_VRB_TO_PRB_INTERLEAVER_N4 = 4
}pdsch_vrb_to_prb_interleaver_et;
typedef UInt8 pdsch_vrb_to_prb_interleaver_t;

typedef enum{
    PDSCH_AGGREGATION_FACTOR_N1 = 1,
    PDSCH_AGGREGATION_FACTOR_N2 = 2,
    PDSCH_AGGREGATION_FACTOR_N4 = 4,
    PDSCH_AGGREGATION_FACTOR_N8 = 8
}pdsch_aggregation_factor_et;
typedef UInt8 pdsch_aggregation_factor_t;

typedef enum{
    RATE_MATCH_PATTERN_MODE_DYNAMIC,
    RATE_MATCH_PATTERN_MODE_SEMISTATIC
}_rate_match_pattern_mode_et;
typedef UInt8   rate_match_pattern_mode_t;

typedef enum{
    DL = 0,
    UL = 1,
    BOTH = 2,
    BFR = 3
}coreset_type_et;
typedef UInt8   coreset_type_t;

typedef enum{
    kBps_0=0,
    kBps_8=1,
    kBps_16=2,
    kBps_32=3,
    kBps_64=4,
    kBps_128=5,
    kBps_256=6,
    kBps_512=7,
    kBps_1024=8,
    kBps_2048=9,
    kBps_4096=10,
    kBps_8192=11,
    kBps_16384=12,
    kBps_32768=13,
    kBps_65535=14,
    infinity=15,
}pbr_type_et;    

typedef enum{
    ms5=0,
    ms10=1,
    ms20=2,
    ms80=3,
    ms100=4,
    ms150=5,
    ms300=6,
    ms500=7,
    ms1000=8
}bsd_type_et;   

typedef enum{
    periodic_bsr_sf1=0,
    periodic_bsr_sf5=1,
    periodic_bsr_sf10=2,
    periodic_bsr_sf16=3,
    periodic_bsr_sf20=4,
    periodic_bsr_sf32=5,
    periodic_bsr_sf40=6,
    periodic_bsr_sf64=7,
    periodic_bsr_sf80=8,
    periodic_bsr_sf128=9,
    periodic_bsr_sf160=10,
    periodic_bsr_sf320=11,
    periodic_bsr_sf640=12,
    periodic_bsr_sf1280=13,
    periodic_bsr_sf2560=14,
    periodic_bsr_infinity=15
}periodic_bsr_type_et;

typedef enum
{
    RACH_SYNC_SUCCESS         = 0,
    OUT_OF_SYNC_INITIAL       = 1,
    IN_SYNC_AFTER_OUT_OF_SYNC = 2,
    OUT_OF_SYNC_MAX_RETRIES   = 3,
    IN_SYNC                   = 4
}ue_sync_status_ind_et;

typedef enum
{
    TYPE_PERIODIC,
    TYPE_SEMI_PERSISTENT_ON_PUCCH,
    TYPE_SEMI_PERSISTENT_ON_PUSCH,
    TYPE_APERIODIC
}csi_report_type_et;

typedef enum
{
    CO0DEBOOK_CONFIG_TYPE1_SINGLE_PANEL,
    CO0DEBOOK_CONFIG_TYPE1_MULTI_PANEL,
    CO0DEBOOK_CONFIG_TYPE2,
    CO0DEBOOK_CONFIG_TYPE2_PORT_SELECTION
}codebook_config_type_et;

typedef enum
{
    CODEBOOK_CONFIG_ONE_TX_CODEBOOK_SUBSET_RESTRCTIONS,
    CODEBOOK_CONFIG_TWO_TX_CODEBOOK_SUBSET_RESTRCTIONS,
    CODEBOOK_CONFIG_TWO_ONE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_TWO_TWO_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_FOUR_ONE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_THREE_TWO_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_SIX_ONE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_FOUR_TWO_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_EIGHT_ONE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_FOUR_THREE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_SIX_TWO_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_TWELVE_ONE_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_FOUR_FOUR_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_EIGHT_TWO_TYPEI_SP_RESTRICTION_PRESENT,
    CODEBOOK_CONFIG_SIXTEEN_ONE_TYPEI_SP_RESTRICTION_PRESENT,
}codebook_config_num_port_et;

typedef UInt8 ue_sync_status_ind_t;

typedef struct _pucch_format_2_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Number of PRBs in frequency domain for the PUCCH transmission */
  UInt8 num_prbs;
  /*^ M, 0, H, 0, 16 ^*/

  /* Number if symbols for PUCCH Transmission. */
  UInt8 num_of_symbols;
  /*^ M, 0, B, 1, 2 ^*/

  /* Starting symbol for PUCCH Transmission. */
  UInt8 Starting_symbol_index;
  /*^ M, 0, H, 0, 13 ^*/

}pucch_format_2_config_t;

typedef struct _pucch_format_1_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* 0 - 11 Initial Cyclic Shift as configured by Higher Layers */
  UInt8 initial_cyclic_shift;
  /*^ M, 0, H, 0, 11 ^*/

  /* 1 to 2 Number if symbols for PUCCH Transmission. */
  UInt8 num_of_symbols;
  /*^ M, 0, B, 4, 14 ^*/

  /* Starting symbol for PUCCH Transmission. */
  UInt8 Starting_symbol_index;
  /*^ M, 0, H, 0, 10 ^*/ 

  /* index for an Orthogonal Cover Code */
  UInt8 time_domain_occ;
  /*^ M, 0, H, 0, 6 ^*/ 

}pucch_format_1_config_t;

typedef struct _pucch_format_0_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* 0 - 11 Initial Cyclic Shift as configured by Higher Layers */
  UInt8 initial_cyclic_shift;
  /*^ M, 0, H, 0, 11 ^*/

  /* 1 to 2 Number if symbols for PUCCH Transmission. */
  UInt8 num_of_symbols;
  /*^ M, 0, B, 1, 2 ^*/

  /* Starting symbol for PUCCH Transmission. */
  UInt8 Starting_symbol_index;
  /*^ M, 0, H, 0, 13 ^*/ 

}pucch_format_0_config_t;


typedef struct _pucch_resource_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SECOND_HOP_PRB_ID_PRESENT        0x0001
#define PUCCH_FORMAT_0_PRESENT           0x0002
#define PUCCH_FORMAT_1_PRESENT           0x0004
#define PUCCH_FORMAT_2_PRESENT           0x0008

  /* 0  to MAX_NUM_PUCCH_RESOURCES -1  ID of a PUCCH Resource, in a list of PUCCH Resources, in a Resource set. */
  UInt8 pucch_resource_Id;
  /*^ M, 0, H, 0, MAX_PUCCH_RESOURCES ^*/

  /* Starting PRB index of the PUCCH Resource.For a PUCCH Format 0 resource, the RB allocated shall be an edge RB of the BWP. */
  UInt16 starting_prb;
  /*^ M, 0, H, 0, MAX_IDX_PHYSICAL_RESOURCE_BLOCKS ^*/
  
  /* Flag for Enabling/Disabling intra-slot frequency hopping */
  UInt8 intra_slot_frequency_hopping;
  /*^ M, 0, H, 0, 1 ^*/

  /* Flag for Enabling/Disabling intra-slot frequency hopping */
  UInt16 second_hop_prb_id;
  /*^ O, SECOND_HOP_PRB_ID_PRESENT, H, 0, MAX_IDX_PHYSICAL_RESOURCE_BLOCKS ^*/

  /* Selection of the PUCCH format 0 specific parameters, see TS 38.213, section 9.2. */
  pucch_format_0_config_t pucch_format_0_config;
  /*^ O, PUCCH_FORMAT_0_PRESENT, N, 0, 0 ^*/

  /* Selection of the PUCCH format 1 specific parameters, see TS 38.213, section 9.2. */
  pucch_format_1_config_t pucch_format_1_config;
  /*^ O, PUCCH_FORMAT_1_PRESENT, N, 0, 0 ^*/

  /* Selection of the PUCCH format 2 specific parameters, see TS 38.213, section 9.2. */
  pucch_format_2_config_t pucch_format_2_config;
  /*^ O, PUCCH_FORMAT_2_PRESENT, N, 0, 0 ^*/

}pucch_resource_config_t;


typedef struct _mac_peer_comm_info_t
{
#define COMM_INFO_DATA_BUFFER_SIZE_PRESENT    0x01

    /* Bitmask indicating presence of optional parameters */
    bitmask_t              bitmask;
    /*^ BITMASK ^*/

    /* Self IP/Port of MAC */
    communication_info_t   self_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* Destination IP/Port used by MAC */
    communication_info_t   peer_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* Maximum Number of Bytes to be received */
    UInt16                 data_buffer_size;
    /*^ O, COMM_INFO_DATA_BUFFER_SIZE_PRESENT , B, 1500, 65535 ^*/

} mac_peer_comm_info_t;

/* TS 38.213 - 11.1 Slot Configuration */
/* TS 38.331 - 6.3.2   ServingCellConfigCommon(tdd-UL-DL-ConfigurationCommon) */
typedef struct _tdd_ul_dl_pattern_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/

    UInt8                               dl_ul_transmission_periodicity;
    /*^ M, 0, H, 0, 7 ^*/

    UInt16                              num_dl_slots;
    /*^ M, 0, H, 0, 320 ^*/

    UInt8                               num_dl_symbols;
    /*^ M, 0, H, 0, 13 ^*/

    UInt16                              num_ul_slots;
    /*^ M, 0, H, 0, 320 ^*/

    UInt8                               num_ul_symbols;
    /*^ M, 0, H, 0, 13 ^*/

}tdd_ul_dl_pattern_t;

typedef struct _tdd_config_common_t
{
#define TDD_CONFIG_PATTERN2_PRESENT         0x0001
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/

    nr_scs_t                            reference_scs;
    /*^ M, 0, H, 0, 4 ^*/

    tdd_ul_dl_pattern_t                 pattern1;
    /*^ M, 0, N, 0, 0 ^*/

    tdd_ul_dl_pattern_t                 pattern2;
    /*^ O, TDD_CONFIG_PATTERN2_PRESENT, N, 0, 0 ^*/

}tdd_config_common_t;

typedef struct _ssb_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/

    /* TS 38.211 - 7.4.2.1 Physical-layer cell identities */
    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(physCellId) */
    nr_pci_t                              phy_cell_id;
    /*^ M, 0, H, 0, 1007 ^*/

    /* Indicates Subcarrier spacing for SIB1, Msg.2/4 for initial access, 
     * paging and broadcast SI-messages. */
    UInt8                              sub_carrier_spacing_common;
    /*^ M, 0, H, 0 , 1 ^*/

    /* Only SCS 120 kHz is supported in current release */
    nr_scs_t                              ssb_scs;
    /*^ M, 0, H, 0, 4 ^*/

    /* TS 38.331 - 6.2.2   MIB(ssb-SubcarrierOffset) */
    /* TS 38.211 - 7.4.3.1 Kssb */
    /* Kssb LSB 4 bits in MIB(ssb-SubcarrierOffset) and MSB 1bit in a(A+5) in PBCH Payload  */
    UInt8                                 ssb_subcarrier_offset;
    /*^ M, 0, H, 0, 31 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(ssb-periodicityServingCell) */
    /* TS 38.213 - 4.1     SSB-periodicityServingCell  */
    ssb_periodicity_t                     ssb_periodicity;
    /*^ M, 0, H, 0, 5 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(dmrs-TypeA-Position) */
    dmrs_typeA_pos_t                      dmrs_typeA_pos;
    /*^ M, 0, B, 2, 3 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(ssb-PositionsInBurst) */
    /* TS 38.213 - 4.1     SSB-transmitted */
    /* Bitmap for actually transmitted SSB. 
     * 0: not transmitted 1: transmitted.
     * MSB->LSB of first 32 bit number corresponds to SSB 0 to SSB 31
     * MSB->LSB of second 32 bit number corresponds to SSB 32 to SSB 63 */
    UInt32                                ssb_mask[2];
    /*^ M,0,OCTET_STRING,FIXED ^*/

    SInt8                                ssb_power;
    /*^ M, 0, B, MIN_SSB_POWER, MAX_SSB_POWER ^*/

    nr_cyclic_prefix_t                    ssb_cyclic_prefix;
    /*^ M, 0, H, 0, 1 ^*/

    /* TS 38.212 - 7.1.1   aHRF */
    /* 1 : first half frame, 0: not first half frame
     * a(A+4) in PBCH Payload  */
    UInt8                                 ssb_half_subframe;
    /*^ M, 0, H, 0, 1 ^*/

    /* Represents the offset to Point A as defined in 3GPP TS 38.211 Section 4.4.4.2 */
    UInt16                               offset_to_pointA;                   
    /*^ M, 0, H, 0, 2199 ^*/
}ssb_config_t;

typedef struct _bwp_info_t
{
#define DL_INITIAL_MCS_PRESENT         0x0001
#define UL_INITIAL_MCS_PRESENT         0x0002
#define PMAX_UL_POWER                  0x0004

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/

    /* TS 38.331 - 6.3.2   BWP(locationAndBandwidth) */
    /* locationAndBandwidth is interpreted as resource indicator value (RIV) as defined
     * TS 38.214 6.1.2.2.2 Uplink resource allocation type 1 with BWPsize 275, start_rb
     * and num_rb. To be encoded by Du-Mgr and send to UE */
    nr_rb_t                               start_rb;
    /*^ M, 0, H, 0, NR_MAX_PRB ^*/

    nr_rb_t                               num_rb;
    /*^ M, 0, B, 1, NR_MAX_PRB ^*/

    /* TS 38.331 - 6.3.2   BWP(subcarrierSpacing) */
    nr_scs_t                              bwp_scs;
    /*^ M, 0, H, 0, 4 ^*/

    SInt8                                 pmax_ul_power;
    /*^ O, PMAX_UL_POWER, B, -30, 33 ^*/

    /* TS 38.331 - 6.3.2   BWP(cyclicPrefix) */
    nr_cyclic_prefix_t                    bwp_cyclic_prefix;
    /*^ M, 0, H, 0, 1 ^*/
   
    /* Initial DL MCS value would be present when bwp_info_t is a part of dl_bwp_config */
    UInt8                                 init_dl_mcs;
    /*^ O, DL_INITIAL_MCS_PRESENT, H, 0, 28 ^*/

    /* Initial UL MCS value would be present when bwp_info_t is a part of ul_bwp_config */
    UInt8                                 init_ul_mcs;
    /*^ O, UL_INITIAL_MCS_PRESENT, H, 0, 28 ^*/

}bwp_info_t;

typedef struct _crset_cce_reg_interleaved_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_CCE_REG_SHIFT_INDEX_PRESENT         0x0001

    interleaved_cce_reg_size_t            reg_bundle_size;    
    /*^ M, 0, H, 0, 2 ^*/

    interleaved_cce_reg_size_t            interleaver_size;   
    /*^ M, 0, H, 0, 2 ^*/

    UInt16                                shift_index;    
    /*^ O, NR_CCE_REG_SHIFT_INDEX_PRESENT, H, 0, NR_MAX_PRB ^*/
}crset_cce_reg_interleaved_info_t;

/* TS 38.331 - ControlResourceSet */
typedef struct _coreset_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_CCE_REG_INTERLEAVED_MAPPING_PRESENT         0x0001

    /* TS 38.331 - 6.3.2   ControlResourceSet(controlResourceSetId) */
    nr_coreset_id_t                  coreset_id;
    /*^ M, 0, B, 1, 11 ^*/

    /* TS 38.331 - 6.3.2   ControlResourceSet(duration) */
    /* TS 38.211, section 7.3.2.2 Contiguous time duration of the CORESET in number of symbols */
    UInt8                            num_symbols;
    /*^ M, 0, B, 1, 3 ^*/

    /* Indicates the type of coreset to be used for Downlink PDCCH 
     * allocation or Uplink PDCCH allocation. In case particular 
     * coreset is configured as BOTH then all coreset shall be handled 
     * as available for both downlink and uplink PDCCH. */
    coreset_type_t                   coreset_type;
    /*^ M, 0, H, 0, 3 ^*/

    /* TS 38.331 - 6.3.2   ControlResourceSet(frequencyDomainResources) */
    /* Bitmap for coreset RBs.Each bit corresponds a group of 6 RBs with grouping starting from PRB 0  
     * 0: RB not used for coreset 1: 6 RB used for coreset.
     * MSB->LSB of first 32 bit number corresponds to RB group 0 to 31
     * MSB->LSB of second 13 bit number corresponds to RB group 32 to 44
     * LSB      of second 19 bits are unused */
    UInt32                           freq_domain_resources[2];
    /*^ M,0,OCTET_STRING,FIXED ^*/

    /* TS 38.331 - 6.3.2   ControlResourceSet(cce-REG-MappingType) */
    /* Only nonInterleaved mapping type is supported in current release */
    crset_cce_reg_mapping_type_t           cce_reg_mapping_type;
    /*^ M, 0, H, 0, 1 ^*/

    /* This IE is not supported in current release */
    crset_cce_reg_interleaved_info_t       cce_reg_interleaved_info;
    /*^ O, NR_CCE_REG_INTERLEAVED_MAPPING_PRESENT, N, 0, 0 ^*/

    /* TS 38.331 - 6.3.2   ControlResourceSet(precoderGranularity) */
    crset_precoder_granularity_t       precoder_granularity;
    /*^ M, 0, N, 0, 1 ^*/

}coreset_config_t;

typedef struct _search_space_common_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

   /* If configured, the UE monitors the DCI formats 0_0 and 1_0 with CRC scrambled by C-RNTI,
    * CS-RNTI (if configured), SP-CSI-RNTI (if configured), RA-RNTI, TC-RNTI, P-RNTI, SI-RNTI */
   UInt8  dci_format_0_0_and_1_0;
    /*^ M, 0, H, 0, 1 ^*/

   /* If configured, UE monitors the DCI format format 2_1 with CRC scrambled by INT-RNTI */
    /* This IE is not supported in current release */
   UInt8  dci_format_2_1;
    /*^ M, 0, H, 0, 1 ^*/

   /* If configured, UE monitors the DCI format 2_2 with CRC scrambled by TPC-PUSCH-RNTI or TPC-PUCCH-RNTI */
    /* This IE is not supported in current release */
   UInt8  dci_format_2_2;
    /*^ M, 0, H, 0, 1 ^*/

   /* If configured, UE monitors the DCI format format 2_0 with CRC scrambled by SFI-RNTI */
    /* This IE is not supported in current release */
   UInt8  dci_format_2_0;
    /*^ M, 0, H, 0, 1 ^*/

   /* If configured, UE monitors the DCI format 2_3 with CRC scrambled by TPC-SRS-RNTI */
    /* This IE is not supported in current release */
   UInt8  dci_format_2_3;
    /*^ M, 0, H, 0, 1 ^*/

}search_space_common_t;

typedef struct _search_space_ue_specific_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

   /* Indicates whether the UE monitors in this USS for DCI formats 0-0 and 1-0 or for formats 0-1 and 1-1.*/ 
   UInt8  dci_format;
    /*^ M, 0, H, 0, 1 ^*/
}search_space_ue_specific_t;

/* TS 38.331 - SearchSpace */
typedef struct _search_space_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_SEARCH_SPACE_TYPE_COMMON_PRESENT         0x0001
#define NR_SEARCH_SPACE_TYPE_UE_SPECIFIC_PRESENT    0x0002
#define NR_SEARCH_SPACE_DURATION_PRESENT            0x0004

    /* TS 38.331 - 6.3.2   SearchSpace (searchSpaceId) */
    nr_search_space_id_t             search_space_id;
    /*^ M, 0, B, 1, 39 ^*/

    nr_coreset_id_t                  coreset_id;
    /*^ M, 0, H, 0, 11 ^*/
      pdcch_mon_slot_periodicity_t    pdcch_slot_periodicity;
      //pdcch_mon_slot_periodicity_et    pdcch_slot_periodicity;
   /*^ M, 0, H, 0, 2560 ^*/

    UInt16                           pdcch_slot_offset;
    /*^ M, 0, H, 0, 2559 ^*/

    UInt16                           search_space_duration;
    /*^ O, NR_SEARCH_SPACE_DURATION_PRESENT, B, 2, 2559 ^*/

    UInt16                           pdcch_symbols_in_slot;
    /*^ M, 0, H, 0, 65535 ^*/

    nr_pdcch_candidates_t            pdcch_candidates[MAX_AGGREGATION_LEVELS];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    search_space_common_t            search_space_common;       
    /*^ O, NR_SEARCH_SPACE_TYPE_COMMON_PRESENT, N, 0, 0 ^*/

    search_space_ue_specific_t       search_space_ue_specific;        
    /*^ O, NR_SEARCH_SPACE_TYPE_UE_SPECIFIC_PRESENT, N, 0, 0 ^*/
}search_space_config_t;

/* TS 38.331 - 6.3.2 PDCCH-ConfigCommon */
typedef struct _pdcch_common_config_t
{
#define PDCCH_CORESET_ZERO_PRESENT          0x0001
#define PDCCH_COMMON_CORESET_PRESENT        0x0002
#define PDCCH_SEARCH_SPACE_ZERO_PRESENT     0x0004
#define PDCCH_COMMON_SEARCH_SPACE_PRESENT   0x0008
#define PDCCH_RA_SEARCH_SPACE_PRESENT       0x0010
#define PDCCH_SIB1_SEARCH_SPACE_PRESENT     0x0020
#define PDCCH_OTHER_SI_SEARCH_SPACE_PRESENT 0x0040
#define PDCCH_PAGING_SEARCH_SPACE_PRESENT   0x0080

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    /* TS 38.331 - 6.3.2   PDCCH-ConfigCommon(controlResourceSetZero) */
    /* 4 MSB bits of IE pdcch-ConfigSIB1 in MIB */
    UInt8                                 coreset_zero;
    /*^ O, PDCCH_CORESET_ZERO_PRESENT, H, 0, 15 ^*/

    /* TS 38.331 - 6.3.2   PDCCH-ConfigCommon(commonControlResourceSet) */
    coreset_config_t                      common_coreset;
    /*^ O, PDCCH_COMMON_CORESET_PRESENT, N, 0, 0 ^*/

    /* TS 38.331 - 6.3.2   PDCCH-ConfigCommon(searchSpaceZero) */
    /* 4 LSB bits of IE pdcch-ConfigSIB1 in MIB */
    UInt8                                 search_space_zero;
    /*^ O, PDCCH_SEARCH_SPACE_ZERO_PRESENT, H, 0, 15 ^*/

    /* TS 38.331 - 6.3.2   PDCCH-ConfigCommon(commonSearchSpace) */
    /* Only 1 search space for RAR will be supported in current release */
    UInt8                                 search_space_count;
    /*^ O, PDCCH_COMMON_SEARCH_SPACE_PRESENT, B, 1, 4 ^*/

    search_space_config_t       search_space_config[MAX_SEARCH_SPACE_COMMON_COUNT];
    /*^ O, PDCCH_COMMON_SEARCH_SPACE_PRESENT, OCTET_STRING, VARIABLE ^*/

    nr_search_space_id_t                  ra_search_space_id;
    /*^ O, PDCCH_RA_SEARCH_SPACE_PRESENT, H, 0, 4 ^*/

    /* This IE is not supported in current release */
    nr_search_space_id_t                  sib1_search_space_id;
    /*^ O, PDCCH_SIB1_SEARCH_SPACE_PRESENT, H, 0, 4 ^*/

    /* This IE is not supported in current release */
    nr_search_space_id_t                  other_si_search_space_id; 
    /*^ O, PDCCH_OTHER_SI_SEARCH_SPACE_PRESENT, H, 0, 4 ^*/

    /* This IE is not supported in current release */
    nr_search_space_id_t                  paging_search_space_id;
    /*^ O, PDCCH_PAGING_SEARCH_SPACE_PRESENT, H, 0, 4 ^*/


}pdcch_common_config_t;

typedef struct _pdsch_res_alloc_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    /* TS 38.331 - 6.3.2 PDSCH-TimeDomainResourceAllocation(k0) */
    /* k0 = 0 is only supported in current release */
    UInt8                                 k0;
    /*^ M, 0, H, 0, 32 ^*/

    /* TS 38.331 - 6.3.2 PDSCH-TimeDomainResourceAllocation(mappingType) */
    /* DMRS TypeA is only supported in current release */
    dmrs_mapping_type_t                   dmrs_mapping_type;
    /*^ M, 0, H, 0, 1 ^*/

    /* TS 38.331 - 6.3.2 PDSCH-TimeDomainResourceAllocation(startSymbolAndLength) */
    /* TS 38.214 Table 5.1.2.1-1: Valid S and L combinations */
    /* startSymbolAndLength is interpreted as SLIV as defined TS 38.214 5.1.2.1, start_symbol
     * and length. To be encoded by Du-Mgr and send to UE */
    /* start_symbol = 3 for TypeA is only supported in current release */
    UInt8                                 start_symbol;
    /*^ M, 0, H, 0, 12 ^*/

    /* length = 11 for TypeA is only supported in current release */
    UInt8                                 length;
    /*^ M, 0, B, 2, 14 ^*/

}pdsch_res_alloc_t;

/* TS 38.331 - 6.3.2 PDSCH-ConfigCommon */
/* Configure a time domain relation between PDCCH and PDSCH. 
 * The PDSCH-TimeDomainResourceAllocationList contains one or more of such PDSCH-TimeDomainResourceAllocations.
 * The network indicates in the DL assignment which of the configued time domain allocations the UE shall apply for that DL assignment.
 * The UE determines the bit width of the DCI field based on the number of entries in the PDSCH-TimeDomainResourceAllocationList.
 * Value 0 in the DCI field refers to the first element in this list, value 1 in the DCI field refers to the second element in this list, and so on */

typedef struct _pdsch_common_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8                                 count;
    /*^ M, 0, B, 1, 16 ^*/

    /* only 1 timedomain resource allocation is supported in current release  */
    pdsch_res_alloc_t           pdsch_res_alloc[MAX_DL_ALLOCATION_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pdsch_common_config_t;

typedef enum
{
    MOD_PER_COEFF_N2              = 0,
    MOD_PER_COEFF_N4              = 1,
    MOD_PER_COEFF_N8              = 2,
    MOD_PER_COEFF_N16             = 3
}mod_period_coeff_et;

typedef UInt8    mod_period_coeff_t;

typedef struct
{
    mod_period_coeff_t    mod_period_coeff;
    /*^ M, 0, H, 0, 3 ^*/   /* rrm_modif_period_coeff_et */
}bcch_config_t;

typedef enum
{
    DEF_PAGING_CYCLE_RF32              = 0,
    DEF_PAGING_CYCLE_RF64              = 1,
    DEF_PAGING_CYCLE_RF128             = 2,
    DEF_PAGING_CYCLE_RF256             = 3   
}default_paging_cycle_et;

typedef UInt32    default_paging_cycle_t;  

typedef enum
{
    PAGING_NVAL_ONET            = 0,
    PAGING_NVAL_HALFT           = 1,
    PAGING_NVAL_QUATERT         = 2,
    PAGING_NVAL_ONEEIGHTH       = 3,
    PAGING_NVAL_ONESIXTEENTH    = 4
}paging_n_val_et;

typedef UInt16 paging_n_val_t;

typedef enum
{
    PAGING_OCC_PER_PAGING_FRAME_FOUR              = 0,
    PAGING_OCC_PER_PAGING_FRAME_TWO               = 1,
    PAGING_OCC_PER_PAGING_FRAME_ONE               = 2    
}paging_Occation_Per_Paging_Frame_et;

typedef UInt32    paging_Occation_Per_Paging_Frame_t; 

typedef enum
{
    SCS_15KH_ONET                                           = 0,
    SCS_30KH_ONE_15KH_HALFT                                 = 1,
    SCS_60KH_ONE_30KH_HALF_5KH_QUARTERT                     = 2,    
    SCS_120KH_ONE_60KH_HALF_30KH_QUATER_15KH_EIGHTHT        = 3,
    SCS_120KH_HALF_60KH_QUARTER_30KH_EIGHT_5KH_SIXTEENTHT   = 4,
    SCS_120KH_QUARTER_60KH_EIGHTHT_30KH_SIXTEENTHT          = 5,
    SCS_120KH_EIGHT_60KH_SIXTEENTHT                         = 6,
    SCS_120KH_SIXTEENTHT                                    = 7
}first_pdcch_monitoring_occ_scs_type_et;

typedef UInt16  first_pdcch_monitoring_occ_scs_type_t;

typedef struct _first_pdcch_monitoring_occ_info_t
{
    first_pdcch_monitoring_occ_scs_type_t  scs_type;
    /*^ M, 0, H, 0, 7 ^*/

    /* Number of paging occasions */
    UInt8         count;
     /*^ M, 0, B, 1, 4 ^*/

    /*Points out the first PDCCH monitoring occasion */
    UInt16        First_pdcch_monitoring_occ[MAX_PO_PER_FRAME];
     /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}first_pdcch_monitoring_occ_info_t;

typedef struct _pcch_config_common_t
{
#define FIRST_PDCCH_MONITORING_OCC_TYPE_PRESENT     0x0001

     /* Bitmask indicating the presence of optional fields */
     bitmask_t                           bitmask;
     /*^ BITMASK ^*/
    
    /* Default paging cycle, used to derive 'T' in 3GPP TS 38.304 Section 7. 
     * Value rf32 corresponds to 32 radio frames, 
     * value rf64 corresponds to 64 radio frames and so on. */
    default_paging_cycle_t    		    default_paging_cycle;
    /*^ M, 0, H, 0, 3 ^*/       

    /* Used to derive the number of total paging frames in T 
     * (corresponding to parameter N in TS 38.304) */
    paging_n_val_t                     n_value;
     /*^ M, 0, H, 0, 4 ^*/ 

    /* paging frame offset (corresponding to parameter PF_offset in TS 38.304 [20]).
     * This field have below possible values with respect to n_val:
     * n_val = 0, pf_offset is 0.
     * n_val = 1, pf_offset = {0..1}
     * n_val = 2, pf_offset = {0..3}
     * n_val = 3, pf_offset = {0..7}
     * n_val = 4, pf_offset = {0..15} */
    UInt8     				            paging_frame_offset;
    /*^ M, 0, H, 0, 15 ^*/      

    /* Number of paging occasions per paging frame */
    paging_Occation_Per_Paging_Frame_t  ns_value;
    /*^ M, 0, H, 0, 2 ^*/       

    first_pdcch_monitoring_occ_info_t   first_pdcch_monitoring_occ_info;
    /*^ O, FIRST_PDCCH_MONITORING_OCC_TYPE_PRESENT, N, 0, 0 ^*/
}pcch_config_common_t;

typedef struct _dl_bwp_common_config_t
{
#define NR_PDCCH_COMMON_CONF_PRESENT     0x0001
#define NR_PDSCH_COMMON_CONF_PRESENT     0x0002
#define NR_BCCH_CONFIG_PRESENT           0x0004
#define NR_PCCH_COMMON_CONF_PRESENT      0x0008

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                   bitmask; 
    /*^ BITMASK ^*/

    pdcch_common_config_t       pdcch_common_config;
    /*^ O, NR_PDCCH_COMMON_CONF_PRESENT, N, 0, 0 ^*/

    pdsch_common_config_t       pdsch_common_config;
    /*^ O, NR_PDSCH_COMMON_CONF_PRESENT, N, 0, 0 ^*/

    bcch_config_t              bcch_config;
    /*^ O, NR_BCCH_CONFIG_PRESENT, N, 0, 0 ^*/

    pcch_config_common_t       pcch_config_common;
   /*^ O, NR_PCCH_COMMON_CONF_PRESENT, N, 0, 0 ^*/
}dl_bwp_common_config_t;

/* TS 38.331 - 6.3.2 PDCCH-Config */
typedef struct _pdcch_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8                             coreset_count;
    /*^ M, 0, B, 1, 3 ^*/

    coreset_config_t                  coreset_config[MAX_CORESET_BWP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

    UInt8                             search_space_count;
    /*^ M, 0, B, 1, 10 ^*/

    search_space_config_t             search_space[MAX_SEARCH_SPACE_BWP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pdcch_dedicated_config_t;  
  
typedef struct _bitmaps_config_t
{
bitmask_t bitmask;    
/*^ BITMASK ^*//* To inform optional parameter presence */
#define RB_SYMBOL_ONE_SLOT_PRESENT 0x0001 
#define RB_SYMBOL_TWO_SLOT_PRESENT 0x0002
#define PERIODICITY_PRESENT 0x0004
#define PATTERN_PRESENT 0x0008

UInt32  resource_block[RESOURCE_BLOCKS_INDEX];
/*^ M, 0, OCTET_STRING, FIXED ^*/
/* 275bits. The LSB 13 bits are of index 9 are unused. Each bit corresponds a group of 1 RB. 
The most significant bit of the first index corresponds to the most significant bit. */
 
UInt16  resource_block_symbol_one_slot;
/*^ O, RB_SYMBOL_ONE_SLOT_PRESENT, H, 0, 16380 ^*/
/* 14 bits. The LSB 2 bits are unused Each bit corresponds to 1 OFDM symbol. The most significant bit of the parameter corresponds to the most significant bit. */

UInt16  resource_block_symbol_two_slot[TWO_SLOTS_SYMBOLS];
/*^ O, RB_SYMBOL_TWO_SLOT_PRESENT, OCTET_STRING, FIXED ^*/ /* 28 bits. The LSB 4 bits are unused Each bit corresponds to 1 OFDM symbol. 
The most significant bit of the parameter corresponds to the most significant bit. */

pdsch_rate_match_slot_periodicity_t slot_periodicity;
/*^ O, PERIODICITY_PRESENT, B, 2, 40 ^*/ /* Enum; A time domain repetition pattern periodicity */

UInt8  slot_pattern[MAX_SLOT_PERIODICITY];
/*^ O, PATTERN_PRESENT, OCTET_STRING, FIXED ^*//* 40 bits. The LSB 8 bits are unused. Each bit corresponds to 1 OFDM symbol. 
The most significant bit of the parameter corresponds to the most significant bit. */

}bitmaps_config_t;

typedef struct _rate_match_pattern_config_t
{
bitmask_t bitmask;    
/*^ BITMASK ^*//* To inform optional parameter presence */
#define CORESET_PRESENT 0x0001
#define BITMAPS_PRESENT 0x0002
#define SUBCARRIER_SPACING_PRESENT  0x0004
#define RATE_MATCH_PATTERN_MODE_PRESENT 0x0008

UInt8 rate_match_pattern_Id;
/*^ M, 0, H, 0, MAX_RATE_MTH_PATTERNS ^*/ /*  The 1 corresponds to the value 1, n2 corresponhds to value 2, and so on. Corresponds to L1 parameter 'K0' (see 38.214) 
When the field is absent the UE applies the value 0 */

UInt8 coreset_id;
/*^ O, CORESET_PRESENT, H, 0, MAX_CORESET_COUNT ^*/ /* ControlResourceSet  used as a PDSCH rate matching pattern, i.e., PDSCH reception rate matches around it. */

bitmaps_config_t  bitmaps_config;
/*^ O, BITMAPS_PRESENT, N, 0, 0 ^*/ /* Bitmaps used as PDSCH rate match pattern. */

nr_scs_t  sub_carrier_spacing;  
/*^ O, SUBCARRIER_SPACING_PRESENT, H, 0, 4 ^*/ /* Subcarrier spacing of the resource pattern. If not present the SCS of associated BWP will be used */

rate_match_pattern_mode_t mode;
/*^ O, RATE_MATCH_PATTERN_MODE_PRESENT, H, 0, 1 ^*/ /* Cell level parameter for dynamic or semistatic config */

}rate_match_pattern_config_t;

typedef struct _pdsch_rate_match_pattern_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8                             rate_match_pattern_count;
    /*^ M, 0, B, 1, 4 ^*/

    rate_match_pattern_config_t       rate_match_patter[MAX_RATE_MATCH_PATTERNS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pdsch_rate_match_pattern_list_t; 

typedef struct _pdsch_alloc_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8                             count;
    /*^ M, 0, B, 1, 16 ^*/

    pdsch_res_alloc_t                 pdsch_allocation[MAX_DL_ALLOCATION_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pdsch_alloc_list_t;

typedef struct _csi_rs_resource_mapping_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SYMBOL_IN_TIME_DOMAIN_2_PRESENT 0x0001
  /* Row Number configured  by higher layers in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt8 freq_domain_allocation_row; 
  /*^ M, 0, B, 1, 18 ^*/

  /* Bitmap configured  by higher layers in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt16 freq_domain_allocation_bitmap; 
  /*^ M, 0, N, 0, 0 ^*/
  
  /* Time Domain allocation in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt8 first_symbol_in_time_domain; 
  /*^ M, 0, H, 0, 13 ^*/

  /* Density in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt8 density; 
  /*^ M, 0, H, 0, 3 ^*/

  /* RB start position in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt16 start_rb; 
  /*^ M, 0, H, 0, 274 ^*/

  /* Num RB in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt16 num_rb; 
  /*^ M, 0, B, 24, 276 ^*/

  /* Time Domain allocation 2 in CSI-RS-ResourceMapping (3GPP TS 38.331) */
  UInt8 first_symbol_in_time_domain2; 
  /*^ O, SYMBOL_IN_TIME_DOMAIN_2_PRESENT, B, 2, 12 ^*/

}csi_rs_resource_mapping_t;
typedef struct _zp_csi_rs_resource_t
{
  /* ZP CSI resource Id configured  by higher layers. */
  UInt8 zp_csi_rs_resource_id; 
  /*^ M, 0, H, 0, 31 ^*/

  /* ZP CSI resource Type configured  by higher layers. */
  UInt8 resource_type; 
  /*^ M, 0, H, 0, 2 ^*/

  /* Refer CSI-RS-ResourceMapping in ZP-CSI-RS-Resource(3GPP TS 38.331) */
  csi_rs_resource_mapping_t resource_mapping; 
  /*^ M, 0, N, 0, 0 ^*/

  /* ZP periodicity configured  by higher layers. */
  UInt8 periodicity;
  /*^ M, 0, H, 0, 12 ^*/ /*csi_rs_periodicity_et*/

  /* ZP resource Offset configured  by higher layers. */
  UInt16 offset;
  /*^ M, 0, H, 0, 639 ^*/

}zp_csi_rs_resource_t;

typedef struct _zp_csi_rs_res_to_add_mod_info_t
{
  /* Count for ZP resources configured  by higher layers. */
  UInt8 zp_csi_rs_res_to_add_mod_count;
  /*^ M, 0, B, 1, 16 ^*/

  /* Refer ZP-CSI-RS-Resource in Pdsch-Config (3GPP TS 38.331) */
  zp_csi_rs_resource_t zp_csi_rs_resource[MAX_NUM_ZP_CSI_RS_RESOURCE];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}zp_csi_rs_res_to_add_mod_info_t;


/* TS 38.331 - 6.3.2 PDSCH-Config */
typedef struct _pdsch_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_DEDICATED_RATE_MATCH_PATTERN_PRESENT     0x0001
#define NR_DEDICATED_PDSCH_RES_ALLOC_PRESENT        0x0002
#define NR_DEDICATED_ZP_RESOURCE_CONFIG_PRESENT     0x0004

    pdsch_rate_match_pattern_list_t      pdsch_rate_match_pattern_list;
    /*^ O, NR_DEDICATED_RATE_MATCH_PATTERN_PRESENT, N, 0, 0 ^*/

    pdsch_alloc_list_t              pdsch_time_domain_resource_allocation;
    /*^ O, NR_DEDICATED_PDSCH_RES_ALLOC_PRESENT, N, 0, 0 ^*/

    /* Refer ZP-CSI-RS-Resource in PDSCH-Config (3GPP TS 38.331) */
    zp_csi_rs_res_to_add_mod_info_t zp_csi_rs_res_to_add_mod_info;
    /*^ O, NR_DEDICATED_ZP_RESOURCE_CONFIG_PRESENT, N, 0, 0 ^*/

}pdsch_dedicated_config_t;  

typedef struct _dl_bwp_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_PDCCH_DEDICATED_CONF_CC_PRESENT  0x0001
#define NR_PDCCH_DEDICATED_CONF_CE_PRESENT  0x0002
#define NR_PDSCH_DEDICATED_CONF_PRESENT     0x0004

    pdcch_dedicated_config_t      pdcch_dedicated_config_CC;
    /*^ O, NR_PDCCH_DEDICATED_CONF_CC_PRESENT, N, 0, 0 ^*/

    pdcch_dedicated_config_t      pdcch_dedicated_config_CE;
    /*^ O, NR_PDCCH_DEDICATED_CONF_CE_PRESENT, N, 0, 0 ^*/

    pdsch_dedicated_config_t      pdsch_dedicated_config;
    /*^ O, NR_PDSCH_DEDICATED_CONF_PRESENT, N, 0, 0 ^*/

}dl_bwp_dedicated_config_t;


typedef struct _rb_res_part_t
{
    UInt16                          start_rb;
    /*^ M, 0, H, 0, NR_MAX_PRB ^*/

    UInt16                          num_rb;
    /*^ M, 0, B, 1, NR_MAX_PRB ^*/

}rb_res_part_t;
  
typedef struct _resource_partition_t
{
    UInt8                          num_cc_region;
    /*^ M, 0, B, 1, 2 ^*/

    UInt8                          num_ce_region;
    /*^ M, 0, H, 0, 1 ^*/

    rb_res_part_t        cc_region[MAX_CC_REGION];
    /*^ M, 0, N, 0, 0 ^*/

    rb_res_part_t        ce_region;
    /*^ M, 0, N, 0, 0 ^*/
}resource_partition_t;

typedef struct _dl_bw_part_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                            bitmask; 
    /*^ BITMASK ^*/
#define DL_BWP_COMMON_CONFIG_PRESENT     0x0001
#define DL_BWP_DEDICATED_CONFIG_PRESENT  0x0002

    /* TS 38.331 - 6.3.2   BWP-Id */
    UInt8                                dl_bwp_id;
    /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

    bwp_info_t                           dl_bwp_info; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt8                                max_dl_ue_to_be_scheduled_in_slot;
    /*^ M, 0, B, 1, 16 ^*/

    dl_bwp_common_config_t               dl_bwp_common_config;
    /*^ O, DL_BWP_COMMON_CONFIG_PRESENT, N, 0, 0 ^*/

    dl_bwp_dedicated_config_t            dl_bwp_dedicated_config;
    /*^ O, DL_BWP_DEDICATED_CONFIG_PRESENT, N, 0, 0 ^*/

}dl_bw_part_config_t;

typedef UInt32    preamble_trans_max_t;
typedef UInt32    power_ramping_step_t;
typedef UInt8    ra_response_window_t; 

typedef struct _rach_common_config_t
{
#define PRACH_RSRP_THRESHOLD_SSB 0x01
#define PREAMBLE_RECV_TARGET_PWR 0x02
#define PREAMBLE_TRANS_MAX       0x04
#define PWR_RAMPING_STEP         0x08
#define RA_RESPONSE_WINDOW       0x10
#define N_TA_OFFSET_PRESENT      0x20  
#define NR_NUM_CFRA_PREAMBLES_PRESENT 0x40

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask; 
    /*^ BITMASK ^*/
    UInt8                               prach_config_index;
    /*^ M, 0, H, 0, 255 ^*/

    /* TS 38.211, section 6.3.3.2 */
    /* TS 38.331 - 6.3.2 RACH-ConfigGeneric(msg1-FDM) */
    /* only value 0(1 occasion) is supproted in current release */
    prach_msg1_fdm_t                    prach_msg1_fdm;
    /*^ M, 0, H, 0, 3 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigGeneric(msg1-FrequencyStart) */
    nr_rb_t                             prach_msg1_freq_start_rb;
    /*^ M, 0, H, 0, NR_MAX_PRB ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigGeneric(zeroCorrelationZoneConfig) */
    UInt8                               zero_correlation_zone_config;
    /*^ M, 0, H, 0, 15 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigCommon(prach-RootSequenceIndex) */
    UInt16                              prach_root_seq_index;
    /*^ M, 0, H, 0, 837 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigCommon(msg1-SubcarrierSpacing) */
    nr_scs_t                            prach_scs;
    /*^ M, 0, H, 0, 4 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigCommon(restrictedSetConfig) */
    prach_restrict_set_t                prach_restrict_set;
    /*^ M, 0, H, 0, 2 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigCommon(ssb-perRACH-OccasionAndCB-PreamblesPerSSB) */
    /* Only 1 combination will be supported in current release */
    ssb_per_rach_occ_t                  ssb_per_rach_occ;
    /*^ M, 0, H, 0, 7 ^*/

    /* Only 1 combination will be supported in current release */
    UInt8                               total_cb_preambles_per_ssb;
    /*^ M, 0, B, 1, 64 ^*/

    /* Only 1 combination will be supported in current release */
    UInt8                               prach_rsrp_threshold_ssb;
    /*^ O, PRACH_RSRP_THRESHOLD_SSB, H, 0, 127 ^*/

    UInt8                               msg3_transform_precoding;
    /*^ M, 0, H, 0, 1 ^*/

    /*The target power level at the network receiver side (see 38.213, section 7.4,
    38.321, section 5.1.2, 5.1.3)*/
    SInt16                              preamble_received_target_power;
    /*^ O, PREAMBLE_RECV_TARGET_PWR, B, -200, -60 ^*/

    preamble_trans_max_t                preamble_trans_max;
    /*^ O, PREAMBLE_TRANS_MAX, H, 0, 10 ^*/

    power_ramping_step_t                power_ramping_step;
    /*^ O, PWR_RAMPING_STEP, H, 0, 3 ^*/
    
    /*Msg2 (RAR) window length in number of slots*/
    ra_response_window_t                ra_response_window;
    /*^ O, RA_RESPONSE_WINDOW, H, 0, 7 ^*/

    /* Total number of preambles used for contention based and 
     * contention free random access, excluding preambles used for other purposes */
    UInt8                              total_ra_preambles;
    /*^ M, 0, B, 1, 64 ^*/

    /* The number of CB preambles per SSB in group A.
     * The num_ra_preambles_group_a should be less than or equal to total_ra_preambles */
    UInt8                            num_ra_preambles_group_a;
    /*^ M, 0, B, 1, 64 ^*/

    /* Transport Blocks size threshold in bit below which the 
     * UE shall use a contention-based RA preamble. */
    UInt16                          ra_msg3_size_grpA;
    /*^ M, 0, N , 0 , 0 ^*/

    /* The initial value for the contention resolution timer.
     * Reference 3GPP TS 38.331 */
    UInt8                          ra_cont_res_timer;
    /*^ M, 0, N , 0 , 0 ^*/

    msg_pwr_offset_grpB_t             msg_pwr_offset_grpB;
    /*^ M, 0, H, 0, 7 ^*/
    
    /*Msg1 TA-Offset 3GPP TS 38.331 section 6.3.2 n-TimingAdvanceOffset*/
    n_ta_offset_t                     n_ta_offset;	
    /*^ O, N_TA_OFFSET_PRESENT, H, 0, 2 ^*/

    /*This is optional parameter and used to split the CFRA preambles between MAC and DuMgr 
      for Beam Failure Recovery. Number of preambles reserved for CFRA. The parameter should 
     be configured less than the difference of total_ra_preambles and total_cb_preambles_per_ssb.
     The preambles other than CBRA and CFRA will be used for BFR by DuMGR*/  
    UInt8                           num_cfra_preambles_per_ssb;
    /*^ O, NR_NUM_CFRA_PREAMBLES_PRESENT, B, 1, 32 ^*/

}rach_common_config_t;

typedef struct _pusch_res_alloc_t
{
#define PUSCH_RES_ALLOC_K2_PRESENT          0x0001
/*Need to add the bitmask check in OAM composing as well*/

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask; 
    /*^ BITMASK ^*/

    /* TS 38.331 - 6.3.2 PUSCH-TimeDomainResourceAllocation(mappingType) */
    /* DMRS TypeA is only supported in current release */
    dmrs_mapping_type_t                 dmrs_mapping_type;
    /*^ M, 0, H, 0, 1 ^*/

    /* TS 38.331 - 6.3.2 PUSCH-TimeDomainResourceAllocation(startSymbolAndLength) */
    /* TS 38.214 Table 6.1.2.1-1: Valid S and L combinations */
    /* startSymbolAndLength is interpreted as SLIV as defined TS 38.214 6.1.2.1, start_symbol
     * and length. To be encoded by Du-Mgr and send to UE */
    /* start_symbol = 0 for TypeA is only supported in current release */
    UInt8                               start_symbol;
    /*^ M, 0, H, 0, 13 ^*/

    /* length = 14 for TypeA is only supported in current release */
    UInt8                               length;
    /*^ M, 0, B, 1, 14 ^*/

    /* TS 38.331 - 6.3.2 PUSCH-TimeDomainResourceAllocation(k2) */
    UInt8                               k2;
    /*^ O, PUSCH_RES_ALLOC_K2_PRESENT, H, 0, 32 ^*/

}pusch_res_alloc_t;

/* TS 38.331 - 6.3.2 PUSCH-ConfigCommon */
/* The IE PUSCH-TimeDomainResourceAllocation is used to configure a time domain relation between PDCCH and PUSCH.
 * PUSCH-TimeDomainResourceAllocationList contains one or more of such PUSCH-TimeDomainResourceAllocations.
 * The network indicates in the UL grant which of the configued time domain allocations the UE shall apply for that UL grant.
 * The UE determines the bit width of the DCI field based on the number of entries in the PUSCH-TimeDomainResourceAllocationList.
 * Value 0 in the DCI field refers to the first element in this list, value 1 in the DCI field refers to the second element in this list, and so on. */
typedef struct _pusch_common_config_t
{
#define MSG3_DELTA_PREAMBLE_PRESENT         0x0001
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                               bitmask; 
    /*^ BITMASK ^*/
    UInt8                                   count;
    /*^ M, 0, B, 1, 16 ^*/

    pusch_res_alloc_t                       pusch_res_alloc[MAX_UL_ALLOCATION_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

    UInt8                                   grp_hop_enabled_transform_precoding;
    /*^ M, 0, H, 0, 1 ^*/

    SInt16                                  p0_nominal_with_grant;
    /*^ M, 0, B, -202, 24 ^*/

    /* Refer PUSCH-ConfigCommon(msg3-DeltaPreamble) (3GPP TS 38.331 section 6.3.2) */
    SInt8                                   msg3_delta_preamble;
    /*^ O, MSG3_DELTA_PREAMBLE_PRESENT, B, -1, 6 ^*/
}pusch_common_config_t;

/* TS 38.331 - 6.3.2 PUCCH-ConfigCommon */
typedef struct _pucch_common_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/
    UInt8                                 pucch_res_common;
    /*^ M, 0, H, 0, 15 ^*/

    /* hopping not supported in current release. only value 0 is applicable  */
    UInt8                                 pucch_grp_hopping;
    /*^ M, 0, H, 0, 2  ^*/
            
    UInt16                                hopping_id;
    /*^ M, 0, H, 0, 1023  ^*/

    SInt8                                 p0_nominal;
    /*^ M, 0, B, -202, 24 ^*/
}pucch_common_config_t;

typedef struct _ul_bwp_common_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define UL_BWP_RACH_COMMON_CONFIG_PRESENT         0x0001
#define UL_BWP_PUSCH_COMMON_CONFIG_PRESENT        0x0002
#define UL_BWP_PUCCH_COMMON_CONFIG_PRESENT        0x0004


    rach_common_config_t      rach_common_config;
    /*^ O, UL_BWP_RACH_COMMON_CONFIG_PRESENT, N, 0, 0 ^*/

    pusch_common_config_t     pusch_common_config;
    /*^ O, UL_BWP_PUSCH_COMMON_CONFIG_PRESENT, N, 0, 0 ^*/

    pucch_common_config_t     pucch_common_config;
    /*^ O, UL_BWP_PUCCH_COMMON_CONFIG_PRESENT, N, 0, 0 ^*/

}ul_bwp_common_config_t;


typedef struct _pusch_allocation_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
    UInt8                                 count;
    /*^ M, 0, B, 1, 16 ^*/

    pusch_res_alloc_t           pusch_res_alloc[MAX_UL_ALLOCATION_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pusch_allocation_list_t;

typedef struct _pusch_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_PUSCH_TIME_DOMAIN_RES_ALLOC_PRESENT         0x0001

    pusch_allocation_list_t      pusch_allocation_list;
    /*^ O, NR_PUSCH_TIME_DOMAIN_RES_ALLOC_PRESENT, N, 0, 0 ^*/

}pusch_dedicated_config_t;

typedef enum
{
    TA_TIME_ALIGNMENT_TIMER_MS500           = 0,
    TA_TIME_ALIGNMENT_TIMER_MS750           = 1,
    TA_TIME_ALIGNMENT_TIMER_MS1280          = 2,
    TA_TIME_ALIGNMENT_TIMER_MS1920          = 3,
    TA_TIME_ALIGNMENT_TIMER_MS2560          = 4,
    TA_TIME_ALIGNMENT_TIMER_MS5120          = 5,
    TA_TIME_ALIGNMENT_TIMER_MS10240         = 6,
    TA_TIME_ALIGNMENT_TIMER_MS_INFINITY     = 7
}ta_time_align_timer_et;
/* Time alignment timer (ta_time_alignment_timer_et) */

typedef struct _pucch_harq_resource_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8  harq_resource_count;
    /*^ M, 0, B, 1, 128 ^*/

    pucch_resource_config_t pucch_resource_harq[MAX_NUM_HARQ_RESOURCES];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pucch_harq_resource_list_t;

typedef struct _pucch_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    pucch_harq_resource_list_t  pucch_harq_resource_list;
    /*^ M, 0, N, 0, 0 ^*/

}pucch_dedicated_config_t;

typedef struct _ul_bwp_dedicated_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define NR_PUSCH_DEDICATED_CONF_PRESENT         0x0001
#define NR_PUCCH_DEDICATED_CONF_PRESENT         0x0002

    pusch_dedicated_config_t      pusch_dedicated_config;
    /*^ O, NR_PUSCH_DEDICATED_CONF_PRESENT, N, 0, 0 ^*/
    
    pucch_dedicated_config_t      pucch_dedicated_config;
    /*^ O, NR_PUCCH_DEDICATED_CONF_PRESENT, N, 0, 0 ^*/

}ul_bwp_dedicated_config_t;

typedef struct _ul_bw_part_config_t
{
#define UL_BWP_COMMON_CONFIG_PRESENT         0x0001
#define UL_BWP_DEDICATED_CONFIG_PRESENT      0x0002
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                               bitmask; 
    /*^ BITMASK ^*/

    UInt8                                   ul_bwp_id;
    /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

    bwp_info_t                              ul_bwp_info; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt8                   max_ul_ue_to_be_scheduled_in_slot;
    /*^ M, 0, B, 1, 16 ^*/

    ul_bwp_common_config_t                  ul_bwp_common_config;
    /*^ O, UL_BWP_COMMON_CONFIG_PRESENT, N, 0, 0 ^*/

    ul_bwp_dedicated_config_t             ul_bwp_dedicated_config;
    /*^ O, UL_BWP_DEDICATED_CONFIG_PRESENT, N, 0, 0 ^*/

}ul_bw_part_config_t;

typedef struct _bwp_config_t
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/
    nr_bwp_count_t                        dl_bwp_count;
    /*^ M, 0, B, 1, MAX_BWP_COUNT ^*/
     
    /* only 1 DL BWP ( initial BWP 0) is supported in current release  */
    dl_bw_part_config_t                       dl_bwp_config[MAX_BWP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

    nr_bwp_count_t                        ul_bwp_count;
    /*^ M, 0, B, 1, MAX_BWP_COUNT ^*/

    /* only 1 UL BWP ( initial BWP 0) is supported in current release  */
    ul_bw_part_config_t                       ul_bwp_config[MAX_BWP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}bwp_config_t;

/* TS 38.331 - 6.2.2   MIB */
/* TS 38.213 - section 4.1 */
/* ASN encoded PDU. MSB->LSB of first byte correspond to bit0 to bit7.
 *  The same bit order applies to the other two bytes.
 *  Only 1 instance of ASN encoded MIB data is sent to MAC from DU-Mgr with systemFrameNumber set to 0. 
 *  MAC will update the SFN in the first 6 bits of the buffer with the 6 most significant bit (MSB) 
 *  of the 10 bit System Frame Number for the respective transmission. */

typedef struct _mib_msg_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

    UInt8           mib_msg_len;
    /*^ M, 0, B, 1, MAX_MIB_LENGTH ^*/

    UInt8           mib_msg_buf[MAX_MIB_LENGTH];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}mib_msg_t;

/* TS 38.321 - 7.1 RNTI values */
typedef struct _rnti_range_t
{
    UInt16                              start_rnti;
    /*^ M, 0, B, 1, 65519 ^*/

    UInt16                              num_rnti;
    /*^ M, 0, B, 1, 65519 ^*/

}rnti_range_t;

typedef enum
{
    CONN_FAIL_COUNT_N1      = 0,
    CONN_FAIL_COUNT_N2      = 1,
    CONN_FAIL_COUNT_N3      = 2,
    CONN_FAIL_COUNT_N4      = 3
}conn_fail_count_et;

typedef UInt8    conn_fail_count_t;  	

typedef enum
{
    CONN_FAIL_OFFSET_VAL_S30       = 0,
    CONN_FAIL_OFFSET_VAL_S60       = 1,
    CONN_FAIL_OFFSET_VAL_S120      = 2,
    CONN_FAIL_OFFSET_VAL_S240      = 3,
    CONN_FAIL_OFFSET_VAL_S300      = 4,
    CONN_FAIL_OFFSET_VAL_S420      = 5,
    CONN_FAIL_OFFSET_VAL_S600      = 6,
    CONN_FAIL_OFFSET_VAL_S900      = 7
}conn_fail_offset_et;

typedef UInt16    conn_fail_offset_val_t;  

typedef struct _con_est_fail_control_t
{
#define CONN_FAIL_OFFSET_PRESENT     0x0001

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                        bitmask; 
    /*^ BITMASK ^*/

    conn_fail_count_t                conn_fail_count;
    /*^ M, 0, H, 0, 4 ^*/

    conn_fail_offset_val_t           conn_fail_offset_validity;
    /*^ M, 0, H, 0, 7 ^*/

    UInt8                            conn_fail_offset;
    /*^ O, CONN_FAIL_OFFSET_PRESENT, H, 0, 15 ^*/
}con_est_fail_control_t;

typedef struct _rnti_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

#define NR_CS_RNTI_RANGE_PRESENT         0x0001
#define NR_TPC_PUCCH_RNTI_RANGE_PRESENT  0x0002
#define NR_TPC_PUSCH_RNTI_RANGE_PRESENT  0x0004
#define NR_TPC_SRS_RNTI_RANGE_PRESENT    0x0008
#define NR_TPC_CS_RNTI_RANGE_PRESENT     0x0010
#define NR_INT_RNTI_RANGE_PRESENT        0x0020
#define NR_SFI_RNTI_RANGE_PRESENT        0x0040
#define NR_SP_CSI_RNTI_RANGE_PRESENT     0x0080

    rnti_range_t                crnti_range;
    /*^ M, 0, N, 0, 0 ^*/

    /* This IE is not supported in current release */
    rnti_range_t                cs_rnti_range;
    /*^ O, NR_CS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_pucch_rnti_range;
    /*^ O, NR_TPC_PUCCH_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_pusch_rnti_range;
    /*^ O, NR_TPC_PUSCH_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_srs_rnti_range;
    /*^ O, NR_TPC_SRS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_cs_rnti_range;
    /*^ O, NR_TPC_CS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                int_rnti_range;
    /*^ O, NR_INT_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                sfi_rnti_range;
    /*^ O, NR_SFI_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                sp_csi_rnti_range;
    /*^ O, NR_SP_CSI_RNTI_RANGE_PRESENT ^*/

}rnti_config_t;

typedef struct{
    
    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
   
    /* The IE ControlResourceSetZero is used to configure CORESET#0 
     * of the initial BWP (see TS 38.213 [13], section 13).*/
    UInt8           control_resource_set_zero; 
    /*^ M, 0, H, 0, 15 ^*/

    /* The IE SearchSpaceZero is used to configure SearchSpace#0 
     * of the initial BWP (see TS 38.213 [13], section 13).*/    
    UInt8           search_space_zero; 
    /*^ M, 0, H, 0, 15 ^*/

    
}pdcch_config_sib1_t;

typedef struct{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/

    /* The IE is used to configure minimum mcs index 
     * to be taken in calculation of Transport Block Size for SIB1*/
    UInt8           min_mcs_index_sib1;
    /*^ M, 0, H, 0, 9 ^*/

    /* The IE is used to configure maximum mcs index 
     * to be taken in calculation of Transport Block Size for SIB1*/
    UInt8           max_mcs_index_sib1;
    /*^ M, 0, H, 0, 9 ^*/
    
}mcs_index_sib1_t;

typedef struct{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/

    /*Length of the System Information block 1.*/
    UInt16          sib1_msg_len;
    /*^ M, 0, B, 1, MAX_SIB_LENGTH ^*/
    
    /* ASN encoded PDU. MSB->LSB of first byte correspond to bit0 to bit7
     * The same bit order applies to the subsequent bytes.
     * Only 1 instance of ASN encoded SIB1 data is sent to MAC from DUMGR*/
    UInt8           sib1_msg_buf[MAX_SIB_LENGTH];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}sib1_msg_t;
typedef struct{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
#define NR_LAYER_SIB1_PRESENT         0x0001

    /* Signifies if there is an associated sib1 with an SSB
     * It should be a subset of the ssb_mask[2] bits
     * If the configuration doesnt have a subset,
     * only those bits are considered for which ssb_mask[2] is 1
     * MSB->LSB of first 32-bit number corresponds to SSB 0 to SSB 31
     * MSB->LSB of second 32-bit number corresponds to SSB 32 to SSB 63*/
    UInt32                           sib1_mask[2];
    /*^ M,0,OCTET_STRING,FIXED ^*/
   
    /* Signifies the coreset and search space information for SIB1
     * Reference 3GPP TS 38.331 section 6.2.2 MIB*/
    pdcch_config_sib1_t              pdcch_config_sib1;
    /*^ M, 0, N, 0, 0 ^*/
  
    /* Indicates the SIB1 Information transmitted on DL-SCH. 
     * Reference 3GPP TS 38.331 section 6.2.2 SIB1.*/
    sib1_msg_t                       sib1_msg;
    /*^ O, NR_LAYER_SIB1_PRESENT, N, 0, 0 ^*/
}sib1_params_t;
typedef struct{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
    UInt8           pdb_weight;
    /*^ M, 0, H, 0, 10 ^*/
    UInt8           qci_weight;
    /*^ M, 0, H, 0, 10 ^*/
    UInt16          token_weight;
    /*^ M, 0, H, 0, 10 ^*/
    UInt8           qload_weight;
    /*^ M, 0, H, 0, 10 ^*/
    UInt8           mcs_weight;
    /*^ M, 0, H, 0, 10 ^*/
}qos_strategy_weights_t;

typedef struct _sinr_aggr_lvl_mcs_selection_t
{
    /* SINR low threshold for selection of aggregation level and MCS index */
    UInt8  sinr_low_threshold;
    /*^ M, 0, H, 0, 255 ^*/

    /* SINR high threshold for selection of aggregation level and MCS index */
    UInt8   sinr_high_threshold;
    /*^ M, 0, H, 0, 255 ^*/

    /* Aggregation level configured for RACH procedure */
    cce_aggr_level_t   aggregation_level;
    /*^ M, 0, H, 0, 4 ^*/

    /* MCS index for rar */
    UInt8   mcs_index_rar;
    /*^ M, 0, H, 0, 9 ^*/

    /* MCS index for msg3 */
    UInt8  mcs_index_msg3;
    /*^ M, 0, H, 0, 9 ^*/

    /* MCS index for msg4 (Contention Resolution) */
    UInt8  mcs_index_msg4;
    /*^ M, 0, H, 0, 9 ^*/

    /* TPC command to be used for msg3 */
    UInt8  msg3_tpc;
    /*^ M, 0, H, 0, 7 ^*/

    /* TB scaling to be applied for determine the TB size*/
    UInt8  tb_scaling;
    /*^ M, 0, H, 0, 2 ^*/

    UInt32 pdcch_power_offset;
    /*^ M, 0, H, 0, 10000 ^*/

    UInt32 pdcch_dmrs_power_offset;
    /*^ M, 0, H, 0, 10000 ^*/

    UInt32 pdsch_power_offset;
    /*^ M, 0, H, 0, 10000 ^*/

    UInt32 pdsch_dmrs_power_offset;
    /*^ M, 0, H, 0, 10000 ^*/

}sinr_aggr_lvl_mcs_selection_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
    UInt8           gbr_bkt_depth_factor;
    /*^ M, 0, B, 1, 5 ^*/
    UInt8           ambr_bkt_depth_factor;
    /*^ M, 0, B, 1, 5 ^*/
    UInt16          token_periodicity;
    /*^ M, 0, B, 10, 100 ^*/
    UInt8           qos_strategy_over_alloc_factor;
    /*^ M, 0, B, 10, 100 ^*/
    UInt8           enable_alloc_after_allowed_bitrate;
    /*^ M, 0, H, 0, 1 ^*/
    UInt8           dl_rb_restriction_factor;
    /*^ M, 0, B, 1, 3 ^*/
    SInt8           dl_ambr_token_limit_factor;
    /*^ M, 0, B, -1, 1 ^*/
    SInt8           dl_gbr_token_limit_factor;
    /*^ M, 0, B, -1, 1 ^*/
    qos_strategy_weights_t      dl_qos_strategy_weights;
    /*^ M, 0, N, 0, 0 ^*/
}dl_qos_params_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
    UInt8           gbr_bkt_depth_factor;
    /*^ M, 0, B, 1, 5 ^*/
    UInt8           ambr_bkt_depth_factor;
    /*^ M, 0, B, 1, 5 ^*/
    UInt16          token_periodicity;
    /*^ M, 0, B, 10, 100 ^*/
    UInt8           qos_strategy_over_alloc_factor;
    /*^ M, 0, B, 10, 100 ^*/
    UInt8           enable_alloc_after_allowed_bitrate;
    /*^ M, 0, H, 0, 1 ^*/
    UInt8           ul_rb_restriction_factor;
    /*^ M, 0, B, 1, 3 ^*/
    SInt8           ul_ambr_token_limit_factor;
    /*^ M, 0, B, -1, 1 ^*/
    SInt8           ul_gbr_token_limit_factor;
    /*^ M, 0, B, -1, 1 ^*/
    qos_strategy_weights_t      ul_qos_strategy_weights;
    /*^ M, 0, N, 0, 0 ^*/
}ul_qos_params_t;

typedef struct{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_QOS_STRATEGY_WT_PDB_WT_PRESENT     0x01
#define RECONFIG_QOS_STRATEGY_WT_QCI_WT_PRESENT     0x02
#define RECONFIG_QOS_STRATEGY_WT_TOKEN_WT_PRESENT   0x04
#define RECONFIG_QOS_STRATEGY_WT_QLOAD_WT_PRESENT   0x08
#define RECONFIG_QOS_STRATEGY_WT_MCS_WT_PRESENT     0x10
    UInt8           pdb_weight;
    /*^ O, RECONFIG_QOS_STRATEGY_WT_PDB_WT_PRESENT, H, 0, 10 ^*/
    UInt8           qci_weight;
    /*^ O, RECONFIG_QOS_STRATEGY_WT_QCI_WT_PRESENT, H, 0, 10 ^*/
    UInt16          token_weight;
    /*^ O, RECONFIG_QOS_STRATEGY_WT_TOKEN_WT_PRESENT, H, 0, 10 ^*/
    UInt8           qload_weight;
    /*^ O, RECONFIG_QOS_STRATEGY_WT_QLOAD_WT_PRESENT, H, 0, 10 ^*/
    UInt8           mcs_weight;
    /*^ O, RECONFIG_QOS_STRATEGY_WT_MCS_WT_PRESENT, H, 0, 10 ^*/
}reconfig_qos_strategy_weights_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t       bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_DL_GBR_BKT_DEPTH_FACTOR_PRESENT    0x001
#define RECONFIG_DL_AMBR_BKT_DEPTH_FACTOR_PRESENT   0x002
#define RECONFIG_DL_TOKEN_PERIODICITY_PRESENT       0x004
#define RECONFIG_DL_QOS_STRATEGY_OVER_ALLOC_FACTOR_PRESENT  0x008
#define RECONFIG_DL_ENABLE_ALLOC_AFTER_ALLOWED_BITRATE_PRESENT  0x010
#define RECONFIG_DL_RB_RESTRICTION_FACTOR_PRESENT               0x020
#define RECONFIG_DL_AMBR_TOKEN_LMT_FACTOR_PRESENT               0x040
#define RECONFIG_DL_GBR_TOKEN_LMT_FACTOR_PRESENT                0x080
#define RECONFIG_DL_QOS_STRATEGY_WT_PRESENT                     0x100
    UInt8           gbr_bkt_depth_factor;
    /*^ O, RECONFIG_DL_GBR_BKT_DEPTH_FACTOR_PRESENT, B, 1, 5 ^*/
    UInt8           ambr_bkt_depth_factor;
    /*^ O, RECONFIG_DL_AMBR_BKT_DEPTH_FACTOR_PRESENT, B, 1, 5 ^*/
    UInt16          token_periodicity;
    /*^ O, RECONFIG_DL_TOKEN_PERIODICITY_PRESENT, B, 10, 100 ^*/
    UInt8           qos_strategy_over_alloc_factor;
    /*^ O, RECONFIG_DL_QOS_STRATEGY_OVER_ALLOC_FACTOR_PRESENT, B, 10, 100 ^*/
    UInt8           enable_alloc_after_allowed_bitrate;
    /*^ O, RECONFIG_DL_ENABLE_ALLOC_AFTER_ALLOWED_BITRATE_PRESENT, H, 0, 1 ^*/
    UInt8           dl_rb_restriction_factor;
    /*^ O, RECONFIG_DL_RB_RESTRICTION_FACTOR_PRESENT, B, 1, 3 ^*/
    SInt8           dl_ambr_token_limit_factor;
    /*^ O, RECONFIG_DL_AMBR_TOKEN_LMT_FACTOR_PRESENT, B, -1, 1 ^*/
    SInt8           dl_gbr_token_limit_factor;
    /*^ O, RECONFIG_DL_GBR_TOKEN_LMT_FACTOR_PRESENT, B, -1, 1 ^*/
    reconfig_qos_strategy_weights_t      dl_qos_strategy_weights;
    /*^ O, RECONFIG_DL_QOS_STRATEGY_WT_PRESENT, N, 0, 0 ^*/
}reconfig_dl_qos_params_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_UL_GBR_BKT_DEPTH_FACTOR_PRESENT   0x001
#define RECONFIG_UL_AMBR_BKT_DEPTH_FACTOR_PRESENT  0x002
#define RECONFIG_UL_TOKEN_PERIODICITY_PRESENT      0x004
#define RECONFIG_UL_QOS_STRATEGY_OVER_ALLOC_FACTOR_PRESENT 0x008
#define RECONFIG_UL_ENABLE_ALLOC_AFTER_ALLOWD_BITRATE_PRESENT  0x010
#define RECONFIG_UL_RB_RESTRICTION_FACTOR_PRESENT           0x020
#define RECONFIG_UL_AMBR_TOKEN_LMT_FACTOR_PRESENT           0x040
#define RECONFIG_UL_GBR_TOKEN_LMT_FACTOR_PRESENT            0x080
#define RECONFIG_UL_QOS_STRATEGY_WTS_PRESENT                0x100
    UInt8           gbr_bkt_depth_factor;
    /*^ O, RECONFIG_UL_GBR_BKT_DEPTH_FACTOR_PRESENT, B, 1, 5 ^*/
    UInt8           ambr_bkt_depth_factor;
    /*^ O, RECONFIG_UL_AMBR_BKT_DEPTH_FACTOR_PRESENT, B, 1, 5 ^*/
    UInt16          token_periodicity;
    /*^ O, RECONFIG_UL_TOKEN_PERIODICITY_PRESENT, B, 10, 100 ^*/
    UInt8           qos_strategy_over_alloc_factor;
    /*^ O, RECONFIG_UL_QOS_STRATEGY_OVER_ALLOC_FACTOR_PRESENT, B, 10, 100 ^*/
    UInt8           enable_alloc_after_allowed_bitrate;
    /*^ O, RECONFIG_UL_ENABLE_ALLOC_AFTER_ALLOWD_BITRATE_PRESENT, H, 0, 1 ^*/
    UInt8           ul_rb_restriction_factor;
    /*^ O, RECONFIG_UL_RB_RESTRICTION_FACTOR_PRESENT, B, 1, 3 ^*/
    SInt8           ul_ambr_token_limit_factor;
    /*^ O, RECONFIG_UL_AMBR_TOKEN_LMT_FACTOR_PRESENT, B, -1, 1 ^*/
    SInt8           ul_gbr_token_limit_factor;
    /*^ O, RECONFIG_UL_GBR_TOKEN_LMT_FACTOR_PRESENT, B, -1, 1 ^*/
    reconfig_qos_strategy_weights_t      ul_qos_strategy_weights;
    /*^ O, RECONFIG_UL_QOS_STRATEGY_WTS_PRESENT, N, 0, 0 ^*/
}reconfig_ul_qos_params_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t               bitmask; 
    /*^ BITMASK ^*/
#define CELL_RECONFIG_NUM_OF_UE_PRESENT     0x001
#define CELL_RECONFIG_RNTI_START_RANGE_PRESENT  0x002
#define CELL_RECONFIG_RNTI_END_RANGE_PRESENT    0x004
#define CELL_RECONFIG_DL_256_QAM_SUPPORT_PRESENT    0x008
#define CELL_RECONFIG_UL_256_QAM_SUPPORT_PRESENT    0x010
#define CELL_RECONFIG_DL_SCHEDULER_STRATEGY_PRESENT 0x020
#define CELL_RECONFIG_UL_SCHEDULER_STRATEGY_PRESENT 0x040
#define CELL_RECONFIG_PHY_COMM_INFO_PRESENT         0x080
#define CELL_RECONFIG_DL_QOS_PARAMS_PRESENT 0x100
#define CELL_RECONFIG_UL_QOS_PARAMS_PRESENT 0x200

    UInt16                  num_of_ue;
    /*^ O, CELL_RECONFIG_NUM_OF_UE_PRESENT, B, 1, MAX_DUM_UE_INDEX ^*/
    UInt16                  rnti_start_range;
    /*^ O, CELL_RECONFIG_RNTI_START_RANGE_PRESENT, B, 1, 65519 ^*/
    UInt16                  rnti_end_range;
    /*^ O, CELL_RECONFIG_RNTI_END_RANGE_PRESENT, B, 1, 65519 ^*/
    UInt8                   dl_256_qam_support;
    /*^ O, CELL_RECONFIG_DL_256_QAM_SUPPORT_PRESENT, H, 0, 1 ^*/
    UInt8                   ul_256_qam_support;
    /*^ O, CELL_RECONFIG_UL_256_QAM_SUPPORT_PRESENT, H, 0, 1 ^*/
    UInt8                   dl_scheduler_strategy;
    /*^ O, CELL_RECONFIG_DL_SCHEDULER_STRATEGY_PRESENT, H, 0, 1 ^*/
    UInt8                   ul_scheduler_strategy;
    /*^ O, CELL_RECONFIG_UL_SCHEDULER_STRATEGY_PRESENT, H, 0, 1 ^*/
    mac_peer_comm_info_t    phy_comm_info;
    /*^ O, CELL_RECONFIG_PHY_COMM_INFO_PRESENT, N, 0, 0 ^*/
    reconfig_dl_qos_params_t         dl_qos_parameters;
    /*^ O, CELL_RECONFIG_DL_QOS_PARAMS_PRESENT, N, 0, 0 ^*/
    reconfig_ul_qos_params_t         ul_qos_parameters;
    /*^ O, CELL_RECONFIG_UL_QOS_PARAMS_PRESENT, N, 0, 0 ^*/
}reconfig_cell_init_params_t;

typedef struct{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t               bitmask; 
    /*^ BITMASK ^*/
#define DL_QOS_PARAMS_PRESENT   0x0001
#define UL_QOS_PARAMS_PRESENT   0x0002
    UInt16                  num_of_ue;
    /*^ M, 0, B, 1, MAX_DUM_UE_INDEX ^*/
    /* AM and UM bearer sum should not be more than MAX_LC */
    /* Number of AM LC's supported per UE in this cell. 
     * This field is used for memory estimation only */
    UInt8      num_am_lc_per_ue;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/

    /* Number of UM LC's supported per UE in this cell
     * This field is used for memory estimation only */
    UInt8      num_um_lc_per_ue;
    /*^ M, 0, B, MIN_LC, MAX_LC ^*/
    /* 18 bit SN support
     * This field is used for memory estimation only in RLCL */
    UInt8      is_18bit_sn_support;
    /*^ M, 0, H, 0, 1 ^*/
    UInt16                  rnti_start_range;
    /*^ M, 0, B, 1, 65519 ^*/
    UInt16                  rnti_end_range;
    /*^ M, 0, B, 1, 65519 ^*/
    UInt8                   dl_256_qam_support;
    /*^ M, 0, H, 0, 1 ^*/
    UInt8                   ul_256_qam_support;
    /*^ M, 0, H, 0, 1 ^*/
    UInt8                   dl_scheduler_strategy;
    /*^ M, 0, H, 0, 1 ^*/
    UInt8                   ul_scheduler_strategy;
    /*^ M, 0, H, 0, 1 ^*/
    mac_peer_comm_info_t    phy_comm_info;
    /*^ M, 0, N, 0, 0 ^*/
    dl_qos_params_t         dl_qos_parameters;
    /*^ O, DL_QOS_PARAMS_PRESENT, N, 0, 0 ^*/
    ul_qos_params_t         ul_qos_parameters;
    /*^ O, UL_QOS_PARAMS_PRESENT, N, 0, 0 ^*/
}cell_init_params_t;

typedef struct _reconfig_mac_rach_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_RA_RSP_WINDOW_SIZE_PRESENT     0x01
#define RECONFIG_TOTAL_RA_PREAMBLES_PRESENT     0x02
#define RECONFIG_NUM_RA_PREAMBLES_GP_A_PRESENT  0x04
#define RECONFIG_RA_MSG3_SIZE_GP_A_PRESENT      0x08
#define RECONFIG_RA_CONT_RES_TIMER_PRESENT      0x10
    /* TS 38.331 - 6.3.2 RACH-ConfigGeneric(ra-ResponseWindow) */
    /* Msg2 (RAR) window length in number of slots. */
    ra_rsp_window_size_t                ra_rsp_window_size;
    /*^ O, RECONFIG_RA_RSP_WINDOW_SIZE_PRESENT, B, 1, 80 ^*/

    /* TS 38.331 - 6.3.2 RACH-ConfigCommon(totalNumberOfRA-Preambles) */
    /* Total number of preambles used for contention based and contention free random access,
     * excluding preambles used for other purposes (e.g. for SI request). 
     * All 64 will be used for RA in current release. DuMgr need not sent to UE */
    UInt8                               total_ra_preambles;
    /*^ O, RECONFIG_TOTAL_RA_PREAMBLES_PRESENT, B, 1, 64 ^*/

    /* This IE is not supported in current release */
    UInt8                               num_ra_preambles_group_a;
    /*^ O, RECONFIG_NUM_RA_PREAMBLES_GP_A_PRESENT, B, 1, 64 ^*/

    /* This IE is not supported in current release */
    ra_msg3_size_grpA_t                 ra_msg3_size_grpA;
    /*^ O, RECONFIG_RA_MSG3_SIZE_GP_A_PRESENT, B, 56, 1000 ^*/

    /* This IE is not supported in current release */
    ra_cont_res_timer_t                 ra_cont_res_timer;
    /*^ O, RECONFIG_RA_CONT_RES_TIMER_PRESENT, B, 8, 64 ^*/

}reconfig_mac_rach_config_t;

typedef struct _reconfig_mib_msg_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_MIB_MSG_LEN_PRESENT    0x01
#define RECONFIG_MSG_BUF_PRESENT        0x02

    UInt8           mib_msg_len;
    /*^ O, RECONFIG_MIB_MSG_LEN_PRESENT, B, 1, MAX_MIB_LENGTH ^*/

    UInt8           mib_msg_buf[MAX_MIB_LENGTH];
    /*^ O, RECONFIG_MSG_BUF_PRESENT, OCTET_STRING, VARIABLE ^*/

}reconfig_mib_msg_t;

typedef struct _reconfig_rnti_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/

#define RECONFIG_CRNTI_RANGE_PRESENT              0x0001
#define RECONFIG_NR_CS_RNTI_RANGE_PRESENT         0x0002
#define RECONFIG_NR_TPC_PUCCH_RNTI_RANGE_PRESENT  0x0004
#define RECONFIG_NR_TPC_PUSCH_RNTI_RANGE_PRESENT  0x0008
#define RECONFIG_NR_TPC_SRS_RNTI_RANGE_PRESENT    0x0010
#define RECONFIG_NR_TPC_CS_RNTI_RANGE_PRESENT     0x0020
#define RECONFIG_NR_INT_RNTI_RANGE_PRESENT        0x0040
#define RECONFIG_NR_SFI_RNTI_RANGE_PRESENT        0x0080
#define RECONFIG_NR_SP_CSI_RNTI_RANGE_PRESENT     0x0100

    rnti_range_t                crnti_range;
    /*^ O, RECONFIG_CRNTI_RANGE_PRESENT, N, 0, 0 ^*/

    /* This IE is not supported in current release */
    rnti_range_t                cs_rnti_range;
    /*^ O, RECONFIG_NR_CS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_pucch_rnti_range;
    /*^ O, RECONFIG_NR_TPC_PUCCH_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_pusch_rnti_range;
    /*^ O, RECONFIG_NR_TPC_PUSCH_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_srs_rnti_range;
    /*^ O, RECONFIG_NR_TPC_SRS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                tpc_cs_rnti_range;
    /*^ O, RECONFIG_NR_TPC_CS_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                int_rnti_range;
    /*^ O, RECONFIG_NR_INT_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                sfi_rnti_range;
    /*^ O, RECONFIG_NR_SFI_RNTI_RANGE_PRESENT ^*/

    /* This IE is not supported in current release */
    rnti_range_t                sp_csi_rnti_range;
    /*^ O, RECONFIG_NR_SP_CSI_RNTI_RANGE_PRESENT ^*/

}reconfig_rnti_config_t;

typedef struct _reconfig_mac_layer_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_MAC_RACH_CONFIG_PRESENT 0x01
#define RECONFIG_NR_LAYER_MIB_PRESENT    0x02
#define RECONFIG_RNTI_CONFIG_PRESENT     0x04

    reconfig_mac_rach_config_t               mac_rach_config;
    /*^ O, RECONFIG_MAC_RACH_CONFIG_PRESENT, N, 0, 0 ^*/

    reconfig_mib_msg_t                       mib_msg;
    /*^ O, RECONFIG_NR_LAYER_MIB_PRESENT, N, 0, 0 ^*/

    reconfig_rnti_config_t                   rnti_config;
    /*^ O, RECONFIG_RNTI_CONFIG_PRESENT, N, 0, 0 ^*/

}reconfig_mac_layer_params_t;

typedef struct _reconfig_ssb_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_NR_PCI_PRESENT         0x001
#define RECONFIG_NR_SCS_PRESENT         0x002
#define RECONFIG_SSB_SUBCARRIER_OFFSET_PRESENT  0x004
#define RECONFIG_SSB_PERIODICITY_PRESENT        0x008
#define RECONFIG_DMRS_TYPE_A_POS_PRESENT        0x010
#define RECONFIG_SSB_MASK_PRESENT               0x020
#define RECONFIG_SSB_POWER_PRESENT              0x040
#define RECONFIG_SSB_CYCLIC_PREFIX_PRESENT      0x080
#define RECONFIG_SSB_HALF_SUBFRAME_PRESENT      0x100
#define RECONFIG_SSB_BURST_PATTERN_PRESENT      0x200
#define RECONFIG_SUB_CARRIER_SPACING_COMMON     0x400
#define RECONFIG_OFFSET_TO_POINTA               0x800
    /* TS 38.211 - 7.4.2.1 Physical-layer cell identities */
    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(physCellId) */
    nr_pci_t                              phy_cell_id;
    /*^ O, RECONFIG_NR_PCI_PRESENT, H, 0, 1007 ^*/

    /* Only SCS 120 kHz is supported in current release */
    nr_scs_t                              ssb_scs;
    /*^ O, RECONFIG_NR_SCS_PRESENT, H, 0, 4 ^*/

    /* TS 38.331 - 6.2.2   MIB(ssb-SubcarrierOffset) */
    /* TS 38.211 - 7.4.3.1 Kssb */
    /* Kssb LSB 4 bits in MIB(ssb-SubcarrierOffset) and MSB 1bit in a(A+5) in PBCH Payload  */
    UInt8                                 ssb_subcarrier_offset;
    /*^ O, RECONFIG_SSB_SUBCARRIER_OFFSET_PRESENT, H, 0, 31 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(ssb-periodicityServingCell) */
    /* TS 38.213 - 4.1     SSB-periodicityServingCell  */
    ssb_periodicity_t                     ssb_periodicity;
    /*^ O, RECONFIG_SSB_PERIODICITY_PRESENT, H, 0, 5 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(dmrs-TypeA-Position) */
    dmrs_typeA_pos_t                      dmrs_typeA_pos;
    /*^ O, RECONFIG_DMRS_TYPE_A_POS_PRESENT, B, 2, 3 ^*/

    /* TS 38.331 - 6.3.2   ServingCellConfigCommon(ssb-PositionsInBurst) */
    /* TS 38.213 - 4.1     SSB-transmitted */
    /* Bitmap for actually transmitted SSB. 
     * 0: not transmitted 1: transmitted.
     * MSB->LSB of first 32 bit number corresponds to SSB 0 to SSB 31
     * MSB->LSB of second 32 bit number corresponds to SSB 32 to SSB 63 */
    UInt32                                ssb_mask[2];
    /*^ O, RECONFIG_SSB_MASK_PRESENT,OCTET_STRING,FIXED ^*/

    SInt8                                ssb_power;
    /*^ O, RECONFIG_SSB_POWER_PRESENT, B, MIN_SSB_POWER, MAX_SSB_POWER ^*/

    nr_cyclic_prefix_t                    ssb_cyclic_prefix;
    /*^ O, RECONFIG_SSB_CYCLIC_PREFIX_PRESENT, H, 0, 1 ^*/

    /* TS 38.212 - 7.1.1   aHRF */
    /* 1 : first half frame, 0: not first half frame
     * a(A+4) in PBCH Payload  */
    UInt8                                 ssb_half_subframe;
    /*^ O, RECONFIG_SSB_HALF_SUBFRAME_PRESENT, H, 0, 1 ^*/

     UInt8                              sub_carrier_spacing_common;
    /*^ O,RECONFIG_SUB_CARRIER_SPACING_COMMON, H, 0, 1 ^*/

    UInt16                             offset_to_pointA;
    /*^ O, RECONFIG_OFFSET_TO_POINTA , H, 0, 2199 ^*/

}reconfig_ssb_config_t;

typedef struct _reconfig_bwp_config_t
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_NR_DL_BWP_COUNT_PRESENT    0x01
#define RECONFIG_DL_BWP_CONFIG_PRESENT      0x02
#define RECONFIG_NR_UL_BWP_COUNT_PRESENT    0x04
#define RECONFIG_UL_BWP_CONFIG_PRESENT      0x08
    nr_bwp_count_t                        dl_bwp_count;
    /*^ O, RECONFIG_NR_DL_BWP_COUNT_PRESENT, B, 1, MAX_BWP_COUNT ^*/
     
    /* only 1 DL BWP ( initial BWP 0) is supported in current release  */
    dl_bw_part_config_t                       dl_bwp_config[MAX_BWP_COUNT];
    /*^ O, RECONFIG_DL_BWP_CONFIG_PRESENT, OCTET_STRING, VARIABLE ^*/

    nr_bwp_count_t                        ul_bwp_count;
    /*^ O, RECONFIG_NR_UL_BWP_COUNT_PRESENT, B, 1, MAX_BWP_COUNT ^*/

    /* only 1 UL BWP ( initial BWP 0) is supported in current release  */
    ul_bw_part_config_t                       ul_bwp_config[MAX_BWP_COUNT];
    /*^ O, RECONFIG_UL_BWP_CONFIG_PRESENT, OCTET_STRING, VARIABLE ^*/

}reconfig_bwp_config_t;

typedef struct _reconfig_tdd_config_common_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_NR_REF_SCS_PRESENT                     0x01
#define RECONFIG_DL_UL_TRANSMISSION_PERIODICITY_PRESENT 0x02
#define RECONFIG_NUM_DL_SLOTS_PRESENT                   0x04
#define RECONFIG_NUM_DL_SYMBOLS_PRESENT                 0x08
#define RECONFIG_NUM_UL_SLOTS_PRESENT                   0x10
#define RECONFIG_NUM_UL_SYMBOLS_PRESENT                 0x20
    nr_scs_t                            reference_scs;
    /*^ O, RECONFIG_NR_REF_SCS_PRESENT, H, 0, 4 ^*/

    tdd_dl_ul_transmission_periodicity_t    dl_ul_transmission_periodicity;
    /*^ O, RECONFIG_DL_UL_TRANSMISSION_PERIODICITY_PRESENT, H, 0, 7 ^*/

    UInt16                              num_dl_slots;
    /*^ O, RECONFIG_NUM_DL_SLOTS_PRESENT, H, 0, 320 ^*/

    UInt8                               num_dl_symbols;
    /*^ O, RECONFIG_NUM_DL_SYMBOLS_PRESENT, H, 0, 13 ^*/

    UInt16                              num_ul_slots;
    /*^ O, RECONFIG_NUM_UL_SLOTS_PRESENT, H, 0, 320 ^*/

    UInt8                               num_ul_symbols;
    /*^ O, RECONFIG_NUM_UL_SYMBOLS_PRESENT, H, 0, 13 ^*/

}reconfig_tdd_config_common_t;

typedef struct _reconfig_pdsch_rate_match_pattern_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                         bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_RATE_MATCH_PATTERN_COUNT_PRESENT   0x01
#define RECONFIG_RATE_MATCH_PATTERN_CONFIG_PRESENT  0x02
    UInt8                             rate_match_pattern_count;
    /*^ O, RECONFIG_RATE_MATCH_PATTERN_COUNT_PRESENT, B, 1, 4 ^*/

    rate_match_pattern_config_t       rate_match_patter[MAX_RATE_MATCH_PATTERNS];
    /*^ O, RECONFIG_RATE_MATCH_PATTERN_CONFIG_PRESENT, OCTET_STRING, VARIABLE ^*/

}reconfig_pdsch_rate_match_pattern_list_t; 

typedef struct _reconfig_phy_vendor_specific_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_SSB_ABSOLUTE_FREQ_PRESENT              0x001
#define RECONFIG_DL_ABSOLUTE_FREQ_PT_A_PRESENT          0x002
#define RECONFIG_UL_ABSOLUTE_FREQ_PT_A_PRESENT         0x004
#define RECONFIG_PHY_DL_FFT_SIZE_PRESENT                     0x008
#define RECONFIG_PHY_UL_FFT_SIZE_PRESENT                     0x010

    /* Absolute Frequency in kHz.
     * calulation using FREF = FREF-Offs + deltaFGlobal (NREF - NREF-Offs) 
     * TS 38.101-1 - 5.4.2.1 FR1
     * TS 38.101-2 - 5.4.2.1 FR2                                  */
    /* TS 38.331 - 6.3.2   FrequencyInfoDL(absoluteFrequencySSB) */
    nr_absolute_freq_t                    ssb_absolute_freq;
    /*^ O, RECONFIG_SSB_ABSOLUTE_FREQ_PRESENT, H, 0, 3279165 ^*/

    /* TS 38.331 - 6.3.2   FrequencyInfoDL(absoluteFrequencyPointA) */
    nr_absolute_freq_t                    dl_absolute_freq_pointA;
    /*^ O, RECONFIG_DL_ABSOLUTE_FREQ_PT_A_PRESENT, H, 0, 3279165 ^*/

    /* TS 38.331 - 6.3.2   FrequencyInfoUL(absoluteFrequencyPointA) */
    /* For TDD the ul_absolute_freq_pointA should be set same as dl_absolute_freq_pointA */
    nr_absolute_freq_t                    ul_absolute_freq_pointA;
    /*^ O, RECONFIG_UL_ABSOLUTE_FREQ_PT_A_PRESENT, H, 0, 3279165 ^*/

    nr_phy_fft_size_t       dl_fft_size;
    /*^ O, RECONFIG_PHY_DL_FFT_SIZE_PRESENT, B, 512, 4096 ^*/

    nr_phy_fft_size_t             ul_fft_size;
    /*^ O, RECONFIG_PHY_UL_FFT_SIZE_PRESENT, B, 512, 4096 ^*/

}reconfig_phy_vendor_specific_params_t;

typedef struct _mac_layer_params_t
{
#define NR_LAYER_MIB_PRESENT                0x0001
#define NR_LAYER_SIB1_PARAMS_PRESENT        0x0002
#define NR_CONN_EST_FAIL_CONTROL_PRESENT    0x0004

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask; 
    /*^ BITMASK ^*/

    /* mib_msg is optional b/w DUOAM DUMGR interface,
     * Mandatory element b/w  DUMGR-MAC interface  */
    mib_msg_t                           mib_msg;
    /*^ O, NR_LAYER_MIB_PRESENT, N, 0, 0 ^*/

    con_est_fail_control_t              con_est_fail_control;
    /*^ O, NR_CONN_EST_FAIL_CONTROL_PRESENT, N, 0, 0 ^*/

    rnti_config_t                       rnti_config;
    /*^ M, 0, N, 0, 0 ^*/

   
    sib1_params_t                       sib1_params;
    /*^ O, NR_LAYER_SIB1_PARAMS_PRESENT, N, 0, 0 ^*/

}mac_layer_params_t;

typedef struct _power_control_common_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    /*Maximum transmit power allowed in this serving cell.The maximum transmit power that 
     * the UE may use on this serving cell may be additionally limited by p-NR-FR1 (configured
     * for the cell group) and by p-UE-FR1 (configured total for all serving cells operating on FR1).
     * If absent, the UE applies the maximum power according to TS 38.101 [15]. Value in dBm.
     * Reference 3GPP TS 38.331 FrequencyInfoUL->p-Max */
    SInt8 p_max;
    /*^ M, 0, B, -30, 33 ^*/

    /* The additional spectrum emission requirements to be applied by the UE on this uplink. 
     * Reference 3GPP TS 38.101-1 Section 6.2.3 for FR1, 38.101-2 Section 6.2.3 for FR2, 38.101-2 Section 6.2B.3.  
     * Default value : 0*/
    UInt8 additional_spectrum_emmision;
    /*^ M, 0, H, 0, 7 ^*/ 

}power_control_common_info_t;

typedef struct _nzp_csi_rs_resource_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* NZP resource Id configured  by higher layers. */
  UInt8 nzp_csi_rs_resource_id; 
  /*^ M, 0, H, 0, 191 ^*/

  /* Refer CSI-RS-ResourceMapping in NZP-CSI-RS-Resource(3GPP TS 38.331) */
  csi_rs_resource_mapping_t resource_mapping; 
  /*^ M, 0, N, 0, 0 ^*/

  /* Power Offset of Pdsch RE configured  by higher layers. */
  UInt8 power_control_offset;
  /*^ M, 0, H, 0, 23 ^*/ /* power_control_offset_et */

  /* Power Offset of SS RE configured  by higher layers. */
  UInt8 power_control_offset_ss;
  /*^ M, 0, H, 0, 3 ^*/

  /* Scrambling Id used for CINIT calculation configured  by higher layers. */
  UInt16 scrambling_id;
  /*^ M, 0, H, 0, 1023 ^*/ 

  /* NZP periodicity configured  by higher layers. */
  UInt8 periodicity;
  /*^ M, 0, H, 0, 12 ^*/ /*csi_rs_periodicity_et*/

  /* NZP resource Offset configured  by higher layers. */
  UInt16 offset;
  /*^ M, 0, H, 0, 639 ^*/

}nzp_csi_rs_resource_t;

typedef struct _nzp_csi_rs_res_to_add_mod_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Count for NZP resources configured  by higher layers. */
  UInt8 nzp_csi_rs_res_to_add_mod_count;
  /*^ M, 0, B, 1, 192 ^*/

  /* Refer NZP-CSI-RS-Resource in Csi-MeasConfig (3GPP TS 38.331) */
  nzp_csi_rs_resource_t nzp_csi_rs_resource[MAX_NUM_NZP_CSI_RS_RESOURCES];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}nzp_csi_rs_res_to_add_mod_info_t;

typedef struct _nzp_csi_rs_resource_set_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* NZP resource Set Id configured  by higher layers. */
  UInt8 nzp_resource_set_id; 
  /*^ M, 0, H, 0, 63 ^*/

  /* Count for NZP resource in a set configured  by higher layers. */
  UInt8 nzp_csi_rs_resource_count;
  /*^ M, 0, B, 1, 64 ^*/

  /* Refer NZP-CSI-RS-ResourceSet in Csi-MeasConfig (3GPP TS 38.331) */
  UInt8 resource_list[MAX_NUM_NZP_CSI_RS_RESOURCE_PER_SET];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}nzp_csi_rs_resource_set_t;

typedef struct _nzp_csi_rs_res_set_to_add_mod_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Count for NZP resource set configured  by higher layers. */
  UInt8 nzp_csi_rs_res_set_to_add_mod_count;
  /*^ M, 0, B, 1, 64 ^*/

  /* Refer NZP-CSI-RS-ResourceSet in Csi-MeasConfig (3GPP TS 38.331) */
  nzp_csi_rs_resource_set_t nzp_csi_rs_resource_set[MAX_NUM_NZP_CSI_RS_RESOURCE_SET];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}nzp_csi_rs_res_set_to_add_mod_info_t;

typedef struct _csi_resource_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* CSI resource config Id configured  by higher layers. */
  UInt8 csi_resource_config_id; 
  /*^ M, 0, H, 0, 111 ^*/

  /* CSI resource Type configured  by higher layers. */
  UInt8 resource_type; 
  /*^ M, 0, H, 0, 2 ^*/

  /* BWP Id configured  by higher layers. */
  UInt8 bwp_id; 
  /*^ M, 0, H, 0, 4 ^*/

  /* Count for CSI resource Set per config configured  by higher layers. */
  UInt8 nzp_csi_rs_resource_set_count;
  /*^ M, 0, B, 1, 16 ^*/

  /* Refer CSI-ResourceConfig in Csi-MeasConfig (3GPP TS 38.331) */
  UInt8 nzp_csi_rs_resource_list[MAX_NZP_RES_SETS_PER_CONFIG];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}csi_resource_config_t;

typedef struct _csi_resource_config_to_add_mod_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Count for CSI resource config configured  by higher layers. */
  UInt8 csi_resource_config_to_add_mod_count;
  /*^ M, 0, B, 1, 112 ^*/

  /* Refer CSI-ResourceConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_resource_config_t csi_resource_config[MAX_NUM_CSI_RESOURCE_CONFIG];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}csi_resource_config_to_add_mod_info_t;

typedef struct _csi_ssb_resource_set_t
{
    
    /* To inform optional parameter presence */
    bitmask_t         bitmask;
    /*^ BITMASK ^*/

    /*Generated by DU-Mgr */
    UInt8            csi_ssb_resource_set_id;
    /*^ M, 0, B, 0, 63^*/

    /*CSI SSB resource will be configured for channel measurement*/
    UInt8            csi_ssb_rs_resource_count;
    /*^ M, 0, H, 1, 64 ^*/

    /*List of CSI-SSB resource Ids which will be part of this resource set*/
    UInt8            ssb_index[MAX_NUM_CSI_SSB_RESOURCE_SET];
    /*^ M, 0, OCTET_STRING, VARIABLE^*/
}csi_ssb_resource_set_t;

typedef struct _csi_ssb_res_set_to_add_mod_info_t
{
    /* To inform optional parameter presence */
    bitmask_t         bitmask;
    /*^ BITMASK ^*/

    /*List count of CSI_SSB_RESOURCE_SET configured. For now, one resource set 
      will be configured which will be common for all the Ues in the cell */
    UInt8      csi_ssb_res_set_to_add_mod_count;
    /*^ M, 0, H, 1, MAX_NUM_CSI_SSB_RESOURCE_SET ^*/

    /*Refer CSI-MeasConfig in ServingCellConfig in TS 38.331. 
      CSI-SSB-ResourceSet is a set of CSI-SSB resources (their IDs) and set-specific parameters */
    csi_ssb_resource_set_t  csi_ssb_resource_set[MAX_NUM_CSI_SSB_RESOURCE_SET];
    /*^M, 0, OCTET_STRING, VARIABLE ^*/
}csi_ssb_res_set_to_add_mod_info_t;

typedef struct _csi_ssb_resource_config_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/

    /*CSI resource config Id is generated by Du-Mgr*/
    UInt8    csi_resource_config_id;
    /*^M, 0, H, 0, 111^*/

    /*Only one CSI-SSB resource set will be present to measure the L1-RSRP */
    UInt8   csi_ssb_resource_set_count;
    /*^M, 0, B, 1, MAX_CSI_SSB_RES_SETS_PER_CONFIG ^*/
 
    /*List of CSI-SSB resource set Id�s which will be part of this resource config */
    UInt8   csi_ssb_resource_set_list[MAX_CSI_SSB_RES_SETS_PER_CONFIG];
    /*^M, 0, OCTET_STRING, VARIABLE ^*/
}csi_ssb_resource_config_t;

typedef struct _csi_meas_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define NZP_CSI_RS_RES_ADD_MOD_LIST_PRESENT   0x0001
#define NZP_CSI_RS_RES_SET_ADD_MOD_LIST_PRESENT 0x0002
#define CSI_RESOURCE_CONFIG_ADD_MOD_LIST_PRESENT 0x0004
#define CSI_SSB_RES_SET_ADD_MOD_LIST_PRESENT 0x0008

  /* Refer NZP-CSI-RS-Resource in Csi-MeasConfig (3GPP TS 38.331) */
  nzp_csi_rs_res_to_add_mod_info_t nzp_csi_rs_res_to_add_mod_info;
  /*^ O, NZP_CSI_RS_RES_ADD_MOD_LIST_PRESENT, N, 0, 0 ^*/

  /* Refer NZP-CSI-RS-ResourceSet in Csi-MeasConfig (3GPP TS 38.331) */
  nzp_csi_rs_res_set_to_add_mod_info_t nzp_csi_rs_res_set_to_add_mod_info;
  /*^ O, NZP_CSI_RS_RES_SET_ADD_MOD_LIST_PRESENT, N, 0, 0 ^*/

  /* Refer CSI-ResourceConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_resource_config_to_add_mod_info_t csi_resource_config_to_add_mod_info;
  /*^ O, CSI_RESOURCE_CONFIG_ADD_MOD_LIST_PRESENT, N, 0, 0 ^*/

  /*CSI-SSB resource set configuration information */
  csi_ssb_res_set_to_add_mod_info_t csi_ssb_res_set_to_add_mod_info;
  /*^ O, CSI_SSB_RES_SET_ADD_MOD_LIST_PRESENT, N, 0, 0^*/

}csi_meas_config_info_t;

typedef struct _reconfig_phy_layer_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask; 
    /*^ BITMASK ^*/
#define RECONFIG_DUPLEXING_MODE_PRESENT 0x0001
#define RECONFIG_DL_RBS_PRESENT         0x0002
#define RECONFIG_UL_RBS_PRESENT         0x0004
#define RECONFIG_NUM_TX_ANTENNA_PRESENT 0x0008
#define RECONFIG_NUM_RX_ANTENNA_PRESENT 0x0010
#define RECONFIG_SSB_CONFIG_PRESENT     0x0020
#define RECONFIG_BWP_CONFIG_PRESENT     0x0040
#define RECONFIG_NR_TDD_CONFIG_COMMON_PRESENT   0x0080
#define RECONFIG_NR_TDD_CONFIG_COMMON2_PRESENT  0x0100
#define RECONFIG_NR_CELL_RATE_MATCH_PATTERN_PRESENT  0x0200
#define RECONFIG_DL_FREQ_BAND            0x0400
#define RECONFIG_UL_FREQ_BAND            0x0800
#define RECONFIG_NR_CSI_MEAS_CONFIG_PRESENT  0x1000    
    /* Only TDD is supported in current release */
    duplexing_mode_t                    duplexing_mode;
    /*^ O, RECONFIG_DUPLEXING_MODE_PRESENT, H, 0, 1 ^*/

    /* Nrb = 66 is supported in current release */
    nr_rb_t                             dl_rbs;
    /*^ O, RECONFIG_DL_RBS_PRESENT, B, 1, NR_MAX_PRB ^*/

    /* Nrb = 66 is supported in current release */
    nr_rb_t                             ul_rbs;
    /*^ O, RECONFIG_UL_RBS_PRESENT, B, 1, NR_MAX_PRB ^*/

    UInt8                               num_of_tx_antenna;
    /*^ O, RECONFIG_NUM_TX_ANTENNA_PRESENT, B, 1, 8 ^*/

    UInt8                               num_of_rx_antenna;
    /*^ O, RECONFIG_NUM_RX_ANTENNA_PRESENT, B, 1, 4 ^*/

    reconfig_ssb_config_t                        ssb_config;
    /*^ O, RECONFIG_SSB_CONFIG_PRESENT, N, 0, 0 ^*/

    reconfig_bwp_config_t                        bwp_config;
    /*^ O, RECONFIG_BWP_CONFIG_PRESENT, N, 0, 0 ^*/

    /* This IE is conditional and present is case of TDD only */
    tdd_config_common_t                 tdd_config_common;
    /*^ O, RECONFIG_NR_TDD_CONFIG_COMMON_PRESENT, N, 0, 0 ^*/

    reconfig_pdsch_rate_match_pattern_list_t      pdsch_cell_rate_match_pattern_list;
    /*^ O, RECONFIG_NR_CELL_RATE_MATCH_PATTERN_PRESENT, N, 0, 0 ^*/

    UInt16                  dl_freq_band;
    /*^ O, RECONFIG_DL_FREQ_BAND ,B, 1, 1024 ^*/

    UInt16                  ul_freq_band;
    /*^ O, RECONFIG_UL_FREQ_BAND ,B, 1, 1024 ^*/
    
    /* CSI-RS releated parameters Refer 38.331 CSI-MeasConfig */
    csi_meas_config_info_t                      csi_meas_config_info;
    /*^ O, RECONFIG_NR_CSI_MEAS_CONFIG_PRESENT, N, 0, 0 ^*/

}reconfig_phy_layer_params_t;


typedef struct _ssb_beam_config_t
{
    /* To inform optional parameter presence */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    /* Index of SSB transmitted in the cell*/
    UInt8        ssb_index;
    /*^ M, 0, H, 0, 63 ^*/
  
    /* Beam Id for the SSB. If SSB mask bit 26 set to 1, then beam Id 
     * will be used to indicate beam of SSB 26.*/
    UInt8    beam_id;
    /*^ M, 0, H, 0, 127 ^*/

    /* TCI state associated to the beam*/
    UInt8 tci_state_id;
    /*^ M, 0, H, 0, 127^*/

    /* Number of TxRU(TRP) mapped for the Beam*/
    UInt8 num_txru_per_beam;
    /*^ M, 0, B, 1, 4 ^*/
 
    /*TxRU(TRP) indexes for the Beam*/
    UInt8  txru_index[MAX_NUM_TXRU];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}ssb_beam_config_t;

typedef struct _ssb_beam_config_list_t
{
     /* To inform optional parameter presence */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/
    
    /*Number of SSB transmitted in the cell*/
    UInt8             count;
    /*^ M, 0, B, 1, 64 ^*/

    /*Beam configuration for each transmitted ssb.*/
    ssb_beam_config_t   ssb_beam_config[MAX_SSB_RESOURCES];
    /*^ M, 0, OCTET_STRING, VARIABLE  ^*/
}ssb_beam_config_list_t;

typedef struct _beam_config_info_t
{
    /* To inform optional parameter presence */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/ 

    /*Indicates ssb-index to beam and TCI state mapping for each transmitted ssb */
    ssb_beam_config_list_t  ssb_beam_config_list;
    /*^M, 0, N, 0, 0 ^*/
}beam_config_info_t;

typedef struct _phy_layer_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                           bitmask; 
    /*^ BITMASK ^*/
#define NR_TDD_CONFIG_COMMON_PRESENT   0x0001
#define NR_TDD_CONFIG_COMMON2_PRESENT  0x0002
#define NR_CELL_RATE_MATCH_PATTERN_PRESENT  0x0004
#define NR_CELL_POWER_CONTROL_COMMON_INFO_PRESENT  0x0008
#define NR_CSI_MEAS_CONFIG_PRESENT  0x0010
#define NR_BEAM_CONFIG_PRESENT 0x0020
    /* Only TDD is supported in current release */
    duplexing_mode_t                    duplexing_mode;
    /*^ M, 0, H, 0, 1 ^*/

    /* Nrb = 66 is supported in current release */
    nr_rb_t                             dl_rbs;
    /*^ M, 0, B, 1, NR_MAX_PRB ^*/

    /* Nrb = 66 is supported in current release */
    nr_rb_t                             ul_rbs;
    /*^ M, 0, B, 1, NR_MAX_PRB ^*/
    
    /* Indicates the DL NR Operating Band */ 
    UInt16                           dl_freq_band;
    /*^ M, 0, B, 1, 1024 ^*/

    /* Indicates UL NR Operating Band. */   
    UInt16                           ul_freq_band;
    /*^ M, 0, B, 1, 1024 ^*/

    UInt8                               num_of_tx_antenna;
    /*^ M, 0, B, 1, 8 ^*/

    UInt8                               num_of_rx_antenna;
    /*^ M, 0, B, 1, 4 ^*/

    ssb_config_t                        ssb_config;
    /*^ M, 0, N, 0, 0 ^*/

    bwp_config_t                        bwp_config;
    /*^ M, 0, N, 0, 0 ^*/

    /* This IE is conditional and present is case of TDD only */
    tdd_config_common_t                 tdd_config_common;
    /*^ O, NR_TDD_CONFIG_COMMON_PRESENT, N, 0, 0 ^*/

    pdsch_rate_match_pattern_list_t      pdsch_cell_rate_match_pattern_list;
    /*^ O, NR_CELL_RATE_MATCH_PATTERN_PRESENT, N, 0, 0 ^*/

    power_control_common_info_t  power_control_common_info;
    /*^ O, NR_CELL_POWER_CONTROL_COMMON_INFO_PRESENT, N, 0, 0 ^*/
    
    /* CSI-RS releated parameters Refer 38.331 CSI-MeasConfig */
    csi_meas_config_info_t csi_meas_config_info;  
    /*^ O, NR_CSI_MEAS_CONFIG_PRESENT, N, 0, 0 ^*/

    /*Beam related configuration for, SSB-Beam and TCI mapping*/
    beam_config_info_t     beam_config_info;
    /*^ O, NR_BEAM_CONFIG_PRESENT, N, 0, 0^*/
}phy_layer_params_t;

typedef struct _phy_vendor_specific_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
#define PHY_UL_ABSOLUTE_FREQ_POINTA_PRESENT         0x0001
#define PHY_DL_FFT_SIZE_PRESENT                     0x0002
#define PHY_UL_FFT_SIZE_PRESENT                     0x0004

    /* Absolute Frequency in kHz.
     * calulation using FREF = FREF-Offs + deltaFGlobal (NREF - NREF-Offs) 
     * TS 38.101-1 - 5.4.2.1 FR1
     * TS 38.101-2 - 5.4.2.1 FR2                                  */
    /* TS 38.331 - 6.3.2   FrequencyInfoDL(absoluteFrequencySSB) */
    nr_absolute_freq_t                    ssb_absolute_freq;
    /*^ M, 0, H, 0, 3279165 ^*/

    /* TS 38.331 - 6.3.2   FrequencyInfoDL(absoluteFrequencyPointA) */
    nr_absolute_freq_t                    dl_absolute_freq_pointA;
    /*^ M, 0, H, 0, 3279165 ^*/

    /* TS 38.331 - 6.3.2   FrequencyInfoUL(absoluteFrequencyPointA) */
    /* For TDD the ul_absolute_freq_pointA should be set same as dl_absolute_freq_pointA */
    nr_absolute_freq_t                    ul_absolute_freq_pointA;
    /*^ O, PHY_UL_ABSOLUTE_FREQ_POINTA_PRESENT, H, 0, 3279165 ^*/

    nr_phy_fft_size_t       dl_fft_size;
    /*^ O, PHY_DL_FFT_SIZE_PRESENT, B, 512, 4096 ^*/

    nr_phy_fft_size_t             ul_fft_size;
    /*^ O, PHY_UL_FFT_SIZE_PRESENT, B, 512, 4096 ^*/

}phy_vendor_specific_params_t;

typedef struct _ssb_index_t
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t               bitmask;
  /*^ BITMASK ^*/

  UInt8 ssb_idx;
  /*^ M, 0, H, 0, 63 ^*/
}ssb_index_t;

typedef struct _cfra_ssb_index_t
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t               bitmask; 
  /*^ BITMASK ^*/
#define NR_CFRA_SSB_RESOURCE_PRESENT 0x0001
#define NR_CFRA_CSIRS_RESOURCE_PRESENT 0x0002  /* To inform optional parameter presence. The bit2 is for future.*/

  /* Number of SSB index for allocation of CFRA preamble*/
  UInt8 ssb_index_count;
  /*^ M, 0, B, 1, 64 ^*/

  /*ssb index. The array length is based on ssb_index_count*/
  ssb_index_t  ssb_index[MAX_SSB_RESOURCES];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/    

}cfra_ssb_index_t;

typedef struct _ssb_resource_list_t
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t      bitmask; 
  /*^ BITMASK ^*/

  UInt8   ssb_index;
  /*^ M, 0, H, 0, 63 ^*/
  UInt8   preamble_index;
  /*^ M, 0, H, 0, 63 ^*/
}ssb_resource_list_t;

typedef struct _cfra_resource_ssb_t
{
  /* Bitmask indicating the presence of optional fields */
  bitmask_t      bitmask; 
  /*^ BITMASK ^*/

  /* 1 - 64 Number of SSB resource allocated for CFRA */ 
  /* ! Only one CFRA resource allocation is supported in current release. 
   * In case SSB Index is received from DU-MGR One CFRA resource allocation will be attempted in RACH occasion mapping to first SBB Index in list provided from DU-MGR in case of resource shortage one CFRA resource will be attempted to be allocated in rach occasion mapping to next(second) SBB Index and so on.
   * In case no SSB Index is received from DU-MGR MAC will select any available ssb-index from first transmitted ssb ! */   
  UInt8   ssb_resource_count;
  /*^ M, 0, B, 1, 64 ^*/
  ssb_resource_list_t ssb_resource_list[MAX_SSB_RESOURCES];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/    

  UInt8   ssb_occasion_mask_index;
  /*^ M, 0, H, 0, 15 ^*/

}cfra_resource_ssb_t;

typedef struct _cfra_resource_info_t
{

  /* Bitmask indicating the presence of optional fields */
  bitmask_t               bitmask; 
  /*^ BITMASK ^*/
#define NR_CFRA_SSB_RESOURCE_PRESENT 0x0001

  /*Structure CFRA SSB resource allocation info. 
   * This IE is mandatory present in current release 
   * It is set optional for CSI-RS support in future */

  cfra_resource_ssb_t  cfra_ssb_resource;
  /*^ O, NR_CFRA_SSB_RESOURCE_PRESENT, N, 0, 0 ^*/

}cfra_resource_info_t;


typedef struct _dl_lc_create_req_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* 1-16  is the logical channel priority of the LC. */
  UInt8 LchPriority;
  /*^ M, 0, B, 1, 16 ^*/ 

}dl_lc_create_req_t;

typedef struct _sr_resource_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/
#define SR_PERIODICITY_PRESENT  0x0001
#define SR_OFFSET_PRESENT 0x0002
#define RESOURCE_INDEX_PRESENT  0x0004

  /* The IE SchedulingRequestResourceId is used to identify scheduling request resources on PUCCH. */
  UInt8 scheduling_request_resource_id;
  /*^ M, 0, B, 1, MAX_SR_RESOURCES ^*/

  /* The ID of the SchedulingRequestConfig that uses this scheduling request resource. */
  UInt8 scheduling_request_id;
  /*^ M, 0, H, 0, MAX_SR_RESOURCES_ID ^*/

  /* The enumerated value: 0 - sym2; 1 - sym6or7; 2 - sl1; 3 - sl2; 4 - sl4; 5 - sl5; 6 - sl8; 7 - sl10; 8 - sl16; 9 - sl20;
   * 10 - sl40;11 - sl80;12 - sl160;13 - sl320;14 - sl640  SR periodicity in number of slots. */
  /* In the current release, default periodicity of 80 slots can be configured. */
  UInt8  sr_periodicity;
  /*^ O, SR_PERIODICITY_PRESENT, H, 0, 14 ^*/

  /* SR offset in number of slots.*/
  /* The range of the sr_offset would depend upon the value of  sr_periodicity, as below:
     sym2       - NULL;sym6or7    - NULL;sl1      - NULL;sl2      - 0 to 1;sl4      - 0 to 3;sl5      - 0 to 4;sl8      - 0 to 7
     sl10       - 0 to 9;sl16       - 0 to 15;sl20      - 0 to 19;sl40      - 0 to 39;sl80      - 0 to 79;sl160       - 0 to 159;
     sl320      - 0 to 319;sl640      - 0 to 639
     In the current Release, offset of 4,9,14,19 could be configured, considering that in a system frame,
     with 4 DL + 1 UL Configuration, 4th, 9th , 14th and 19th slot would be UL slot in numerology 1. */
  UInt16  sr_offset;
  /*^ O, SR_OFFSET_PRESENT, H, 0, 639 ^*/

  /* ID of the PUCCH resource in which the UE shall send the scheduling request.
     The actual PUCCH-Resource is configured in PUCCH-Config of the same UL BWP and serving cell as this SchedulingRequestResourceConfig.
     The network configures a PUCCH-Resource of PUCCH-format0 or PUCCH-format1 (other formats not supported).
     Corresponds to L1 parameter 'SR-resource' (see 38.213, section 9.2.2) */
  UInt8 resource_index;
  /*^ O, RESOURCE_INDEX_PRESENT, H, 0, MAX_PUCCH_RESOURCES ^*/

}sr_resource_config_t;


typedef struct _ul_lc_create_req_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SR_ID_PRESENT 0x0001
#define LC_PRIORITY_PRESENT 0x0002
#define PBR_PRESENT         0x0004
#define BSD_PRESENT         0x0008  

  /* 0-7 is the logical channel group Id of the LC. */
  UInt8 LcGId;
  /*^ M, 0, H, 0, 7 ^*/

  /* The ID of the SchedulingRequestConfig that uses this scheduling request resource. */
  UInt8	scheduling_request_id;
  /*^ O, SR_ID_PRESENT, H, 0, MAX_SR_RESOURCES_ID ^*/ 

  UInt8	lc_id_priority;
  /*^ O,LC_PRIORITY_PRESENT, B, 1, 16 ^*/ 

  UInt8	priority_bit_rate;
  /*^ O,PBR_PRESENT, H, 0, infinity ^*/ 

  UInt8	bucket_size_duration;
  /*^ O,BSD_PRESENT, H, 0, ms1000 ^*/ 
}ul_lc_create_req_t;


typedef struct _gbr_qos_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/

  /* Reference 3GPP TS 38.473 Section GBR QoS Information */
  /* (0.. 4,000,000,000,000) bits/sec  Maximum Bit Rate in DL */
  UInt64  dl_maximum_bit_rate;
  /*^ M, 0, H, 0, 4000000000000 ^*/ 

  /* Reference 3GPP TS 38.473 Section GBR QoS Information */
  /* (0.. 4,000,000,000,000) bits/sec  Maximum Bit Rate in UL */
  UInt64  ul_maximum_bit_rate;
  /*^ M, 0, H, 0, 4000000000000 ^*/ 

  /* Reference 3GPP TS 38.473 Section GBR QoS Information */
  /* (0.. 4,000,000,000,000) bits/sec  Guaranteed Bit Rate in DL */
  UInt64  dl_guaranteed_bit_rate;
  /*^ M, 0, H, 0, 4000000000000 ^*/ 

  /* Reference 3GPP TS 38.473 Section GBR QoS Information */
  /* (0.. 4,000,000,000,000) bits/sec  Guaranteed Bit Rate in UL */
  UInt64  ul_guaranteed_bit_rate;
  /*^ M, 0, H, 0, 4000000000000 ^*/ 

}gbr_qos_info_t;

typedef struct _qos_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/
#define GBR_QOS_INFO_PRESENT 0x0001

  /* 0 to 1  Enum (0 .GBR, 1 . NON_GBR) */
  UInt8 bearer_type;
  /*^ M, 0, H, 0, 1 ^*/ 

  /* 0 to 255 Supported QCI at MAC */
  UInt8 qci;
  /*^ M, 0, H, 0, 255 ^*/ 

  /* Applies for GBR bearers */
  gbr_qos_info_t gbr_qos_info; 
  /*^ O, GBR_QOS_INFO_PRESENT, N, 0, 0 ^*/

}qos_info_t;


typedef struct _lc_create_req_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define UL_LC_CREATE_PRESENT  0x0001
#define DL_LC_CREATE_PRESENT  0x0002
#define QOS_INFO_PRESENT      0x0004

  /*  It is the logical channel id. */
  UInt8 lch_id;
  /*^ M, 0, H, 0, 31 ^*/ 

  /* indicates the type of rlc mode i.e. Acknowledge Mode, Un-acknowledge Mode or Transparent Mode.
     0 - Transparent Mode,1 - Unacknowledged Mode, 2 - Acknowledged Mode */
  UInt8 rlc_mode;
  /*^ M, 0, H, 0, 2 ^*/

  /* Should be present for Uplink LC request. */
  ul_lc_create_req_t  ul_lc_create_req;
  /*^ O, UL_LC_CREATE_PRESENT, N, 0, 0 ^*/

  /* Should be present for Downlink LC request. */
  dl_lc_create_req_t  dl_lc_create_req;
  /*^ O, DL_LC_CREATE_PRESENT, N, 0, 0 ^*/

  /* Qos_info contains QOS information of the logical channel that is being created/modified. 
     Not present for SRBs. Valid only for LCs mapping to DRBs. */
  qos_info_t  qos_info; 
  /*^ O, QOS_INFO_PRESENT, N, 0, 0 ^*/

}lc_create_req_t;

typedef struct _create_lc_req_list_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define LC_CREATE_PRESENT 0x0001

  UInt8 lc_id_count;
  /*^ M, 0, H, 0, 32 ^*/

  lc_create_req_t lc_create_req_list[MAX_LC_COUNT];
  /*^ O, LC_CREATE_PRESENT, OCTET_STRING, VARIABLE ^*/
}create_lc_req_list_t; 


typedef struct _tag_to_add_mod_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Timing Advance Group ID. Only TAG ID 0 shall be configured in current release. */
  UInt8 tag_id;
  /*^ M, 0, H, 0, 3 ^*/

  /* The enumerated value: 0 - ms500,1  ms750,2  ms1280,3  ms1920,4  ms2560,5  ms5120,6  ms10240,7  
   * infinity Refer TAG in MAC-CellGroupConfig (3GPP TS 38.331) */
  UInt8 time_alignment_timer;
  /*^ M, 0, H, 0, 7 ^*/

}tag_to_add_mod_info_t;

typedef struct _cell_gp_tag_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define TAG_TO_ADD_LIST_PRESENT 0x0001

  /* 1 to 4  Specifies the count of TAGS configured in the tag_to_add_mod_list. Only 1 tag shall be configured in current release. */
  UInt8 tag_add_mod_count;
  /*^ M, 0, B, 1, 4 ^*/

  /* Refer TAG-Config in MAC-CellGroupConfig (3GPP TS 38.331) */
  tag_to_add_mod_info_t tag_to_add_mod_list[MAX_NUM_TAGS];
  /*^ O, TAG_TO_ADD_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/

}cell_gp_tag_config_t;

typedef struct _sr_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/
#define SR_CONF_PROHIBIT_TIMER_PRESENT   0x0001

  /* The IE SchedulingRequestId is used to identify a Scheduling Request instance in the MAC layer. */
  UInt8 scheduling_request_id;
  /*^ M, 0, H, 0, 7 ^*/

  /* The enumerated value: 0 - n4,1 - n8,2 - n16,3 - n32,4 - n64,5 - spare3,6 - spare2, 7 - spare1  Maximum number of SR
   * transmissions as described in 38.321 [3]. n4 corresponds to 4, n8 corresponds to 8, and so on. */
  /* In current release n4 shall be configured from Higher Layers as the default value. */
  UInt8 sr_trans_max;
  /*^ M, 0, H, 0, 7 ^*/

  /* The enumerated value:0 - ms1,1 - ms2,2 - ms4,3 - ms8,4 - ms16,5 - ms32,6 - ms64,
     7 - ms128 Timer for SR transmission on PUCCH in TS 38.321 [3]. Value in ms.
     ms1 corresponds to 1ms, ms2 corresponds to 2ms, and so on.  When the field is absent, the UE applies the value 0. */
  /* In current release, 16ms shall be configured as default value. (considering 4 DL + 1 UL Configuration,
   * it may take from minimum 10 slots to schedule the DCI -0, with a configured K2 offset of 4) */
  UInt8 sr_prohibit_timer;
  /*^ O, SR_CONF_PROHIBIT_TIMER_PRESENT, H, 0, 7 ^*/

}sr_config_info_t;

typedef struct _sr_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SR_TO_ADD_LIST_PRESENT  0x0001

  /* Specifies the count of SR resources in the sr_to_add_mod_list */
  UInt8 sr_add_mod_count;
  /*^ M, 0, B, 1, 8 ^*/

  /* Refer SchedulingRequestConfig in MAC-CellGroupConfig (3GPP TS 38.331) */
  sr_config_info_t  sr_to_add_mod_list[MAX_SR_CONFIG_PER_CELL_GROUP];
  /*^ O, SR_TO_ADD_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/ 

}sr_config_t;

typedef struct
{
    /* Periodic PHR timer (phr_periodic_timer_et) */
    UInt32  phr_periodic_timer;
    /*^ M, 0, N, 0, 0 ^*/

    /* PHR Prohibit timer (phr_prohibit_timer_et) */
    UInt32  phr_prohibit_timer;
    /*^ M, 0, N, 0, 0 ^*/

    /* PHR Tx Power change factor (phr_tx_power_factor_change_et) */
    UInt32  phr_tx_power_factor_change;
    /*^ M, 0, N, 0, 0 ^*/

    /* Flag to indicate if power headroom shall be reported using
     *      * multiple PHR MAC control element */
    UInt8   multiple_phr_enabled;
    /*^ M, 0, N, 0, 0 ^*/

    /* Flag to indicate whether to report PHR type2 for PCell */
    UInt8   phr_type2_sp_cell;
    /*^ M, 0, N, 0, 0 ^*/

    /* Flag to indicate whether to report PHR type2 for PSCell 
     *      * and PUCCH sCells */
    UInt8   phr_type2_other_cell;
    /*^ M, 0, N, 0, 0 ^*/

    /* PHR Mode for other CG (phr_mode_other_cg_et) */
    UInt32  phr_mode_other_cg;
    /*^ M, 0, N, 0, 0 ^*/

} phr_config_info_t;


typedef struct _ul_mac_cell_group_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SR_CONFIG_PRESENT 0x0001
#define TAG_CONFIG_PRESENT  0x0002
#define PHR_CONFIG_INFO_PRESENT 0x0004

  /* Refer MAC-CellGroupConfig (3GPP TS 38.331) */
  cell_gp_tag_config_t  tag_config;
  /*^ O, TAG_CONFIG_PRESENT, N, 0, 0 ^*/

  /* Refer MAC-CellGroupConfig (3GPP TS 38.331) */
  sr_config_t   sr_config;
  /*^ O, SR_CONFIG_PRESENT, N, 0, 0 ^*/
  phr_config_info_t            phr_config_info;
  /*^ O, PHR_CONFIG_INFO_PRESENT, N, 0, 0 ^*/

}ul_mac_cell_group_config_t;

typedef struct _betaoffsets_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define BETAOFFSETACK_INDEX1_PRESENT        0x0001
#define BETAOFFSETACK_INDEX2_PRESENT        0x0002
#define BETAOFFSETACK_INDEX3_PRESENT        0x0004
#define BETAOFFSETCSI_PART1_INDEX1_PRESENT  0x0008
#define BETAOFFSETCSI_PART1_INDEX2_PRESENT  0x0010
#define BETAOFFSETCSI_PART2_INDEX1_PRESENT  0x0020
#define BETAOFFSETCSI_PART2_INDEX2_PRESENT  0x0040

  /* 0 to 31 Up to 2 bits HARQ-ACK. Corresponds to L1 parameter 'betaOffset-ACK-Index-1' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 11 */
  UInt8 betaOffsetACK_Index1;
  /*^ O, BETAOFFSETACK_INDEX1_PRESENT, H, 0, 31 ^*/

  /*0 to 31  Up to 11 bits HARQ-ACK. Corresponds to L1 parameter 'betaOffset-ACK-Index-2' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 11 */
  UInt8 betaOffsetACK_Index2;
  /*^ O, BETAOFFSETACK_INDEX2_PRESENT, H, 0, 31 ^*/

  /* 0 to 31 Above 11 bits HARQ-ACK. Corresponds to L1 parameter 'betaOffset-ACK-Index-3' (see 38.213, section 9.3) 
 * When the field is absent the UE applies the value 11 */
  UInt8 betaOffsetACK_Index3;
  /*^ O, BETAOFFSETACK_INDEX3_PRESENT, H, 0, 31 ^*/
  
  /* Up to 11 bits of CSI Part1. Corresponds to L1 parameter 'betaOffsetCSI-Part1-Index1" (see 38.213, section 9.3) 
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCSI_part_1_index_1;
  /*^ O, BETAOFFSETCSI_PART1_INDEX1_PRESENT, H, 0, 31 ^*/

  /* Up to 11 bits of CSI Part1. Corresponds to L1 parameter 'betaOffsetCSI-Part1-Index2" (see 38.213, section 9.3) 
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCSI_part_1_index_2;
  /*^ O, BETAOFFSETCSI_PART1_INDEX2_PRESENT, H, 0, 31 ^*/

  /* Up to 11 bits of CSI Part1. Corresponds to L1 parameter 'betaOffsetCSI-Part2-Index1" (see 38.213, section 9.3) 
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCSI_part_2_index_1;
  /*^ O, BETAOFFSETCSI_PART2_INDEX1_PRESENT, H, 0, 31 ^*/

  /* Up to 11 bits of CSI Part1. Corresponds to L1 parameter 'betaOffsetCSI-Part2-Index2" (see 38.213, section 9.3) 
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCSI_part_2_index_2;
  /*^ O, BETAOFFSETCSI_PART2_INDEX2_PRESENT, H, 0, 31 ^*/


  /* 0 to 31  Up to 11 bits CSI. Corresponds to L1 parameter 'betaOffsetCSI-Part1-Index1' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCsiPart1Index1;
  /*^ O, BETAOFFSETCSI_PART1_INDEX1_PRESENT, H, 0, 31 ^*/

  /* 0 to 31  Up to 11 bits CSI. Corresponds to L1 parameter 'betaOffsetCSI-Part1-Index2' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCsiPart1Index2;
  /*^ O, BETAOFFSETCSI_PART1_INDEX2_PRESENT, H, 0, 31 ^*/

  /* 0 to 31  Up to 11 bits CSI. Corresponds to L1 parameter 'betaOffsetCSI-Part2-Index1' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCsiPart2Index1;
  /*^ O, BETAOFFSETCSI_PART2_INDEX1_PRESENT, H, 0, 31 ^*/

  /* 0 to 31  Up to 11 bits CSI. Corresponds to L1 parameter 'betaOffsetCSI-Part2-Index2' (see 38.213, section 9.3)
   * When the field is absent the UE applies the value 13 */
  UInt8 betaOffsetCsiPart2Index2;
  /*^ O, BETAOFFSETCSI_PART2_INDEX2_PRESENT, H, 0, 31 ^*/

}betaoffsets_config_t;

typedef struct _transform_precoding_enabled_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define NPUSCH_ID_PRESENT 0x0001 
#define DISABLE_SEQ_GP_HOPPING_PRESENT  0x0002 
#define ENABLE_SEQ_HOPPING_PRESENT  0x0004 

  /* 0-1007  Parameter: N_ID^(PUSCH) for DFT-s-OFDM DMRS. If the value is absent or released, the UE uses the Physical cell ID 
     (see 38.211, section FFS_Section)  */
  UInt16  nPUSCH_Identity;
  /*^ O, NPUSCH_ID_PRESENT, H, 0, 1007 ^*/ 

  /* The enumerated value: 0  Disabled;1- Enabled  Sequence-group hopping for PUSCH can be disabled for a certain UE 
   * despite being enabled on a cell basis. For DFT-s-OFDM DMRS when the field is absent, 
     the UE considers group hopping to be enabled (see 38.211, section FFS_Section) */
  UInt8 Disable_sequence_group_hopping;
  /*^ O, DISABLE_SEQ_GP_HOPPING_PRESENT, H, 0, 1 ^*/ 

  /* The enumerated value: 0  Disabled ;1 - Enabled Determines if sequence hopping is enabled or not. For DFT-s-OFDM DMRS. 
   * If the field is absent, the UE considers sequence hopping to be disabled (see 38.211, section FFS_Section) */
  UInt8 Sequence_hopping_enabled;
  /*^ O, ENABLE_SEQ_HOPPING_PRESENT, H, 0, 1 ^*/

}transform_precoding_enabled_t;

typedef struct _transform_precoding_disabled_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define SCRAMBLING_ID0_PRESENT  0x0002
#define SCRAMBLING_ID1_PRESENT  0x0004

  /* 0-65535  UL DMRS scrambling initalization for CP-OFDM Corresponds to L1 parameter 'n_SCID 0'  */
  UInt16  scramblingID0;
  /*^ O, SCRAMBLING_ID0_PRESENT, H, 0, 65535 ^*/

  /* 0-65535  UL DMRS scrambling initalization for CP-OFDM. Corresponds to L1 parameter 'n_SCID 1' */
  UInt16  scramblingID1;
  /*^ O, SCRAMBLING_ID1_PRESENT, H, 0, 65535 ^*/

}transform_precoding_disabled_t;

typedef struct _ul_ptrs_tpd_config_t
{
 /* To inform optional parameter presence */
  bitmask_t bitmask;
   /*^ BITMASK ^*/
#define  UL_PTRS_FREQ_DENSITY_PRESENT 0x0001
#define  UL_PTRS_TIME_DENSITY_PRESENT 0x0002

  UInt8  re_offset;
  /*^ M, 0, B, 0, 3 ^*/

  UInt8  ptrs_power;
  /*^ M, 0, B, 0, 3 ^*/

  UInt8  max_ports;
   /*^ M, 0, B, 0, 1 ^*/

  /* PRB Count, values in ascending order, range values should be within configured cell BW */
  UInt16 freq_density[MAX_PTRS_CONFIG_FREQ_DENSITY];
   /*^ O, UL_PTRS_FREQ_DENSITY_PRESENT, OCTET_STRING, FIXED ^*/

  /* UE configuration with UL MCS as per Table 5.1.3.1-1 (64QAM) or Table 5.1.3.1-2 (256 QAM) or Table 5.1.3.1-2 (64 LOWSE QAM) of 38.214 */
  UInt8 time_density[MAX_PTRS_CONFIG_TIME_DENSITY];
  /*^ O, UL_PTRS_TIME_DENSITY_PRESENT, OCTET_STRING, FIXED ^*/
}ul_ptrs_tpd_config_t;

typedef struct _ul_ptrs_tpe_config_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
     /*^ BITMASK ^*/
#define UL_TPE_TRANSFORM_PRECODING_PRESENT 0x0001

    UInt16 sample_density[MAX_PTRS_CONFIG_SAMPLE_DENSITY];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    UInt8  time_density_transform_precoding;
    /*^ O, UL_TPE_TRANSFORM_PRECODING_PRESENT, N, 0, 0^*/
 
}ul_ptrs_tpe_config_t;

typedef struct _ul_ptrs_config_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
     /*^ BITMASK ^*/
#define UL_PTRS_TP_DISABLED_PRESENT 0x0001
#define UL_PTRS_TP_ENABLED_PRESENT 0x0002
    
    /* PTRS configurable for UL allocation with �Transform Precoding Disabeld� */
    ul_ptrs_tpd_config_t ul_ptrs_tp_disabled;
    /*^ O, UL_PTRS_TP_DISABLED_PRESENT, N, 0, 0 ^*/

   /* PTRS configurable for UL allocation with �Transform Precoding Enabeld� */
    ul_ptrs_tpe_config_t ul_ptrs_tp_enabled;
   /*^ O, UL_PTRS_TP_ENABLED_PRESENT, N, 0, 0 ^*/
}ul_ptrs_config_t;

typedef struct _dmrs_uplink_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DMRS_TYPE_PRESENT 0x0001
#define DMRS_ADDITIONAL_POSITION_PRESENT  0x0002
#define MAX_LENGTH_PRESENT  0x0004
#define TRANSFORM_PRECODING_ENABLED_PRESENT 0x0008
#define TRANSFORM_PRECODING_DISABLED_PRESENT  0x0010
#define UL_PTRS_PRESENT 0x0020  

  /* The enumerated value 0 - Type2  Selection of the DMRS type to be used for UL (see section 38.211, section 6.4.1.1.3)
   * If the field is absent, the UE uses DMRS type 1.  */
  UInt8 dmrs_type;
  /*^ O, DMRS_TYPE_PRESENT, H, 0, 2 ^*/

  /* The enumerated value: 0 - pos0;1 � pos1;2 � pos3 Position for additional DM-RS in UL, see Table 7.4.1.1.2-4 in 38.211.
   * If the field is absent, the UE applies the value pos2. */
  /* Currently value 0 shall be used. */
  UInt8 dmrs_additional_position;
  /*^ O, DMRS_ADDITIONAL_POSITION_PRESENT, H, 0, 2 ^*/

  /* The enumerated value: 0 len2  The maximum number of OFDM symbols for UL front loaded DMRS. If the field is absent, 
 * the UE applies value len1. (see 38.214, section 6.4.1.1.2)  */
  /*Not configured in the current release. */
  UInt8 max_length;
  /*^ O, MAX_LENGTH_PRESENT, H, 0, 2 ^*/

  /* Configuration of transform_precoding_disabled */
  transform_precoding_disabled_t transform_precoding_disabled;
  /*^ O, TRANSFORM_PRECODING_DISABLED_PRESENT, N, 0, 0 ^*/

  /* Configuration of transform_precoding_enabled *//* Not configured in the current release. */
  transform_precoding_enabled_t transform_precoding_enabled;
  /*^ O, TRANSFORM_PRECODING_ENABLED_PRESENT, N, 0, 0 ^*/

  /* PTRS Configuration */
  ul_ptrs_config_t ptrs_config;
  /*^ O, UL_PTRS_PRESENT, N, 0, 0 ^*/
}dmrs_uplink_config_t;


typedef struct _uci_on_pusch_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DYNAMIC_BETA_OFFSETS_PRESENT  0x0001
#define SEMISTATIC_BETA_OFFSETS_PRESENT 0x0002
#define UCI_ON_PUSCH_SCALING_PRESENT  0x0004

  /* Configuration of dynamic beta-offset. */
  betaoffsets_config_t  Dynamic_beta_offsets[MAX_BETA_OFFSETS];
  /*^ O, DYNAMIC_BETA_OFFSETS_PRESENT, OCTET_STRING, FIXED ^*/

  /* Configuration of semi-static beta-offset. */
  betaoffsets_config_t  semistatic_beta_offsets;
  /*^ O, SEMISTATIC_BETA_OFFSETS_PRESENT, N, 0, 0 ^*/

  /* The enumerated value: 0 - f0p5,1 - f0p65,2 - f0p8, 3  f1,  Indicates a scaling factor to limit the number of 
   * resource elements assigned to UCI on PUSCH. Value f0p5 corresponds to 0.5,
     value f0p65 corresponds to 0.65, and so on. Corresponds to L1 parameter 'uci-on-pusch-scaling' (see 38.212, section 6.3). */
  UInt8 uci_on_pusch_scaling;
  /*^ O, UCI_ON_PUSCH_SCALING_PRESENT, H, 0, 3 ^*/

}uci_on_pusch_info_t;

typedef struct _po_pusch_alpha_set_info_t
{

    bitmask_t   bitmask;
  /*^ BITMASK ^*/

    UInt8   p0_pusch_alpha_set_id;
  /*^ M, 0, H, 0, MAX_P0_PUSCH_ALPHA_SETS ^*/

    SInt8   p0;
  /*^ M, 0, B, -16, 15 ^*/

    /* alpha_et */
    /* receives value multiplied by 10 */
    UInt8  alpha;
  /*^ M, 0, H, 0, 7 ^*/

} po_pusch_alpha_set_info_t;


typedef struct _pusch_power_control_p0_alpha_sets_info_t
{
    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    UInt8   count;
    /*^ M, 0, B, 1, MAX_NUM_P0_PUSCH_ALPHA_SETS  ^*/

    po_pusch_alpha_set_info_t  
        p0_alpha_set[MAX_NUM_P0_PUSCH_ALPHA_SETS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/ 

} pusch_power_control_p0_alpha_sets_info_t;

typedef struct _pusch_path_loss_reference_rs_info_t
{
#define PUSCH_PATH_LOSS_REFERENCE_RS_SSB_INDEX_PRESENT  0x01
#define PUSCH_PATH_LOSS_REFERENCE_RS_CSI_RS_INDEX_PRESENT  0x02

    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    UInt8   pusch_pathloss_reference_rs_id;
    /*^ M, 0, H, 0, MAX_PUSCH_RL_RS  ^*/

    UInt8   ssb_index;
    /*^ O, PUSCH_PATH_LOSS_REFERENCE_RS_SSB_INDEX_PRESENT, H, 0, 63  ^*/

    UInt8   csi_rs_index;
    /*^ O, PUSCH_PATH_LOSS_REFERENCE_RS_CSI_RS_INDEX_PRESENT, H, 0, 191  ^*/

} pusch_path_loss_reference_rs_info_t;

typedef struct _path_loss_reference_rs_to_add_mod_list_t
{
    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    UInt8   count;
  /*^ M, 0, B, 1, MAX_NUM_PUSCH_RL_RS ^*/

    pusch_path_loss_reference_rs_info_t
        pusch_path_loss_reference_rs[MAX_NUM_PUSCH_RL_RS];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/ 

} path_loss_reference_rs_to_add_mod_list_t;

typedef struct _path_loss_reference_rs_to_rel_list_t
{
    bitmask_t       bitmask;
    /*^ BITMASK ^*/

    UInt8  count;
  /*^ M, 0, B, 1, MAX_NUM_PUSCH_RL_RS ^*/

    UInt8  pathloss_reference_id[MAX_NUM_PUSCH_RL_RS];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/ 

} path_loss_reference_rs_to_rel_list_t;

typedef struct _pusch_power_control_config_t
{
#define PUSCH_POWER_CONTROL_CONFIG_TPC_ACCUMULATION_PRESENT                      0x01
#define PUSCH_POWER_CONTROL_CONFIG_MSG3_ALPHA_PRESENT                            0x02
#define PUSCH_POWER_CONTROL_CONFIG_P0_NOMINAL_WITHOUT_GRANT_PRESENT              0x04
#define PUSCH_POWER_CONTROL_CONFIG_P0_ALPHA_SETS_INFO_PRESENT                    0x08
#define PUSCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_TO_ADD_MOD_PRESENT         0x10
#define PUSCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_TO_REL_PRESENT             0x20
#define PUSCH_POWER_CONTROL_CONFIG_TWO_PUSCH_PC_ADJUSTMENT_STATES_PRESENT        0x40
#define PUSCH_POWER_CONTROL_CONFIG_DELTA_MCS_PRESENT                             0x80

    bitmask_t       bitmask;
  /*^ BITMASK ^*/

    UInt8        tpc_accumulation_disabled;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_TPC_ACCUMULATION_PRESENT, H, 0, 1 ^*/

    /* alpha_et */
    UInt32       msg3_alpha;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_MSG3_ALPHA_PRESENT, N, 0, 0 ^*/

    SInt16       p0_nominal_without_grant;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_P0_NOMINAL_WITHOUT_GRANT_PRESENT, B, -202, 24 ^*/

    pusch_power_control_p0_alpha_sets_info_t
        p0_alpha_sets;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_P0_ALPHA_SETS_INFO_PRESENT, N, 0, 0 ^*/

    path_loss_reference_rs_to_add_mod_list_t
        pathloss_reference_rs_to_add_mod_list;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_TO_ADD_MOD_PRESENT, N, 0, 0 ^*/

    path_loss_reference_rs_to_rel_list_t
        pathloss_reference_rs_to_rel_list;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_TO_REL_PRESENT, N, 0, 0 ^*/

    /* pusch_power_cntrl_two_pusch_pc_adjustment_states_et */
    UInt32       two_pusch_pc_adjustment_states;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_TWO_PUSCH_PC_ADJUSTMENT_STATES_PRESENT, H, 0, 1 ^*/

    UInt8        delta_mcs_enabled;
  /*^ O, PUSCH_POWER_CONTROL_CONFIG_DELTA_MCS_PRESENT, H, 0, 1 ^*/


} pusch_power_control_config_t;


typedef struct _pusch_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CODE_BOOK_SUBSET_PRESENT  0x0001
#define MAX_RANK_PRESENT  0x0002
#define DATA_SCRAMBLING_ID_PRESENT  0x0004
#define PUSCH_ALLOCATION_UL_TYPEA_PRESENT 0x0008 
#define PUSCH_ALLOCATION_UL_TYPEB_PRESENT 0x0010 
#define PUSCH_POWER_CONTROL_PRESENT 0x0020

  /* 0 = codebook;1 = non-Codebook Refer txConfig in PUSCH-Config (3GPP TS 38.331). Only non-Codebook is supported in Current Release. */
  UInt8 tx_config;
  /*^ M, 0, H, 0, 1 ^*/

  /* 0  disabled;1  mode1;2  mode2 Refer frequencyHopping in PUSCH-Config (3GPP TS 38.331). 
   * Frequency hopping is disabled in current Release. */
  UInt8 freq_hopping;
  /*^ M, 0, H, 0, 2 ^*/

  /* 0  Type0;1  Type1;2  DynamicSwitch  Refer resourceAllocation in PUSCH-Config (3GPP TS 38.331). 
   * Type 1 is supported in the current release. */
  UInt8 resource_allocation;
  /*^ M, 0, H, 0, 2 ^*/

  /* 0:config1, 1:config2 This is applicapble only for resourceAllocationType0 and ignored otherwise */ 
  UInt8 rbg_size;
  /*^ M, 0, H, 0, 1 ^*/

  /* 0  disabled (No PUSCH Repetition);2  n2; 4  n4; 8  n8 Refer pusch-AggregationFactor in PUSCH-Config (3GPP TS 38.331). 
   * This field will not be present in current release and will be set to disabled which means no PUSCH repetition. */
  UInt8 aggregation_factor;
  /*^ M, 0, H, 0, 8 ^*/

  /* 0  NR_FALSE;1  NR_TRUE  Refer mcs-Table in PUSCH-Config (3GPP TS 38.331). Shall be disabled in current release. */
  UInt8 mcs_table_enabled;
  /*^ M, 0, H, 0, 1 ^*/

  /* 0  NR_FALSE;1  NR_TRUE  Refer mcs-TableTransformPrecoder in PUSCH-Config (3GPP TS 38.331). 
   * NR_TRUE means 256qam table will be used. This parameter is used only if transform_precoder_enabled flag is TRUE. */
  /* Not Supported in current release. */
  UInt8 mcs_table_transform_precoder_enabled;
  /*^ M, 0, H, 0, 1 ^*/

  /* 0  NR_FALSE;1  NR_TRUE  Refer transformPrecoder in PUSCH-Config (3GPP TS 38.331). 
   * Transform Precoder would be disabled in current release. */
  UInt8 transform_precoder_enabled;
  /*^ M, 0, H, 0, 1 ^*/

  /*Selection between and configuration of dynamic and semi-static beta-offset. If the field is absent or released, 
   * the UE applies the value 'semiStatic' and the BetaOffsets according to FFS [BetaOffsets and/or section 9.x.x). 
   * Corresponds to L1 parameter 'UCI-on-PUSCH' (see 38.213, section 9.3). */
  uci_on_pusch_info_t uci_on_pusch;
  /*^ M, 0, N, 0, 0 ^*/

  /* 0 - fullyAndPartialAndNonCoherent;1 - partialAndNonCoherent;2 - nonCoherent  Refer codebookSubset in PUSCH-Config (3GPP TS 38.331) */
  /* This field is valid only if tx_config field is set to codebook, which is not supported in current release. */
  UInt8 codebook_subset;
  /*^ O, CODE_BOOK_SUBSET_PRESENT, H, 0, 2 ^*/

  /* Refer maxRank in PUSCH-Config (3GPP TS 38.331). This field is valid only if tx_config field is set to codebook */
  UInt8 max_rank;
  /*^ O, MAX_RANK_PRESENT, H, 0, 4 ^*/

  /* Refer dataScramblingIdentityPUSCH in PUSCH-Config (3GPP TS 38.331) */
  UInt16  data_sc_id;
  /*^ O, DATA_SCRAMBLING_ID_PRESENT, H, 0, 1023 ^*/

  /* DMRS configuration for PUSCH transmissions using PUSCH mapping type A */
  dmrs_uplink_config_t  dmrs_UplinkForPUSCH_MappingTypeA;
  /*^ O, PUSCH_ALLOCATION_UL_TYPEA_PRESENT, N, 0, 0^*/

  /* DMRS configuration for PUSCH transmissions using PUSCH mapping type B */
  dmrs_uplink_config_t  dmrs_UplinkForPUSCH_MappingTypeB;
  /*^ O, PUSCH_ALLOCATION_UL_TYPEB_PRESENT, N, 0, 0^*/
  /* PUSCH power calculation values */
  pusch_power_control_config_t pusch_power_control;
  /*^ O, PUSCH_POWER_CONTROL_PRESENT, N, 0, 0^*/

}pusch_config_info_t;


typedef struct _ue_pusch_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PUSCH_CONFIG_INFO_PRESENT 0x0001

  /* Refer PUSCH-Config in BWP-UplinkDedicated (3GPP TS 38.331). This field is configured if PUSCH_CONFIG_INFO_PRESENT is set in bitmask */
  pusch_config_info_t pusch_config_info;
  /*^ O, PUSCH_CONFIG_INFO_PRESENT, N, 0, 0 ^*/

}ue_pusch_config_t;

typedef struct _ue_pucch_format_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define MAX_CODE_RATE_PRESENT 0x0001

  /* The enumerated value:
     0 - zeroDot08
     1 - zeroDot15
     2-  zeroDot25
     3 - zeroDot35
     4 - zeroDot45
     5 - zeroDot60
     6 - zeroDot80 Max coding rate to determine how to feedback UCI on PUCCH for format 2, 3 or 4.
     The field is not applicable for format 1. See TS 38.213, section 9.2.5. */
  UInt8 max_code_rate;
  /*^ O, MAX_CODE_RATE_PRESENT, H, 0, 6 ^*/

}ue_pucch_format_config_t;

typedef struct _resource_list_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  UInt8 pucch_resource;
  /*^ M, 0, H, 0, MAX_PUCCH_RESOURCES ^*/
}resource_list_t;

typedef struct _pucch_resource_set_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define MAX_PAYLOAD_PRESENT 0x0001

  /* MAX_NUM_PUCCH_RESOURCE_SETS  1 ID of the PUCCH resource set. Maximum of 4 PUCCH Resource sets 
   * could be configured for a UE. Initial Resource set has the ID 0. */
  UInt8 pucch_resource_set_Id;
  /*^ M, 0, H, 0, MAX_PUCCH_RESOURCE_SETS ^*/ 

  /* List count of resource_list */
  UInt8 resource_list_count;
  /*^ M, 0, H, 1, MAX_NUM_PUCCH_RESOURCE_PER_SET ^*/ 

  /* MAX_NUM_PUCCH_RESOURCES -1 List of PUCCH-ResourceId. PUCCH resources of format0 and format1 are only allowed 
 * in the first PUCCH resource set, i.e., in a PUCCH-ResourceSet with pucch-ResourceSetId = 0. This set may contain 
 * between 1 and 32 resources. PUCCH resources of format2, format3 and format4 are only allowed  in a PUCCH-ResourceSet 
 * with pucch-ResourceSetId > 0. If present, these sets contain between 1 and 8 resources each.
 * Note that this list contains only a list of resource IDs. The actual resources are configured in PUCCH-Config. */
  resource_list_t resource_list [MAX_NUM_PUCCH_RESOURCE_PER_SET];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/ 

  /* Maximum number of payload bits minus 1 that the UE may transmit using this PUCCH resource set. In a PUCCH occurrence, 
   * the UE chooses the first of its PUCCH-ResourceSet which supports the number of bits that the UE wants to transmit. 
   * The field is not present in the first set (Set0) since the maximum Size of Set0 is specified to be 3 bit. 
   * The field is not present in the last configured set since the UE derives its maximum payload size as specified in 38.213.
   * This field can take integer values that are multiples of 4. Corresponds to L1 parameter 'N_2' or 'N_3' (see TS 38.213, section 9.2). */
  UInt16      Max_payload_minus_1;
  /*^ O, MAX_PAYLOAD_PRESENT, B, 4, 256 ^*/ 

}pucch_resource_set_config_t;

typedef struct _dl_data_to_ul_ack_list_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    /* Corresponds to L1 parameter 'Slot-timing-value-K1'. Values 0 to 7 (K1) can be configured initially, corresponding to the array index. 
       MAC would dynamically pick values out of the configured values. */
    UInt8 dl_data_to_ul_ack;
    /*^ M, 0, H, 0, 15 ^*/ 

}dl_data_to_ul_ack_list_t;

typedef struct _pusch_power_reconfig_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    /* Index in the p0 alpha sets */
    UInt8 p0_alphaset_id;
    /*^ M, 0, H, 0, MAX_P0_PUSCH_ALPHA_SETS ^*/ 

    /* P0 value for PUSCH with grant (except msg3) in steps of 1dB.
     * Reference 3GPP TS 38.213 Section 7.1*/
    SInt8 p0;
    /*^ M, 0, B, -16, 15 ^*/

}pusch_power_reconfig_info_t;

typedef struct _pucch_power_reconfig_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    /* Index in the p0 pucch  */
    UInt8 p0_pucch_id;
    /*^ M, 0, B, 1, MAX_NUM_P0_PUCCH_SETS ^*/

    /* P0 value for PUCCH with 1dB step size.
     * Reference 3GPP TS 38.213 Section 7.1*/
    SInt8 p0_pucch_value;
    /*^ M, 0, B, -16, 15 ^*/

}pucch_power_reconfig_info_t;

typedef struct _powercoordination_fr1_t
{
#define POWERCOORDINATION_FR1_P_MAX_NR_FR1 0x0001
#define POWERCOORDINATION_FR1_P_MAX_EUTRA  0x0002
#define POWERCOORDINATION_FR1_P_MAX_UE_FR1 0x0004
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    SInt8 p_max_nr_fr1;
    /*^ O, POWERCOORDINATION_FR1_P_MAX_NR_FR1, B, -30, 33 ^*/ 

    SInt8 p_max_eutra;
    /*^ O, POWERCOORDINATION_FR1_P_MAX_EUTRA, B, -30, 33 ^*/ 

    SInt8 p_max_ue_fr1;
    /*^ O, POWERCOORDINATION_FR1_P_MAX_UE_FR1, B, -30, 33 ^*/ 

}powercoordination_fr1_t;

typedef struct _pucch_pathloss_reference_rs_info_t
{
    /* To inform optional parameter presence */
    /*Only ssb-index or csi-rs-index can be configured for 1 Reference Signal.
     * Only ssb-index is supported in current release*/
    bitmask_t bitmask;    
    /*^ BITMASK ^*/
#define PUCCH_PATHLOSS_REFERENCE_RS_INFO_SSB_INDEX_PRESENT  0x0001
#define PUCCH_PATHLOSS_REFERENCE_RS_INFO_CSI_RS_INDEX_PRESENT 0x0002

    UInt8 pucch_pathloss_reference_rs_id;
    /*^ M, 0, H, 0, MAX_PUCCH_RL_RS ^*/ 

    /* SS block to be used for PCUCH path loss estimation */
    UInt8 ssb_index;
    /*^ O, PUCCH_PATHLOSS_REFERENCE_RS_INFO_SSB_INDEX_PRESENT, H, 0, 63 ^*/ 

    /*CSI-RS config to be used for PUCCH path loss estimation*/
    UInt8 csi_rs_index;
    /*^ O, PUCCH_PATHLOSS_REFERENCE_RS_INFO_CSI_RS_INDEX_PRESENT, H, 0, 191 ^*/ 

}pucch_pathloss_reference_rs_info_t;

typedef struct _pucch_pathloss_reference_rs_list_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
    /*^ BITMASK ^*/

    UInt8 count;
    /*^ M, 0, B, 1, MAX_NUM_PUCCH_RL_RS ^*/ 

    pucch_pathloss_reference_rs_info_t pucch_pathloss_reference_rs[MAX_NUM_PUCCH_RL_RS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pucch_pathloss_reference_rs_list_t;

typedef struct _p0_pucch_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Index in the p0 pucch*/ 
  UInt8 p0_pucch_id;
  /*^ M, 0, B, 1, MAX_NUM_P0_PUCCH_SETS ^*/ 

  /* P0 value for PUCCH with 1dB step size.
   * Reference 3GPP TS 38.213 Section 7.1 */
  SInt8 p0_pucch_value;
  /*^ M, 0, B, -16, 15 ^*/ 

}p0_pucch_info_t;

typedef struct _p0_pucch_set_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  UInt8 count;
  /*^ M, 0, B, 1, MAX_NUM_P0_PUCCH_SETS ^*/ 

  /* List of p0 pucch sets. Only 1 set is supported in current release */
  p0_pucch_info_t p0_pucch[MAX_NUM_P0_PUCCH_SETS];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}p0_pucch_set_t;

typedef struct _pucch_power_control_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F0_PRESENT 0x0001
#define PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F1_PRESENT 0x0002
#define PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F2_PRESENT 0x0004
#define PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F3_PRESENT 0x0008
#define PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F4_PRESENT 0x0010
#define PUCCH_POWER_CONTROL_CONFIG_TWO_PUCCH_PC_ADJUSTMENT_STATES_PRESENT 0x0020
#define PUCCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_RS_LIST_PRESENT 0x0040

  /* deltaF for PUCCH format 0 with 1dB step size.*/
  SInt8 deltaf_pucch_f0;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F0_PRESENT, B, -16, 15 ^*/ 

  /* deltaF for PUCCH format 1 with 1dB step size.*/
  SInt8 deltaf_pucch_f1;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F1_PRESENT, B, -16, 15 ^*/ 

  /* deltaF for PUCCH format 2 with 1dB step size.*/
  SInt8 deltaf_pucch_f2;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F2_PRESENT, B, -16, 15 ^*/ 

  /* deltaF for PUCCH format 3 with 1dB step size.*/
  SInt8 deltaf_pucch_f3;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F3_PRESENT, B, -16, 15 ^*/ 

  /* deltaF for PUCCH format 4 with 1dB step size.*/
  SInt8 deltaf_pucch_f4;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_DELTAF_PUCCH_F4_PRESENT, B, -16, 15 ^*/ 
  
  /* A set with dedicated P0 values for PUCCH, i.e.,  {P01, P02,... }.
   * Reference 3GPP TS 38.213 Section 7.2*/
  p0_pucch_set_t p0_pucch_set;
  /*^ M, 0, N, 0, 0 ^*/ 

  /* pucch_power_cntrl_two_pucch_pc_adjustment_states_et */
  UInt8       two_pucch_pc_adjustment_states;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_TWO_PUCCH_PC_ADJUSTMENT_STATES_PRESENT, H, 0, 1 ^*/

  pucch_pathloss_reference_rs_list_t pucch_pathloss_reference_rs_list;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_PATHLOSS_REFERENCE_RS_LIST_PRESENT, N, 0, 0 ^*/

}pucch_power_control_config_t;

typedef struct _pucch_spatialrelation_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/

    /*PUCCH Spatial Relation Info Identifier*/
    UInt8    pucch_spatialrelation_info_id;
    /*^M, 0, B, 1, 8^*/

    /*TCI state for the SS/Block index*/
    UInt8    tci_state_id;
     /*^M, 0, B, 0, 127^*/

    /*Reference Signal to be used for PUCCH pathloss estimation */
    UInt8     pucch_pathloss_reference_rs_id;
     /*^M, 0, H, 0, 3^*/

    /*Index in the p0 pucch */
    UInt8     p0_pucch_id;
     /*^M, 0, H, 1, MAX_NUM_P0_PUCCH_SETS^*/

    /*Closed Loop index for PUCCH power transmission. Only 0 is supported in current release. 
      1 is applicable if twoPUCCH-PC-AdjustmentStates is enabled.*/
     UInt8     closed_loop_index;
      /*^M, 0, B, 0, 1^*/    

}pucch_spatialrelation_info_t;

typedef struct _pucch_spatialrelation_to_add_mod_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/
   
    /* Specifies the count of Spatial Relation Info RS to add for PUCCH.*/
    UInt8   count;
    /*^ M, 0, B, 1, 8 ^*/

    /*Refer �spatialRelationInfoToAddModList� in PUCCH-Config (3GPP TS 38.331)*/
    pucch_spatialrelation_info_t pucch_spatialrelastion_info_to_add_mod_list[MAX_SPATIAL_RELATIONINFO];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pucch_spatialrelation_to_add_mod_info_t;

typedef struct _pucch_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define RESOURCE_SET_ADD_LIST_PRESENT 0x0001
#define RESOURCE_ADD_LIST_PRESENT 0x0002
#define PUCCH_FORMAT_2_CONFIG_PRESENT 0x0004
#define DL_DATA_TO_UL_ACK_LIST_PRESENT  0x0008
#define SR_RES_TO_ADD_MOD_PRESENT 0x0010
#define PUCCH_POWER_CONTROL_CONFIG_PRESENT 0x0020
#define PUCCH_SPATIAL_RELATIONINFO_PRESENT 0x0040

  /* Count of the elements in  dl_data_to_ul_ack list */
  UInt8 dl_data_to_ul_ack_list_count;
  /*^ M, 0, B, 1, 8 ^*/ 

  /* List of timing for given PDSCH to the UL ACK. Only the values [0..8] are applicable. */
  dl_data_to_ul_ack_list_t  dl_data_to_ul_ack_list[MAX_UL_ACK_INDEX];
  /*^ O, DL_DATA_TO_UL_ACK_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* List count of resource_set_to_add_mod_list Only 2 resource sets would be supported initially, 
   * 1st for PUCCH Format 0 and 2nd for PUCCH Format 2. */
  UInt8 resource_set_to_add_mod_count;
  /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCE_SETS ^*/ 

  /* Refer PUCCH-Config in BWP-UplinkDedicated (3GPP TS 38.331). 
     Lists for adding PUCCH resource sets (see TS 38.213, section 9.2). */
  pucch_resource_set_config_t resource_set_to_add_mod_list [MAX_NUM_PUCCH_RESOURCE_SETS];
  /*^ O, RESOURCE_SET_ADD_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* List count of resource_t o_add_mod_list */
  UInt8 resource_to_add_mod_count;
  /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCES ^*/ 

  /* Refer PUCCH-Config in BWP-UplinkDedicated (3GPP TS 38.331).
     Lists for adding PUCCH resources applicable for the UL BWP and serving cell in which the PUCCH-Config is defined. 
     The resources defined herein are referred to from other parts of the configuration to determine which resource 
     the UE shall use for which report. */
  pucch_resource_config_t resource_to_add_mod_list [MAX_NUM_PUCCH_RESOURCES];
  /*^ O, RESOURCE_ADD_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* Refer PUCCH-Config in BWP-UplinkDedicated (3GPP TS 38.331).
     Parameters that are common for all PUCCH resources of format 2. */
  ue_pucch_format_config_t pucch_format_2_config;
  /*^ O, PUCCH_FORMAT_2_CONFIG_PRESENT, N, 0, 0 ^*/ 

  /* List count of sr_resource_t o_add_mod_list */
  UInt8	sr_resource_to_add_mod_count;
  /*^ M, 0, B, 1, MAX_SR_RESOURCES ^*/

  /* List for adding physical layer resources on PUCCH where the UE may send the dedicated scheduling request (D-SR) (see 38.213, section 9.2.2). */
  /* Refer .PUCCH-Config. in BWP-UplinkDedicated (3GPP TS 38.331). */
  sr_resource_config_t  sr_resource_to_add_mod_list[MAX_NUM_SR_RESOURCES]; 
  /*^ O, SR_RES_TO_ADD_MOD_PRESENT, OCTET_STRING, VARIABLE ^*/ 

  /* UE specific power control parameter for PUCCH. Refer "
   * PUCCH-PowerControl" in PUCCH-Config( 3GPP TS 38.331)*/
  pucch_power_control_config_t pucch_power_control;
  /*^ O, PUCCH_POWER_CONTROL_CONFIG_PRESENT, N, 0, 0 ^*/ 

  /*PUCCH Spatial Relation Info parameters */
   pucch_spatialrelation_to_add_mod_info_t pucch_spatialrelation_info_to_add;
  /*^ O, PUCCH_SPATIAL_RELATIONINFO_PRESENT, N, 0, 0^*/

}pucch_config_info_t;

typedef struct _ue_pucch_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PUCCH_CONFIG_INFO_PRESENT 0x0001

  /* Refer PUCCH-Config in BWP-UplinkDedicated (3GPP TS 38.331). This field is configured if SETUP_PRESENT is set in bitmask */
  pucch_config_info_t pucch_config_info;
  /*^ O, PUCCH_CONFIG_INFO_PRESENT, N, 0, 0 ^*/ 

}ue_pucch_config_t;

typedef struct _tci_state_pdcch_to_add_mod_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/

    /* Specifies the count of TCI states to add for PDCCH.*/
    UInt8   count;
    /*^ M, 0, B, 1, 64 ^*/

    /* Refer tci-StatesPDCCH-ToAddList in ControlResourceSet (3GPP TS 38.331)*/
    UInt8   tci_state_id_to_add_mod_list[MAX_TCI_STATE_PDCCH];
     /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}tci_state_pdcch_to_add_mod_info_t;

typedef struct _tci_state_pdcch_to_release_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/

    /* Specifies the count of TCI states to release for PDCCH.*/
    UInt8   count;
    /*^ M, 0, B, 1, 64 ^*/

   /*Refer tci-StatesPDCCH-ToReleaseList in ControlResourceSet (3GPP TS 38.331)*/
   UInt8   tci_state_id_to_release_list[MAX_TCI_STATE_PDCCH];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}tci_state_pdcch_to_release_info_t;


typedef struct _coreset_to_add_mod_list_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/
#define TCI_STATE_ADD_MOD_LIST_PRESENT 0x0001
#define TCI_STATE_RELEASE_LIST_PRESENT 0x0002
  nr_coreset_id_t coreset_to_add_mod;
  /*^ M, 0, B, 1, 11 ^*/

  /*A subset of the TCI states defined in pdsch-Config. They are used for providing QCL relationships between 
   the DL RS(s) in one RS Set (TCI-State) and the PDCCH DMRS ports (Refer 3GPP TS 38.213,  ection 6.).*/
  tci_state_pdcch_to_add_mod_info_t tci_state_pdcch_to_add_mod_list;
  /*^ O, TCI_STATE_ADD_MOD_LIST_PRESENT, N, 0, 0^*/
 
  /*TCI state is release during reconfiguration. This parameter is present in Reconfiguration only if required.*/
  tci_state_pdcch_to_release_info_t tci_state_pdcch_to_release_list;
   /*^ O, TCI_STATE_RELEASE_LIST_PRESENT, N, 0, 0^*/
}coreset_to_add_mod_list_t;

typedef struct _searchspace_to_add_mod_t
{
  bitmask_t bitmask;
  /*^ BITMASK ^*//* To inform optional parameter presence */

  nr_search_space_id_t search_space_to_add_mod;
  /*^ M, 0, B, 1, 39 ^*/

}searchspace_to_add_mod_t;

typedef struct _pdcch_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CORESET_TO_ADD_PRESENT 0x0001
#define SEARCH_SPACE_TO_ADD_PRESENT 0x0002

  /* Count of coreset to add */
  UInt8 coreset_count;
  /*^ M, 0, H, 0, MAX_CORESET_BWP_COUNT ^*/

  /* List of CORESET Ids configured for the UE. The Configuration related to the Coreset ID is send during cell-config. 
     DuMgr needs to select the coreset Ids for the UE so that the coresets are evenly distributed across UEs. */
  coreset_to_add_mod_list_t coreset_to_add_mod_list[MAX_CORESET_BWP_COUNT];
  /*^ O, CORESET_TO_ADD_PRESENT, OCTET_STRING, VARIABLE ^*/

  UInt8 search_space_count;
  /*^ M, 0, H, 0, MAX_SEARCH_SPACE_BWP_COUNT ^*/ /* Count of search space to add */ 

  /* List of Search Spaces Ids configured for the UE. 
     The Configuration related to the Search Space is send during cell-config. 
     DuMgr needs to select the Search Space Ids for the UE so that they are evenly distributed across UEs.  */
  searchspace_to_add_mod_t searchspace_to_add_mod_list[MAX_SEARCH_SPACE_BWP_COUNT];
  /*^ O, SEARCH_SPACE_TO_ADD_PRESENT, OCTET_STRING, VARIABLE ^*/

}pdcch_config_info_t;

typedef struct _ue_pdcch_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PDCCH_CONFIG_INFO_PRESENT 0x0001

  /* Refer .PDCCH-Config. in BWP-DownlinkDedicated (3GPP TS 38.331). */
  pdcch_config_info_t pdcch_config_info;
  /*^ O, PDCCH_CONFIG_INFO_PRESENT, N, 0, 0 ^*/
}ue_pdcch_config_t;

typedef struct _ul_bwp_dedicated_t 
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PUCCH_CONFIG_PRESENT  0x0001
#define PUSCH_CONFIG_PRESENT  0x0002
#define UL_PDCCH_CONFIG_PRESENT 0x0004
#define BFR_CFRA_PRESENT 0x0008

  /* The IE PUCCH-Config is used to configure UE specific PUCCH parameters (per BWP) */
  ue_pucch_config_t  pucch_config;
  /*^ O, PUCCH_CONFIG_PRESENT, N, 0, 0 ^*/ 

  /*  IE PUSCH-Config is used to configure UE specific PUSCH parameters (per BWP) */
  ue_pusch_config_t  pusch_config;
  /*^ O, PUSCH_CONFIG_PRESENT, N, 0, 0 ^*/ 
  /*Contains Search Space and Coreset for Uplink DCI */
  ue_pdcch_config_t  pdcch_config;
  /*^ O, UL_PDCCH_CONFIG_PRESENT, N, 0, 0 ^*/

  /*Dedicated CFRA resources for BFR. The same preamble index will be used for all SSB*/
  UInt8         ue_bfr_cfra_preamble;
   /*^ O, BFR_CFRA_PRESENT, H, 0, 63 ^*/

}ul_bwp_dedicated_t;

typedef struct _bwp_uplink_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define UL_BWP_DEDICATED_PRESENT  0x0001

  /* An identifier for this bandwidth part. */
  UInt8 bwp_id;
  /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/ 

  /*Dedicated parameters for an UL BWP. */
  ul_bwp_dedicated_t  ul_bwp_dedicated;
  /*^ O, UL_BWP_DEDICATED_PRESENT, N, 0, 0 ^*/ 

}bwp_uplink_t;

/*varun pusch serving cell config.-----------------*/
typedef struct _pusch_ser_cell_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  UInt8 maxmimo_layers;
  /*^ M, 0 , B, 1, 4 ^*/ 

  /* The number of HARQ processes to be used on the PUSCH of a serving cell. n2 corresponds to 2 HARQ processes, 
   * n4 to 4 HARQ processes and so on. If the field is absent, the UE uses 8 HARQ processes. */
  /* In the current release 16 HARQ process shall be configured. */
  UInt32  num_harq_process_for_pusch;
  /*^ M, 0, H, 0, 16 ^*/ 

  /*Accounts for overhead from CSI-RS, CORESET, etc */
  UInt8 x_over_head;
  /*^ M, 0, H, 0, 18 ^*/ /*pdsch_x_over_head_et*/
  /* Indicates the maximum number of layers  for one TB to be used for PDSCH in
   * all BWPs of this serving cell. (refer 3GPP TS 38.212 Section 5.4.2.1)*/

}pusch_ser_cell_config_t;
/*------------------------------------------------*/

typedef struct _ul_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define UL_BWP_TO_ADD_PRESENT 0x0001

  /* Refer initialUplinkBWP in UplinkConfig (3GPP TS 38.331). */
  /*The dedicated (UE-specific) configuration for the initial Uplink bandwidth-part. */
  ul_bwp_dedicated_t  initial_ul_BWP_info;
  /*^ M, 0, N, 0, 0 ^*/ 

  /* Refer mac-CellGroupConfig in CellGroupConfig (3GPP TS 38.331) */
  ul_mac_cell_group_config_t ul_mac_cell_group_config;
  /*^ M, 0, N, 0, 0 ^*/

  /* Timing Advance Group ID. In current release  only one TAG shall be configured with TAG-ID 0 */
  UInt8 tag_id;
  /*^ M, 0, H, 0, 3 ^*/ 

  /* Count for additional UL BWPs configured by higher layers. */
  /* Not Configured in the current release. */
  UInt8 bwp_uplink_count;
  /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/ 

  /* List of additional uplink bandwidth parts to be added or modified. */
  /* Currently only initial BWP is supported No, additional BWP would be configured. */
  bwp_uplink_t  bwp_uplink[MAX_BWP_COUNT];
  /*^ O, UL_BWP_TO_ADD_PRESENT, OCTET_STRING, VARIABLE ^*/ 

  /*ID of the UL BWP to be activated upon performing the RRC (re-)configuration */
  UInt8 first_active_ul_bwp_id;
  /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

  /*Pusch related Paramter*/
  pusch_ser_cell_config_t pusch_serving_cell_config;
  /*^ M, 0, N, 0, 0 ^*/

}ul_config_info_t;

typedef struct _pdsch_ser_cell_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define NUM_HARQ_PROCESS_FOR_PDSCH_PRESENT  0x0001
#define X_OVER_HEAD_PRESENT 0x0002

  /* The number of HARQ processes to be used on the PDSCH of a serving cell. n2 corresponds to 2 HARQ processes, 
   * n4 to 4 HARQ processes and so on. If the field is absent, the UE uses 8 HARQ processes. */
  /* In the current release 16 HARQ process shall be configured. */
  UInt32  num_harq_process_for_pdsch;
  /*^ O, NUM_HARQ_PROCESS_FOR_PDSCH_PRESENT, H, 0, 16 ^*/ 

  /*Accounts for overhead from CSI-RS, CORESET, etc */
  UInt8 x_over_head;
  /*^ O, X_OVER_HEAD_PRESENT, H, 0, 18 ^*/ /*pdsch_x_over_head_et*/
  /* Indicates the maximum number of layers  for one TB to be used for PDSCH in
   * all BWPs of this serving cell. (refer 3GPP TS 38.212 Section 5.4.2.1)*/
  UInt8 maxmimo_layers;
  /*^ M, 0 , B, 1, 8 ^*/ 

}pdsch_ser_cell_config_t;

typedef struct _rate_match_pattern_group_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CELL_LEVEL_RATE_MATCH_PATTERN_PRESENT 0x0001
#define BWP_LEVEL_RATE_MATCH_PATTERN_PRESENT 0x0002

  /* Rate Match Pattern ID defined by 
     Serving_cell_config_common -> rate_match_pattern_to_add_mod_list */
  UInt8 cell_level;
  /*^ O, CELL_LEVEL_RATE_MATCH_PATTERN_PRESENT, H, 0, MAX_RATE_MATCH_PATTERNS ^*/ 

  /* Rate Match Pattern ID defined by
     PDSCH-Config -> rate_match_pattern_to_add_mod_list */
  UInt8 bwp_level;
  /*^ O, BWP_LEVEL_RATE_MATCH_PATTERN_PRESENT, H, 0, MAX_RATE_MATCH_PATTERNS ^*/ 

}rate_match_pattern_group_t;

typedef struct _dl_ptrs_config_t
{
    /* To inform optional parameter pressent */
    bitmask_t bitmask;
    /*^ BITMASK ^*/
#define DL_PTRS_FREQ_DENSITY_PRESENT 0x0001
#define DL_PTRS_TIME_DENSITY_PRESENT 0x0002

    UInt8 re_offset;
    /*^ M, 0, B, 0, 3 ^*/

    UInt8 epre_ratio;
    /*^ M, 0, B, 0, 3 ^*/

    /*PRB Count, values in ascending order, range values should be within configured cell BW */
    UInt16 freq_density[MAX_PTRS_CONFIG_FREQ_DENSITY];
    /*^ O, DL_PTRS_FREQ_DENSITY_PRESENT, OCTET_STRING, FIXED ^*/
	
    /*UE configuration with DL MCS Table per 5.1.3.1-1 (64QAM) or Table 5.1.3.1-2 (256 QAM) or Table 5.1.3.1-2 (64 LOWSE QAM) of 38.214 */
    UInt8 time_density[MAX_PTRS_CONFIG_TIME_DENSITY];
    /*^ O, DL_PTRS_TIME_DENSITY_PRESENT, OCTET_STRING, FIXED ^*/
}dl_ptrs_config_t;

typedef struct _dmrs_downlink_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DMRS_TYPE_PRESENT 0x0001
#define DMRS_ADDITIONAL_POSITION_PRESENT 0x0002 
#define MAX_LENGTH_PRESENT 0x0004
#define SCRAMBLING_ID_0_PRESENT 0x0008
#define SCRAMBLING_ID_1_PRESENT 0x0010
#define DL_PTRS_PRESENT 0x0020
  /* Selection of the DMRS type to be used for DL (see 38.211, section 7.4.1.1.1). If the field is absent, the UE uses DMRS type 1. */
  UInt8 dmrs_type;
  /*^ O, DMRS_TYPE_PRESENT, H, 0, 0 ^*/ 

  /* Position for additional DM-RS in DL, see Table 7.4.1.1.2-4 in 38.211. If the field is absent, the UE applies the value pos2.  */
  /* Currently value 0 shall be used. */
  UInt8 dmrs_additional_position; 
  /*^ O, DMRS_ADDITIONAL_POSITION_PRESENT, H, 0, 2 ^*/ 

  /* The maximum number of OFDM symbols for DL front loaded DMRS. If the field is absent, 
   * the UE applies value len1. (see 38.214, section 5.1) */
  /* Not configured in the current release. */
  UInt8 max_length;
  /*^ O, MAX_LENGTH_PRESENT, H, 0, 0 ^*/ 

  /*DL DMRS scrambling initialization Corresponds to L1 parameter 'n_SCID 0' */
  UInt16 scrambling_id_0;
  /*^ O, SCRAMBLING_ID_0_PRESENT, H, 0, 65535 ^*/

   /*DL DMRS scrambling initialization Corresponds to L1 parameter 'n_SCID 1' */
   UInt16 scrambling_id_1;
   /*^ O, SCRAMBLING_ID_1_PRESENT, H, 0, 65535 ^*/

   /* PTRS Configuration */
   dl_ptrs_config_t ptrs_config;
  /*^ O, DL_PTRS_PRESENT, N, 0, 0 ^*/

}dmrs_downlink_config_t;

typedef struct _tci_state_pdsch_to_add_mod_info_t
{
    /* To inform optional parameter presence */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/
 
    /*Specifies the count of TCI states to add for PDSCH.*/
    UInt8       count;
     /*^ M, 0, B, 1, 127 ^*/
 
    /* Refer tci-StatesToAddModList in PDSCH-Config (3GPP TS 38.331)*/
    UInt8        tci_state_id_to_add_mod_list[MAX_TCI_STATE_PDSCH];
     /*^ M, 0, OCTET_STRING, VARIABLE^*/
}tci_state_pdsch_to_add_mod_info_t;

typedef struct _pdsch_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DMRS_MAPPING_TYPEA_PRESENT 0x0001 
#define DMRS_MAPPING_TYPEB_PRESENT 0x0002
#define PDSCH_TIME_DOMAIN_RESOURCE_PRESENT 0x0004
#define MAX_CODEWORDS_SCHDULED_DCI_PRESENT 0x0008
#define RATE_MATCH_PATTERN_TO_ADD_LIST_PRESENT 0x0010
#define RATE_MATCH_PATTERN_GROUP1_PRESENT 0x0020
#define RATE_MATCH_PATTERN_GROUP2_PRESENT 0x0040
#define PDSCH_DATA_SCRAMBLING_ID_PRESENT 0x0080
#define VRB_TO_PRB_INTERLEAVER_PRESENT 0x0100
#define AGGREGATION_FACTOR_PRESENT 0x0200
#define TCI_STATE_PDSCH_PRESENT  0x0400

  /* Configuration of resource allocation type. Currently resource allocation type 1 is supported */
  UInt8 resource_allocation;    
  /*^ M, 0, H, 0, 2 ^*/

  /* 0:config1, 1:config2 This is applicapble only for resourceAllocationType0 and ignored otherwise */ 
  UInt8 rbg_size;
  /*^ M, 0, H, 0, 1 ^*/

  /*Refer mcs-table in PDSCH-Config (3GPP TS 38.331). NR_TRUE means 256qam table will be used.). 
    If the field is absent the UE applies the value 64QAM.
    In the current release 64QAM shall be used. */
  UInt8 mcs_table;  
  /*^ M, 0, H, 0, 2 ^*/

  /* DMRS configuration for PDSCH transmissions using PDSCH mapping type A
     In the current release mapping TypeA shall be used. */
  dmrs_downlink_config_t  dmrs_downlink_pdsch_mappingTypeA;
  /*^ O, DMRS_MAPPING_TYPEA_PRESENT, N, 0, 0 ^*/

  /* DMRS configuration for PDSCH transmissions using PDSCH mapping type B. */
  /* Not configured in current release. */
  dmrs_downlink_config_t  dmrs_downlink_pdsch_mappingTypeB;   
  /*^ O, DMRS_MAPPING_TYPEB_PRESENT, N, 0, 0 ^*/

  /* Maximum number of code words that a single DCI may schedule.(3GPP TS 38.331). In the current release n1 shall be used. */
  UInt8 max_no_of_codeWords_scheduledby_DCI;
  /*^ O, MAX_CODEWORDS_SCHDULED_DCI_PRESENT, H, 0, 1 ^*/

  /* Count of additional rate match pattern */
  UInt8 rate_match_pattern_count;
  /*^ M, 0, H, 0, MAX_RATE_MATCH_PATTERNS ^*/

  /* Resources patterns which the UE should rate match PDSCH around(3GPP TS 38.331) 
     In current release rate match pattern received in cell_config shall be supported. */
  rate_match_pattern_config_t rate_match_pattern_to_add_mod_list[MAX_RATE_MATCH_PATTERNS];
  /*^ O, RATE_MATCH_PATTERN_TO_ADD_LIST_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* Count of group 1 rate match pattern */
  UInt8 rate_match_pattern_group1_count;
  /*^ M, 0, H, 0, MAX_RATE_MATCH_PATTERNS ^*/

  /* The IDs of a first group of RateMatchPatterns(3GPP TS 38.331) */
  /* Not used in the current release. */
  rate_match_pattern_group_t  rate_match_pattern_group1[MAX_RATE_MATCH_PATTERNS_PER_GROUP];
  /*^ O, RATE_MATCH_PATTERN_GROUP1_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* Count of group 2 rate match pattern */
  UInt8 rate_match_pattern_group2_count;
  /*^ M, 0, H, 0, MAX_RATE_MATCH_PATTERNS ^*/

  /* The IDs of a second group of RateMatchPatterns (3GPP TS 38.331) */
  /* Not used in the current release. */
  rate_match_pattern_group_t  rate_match_pattern_group2[MAX_RATE_MATCH_PATTERNS_PER_GROUP];
  /*^ O, RATE_MATCH_PATTERN_GROUP2_PRESENT, OCTET_STRING, VARIABLE ^*/

  /* Identifier used to initialize data scrambling (c_init) for PDSCH. */
  UInt16 data_scrambling_id;
  /*^ O,  PDSCH_DATA_SCRAMBLING_ID_PRESENT, H, 0, 1023 ^*/

  /* Interleaving unit configurable between 2 and 4 PRBs Corresponds 
   * to L1 parameter 'VRB-to-PRB-interleaver */
  UInt8 vrb_to_prb_interleaver;
  /*^ O, VRB_TO_PRB_INTERLEAVER_PRESENT, B, 2, 4 ^*/

  /* Number of repetitions for data. Corresponds to L1 parameter 
   * 'aggregation-factor-DL'. */
  UInt8 aggregation_factor;
   /*^ O, AGGREGATION_FACTOR_PRESENT, B, 2, 8^*/

  /*A list of Transmission Configuration Indicator (TCI) states indicating a transmission 
    configuration which includes QCL-relationships between the DL RSs in 
    one RS set and the PDSCH DMRS ports (Refer 3GPP TS 38.214, section 5.1.4)*/
   tci_state_pdsch_to_add_mod_info_t tci_state_to_add_mod_list;
  /*^ O, TCI_STATE_PDSCH_PRESENT, N, 0, 0^*/

}pdsch_config_info_t;


typedef struct _ue_pdsch_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define PDSCH_CONFIG_PRESENT 0x0001

  /* Refer PDSCH-Config in BWP-DownlinkDedicated (3GPP TS 38.331). */
  pdsch_config_info_t pdsch_config_info;
  /*^ O, PDSCH_CONFIG_PRESENT, N, 0, 0 ^*/
}ue_pdsch_config_t;


typedef struct _bwp_dl_dedicated_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DED_PDCCH_CONFIG_PRESENT 0x0001 
#define DED_PDSCH_CONFIG_PRESENT 0x0002 

  /*Refer PDCCH-Config in BWP-DownlinkDedicated (3GPP TS 38.331). */
  ue_pdcch_config_t  pdcch_config;
  /*^ O, DED_PDCCH_CONFIG_PRESENT, N, 0, 0 ^*/

  /* Refer PDSCH-Config in BWP-DownlinkDedicated (3GPP TS 38.331). */
  ue_pdsch_config_t  pdsch_config; 
  /*^ O, DED_PDSCH_CONFIG_PRESENT, N, 0, 0 ^*/
}bwp_dl_dedicated_info_t;


typedef struct _bwp_downlink_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DL_BWP_DEDICATED_PRESENT 0x0001

  /* An identifier for this bandwidth part */
  UInt8 bwp_id;
  /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

  bwp_dl_dedicated_info_t dl_bwp_dedicated;
  /*^ O, DL_BWP_DEDICATED_PRESENT, N, 0, 0 ^*/
}bwp_downlink_t;


typedef struct _dl_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define DL_BWP_TO_ADD_PRESENT   0x0001
#define PDSCH_SERVING_CELL_CONFIG_PRESENT 0x0002

  /* Refer initialDownlinkBWP in DownlinkConfig (3GPP TS 38.331) */
  bwp_dl_dedicated_info_t initial_dl_BWP_info;
  /*^ M, 0, N, 0, 0 ^*/

  /* Count for additional DL BWPs configured by higher layers. */
  UInt8 bwp_downlink_count;
  /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

  /* List of additional downlink bandwidth parts to be added or modified.
     In the current release only initial DL BWP is supported. */
  bwp_downlink_t bwp_downlink[MAX_BWP_COUNT]; 
  /*^ O, DL_BWP_TO_ADD_PRESENT, OCTET_STRING, VARIABLE ^*/

  /*ID of the DL BWP to be activated upon performing the RRC (re-)configuration */
   UInt8 first_active_dl_bwp_id;
   /*^ M, 0, H, 0, MAX_BWP_COUNT ^*/

  /* PDSCH releated parameters that are not BWP-specific. */
  pdsch_ser_cell_config_t pdsch_serving_cell_config;  
  /*^ O, PDSCH_SERVING_CELL_CONFIG_PRESENT, N, 0, 0 ^*/
}dl_config_info_t;

typedef struct _pucch_csi_resource_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* BWP Id */
  UInt8 bwp_id; 
  /*^ M, 0, N, 0, 0 ^*/

  /* PUCCH resource Id configured  by higher layers. */
  UInt8 pucch_resource_id; 
  /*^ M, 0, H, 0, 127 ^*/

}pucch_csi_resource_t;

typedef struct _codebook_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Codebook Type configured by higher layers */
  UInt8 codebook_type; 
  /*^ M, 0, H, 0, 3 ^*/ /* codebook_config_type_et */

  /* Number of Antenna port configured by higher layers */
  UInt8 num_port; 
  /*^ M, 0, H, 0, 14 ^*/ /* codebook_config_num_port_et */

  /* RI-restriction configured by higher layers */
  UInt8 ri_restriction; 
  /*^ M, 0, N, 0, 0 ^*/

}codebook_config_t;

typedef struct _csi_report_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CQI_FORMAT_INDICATOR_PRESENT 0x0001
#define PMI_FORMAT_INDICATOR_PRESENT 0x0002
#define CQI_TBL_CONFIG_PRESENT 0x0004
#define CODEBOOK_CONFIG_PRESENT 0x0008

  /* CSI report config Id configured  by higher layers. */
  UInt8 csi_report_config_id; 
  /*^ M, 0, H, 0, 47 ^*/

  /* CSI resource config Id to be measured. */
  UInt8 csi_resource_config_id; 
  /*^ M, 0, H, 0, 111 ^*/

  /* CSI report type configured  by higher layers. */
  UInt8 report_type; 
  /*^ M, 0, H, 0, 3 ^*/ /* csi_report_type_et */

  /* CSI report periodicity configured  by higher layers. */
  UInt8 periodicity;
  /*^ M, 0, H, 0, 9 ^*/

  /* CSI report Offset configured  by higher layers. */
  UInt16 offset;
  /*^ M, 0, H, 0, 319 ^*/

  /* BWP count */
  UInt8 bwp_count; 
  /*^ M, 0, H, 0, 1 ^*/

  /* PUCCH CSI resource configured  by higher layers. */
  pucch_csi_resource_t pucch_csi_resource[MAX_BWP_COUNT];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

  /* CSI report quantity configured  by higher layers. */
  UInt8 report_quantity;
  /*^ M, 0, H, 0, 4 ^*/

  /* CQI format configured  by higher layers. */
  UInt8 cqi_format_indicator;
  /*^ O, CQI_FORMAT_INDICATOR_PRESENT, H, 0, 1 ^*/

  /* PMI format configured  by higher layers. */
  UInt8 pmi_format_indicator;
  /*^ O, PMI_FORMAT_INDICATOR_PRESENT, H, 0, 1 ^*/

  /* CQI table configured  by higher layers. */
  UInt8 cqi_table;
  /*^ O, CQI_TBL_CONFIG_PRESENT, H, 0, 2 ^*/

  /* Codebook configuration for subset restriction configured  by higher layers. */
  codebook_config_t codebookConfig;
  /*^ M, 0, N, 0, 0 ^*/

}csi_report_config_t;

typedef struct _csi_report_config_to_add_mod_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Count for CSI report config configured  by higher layers. */
  UInt8 csi_report_config_to_add_mod_count;
  /*^ M, 0, B, 1, 48 ^*/

  /* Refer CSI-ReportConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_report_config_t csi_report_config[MAX_NUM_CSI_REPORT_CONFIG];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}csi_report_config_to_add_mod_info_t;

typedef struct _serving_cell_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CSI_REPORT_CONFIG_PRESENT   0x0001
#define UL_CONFIG_PRESENT           0x0002

  /* Refer DownlinkConfig in ServingCellConfig (3GPP TS 38.331) */
  dl_config_info_t dl_config_info;
  /*^ M, 0, N, 0, 0 ^*/

  /* Refer UplinkConfig in ServingCellConfig (3GPP TS 38.331)
   * UL_CONFIG_PRESENT is always set for PScell but optional for Scell
   */
  ul_config_info_t ul_config_info;
  /*^ M, 0, N, 0, 0 ^*/

  /* Refer CSI-ReportConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_report_config_to_add_mod_info_t csi_report_config_to_add_mod_info;
  /*^ O, CSI_REPORT_CONFIG_PRESENT, N, 0, 0 ^*/

}serving_cell_config_info_t;


typedef struct _spcell_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Refer ServCellIndex in SpCellConfig (3GPP TS 38.331).Value 0 shall be configured in current release. */
  UInt8   serv_cell_index;
  /*^ M, 0, H, 0, 31 ^*/

  /* Refer ServingCellConfig in SpCellConfig (3GPP TS 38.331) */
  serving_cell_config_info_t  serving_cell_config_info; 
  /*^ M, 0, N, 0, 0 ^*/
}spcell_config_info_t;

typedef struct _phy_cell_group_cfg_t
{
    /*limit the UE's uplink transmission power on a carrier frequency 
     * Reference 3GPP TS 38.331 Section 6.3.2 P-Max */
    SInt8    p_nr;
    /*^ M, 0, B, -30, 33 ^*/

    /*The PDSCH HARQ-ACK codebook is either semi-static or dynamic. 
     * This is applicable to both CA and none CA operation. ^*/
    UInt8   pdsch_harq_ack_codebook;
    /*^ M, 0, H, 0, 1 ^*/
}phy_cell_group_cfg_t;

typedef struct _bsr_config_info_t
{
    /* To inform optional parameter presence */
    bitmask_t bitmask;
    /*^ BITMASK ^*/

    /*periodic bsr timer*/
    UInt8 periodic_bsr_timer;
    /*^ M, 0, H,0,periodic_bsr_infinity ^*/ 
    
    UInt8 retx_bsr_timer;
    /*^ M, 0, H,0,10 ^*/ 
}bsr_config_info_t;

typedef struct _mac_config_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;  
  /*^ BITMASK ^*/
#define BSR_CONFIG_INFO_PRESENT 0x0001

  /* Refer bsr-Config in MAC-CellGroupConfig (3GPP TS 38.331) */
  bsr_config_info_t bsr_config_info;
  /*^ O, BSR_CONFIG_INFO_PRESENT, N, 0, 0 ^*/
}mac_config_info_t;    

typedef struct _ue_capability_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;  
  /*^ BITMASK ^*/

  UInt8 ue_power_class;
  /*^ M, 0, H, 0, 3 ^*/ 
  UInt8 power_boosting_pi2BPSK;
  /*^ M, 0, H, 0, 1 ^*/ 

  UInt8 dynamic_power_sharing;
  /*^ M, 0, H, 0, 1 ^*/ 

  /* Refer 38306:F30 */
  UInt8 mux_sr_harq_csi_pucch;
  /*^ M, 0, H, 0, 1 ^*/ 

}ue_capability_info_t;

typedef struct _ue_ambr_qos_info_t
{
   UInt64 ul_ambr;
   /*^ M, 0, N, 0, 0 ^*/
}ue_ambr_qos_info_t;

typedef struct _scell_config_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;  
  /*^ BITMASK ^*/
  
  UInt8 cell_index;
  /*^ M, 0, H, 0, 3 ^*/ 

  UInt8 scell_index;
  /*^ M, 0, H, 0, 31 ^*/ 

  serving_cell_config_info_t scell_config_dedicated_info;
  /*^ M, 0, N, 0, 0 ^*/ 

}scell_config_t;

typedef struct _scell_configuration_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;  
  /*^ BITMASK ^*/

  UInt8          scell_to_add_mod_count;
  /*^ M, 0, B, 1, 3 ^*/ 

  scell_config_t scell_config[MAX_NUM_SCELL_PER_DU];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}scell_configuration_info_t;

typedef struct _add_ue_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;  
  /*^ BITMASK ^*/
#define MAC_CONFIG_INFO_PRESENT             0x0001
#define NR_UE_CAPABILITY_INFO_PRESENT       0x0002
#define MAC_POWER_COORDINATION_FR1_PRESENT  0x0004
#define MAC_UE_AMBR_PRESENT                 0x0008
#define MAC_SCELL_CONFIG_PRESENT            0x0010
  /* rnti is the unique identifier for the UE for which context is to be created */
  UInt16    rnti;       
  /*^ M, 0, B, MIN_VAL_RNTI, MAX_VAL_RNTI ^*/ 

  /* 0- N1  1- N2 */
  UInt16    ue_category;
  /*^ M, 0, H, 0, 1 ^*/

  /* Refer SpCellConfig in CellGroupConfig (3GPP TS 38.331) */
  spcell_config_info_t  spcell_config_info; 
  /*^ M, 0, N, 0, 0 ^*/

  /* Refer PhysicalCellGroupConfig� in CellGroupConfig (3GPP TS 38.331) */
  phy_cell_group_cfg_t phy_cell_group_config;
  /*^ M, 0, N, 0, 0 ^*/

  /* Refer MAC-CellGroupConfig in CellGroupConfig (3GPP TS 38.331) */
  mac_config_info_t mac_config_info;
  /*^ O, MAC_CONFIG_INFO_PRESENT, N, 0, 0 ^*/

  ue_capability_info_t ue_capability_info;
  /*^ O, NR_UE_CAPABILITY_INFO_PRESENT, N, 0, 0 ^*/

  powercoordination_fr1_t powercoordination_fr1;
  /*^ O, MAC_POWER_COORDINATION_FR1_PRESENT, N, 0, 0 ^*/

  ue_ambr_qos_info_t  ue_ambr_qos_info;
  /*^ O, MAC_UE_AMBR_PRESENT, N, 0, 0 ^*/

  scell_configuration_info_t scell_configuration_info;
  /*^ O, MAC_SCELL_CONFIG_PRESENT, N, 0, 0 ^*/

}add_ue_info_t;


typedef struct _rlc_config_delete_req_t
{
	/* user equipment index.  */
	ue_index_t            ueIndex;    
	/*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/ 

	/* Num of LC's */
	UInt8             num_lcs;
	/*^ M, 0, B, 0, MAX_LC_ID ^*/ 

	/*This field indicates the logical channel identifier
	 *corresponding to this RLC entity.*/
	UInt8             lcId[MAX_LC_ID];
	/*^ M, 0, N, 0, 0 ^*/ 

}rlc_config_delete_req_t;


typedef enum 
{
    RLCL_ENTITY_NONE = 0,
    RLCL_ENTITY_UM ,
    RLCL_ENTITY_AM
}rlc_entity_mode_et;


typedef enum 
{
    pdu4     = 4,
    pdu8     = 8,
    pdu16    = 16,
    pdu32    = 32,
    pdu64    = 64,
    pdu128   = 128,
    pdu256   = 256,
    pdu512   = 512,
    pdu1024  = 1024,
    pdu2048  = 2048,
    pdu4096  = 4096,
    pdu6144  = 6144,
    pdu8192  = 8192,
    pdu12288 = 12288,
    pdu16384 = 16384,
    pdu20480 = 20480,
    pdu24576 = 24576,
    pdu28672 = 28672,
    pdu32768 = 32768,
    pdu40960 = 40960,
    pdu49152 = 49152,
    pdu57344 = 57344,
    pdu65536 = 65536,
    pPduInfinity
}rlc_lower_poll_pdu_et;

typedef struct _tx_am_rlc_t
{
    rlc_lower_poll_pdu_et poll_pdu ;
  /*^ M, 0, H, 0, pdu65536 ^*/ 

    UInt32 pollByte ; 
  /*^ M, 0, N, 0, 0 ^*/ 
}tx_am_rlc_t;

typedef struct _rlc_entity_cfg_info_t
{
    /* This field indicates the logical channel identifier
     * corresponding to this RLC entity.*/
    UInt8              lcId;
    /*^ M, 0, H, 0, MAX_LC_ID ^*/ 
    
    /* SN Size */
    UInt32                sn_size;
    /*^ M, 0, N, 0, 0 ^*/

    /* This field indicates the type of entity */
    /***********************************************
    *RLC_ENTITY_UM - for UM entity ,
    *RLC_ENTITY_AM - for AM entity
    *************************************************/
    rlc_entity_mode_et rlc_entity_mode ;
    /*^ M, 0, H, 0, RLCL_ENTITY_AM  ^*/ 

    /* Mode specific variables */
    tx_am_rlc_t          amEntity ;
    /*^ M, 0, N, 0, 0 ^*/ 
    
}rlc_entity_cfg_info_t;

typedef struct _rlc_config_create_req_t
{
    /* user equipment index.  */
    ue_index_t                ueIndex;    
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/ 

    /* Num of LC's */
    UInt8                 num_lcs;
    /*^ M, 0, H, 0, MAX_LC_ID ^*/ 

    /* list of Logical channel Ids of the RLC entity to be established  */
    rlc_entity_cfg_info_t  rlc_entity_cfg_info[MAX_LC_ID];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}rlc_config_create_req_t;

typedef struct _coreset_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of coreset to add */
   UInt8  coreset_add_mod_count;
   /*^ M, 0, B, 1, 3 ^*/

   /* Coreset Id to be added for the UE */
   coreset_to_add_mod_list_t  coreset_to_add_mod_list[MAX_CORESET_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}coreset_to_add_mod_info_t;

typedef struct _searchspace_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of searchspace to add */
   UInt8   searchspace_add_mod_count;
   /*^ M, 0, B, 1, 10 ^*/
  
   /* searchspace Id to be added for the UE */
   searchspace_to_add_mod_t   searchspace_to_add_mod_list[MAX_SEARCH_SPACE_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}searchspace_to_add_mod_info_t;


typedef struct _coreset_to_release_list_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;
  /*^ BITMASK ^*/

  nr_coreset_id_t coreset_to_release;
  /*^ M, 0, B, 1, 11 ^*/

}coreset_to_release_list_t;



typedef struct _coreset_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the coreset_to_release_list */
   UInt8    coreset_release_count;
   /*^ M, 0, B, 1, 3 ^*/

   /* Coreset ID to be released */
   coreset_to_release_list_t   coreset_to_release_list[MAX_CORESET_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}coreset_to_release_info_t;

typedef struct _searchspace_to_release_list_t
{
  bitmask_t bitmask;
  /*^ BITMASK ^*//* To inform optional parameter presence */

  nr_search_space_id_t search_space_to_release;
  /*^ M, 0, B, 1, 39 ^*/

}searchspace_to_release_list_t;

typedef struct _searchspace_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the searchspace_to_release_list */
   UInt8   searchspace_release_count;
   /*^ M, 0, B, 1, 10 ^*/

   /* Search space ID to be released */
   searchspace_to_release_list_t   searchspace_to_release_list[MAX_SEARCH_SPACE_BWP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}searchspace_to_release_info_t; 

typedef struct _ue_pdcch_reconfig_info_t
{
#define DED_PDCCH_CORESET_TO_ADD_MOD_PRESENT 0x0001
#define DED_PDCCH_SEARCH_SPACE_TO_ADD_PRESENT 0x0002
#define DED_PDCCH_CORESET_TO_RELEASE_PRESENT 0x0004
#define DED_PDCCH_SEARCH_SPACE_TO_RELEASE_PRESENT 0x0008
    
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* List of CORESET Ids configured for the UE */
   coreset_to_add_mod_info_t  coreset_to_add_mod_info;
   /*^ O, DED_PDCCH_CORESET_TO_ADD_MOD_PRESENT, N, 0, 0 ^*/

   /* List of Search Spaces Ids configured for the UE */
   searchspace_to_add_mod_info_t  searchspace_to_add_mod_info;
   /*^ O, DED_PDCCH_SEARCH_SPACE_TO_ADD_PRESENT, N, 0, 0 ^*/

   /* List of CORESET Ids to be released for the UE */
   coreset_to_release_info_t   coreset_to_release_info;
   /*^ O, DED_PDCCH_CORESET_TO_RELEASE_PRESENT, N, 0, 0 ^*/

   /* List of SearchSpace Ids to be released for the UE */
   searchspace_to_release_info_t   searchspace_to_release_info;
   /*^ O, DED_PDCCH_SEARCH_SPACE_TO_RELEASE_PRESENT, N, 0, 0 ^*/
}ue_pdcch_reconfig_info_t;

typedef struct _rate_match_pattern_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   UInt8 rate_match_pattern;
   /*^ M, 0, H, 0, 3 ^*/
}rate_match_pattern_to_release_t;

    
typedef struct _mac_rate_match_pattern_to_release_list_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the release list */
   UInt8 rate_match_pattern_release_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* RateMatchpattern  ID to be released */
   rate_match_pattern_to_release_t rate_match_pattern_to_release[MAX_RATE_MATCH_PATTERNS];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}mac_rate_match_pattern_to_release_list_t;

typedef struct _tci_state_pdsch_to_release_info_t
{
    /* To inform optional parameter presence */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /*Specifies the count of TCI states to release for PDSCH.*/
    UInt8       count ;
     /*^ M, 0, B, 1, 127 ^*/

    /*Refer tci-StatesToReleaseList in PDSCH-Config (3GPP TS 38.331)*/
    UInt8      tci_state_id_to_release_list[MAX_TCI_STATE_PDSCH];
     /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}tci_state_pdsch_to_release_info_t;

typedef struct _ue_pdsch_reconfig_info_t
{
#define PDSCH_RECONFIG_DATA_SCRAMBLING_ID_PRESENT 0x0001
#define UE_PDSCH_RECONFIG_DMRS_MAPPING_TYPEA_PRESENT 0x0002
#define UE_PDSCH_RECONFIG_DMRS_MAPPING_TYPEB_PRESENT 0x0004
#define RECONFIG_VRB_TO_PRB_INTERLEAVER_PRESENT 0x0008
#define UE_PDSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT 0x0010
#define MCS_TABLE_PRESENT 0x0020
#define UE_PDSCH_RECONFIG_MAX_CODEWORDS_SCHDULED_DCI_PRESENT 0x0040
#define RECONFIG_AGGREGATION_FACTOR_PRESENT 0x0080
#define RATE_MATCH_PATTERN_TO_ADD_MOD_PRESENT 0x0100
#define RATE_MATCH_PATTERN_TO_RELEASE_PRESENT  0x0200
#define TCI_STATE_PDSCH_TO_ADD_MOD_PRESENT   0x0400
#define TCI_STATE_PDSCH_TO_RELEASE_PRESENT   0x0800

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Identifier used to initialize data scrambling (c_init) for PDSCH */
   UInt16   data_scrambling_id;
   /*^ O, PDSCH_RECONFIG_DATA_SCRAMBLING_ID_PRESENT, H, 0, 1023 ^*/
 
   /* DMRS configuration for PDSCH transmissions using PDSCH mapping type A */
   dmrs_downlink_config_t   dmrs_downlink_pdsch_mappingTypeA;
   /*^ O,  UE_PDSCH_RECONFIG_DMRS_MAPPING_TYPEA_PRESENT, N, 0, 0 ^*/
 
   /* DMRS configuration for PDSCH transmissions using PDSCH mapping type B */
   dmrs_downlink_config_t dmrs_downlink_pdsch_mappingTypeB;
   /*^ O,  UE_PDSCH_RECONFIG_DMRS_MAPPING_TYPEB_PRESENT, N, 0, 0 ^*/

   /* Interleaving unit configurable between 2 and 4 PRBs Corresponds to L1 parameter*/
   UInt8   vrb_to_prb_interleaver;
   /*^ O, RECONFIG_VRB_TO_PRB_INTERLEAVER_PRESENT, H, 0, 1 ^*/

   /* Configuration of resource allocation type. Currently resource allocation type 1 is supported */
   UInt8   resource_allocation;
   /*^ O, UE_PDSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT, H, 0, 2 ^*/

  /* 0:config1, 1:config2 This is applicapble only for resourceAllocationType0 and ignored otherwise */ 
  UInt8 rbg_size;
  /*^ O, UE_PDSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT, H, 0, 1 ^*/

   /* mcs-table in PDSCH-Config */
   UInt8   mcs_table;
   /*^ O, MCS_TABLE_PRESENT, H, 0, 2 ^*/

   /* Maximum number of code words that a single DCI may schedule */
   UInt8  max_no_of_codeWords_scheduledby_DCI;
   /*^ O,  UE_PDSCH_RECONFIG_MAX_CODEWORDS_SCHDULED_DCI_PRESENT, H, 0, 1 ^*/

   /* Number of repetitions for data. Corresponds to L1 parameter 'aggregation-factor-DL' */
   UInt8  aggregation_factor;
   /*^ O, RECONFIG_AGGREGATION_FACTOR_PRESENT, N, 2, 8 ^*/

   /*Resources patterns which the UE should rate match PDSCH around.
   * In current release rate match pattern received in cell_config shall be supported.*/
   pdsch_rate_match_pattern_list_t  rate_match_pattern_to_add_mod_list;
   /*^ O, RATE_MATCH_PATTERN_TO_ADD_MOD_PRESENT, N, 0, 0 ^*/
 
   /* Resource pattern to be release for the UE 
   *  Not supported in current release*/
   mac_rate_match_pattern_to_release_list_t rate_match_pattern_to_release_list;
   /*^ O, RATE_MATCH_PATTERN_TO_RELEASE_PRESENT, N, 0, 0 ^*/
 
   /* A list of Transmission Configuration Indicator (TCI) states indicating a transmission 
     configuration which includes QCL-relationships between the DL RSs in one RS set and the 
     DSCH DMRS ports (Refer 3GPP TS 38.214, section 5.1.4).*/
   tci_state_pdsch_to_add_mod_info_t tci_state_pdsch_to_add_mod_list;
    /*^ O, TCI_STATE_PDSCH_TO_ADD_MOD_PRESENT, N, 0, 0^*/

   /*A list of TCI state to release if required. */
   tci_state_pdsch_to_release_info_t  tci_state_pdsch_to_release_list;
   /*^O, TCI_STATE_PDSCH_TO_RELEASE_PRESENT, N, 0, 0 ^*/

}ue_pdsch_reconfig_info_t;

typedef struct _dl_bwp_dedicated_reconfig_info_t
{
#define DED_PDCCH_RECONFIG_PRESENT 0x0001
#define DED_PDSCH_RECONFIG_PRESENT 0x0002
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   /* PDCCH-Config in BWP-DownlinkDedicated */
   ue_pdcch_reconfig_info_t  pdcch_reconfig;
   /*^ O, DED_PDCCH_RECONFIG_PRESENT, N, 0, 0 ^*/

   /* PDSCH-Config in BWP-DownlinkDedicated */
   ue_pdsch_reconfig_info_t  pdsch_reconfig;
   /*^ O, DED_PDSCH_RECONFIG_PRESENT, N, 0, 0 ^*/
}dl_bwp_dedicated_reconfig_info_t;

typedef struct _dl_bwp_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of Additional downlink BWP to be added or modified */
   UInt8   dl_bwp_add_mod_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* List of additional downlink bandwidth parts to be added or modified */
   bwp_downlink_t   bwp_downlink[MAX_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}dl_bwp_to_add_mod_info_t;

typedef struct  _dl_bwp_to_release_list_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8   dl_bwp_to_release_list;
   /*^ M, 0, B, 1, 4 ^*/
}dl_bwp_to_release_list_t;

typedef struct _dl_bwp_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the dl_bwp_to_release_list */
   UInt8    dl_bwp_release_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* Additional downlink bandwidth part ID to be released */
   dl_bwp_to_release_list_t    dl_bwp_to_release_list[MAX_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}dl_bwp_to_release_info_t;

typedef struct _dl_reconfig_info_t
{
#define INITAIL_DL_BWP_TO_RECONFIG_INFO_PRESENT 0x0001
#define DL_BWP_TO_ADD_MOD_INFO_PRESENT 0x0002
#define DL_BWP_TO_RELEASE_INFO_PRESENT 0x0004
#define DL_BWP_FIRST_ACTIVE_BWPID_PRESENT 0x0008
#define DL_BWP_PDSCH_SER_CELL_RECONFIG_PRESENT 0x0010
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* initialDownlinkBWP in ServingCellConfig */
   dl_bwp_dedicated_reconfig_info_t    initial_dl_bwp_reconfig_info;
   /*^ O, INITAIL_DL_BWP_TO_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/

   /* downlinkBWP-ToAddModList in ServingCellConfig */
   dl_bwp_to_add_mod_info_t      dl_bwp_to_add_mod_info;
   /*^ O, DL_BWP_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/
  
   /* downlinkBWP-ToReleaseList in ServingCellConfig */
   dl_bwp_to_release_info_t      dl_bwp_to_release_info;
   /*^ O, DL_BWP_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/

   /* ID of the DL BWP to be activated upon performing the RRC */
   UInt8     first_active_dl_bwp_id;
   /*^ O, DL_BWP_FIRST_ACTIVE_BWPID_PRESENT, H, 0, MAX_BWP_COUNT ^*/

   /* pdsch-ServingCellConfig” in ServingCellConfig */
   pdsch_ser_cell_config_t  pdsch_serving_cell_reconfig;
   /*^  O, DL_BWP_PDSCH_SER_CELL_RECONFIG_PRESENT, N, 0, 0 ^*/
}dl_reconfig_info_t;

typedef struct _pucch_resource_set_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   /* Specifies the count of pucch resources set to add or modify */
   UInt8  pucch_resource_set_add_mod_count;
   /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCE_SETS ^*/

   /* resourceSetToAddModList in PUCCH-Config */
   pucch_resource_set_config_t   pucch_resource_set_to_add_mod_list[MAX_NUM_PUCCH_RESOURCE_SETS];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pucch_resource_set_to_add_mod_info_t;

typedef struct _pucch_resource_set_to_release_list_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8 pucch_resource_set_to_release;
   /*^ M, 0, H, 0, MAX_NUM_PUCCH_RESOURCE_SETS ^*/
}pucch_resource_set_to_release_list_t;

typedef struct _pucch_resource_set_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of Pucch Resource set to be released */
   UInt8   pucch_resource_set_release_count;
   /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCE_SETS ^*/

   /* The IE PUCCH-ResourceSetId is used to identify a PUCCH Resource set instance in the MAC layer */
   pucch_resource_set_to_release_list_t   pucch_resource_set_to_release_list[MAX_NUM_PUCCH_RESOURCE_SETS];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pucch_resource_set_to_release_info_t; 

typedef struct _pucch_resource_set_reconfig_info_t 
{
#define PUCCH_RESOURCE_SET_TO_ADD_MOD_INFO_PRESENT 0x0001
#define PUCCH_RESOURCE_SET_TO_RELEASE_INFO_PRESENT 0x0002
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* resourceSetToAddModList in PUCCH-Config */
   pucch_resource_set_to_add_mod_info_t pucch_resource_set_to_add_mod_info;
   /*^ O, PUCCH_RESOURCE_SET_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* resourceSetToReleaseList in PUCCH-Config */
   pucch_resource_set_to_release_info_t pucch_resource_set_to_release_info;
   /*^ O, PUCCH_RESOURCE_SET_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/
}pucch_resource_set_reconfig_info_t;

typedef struct _pucch_resource_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of pucch resources to add or modify */
   UInt8   pucch_resource_add_mod_count;
   /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCES ^*/

   /* resourceToAddModList in PUCCH-Config */
   pucch_resource_config_t  pucch_resource_to_add_mod_list[MAX_NUM_PUCCH_RESOURCES];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pucch_resource_to_add_mod_info_t;

typedef struct _pucch_resource_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   UInt8    pucch_resource_to_release;
   /*^ M, 0, H, 0, MAX_NUM_PUCCH_RESOURCES ^*/
}pucch_resource_to_release_t;
typedef struct _pucch_resource_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
  
   /* Specifies the count of Pucch Resource to be released */
   UInt8   pucch_resource_release_count;
   /*^ M, 0, B, 1, MAX_NUM_PUCCH_RESOURCES ^*/

   /* The IE PUCCH-Resource Id is used to identify a PUCCH Resource instance in the MAC layer */
   pucch_resource_to_release_t  pucch_resource_to_release_list[MAX_NUM_PUCCH_RESOURCES];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pucch_resource_to_release_info_t; 

typedef struct _pucch_resource_reconfig_info_t
{
#define PUCCH_RESOURCE_TO_ADD_MOD_INFO_PRESENT 0x0001
#define PUCCH_RESOURCE_TO_RELEASE_INFO_PRESENT 0x0002
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* resourceToAddModList in PUCCH-Config */
   pucch_resource_to_add_mod_info_t  pucch_resource_to_add_mod_info;
   /*^ O, PUCCH_RESOURCE_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* resourceToReleaseList in PUCCH-Config */
   pucch_resource_to_release_info_t  pucch_resource_to_release_info;
   /*^ O, PUCCH_RESOURCE_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/
}pucch_resource_reconfig_info_t;

typedef struct _sr_resource_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of SR resources to add or modify */
   UInt8    sr_resource_add_mod_count;
   /*^ M, 0, B, 1, MAX_SR_RESOURCES ^*/

   /* schedulingRequestResourceToAddModList in PUCCH-Config */
   sr_resource_config_t  sr_resource_to_add_mod_list[MAX_SR_RESOURCES];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}sr_resource_to_add_mod_info_t;

typedef struct _sr_resource_set_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8  sr_resource_set_to_release;
   /*^ M, 0, H, 0, MAX_SR_RESOURCES ^*/
}sr_resource_set_to_release_t;

typedef struct _sr_resource_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of SR Resource to be released */
   UInt8  sr_resource_release_count;
   /*^ M, 0, B, 1, MAX_SR_RESOURCES ^*/

   /* The IE SR Resource Id is used to identify a SR Resource instance in the MAC layer */
   sr_resource_set_to_release_t  sr_resource_set_to_release_list[MAX_SR_RESOURCES];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}sr_resource_to_release_info_t;

typedef struct _sr_resource_reconfig_info_t
{
#define SR_RESOURCE_TO_ADD_MOD_INFO_PRESENT 0x0001
#define SR_RESOURCE_TO_RELEASE_INFO_PRESENT 0x0002

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* schedulingRequestResourceToAddModList in PUCCH-Config */
   sr_resource_to_add_mod_info_t   sr_resource_to_add_mod_info;
   /*^ O, SR_RESOURCE_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* schedulingRequestResourceToReleaseList in PUCCH-Config */
   sr_resource_to_release_info_t   sr_resource_to_release_info;
   /*^ O, SR_RESOURCE_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/
}sr_resource_reconfig_info_t;

typedef struct _pucch_spatialrelation_to_release_info_t
{
     /* To inform optional parameter presence */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/

    /*Specifies the count of TCI states to release for PDSCH.*/
    UInt8       count;
    /*^M, 0, B, 1, 8^*/

    /*Refer spatialRelationInfoToReleaseList in PUCCH-Config (3GPP TS 38.331)*/
    UInt8      pucch_spatialrelastion_info_to_release_list[MAX_SPATIAL_RELATIONINFO];
    /*^M, 0, OCTET_STRING, VARIABLE^*/

}pucch_spatialrelation_to_release_info_t;
typedef struct _pucch_spatial_relation_reconfig_info_t
{
    /* To inform optional parameter presence */
    bitmask_t    bitmask;
    /*^ BITMASK ^*/
#define PUCCH_SPATIAL_RELATION_INFO_TO_ADD_MOD_INFO_PRESENT 0x0001
#define PUCCH_SPATIAL_RELATION_INFO_TO_RELEASE_INFO_PRESENT 0x002

   /*Refer spatialRelationInfoToAddModList in PUCCH-Config (3GPP TS 38.331)
     This IE is present only when new PUCCH Spatial Relation configuration 
     is to be added or existing Configuration is to be modified*/
    pucch_spatialrelation_to_add_mod_info_t pucch_spatialrelation_to_add_mod_info;
    /*^ O, PUCCH_SPATIAL_RELATION_INFO_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

     /*Refer spatialRelationInfoToReleaseList in PUCCH-Config (3GPP TS 38.331)
       This IE is present only when existing Configuration is to be released*/
     pucch_spatialrelation_to_release_info_t pucch_spatialrelation_to_release_info;
     /*^ O, PUCCH_SPATIAL_RELATION_INFO_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/

}pucch_spatial_relation_reconfig_info_t;

typedef struct _ue_pucch_reconfig_info_t
{
#define PUCCH_RESOURCE_SET_RECONFIG_PRESENT 0x0001
#define PUCCH_RESOURCE_RECONFIG_PRESENT 0x0002
#define SR_RESOURCE_RECONFIG_PRESENT 0x0004
#define PUCCH_POWER_RECONFIG_PRESENT 0x0008
#define PUCCH_SPATIAL_RELATIONINFO_RECONFIG_PRESENT 0x0010
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Config adding and releasing PUCCH resource sets. */
   pucch_resource_set_reconfig_info_t  pucch_resource_set_reconfig_info;
   /*^ O, PUCCH_RESOURCE_SET_RECONFIG_PRESENT, N, 0, 0 ^*/

   /* Config adding and releasing PUCCH resource. */
   pucch_resource_reconfig_info_t   pucch_resource_reconfig_info;
   /*^ O, PUCCH_RESOURCE_RECONFIG_PRESENT, N, 0, 0 ^*/

   /* Config adding and releasing SR resource */
   sr_resource_reconfig_info_t   sr_resource_reconfig_info;
   /*^ O, SR_RESOURCE_RECONFIG_PRESENT, N, 0, 0 ^*/
   /* Configuration to reconfigure the PUCCH power control parameters.
    * This IE is applicable only for OLPC*/
   pucch_power_reconfig_info_t pucch_power_reconfig_info;
   /*^ O, PUCCH_POWER_RECONFIG_PRESENT, N, 0, 0 ^*/
 
  /*Config adding and releasing Spatial Relation resources*/
  pucch_spatial_relation_reconfig_info_t pucch_spatial_relation_reconfig_info;
  /*^ O, PUCCH_SPATIAL_RELATIONINFO_RECONFIG_PRESENT, N, 0, 0 ^*/

}ue_pucch_reconfig_info_t;

typedef struct _ue_pusch_reconfig_info_t
{
#define TX_CONFIG_PRESENT 0x0001
#define FREQ_HOPPING_PRESENT 0x0002
#define UE_PUSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT 0x0004
#define PUSCH_AGGREGATION_FACTOR_PRESENT 0x0008
#define PUSCH_MCS_TABLE_PRESENT 0x0010
#define PUSCH_MCS_TABLE_TRANSFORM_PRECODER_PRESENT 0x0020
#define PUSCH_TRANSFORM_PRECODER_ENABLED_PRESENT 0x0040	
#define UE_PUSCH_RECONFIG_UCI_ON_PUSCH_PRESENT 0x0080
#define UE_PUSCH_RECONFIG_CODE_BOOK_SUBSET_PRESENT 0x0100
#define UE_PUSCH_RECONFIG_MAX_RANK_PRESENT 0x0200
#define UE_PUSCH_RECONFIG_DATA_SCRAMBLING_ID_PRESENT 0x0400
#define PUSCH_DMRS_TYPEA_PRESENT 0x0800
#define PUSCH_DMRS_TYPEB_PRESENT 0x1000
#define PUSCH_POWE_RECONFIG_PRESENT 0x2000
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* txConfig in PUSCH-Config  */
   UInt8 tx_config;
   /*^ O, TX_CONFIG_PRESENT, H, 0, 1 ^*/

   /* frequencyHopping in PUSCH-Config */
   UInt8 freq_hopping;
   /*^ O, FREQ_HOPPING_PRESENT, H, 0, 2 ^*/

   /* resourceAllocation in PUSCH-Config  */
   UInt8  resource_allocation;
   /*^ O, UE_PUSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT, H, 0, 2 ^*/

  /* 0:config1, 1:config2 This is applicapble only for resourceAllocationType0 and ignored otherwise */ 
  UInt8 rbg_size;
  /*^ O, UE_PUSCH_RECONFIG_RESOURCE_ALLOC_TYPE_PRESENT, H, 0, 1 ^*/

   /* pusch-AggregationFactor in PUSCH-Config */
   UInt8 aggregation_factor;
   /*^ O, PUSCH_AGGREGATION_FACTOR_PRESENT, H, 0, 8 ^*/

   /* mcs-Table in PUSCH-Config */
   UInt8 mcs_table_enabled;
   /*^ O, PUSCH_MCS_TABLE_PRESENT, H, 0, 2 ^*/

   /* mcs-TableTransformPrecoder in PUSCH-Config */
   UInt8 mcs_table_transform_precoder_enabled;
   /*^ O, PUSCH_MCS_TABLE_TRANSFORM_PRECODER_PRESENT, H, 0, 2 ^*/

   /* transformPrecoder� in PUSCH-Config  */
   UInt8 transform_precoder_enabled;
   /*^ O, PUSCH_TRANSFORM_PRECODER_ENABLED_PRESENT, H, 0, 1 ^*/

   /* Selection between and configuration of dynamic and semi-static beta-offset. If the field is absent or released,
   * the UE applies the value 'semiStatic' and the BetaOffsets according to FFS. Corresponds to L1 parameter */
   uci_on_pusch_info_t  uci_on_pusch;
   /*^ O, UE_PUSCH_RECONFIG_UCI_ON_PUSCH_PRESENT, N, 0, 0 ^*/

   /* codebookSubset in PUSCH-Config */
   UInt8 codebook_subset;
   /*^ O, UE_PUSCH_RECONFIG_CODE_BOOK_SUBSET_PRESENT, H, 0, 2 ^*/

   /* maxRank in PUSCH-Config */
   UInt8 max_rank;
   /*^ O, UE_PUSCH_RECONFIG_MAX_RANK_PRESENT, B, 1, 4 ^*/

   /* dataScramblingIdentityPUSCH in PUSCH-Config */ 
   UInt16 data_sc_id;
   /*^ O, UE_PUSCH_RECONFIG_DATA_SCRAMBLING_ID_PRESENT, H, 0, 1023 ^*/

   /* DMRS configuration for PUSCH transmissions using PUSCH mapping type A */
   dmrs_uplink_config_t dmrs_UplinkForPUSCH_MappingTypeA;
   /*^ O, PUSCH_DMRS_TYPEA_PRESENT, N, 0, 0 ^*/

   /* DMRS configuration for PUSCH transmissions using PUSCH mapping type B */
   dmrs_uplink_config_t dmrs_UplinkForPUSCH_MappingTypeB;
   /*^ O, PUSCH_DMRS_TYPEB_PRESENT, N, 0, 0 ^*/

   pusch_power_reconfig_info_t  pusch_power_reconfig_info;
   /*^ O, PUSCH_POWE_RECONFIG_PRESENT, N, 0, 0 ^*/

}ue_pusch_reconfig_info_t;

typedef struct _ul_bwp_dedicated_reconfig_info_t
{
#define PUCCH_RECONFIG_PRESENT 0x0001
#define PUSCH_RECONFIG_PRESENT 0x0002
#define UL_PDCCH_RECONFIG_PRESENT 0x0004

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* The IE PUCCH-Config is used to configure UE specific PUCCH parameters (per BWP) */
   ue_pucch_reconfig_info_t  pucch_reconfig;
   /*^ O, PUCCH_RECONFIG_PRESENT, N, 0, 0 ^*/
 
   /* The IE PUSCH-Config is used to configure UE specific PUSCH parameters (per BWP) */
   ue_pusch_reconfig_info_t  pusch_reconfig;
   /*^ O, PUSCH_RECONFIG_PRESENT, N, 0, 0 ^*/

   /* Contains Search Spaces and CORESET for Uplink DCI */
   ue_pdcch_reconfig_info_t  pdcch_reconfig;
   /*^ O, UL_PDCCH_RECONFIG_PRESENT, N, 0, 0 ^*/
}ul_bwp_dedicated_reconfig_info_t;

typedef struct _ul_bwp_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of Additional uplink BWP to be added or modified */
   UInt8    ul_bwp_add_mod_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* List of additional uplink bandwidth parts to be added or modified */
   bwp_uplink_t  bwp_uplink[MAX_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}ul_bwp_to_add_mod_info_t;

typedef struct _ul_bwp_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8   ul_bwp_to_release;
   /*^ M, 0, B, 1, 4 ^*/
}ul_bwp_to_release_t;
   
typedef struct _ul_bwp_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the ul_bwp_to_release_list */
   UInt8   ul_bwp_release_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* Additional uplink bandwidth part ID to be released */
   ul_bwp_to_release_t   ul_bwp_to_release_list[MAX_BWP_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}ul_bwp_to_release_info_t;

typedef struct _ul_reconfig_info_t
{
#define INITIAL_UL_BWP_TO_RECONFIG_INFO_PRESENT 0x0001
#define UL_BWP_TO_ADD_MOD_INFO_PRESENT 0x0002
#define UL_BWP_TO_RELEASE_INFO_PRESENT 0x0004
#define UL_BWP_FIRST_ACTIVE_BWPID_PRESENT 0x0008
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* initialUplinkBWP in ServingCellConfig */
   ul_bwp_dedicated_reconfig_info_t  initial_ul_bwp_reconfig_info;
   /*^ O, INITIAL_UL_BWP_TO_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/

   /* uplinkBWP-ToAddModList in ServingCellConfig */
   ul_bwp_to_add_mod_info_t   ul_bwp_to_add_mod_info;
   /*^ O, UL_BWP_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* uplinkBWP-ToReleaseList in ServingCellConfig */
   ul_bwp_to_release_info_t   ul_bwp_to_release_info;
   /*^ O, UL_BWP_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/

   /* ID of the UL BWP to be activated upon performing the RRC (re-)configuration */
   UInt8     first_active_ul_bwp_id;
   /*^ O, UL_BWP_FIRST_ACTIVE_BWPID_PRESENT, H, 0, MAX_BWP_COUNT ^*/
}ul_reconfig_info_t;

typedef struct _csi_report_config_to_release_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/

  /* Count for CSI report config configured  by higher layers. */
  UInt8 csi_report_config_to_release_count;
  /*^ M, 0, B, 1, 48 ^*/

  /* Refer CSI Report config release in Csi-MeasConfig (3GPP TS 38.331) */
  UInt8 resource_list[MAX_NUM_CSI_REPORT_CONFIG];
  /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}csi_report_config_to_release_info_t;

typedef struct _csi_report_config_reconfig_info_t
{
  /* To inform optional parameter presence */
  bitmask_t bitmask;    
  /*^ BITMASK ^*/
#define CSI_REPORT_CONFIG_TO_ADD_MOD_INFO_PRESENT 0x0001
#define CSI_REPORT_CONFIG_TO_RELEASE_INFO_PRESENT 0x0002

  /* Refer CSI-ReportConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_report_config_to_add_mod_info_t csi_report_config_to_add_mod_info;
  /*^ O, CSI_REPORT_CONFIG_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

  /* Refer CSI-ReportConfig release in Csi-MeasConfig (3GPP TS 38.331) */
  csi_report_config_to_release_info_t csi_report_config_to_release_info;
  /*^ O, CSI_REPORT_CONFIG_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/

}csi_report_config_reconfig_info_t;

typedef struct _serving_cell_reconfig_info_t
{
#define SP_CELL_DL_RECONF_INFO_PRESENT 0x0001
#define SP_CELL_UL_RECONF_INFO_PRESENT 0x0002
#define CSI_REPORT_CONFIG_RECONFIG_PRESENT 0x0004

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   /* Downlink Configuration parameters in ServingCellConfig  */
   dl_reconfig_info_t    dl_reconfig_info;
   /*^ O, SP_CELL_DL_RECONF_INFO_PRESENT, N, 0, 0 ^*/

   /* Uplink Configuration parameters in ServingCellConfig */
   ul_reconfig_info_t   ul_reconfig_info;
   /*^ O, SP_CELL_UL_RECONF_INFO_PRESENT, N, 0, 0 ^*/

  /* Refer CSI-ReportConfig in Csi-MeasConfig (3GPP TS 38.331) */
  csi_report_config_reconfig_info_t csi_report_config_reconfig_info;
  /*^ O, CSI_REPORT_CONFIG_RECONFIG_PRESENT, N, 0, 0 ^*/

}serving_cell_reconfig_info_t;


typedef struct _sp_cell_reconfig_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
 
   UInt8     serv_cell_index;
   /*^ M, 0, H, 0,31 ^*/

   serving_cell_reconfig_info_t   serving_cell_reconfig_info;
   /*^ M, 0, N, 0, 0 ^*/
}sp_cell_reconfig_info_t;


typedef struct _sr_to_add_mod_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of SR resources in the sr_to_add_mod_list */
   UInt8     sr_add_mod_count;
   /*^ M, 0, B, 1, 8 ^*/

   /* SchedulingRequestToAddMod in SchedulingRequestConfig */
   sr_config_info_t   sr_to_add_mod_list[MAX_SR_CONFIG_PER_CELL_GROUP];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}sr_to_add_mod_info_t;

typedef struct _sr_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8    sr_to_release;
   /*^ M, 0, H, 0, 7 ^*/
}sr_to_release_t;

typedef struct _sr_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count of SR resources in the sr_to_release_list */
   UInt8    sr_release_count;
   /*^ M, 0, B, 1, 8 ^*/

   /* The IE SchedulingRequestId is used to identify a Scheduling Request instance in the MAC layer */
   sr_to_release_t    sr_to_release_list[MAX_SR_RELEASE_LIST];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}sr_to_release_info_t;

typedef struct _sr_reconfig_info_t
{
#define SR_TO_ADD_MOD_INFO_PRESENT 0x0001
#define SR_TO_RELEASE_INFO_PRESENT 0x0002

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* schedulingRequestToAddModList in SchedulingRequestConfig */
   sr_to_add_mod_info_t    sr_to_add_mod_info;
   /*^ O, SR_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* schedulingRequestToReleaseList in SchedulingRequestConfig */
   sr_to_release_info_t    sr_to_release_info;
   /*^ O, SR_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/
}sr_reconfig_info_t;

typedef struct _tag_to_release_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   UInt8    tag_to_release;
   /*^ M, 0, H, 0, 3 ^*/
}tag_to_release_t;

typedef struct _tag_to_release_info_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Specifies the count in the tag_to_release_list */
   UInt8    tag_release_count;
   /*^ M, 0, B, 1, 4 ^*/

   /* Timing Advance Group ID to be released */
   tag_to_release_t    tag_to_release_list[MAX_NUM_TAGS];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}tag_to_release_info_t;

typedef struct _tag_reconfig_info_t
{
#define TAG_TO_ADD_MOD_INFO_PRESENT 0x0001
#define TAG_TO_RELEASE_INFO_PRESENT 0x0002
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* tag-ToAddModList in TAG-Config */
   cell_gp_tag_config_t   tag_to_add_mod_info;
   /*^ O, TAG_TO_ADD_MOD_INFO_PRESENT, N, 0, 0 ^*/

   /* tag-ToReleaseList in TAG-Config */
   tag_to_release_info_t   tag_to_release_info;
   /*^ O, TAG_TO_RELEASE_INFO_PRESENT, N, 0, 0 ^*/
}tag_reconfig_info_t; 

typedef struct _mac_cell_group_reconfig_info_t
{
#define MAC_SR_RECONFIG_INFO_PRESENT 0x0001
#define MAC_TAG_RECONFIG_INFO_PRESENT 0x0002
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* SchedulingRequestConfig */
   sr_reconfig_info_t   sr_reconfig_info;
   /*^ O, MAC_SR_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/

   /* TAG-Config */
   tag_reconfig_info_t  tag_reconfig_info;
   /*^ O, MAC_TAG_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/
}mac_cell_group_reconfig_info_t;

typedef struct _phy_cell_group_reconfig_info_t
{
#define PHY_CG_RECONFIG_P_NR_PRESENT 0x0001
#define PHY_CG_RECONFIG_HARQ_ACK_CODEBOOK_PRESENT 0x0002

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* limit the UE's uplink transmission power on a carrier frequency */
   SInt8    p_nr;
   /*^ O, PHY_CG_RECONFIG_P_NR_PRESENT, B, -30, 33 ^*/

   /* Corresponds to L1 parameter 'HARQ-ACK-codebook' */
   UInt8    pdsch_harq_ack_codebook;
   /*^ O, PHY_CG_RECONFIG_HARQ_ACK_CODEBOOK_PRESENT, H, 0, 1 ^*/
}phy_cell_group_reconfig_info_t;

typedef struct _cell_group_reconfig_info_t
{
#define MAC_SP_CELL_RECONFIG_INFO_PRESENT 0x0001
#define PHY_CELL_GROUP_RECONFIG_INFO_PRESENT 0x0002
#define MAC_CELL_GROUP_RECONFIG_INFO_PRESENT 0x0004

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   sp_cell_reconfig_info_t    sp_cell_reconfig_info;
   /*^ O, MAC_SP_CELL_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/

   mac_cell_group_reconfig_info_t    mac_cell_group_reconfig_info;
   /*^ O, MAC_CELL_GROUP_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/
  
   phy_cell_group_reconfig_info_t    phy_cell_group_reconfig_info;
   /*^ O, PHY_CELL_GROUP_RECONFIG_INFO_PRESENT, N, 0, 0 ^*/
}cell_group_reconfig_info_t;
      
typedef struct _mac_reconfigure_ue_info_t
{
    
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/
#define MAC_RECONFIG_UE_CAPABILITY_INFO_PRESENT 0x0001
#define MAC_RECONFIG_UE_AMBR_PRESENT            0x0002
#define MAC_RECONFIG_SCELL_PRESENT              0x0004

   cell_group_reconfig_info_t   cell_group_reconfig_info;
   /*^ M, 0, N, 0, 0 ^*/

   ue_capability_info_t  ue_capability_info;
   /*^ O, MAC_RECONFIG_UE_CAPABILITY_INFO_PRESENT, N, 0, 0 ^*/

   ue_ambr_qos_info_t  ue_ambr_qos_info;
   /*^ O, MAC_RECONFIG_UE_AMBR_PRESENT, N, 0, 0 ^*/

   scell_configuration_info_t scell_configuration_info;
   /*^ O, MAC_RECONFIG_SCELL_PRESENT, N, 0, 0 ^*/
}mac_reconfigure_ue_info_t;

typedef struct _delete_lc_req_list_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Number of Logical channel to be deleted */
   UInt8    lc_id_count;
   /*^ M, 0, B, 1, 32 ^*/
  
   /* Logical channel id to be deleted */
   UInt8    lc_id [MAX_LC_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}delete_lc_req_list_t;

typedef struct _ul_lc_reconfig_req_t 
{
#define SR_ID_PRESENT 0x0001
   
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* The ID of the SchedulingRequestConfig that uses this scheduling request resource */
   UInt8   scheduling_request_id;
   /*^ O, SR_ID_PRESENT, H, 0, MAX_SR_RESOURCES ^*/
}ul_lc_reconfig_req_t;

typedef struct _lc_reconfig_req_t
{
#define UL_LC_RECONFIG_PRESENT 0x0001
#define GBR_INFO_RECONFIG_PRESENT 0x0002
    
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* logical channel id */
   UInt8   lch_id;
   /*^ M, 0, B, 1, 32 ^*/

   /* Uplink Logical Channel reconfiguration parameters */
   ul_lc_reconfig_req_t   ul_lc_reconfig_req;
   /*^ O, UL_LC_RECONFIG_PRESENT, N, 0, 0 ^*/

   /* Applies for GBR bearers*/
   gbr_qos_info_t  gbr_qos_info;
   /*^ O, GBR_INFO_RECONFIG_PRESENT, N, 0, 0 ^*/
}lc_reconfig_req_t;

typedef struct _reconfig_lc_req_list_t
{
   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Number of Logical channel to be reconfigured */
   UInt8    lc_id_count;
   /*^ M, 0, B, 1, 32 ^*/

   /* Logical channel reconfiguration for Downlink and Uplink */
   lc_reconfig_req_t   lc_reconfig_req [MAX_LC_COUNT];
   /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}reconfig_lc_req_list_t;


typedef struct _mac_reconfigure_lc_req_t
{
#define MAC_RECONFIG_CREATE_LC_PRESENT 0x0001
#define MAC_RECONFIG_DELETE_LC_PRESENT 0x0002
#define MAC_RECONFIG_RECONFIG_LC_PRESENT 0x0004\

   /* To inform optional parameter presence */
   bitmask_t    bitmask;
   /*^ BITMASK ^*/

   /* Logical Channels to be created for the UE */
   create_lc_req_list_t    create_lc;
   /*^ O, MAC_RECONFIG_CREATE_LC_PRESENT, N, 0, 0 ^*/

   /* Logical Channels to be deleted for the UE */
   delete_lc_req_list_t   delete_lc;
   /*^ O, MAC_RECONFIG_DELETE_LC_PRESENT, N, 0, 0 ^*/

   /* Logical Channels to be reconfigured for the UE */
   reconfig_lc_req_list_t  reconfig_lc;
   /*^ O, MAC_RECONFIG_RECONFIG_LC_PRESENT, N, 0, 0 ^*/
}mac_reconfigure_lc_req_t; 

typedef struct _lc_failure_info_t
{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Logical channel Id failed to be created */
    UInt8   lc_id;
    /*^ M, 0, B, 1, 32 ^*/
   
    /* Cause of failure */
    UInt16  cause;
    /*^ M, 0, N, 0, 0 ^*/
}lc_failure_info_t;     

typedef struct _lc_fail_list_t
{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Number of Logical channel failed to be reconfigured */
    UInt8   lc_id_count;
    /*^ M, 0, B, 1, 32 ^*/

    /* Logical channel Id’s failed to reconfigure */
    lc_failure_info_t lc_fail_list [MAX_LC_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}lc_fail_list_t;

typedef struct mac_ue_stats_t
{
#define  PATH_LOSS_PRESENT   0x0001
#define  PUSCH_AVG_PRESENT  0x0002
#define  PUCCH_AVG_PRESENT  0x0004
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    ue_index_t     ue_index;
    /*^ M, 0, H, 0, MAX_DU_MANAGER_UE_INDEX ^*/

    /* Path loss for the measured periodicity */
    UInt8   path_loss;
    /*^ O, PATH_LOSS_PRESENT, N, 0, 0 ^*/
    /* Average pusch sinr for the measured periodicity */
    UInt8   pusch_sinr_avg;
    /*^ O, PUSCH_AVG_PRESENT, N, 0, 0 ^*/
    /* Average pucch sinr for the measured periodicity */
    UInt8   pucch_sinr_avg;
    /*^ O, PUCCH_AVG_PRESENT, N, 0, 0 ^*/

}mac_ue_stats_t;

typedef struct _pcch_message_t
{
    /* To inform optional parameter presence */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Length of the PCCH message buffer */
    UInt8      msg_len;
     /*^ M, 0, B, 6, 255 ^*/

    /*PCCH message buffer to send */
    UInt8     pcch_msg[MAX_MSG_LEN];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pcch_message_t;


#endif   /* _DU_COMM_INTF_DEFN_H_ */
