/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  $Id: ngap_global_ctx.h
 *
 ****************************************************************************
 *
 *  File Description : This file contains all the information which is 
 *  commonly required for the NGAP stack
 *  
 ***************************************************************************/
#ifndef _NGAP_GLOBAL_CTX_H_
#define _NGAP_GLOBAL_CTX_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include "ngap_intf_mgmnt.h"
#include "ngap_types.h"
#include "rrc_ngap_oam_intf.h"
#include "l3_search_tree.h"


/****************************************************************************
 * Exported Includes
 ****************************************************************************/

typedef enum
{

    GNB_INITIALIZED_RESET,
    AMF_INITIALIZED_RESET

} ngap_reset_initializer_type_et;

typedef enum
{

    RMV_TYPE_UE_CONTEXT_RELEASE,
    RMV_TYPE_NG_RESET

} ngap_ue_ctx_removal_type_et;

typedef struct
{
    UInt8      count;

    UInt8      *amf_index_list;

}amf_reset_list_t;

typedef struct
{
    UInt16      count;

    UInt16      *ue_index_list;

} ngap_reset_list_t;

typedef struct
{
#define NGAP_UE_ASSOS_NG_CONN_LIST_PRESENT  0x01

    UInt8               bitmask;

    ngap_reset_list_t   ongoing_reset_list;

    amf_reset_list_t    amf_list;

    UInt32              rel_complete_rcvd_count_frm_uecc;

    ngap_ue_associated_logical_ng_connection_list_t ue_associated_logical_ng_connection_list;

} ngap_ongoing_reset_proc_t;

typedef struct
{
    SInt16               pdu_session_id;
}pdu_session_id_t;

#define MAX_PDU_PDU_SESSION_ID 255
typedef struct
{
    UInt8               count;
    UInt16              ue_index;
    pdu_session_id_t    pdu_session_id[MAX_PDU_PDU_SESSION_ID];

}active_pdu_session_id_list_t;

typedef struct
{

    UInt8           		is_ue_context_valid;

    UInt8           		is_amf_ue_ngap_id_valid;

    UInt8           		amf_id;

    UInt8           		selected_plmn_index;

    UInt8           		is_ue_index_valid;
    
    UInt16          		ue_index;
    
    cell_index_t    		cell_index;

    UInt32          		ran_ue_ngap_id;

    UInt32          		amf_ue_ngap_id;

    UInt16          		stream_id;

    ngap_ue_ctx_removal_type_et	    ue_context_removal_type;

    ngap_reset_initializer_type_et  reset_initializer_type;

    active_pdu_session_id_list_t    pdu_id_list;

} ngap_ue_context_t;

typedef struct
{
    UInt32      not_allocated_ue_ids_count;
    
    UInt32      not_allocated_ue_ids_cur;
    
    UInt32      *not_allocated_ue_ids;
    
} ran_ue_ngap_context_t;

typedef struct
{
    /* Flag to inform whether DU is deleted or configured */
    UInt8                                   is_du_configured;

    /* Internal DU Identifier */
    UInt16                                  du_index;

    /* gNB-DU-ID */
    UInt64                                  du_id;

    /* List of AMF Those Can Support This DU Configuration i.e. TAC & BPLMNs */
    UInt8                                   supported_amf_idx[MAX_AMF_SUPPORTED];

    /* Served cell info list in a DU */
    served_cell_information_list_t          served_cell_info_list;

} ngap_du_context_t;

typedef struct
{
    rrc_timer_t     ng_setup_gurad_timer;           /* Timer To Guard NG Setup Procedure */
    rrc_timer_t     ran_config_update_guard_timer;  /* Timer To Guard RAN Config Update Procedure */
    rrc_timer_t     ngap_ll_guard_timer;            /* Timer To Guard Lower Layer Communication */
    rrc_timer_t     ngap_reset_guard_timer;         /* Timer To Guard Reset Procedure */
    UInt8           ng_setup_retry_count;           /* Count of Ongoing NG Setup Retry */
    UInt8           ng_reset_retry_count;           /* Count of Ongoing NG Reset Retry */
    UInt8           ran_config_update_retry_count;  /* Count of Ongoing RAN Config Update Retry */
} ngap_amf_timer_info_t;

/* Stream information for an association */
typedef struct
{

#define MAX_NGAP_STREAMS_PER_ASSOCIATION    10

    /* Variable used to distribute the streams Ids among UEs in 
     * round robin fashion */
    UInt8     stream_idx_returned;

    /* Number of streams negotiated for this association */
    UInt8     num_of_streams;

    /* List of available stream Identifiers for this association */
    UInt16    stream_ids[MAX_NGAP_STREAMS_PER_ASSOCIATION];

} ngap_stream_info_t;

typedef struct
{
    l3_search_tree_node_t   anchor_node;

    /*As a key*/
    UInt64          		amf_ue_ngap_id;

    UInt16          		ue_index;
} amf_ngap_id_search_node_t;

/*NGAP_CONTEXT_CHANGES_START*/
typedef struct
{
    l3_search_tree_node_t   anchor_node;

    /*As a key*/
    UInt16          		ue_index;
    
    UInt32          		ran_ue_ngap_id;
} ue_index_search_node_t;
/*NGAP_CONTEXT_CHANGES_STOP*/

typedef struct
{
    l3_search_tree_t    amf_ngap_id_search_tree;
/*NGAP_CONTEXT_CHANGES_START*/
    l3_search_tree_t    ue_index_search_tree;
/*NGAP_CONTEXT_CHANGES_STOP*/
} ngap_search_tree_t;

typedef struct
{

#define NGAP_AMF_GLOBAL_CTX_AMF_NAME_PRESENT    0x01

    UInt32                              bitmask;

    ngap_bool_et                        is_amf_ctx_provision;

    UInt8                               amf_id;

    ng_link_status_et                   ng_link_status;

    ngap_amf_state_et                   current_amf_state;

    ngap_curr_ongoing_amf_procedure_et  current_ongoing_procedure;

    /* gNB Name */
    UInt8                               amf_name[NGAP_MAX_AMF_NAME_LENGTH];

    sctp_sd_t                           sctp_sd;

    ngap_amf_timer_info_t               ng_amf_timer_info;

    ngap_stream_info_t                  stream_info;

    ngap_amf_comm_info_t                amf_comm_info;

    /* Served GUAMI List */
    ngap_served_guami_list_t            served_guami_list;

    /* Relative AMF Capacity */
    UInt8                               relative_amf_capacity;

    /* PLMN Support List */
    ngap_plmn_support_list_t            plmn_support_list;

    /* NG Setup Request Content */
    ngap_setup_request_t                *p_ng_setup_req_with_amf;
       
    /* NG Reset Content */
    ngap_reset_t                        *p_ng_reset_with_amf;

    /* NG RAN Config Update Content */
    ran_config_update_t                 *p_ng_ran_config_update;
        
} ngap_amf_global_context;


typedef struct
{

#define NGAP_GLB_CTX_LOG_LEVEL_PRESENT              0x01
#define NGAP_GLB_CTX_AMF_COMM_INFO_PRESENT          0x02
#define NGAP_GLB_CTX_LOCAL_COMM_INFO_PRESENT        0x04
#define NGAP_GLB_CTX_SCTP_CONFIG_PARAM_PRESENT      0x08
#define NGAP_GLB_CTX_TIMER_CONFIG_PRESENT           0x10
#define NGAP_GLB_CTX_GLOBAL_RAN_NODE_INFO_PRESENT   0x20
#define NGAP_GLB_CTX_SUPPORTED_TA_LIST_PRESENT      0x40
#define NGAP_CONFIGURATION_COMPLETED_BITMASK        0x7F

    ngap_bool_et                    is_ngap_configured;

    UInt32                          ngap_config_bitmask;
    
    ngap_bool_et                    is_logging_enabled;

    ngap_state_et                   current_ngap_state;
    
    UInt8                           log_level;
     
    /* Current Ongoing Procedure at NGAP Stack */
    ngap_curr_ongoing_procedure_et  current_ongoing_proc;

    x2ap_sctp_conf_info_t           ngap_sctp_conf_info;

    ngap_timer_info_t               ngap_timer_info;

    ngap_global_ran_node_info_t     ngap_global_ran_node_info;

    ngap_ip_comm_info_t             ngap_local_comm_info;

    UInt8                           num_amf_count;

    ngap_amf_global_context         amf_context [MAX_AMF_SUPPORTED];

    UInt8                           amf_selection_algo;

    /* Supported TA List */
    ngap_supported_ta_list_t        supported_ta_list;    

    /* NGAP_OAM_INIT_IND Timer Duration */
    rrc_timer_duration_t          	oam_init_ind_duration;

    /* NGAP_OAM_INIT_IND Timer Identifier */
    rrc_timer_t                     oam_init_ind_timer;

    ngap_du_context_t               du_context[MAX_NUM_DU];

    ngap_ue_context_t               *p_p_ue_ngap_contexts;

    ran_ue_ngap_context_t           ngap_ueid_ctx;

    UInt32                          total_ue_supported;

    ngap_search_tree_t              ngap_search_trees;

    ngap_ongoing_reset_proc_t       ongoing_reset_context;

} ngap_global_context_t;

/*ngap_global_context_t *p_ngap_glb_ctx;*/

#endif  /* _NGAP_GLOBAL_CTX_H_  */
