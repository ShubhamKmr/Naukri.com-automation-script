
/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name: rrc_ngap_oam_intf.h
 *
 ****************************************************************************
 *
 *  File Description : This file contains the declarations of data types for
 *                     NGAP-OAM interface file.
 *
 ***************************************************************************/

#ifndef __NGAP_OAM_INTF_H__
#define __NGAP_OAM_INTF_H__

/****************************************************************************
 * Project Includes
 ****************************************************************************/

#include "rrc_defines.h"
#include "ngap_api.h"
#include "ngap_types.h"
#include "rrc_ngap_cu_common_def.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/



/****************************************************************************
 * Exported Definitions
 ****************************************************************************/
/* Hash Defined*/
#define NGAP_MAX_NUM_IP_ADDR                          3
#define MAX_PLMN_ID_BYTES                             3

#define RRC_NGAPOAM_MODULE_ID                         RRC_OAM_MODULE_ID


/****************************************************************************
 * Exported Types
 ****************************************************************************/

#pragma pack(push, 1)

/******************************************************************************
  NGAP_OAM_INIT_IND
 ******************************************************************************/

typedef struct
{
    UInt8 dummy; 
    /*^ M, 0, NOT_PRESENT_IN_MESSAGE ^*/
} ngap_oam_init_ind_t; /*^ API, EMPTY, NGAP_OAM_INIT_IND ^*/ 


/******************************************************************************
  NGAP_OAM_PROVISION_REQ
 ******************************************************************************/

/* Structure defining the configured IPv4 addresses */
typedef struct 
{
    UInt8               num_ipv4_addr;
    /*^ M, 0, B, 1, MAX_NUM_IP_ADDR ^*/

    x2_ip_addr_t        ipv4_addr[NGAP_MAX_NUM_IP_ADDR];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} ngap_ipv4_addr_info_t;


/* Structure defining the configured IPv6 addresses */
typedef struct 
{
    UInt8               num_ipv6_addr;
    /*^ M, 0, B, 1, MAX_NUM_IP_ADDR ^*/

    x2_ipv6_addr_t      ipv6_addr[NGAP_MAX_NUM_IP_ADDR];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} ngap_ipv6_addr_info_t;


/* Structure defining the socket communication specific 
 * configuration to be used by NGAP */
typedef struct 
{

#define NGAP_COMM_INFO_IPV4_ADDR_PRESENT      0x01
#define NGAP_COMM_INFO_IPV6_ADDR_PRESENT      0x02
   
    rrc_bitmask_t                   bitmask;
    /*^ BITMASK ^*/

    /* Configured IPv4 addresses for NGAP */
    ngap_ipv4_addr_info_t       ipv4_addr;
    /*^ O, NGAP_COMM_INFO_IPV4_ADDR_PRESENT, B, 1, NGAP_MAX_NUM_IP_ADDR ^*/

    /* Configured IPv6 addresses for NGAP */
    ngap_ipv6_addr_info_t       ipv6_addr;
    /*^ O, NGAP_COMM_INFO_IPV6_ADDR_PRESENT, B, 1, NGAP_MAX_NUM_IP_ADDR ^*/

} ngap_ip_comm_info_t;

/* Structure defining the socket communication specific 
 * configuration to be used by AMF */
typedef struct 
{
    /* Number of SCTP Streams To Be Used For a AMF Connection */
    UInt8                           num_sctp_streams;  
    /*^ M, 0, N, 0, 0 ^*/

    /* Number of SCTP Association To Be Used For a AMF Connection */
    UInt8                           num_sctp_association;  
    /*^ M, 0, N, 0, 0 ^*/

    /* NG Connection Mode to check whether connection 
    *   need to be establised with one AMF IP or All 
    */
    UInt8                           ng_connection_mode;  
    /*^ M, 0, N, 0, 0 ^*/

    /* IP Information of Configured AMF */    
    ngap_ip_comm_info_t             ngap_amf_ip_info;
    /*^ M, 0, N, 0, 0 ^*/

} ngap_amf_comm_info_t;

/* Structure defining the timer specific configuration to 
 * be used by NGAP. */

typedef struct 
{

#define NGAP_HEALTH_MONITOR_TIMER_PRESENT       0x01

    rrc_bitmask_t       bitmask; 
    /*^ BITMASK ^*/

    UInt8               ng_setup_retry_count; 
    /*^ M, 0, H, 0, 10 ^*/

    UInt8               ng_reset_retry_count; 
    /*^ M, 0, H, 0, 10 ^*/

    UInt32              ng_setup_timer; 
    /*^ M, 0, B, 50, 65535 ^*/

    UInt32              ng_reset_timer; 
    /*^ M, 0, B, 50, 65535 ^*/

    UInt32              ng_conn_recovery_timer; 
    /*^ M, 0, B, 50, 65535 ^*/

    UInt16              ngap_health_monitor_timer; 
    /*^ O, NGAP_HEALTH_MONITOR_TIMER_PRESENT, H, 50, 65535  ^*/

} ngap_timer_info_t;



/* 
 * Structure defining the Global RAN Info to be used by NGAP 
 */
typedef struct
{

#define NGAP_GLOBAL_RAN_INFO_NODE_ID_PRESENT        0x01
#define NGAP_GLOBAL_RAN_INFO_NODE_NAME_PRESENT      0x02
#define NGAP_GLOBAL_RAN_INFO_PAGING_DRX_PRESENT     0x04

    rrc_bitmask_t               bitmask;
    /*^ BITMASK ^*/

    /* RAN NODE Id */
    ngap_global_ran_node_id_t   ngap_ran_node_id;
    /*^ O, NGAP_GLOBAL_RAN_INFO_NODE_ID_PRESENT, N, 0, 0 ^*/

    /* Length of RAN Node Name */
    UInt8                       ran_node_name_length;
    /*^ O, NGAP_GLOBAL_RAN_INFO_NODE_NAME_PRESENT, N, 0, 0 ^*/

    /* RAN Node Name */
    UInt8                       ran_node_name [NGAP_MAX_RAN_NODE_NAME_LENGTH];
    /*^ O, NGAP_GLOBAL_RAN_INFO_NODE_NAME_PRESENT, OCTET_STRING, VARIABLE ^*/

    /* Default Paging DRX */
    UInt32                      default_paging_drx;
    /*^ O, NGAP_GLOBAL_RAN_INFO_PAGING_DRX_PRESENT, N, 0, 0 ^*/

} ngap_global_ran_node_info_t;

/* NGAP_OAM_PROVISION_REQ */
typedef struct
{

#define NGAP_LOG_LEVEL_PRESENT                  0x01
#define NGAP_AMF_COMM_INFO_PRESENT              0x02
#define NGAP_LOCAL_COMM_INFO_PRESENT            0x04
#define NGAP_SCTP_CONFIG_PARAM_PRESENT          0x08
#define NGAP_TIMER_CONFIG_PRESENT               0x10
#define NGAP_GLOBAL_RAN_NODE_INFO_PRESENT       0x20

    rrc_bitmask_t                       bitmask; 
    /*^ BITMASK ^*/

    /* Log Level */
    UInt8                               log_level;          
    /*^ M, 0, H, 0, 127 ^*/

    /* Number of Supported AMF */
    UInt8                               num_amf;          
    /*^ M, 0, H, 0, MAX_AMF_SUPPORTED ^*/
    
    /* AMF Communication Info  */
    ngap_amf_comm_info_t                amf_comm_info [MAX_AMF_SUPPORTED];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
    
    /* Local NGAP Communication IP Info  */
    ngap_ip_comm_info_t                 ngap_local_comm_info;          
    /*^ M, 0, N, 0, 0 ^*/

    /* Local NGAP Communication Port Info  */
    UInt32                              ngap_local_port_num;
    /*^ M, 0, N, 0, 0 ^*/
    
    /* NGAP Sctp Configuration Pparameters For All AMF/Associations */
    x2ap_sctp_conf_info_t               ngap_sctp_conf_param;     
    /*^ O, NGAP_SCTP_CONFIG_PARAM_PRESENT, N, 0, 0 ^*/

    /* NGAP Timer Specific Configuration */
    ngap_timer_info_t                   ngap_timer_info;        
    /*^ O, NGAP_TIMER_CONFIG_PRESENT, N, 0, 0 ^*/

    /* NGAP RAN Node Info */
    ngap_global_ran_node_info_t         global_ran_node_info;
    /*^ O, NGAP_GLOBAL_RAN_NODE_INFO_PRESENT, N, 0, 0 ^*/

} ngap_oam_provision_req_t;   /*^ API, NGAP_OAM_PROVISION_REQ ^*/


/**************************************************************************
 * NGAP_OAM_PROVISION_RESP
 *************************************************************************/

typedef struct
{
    UInt8    response;
    /*^ M, 0, H, 0, 1 ^*/  /* rrc_return_et */

} ngap_oam_provision_resp_t;  /*^ API, NGAP_OAM_PROVISION_RESP ^*/

/******************************************************************************
  NGAP_OAM_NGAP_LINK_STATUS_IND
 ******************************************************************************/

typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;
    /*^ M, 0, N, 0, 0 ^*/

    /* TAI Slice Support List - To be added later */

} supported_plmn_item_t;

typedef struct
{
    /* Number of Supported PLMN List */
    UInt8                    plmn_count;
    /*^ M, 0, H, 0, MAX_NUM_SUPPORTED_PLMN_LIST ^*/

    /* PLMN Identity */
    supported_plmn_item_t    supported_plmn[MAX_NUM_SUPPORTED_PLMN_LIST];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} supported_plmn_list_t;


typedef struct
{

#define NG_LINK_STATUS_AMF_NAME_PRESENT     0x01

    rrc_bitmask_t               bitmask;   
    /*^ BITMASK ^*/

    /* Index of AMF Context */
    UInt8                       amf_index;      
    /*^ M, 0, H, 0, MAX_AMF_SUPPORTED ^*/
    
    /* Status of NGAP LINK */
    UInt8                       ng_link_status; 
    /*^ M, 0, H, 0, 1 ^*/ /* ng_link_status_et */

    /* GUAMI Information as Provided by AMF */
    ngap_served_guami_list_t    guami;
    /*^ M, 0, N, 0, 0 ^*/

    /* AMF Name as Provided by AMF */
    UInt8                       amf_name[NGAP_MAX_AMF_NAME_LENGTH];
    /*^ O, NG_LINK_STATUS_AMF_NAME_PRESENT, OCTET_STRING, FIXED ^*/    

    /* IP Information of AMF */
    ngap_ip_comm_info_t         amf_conection_info;
    /*^ M, 0, N, 0, 0 ^*/    

    /* Supported PLMN List of AMF */
    supported_plmn_list_t       plmn_support_list;
    /*^ M, 0, N, 0, 0 ^*/

} ngap_oam_ngap_link_status_ind_t; /*^ API, NGAP_OAM_NGAP_LINK_STATUS_IND ^*/


/******************************************************************************
  NGAP_OAM_ALARM_NOTIFICATION_IND
 ******************************************************************************/

typedef struct
{

#define MAX_ALARM_STRING_SIZE   256

    /* Alarm ID */
    UInt16          alarm_id; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Alarm Criticality Info - alarm_criticality_et */
    UInt16          alarm_criticality; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Alarm String to Provide Information of Possbile Error */
    UInt8           alarm_string [MAX_ALARM_STRING_SIZE];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    
} ngap_oam_alarm_notification_t; /*^ API, NGAP_OAM_ALARM_NOTIFICATION_IND ^*/


#pragma pack(pop)


/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

#endif /* __NGAP_OAM_INTF_H__ */
