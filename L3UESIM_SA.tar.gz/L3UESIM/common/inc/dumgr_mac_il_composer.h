/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2014 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file dumgr_mac_il_composer.h contains the prototypes 
 *                     of DUMGR-MAC interface message composing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _DUMGR_MAC_IL_COMPOSER_H_
#define _DUMGR_MAC_IL_COMPOSER_H_

#include "gnb_defines.h"
#include "dumgr_mac_intf.h"
#include "gnb_msg_mgmt.h"

gnb_length_t
gnb_il_get_dumgr_mac_cell_config_req_len
(
    dumgr_mac_cell_config_req_t *p_dumgr_mac_cell_config_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_cell_config_req
(
    UInt8  **pp_buffer,
    dumgr_mac_cell_config_req_t *p_dumgr_mac_cell_config_req
);

gnb_length_t
gnb_il_get_mac_dumgr_cell_config_resp_len
(
    mac_dumgr_cell_config_resp_t *p_mac_dumgr_cell_config_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_cell_config_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_cell_config_resp_t *p_mac_dumgr_cell_config_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_cell_reconfig_req_len
(
    dumgr_mac_cell_reconfig_req_t *p_dumgr_mac_cell_reconfig_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_cell_reconfig_req
(
    UInt8  **pp_buffer,
    dumgr_mac_cell_reconfig_req_t *p_dumgr_mac_cell_reconfig_req
);

gnb_length_t
gnb_il_get_mac_dumgr_cell_reconfig_resp_len
(
    mac_dumgr_cell_reconfig_resp_t *p_mac_dumgr_cell_reconfig_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_cell_reconfig_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_cell_reconfig_resp_t *p_mac_dumgr_cell_reconfig_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_cell_start_req_len
(
    dumgr_mac_cell_start_req_t *p_dumgr_mac_cell_start_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_cell_start_req
(
    UInt8  **pp_buffer,
    dumgr_mac_cell_start_req_t *p_dumgr_mac_cell_start_req
);

gnb_length_t
gnb_il_get_mac_dumgr_cell_start_resp_len
(
    mac_dumgr_cell_start_resp_t *p_mac_dumgr_cell_start_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_cell_start_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_cell_start_resp_t *p_mac_dumgr_cell_start_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_cell_stop_req_len
(
    dumgr_mac_cell_stop_req_t *p_dumgr_mac_cell_stop_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_cell_stop_req
(
    UInt8  **pp_buffer,
    dumgr_mac_cell_stop_req_t *p_dumgr_mac_cell_stop_req
);

gnb_length_t
gnb_il_get_mac_dumgr_cell_stop_resp_len
(
    mac_dumgr_cell_stop_resp_t *p_mac_dumgr_cell_stop_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_cell_stop_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_cell_stop_resp_t *p_mac_dumgr_cell_stop_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_cell_delete_req_len
(
    dumgr_mac_cell_delete_req_t *p_dumgr_mac_cell_delete_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_cell_delete_req
(
    UInt8  **pp_buffer,
    dumgr_mac_cell_delete_req_t *p_dumgr_mac_cell_delete_req
);

gnb_length_t
gnb_il_get_mac_dumgr_cell_delete_resp_len
(
    mac_dumgr_cell_delete_resp_t *p_mac_dumgr_cell_delete_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_cell_delete_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_cell_delete_resp_t *p_mac_dumgr_cell_delete_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_rach_resource_req_len
(
    dumgr_mac_rach_resource_req_t *p_dumgr_mac_rach_resource_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_rach_resource_req
(
    UInt8  **pp_buffer,
    dumgr_mac_rach_resource_req_t *p_dumgr_mac_rach_resource_req
);

gnb_length_t
gnb_il_get_mac_dumgr_rach_resource_resp_len
(
    mac_dumgr_rach_resource_resp_t *p_mac_dumgr_rach_resource_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_rach_resource_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_rach_resource_resp_t *p_mac_dumgr_rach_resource_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_rach_resource_rel_ind_len
(
    dumgr_mac_rach_resource_rel_ind_t *p_dumgr_mac_rach_resource_rel_ind
);

gnb_return_t
gnb_il_compose_dumgr_mac_rach_resource_rel_ind
(
    UInt8  **pp_buffer,
    dumgr_mac_rach_resource_rel_ind_t *p_dumgr_mac_rach_resource_rel_ind
);

gnb_length_t
gnb_il_get_dumgr_mac_reset_ue_entity_req_len
(
    dumgr_mac_reset_ue_entity_req *p_dumgr_mac_reset_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_reset_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_mac_reset_ue_entity_req *p_dumgr_mac_reset_ue_entity_req
);

gnb_length_t
gnb_il_get_mac_dumgr_reset_ue_entity_resp_len
(
    mac_dumgr_reset_ue_entity_resp *p_mac_dumgr_reset_ue_entity_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_reset_ue_entity_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_reset_ue_entity_resp *p_mac_dumgr_reset_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_delete_ue_entity_req_len
(
    dumgr_mac_delete_ue_entity_req_t *p_dumgr_mac_delete_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_delete_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_mac_delete_ue_entity_req_t *p_dumgr_mac_delete_ue_entity_req
);

gnb_length_t
gnb_il_get_mac_dumgr_delete_ue_entity_resp_len
(
    mac_dumgr_delete_ue_entity_resp_t *p_mac_dumgr_delete_ue_entity_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_delete_ue_entity_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_delete_ue_entity_resp_t *p_mac_dumgr_delete_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_purge_cell_ues_req_len
(
    dumgr_mac_purge_cell_ues_req_t *p_dumgr_mac_purge_cell_ues_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_purge_cell_ues_req
(
    UInt8  **pp_buffer,
    dumgr_mac_purge_cell_ues_req_t *p_dumgr_mac_purge_cell_ues_req
);

gnb_length_t
gnb_il_get_mac_dumgr_purge_cell_ues_resp_len
(
    mac_dumgr_purge_cell_ues_resp_t *p_mac_dumgr_purge_cell_ues_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_purge_cell_ues_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_purge_cell_ues_resp_t *p_mac_dumgr_purge_cell_ues_resp
);

gnb_length_t
gnb_il_get_mac_create_ue_entity_req_len
(
    mac_create_ue_entity_req_t *p_mac_create_ue_entity_req
);

gnb_return_t
gnb_il_compose_mac_create_ue_entity_req
(
    UInt8  **pp_buffer,
    mac_create_ue_entity_req_t *p_mac_create_ue_entity_req
);

gnb_length_t
gnb_il_get_mac_create_ue_entity_resp_len
(
    mac_create_ue_entity_resp_t *p_mac_create_ue_entity_resp
);

gnb_return_t
gnb_il_compose_mac_create_ue_entity_resp
(
    UInt8  **pp_buffer,
    mac_create_ue_entity_resp_t *p_mac_create_ue_entity_resp
);

gnb_length_t
gnb_il_get_dumgr_mac_reconfig_ue_entity_req_len
(
    dumgr_mac_reconfig_ue_entity_req_t *p_dumgr_mac_reconfig_ue_entity_req
);

gnb_return_t
gnb_il_compose_dumgr_mac_reconfig_ue_entity_req
(
    UInt8  **pp_buffer,
    dumgr_mac_reconfig_ue_entity_req_t *p_dumgr_mac_reconfig_ue_entity_req
);

gnb_length_t
gnb_il_get_mac_dumgr_reconfig_ue_entity_resp_len
(
    mac_dumgr_reconfig_ue_entity_resp_t *p_mac_dumgr_reconfig_ue_entity_resp
);

gnb_return_t
gnb_il_compose_mac_dumgr_reconfig_ue_entity_resp
(
    UInt8  **pp_buffer,
    mac_dumgr_reconfig_ue_entity_resp_t *p_mac_dumgr_reconfig_ue_entity_resp
);

gnb_length_t
gnb_il_get_mac_dumgr_ul_ccch_msg_ind_len
(
    mac_dumgr_ul_ccch_msg_ind_t *p_mac_dumgr_ul_ccch_msg_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_ul_ccch_msg_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_ul_ccch_msg_ind_t *p_mac_dumgr_ul_ccch_msg_ind
);

gnb_length_t
gnb_il_get_dumgr_mac_dl_ccch_msg_ind_len
(
    dumgr_mac_dl_ccch_msg_ind_t *p_dumgr_mac_dl_ccch_msg_ind
);

gnb_return_t
gnb_il_compose_dumgr_mac_dl_ccch_msg_ind
(
    UInt8  **pp_buffer,
    dumgr_mac_dl_ccch_msg_ind_t *p_dumgr_mac_dl_ccch_msg_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_si_msg_ind_len
(
    mac_dumgr_si_msg_ind_t *p_mac_dumgr_si_msg_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_si_msg_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_si_msg_ind_t *p_mac_dumgr_si_msg_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_periodic_stats_ind_len
(
    mac_dumgr_periodic_stats_ind_t *p_mac_dumgr_periodic_stats_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_periodic_stats_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_periodic_stats_ind_t *p_mac_dumgr_periodic_stats_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_ue_sync_ind_len
(
    mac_dumgr_ue_sync_ind_t *p_mac_dumgr_ue_sync_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_ue_sync_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_ue_sync_ind_t *p_mac_dumgr_ue_sync_ind
);

gnb_length_t
gnb_il_get_dumgr_mac_pcch_msg_ind_len
(
    dumgr_mac_pcch_msg_ind_t *p_dumgr_mac_pcch_msg_ind
);

gnb_return_t
gnb_il_compose_dumgr_mac_pcch_msg_ind
(
    UInt8  **pp_buffer,
    dumgr_mac_pcch_msg_ind_t *p_dumgr_mac_pcch_msg_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_sfn_slot_ind_len
(
    mac_dumgr_sfn_slot_ind_t *p_mac_dumgr_sfn_slot_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_sfn_slot_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_sfn_slot_ind_t *p_mac_dumgr_sfn_slot_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_sfn_err_ind_len
(
    mac_dumgr_sfn_err_ind_t *p_mac_dumgr_sfn_err_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_sfn_err_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_sfn_err_ind_t *p_mac_dumgr_sfn_err_ind
);

gnb_length_t
gnb_il_get_mac_dumgr_beam_switch_ind_len
(
    mac_dumgr_beam_switch_ind_t *p_mac_dumgr_beam_switch_ind
);

gnb_return_t
gnb_il_compose_mac_dumgr_beam_switch_ind
(
    UInt8  **pp_buffer,
    mac_dumgr_beam_switch_ind_t *p_mac_dumgr_beam_switch_ind
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_cell_config_req
(
    dumgr_mac_cell_config_req_t  *p_dumgr_mac_cell_config_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_cell_config_resp
(
    mac_dumgr_cell_config_resp_t  *p_mac_dumgr_cell_config_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_cell_reconfig_req
(
    dumgr_mac_cell_reconfig_req_t  *p_dumgr_mac_cell_reconfig_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_cell_reconfig_resp
(
    mac_dumgr_cell_reconfig_resp_t  *p_mac_dumgr_cell_reconfig_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_cell_start_req
(
    dumgr_mac_cell_start_req_t  *p_dumgr_mac_cell_start_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_cell_start_resp
(
    mac_dumgr_cell_start_resp_t  *p_mac_dumgr_cell_start_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_cell_stop_req
(
    dumgr_mac_cell_stop_req_t  *p_dumgr_mac_cell_stop_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_cell_stop_resp
(
    mac_dumgr_cell_stop_resp_t  *p_mac_dumgr_cell_stop_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_cell_delete_req
(
    dumgr_mac_cell_delete_req_t  *p_dumgr_mac_cell_delete_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_cell_delete_resp
(
    mac_dumgr_cell_delete_resp_t  *p_mac_dumgr_cell_delete_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_rach_resource_req
(
    dumgr_mac_rach_resource_req_t  *p_dumgr_mac_rach_resource_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_rach_resource_resp
(
    mac_dumgr_rach_resource_resp_t  *p_mac_dumgr_rach_resource_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_rach_resource_rel_ind
(
    dumgr_mac_rach_resource_rel_ind_t  *p_dumgr_mac_rach_resource_rel_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_reset_ue_entity_req
(
    dumgr_mac_reset_ue_entity_req  *p_dumgr_mac_reset_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_reset_ue_entity_resp
(
    mac_dumgr_reset_ue_entity_resp  *p_mac_dumgr_reset_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_delete_ue_entity_req
(
    dumgr_mac_delete_ue_entity_req_t  *p_dumgr_mac_delete_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_delete_ue_entity_resp
(
    mac_dumgr_delete_ue_entity_resp_t  *p_mac_dumgr_delete_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_purge_cell_ues_req
(
    dumgr_mac_purge_cell_ues_req_t  *p_dumgr_mac_purge_cell_ues_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_purge_cell_ues_resp
(
    mac_dumgr_purge_cell_ues_resp_t  *p_mac_dumgr_purge_cell_ues_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_create_ue_entity_req
(
    mac_create_ue_entity_req_t  *p_mac_create_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_create_ue_entity_resp
(
    mac_create_ue_entity_resp_t  *p_mac_create_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_reconfig_ue_entity_req
(
    dumgr_mac_reconfig_ue_entity_req_t  *p_dumgr_mac_reconfig_ue_entity_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_reconfig_ue_entity_resp
(
    mac_dumgr_reconfig_ue_entity_resp_t  *p_mac_dumgr_reconfig_ue_entity_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_ul_ccch_msg_ind
(
    mac_dumgr_ul_ccch_msg_ind_t  *p_mac_dumgr_ul_ccch_msg_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_dl_ccch_msg_ind
(
    dumgr_mac_dl_ccch_msg_ind_t  *p_dumgr_mac_dl_ccch_msg_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_si_msg_ind
(
    mac_dumgr_si_msg_ind_t  *p_mac_dumgr_si_msg_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_periodic_stats_ind
(
    mac_dumgr_periodic_stats_ind_t  *p_mac_dumgr_periodic_stats_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_ue_sync_ind
(
    mac_dumgr_ue_sync_ind_t  *p_mac_dumgr_ue_sync_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_dumgr_mac_pcch_msg_ind
(
    dumgr_mac_pcch_msg_ind_t  *p_dumgr_mac_pcch_msg_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_sfn_slot_ind
(
    mac_dumgr_sfn_slot_ind_t  *p_mac_dumgr_sfn_slot_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_sfn_err_ind
(
    mac_dumgr_sfn_err_ind_t  *p_mac_dumgr_sfn_err_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_dumgr_il_send_mac_dumgr_beam_switch_ind
(
    mac_dumgr_beam_switch_ind_t  *p_mac_dumgr_beam_switch_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

#endif /* _DUMGR_MAC_IL_COMPOSER_H_ */
