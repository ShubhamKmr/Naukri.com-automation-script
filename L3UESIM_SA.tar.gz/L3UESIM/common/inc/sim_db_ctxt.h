#ifndef _SIM_DB_CTXT_H_
#define _SIM_DB_CTXT_H_
#include "lteTypes.h"
#include "stdio.h"
#include "ctype.h"
#include "stdbool.h"
#include "test_suite_mgmt.h"
#include "rrc_ngap_common_def.h"
#define MAX_L2_SIM_INSTANCE 2
#define MAX_SUPPORTED_CELL_PER_INST 4
#define MAX_SUPPORTED_UE_PER_CELL  64
#include "rrc_asn_enc_dec_nr_sim.h"
#define MAX_SUPPORTED_UE  64
#define MAX_SUPPORTED_ENB 1
#define MAX_SUPPORTED_CELL 8 /* This should be multiplication of MAX_L2_SIM_INSTANCE x MAX_SUPPORTED_CELL_PER_INST */

typedef unsigned int imsi_t;

typedef struct _ngap_id_t
{
    union {
        bool   amf_ue_ngap_id_present:1;
    }u;

    unsigned long long amf_ue_ngap_id; 
    unsigned int ran_ue_ngap_id; 

}ngap_id_t;


typedef struct _eRab_context_t
{
    union {
        bool eRab_id_present:1;
        bool drb_id_present:1;
        bool lc_id_present:1;
        bool qci_present:1;
    }u;
    unsigned char       eRab_id;
    unsigned char       drb_id;
    unsigned char       lc_id;
    unsigned char       qci;
}eRab_context_t;

/*shourya_changes*/
#if 1

typedef struct _uesim_node_ref_t
{
    void *prev;

    void *next;

}uesim_node_ref_t;

typedef struct _uesim_meas_object_to_add_mod_item_t
{
    unsigned char   meas_object_id;
    
    unsigned int    ssbFrequency;

}uesim_meas_object_to_add_mod_item_t;

typedef struct _uesim_meas_object_to_add_mod_list_t
{
    unsigned char                             count;
    
    uesim_meas_object_to_add_mod_item_t       meas_object_node_data;

    uesim_node_ref_t                          ref_node; 
    
}uesim_meas_object_to_add_mod_list_t;

typedef struct _uesim_meas_id_to_add_mod_item_t
{
    unsigned char        meas_id;

    unsigned char        meas_object_id;

    unsigned char        report_config_id;  

}uesim_meas_id_to_add_mod_item_t;

typedef struct _uesim_meas_id_to_add_mod_list_t
{
    unsigned char                         count;

    uesim_meas_id_to_add_mod_item_t       meas_id_node_data;
    
    uesim_node_ref_t                      ref_node;

}uesim_meas_id_to_add_mod_list_t;

typedef struct _uesim_meas_report_config_to_add_mod_item_t
{
    unsigned int                    report_config_id;
        
}uesim_meas_report_config_to_add_mod_item_t;


typedef struct _uesim_meas_report_config_to_add_mod_list_t
{
    unsigned char                                 count;

    uesim_meas_report_config_to_add_mod_item_t    meas_report_node_data;

    uesim_node_ref_t                              ref_node;
        
}uesim_meas_report_config_to_add_mod_list_t;

typedef struct _meas_config_t {
    
    uesim_meas_object_to_add_mod_list_t           meas_object_add_mod_list;
    
    uesim_meas_report_config_to_add_mod_list_t    meas_report_config_list;

    uesim_meas_id_to_add_mod_list_t               meas_id_add_mod_list;

}meas_config_t;
#endif
/*shourya_changes*/

/*HO_fix*/
typedef struct ue_moreThanOneRCL_primary_pth
{   
    unsigned int cellGroup;

    unsigned int logicalChannel;

}ue_moreThanOneRCL_primary_pth_t;

typedef struct ue_pdcp_conf_moreThanOneRLC
{

   ue_moreThanOneRCL_primary_pth_t  primary_path;

   unsigned int ul_DataSplitThreshold;

   bool pdcp_Duplication;

}ue_pdcp_conf_moreThanOneRLC_t;


typedef struct ue_pdcp_conf_drb
{
    unsigned int discardTimer;

    unsigned int pdcp_SN_SizeUL;

    unsigned int pdcp_SN_SizeDL;

    unsigned int integrityProtection;

    unsigned int statusReportRequired;

    unsigned int outOfOrderDelivery;

}ue_pdcp_conf_drb_t;

typedef struct ue_pdcp_config
{
    ue_pdcp_conf_drb_t  drb;

    ue_pdcp_conf_moreThanOneRLC_t moreThanOneRLC;

    unsigned int t_reordering;

    unsigned int  cipheringDisabled;

}ue_pdcp_config_t;

typedef struct ue_srb_add_list_item
{
    unsigned char srb_id;
    
    unsigned int reestablish_pdcp;

    unsigned int discard_on_pdcp;

    ue_pdcp_config_t    pdcp_config;

}ue_srb_add_list_item_t;

typedef struct ue_srb_to_add_list
{
    unsigned int count;
    
    ue_srb_add_list_item_t  srb_item[4];

}ue_srb_to_add_list_t;

typedef struct ue_sdap_flows_to_add_list
{
    int count;

    unsigned char elem[64];

}ue_sdap_flows_to_add_list_t;

typedef struct ue_sdap_config
{
    unsigned char pdu_Session;
    
    unsigned int sdap_HeaderDL;

    unsigned int sdap_HeaderUL;

    bool defaultDRB;

    ue_sdap_flows_to_add_list_t flows_to_add_list;

}ue_sdap_config_t;

typedef struct ue_drb_cn_assn
{
    unsigned char eps_BearerIdentity;

    ue_sdap_config_t    sdap_config;

}ue_drb_cn_assn_t;


typedef struct ue_drb_to_add_list_item
{
    ue_drb_cn_assn_t cn_assn;
    
    bool isValidDRB;

    unsigned int drb_id;

    unsigned int reestablishPDCP;

    unsigned int recoverPDCP;

    ue_pdcp_config_t    pdcp_config;

}ue_drb_to_add_list_item_t;

typedef struct ue_drb_to_add_list
{
    unsigned int count;

    ue_drb_to_add_list_item_t   drb_list[33];

}ue_drb_to_add_list_t;


/*HO_fix*/

typedef struct _ue_sa_context_t
{
     struct {
         unsigned integrityProtAlgorithmPresent : 1;
         bool ng_s_tmsiPresent:1;
     } m;
       unsigned int cipheringAlgorithm;
       unsigned int integrityProtAlgorithm;
    unsigned char security_key[32];
    ngap_id_t     ngap_id_info;
    unsigned short  erab_cnt;
    eRab_context_t eRab_ctxt[8];
    ngap_5g_s_tmsi_t ng_s_tmsi;
    unsigned char keys[32];
    meas_config_t meas_config;

    /*HO_fix*/
    ue_srb_to_add_list_t    srb_list;
    ue_drb_to_add_list_t    drb_list;
    /*HO_fix*/


}ue_sa_context_t;

typedef struct _ue_nsa_context_t
{
    /* Unique eNB Identifier */
    unsigned short enb_id;

    /* MeNB UE X2AP ID */
    unsigned short menb_ue_x2ap_id;

    /* SeNB UE X2AP ID */
    unsigned short senb_ue_x2ap_id;

    /* MeNB UE X2AP ID extension */
    unsigned int   menb_ue_x2ap_id_extn;

    /* SeNB UE X2AP ID extension */
    unsigned int   senb_ue_x2ap_id_extn;

    /* SgNB UE X2AP ID */
    unsigned short sgnb_ue_x2ap_id;
    unsigned int sgnb_ue_x2ap_id_extn;
    unsigned short menb_sgnb_ue_x2ap_id;
    unsigned int gnb_cu_ue_fiap_id;
    unsigned int gnb_du_ue_fiap_id;
    unsigned int f1_ue_index;
}ue_nsa_context_t;

/*PUE Changes start*/
typedef enum
{
    UE_IDLE,
    W_FOR_UE_CREATE_RESP,
    W_FOR_UE_RECONFIG_RESP,
    W_FOR_UE_RACH_RESP,
    W_FOR_UE_DELETE_RESP,
    W_FOR_PDCP_SECURITY_CNF,
    W_PDCP_MAC_I_RESP
}ue_wait_state_et;

typedef enum
{
    CELL_IDLE,
    W_FOR_CELL_INIT,
    W_FOR_CELL_SI_IND,
    W_FOR_CELL_RECONFIG_RESP,
    CELL_ACTIVE,
}cell_wait_state_et;

typedef enum
{
    UESIM_RRC_CONNECTED,
    UESIM_HO_ONGOING,
    /*shourya_fix*/
    UESIM_HO_SUCCESS_ONGOING,
    /*shourya_fix*/
    UESIM_REESTABLISMENT,
}ue_rrc_state_et;


typedef struct _targetCellId_info
{
    unsigned int numbits;
    unsigned char data[5];
}targetCellId_info_t;

typedef struct uesim_restab_info
{
    union {
        bool is_reestablish_present:1;
    }u;
    unsigned char is_reestablish;
    unsigned short sourcePhysCellId;
    targetCellId_info_t targetCellIdentity;
    unsigned int cause;
}uesim_reestab_info_t;
/*PUE Changes end*/
/* Structure defining the content of UEs used in a test case */
typedef struct
{
    /* Flag to indicate that this UE context is currently in use */
    bool           inUse;

    /* Unique UE identifier */
    unsigned int   imsi;
    unsigned int   rnti;
    /*PUE Changes start*/
    sim_activity_t *activities;
    sim_activity_t *amf_activities;
    unsigned int l2_ue_context;
    ue_wait_state_et current_state;
    /*PUE Changes end*/
    ue_rrc_state_et current_state_ue;
#define UESIM_NSA_TYPE   0
#define UESIM_SA_TYPE   1

    int             type; /* SA or NSA */
    union {
        ue_nsa_context_t nsa_ue_info;
        ue_sa_context_t sa_ue_info;
    }u;

    uesim_reestab_info_t reestab_info;
} tc_ue_context_t;

typedef struct _ue_nr_sib_info_t
{
    ue_nr_rrc_CellAccessRelatedInfo cellAccessRelatedInfo;
}ue_nr_sib_info_t;

typedef struct _FrequencyInfoDL
{
    struct {
        unsigned absoluteFrequencySSBPresent : 1;
    } m;
    unsigned int absoluteFrequencySSB;
    unsigned int absoluteFrequencyPointA;
}FrequencyInfoDL;

typedef struct _tc_cell_ctxt_t
{
    tc_ue_context_t   ue_context[MAX_SUPPORTED_UE_PER_CELL];
    
    /* Last allocated MeNB UE X2AP ID */
    unsigned short    last_used_menb_ue_x2ap_id;

    /* Last allocated MeNB UE X2AP ID extension */
    unsigned int      last_used_menb_ue_x2ap_id_extn;

    /*PUE Changes start*/
    cell_wait_state_et current_state;
    /*PUE Changes end*/
            
    unsigned int PCI;

    bool mac_cell_reconfig_req_send;


    FrequencyInfoDL frequencyInfoDL;
            
    /* New sib structure added */
    ue_nr_sib_info_t ue_nr_sib_info;

     unsigned short  location_Bandwidth_dl;
     unsigned int    subcarrierSpacing;
     unsigned short  location_Bandwidth_ul;
    /*GQA-1173 Multi-Cell Changes Start*/
    unsigned short preambleIndex;
    /*GQA-1173 Multi-Cell Changes Stop*/
    unsigned int num_of_cfra_Preambles; 
}tc_cell_ctxt_t;

typedef struct
{
    /* Unique eNB Identifier */
    unsigned short enb_id;
#define SIM_NG_GNB   1
#define SIM_XN_GNB   0

    int             enb_type; 
    union {
        sim_activity_t *xn_activities;
        sim_activity_t *ng_activities;
    }u;

} enb_context_t;

/* Structure defining the context maintained for each test case. It
 * will store information used during test case execution. */
typedef struct _tc_context_t
{
    /* eNB Context */
    enb_context_t     enb_context[MAX_SUPPORTED_ENB];

    tc_cell_ctxt_t    cell_context[MAX_SUPPORTED_CELL];
   unsigned int FreqDomainAllocationRowOther; 
    unsigned int last_used_index;    

    unsigned int num_of_cells_configured;
    /*shourya_fix*/
    unsigned int old_imsi;
    /*shourya_fix*/

    unsigned char  ssb_index;
}tc_context_t;

/* For Key generation */
typedef struct
{
    UInt8 fc;
    UInt8 p0;
    UInt8 l0[2];
    UInt8 p1;
    UInt8 l1[2];
} rrc_key_s_t;

/* Object of test case context */
tc_context_t   tcContext;

int uesim_get_l2_ue_index(unsigned int imsi);
bool encode_imsi(imsi_t* imsi , unsigned int cellid ,unsigned int ueid );

bool allocate_new_imsi(unsigned char cell_index,unsigned int* imsi,sim_activity_t* p_activity_node);

void decode_imsi( unsigned int imsi,unsigned char *cell_index,unsigned short *ue_index );

/* This function deallocate imsi and return ue_context */
tc_ue_context_t*  get_ue_context(unsigned int imsi);
bool deallocate_imsi(unsigned int imsi);
bool is_amf_msg_node(sim_activity_t* p_activity_node);
unsigned short sim_get_rnti(unsigned int imsi);
bool allocate_new_cell(unsigned char *cell_idx);
unsigned int uesim_generate_te_id(unsigned int imsi, unsigned int pdu_session_id);
#endif
