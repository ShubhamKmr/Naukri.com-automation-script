#ifndef _F1AP_ASN_COMMON_H_
#define _F1AP_ASN_COMMON_H_

#define MAX_F1_CONN_RESET            256
#define MAX_CELL_PER_DU              8
#define MAX_MIB_LEN                  50
#define MAX_SIB1_LEN                 100
#define MAX_IE_IN_CRIT_DIAG_IE_LIST  8
#define MAX_DU_NAME_LENGTH           150
#define MAX_RRC_CONTAINER_SIZE       8192


typedef struct _f1ap_CriticalityDiagnostics_IE_Item 
{
    /* IE Criticality */
    unsigned int    iECriticality;

    /* IE ID */
    unsigned short  iE_ID;

    /* Type of Error */
    unsigned int    typeOfError;

} _f1ap_CriticalityDiagnostics_IE_Item;


/* Criticality Diagnostics IE List */
typedef struct _f1ap_CriticalityDiagnostics_IE_List
{
    /* IE count */
    unsigned int    ie_count;

    /* IE info */
    _f1ap_CriticalityDiagnostics_IE_Item
                    ie_info[MAX_IE_IN_CRIT_DIAG_IE_LIST];

} _f1ap_CriticalityDiagnostics_IE_List;


/* Criticality Diagnostics IE content */
typedef struct _f1ap_CriticalityDiagnostics
{
#define CRIT_DIAG_PROC_CODE_PRESENT        0x01
#define CRIT_DIAG_TRIGGERING_MSG_PRESENT   0x02
#define CRIT_DIAG_PROC_CRIT_PRESENT        0x04
#define CRIT_DIAG_IE_LIST_PRESENT          0x08

    unsigned int   bitmask;

    /* Procedure code */
    unsigned char  procedureCode;

    /* Triggering message */
    unsigned int   triggeringMessage;

    /* Procedure criticality */
    unsigned int   procedureCriticality;

    /* IEs list */
    _f1ap_CriticalityDiagnostics_IE_List 
                   iEsList;

} _f1ap_CriticalityDiagnostics;


/* Cause */
typedef struct _f1ap_Cause 
{
#define F1_CAUSE_RADIO_NETWORK    0
#define F1_CAUSE_TRANSPORT        1 
#define F1_CAUSE_PROTOCOL         2
#define F1_CAUSE_MISC             3

   /* Cause type */
   unsigned int     cause_type;

   union 
   {
      /* t = 0 */
      unsigned int  radioNetwork;

      /* t = 1 */
      unsigned int  transport;

      /* t = 2 */
      unsigned int  protocol;

      /* t = 3 */
      unsigned int  misc;
   } u;

} _f1ap_Cause;


/* NR Cell Identitiy */
typedef struct _f1ap_NRCellIdentity {
   unsigned int   numbits;
   unsigned char  data[5];
} _f1ap_NRCellIdentity;


/* PLMN Identity */
typedef struct _f1ap_PLMN_Identity {
   unsigned int   numocts;
   unsigned char  data[3];
} _f1ap_PLMN_Identity;


/* CGI for Served cell */
typedef struct _f1ap_NCGI 
{
    _f1ap_PLMN_Identity   pLMN_Identity;
    _f1ap_NRCellIdentity  nRCellIdentity;
} _f1ap_NCGI;


/* RRC Container */
typedef struct _f1ap_rrc_container {

    /* RRC Container length */
    unsigned int  rrcContainerLength;

    /* RRCContainer */
    unsigned char rrcContainer[MAX_RRC_CONTAINER_SIZE];

} _f1ap_RRCContainer;


#endif  // _F1AP_ASN_COMMON_H_
