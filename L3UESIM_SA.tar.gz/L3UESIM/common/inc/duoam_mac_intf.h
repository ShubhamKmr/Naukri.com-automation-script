/*******************************************************************************
 *
 * ARICENT -
 *
 * Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 *******************************************************************************
 *
 *   FILE NAME:   duoam_mac_intf.h
 *
 *   DESCRIPTION: Definitions for Interface between the MAC layer and
 *                DUOAM stack entity at DU.
 *
 *   DATE           REFERENCE       REASON
 *   18 June 2018   --------       Initial
 *
 *
 ******************************************************************************/

#ifndef _DUOAM_MAC_INTF_H_
#define _DUOAM_MAC_INTF_H_

/*******************************************************************************
 * Project Includes
 ******************************************************************************/
#include "gnb_defines.h"
#include "du_comm_intf_defn.h"
#include "cspl.h"
/*******************************************************************************
 * Exported Includes
 ******************************************************************************/

/*******************************************************************************
 * Exported Definitions
 ******************************************************************************/

/*******************************************************************************
 * Exported Types
 ******************************************************************************/
/* MAC DUOAM API Ids */
#define DUOAM_MAC_MESSAGE_API_START            (0x0000)
#define MAC_DUOAM_INIT_IND                     (DUOAM_MAC_MESSAGE_API_START + 0)
#define DUOAM_MAC_PROVISIONING_REQ             (DUOAM_MAC_MESSAGE_API_START + 1)
#define MAC_DUOAM_PROVISIONING_RESP            (DUOAM_MAC_MESSAGE_API_START + 2)
#define DUOAM_MAC_CLEANUP_REQ                  (DUOAM_MAC_MESSAGE_API_START + 3)
#define MAC_DUOAM_CLEANUP_RESP                 (DUOAM_MAC_MESSAGE_API_START + 4)
#define DUOAM_MAC_PROC_SUP_REQ                 (DUOAM_MAC_MESSAGE_API_START + 5)
#define MAC_DUOAM_PROC_SUP_RESP                (DUOAM_MAC_MESSAGE_API_START + 6)
#define DUOAM_MAC_SET_LOG_LEVEL_IND            (DUOAM_MAC_MESSAGE_API_START + 7)
#define DUOAM_MAC_GET_LOG_LEVEL_REQ            (DUOAM_MAC_MESSAGE_API_START + 8)
#define MAC_DUOAM_GET_LOG_LEVEL_RESP           (DUOAM_MAC_MESSAGE_API_START + 9)
#define DUOAM_MAC_ENABLE_LOG_CATEGORY_IND      (DUOAM_MAC_MESSAGE_API_START + 10)
#define DUOAM_MAC_DISABLE_LOG_CATEGORY_REQ     (DUOAM_MAC_MESSAGE_API_START + 11)
#define DUOAM_MAC_GET_LOG_CATEGORY_REQ         (DUOAM_MAC_MESSAGE_API_START + 12)
#define MAC_DUOAM_GET_LOG_CATEGORY_RESP        (DUOAM_MAC_MESSAGE_API_START + 13)
#define DUOAM_MAC_GET_DEBUG_INFO_REQ           (DUOAM_MAC_MESSAGE_API_START + 14)
#define MAC_DUOAM_GET_DEBUG_INFO_RESP          (DUOAM_MAC_MESSAGE_API_START + 15)
#define DUOAM_MAC_SCHEDULER_PARAMS_REQ         (DUOAM_MAC_MESSAGE_API_START + 16)
#define MAC_DUOAM_SCHEDULER_PARAMS_RESP        (DUOAM_MAC_MESSAGE_API_START + 17)
#define DUOAM_MAC_PRECODING_PARAMS_REQ         (DUOAM_MAC_MESSAGE_API_START + 18)
#define MAC_DUOAM_PRECODING_PARAMS_RESP        (DUOAM_MAC_MESSAGE_API_START + 19)
#define MAC_MAX_DUOAM_API                      (MAC_DUOAM_PRECODING_PARAMS_RESP)

/*******************************************************************************
 * Exported Constants
 ******************************************************************************/
typedef enum
{
    LC_GBR = 0,
    LC_NGBR
} logical_channel_type_et;

typedef enum
{
    CCE_AGGR_LEVEL_4 = 0,
    CCE_AGGR_LEVEL_8,
    CCE_AGGR_LEVEL_16
}cce_aggr_level_sib_et;
typedef UInt8 cce_aggr_level_sib_t;
typedef UInt8 cce_aggr_level_for_paging_t;

typedef enum
{
    TB_SCALING_ONE = 0,
    TB_SCALING_POINT_FIVE,
    TB_SCALING_ZERO_POINT_TWO_FIVE
}tb_scaling_et;
typedef UInt8 tb_scaling_t;
/*******************************************************************************
 * Exported Variables
 ******************************************************************************/

/*******************************************************************************
 * MAC_DUOAM_INIT_IND API - Mandatory parameters structure definition 
 ******************************************************************************/
/* No Payload Required */

/*******************************************************************************
 * DUOAM_MAC_PROVISIONING_REQ API - Mandatory parameters structure definition
 ******************************************************************************/
#define MAC_ADDR_LENGTH             6 
#define IF_NAMSIZ                16 
typedef struct _mac_phy_ethernet_comm_info_t
{
    UInt8                          phy_eth_add[MAC_ADDR_LENGTH];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8                          l2_eth_add[MAC_ADDR_LENGTH];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8                          l1_eth_dev_str_len;
    /*^ M, 0, H, 0, 16 ^*/
    SInt8                          l1_eth_dev_str[IF_NAMSIZ];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
}mac_phy_ethernet_comm_info_t;
typedef struct _mac_communication_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t              bitmask;
    /*^ BITMASK ^*/

    /* IP/Port used by MAC for communication with DU Mgr */
    mac_peer_comm_info_t   dumgr_comm_info;
    /*^ M, 0, N, 0, 0 ^*/

    /* IP/Port used by MAC for communication with RLC */
    mac_peer_comm_info_t   rlc_comm_info;
    /*^ M, 0, N, 0, 0 ^*/

    /*Ethernet Info used by MAC for RAW socket comunication with PHY*/
    mac_phy_ethernet_comm_info_t    phy_ethernet_comm_info;
    /*^ M, 0, N, 0, 0 ^*/
    
} mac_communication_info_t;


typedef struct _qos_qci_info_t
{
    /** Bitmask indicating presence of optional parameters **/
    bitmask_t                       bitmask; 
    /*^ BITMASK ^*/
    
    /* Quality class identifier */
    UInt8                           qci;
    /*^ M, 0, H, 0, 255 ^*/
    
    /* Indicates the priority of that logical channel */
    UInt8                           priority;
    /*^ M, 0, B, 1, 9 ^*/
    
    /* Indicates the packet expiry period of a QCI */
    UInt16                          pkt_delay_bdgt;
    /*^ M, 0, B, 50, 300 ^*/
   
    /* Indicates the type of resources required for a particular QCI */
    logical_channel_type_et         res_type;
    /*^ M, 0, H, 0, 1 ^*/
    
    /* Indicates the loss rate */
    UInt16                          pkt_err_loss_rate;
    /* M, 0, H, 0, 6 */

} qos_qci_info_t;
    

typedef struct _qos_qci_info_list_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t               bitmask;
    /*^ BITMASK ^*/

    /* Number of QCIs in the list, currently QCI 1-9 are supported */
    UInt16                   num_qci;
    /*^ M, 0, H, 0, MAX_QCI ^*/

    /* Information for a specific QCI */
    qos_qci_info_t         qosQciInfo[MAX_QCI];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} qos_qci_info_list_t;


typedef struct _system_params_t
{
    /* Bitmask indicating presence of optional parameters */
    bitmask_t                 bitmask; 
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG),
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG),
     * 64 (DETAILED ALL)
     * If a higher level log level set, lower values will also be set. For
     * example if ERROR is set then FATAL will also be enabled */
    UInt8                     log_level;
    /*^ M, 0, H, 0, 127 ^*/

    /* Indicates whether CA support is ON or not */
    UInt8                     ca_supported;
    /*^ M, 0, H, 0, 1 ^*/

    /* Indicates the thread model used at mac by every cell */
    UInt8                     mac_thread_model;
    /*^ M, 0, B, 0, 2 ^*/

    /* Indicates whether Buffer Occupancy and Tx Opportunity will be executed
     on primary cell or on another cell i.e. hosted cell */
    UInt8                     is_hosted_cell_enable;
    /*^ M, 0, B, 0, 1 ^*/

    /* Health monitoring time Interval for MAC */
    UInt16                    health_monitoring_time_interval;  
    /*^ M, 0, N, 0, 0 ^*/ 
        
    /* Log category which is enabled */
    UInt64                    log_category;
    /*^ M, 0, N, 0, 0 ^*/
    
    /* Contains the QCI table information used for each Data
     * logical channel configured at MAC */
    qos_qci_info_list_t       qos_qci_list;
    /*^ M, 0, N, 0, 0 ^*/

} system_params_t;


typedef struct _rlcl_system_params_t
{
    /* Bitmask indicating presence of optional parameters */
    bitmask_t                 bitmask; 
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG),
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG),
     * 64 (DETAILED ALL)
     * If a higher level log level set, lower values will also be set. For
     * example if ERROR is set then FATAL will also be enabled */
    UInt8                     log_level;
    /*^ M, 0, H, 0, 127 ^*/

    /* Log category which is enabled */
    UInt64                    log_category;
    /*^ M, 0, N, 0, 0 ^*/

    /* Core Number of Worker thread to bind */
    UInt8                     core_num_worker_thread;
    /*^ M, 0, N, 0, 0 ^*/
    
} rlcl_system_params_t;



typedef struct _duoam_mac_provisioning_req_t
{
    /* Bitmask indicating presence of optional parameters */
    bitmask_t           bitmask; 
    /*^ BITMASK ^*/
    
    /* Consisting of various IP/Ports used by MAC for communication
     * with RLC and DU Manager */
    mac_communication_info_t  communication_info; 
    /*^ M, 0, N, 0, 0 ^*/ 
    
    /* Global parameters applicable for all cells */
    system_params_t     mac_global_params; 
    /*^ M, 0, N, 0, 0 ^*/ 

    /* Global parameters applicable for all cells in RLCL */
    rlcl_system_params_t     rlc_lower_global_params; 
    /*^ M, 0, N, 0, 0 ^*/ 

    
} duoam_mac_provisioning_req_t; /*^ API, DUOAM_MAC_PROVISIONING_REQ ^*/


/*******************************************************************************
 * MAC_DUOAM_PROVISIONING_RESP API - Mandatory parameters structure definition
 ******************************************************************************/
typedef struct  _mac_duoam_provisioning_resp_t
{
#define MAC_PROV_FAIL_CAUSE_PRESENT    0x0001

    /* Bitmask indicating presence of optional parameters */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    /* Response of Provisioning request i.e. NR_SUCCESS/NR_FAILURE */
    UInt8               response;
    /*^ M, 0, H, 0, 1 ^*/ 

    /* Error code, in case of failure, indicating reason for failure */
    UInt16               cause;
    /*^ O, MAC_PROV_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/

} mac_duoam_provisioning_resp_t; /*^ API, MAC_DUOAM_PROVISIONING_RESP ^*/


/****************************************************************************
 * DUOAM_MAC_CLEANUP_REQ API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * MAC_DUOAM_CLEANUP_RESP
 ******************************************************************************/
typedef struct _mac_duoam_cleanup_resp_t
{
#define MAC_CLEANUP_FAIL_CAUSE_PRESENT  0x01

    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Response code */
    UInt8       response;
    /*^ M, 0, H, 0, 1 ^*/ 
    
    /* Error code, in case of failure, indicating reason for failure */
    UInt16      cause;
    /*^ O, MAC_CLEANUP_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/

} mac_duoam_cleanup_resp_t;    /*^ API, MAC_DUOAM_CLEANUP_RESP ^*/


/****************************************************************************
 * DUOAM_MAC_PROC_SUP_REQ API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/****************************************************************************
 * MAC_DUOAM_PROC_SUP_RESP API - Mandatory parameters structure definition 
 ****************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * DUOAM_MAC_SET_LOG_LEVEL_IND API 
 ******************************************************************************/
typedef struct _duoam_mac_set_log_level_ind_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG), 
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG), 
     * 64 (DETAILED ALL) */
    UInt8       log_level;
    /*^ M, 0, H, 0, 127 ^*/

} duoam_mac_set_log_level_ind_t;    /*^ API, DUOAM_MAC_SET_LOG_LEVEL_IND ^*/


/*******************************************************************************
 * DUOAM_MAC_GET_LOG_LEVEL_REQ API 
 ******************************************************************************/
/* No Payload Required */


/*******************************************************************************
 * MAC_DUOAM_GET_LOG_LEVEL_RESP API 
 ******************************************************************************/
typedef struct _mac_duoam_get_log_level_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG), 
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG), 
     * 64 (DETAILED ALL) */
    UInt8       log_level;
    /*^ M, 0, H, 0, 127 ^*/

} mac_duoam_get_log_level_resp_t;    /*^ API, MAC_DUOAM_GET_LOG_LEVEL_RESP ^*/


/*******************************************************************************
 *  DUOAM_MAC_ENABLE_LOG_CATEGORY_IND 
 ******************************************************************************/
typedef struct _duoam_mac_enable_log_category_ind_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask; 
    /*^ BITMASK ^*/

    UInt64      log_category;
    /*^ M, 0, N, 0, 0 ^*/

} duoam_mac_enable_log_category_ind_t;   /*^ API, DUOAM_MAC_ENABLE_LOG_CATEGORY_IND ^*/


/*******************************************************************************
 *  DUOAM_MAC_DISABLE_LOG_CATEGORY_REQ 
 ******************************************************************************/
typedef struct _duoam_mac_disable_log_category_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    UInt64      log_category;
    /*^ M, 0, N, 0, 0 ^*/ 
    
} duoam_mac_disable_log_category_req_t;   /*^ API, DUOAM_MAC_DISABLE_LOG_CATEGORY_REQ ^*/


/****************************************************************************
 * DUOAM_MAC_GET_LOG_CATEGORY_REQ API 
 ****************************************************************************/
/* No Payload Required */
    

/****************************************************************************
 * MAC_DUOAM_GET_LOG_CATEGORY_RESP API 
 ****************************************************************************/
typedef struct _mac_duoam_get_log_category_resp_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask; 
    /*^ BITMASK ^*/

    UInt64     log_category;
    /*^ M, 0, N, 0, 0 ^*/

} mac_duoam_get_log_category_resp_t;   /*^ API, MAC_DUOAM_GET_LOG_CATEGORY_RESP ^*/


/*******************************************************************************
 * DUOAM_MAC_GET_DEBUG_INFO_REQ
 ******************************************************************************/
typedef struct _duoam_mac_get_debug_info_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_u32_t             bitmask;
    /*^ BITMASK ^*/

    /* This field informs the type of debugging information needed */
    /* Check Enum DebugInfoType */
    UInt32                    debugInfoType; 
    /*^ M, 0, H, 0, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_MAX_CTRS^*/

    UInt8                     reset_flag; 
    /*^ M, 0, N, 0, 0 ^*/

} duoam_mac_get_debug_info_req_t;  /*^ API, DUOAM_MAC_GET_DEBUG_INFO_REQ ^*/


/*******************************************************************************
 * MAC_DUOAM_GET_DEBUG_INFO_RESP
 ******************************************************************************/
typedef struct _mac_pool_stats_t 
{
    /* Size of the buffer allocated in this pool */
    UInt32  bufSize; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Total number of Buffers in this pool */
    UInt32  numOfBuf; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Total number of Buffers allocated from this pool */
    UInt32  numOfAllocBuf; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Peak of Total number of Buffers allocated from
     * this pool during the system is running */
    UInt32  numOfPeakBuf; 
    /*^ M, 0, N, 0, 0 ^*/

} mac_pool_stats_t;

/* This structure provides the MEM POOL stats */
typedef struct _l2_mem_pool_stats_t 
{
    /* Stats for each pool */
    mac_pool_stats_t   stats[NVARPOOL]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} mac_mem_pool_stats_t;


/* This structure provides the MSG POOL stats */
typedef struct _l2_msg_pool_stats_t 
{
    /* Stats for each pool */
    mac_pool_stats_t   stats[NVARPOOL]; 
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    /* QPCTL stats */
    mac_pool_stats_t   qpctlStats; 
    /*^ M, 0, N, 0, 0 ^*/

    /* QMSG stats */
    mac_pool_stats_t   qmsgStats; 
    /*^ M, 0, N, 0, 0 ^*/

} mac_msg_pool_stats_t;

typedef struct _mac_cell_setup_debug_counters_t 
{
    UInt32 total_dumgr_mac_config_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_config_resp_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_config_resp_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_dumgr_mac_start_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_phy_config_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_phy_mac_config_resp_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_phy_mac_config_resp_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_phy_start_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_phy_mac_start_resp_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_phy_mac_start_resp_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_start_resp_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_start_resp_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 send_mac_dumgr_config_resp_fails;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 send_mac_phy_config_req_fails;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 send_mac_phy_start_req_fails;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 send_mac_dumgr_start_resp_fails;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_config_req_nacks;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_config_req_acks;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_start_req_nacks;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_mac_dumgr_start_req_acks;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 first_sfn_received;
    /*^ M, 0, N, 0, 0 ^*/

} mac_cell_setup_debug_counters_t;

typedef struct _mac_duoam_if_debug_counters_t
{
    UInt32    parse_fail_prov_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_sched_param_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_set_log_level_ind;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_enable_log_category_ind;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    send_fail_prov_resp;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    send_fail_sched_param_resp;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    send_fail_get_log_level_resp;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    send_fail_get_log_category_resp;
    /*^ M, 0, N, 0, 0 ^*/

} mac_duoam_if_debug_counters_t;

typedef struct _mcs_threshold_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/

    UInt8                      MCSThreshold64QAM2x2;
   /*^ M, 0, H, 1, 28 ^*/

    UInt8                      MCSThreshold64QAM4x4[NR_QI_THRESHOLD4_4];
   /*^ M, 0, OCTET_STRING, FIXED ^*/

    UInt8                      MCSThreshold64QAM8x8[NR_QI_THRESHOLD8_8];
   /*^ M, 0, OCTET_STRING, FIXED ^*/

    UInt8                      MCSThreshold256QAM2x2;
   /*^ M, 0, H, 1, 27 ^*/

    UInt8                      MCSThreshold256QAM4x4[NR_QI_THRESHOLD4_4];
   /*^ M, 0, OCTET_STRING, FIXED ^*/

    UInt8                      MCSThreshold256QAM8x8[NR_QI_THRESHOLD8_8];
   /*^ M, 0, OCTET_STRING, FIXED ^*/
}mcs_threshold_info_t;

typedef struct _mac_dumgr_if_debug_counters_t
{
    UInt32    parse_fail_cell_config_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_cell_start_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_cell_stop_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    parse_fail_cell_delete_req;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_duplex_mode;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_scs;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_trans_period;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_slot;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_symbols;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_ssburst_type;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_ssburst_slot;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_ssb_freq;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32    cell_conf_invalid_ssb_range;
    /*^ M, 0, N, 0, 0 ^*/

} mac_dumgr_if_debug_counters_t;

typedef struct _mac_rach_debug_counters_t
{
    UInt32 tot_rach_ignored_phy_delay;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_incorr_pream_info_recvd;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_below_min_power;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_invalid_ssb;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_duplicate_rach;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_handled_cfra;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_others;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_invalid_pream_type;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cfra_pream_status_mismatch_is_free;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cfra_pream_status_mismatch_is_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cfra_pream_already_recvd;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_no_valid_slot_sfn_rar;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 no_valid_slot_rar_within_window_for_all;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_fail_rar_window_exp;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_pending_ue_del_flag_set_cfra_check;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_no_ul_ue_ctx_cfra_check;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_no_dl_ue_ctx_cfra_check;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_duplicate_rach_from_cfra_queue;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_no_valid_slot_sfn_msg3;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_invalid_harq_id;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_err_not_free_harq_id;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_fail_ul_allocation;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_fail_pdcch;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_fail_pdsch;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_msg3_crc_ack;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_msg3_crc_nack;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_msg3_max_retx_reached;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_ul_48_bit_ccch_decode_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_ul_48_bit_ccch_decode_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cb_rach_fail_ul_allocation;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_cce_alloc_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_cce_alloc_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_pdsch_alloc_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_pdsch_alloc_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_interface_queue_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_interface_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_invalid_rnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_stop_create_ue_list_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_create_ue_list_rnti_not_found;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rnti_info_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_failed_free_rnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_freeIdxNode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_pushNode_free_rnti_queue_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rnti_failed_before_temp_ue_contx;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_preamble_index_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_free_preamble_unavailable_ssb;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_preamble_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_preamble_invalid_msg3_reception;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_dumgr_ue_sync_ind_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_demux_qnode_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_invalid_demux_msg_type;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_contention_ack_qnode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_contention_timer_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_contention_timer_queue_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_tcrnti_ctxt_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_failed_free_tcrnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_create_ue_list_timer_expired;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_failure_getting_ueindex_rnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_invalid_slot_rar;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rar_pdu_schdl_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_ra_req_qnode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rar_neg_qnode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_neg_ack_send_ul_ra_rnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_return_default_sinr_value;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_current_tti_lower_rar_window;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_tx_tti_lower_rar_window;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rar_pdu_not_found;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_dumgr_ue_sync_ind_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_invalid_preamble_indx;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 prach_slot_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_mem_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 prach_rb_alloc_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rar_cleanup_quenode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_mem_unavailable_for_tcrnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_incorr_pream_info_recv;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_ignored_inval_ssb;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_handle_cfra;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cfra_pream_status_mismatch_free;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_cfra_pream_status_mismatch_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_err_not_free_harq_ids;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 tot_rach_fail_ul_alloca;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_cce_allocation_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 total_cri_cce_allocate_success;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_invalid_rnti_range;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rnti_info_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_failed_free_rnti_nsa;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_rnti_fail_bef_temp_ue_cntx;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_preamble_indx_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_neg_rar_qnode_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_mem_allocate_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 rach_recv_prb_set_one_null;
    /*^ M, 0, N, 0, 0 ^*/
} mac_rach_debug_counters_t;

typedef struct _mac_demux_debug_counters_t
{
    UInt32 demux_mem_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_queue_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rnti_info_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_ue_cntxt_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_msg_sgnxt_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_data_seg_zero;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rem_payload_len_zero;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_single_pwr_rem_payload_len_zero;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rem_payload_len_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_crnti_decoding_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_bsr_rem_payload_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_bsr_decoding_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_long_bsr_rem_payload_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_l_bsr_decoding_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rach_qnode; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rach_manager_interface_q;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_bsr_qnode;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_zero_non_zero_bsr_trigger_queue_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_payload_length_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_padding_lch_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_invalid_lcid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_ue_index_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_mac_ue_data_indication_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_lc_id_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_rnti_infor_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 demux_ue_cntx_null;
    /*^ M, 0, N, 0, 0 ^*/

} mac_demux_debug_counters_t;

typedef struct _mac_receiver_debug_counters_t 
{
    UInt32 crc_phy_delay_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_phy_delay_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_phy_delay_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 sr_phy_delay_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 sr_rnti_info_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 sr_pending_del_flag_true;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 sr_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 sr_alloc_mem_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 csi_phy_delay_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 csi_alloc_mem_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 csi_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 invalid_ul_pdu_recvd;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_rnti_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_pending_del_flag_true;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_invalid_ue_idx;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_nack_handling_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_harq_process_free;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_harq_timer_stop_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_ue_cntxt_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_invalid_ta_value;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 crc_harq_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulcsi_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulcsi_rnti_info_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_rnti_info_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_ul_cntxt_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_ue_cntxt_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_harq_id_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_sinr_mem_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_sinr_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulsch_tcrnti_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_rnti_info_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_pending_del_flag;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_ue_cntxt_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_process_id_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_process_free;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_timer_not_started;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_free;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_timer_stop_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_retx_push_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_nack_mem_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_dai_reset_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_timer_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_mem_alloc_retx_node_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_timer_start_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_push_node_retx_queue_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_mem_alloc_retx_node_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_push_node_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ulharq_ue_deleted;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 receiver_ulsch_data_len_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_rnti_info_empty; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dlharq_dai_reset_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 receiver_ulsch_data_leng_null;
    /*^ M, 0, N, 0, 0 ^*/

} mac_receiver_debug_counters_t;

typedef struct _mac_pdcch_debug_counters_t 
{

    UInt32  pdcch_ra_resp_q_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_ra_resp_tti_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_re_tx_strategy_q_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_re_tx_pending_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_re_tx_alloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_new_tx_strategy_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_new_tx_pending_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_new_tx_alloc_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_ta_q_entry_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_ra_resp_q_node_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  pdcch_re_tx_pend_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

} mac_pdcch_debug_counters_t;

typedef struct _mac_pdsch_debug_counters_t 
{
    UInt32 pdsch_ccch_k0_unavail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_invalid_sliv_comb ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_invalid_dl_slot ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_dmrs_invalid_mapp_type ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_dmrs_overlapping_sym ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_boundary_check_failed ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_rb_unavail_coreset ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_coreset_boundary_check_failed ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_coreset_rbs_unavail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_phy_virt_start_rb_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_ccch_valid_ko_unavail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_cri_k0_unavail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_cri_dmrs_failure ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_cri_invalid_mapp ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_cri_rb_alloc_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_pending_flag_true ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tb1_invalid ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_k0_invalid ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_another_k0_not_avail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_dmrs_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_invalid_mapp ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_dmrs_err ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_incorr_dci_format ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_invalid_tx_type ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_incorr_numero ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_mux_node_null ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_re_tx_encoder_entry_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_rb_alloc_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_tx_sliv_alloc_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_new_tx_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_new_tx_ta_entry_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_re_tx_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_invalid_tx_type ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_resv_prb_set_one_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_resv_prb_set_two_null;
    /*^ M, 0, N, 0, 0 ^*/

} mac_pdsch_debug_counters_t;

typedef struct _mac_pusch_debug_counters_t 
{
    UInt32 pusch_rar_tti_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_tick_elapsed_ul_alloc; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_alloc_table_type_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_res_alloc_table_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_min_k2_exceeds_max_ul; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_sliv_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_invalid_ul_slot; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_invalid_k2_table_idx; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_dmrs_mapping_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_ul_harq_process_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_res_alloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_invalid_res_alloc_type; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_required_rb_unavailable; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_node_ue_indx_absent_non_zero_list; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_rb_alloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_codebook_transmission_not_supported; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_confg_grant_not_supported; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_invalid_grant_type; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_ul_harq_timer_start_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_min_k2_exceeds_max_ul_value;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_sliv_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pusch_req_rb_unavail;
    /*^ M, 0, N, 0, 0 ^*/

} mac_pusch_debug_counters_t;

typedef struct _mac_pucch_debug_counters_t 
{
    UInt32 pucch_ulsch_pdu_fail ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_unsupported_pucch_type ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pucchFmtInd_invalid ; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_ulsch_uci_rach_container_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_list_node_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_format_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_rb_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_incorrect_sr_conf_recv_dumgr;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_failed_mark_rb;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_perodic_long_report_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_resource_format2_not_conf;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_resource_conf_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_format2_resource_alloc_other_ue;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_mem_alloc_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 alloc_pucch_resource_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_invalid_ul_slot;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_invalid_ul_slot_offset;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 prepare_pucch_harq_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 dci_pdsch_info_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_rb_reserve_first_hop_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_uci_harq_container_failed ;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_rb_reserve_second_hop_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_resources_ccch_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_harq_prep_ccch_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_invalid_msg_type;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_one;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_two;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_three;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_four;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_five;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_six;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_pdu_type_invalid_seven;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_format_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_rb_allocate_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_fail_mark_rb;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_res_conf_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_resource_config_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_mem_allocate_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_inval_ul_slot_offset;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pucch_resv_prb_set_null;
    /*^ M, 0, N, 0, 0 ^*/

} mac_pucch_debug_counters_t;


typedef struct _mac_mux_debug_counters_t
{
    UInt32 mux_dl_data_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_ue_oppor_ind_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_lc_id_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_num_lc_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_ta_value_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_multipex_tbsize_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_single_tb_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_tb1_size_less_min_sdu; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_mem_rlc_data_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_tb2_size_less_min_sdu; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_failure_single_tb_distri; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_no_valid_tb; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_unable_to_multiplex_data; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_failure_dual_tb_dist; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_node_processing_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_single_tb_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 mux_single_tb_dist_failed;
    /*^ M, 0, N, 0, 0 ^*/

} mac_mux_debug_counters_t;

typedef struct _mac_encoder_debug_counters_t 
{
    UInt32  encoder_insufficient_mem_queue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_create_tb_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_lc_count_zero; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_ta_scheduled_flag_false; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_rlc_data_empty; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_msg_insert_failure; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_pushnode_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_harq_processid_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_tb_enncoding_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_failure_processing_encoder_node; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_tti_current_tti_break; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_node_not_given_tti; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_tb_two_and_one_both_valid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_msg_insert_failure_ce; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_invalid_ta_mac_ce; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_invalid_msg_type_ce; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_create_br_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_tb_notvalid_create_mac_ce; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_failure_create_tb_for_ta; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_tb1_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_failure_process_mac_ce_tx; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_failure_process_re_tx; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_ue_pending_delete; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_ue_context_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_node_BO_queue_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_pending_delete_flag; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_ue_context_null_BO_queue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  encoder_enqueue_dl_ue_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 encoder_create_tb_fail_ue;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 encoder_ta_schd_flag_false;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 encoder_msg_insrt_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 encoder_rlc_pushnode_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 encoder_msg_insrt_fail_ce;
    /*^ M, 0, N, 0, 0 ^*/

} mac_encoder_debug_counters_t;

typedef struct _mac_tx_debug_counters_t 
{
    UInt32  tx_send_msg_to_module_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_invalid_dl_data_or_tb1; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_dci_format_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_pos_mem_aloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_data_mem_aloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_harq_process_id_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_dci_format_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_pos_mem_aloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_data_mem_aloc_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_msg_type_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_dci_dlsch_info_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ul_mem_failure; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ul_dci0_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_data_tb1_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_data_tb2_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_data_ptr_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_tb1_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_send_msg_to_module_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_send_msg_to_phy_fail;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_dci_frmt_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_harq_prcs_id_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_dci_frmt_inval;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32  tx_ccch_mssg_type_inval;
    /*^ M, 0, N, 0, 0 ^*/

} mac_tx_debug_counters_t;

typedef struct _mac_strategy_debug_counters_t 
{
    UInt32 strategy_ul_retx_pushnode_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_sr_pending_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_sr_periodicty_exceed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_sr_harq_not_free; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_sr_grant_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_sr_node_entry_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_sr_rbs_not_avail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_sr_ue_cntxt_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_sr_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_no_active_ue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_ue_to_schedule_zero; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_non_zero_bsr_list_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_ue_cntxt_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_pending_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_ul_ue_cntxt_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_rach_not_triggered; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_bsr_not_avail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_harq_not_free; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_harq_busy; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_harq_process_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_harq_cntxt_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_ue_validation_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_rb_unavail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_send_node_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_ul_rr_used_rb_bytes_zero; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_retx_pushnode_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_retx_node_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_retx_pending_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_already_for_scheduling_flag; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_harq_status_or_dci_format_inc; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_node_invalid_for_retx; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_retx_node_temp_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_pop_retx_node_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_node_absent_for_ue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_tx_node_entry_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_pop_push_re_tx_ccch_q_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_retx_tb_wrong; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_scheduler_re_tx_queue_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rb_not_assigned_to_ue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ue_context_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ue_absent_non_zero_queue; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_pushnode_failed_ta_q; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_freeing_ta_node_from_fail_q; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_insuf_rb_for_stra_node; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_node_not_pushed_in_dl_sc; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_freeing_failure_ta_node; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ue_cntx_null_or_fail_pending; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ta_node_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_tb_size_or_rb_unavailable; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_non_zero_queue_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ue_index_invalid; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 trategy_dl_ue_context_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_rach_not_triggered; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_ue_queueload_zero; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_invalid_harq_id; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_harq_process_returned_null; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rb_unavailable; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_put_entry_new_tx_fail; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_tx_node_failed; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_rb_unavailable; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_rr_pending_delete_flag_true; 
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_re_tx_pushnode_failed;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_node_absnt_for_ue;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_ue_context_null_ta;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_zero_non_zero_ue_ctx_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_pushnode_fail_ta_q_one;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 strategy_dl_pushnode_fail_ta_q_two;
    /*^ M, 0, N, 0, 0 ^*/

}mac_strategy_debug_counters_t;

typedef struct _mac_harq_debug_counters_t
{
    UInt32 harq_process_id_invalid;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ue_idx_from_rnti_map_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 temp_crnti_context_ptr_null;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 harq_timer_not_started_for_tcrnti;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 invalid_ul_harq_process_id;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 ul_harq_timer_not_started_for_ue_index;
    /*^ M, 0, N, 0, 0 ^*/

}mac_harq_debug_counters_t;
/* This structure provides the MEM POOL stats */
typedef struct _mac_duoam_get_debug_info_resp_t
{
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MEM_POOL_STATS_PRESENT      0x00000001
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MSG_POOL_STATS_PRESENT      0x00000002
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_CELL_SETUP_CTRS_PRESENT 0x00000004
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DUOAM_CTRS_PRESENT      0x00000008
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DUMGR_CTRS_PRESENT      0x00000010 
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_RACH_CTRS_PRESENT       0x00000020
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_RECEIVER_CTRS_PRESENT   0x00000040
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DEMUX_CTRS_PRESENT      0x00000080
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PDCCH_CTRS_PRESENT      0x00000100
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PDSCH_CTRS_PRESENT      0x00000200
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PUSCH_CTRS_PRESENT      0x00000400
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PUCCH_CTRS_PRESENT      0x00000800  
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_MUX_CTRS_PRESENT        0x00001000   
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_ENCODER_CTRS_PRESENT    0x00002000
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_TX_CTRS_PRESENT         0x00004000
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_STRATEGY_CTRS_PRESENT   0x00008000
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_HARQ_CTRS_PRESENT       0x00010000
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_ALL_CTRS_PRESENT        0x0001FFFF
#define MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_MAX_CTRS                0xFFFFFFFF

    /* Bitmask indicating the presence of optional fields */
    bitmask_u32_t                   bitmask;
    /*^ BITMASK ^*/
    
    /*number of ticks elapsed since last reset*/
    UInt64 num_ticks; 
    /*^ M, 0, N, 0, 0 ^*/

    /* Memory Pool Stats */
    mac_mem_pool_stats_t            csplMemPoolStats;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MEM_POOL_STATS_PRESENT, N, 0, 0  ^*/

    /* Message Pool Stats */
    mac_msg_pool_stats_t            csplMsgPoolStats;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MSG_POOL_STATS_PRESENT, N, 0, 0  ^*/

    /* MAC cell setup counters*/ 
    mac_cell_setup_debug_counters_t cell_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_CELL_SETUP_CTRS_PRESENT, N, 0, 0  ^*/

    /* Structure defining the Global Counters for DUOAM Interface. */
    mac_duoam_if_debug_counters_t  mac_duoam_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DUOAM_CTRS_PRESENT, N, 0, 0  ^*/

    /* Structure defining the Global Counters for DUMGR Interface. */
    mac_dumgr_if_debug_counters_t  mac_dumgr_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DUMGR_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for RACH */
    mac_rach_debug_counters_t mac_rach_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_RACH_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for receiver */
    mac_receiver_debug_counters_t mac_receiver_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_RECEIVER_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for demux */
    mac_demux_debug_counters_t mac_demux_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_DEMUX_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for pdcch */
    mac_pdcch_debug_counters_t mac_pdcch_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PDCCH_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for pdsch*/
    mac_pdsch_debug_counters_t mac_pdsch_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PDSCH_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for pusch */
    mac_pusch_debug_counters_t mac_pusch_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PUSCH_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for pucch */
    mac_pucch_debug_counters_t mac_pucch_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_PUCCH_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for multiplexer */
    mac_mux_debug_counters_t  mac_mux_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_MUX_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for encoder */
    mac_encoder_debug_counters_t mac_encoder_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_ENCODER_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for transmitter */
    mac_tx_debug_counters_t mac_tx_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_TX_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for strategy*/
    mac_strategy_debug_counters_t mac_strategy_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_STRATEGY_CTRS_PRESENT, N, 0, 0  ^*/

    /*Structure defining the global counters for harq*/
    mac_harq_debug_counters_t mac_harq_counters;
    /*^ O, MAC_DUOAM_GET_DEBUG_INFO_RESP_MAC_HARQ_CTRS_PRESENT, N, 0, 0  ^*/

} mac_duoam_get_debug_info_resp_t;  /*^ API, MAC_DUOAM_GET_DEBUG_INFO_RESP ^*/

/**************************************************************************
 * DUOAM_MAC_SCHEDULER_PARAMS_REQ
 *************************************************************************/
typedef struct _system_info_params_t
{
#define CCE_AGGR_LEVEL_SIB_PRESENT 0x0001

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    
    /* To Signify the CCE Aggregation level configured for SIB  */  
    cce_aggr_level_sib_t     cce_aggr_level_sib;
    /*^ O, CCE_AGGR_LEVEL_SIB_PRESENT, N, 0, 0 ^*/

    /* Log Level
     * Valid values = 0 (NOT USED), 1 (FATAL LOG), 2 (ERROR LOG),
     * 4 (WARNING LOG), 8 (INFO LOG), 16 (BRIEF LOG), 32 (DETAILED LOG),
     * 64 (DETAILED ALL)
     * If a higher level log level set, lower values will also be set. For
     * example if ERROR is set then FATAL will also be enabled */
    UInt8                     log_level;
    /*^ M, 0, H, 0, 127 ^*/

    /* Signifies the minimum and the maximum mcs Index value to be used for SIB1 */
    mcs_index_sib1_t         mcs_index_sib1;
    /*^ M, 0, N, 0, 0 ^*/

    /* Signifies the vrb to prb mapping for SIB1 */
    UInt8     vrb_to_prb_mapping_sib1;
    /*^ M, 0, H, 0, 1 ^*/

    /* Signifies the sib1 transmission in n0 and n1 slot */
    UInt8     slot_transmission_n0_n1_sib1;
    /*^ M, 0, H, 0, 2 ^*/

    /* Signifies the PDSCH Mapping Type to be supported for SIB1 */
    UInt8     pdsch_mapping_type_sib1;
    /*^ M, 0, H, 0, 3 ^*/

    UInt32 pdcch_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    UInt32 pdcch_dmrs_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    UInt32 pdsch_power_offset;
    /*^ M, 0, H, 0, 10000 ^*/
        
    /* Log category which is enabled */
    UInt64                    log_category;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32 pdsch_dmrs_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    UInt8  scheduling_period;
    /*^ M, O, H, 1, 8 ^*/

}system_info_params_t;

typedef struct _rach_info_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/
    
    /* SINR threshold to be considered whether to drop the RACH preamble */
    UInt8                    rach_sinr_threshold;
    /*^ M, 0, H, 0, 255 ^*/

    /* Transport block size in bytes for Contention free uplink grant. Default value is configured to 7 */
    UInt8                    cfra_grant_bytes;
    /*^ M, 0, B, 5, 25 ^*/    

    /* Maximum harq retransmission for msg3 */
    UInt8                    msg3_max_harq_retx;
    /*^ M, 0, B, 1, 16 ^*/

    /* Maximum harq retransmission for msg4 */
    UInt8                    msg4_max_harq_retx;
    /*^ M, 0, H, 0, 6 ^*/

    /* Indicates whether frequency hopping is enabled or disabled for msg3 */
    UInt8                      msg3_freq_hop;
    /*^ M, 0, H, 0, 1 ^*/
   
    /* Signifies the vrb to prb mapping for RAR and MSG4 till UE context creation for CBRA */
    UInt8                     vrb_to_prb_mapping_for_rar_msg4;
    /*^ M, 0, H, 0, 1 ^*/

    /* count of the configured RACH Sinr and Aggregation table */
    UInt8                     count;
    /*^ M, 0, B, 1, MAX_SINR_AL_MCS_ROW_COUNT ^*/

    /* Table for selection of aggregation level and MCS index based on RACH SINR threshold levels */
    sinr_aggr_lvl_mcs_selection_t   sinr_aggr_lvl_mcs_array[MAX_SINR_AL_MCS_ROW_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}rach_info_params_t;
typedef struct _olpc_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /* Indicates if periodic reporting is enabled or not*/
    UInt8   periodic_reporting_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /* Default value is 820. Corresponds to ratio 80:20 */
    UInt16   time_avg_coeff_iir_olpc;
    /*^ M, 0, H, 0, 1024 ^*/
    /* (100-5000)ms, in steps of 100ms *
    * Default value is 100ms. */
    UInt32  report_periodicity;
    /*^ M, 0, B, 100, 5000 ^*/
    /*Minimum reports for calculating SINR average 
     * in reporting periodicity for sending particular stats to DuMgr. */
    UInt8   min_reports;
    /*^ M, 0, B, 1, 100 ^*/
    /* (5-25), in steps of 5 */
    UInt8   ue_batch_size;
    /*^ M, 0, B, 5, 25 ^*/
}olpc_config_t;

/*19.4.19*/
typedef struct _delta_sinr_to_tpc_map_pucch_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Start delta sinr value */
    SInt16 start_delta_sinr;
    /*^ M, 0, B, -255, 255 ^*/
    /*End delta sinr value*/
    SInt16 end_delta_sinr;
    /*^ M, 0, B, -255, 255 ^*/
    /*Tpc command for the sinr range */
    SInt8 pucch_tpc;
    /*^ M, 0, B, -1, 3 ^*/
}delta_sinr_to_tpc_map_pucch_info_t;

typedef struct _delta_bler_to_tpc_map_pucch_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Start bler value*/
    SInt16 start_bler;
    /*^ M, 0, B, -100, 100 ^*/
    /*End bler value*/
    SInt16 end_bler;
    /*^ M, 0, B, -100, 100 ^*/
    /*Tpc command for the Bler range*/
    SInt8 pucch_tpc;
    /*^ M, 0, B, -1, 3 ^*/
}delta_bler_to_tpc_map_pucch_info_t;

typedef struct _delta_sinr_to_tpc_map_pusch_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Start delta sinr value */
    SInt16  start_delta_sinr;
    /*^ M, 0, B, -255, 255 ^*/
    /*End delta sinr value */
    SInt16 end_delta_sinr;
    /*^ M, 0, B, -255, 255 ^*/
    /*Tpc command for the sinr range */
    SInt8 pusch_tpc;
    /*^ M, 0, B, -4, 4 ^*/
}delta_sinr_to_tpc_map_pusch_info_t;

typedef struct _delta_sinr_to_tpc_map_pucch_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*CLPC PUCCH target sinr to decide TPC commands.
    *0 - 255, representing -64dBm to 63.5dBm in steps of 0.5*/
    UInt8 pucch_target_sinr;
    /*^ M, 0, H, 0, 255 ^*/
    /*Delta sinr to tpc command table count. */
    UInt8 count;
    /*^ M, 0, B, 1, MAX_NUM_DELTA_SINR_TO_TPC_MAP_COUNT ^*/
    /*Delta SINR to PUCCH TPC command mapping table. The Delta Sinr 
    *range should be configured in increasing order and the one entry 
    *in the table should not be overlapping with other entries in the table. */
    delta_sinr_to_tpc_map_pucch_info_t delta_sinr_to_tpc_map_pucch_info[MAX_NUM_DELTA_SINR_TO_TPC_MAP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}delta_sinr_to_tpc_map_pucch_t;

typedef struct _delta_bler_to_tpc_map_pucch_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*CLPC PUCCH target bler to decide TPC commands.
    *0 – 100, Default value 10. */
    UInt8 pucch_target_bler;
    /*^ M, 0, H, 0, 100 ^*/
    /*Delta sinr to tpc command table count. */
    UInt8 Count;
    /*^ M, 0, B, 1, MAX_NUM_DELTA_BLER_TO_TPC_MAP_COUNT ^*/
    /*Delta Bler to PUCCH TPC command mapping table. The Delta Bler range should 
    *be configured in increasing order and the one entry in the table should not 
    *be overlapping with other entries in the table */
    delta_bler_to_tpc_map_pucch_info_t delta_bler_to_tpc_map_pucch_info[MAX_NUM_DELTA_BLER_TO_TPC_MAP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}delta_bler_to_tpc_map_pucch_t;

typedef struct _pathloss_to_target_sinr_map_info_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*PL start range for this quadrant */
    UInt8 start_path_loss;
    /*^ M, 0, H, 0, 255 ^*/
    /*PL end range for this quadrant. */
    UInt8 end_path_loss;
    /*^ M, 0, H, 0, 255 ^*/
    /*CLPC PUSCH target sinr to decide TPC commands.
    *0 - 255, representing -64dBm to 63.5dBm in steps of 0.5*/
    UInt8 target_sinr;
    /*^ M, 0, H, 0, 255 ^*/
}pathloss_to_target_sinr_map_info_t;

typedef struct _atb_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Minimum MCS */
    UInt8 min_mcs_for_atb;
    /*^ M, 0, H, 0, 28 ^*/
    /*Minimum prb. RB range is based on the Carrier Bandwidth. */
    UInt16 min_prb_for_atb;
    /*^ M, 0, H, 0, 273 ^*/
}atb_config_t;

typedef struct _delta_sinr_to_tpc_map_pusch_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Delta sinr to tpc command table count. */
    UInt8 count;
    /*^ M, 0, B, 1, MAX_NUM_DELTA_SINR_TO_TPC_MAP_COUNT ^*/
    /*Delta SINR to PUSCH TPC command mapping table. The Delta Sinr 
    *range should be configured in increasing order and the one entry 
    *in the table should not be overlapping with other entries in the table. */
    delta_sinr_to_tpc_map_pusch_info_t delta_sinr_to_tpc_map_pusch_info[MAX_NUM_DELTA_SINR_TO_TPC_MAP_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}delta_sinr_to_tpc_map_pusch_t;

typedef struct _pathloss_to_target_sinr_map_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Pathloss to target SINR table count.*/
    UInt8 count;
    /*^ M, 0, B, 1, MAX_NUM_PATHLOSS_TO_SINR_COUNT^*/
    /*Pathloss to target SINR mapping table. The PL range should be 
    *configured in increasing order and the one entry in the table should 
    *not be overlapping with other entries in the table. */
    pathloss_to_target_sinr_map_info_t pathloss_to_target_sinr_map_info[MAX_NUM_PATHLOSS_TO_SINR_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}pathloss_to_target_sinr_map_t;

typedef struct _alpha_based_pathloss_to_target_sinr_map_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Default path loss value of UE before PHR reports */
    UInt8 default_path_loss;
    /*^ M, 0, H, 0, 255 ^*/
    /*Pathloss to target SINR mapping table for each Alpha value. 
    *Shall be configured in ascending order of alpha values 
    *0, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1 */
    pathloss_to_target_sinr_map_t pathloss_to_target_sinr_map[MAX_NUM_ALPHA];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
}alpha_based_pathloss_to_target_sinr_map_t;

typedef struct _clpc_pusch_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Interval between the last time TPC was applied for PUSCH 
    *Power control and the new TPC triggered due to wideband power control. */
    UInt8   cool_off_period_for_pusch_tpc;
    /*^ M, 0, H, 0, 255 ^*/
    /*In steps of 10 Default value is 820. */
    UInt16 time_avg_coeff_iir_pusch_clpc;
    /*^ M, 0, H, 0, 1024 ^*/
    /*Alpha based Pathloss to Target SINR config table. */
    alpha_based_pathloss_to_target_sinr_map_t alpha_pathloss_to_target_sinr_map;
    /*^ M, 0, N, 0, 0 ^*/
    /*Delta Sinr to PUSCH TPC map table. */
    delta_sinr_to_tpc_map_pusch_t delta_sinr_to_tpc_map_pusch;
    /*^ M, 0, N, 0, 0 ^*/
    /*ATB Configuration parameters*/
    atb_config_t atb_config;
    /*^ M, 0, N, 0, 0 ^*/
    /*In tpc accumulation mode, if the received PUSCH Sinr threshold in case 
    *of CRC Error is lower than back off threshold the previously applied 
    *TPC command is backed-off from the “fi” value Since in accumulation 
    *mode there is no way to check if UE has applied the TPC command or Not 
    *in case of CRC Error, the “fi” at UE and gNB may mismatch. Default value: disabled */
    UInt8 fi_backoff_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /*PUSCH threshold value with CRC Error for backing off previously applied TPC command.
    *Default: 130*/
    UInt8 fi_backoff_threshold;
    /*^ M, 0, H, 0, 255 ^*/
}clpc_pusch_config_t;

typedef struct _clpc_pucch_config_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Indicates if CLPC feature on PUCCH Sinr is enabled or disabled. */
    UInt8 clpc_pucch_sinr_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /*Indicates if CLPC feature on PUCCH Bler is enabled or disabled. */
    UInt8 clpc_pucch_bler_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /*Interval between the last time TPC was applied for PUCCH Power 
    *control and the new TPC triggered due to SINR. */
    UInt8 cool_off_period_for_pucch_sinr_tpc;
    /*^ M, 0, H, 0, 255 ^*/
    /*Interval between the last time TPC was applied for PUCCH Power 
    *control and the new TPC triggered due to BLER. */
    UInt8 cool_off_period_for_pucch_bler_tpc;
    /*^ M, 0, H, 0, 255 ^*/
    /*In steps of 10. Default value is 820 */
    UInt16 time_avg_coeff_iir_pucch_clpc;
    /*^ M, 0, H, 0, 1024 ^*/
    /*Delta Sinr to PUCCH TPC map table */
    delta_sinr_to_tpc_map_pucch_t delta_sinr_to_tpc_map_pucch;
    /*^ M, 0, N, 0, 0 ^*/
    /*Delta Bler to PUCCH TPC map table. */
    delta_bler_to_tpc_map_pucch_t delta_bler_to_tpc_map_pucch;
    /*^ M, 0, N, 0, 0 ^*/
}clpc_pucch_config_t;

typedef struct _clpc_config_t
{
#define CLPC_PUSCH_CONFIG_PRESENT 0x0001
#define CLPC_PUCCH_CONFIG_PRESENT 0x0002
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/
    /*Indicates if CLPC feature on PUSCH is enabled or disabled. */
    UInt8   clpc_pusch_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /*Indicates if CLPC feature on PUCCH is enabled or disabled. */
    UInt8   clpc_pucch_enabled;
    /*^ M, 0, H, 0, 1 ^*/
    /*Configuration parameters for CLPC PUSCH.*/
    clpc_pusch_config_t clpc_pusch_config;
    /*^ O, CLPC_PUSCH_CONFIG_PRESENT, N, 0, 0 ^*/
    /*Configuration parameters for CLPC PUCCH */
    clpc_pucch_config_t clpc_pucch_config;
    /*^ O, CLPC_PUCCH_CONFIG_PRESENT, N, 0, 0 ^*/
}clpc_config_t;
/*19.4.19*/

typedef struct _power_control_params_t
{
#define OLPC_CONFIG_PRESENT 0x0001
#define CLPC_CONFIG_PRESENT 0x0002
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/

    olpc_config_t   olpc_config;
    /*^ O, OLPC_CONFIG_PRESENT, N, 0, 0 ^*/
    clpc_config_t   clpc_config;
   /*^ O, CLPC_CONFIG_PRESENT, N, 0, 0 ^*/
}power_control_params_t;


typedef struct _ta_info_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    UInt8                     ta_averaging_factor; 
    /*^ M, 0, H, 0, 100 ^*/
    
    UInt8                     ta_on_pucch;
    /*^ M, 0, H, 0, 1 ^*/

    UInt16                    ta_sync_timer_delta;
    /*^ M, 0, B, 1, 50 ^*/

}ta_info_params_t;

typedef struct _dl_la_info_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /*LA feature enabled or disabled.Default value: Disabled */
    UInt8                    dl_la_enabled;
    /*^ M, 0, H, 0, 1 ^*/

    /*LA feature Mode Default value: 0 */ 
    UInt8                    dl_la_mode;
    /*^ M, 0, H, 0, 2 ^*/

    /* LA shall be triggered after this timer expiry. Default value 160ms, 0 means: LA will not be triggered based on Timer */
    UInt16                   dl_la_trigger_timer;
    /*^ M, 0, H, 0, 65535 ^*/

    /* LA shall be triggered after this number of DL MAC packets (Tx or ReTx, HARQ Ack/NACK in this case) Default value 100, 
       0 means: LA will not be triggered based on Packet count */
    UInt16                   dl_la_pkt_count;
    /*^ M, 0, H, 0, 65535 ^*/

    /*LA trigger after this number of CQI reports. This is valid only if LAMode=1 or 2.Default value:1 (with every CQI), 
      0 means: LA will not be triggered when CQI is received */
    UInt16                  dl_la_cqi_report_count;
    /*^ M, 0, H, 0, 65535 ^*/

    /* Maximum running samples of HARQ ACK/NACK or CRC to be considered for BLER calculation */
    UInt16                  dl_la_bler_samples_count;
    /*^ M, 0, H, 0, 65535 ^*/

    /*Target BLER to be considered for LA Default value: 10 % */
    UInt8                  dl_la_target_bler;
    /*^ M, 0, H, 0, 100 ^*/

    /* CQI Averaging share Default value: 80% */
    UInt8                  dl_la_iir_coefficient;
    /*^ M, 0, H, 0, 100 ^*/

    /* Minimum HARQ  ACK/NACK or CRC samples after which BLER is calculated. Default value:20 */
    UInt16                 dl_la_min_samples;
    /*^ M, 0, H, 0, 65535 ^*/

    /*This parameter is used in calculation of dl_bler_correction_factor. Default value: 15 */
    UInt16                 dl_la_bler_scaling_value;
    /*^ M, 0, H, 0, 100 ^*/

    /* percentage of UL feedback (MCS / SINR) to be considered while calculating DL MCS.
     * Default value:0
     * */
    UInt16               dl_la_ul_to_dl_feedback;
    /*^ M, 0, H, 0, 100 ^*/

    /*Mapping table to fetch MCS from the cqi value */ 
    UInt8              dl_la_cqi_to_MCS_table_64_qam[MAX_MCS_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8              dl_la_cqi_to_MCS_table_256_qam[MAX_MCS_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8              dl_la_cqi_to_MCS_table_low_sc_qam[MAX_MCS_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    
    UInt8              dl_la_ri_switch_low_to_high_samples;
    /*^ M, 0, B, 1, 255 ^*/

    UInt8              dl_la_ri_switch_high_to_low_samples;
    /*^ M, 0, B, 1, 255 ^*/

}dl_la_info_params_t;

typedef struct _ul_la_info_params_t
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /*LA feature enabled or disabled.Default value: Disabled */
    UInt8                   ul_la_enabled;
    /*^ M, 0, H, 0, 1 ^*/

    /*LA feature Mode Default value: 0 */ 
    UInt8                    ul_la_mode;
    /*^ M, 0, H, 0, 2 ^*/

    /* LA shall be triggered after this timer expiry. Default value 160ms, 0 means: LA will not be triggered based on Timer */
    UInt16                  ul_la_trigger_timer;
    /*^ M, 0, H, 0, 65535 ^*/

    /* LA shall be triggered after this number of DL MAC packets (Tx or ReTx, HARQ Ack/NACK in this case) Default value 100, 
       0 means: LA will not be triggered based on Packet count */
    UInt16                  ul_la_pkt_count;
    /*^ M, 0, H, 0, 65535 ^*/

    /* Maximum running samples of HARQ ACK/NACK or CRC to be considered for BLER calculation */
    UInt16                 ul_la_bler_samples_count;
    /*^ M, 0, H, 0, 65535 ^*/

    /*Target BLER to be considered for LA Default value: 10 % */
    UInt8                  ul_la_target_bler;
    /*^ M, 0, H, 0, 100 ^*/

    /* CQI Averaging share Default value: 80% */
    UInt8                  ul_la_iir_coefficient;
    /*^ M, 0, H, 0, 100 ^*/

    /* Minimum HARQ  ACK/NACK or CRC samples after which BLER is calculated. Default value:20 */
    UInt16                 ul_la_min_samples;
    /*^ M, 0, H, 0, 65535 ^*/

    /*This parameter is used in calculation of dl_bler_correction_factor. Default value: 15 */
    UInt16                 ul_la_bler_scaling_value;
    /*^ M, 0, H, 0, 100 ^*/

    /* percentage of UL feedback (MCS / SINR) to be considered while calculating DL MCS.
     * Default value:0
     * */
    UInt16               ul_la_dl_to_ul_feedback;
    /*^ M, 0, H, 0, 100 ^*/

    /*Mapping table to fetch MCS from the cqi value */ 
    UInt8               ul_la_sinr_to_mcs_64_qam[SINR_TO_ARRAY_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8               ul_la_sinr_to_mcs_256_qam[SINR_TO_ARRAY_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
    UInt8               ul_la_sinr_to_mcs_low_sc_qam[SINR_TO_ARRAY_INDEX];
    /*^ M, 0, OCTET_STRING, FIXED ^*/
}ul_la_info_params_t;

typedef struct _dl_generic_params_t 
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* Max harq process supported for Downlink Retransmission default - 6*/
    UInt8                   max_dl_harq_retx;
    /*^ M, 0, H, 0, 28 ^*/

    /* If present SSB resources need to be reserved in resource grid */
    UInt8                       is_ssb_resources_reserved;
    /*^ M, 0, H, 0, 1 ^*/
}dl_generic_params_t;

typedef struct _ul_generic_params_t 
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* Max harq process supported for Uplink Retransmission default -4*/
    UInt8                   max_ul_harq_retx;
    /*^ M, 0, H, 0, 28 ^*/

}ul_generic_params_t;

typedef struct _force_grant_params_t
{

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                 bitmask;
    /*^ BITMASK ^*/

    /* Number of supported force grant */
    UInt16                     num_force_grant;
    /*^ M, 0, H, 0, 65535 ^*/

    /* Size of force grant in bytes */
    UInt8                     size_of_force_grant;
    /*^ M, 0, B, 10, 100 ^*/

}force_grant_params_t;
typedef struct _pdcch_aggr_pwr_offset_tuples_t
{
    /* Bitmask indicating the presence of optional fields */
     bitmask_t                             bitmask;
    /*^ BITMASK ^*/

    UInt8 aggregation_level;
    /*^ M, 0, B, 1, 16 ^*/

    UInt32 pdcch_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    UInt32 pdcch_dmrs_power_offset;
     /*^ M, 0, H, 0, 20000 ^*/

}pdcch_aggr_pwr_offset_tuples_t;


typedef struct _pdcch_aggregation_power_offset_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask;
    /*^ BITMASK ^*/

    UInt8 count;
    /*^ M, 0, H, 0, 5 ^*/


    pdcch_aggr_pwr_offset_tuples_t  pdcch_aggr_pwr_offset_tuples[MAX_AGGREGATION_LEVELS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}pdcch_aggregation_power_offset_t;

typedef struct pdcch_power_control_t
{
  /* Bitmask indicating the presence of optional fields */
   bitmask_t                             bitmask;
  /*^ BITMASK ^*/

   pdcch_aggregation_power_offset_t  pdcch_aggregation_power_offset[MAX_CQI];
   /*^ M, 0, OCTET_STRING, FIXED ^*/

}pdcch_power_control_t;


typedef struct _pdsch_aggr_pwr_offset_tuples_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask;
    /*^ BITMASK ^*/

    UInt32 pdsch_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    UInt32 pdsch_dmrs_power_offset;
     /*^ M, 0, H, 0, 20000 ^*/

}pdsch_aggr_pwr_offset_tuples_t;

typedef struct _pdsch_power_control_t
{
   /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask;
   /*^ BITMASK ^*/


    pdsch_aggr_pwr_offset_tuples_t  pdsch_aggr_pwr_offset_tuples[MAX_CQI];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

}pdsch_power_control_t;


typedef struct _dl_pdsch_power_control_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask;
    /*^ BITMASK ^*/

    UInt8 pdsch_power_control_enabled;
    /*^ M, 0, H, 0, 1 ^*/

    pdsch_power_control_t pdsch_power_control_cc;
    /*^ M, 0, N, 0, 0 ^*/

    pdsch_power_control_t pdsch_power_control_ce;
     /*^ M, 0, N, 0, 0 ^*/
}dl_pdsch_power_control_t;

typedef struct _dl_pdcch_power_control_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                             bitmask;
    /*^ BITMASK ^*/

    UInt8 pdcch_power_control_enabled;
    /*^ M, 0, H, 0, 1 ^*/

    UInt8 small_dci_threshold;
    /*^ M, 0, B, 10, 50 ^*/

    UInt8 medium_dci_threshold;
    /*^ M , 0, B, 55, 70 ^*/

    pdcch_power_control_t pdcch_power_control_cc[MAX_DCI_CATEGORY];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

    pdcch_power_control_t pdcch_power_control_ce[MAX_DCI_CATEGORY];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

}dl_pdcch_power_control_t;

typedef struct _paging_info_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                       bitmask;
    /*^ BITMASK ^*/

    /* Signifies the CCE Aggregation level configured for paging
     * defualt is 0 */
    cce_aggr_level_for_paging_t     cce_aggr_level_for_paging;
    /*^ M, 0, H , 0 , 2 ^*/

    /* Signifies the mcs Index value to be used for paging */
    UInt8                           mcs_index;
    /*^ M, 0, H , 0 , 9 ^*/

    /* Signifies the vrb to prb mapping for paging */
    UInt8                           vrb_to_prb_mapping;
    /*^ M, 0, H, 0, 1 ^*/

    /*TB scaling to be applied for determine the TB size for paging
     * Refer section 5.1.3.2 of 3GPP 38.214 */
    tb_scaling_t                    tb_scaling;
    /*^ M, 0, H, 0, 2 ^*/

    /*pdcch power offset for PCCH
     * Range from -6dB to 14 dB with 0.001 dB step */
    UInt32                           pdcch_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    /*pdsch power offset for PCCH
     * Range from -6dB to 14 dB with 0.001 dB step */
    UInt32                           pdsch_power_offset;
     /*^ M, 0, H, 0, 20000 ^*/

    /*pdcch dmrs power offset for PCCH
     * Range from -6dB to 14 dB with 0.001 dB step*/
    UInt32                          pdcch_dmrs_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/

    /*Pdsch dmrs power offset for PCCH
     * Range from -6dB to 14 dB with 0.001 dB step*/
    UInt32                          pdsch_dmrs_power_offset;
    /*^ M, 0, H, 0, 20000 ^*/
}paging_info_params_t;

typedef struct _beam_generic_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                   bitmask;
    /*^ BITMASK ^*/ 

    /*Number of SSBRI RSRP reports above configured threshold to trigger beam switch */
    UInt8                      num_rsrp_reports;
    /*^ M, 0, B, 1, 50 ^*/

    /*This parameter informs if RSRP threshold above which the 
      ssb beam will be considered for beam switching. 
      Refer  Table 10.1.6.1-1 & Table 10.1.6.1-2  
      3GPP TS 38.133 for L1 RSRP and Differential RSRP reported by UE */
    UInt8                     ssb_rsrp_threshold;
    /*^ M, 0, B, 0, 100 ^*/    
}beam_generic_params_t;

typedef struct _ca_info_params_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t                   bitmask;
    /*^ BITMASK ^*/

    /*This parameter informs cell(s) to consider capacity up-to
     ** this parameter before distributing queue load to other cell(s)*/
    UInt32                      periodicity_for_bo_distribution;
    /*^ M, 0, B, 1, 100 ^*/

    /*This parameter enables cell(s) to offload buffer (Bytes) to other
     *      * cell(s) only if offloaded part exceeds this parameter*/
    UInt32                      threshold_for_scell_distribution;
    /*^ M, 0, B, 1000, 65535 ^*/

}ca_info_params_t;

typedef struct _duoam_mac_scheduler_params_req_t
{
#define SYSTEM_INFO_PARAMS_PRESENT             0x0001
#define RACH_INFO_PARAMS_PRESENT               0x0002
#define MCS_THRESHOLD_INFO_PRESENT             0x0004 
#define POWER_CONTROL_CONFIG_PARAMS_PRESENT    0x0008
#define TA_INFO_PARAMS_PRESENT                 0x0010
#define DL_LA_INFO_PARAMS_PRESENT              0x0020 
#define UL_LA_INFO_PARAMS_PRESENT              0x0040 
#define FORCE_GRANT_PARAMS_PRESENT             0x0080 
#define DL_GENERIC_PARAMS_PRESENT              0x0100
#define UL_GENERIC_PARAMS_PRESENT              0x0200
#define PAGING_INFO_PARAMS_PRESENT             0x0400
#define NR_DL_PDSCH_POWER_CONTROL              0x0800
#define NR_BEAM_GENERIC_PARAMS_PRESENT         0x1000
#define CA_INFO_PARAMS_PRESENT                 0x2000
#define NR_DL_PDCCH_POWER_CONTROL              0x4000

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/

    system_info_params_t       system_info_params;
    /*^ O, SYSTEM_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

    rach_info_params_t          rach_info_params;
    /*^ O, RACH_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

    mcs_threshold_info_t        mcs_threshold_info;
    /*^ O, MCS_THRESHOLD_INFO_PRESENT, N, 0, 0 ^*/

    power_control_params_t      power_control_config;
    /*^ O, POWER_CONTROL_CONFIG_PARAMS_PRESENT, N, 0, 0 ^*/

    ta_info_params_t            ta_info_params;
    /*^ O, TA_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

    dl_la_info_params_t         dl_la_info_params;
    /*^ O, DL_LA_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

    ul_la_info_params_t         ul_la_info_params;
    /*^ O, UL_LA_INFO_PARAMS_PRESENT, N, 0, 0 ^*/
    
    force_grant_params_t        force_grant_params;
    /*^ O, FORCE_GRANT_PARAMS_PRESENT, N, 0, 0 ^*/

    dl_generic_params_t         dl_generic_params;
    /*^ O, DL_GENERIC_PARAMS_PRESENT, N, 0, 0 ^*/

    ul_generic_params_t         ul_generic_params;
    /*^ O, UL_GENERIC_PARAMS_PRESENT, N, 0, 0 ^*/

    dl_pdsch_power_control_t    dl_pdsch_power_control;
    /*^ O, NR_DL_PDSCH_POWER_CONTROL, N, 0, 0 ^*/

    paging_info_params_t        paging_info_params;
    /*^ O, PAGING_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

    beam_generic_params_t       beam_generic_params;
    /*^ O, NR_BEAM_GENERIC_PARAMS_PRESENT, N, 0, 0 ^*/
    
    dl_pdcch_power_control_t    dl_pdcch_power_control;
    /*^ O, NR_DL_PDCCH_POWER_CONTROL, N, 0, 0 ^*/
  
    ca_info_params_t           ca_info_params;
    /*^ O, CA_INFO_PARAMS_PRESENT, N, 0, 0 ^*/

}duoam_mac_scheduler_params_req_t; /*^ API, DUOAM_MAC_SCHEDULER_PARAMS_REQ ^*/

/**********************************************************************
 * MAC_DUOAM_SCHEDULER_PARAMS_RESP
 * *******************************************************************/
typedef struct _mac_duoam_scheduler_params_resp_t
{
#define MAC_SCH_FAIL_CAUSE_PRESENT  0x0001

    /* Bitmask indicating the presence of optional fields */
    bitmask_t                  bitmask;
    /*^ BITMASK ^*/

    UInt8               response;
    /*^ M, 0, H, 0, 1 ^*/

    UInt16              cause;
    /*^ O, MAC_SCH_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
}mac_duoam_scheduler_params_resp_t; /*^ API, MAC_DUOAM_SCHEDULER_PARAMS_RESP ^*/

/**********************************************************************
 * DUOAM_MAC_PRECODING_PARAMS_REQ
 * *******************************************************************/
typedef struct _precoder_weight_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    SInt16              prec_weight_real;
    /*^ M, 0, N, 0, 0 ^*/
    
    SInt16              prec_weight_imag;
    /*^ M, 0, N, 0, 0 ^*/

}precoder_weight_t;

typedef struct
{
    UInt16              num_port;
    /*^ M, 0, H, 0, MAX_NUM_PORTS ^*/

    precoder_weight_t   precoder_weight[MAX_NUM_PORTS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}precoder_weight_array_t;

typedef struct _precoding_matrix_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    UInt16              pmi_index;
    /*^ M, 0, H, 0, MAX_PMI_COUNT ^*/
    
    UInt16              num_layer;
    /*^ M, 0, H, 0, MAX_NUM_LAYERS ^*/

    precoder_weight_array_t   precoder_weight_array[MAX_NUM_LAYERS];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}precoding_matrix_t;

typedef struct _duoam_mac_precoding_params_req_t
{
    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    UInt8               end_indicator;
    /*^ M, 0, H, 0, 1 ^*/
    
    UInt16              pmi_index_count;
    /*^ M, 0, H, 0, MAX_PMI_COUNT ^*/

    precoding_matrix_t  precoding_matrix[MAX_PMI_COUNT];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/
}duoam_mac_precoding_params_req_t; /*^ API, DUOAM_MAC_PRECODING_PARAMS_REQ ^*/

/**********************************************************************
 * MAC_DUOAM_PRECODING_PARAMS_RESP
 * *******************************************************************/
typedef struct _mac_duoam_precoding_params_resp_t
{
#define MAC_SCH_FAIL_CAUSE_PRESENT  0x0001

    /* Bitmask indicating the presence of optional fields */
    bitmask_t           bitmask;
    /*^ BITMASK ^*/

    UInt8               response;
    /*^ M, 0, H, 0, 1 ^*/

    UInt16              cause;
    /*^ O, MAC_SCH_FAIL_CAUSE_PRESENT, N, 0, 0 ^*/
}mac_duoam_precoding_params_resp_t; /*^ API, MAC_DUOAM_PRECODING_PARAMS_RESP ^*/

#endif
