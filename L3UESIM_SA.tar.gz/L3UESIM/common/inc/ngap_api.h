/*******************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 *******************************************************************************
 *
 *  $Id: ngap_api.h,
 *
 *******************************************************************************
 *
 *  File Description : 
 *
 *******************************************************************************
 *
 * Revision Details
 * ----------------
 *
 * $Log: ngap_api.h,v $
 *
 * 
 *
 ******************************************************************************/
#ifndef _NGAP_API_H_
#define _NGAP_API_H_

/*******************************************************************************
 * Project Includes
 ******************************************************************************/

/*******************************************************************************
 * Exported Includes
 ******************************************************************************/



/*******************************************************************************
 * Exported Definitions
 ******************************************************************************/


/*******************************************************************************
 *                        EXTERNAL APIs
 ******************************************************************************/


/*******************************************************************************
 * NGAP - OAM APIs
 *******************************************************************/
#define NGAP_OAM_API_BASE                   1100

#define NGAP_OAM_INIT_IND                      (NGAP_OAM_API_BASE + 1)
#define NGAP_OAM_PROVISION_REQ                 (NGAP_OAM_API_BASE + 2)
#define NGAP_OAM_PROVISION_RESP                (NGAP_OAM_API_BASE + 3)
#define NGAP_OAM_NGAP_LINK_STATUS_IND          (NGAP_OAM_API_BASE + 4)
#define NGAP_OAM_ALARM_NOTIFICATION_IND   (NGAP_OAM_API_BASE + 5)  
#define NGAP_OAM_GET_LOG_LEVEL_REQ             (NGAP_OAM_API_BASE + 6)
#define NGAP_OAM_GET_LOG_LEVEL_RESP            (NGAP_OAM_API_BASE + 7)
#define NGAP_OAM_SET_LOG_LEVEL_REQ             (NGAP_OAM_API_BASE + 8)
#define NGAP_OAM_SET_LOG_LEVEL_RESP            (NGAP_OAM_API_BASE + 9)
#define NGAP_OAM_LOG_ENABLE_REQ                (NGAP_OAM_API_BASE + 10)
#define NGAP_OAM_LOG_ENABLE_RESP               (NGAP_OAM_API_BASE + 11)
#define NGAP_OAM_LOG_DISABLE_REQ               (NGAP_OAM_API_BASE + 12)
#define NGAP_OAM_LOG_DISABLE_RESP              (NGAP_OAM_API_BASE + 13)
#define NGAP_OAM_STATUS_REQ                    (NGAP_OAM_API_BASE + 14)
#define NGAP_OAM_STATUS_RESP                   (NGAP_OAM_API_BASE + 15)
#define NGAP_OAM_GET_SCTP_STATUS_REQ           (NGAP_OAM_API_BASE + 16)
#define NGAP_OAM_GET_SCTP_STATUS_RESP          (NGAP_OAM_API_BASE + 17)
#define NGAP_OAM_RESET_REQ                     (NGAP_OAM_API_BASE + 18)
#define NGAP_OAM_RESET_RESP                    (NGAP_OAM_API_BASE + 19)



#define NGAP_OAM_API_LAST                   1199


/********************************************************************
 *                        INTERNAL APIs
 *******************************************************************/

/********************************************************************
 * NGAP - SCTP ASSOCIATED
 *******************************************************************/
#define NGAP_EXTERNAL_API_BASE                1200
#define NGAP_AMF_MESSAGE                      NGAP_EXTERNAL_API_BASE + 1  /* To Indicate Message from AMF */
#define NGAP_SCTP_CONN_FAILURE_IND            NGAP_EXTERNAL_API_BASE + 2     /* Connecttion Lost */
#define NGAP_SCTP_CONN_RESTART_IND            NGAP_EXTERNAL_API_BASE + 3     /* Connection restart */
#define NGAP_SCTP_CLOSED_IND                  NGAP_EXTERNAL_API_BASE + 4     /* Shut down complete */
#define NGAP_SCTP_COMM_UP_IND                 NGAP_EXTERNAL_API_BASE + 5     /* Communication up */
#define NGAP_SCTP_PEND_CONN_IND               NGAP_EXTERNAL_API_BASE + 6     /* Pending */
#define NGAP_SCTP_SHUT_DOWN_INIT_IND          NGAP_EXTERNAL_API_BASE + 7     /* Shut down initiated */ 

/****************************************************************************
 * Exported Types
 ****************************************************************************/

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/

/****************************************************************************
 * Exported Functions
 ****************************************************************************/

#endif  /* _NGAP_API_H_ */
