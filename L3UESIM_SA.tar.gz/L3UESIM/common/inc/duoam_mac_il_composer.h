/***************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (c) 2014 Aricent.
 *
 ****************************************************************************
 * File Details
 * ------------
 *  $Id: $
 ****************************************************************************
 *
 *  File Description : The file duoam_mac_il_composer.h contains the prototypes 
 *                     of DUOAM-MAC interface message composing functions.
 *
 ****************************************************************************
 *
 * Revision Details
 * ----------------
 * $Log: $
 *
 ****************************************************************************/
#ifndef _DUOAM_MAC_IL_COMPOSER_H_
#define _DUOAM_MAC_IL_COMPOSER_H_

#include "gnb_defines.h"
#include "duoam_mac_intf.h"
#include "gnb_msg_mgmt.h"

gnb_length_t
gnb_il_get_duoam_mac_provisioning_req_len
(
    duoam_mac_provisioning_req_t *p_duoam_mac_provisioning_req
);

gnb_return_t
gnb_il_compose_duoam_mac_provisioning_req
(
    UInt8  **pp_buffer,
    duoam_mac_provisioning_req_t *p_duoam_mac_provisioning_req
);

gnb_length_t
gnb_il_get_mac_duoam_provisioning_resp_len
(
    mac_duoam_provisioning_resp_t *p_mac_duoam_provisioning_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_provisioning_resp
(
    UInt8  **pp_buffer,
    mac_duoam_provisioning_resp_t *p_mac_duoam_provisioning_resp
);

gnb_length_t
gnb_il_get_mac_duoam_cleanup_resp_len
(
    mac_duoam_cleanup_resp_t *p_mac_duoam_cleanup_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_cleanup_resp
(
    UInt8  **pp_buffer,
    mac_duoam_cleanup_resp_t *p_mac_duoam_cleanup_resp
);

gnb_length_t
gnb_il_get_duoam_mac_set_log_level_ind_len
(
    duoam_mac_set_log_level_ind_t *p_duoam_mac_set_log_level_ind
);

gnb_return_t
gnb_il_compose_duoam_mac_set_log_level_ind
(
    UInt8  **pp_buffer,
    duoam_mac_set_log_level_ind_t *p_duoam_mac_set_log_level_ind
);

gnb_length_t
gnb_il_get_mac_duoam_get_log_level_resp_len
(
    mac_duoam_get_log_level_resp_t *p_mac_duoam_get_log_level_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_get_log_level_resp
(
    UInt8  **pp_buffer,
    mac_duoam_get_log_level_resp_t *p_mac_duoam_get_log_level_resp
);

gnb_length_t
gnb_il_get_duoam_mac_enable_log_category_ind_len
(
    duoam_mac_enable_log_category_ind_t *p_duoam_mac_enable_log_category_ind
);

gnb_return_t
gnb_il_compose_duoam_mac_enable_log_category_ind
(
    UInt8  **pp_buffer,
    duoam_mac_enable_log_category_ind_t *p_duoam_mac_enable_log_category_ind
);

gnb_length_t
gnb_il_get_duoam_mac_disable_log_category_req_len
(
    duoam_mac_disable_log_category_req_t *p_duoam_mac_disable_log_category_req
);

gnb_return_t
gnb_il_compose_duoam_mac_disable_log_category_req
(
    UInt8  **pp_buffer,
    duoam_mac_disable_log_category_req_t *p_duoam_mac_disable_log_category_req
);

gnb_length_t
gnb_il_get_mac_duoam_get_log_category_resp_len
(
    mac_duoam_get_log_category_resp_t *p_mac_duoam_get_log_category_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_get_log_category_resp
(
    UInt8  **pp_buffer,
    mac_duoam_get_log_category_resp_t *p_mac_duoam_get_log_category_resp
);

gnb_length_t
gnb_il_get_duoam_mac_get_debug_info_req_len
(
    duoam_mac_get_debug_info_req_t *p_duoam_mac_get_debug_info_req
);

gnb_return_t
gnb_il_compose_duoam_mac_get_debug_info_req
(
    UInt8  **pp_buffer,
    duoam_mac_get_debug_info_req_t *p_duoam_mac_get_debug_info_req
);

gnb_length_t
gnb_il_get_mac_duoam_get_debug_info_resp_len
(
    mac_duoam_get_debug_info_resp_t *p_mac_duoam_get_debug_info_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_get_debug_info_resp
(
    UInt8  **pp_buffer,
    mac_duoam_get_debug_info_resp_t *p_mac_duoam_get_debug_info_resp
);

gnb_length_t
gnb_il_get_duoam_mac_scheduler_params_req_len
(
    duoam_mac_scheduler_params_req_t *p_duoam_mac_scheduler_params_req
);

gnb_return_t
gnb_il_compose_duoam_mac_scheduler_params_req
(
    UInt8  **pp_buffer,
    duoam_mac_scheduler_params_req_t *p_duoam_mac_scheduler_params_req
);

gnb_length_t
gnb_il_get_mac_duoam_scheduler_params_resp_len
(
    mac_duoam_scheduler_params_resp_t *p_mac_duoam_scheduler_params_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_scheduler_params_resp
(
    UInt8  **pp_buffer,
    mac_duoam_scheduler_params_resp_t *p_mac_duoam_scheduler_params_resp
);

gnb_length_t
gnb_il_get_duoam_mac_precoding_params_req_len
(
    duoam_mac_precoding_params_req_t *p_duoam_mac_precoding_params_req
);

gnb_return_t
gnb_il_compose_duoam_mac_precoding_params_req
(
    UInt8  **pp_buffer,
    duoam_mac_precoding_params_req_t *p_duoam_mac_precoding_params_req
);

gnb_length_t
gnb_il_get_mac_duoam_precoding_params_resp_len
(
    mac_duoam_precoding_params_resp_t *p_mac_duoam_precoding_params_resp
);

gnb_return_t
gnb_il_compose_mac_duoam_precoding_params_resp
(
    UInt8  **pp_buffer,
    mac_duoam_precoding_params_resp_t *p_mac_duoam_precoding_params_resp
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_provisioning_req
(
    duoam_mac_provisioning_req_t  *p_duoam_mac_provisioning_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_provisioning_resp
(
    mac_duoam_provisioning_resp_t  *p_mac_duoam_provisioning_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_cleanup_resp
(
    mac_duoam_cleanup_resp_t  *p_mac_duoam_cleanup_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_set_log_level_ind
(
    duoam_mac_set_log_level_ind_t  *p_duoam_mac_set_log_level_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_get_log_level_resp
(
    mac_duoam_get_log_level_resp_t  *p_mac_duoam_get_log_level_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_enable_log_category_ind
(
    duoam_mac_enable_log_category_ind_t  *p_duoam_mac_enable_log_category_ind,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_disable_log_category_req
(
    duoam_mac_disable_log_category_req_t  *p_duoam_mac_disable_log_category_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_get_log_category_resp
(
    mac_duoam_get_log_category_resp_t  *p_mac_duoam_get_log_category_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_get_debug_info_req
(
    duoam_mac_get_debug_info_req_t  *p_duoam_mac_get_debug_info_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_get_debug_info_resp
(
    mac_duoam_get_debug_info_resp_t  *p_mac_duoam_get_debug_info_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_scheduler_params_req
(
    duoam_mac_scheduler_params_req_t  *p_duoam_mac_scheduler_params_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_scheduler_params_resp
(
    mac_duoam_scheduler_params_resp_t  *p_mac_duoam_scheduler_params_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_duoam_mac_precoding_params_req
(
    duoam_mac_precoding_params_req_t  *p_duoam_mac_precoding_params_req,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

gnb_return_t
gnb_duoam_il_send_mac_duoam_precoding_params_resp
(
    mac_duoam_precoding_params_resp_t  *p_mac_duoam_precoding_params_resp,
    UInt16                 src_module_id,
    UInt16                 dst_module_id,
    UInt16                 transaction_id,
    UInt16                 cell_index,
    pup_send_callback      send_callback
);

#endif /* _DUOAM_MAC_IL_COMPOSER_H_ */
