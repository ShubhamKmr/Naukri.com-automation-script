typedef unsigned int imsi_t;

typedef struct _ul_nas
{
    imsi_t imsi;
}ul_nas_t;

typedef struct _eRab_parameter_t
{
    union {
        bool gbr_ul_bitrate_present:1;
        bool gbr_dl_bitrate_present:1;
        bool mbr_dl_bitrate_present:1;
        bool mbr_ul_bitrate_present:1;
    }u;
    unsigned long long       gbr_ul_bitrate;
    unsigned long long       gbr_dl_bitrate;
    unsigned long long       mbr_dl_bitrate;
    unsigned long long       mbr_ul_bitrate;
    unsigned char            eRab_id;
    unsigned char            qci;
}eRab_parameter_t;

typedef struct _eRab_list_t
{
    int count;
    eRab_parameter_t eRab_info[8];
}eRab_list_t;

typedef struct _dl_nas
{
    eRab_list_t eRabinfo;
    unsigned char ueambr;
}dl_nas;
