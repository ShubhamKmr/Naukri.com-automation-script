/******************************************************************************
*
*   FILE NAME:
*       rrc_ngap_common_def.h
*
*   Copyright (c) 2019, Aricent Inc. All Rights Reserved
*
******************************************************************************/
#ifndef _RRC_NGAP_CU_COMMON_DEF_H_
#define _RRC_NGAP_CU_COMMON_DEF_H_

#include "gnb_types.h"

#define NGAP_MAX_RAN_NODE_NAME_LENGTH                 150
#define AMF_MAX_NODE_NAME_LENGTH                      150
#define NGAP_GNB_ID_OCTET_SIZE                        4   /* To Support bits 22-32 */
#define NGAP_MACRO_NG_ENB_ID_OCTET_SIZE               3   /* To Support 20 bits */
#define NGAP_SHORT_MACRO_NG_ENB_ID_OCTET_SIZE         3   /* To Support 18 bits */
#define NGAP_LONG_MACRO_NG_ENB_ID_OCTET_SIZE          3   /* To Support 21 bits */
#define NGAP_N3IWF_ID_OCTET_SIZE                      2   /* To Support 16 bits */
#define NGAP_MAX_AMF_NAME_LENGTH                      150
#define NGAP_AMF_REGION_ID_OCTET_SIZE                 1   /* To Support 8 bits */
#define NGAP_AMF_SET_ID_OCTET_SIZE                    2   /* To Support 10 bits */
#define NGAP_AMF_POINTER_OCTET_SIZE                   1   /* To Support 6 bits */
#define MAX_QFI_DRB_PER_PDU_SESSION                   3   /* This is to support maximum 3 qfi/drb per pdu session*/
#define NGAP_PDU_SESSION_MAX_NO_OF_PDU_SESSION_PER_UE 3
//Aman Fix
#define MAX_QOS_FLOW_COUNT_PER_PDU_SESSION            3
typedef enum
{
    NR_CELL_TYPE_VERY_SMALL,
    NR_CELL_TYPE_SMALL,
    NR_CELL_TYPE_MEDIUM,
    NR_CELL_TYPE_LARGE
}nr_cell_type_et;


/***************************************************************************
 * IE Defination
 **************************************************************************/

typedef struct
{

#define NGAP_PLMN_IDENTITY_MAX_BYTES     3

    /* PLMN Identity Bytes */
    UInt8   plmn_id_bytes [NGAP_PLMN_IDENTITY_MAX_BYTES];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} ngap_plmn_identity_t;

/* Global N3IWF ID*/
typedef struct
{
    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;
    /*^ M, 0, N, 0, 0 ^*/

    /* n3iwf ID */
    UInt8                   n3iwf_id[NGAP_N3IWF_ID_OCTET_SIZE];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} global_n3iwf_id_t;

/* Global ng-eNB ID*/
typedef struct
{

#define GLOBAL_NG_ENB_CHOICE_MACRO_ID       0x01
#define GLOBAL_NG_ENB_CHOICE_SHORT_MACRO_ID 0x02
#define GLOBAL_NG_ENB_CHOICE_LONG_MACRO_ID  0x04

    /* Choice Type for Global NG_ENB ID */
    UInt8                   choice_type;
    /*^ BITMASK ^*/

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;
    /*^ M, 0, N, 0, 0 ^*/

    /* Macro ng-eNB ID */
    UInt8   macro_ng_enb_id[NGAP_MACRO_NG_ENB_ID_OCTET_SIZE];
    /*^ O, GLOBAL_NG_ENB_CHOICE_MACRO_ID, OCTET_STRING, FIXED ^*/

    /* Short Macro ng-eNB ID */
    UInt8   short_macro_ng_enb_id[NGAP_SHORT_MACRO_NG_ENB_ID_OCTET_SIZE];
    /*^ O, GLOBAL_NG_ENB_CHOICE_SHORT_MACRO_ID, OCTET_STRING, FIXED ^*/

    /* Long Macro ng-eNB ID */
    UInt8   long_macro_ng_enb_id[NGAP_LONG_MACRO_NG_ENB_ID_OCTET_SIZE];
    /*^ O, GLOBAL_NG_ENB_CHOICE_LONG_MACRO_ID, OCTET_STRING, FIXED ^*/

} global_ng_enb_id_t;

typedef struct
{

    /* Valid gNB Bits */
    UInt8   num_gnb_id_bits;
    /*^ M, 0, H, 22, 32 ^*/

    /* gNB ID */
    UInt8   gnb_id_bytes [NGAP_GNB_ID_OCTET_SIZE];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} ngap_gnb_id_t;

typedef struct
{
    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;
    /*^ M, 0, N, 0, 0 ^*/

    /* gNB ID */
    ngap_gnb_id_t           gnb_id;
    /*^ M, 0, N, 0, 0 ^*/

} global_gnb_id_t;


/* Global RAN Node ID*/
typedef struct
{

#define NGAP_GLOBAL_RAN_NODE_CHOICE_GNB_ID      0x01
#define NGAP_GLOBAL_RAN_NODE_CHOICE_NG_ENB_ID   0x02
#define NGAP_GLOBAL_RAN_NODE_CHOICE_N3IWF_ID    0x04

    /* Choice Type for Global RAN Node ID */
    UInt8   choice_type;
    /*^ BITMASK ^*/

    /* gNB - Global gNB ID */
    global_gnb_id_t     global_gnb_id;
    /*^ O, NGAP_GLOBAL_RAN_NODE_CHOICE_GNB_ID, N, 0, 0 ^*/

    /* ng-eNB - Global ng-eNB ID */
    global_ng_enb_id_t  global_ng_enb_id;
    /*^ O, NGAP_GLOBAL_RAN_NODE_CHOICE_NG_ENB_ID, N, 0, 0 ^*/

    /* N3IWF - Global N3IWF ID */
    global_n3iwf_id_t   global_n3iwf_id;
    /*^ O, NGAP_GLOBAL_RAN_NODE_CHOICE_N3IWF_ID, N, 0, 0 ^*/

} ngap_global_ran_node_id_t;

/* GUAMI */
typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;
    /*^ M, 0, N, 0, 0 ^*/

    /* AMF Region ID */
    UInt8                   amf_region_id[NGAP_AMF_REGION_ID_OCTET_SIZE];
    /*^ M,0,OCTET_STRING,FIXED ^*/

    /* AMF SET ID */
    UInt8                   amf_set_id[NGAP_AMF_SET_ID_OCTET_SIZE];
    /*^ M,0,OCTET_STRING,FIXED ^*/

    /* AMF Pointer */
    UInt8                   amf_pointer[NGAP_AMF_POINTER_OCTET_SIZE];
    /*^ M,0,OCTET_STRING,FIXED ^*/

} ngap_guami_t;


/* AMF Name */
typedef struct
{

    /* AMF Name */
      SInt8   amf_name[NGAP_MAX_AMF_NAME_LENGTH];
    /*^ M, 0, OCTET_STRING, FIXED ^*/

} ngap_amf_name_t;

/* Served GUAMI Item */
typedef struct
{

#define NG_SETUP_RES_BACKUP_AMF_NAME_PRESENT    0x01

    UInt32          bitmask;
    /*^ BITMASK ^*/

    /* GUAMI */
    ngap_guami_t    guami;
    /*^ M, 0, N, 0, 0 ^*/

    /* Backup AMF Name */
    ngap_amf_name_t backup_amf_name;
    /*^ M, 0, N, 0, 0 ^*/

} ngap_served_guami_item_t;

/* Served GUAMI List */
typedef struct
{

#define NG_SETUP_RES_MAX_NO_OF_SERVED_GUAMI     256

    /* Count of Served GUAMI List */
    UInt16                      count;
    /*^ M, 0, H, 0, NG_SETUP_RES_MAX_NO_OF_SERVED_GUAMI ^*/

    /* Served GUAMI Item */
    ngap_served_guami_item_t    guami_item [NG_SETUP_RES_MAX_NO_OF_SERVED_GUAMI];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

} ngap_served_guami_list_t;

/******************************************************************************
    RRC_RRM_PDU_SESSION_SETUP_REQ
******************************************************************************/
typedef enum
{
    //NOTIFICATION_CONTROL_NOTIFY, /Handover bug fixes*/
    NOTIFICATION_CONTROL_REQUESTED

}notification_control_et;

typedef enum
{
    ADDITIONAL_QOS_FLOW_INFO_MORE_LIKELY

}additional_qos_flow_info_et;

typedef enum
{
    REFLECTIVE_QOS_ATTR_SUBJECT_TO

}reflective_qos_attribute_et;

typedef enum
{
    PRE_EMPTION_CAPABILITY_SHALL_NOT_TRIGGER_PRE_EMPTION,
    PRE_EMPTION_CAPABILITY_MAY_TRIGGER_PRE_EMPTION

}pre_emption_capability_et;

typedef enum
{
    PRE_EMPTION_VULNERABILITY_NOT_PRE_EMPTABLE,
    PRE_EMPTION_VULNERABILITY_PRE_EMPTABLE

}pre_emption_vnerability_et;

typedef enum
{
  DC_DELAY_CRITICAL,
  DC_NON_DELAY_CRITICAL

}delay_critical_et;

typedef struct
{
    additional_qos_flow_info_et     additional_qos_flow_info;
    /*^ M, 0, H, 0, ADDITIONAL_QOS_FLOW_INFO_MORE_LIKELY ^*/

} additional_qos_flow_info_t;

/* REFLECTIVE QOS ATTRIBUTE */
typedef struct
{
    reflective_qos_attribute_et      reflective_qos_attribute;
    /*^ M, 0, N, 0, REFLECTIVE_QOS_ATTR_SUBJECT_TO ^*/

}reflective_qos_attribute_t;

/* GBR_QOS_INFORMATION */
typedef struct
{
#define GBR_QOS_INFO_NOTIFICATION_CONTROL_PRESENT           0x01
#define GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_DL_PRESENT    0x02
#define GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_UL_PRESENT    0x04

    UInt32                    bitmask;
    /*^ BITMASK ^*/

    UInt64                    max_flow_bit_rate_dl;
    /*^ M, 0, N, 0, 0 ^*/

    UInt64                    max_flow_bit_rate_ul;
    /*^ M, 0, N, 0, 0 ^*/

    UInt64                    guaranteed_flow_bit_rate_dl;
    /*^ M, 0, N, 0, 0 ^*/

    UInt64                    guaranteed_flow_bit_rate_ul;
    /*^ M, 0, N, 0, 0 ^*/

    notification_control_et   notification_control;
    /*^ O, GBR_QOS_INFO_NOTIFICATION_CONTROL_PRESENT, H, 0, NOTIFICATION_CONTROL_REQUESTED ^*/

    UInt32                    max_packet_loss_rate_dl;
    /*^ O, GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_DL_PRESENT, H, 0, 1000 ^*/

    UInt32                    max_packet_loss_rate_ul;
    /*^ O, GBR_QOS_INFO_MAXIMUM_PACKET_LOSS_RATE_UL_PRESENT, H, 0, 1000 ^*/

}cu_gbr_qos_info_t;

/* ALLOCATION AND RETENTION PRIORITY */
typedef struct
{
    UInt8                          priority_level_arp;
    /*^ M, 0, B, 1, 15 ^*/

    pre_emption_capability_et      pre_emption_capability;
    /*^ M, 0, H, 0, PRE_EMPTION_CAPABILITY_MAY_TRIGGER_PRE_EMPTION ^*/

    pre_emption_vnerability_et     pre_emption_vulnerability;
    /*^ M, 0, H, 0, PRE_EMPTION_VULNERABILITY_PRE_EMPTABLE ^*/

}allocation_and_retention_priority_t;

/* PACKET ERROR RATE */
typedef struct
{
    UInt32      per_scalar;
    /*^ M, 0, H, 0, 9 ^*/

    UInt32      per_exponent;
    /*^ M, 0, H, 0, 9 ^*/

}packet_error_rate_t;

/* DYNAMIC 5QI DESCRIPTOR */
typedef struct
{
#define DYNAMIC_5QI_DISCRIPTOR_FIVE_QI_PRESENT                            0x01
#define DYNAMIC_5QI_DISCRIPTOR_DELAY_CRITICAL_PRESENT                     0x02
#define DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_AVERAGE_WINDOW_PRESENT             0x04
#define DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_MAXIMUM_DATA_BURST_VOLUME_PRESENT  0x08

    UInt32                      bitmask;
    /*^ BITMASK ^*/

    UInt32                      priority_level_qos;
    /*^ M, 0, B, 1, 127 ^*/

    UInt32                      packet_delay_budget;
    /*^ M, 0, H, 0, 1023 ^*/

    packet_error_rate_t         packet_error_rate;
    /*^ M, 0, N, 0, 0 ^*/

    UInt32                      five_qi;
    /*^ O, DYNAMIC_5QI_DISCRIPTOR_FIVE_QI_PRESENT, H, 0, 255 ^*/

    delay_critical_et           delay_critical;
    /*^ O, DYNAMIC_5QI_DISCRIPTOR_DELAY_CRITICAL_PRESENT, H, 0, DC_NON_DELAY_CRITICAL ^*/

    UInt32                      average_window;
    /*^ O, DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_AVERAGE_WINDOW_PRESENT, H, 0, 4095 ^*/

    UInt32                      max_data_burst_volume;
    /*^ O, DYNAMIC_5QI_DISCRIPTOR_DYNAMIC_MAXIMUM_DATA_BURST_VOLUME_PRESENT, H, 0, 4095 ^*/

}dynamic_5qi_descriptor_t;

/* NON DYNAMIC 5QI DESCRIPTOR */
typedef struct
{
#define NON_DYNAMIC_5QI_DISCRIPTOR_PRITORITY_LEVEL_QOS_PRESENT        0x01
#define NON_DYNAMIC_5QI_DISCRIPTOR_AVERAGE_WINDOW_PRESENT             0x02
#define NON_DYNAMIC_5QI_DISCRIPTORMAXIMUM_DATA_BURST_VOLUME_PRESENT   0x04

    UInt32                      bitmask;
    /*^ BITMASK ^*/

    UInt32                      five_qi;
    /*^ M, 0, H, 0, 255 ^*/

    UInt32                      priority_level_qos;
    /*^ O, NON_DYNAMIC_5QI_DISCRIPTOR_PRITORITY_LEVEL_QOS_PRESENT, B, 1, 127 ^*/

    UInt32                      average_window;
    /*^ O, NON_DYNAMIC_5QI_DISCRIPTOR_AVERAGE_WINDOW_PRESENT, H, 0, 4095 ^*/

    UInt32                      max_data_burst_volume;
    /*^ O, NON_DYNAMIC_5QI_DISCRIPTORMAXIMUM_DATA_BURST_VOLUME_PRESENT, H, 0, 4095 ^*/

}non_dynamic_5qi_descriptor_t;

/* QOS CHARCATERSTICS */
typedef  struct
{
#define QOS_CHARACTERSTICS_NON_DYNAMIC_5QI_DESCRIPTOR     0x01
#define QOS_CHARACTERSTICS_DYNAMIC_5QI_DESCRIPTOR         0x02

    UInt8                               choice_type;/*Handover bug fixes*/
    /*^ BITMASK ^*/

    non_dynamic_5qi_descriptor_t        non_dynamic_5qi_descriptor;
    /*^ O, QOS_CHARACTERSTICS_NON_DYNAMIC_5QI_DESCRIPTOR, N, 0, 0 ^*/

    dynamic_5qi_descriptor_t            dynamic_5qi_descriptor;
    /*^ O, QOS_CHARACTERSTICS_DYNAMIC_5QI_DESCRIPTOR, N, 0, 0 ^*/

}qos_characterstics_t;

/* QOS FLOW LEVEL QOS PARAMETERS */
typedef struct
{
#define QOS_FLOW_LEVEL_QOS_PARAM_QOS_INFORMATION_PRESENT                    0x01
#define QOS_FLOW_LEVEL_QOS_PARAM_REFLECTIVE_QOS_ATTRIBUTE_PRESENT           0x02
#define QOS_FLOW_LEVEL_QOS_PARAM_ADDITIONAL_QOS_FLOW_INFORMATION_PRESENT    0x04

    UInt8                                         bitmask;
    /*^ BITMASK ^*/

    qos_characterstics_t                           qos_characterstics;
    /*^ M, 0, N, 0, 0 ^*/

    allocation_and_retention_priority_t            allocation_and_retention_priority;
    /*^ M, 0, N, 0, 0 ^*/

    cu_gbr_qos_info_t                              gbr_qos_info;
    /*^ O, QOS_FLOW_LEVEL_QOS_PARAM_QOS_INFORMATION_PRESENT, N, 0, 0 ^*/

    reflective_qos_attribute_t                     reflective_qos_attribute;
    /*^ O, QOS_FLOW_LEVEL_QOS_PARAM_REFLECTIVE_QOS_ATTRIBUTE_PRESENT, N, 0, 0 ^*/

    additional_qos_flow_info_t                     additional_qos_flow_info;
    /*^ O, QOS_FLOW_LEVEL_QOS_PARAM_ADDITIONAL_QOS_FLOW_INFORMATION_PRESENT, N, 0, 0 ^*/

}qos_flow_level_qos_parameters_t;

/* QOS FLOW SETUP LIST */
typedef struct
{
#define QOS_FLOW_SETUP_REQ_LIST_ITEM_QOS_FLOW_ID_PRESENT       0x01
#define ERAB_ID_PRESENT       0x02

    UInt32                                  bitmask;
    /*^ BITMASK ^*/

    UInt32                                  qos_flow_identifier;
    /*^ O, QOS_FLOW_SETUP_REQ_LIST_ITEM_QOS_FLOW_ID_PRESENT, H, 0, 63 ^*/

    qos_flow_level_qos_parameters_t         qos_flow_level_qos_parameters;
    /*^ M, 0, N, 0, 0 ^*/
    
    UInt32                                  drb_id;
    /*^ O, ERAB_ID_PRESENT, H, 0, 15 ^*/

}qos_flow_setup_req_list_item_t;

/*  QOS FLOW LIST  */
typedef struct
{

    UInt16                                 count;
    /*^ M, 0, B, 1, MAX_QFI_DRB_PER_PDU_SESSION^*/

    qos_flow_setup_req_list_item_t         qos_flow_item[MAX_QFI_DRB_PER_PDU_SESSION];
    /*^ M, 0, OCTET_STRING, VARIABLE ^*/

}qos_flow_setup_req_list_t;

/* MAXIMUM INTEGRITY PROTECTED DATA RATE */
typedef enum
{
    INTEGRITY_PROTECTED_BITRATE_64_KBS,
    INTEGRITY_PROTECTED_MAXIMUM_UE_RATE

}maximum_integrity_protected_data_rate_et;

/* INTEGRITY PROTECTION INDICATION */
typedef enum
{
    INTEGRITY_PROTECTION_INDICATION_REQUIRED_1,
    INTEGRITY_PROTECTION_INDICATION_PREFERRED_1,
    INTEGRITY_PROTECTION_INDICATION_NOT_NEEDED_1

}integrity_protection_indication_et;

/* SECURITY INDICATION */
typedef struct
{
#define NGAP_SECURITY_INDICATION_MAX_INTEGRITY_PROTECTED_DATA_RATE_PRESENT 0x01

    UInt32                                      bitmask;

    integrity_protection_indication_et          integrity_protection_indication;
    /*^ M, 0, H, 0, INTEGRITY_PROTECTION_INDICATION_NOT_NEEDED_1 ^*/ /* integrity_protection_indication_et */

    integrity_protection_indication_et          confidentiality_protection_indication;
    /*^ M, 0, H, 0, INTEGRITY_PROTECTION_INDICATION_NOT_NEEDED_1 ^*/ /* integrity_protection_indication_et */

    maximum_integrity_protected_data_rate_et    maximum_integrity_protected_data_rate;
    /*^ M, 0, H, 0, INTEGRITY_PROTECTED_MAXIMUM_UE_RATE ^*/ /* maximum_integrity_protected_data_rate_et */

}security_indication_t;

/* SESSION TYPE */
typedef enum
{
    PDU_SESSION_TYPE_IPV4,
    PDU_SESSION_TYPE_IPV6,
    PDU_SESSION_TYPE_IPV4V6,
    PDU_SESSION_TYPE_ETHERNET,
    PDU_SESSION_TYPE_UNSTRUCTURED
}pdu_session_type_et;

/* DATA FORWARDING NOT POSSIBLE */
typedef struct
{
    UInt32          data_forwarding_not_possible;
    /*^ M, 0, N, 0, 0 ^*/

}data_forwarding_not_possible_t;

/* PDU SESSION MAXIMUM AGGREGATE BIT RATE */
typedef struct
{
    UInt64                  maximum_bit_rate_dl;
    /*^ M, 0, N, 0, 0 ^*/

    UInt64                  maximum_bit_rate_ul;
    /*^ M, 0, N, 0, 0 ^*/

}pdu_session_aggregate_maximum_bit_rate_t;



#endif  /* _RRC_NGAP_CU_COMMON_DEF_H_ */
