/*******************************************************************************
*
*   FILE NAME:
*       du_types.h
*
*   DESCRIPTION:
*       This file contains common types used across gNB layers.
*
*   DATE            AUTHOR      REFERENCE       REASON
*   09 Mar 2018     Chirantan   ---------       Initial
*
*   Copyright (c) 2018, Aricent Inc. All Rights Reserved
*
*******************************************************************************/

#ifndef _DU_TYPES_H_
#define _DU_TYPES_H_

#include "gnb_defines.h"

#define IPV4_ADDRESS_LENGTH       16
#define IPV6_ADDRESS_LENGTH       40

typedef struct _communication_info_t
{
#define COMMUNICATION_INFO_IPV4_ADDR_PRESENT   0x01
#define COMMUNICATION_INFO_IPV6_ADDR_PRESENT   0x02

    /* Bitmask indicating presence of optional parameters */
    bitmask_t   bitmask;
    /*^ BITMASK ^*/

    /* Port to be used for communication */
    UInt16      port;
    /*^ M, 0, N, 0, 0 ^*/

    /* IPv4 Address to be used for communication */
    UInt8       ipv4_addr[IPV4_ADDRESS_LENGTH];
    /*^ O, COMMUNICATION_INFO_IPV4_ADDR_PRESENT, OCTET_STRING, FIXED ^*/

    /* IPv6 Address to be used for communication */
    UInt8       ipv6_addr[IPV6_ADDRESS_LENGTH];
    /*^ O, COMMUNICATION_INFO_IPV6_ADDR_PRESENT, OCTET_STRING, FIXED ^*/

} communication_info_t;

fd_set g_fd;
#endif   /* _DU_TYPES_H_ */
