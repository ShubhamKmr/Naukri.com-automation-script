/****************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2012 Aricent Inc . All Rights Reserved.
 *
 ****************************************************************************
 *
 *  File Name: hash_wrapper.h
 *
 ****************************************************************************
 *
 *  File Description : 
 *
 ****************************************************************************/

#ifndef _HASH_WRAPPER_H_
#define _HASH_WRAPPER_H_

/****************************************************************************
 * Project Includes
 ****************************************************************************/
#include    "ylib.h"

/****************************************************************************
 * Exported Includes
 ****************************************************************************/

/****************************************************************************
 * Exported Definitions
 ****************************************************************************/


/****************************************************************************
 * Exported Types
 ****************************************************************************/

/* This is needed to create a user defined hash table. An object of this 
   needs to be passed to the intialization function of the hash table. */
typedef YHASH NR_HASH;

/* This is the anchor of the entry to be made in the hash table. This object 
   should be part of every node that is created to be inserted into 
   hash table. */
typedef YHNODE NR_HASH_NODE;

/****************************************************************************
 * Exported Constants
 ****************************************************************************/

/****************************************************************************
 * Exported Variables
 ****************************************************************************/


/****************************************************************************
 * Exported Functions
 ****************************************************************************/

void    hashInit(NR_HASH *pHash, UInt32 nBuckets, 
        ULong32 (*hash)(const void*),
        SInt32 (*compare)(const void *, const void *),
        const void *(*keyof)(const NR_HASH_NODE *), NR_HASH_NODE **table);

void hashInsert(NR_HASH *pHash, NR_HASH_NODE *pNode);

void hashDelete(NR_HASH *pHash, NR_HASH_NODE *pNode);

UInt32  hashCount(const NR_HASH *pHash);

NR_HASH_NODE *hashFind(const NR_HASH *pHash, const void *item);

NR_HASH_NODE *hashGetFirst(const NR_HASH *pHash);

NR_HASH_NODE *hashGetNext(const NR_HASH *pHash, NR_HASH_NODE *pNode);

#endif
