#ifndef _SIM_TYPES_H_
#define _SIM_TYPES_H__

typedef size_t          gnb_size_t;
#define GNB_MSG_MEM_GET gnb_msg_mem_get

#endif
