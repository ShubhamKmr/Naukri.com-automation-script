/******************************************************************************
*
*   FILE NAME:
*       rrc_ngap_common_def.h
*
*   Copyright (c) 2019, Aricent Inc. All Rights Reserved
*
******************************************************************************/
#ifndef _RRC_NGAP_COMMON_DEF_H_
#define _RRC_NGAP_COMMON_DEF_H_

#include "rrc_ngap_cu_common_def.h"



#define NGAP_5G_TMSI_OCTET_SIZE                                 4   /* To Support 4 bytes */
#define NGAP_TAC_OCTET_SIZE                                     3
#define NGAP_NR_CELL_IDENTITY_OCTET_SIZE                        5   /* To Support 36 bits */
#define NGAP_NR_CELL_IDENTITY_NUMBITS                           36
#define NGAP_SST_OCTET_SIZE                                     1
#define NGAP_SD_OCTET_SIZE                                      3
#define NGAP_TRANSPORT_LAYER_ADDRESS_OCTET                      20  /*To support 20 bytes */
#define NGAP_MAX_NO_OF_PDU_SESSION                              2
#define NGAP_MAX_NO_OF_QOS_FLOWS                                64
#define NGAP_SECURITY_KEY_OCTET_SIZE                            32  /* To Support 256 bits*/
#define NGAP_NR_ENCRYPTION_ALGORITHM_OCTET_SIZE                 2   /* To Support 16 bits */
#define NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE       2   /* To Support 16 bits */
#define NGAP_EUTRA_ENCRYPTION_ALGORITHM_OCTET_SIZE              2   /* To Support 16 bits */
#define NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE    2   /* To Support 16 bits */


/***************************************************************************
 * IE Defination
 **************************************************************************/
/* Dynamic String */
typedef struct
{
    /* Length of Dynamic String */
    UInt32  num_string_len;

    /* String Data */
    UInt8   *string_data;

} ngap_dynamic_string_t;

typedef enum
{

    RESET_ALL

} ngap_reset_all_et;

typedef enum
{

    value_32,
    value_64,
    value_128,
    value_256

} default_paging_drx_et;

typedef enum
{

    PAGING_ORIGIN_NON_3GPP

} ngap_paging_origin_et;

typedef enum
{

    PAGING_PRIORITY_LEVEL_1,
    PAGING_PRIORITY_LEVEL_2,
    PAGING_PRIORITY_LEVEL_3,
    PAGING_PRIORITY_LEVEL_4,
    PAGING_PRIORITY_LEVEL_5,
    PAGING_PRIORITY_LEVEL_6,
    PAGING_PRIORITY_LEVEL_7,
    PAGING_PRIORITY_LEVEL_8

} ngap_paging_priority_et;

/* AMF Pointer */
typedef struct
{

    UInt8   amf_pointer[NGAP_AMF_POINTER_OCTET_SIZE];

} ngap_amf_pointer_t;

/* AMF Set Id */
typedef struct
{

    UInt8   amf_set_id[NGAP_AMF_SET_ID_OCTET_SIZE];

} ngap_amf_set_id_t;

/* 5G-S-TMSI */
typedef struct
{

    /* AMF Set Id */
    ngap_amf_set_id_t   amf_set_id;

    /* AMF Pointer */
    ngap_amf_pointer_t  amf_pointer;

    /* 5G-TMSI */
    UInt8               tmsi_5g[NGAP_5G_TMSI_OCTET_SIZE];

} ngap_5g_s_tmsi_t;

typedef struct
{
#define UE_PAGING_IDENTITY_5G_S_TMSI_PRESENT    0x01

    UInt8               bitmask;

    /* 5G-S-TMSI */
    ngap_5g_s_tmsi_t    tmsi;

} ngap_ue_paging_identity_t;

typedef struct
{

    /* TAC */
    UInt8   tac[NGAP_TAC_OCTET_SIZE];

} ngap_tac_t;

typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;

    /* TAC */
    ngap_tac_t              tac;

} ngap_tai_t;

typedef struct
{

    /* TAI */
    ngap_tai_t      tai;

} ngap_tai_list_for_paging_item_t;

typedef struct
{
#define NGAP_PAGING_MAX_NO_OF_TAI_FOR_PAGING    16

    /* Count of TAI List For Paging  */
    UInt16                              count;

    /* TAI List for Paging Item */
    ngap_tai_list_for_paging_item_t     tai_list_for_paging_item[NGAP_PAGING_MAX_NO_OF_TAI_FOR_PAGING];

} ngap_tai_list_for_paging_t;

typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t    plmn_identity;

    /* NR Cell Identity */
    UInt8                   nr_cell_identity[NGAP_NR_CELL_IDENTITY_OCTET_SIZE];

} ngap_nr_cgi_t;

/* S-NSSAI */
typedef struct
{
#define NG_SETUP_REQ_S_NSSAI_IE_SD_PRESENT     0x01

    /*COVERITY FIX*/
    UInt8  bitmask;
    /*COVERITY FIX*/

    /* SST */
    UInt8   sst [NGAP_SST_OCTET_SIZE];

    /* SD */
    UInt8   sd [NGAP_SD_OCTET_SIZE];

} ngap_s_nssai_t;

/* Slice Support Item */
typedef struct
{

    /* S-NSSAI */
    ngap_s_nssai_t  s_nssai;

} ngap_slice_support_item_t;

/* TAI Slice Support List */
typedef struct
{

#define NG_SETUP_REQ_MAX_NO_OF_SLICE_ITEMS  1024

    /* count of S-NSSAI */
    UInt16                      tai_slice_count;

    /* Slice Support Item */
    ngap_slice_support_item_t   slice_support_item[NG_SETUP_REQ_MAX_NO_OF_SLICE_ITEMS];

} ngap_tai_slice_support_list_t;

/* Broadcast PLMN List Elements */
typedef struct
{

    /* PLMN Identity */
    ngap_plmn_identity_t            plmn_identity;

    /* TAI Slice Support List */
    ngap_tai_slice_support_list_t   tai_slice_support_list;

} ngap_broadcast_plmn_list_element_t;

/* Broadcast PLMN List */
typedef struct
{

#define NG_SETUP_REQ_MAX_NO_OF_BROADCAST_PLMN       12

    /* Count of Broadcast PLMNs */
    UInt8                               plmn_count;

    /* Supported PLMN List */
    ngap_broadcast_plmn_list_element_t  supported_plmn [NG_SETUP_REQ_MAX_NO_OF_BROADCAST_PLMN];

} ngap_broadcast_plmn_list_t;

typedef enum
{

    EMERGENCY,
    HIGH_PRIORITY_ACCESS,
    MT_ACCESS,
    MO_SIGNALLING,
    MO_DATA,
    MO_VOICECALL,
    MO_VIDEOCALL,
    MO_SMS,
    MPS_PRIORITYACCESS,
    MCS_PRIORITYACCESS,
    NOT_AVAILABLE
} ngap_rrc_establishment_cause_et;

/******************************************************************************
 * NETWORK INSTANCE
 * ***************************************************************************/
typedef struct
{

    UInt32                                  network_instance;

}ngap_network_instance_t;

/*****************************************************************************
 * NGAP_GTP_TUNNEL
 * **************************************************************************/
typedef struct
{
#define NGAP_GTP_TUNNEL_TEID    4

    UInt8                       transport_layer_address[NGAP_TRANSPORT_LAYER_ADDRESS_OCTET];

    UInt32                      gtp_TEID;

} ngap_gtp_tunnel_t;

/******************************************************************************
 * UP TRANSPORT LAYER INFORMATION
 *****************************************************************************/
typedef struct
{
#define UP_TRANSPORT_LAYER_INFO_GP_TUNNEL   0x01

    UInt8                   choice_type;

    ngap_gtp_tunnel_t       gtp_tunnel;

}ngap_up_transport_layer_information_t;

/******************************************************************************
 * UP TRANSPORT LAYER INFORMATION ITEM
 ***************************************************************************/
typedef struct
{
   ngap_up_transport_layer_information_t   up_transport_layer_info;

}ngap_up_transport_layer_infotmation_item_t;

/******************************************************************************
 * UP TRANSPORT LAYER INFORMATION LIST
 ***************************************************************************/
typedef struct
{
#define NGAP_UP_TRANSPORT_UP_LAYER_INFORMATION_COUNT    3

    UInt8                                        count;

    ngap_up_transport_layer_infotmation_item_t   up_transport_layer_info[NGAP_UP_TRANSPORT_UP_LAYER_INFORMATION_COUNT];

}ngap_up_transport_layer_information_list_t;

typedef struct
{
    UInt16   pdu_session_id;

} ngap_pdu_session_id_t;

typedef struct
{
#define PSSRT_PDU_SESSION_MAXIMUM_AGGREGATE_MAXIMUM_BIT_RATE_PRESENT    0x01
#define PSSRT_ADDITIONAL_UP_LAYER_TRANSFER_PRESENT                      0x02
#define PSSRT_DATA_FORWARDING_NOT_POSSIBLE_PRESENT                      0x04
#define PSSRT_SECURITY_INDICATION_PRESENT                               0x08
#define PSSRT_NETWORK_INSTANCE_PRESENT                                  0x10
#define PSSRT_PDU_SESSION_REQ_QOS_FLOW_SETUP_REQ_LIST_PRESENT           0x20
#define PSSRT_COMMOM_NETWORK_INSTANCE_PRESENT                           0x40

    UInt8                                               bitmask;

    pdu_session_aggregate_maximum_bit_rate_t            maximum_bit_rate;

    ngap_up_transport_layer_information_t               up_transport_layer_info;

    ngap_up_transport_layer_information_list_t          additional_up_layer_info;

    data_forwarding_not_possible_t                      data_forwarding_not_possible;

    pdu_session_type_et                                 pdu_session_type;

    security_indication_t                               security_indication;

    ngap_network_instance_t                             network_instance;

    qos_flow_setup_req_list_t                           qos_flow_setup_req_list;
    
    ngap_dynamic_string_t                               common_network_instance;                      
}ngap_pdu_session_resource_setup_request_transfer_list_t;

typedef struct
{
#define PDU_SESSION_RESOURCE_SETUP_REQUEST_ITEM_NAS_PDU_PRESENT     0x01

    UInt32                                                      bitmask;

    /* PDU Session ID */
    ngap_pdu_session_id_t                                       pdu_session_id;

    /* NAS-PDU */
    ngap_dynamic_string_t                                       nas_pdu;

    /* S-NSSAI */
    ngap_s_nssai_t                                              s_nssai;

    /* PDU Session Resource Setup Request Transfer */
    ngap_pdu_session_resource_setup_request_transfer_list_t     pdu_session_resource_setup_request_transfer;

} ngap_pdu_session_resource_setup_request_item_t;

typedef struct
{

    /* count of pdu session resource setup request items */
    UInt8                                           count;

    /* pdu session resource setup request items */
    ngap_pdu_session_resource_setup_request_item_t
        pdu_session_resource_setup_request_item[NGAP_MAX_NO_OF_PDU_SESSION];

} ngap_pdu_session_resource_setup_request_list_t;

typedef struct _ngap_security_key_t
{

    UInt8   security_key[NGAP_SECURITY_KEY_OCTET_SIZE];

} ngap_security_key_t;

typedef struct
{

    /* NR Encryption Algorithms */
    UInt8   nr_encryption_algorithm[NGAP_NR_ENCRYPTION_ALGORITHM_OCTET_SIZE];

    /* NR Integrity Protection Algorithms */
    UInt8   nr_integrity_protection_algorithm[NGAP_NR_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE];

    /* E-UTRA Encryption Algorithms */
    UInt8   eutra_encryption_algorithm[NGAP_EUTRA_ENCRYPTION_ALGORITHM_OCTET_SIZE];

    /* E-UTRA Integrity Protection Algorithms */
    UInt8  eutra_integrity_protection_algorithm[NGAP_EUTRA_INTEGRITY_PROTECTION_ALGORITHM_OCTET_SIZE];

} ngap_ue_security_capabilities_t;

/* Radio Network Layer Cause */
typedef enum
{

    RNL_CAUSE_UNSPECIFIED,
    RNL_TXNRELOC_OVERALL_EXPIRY,
    RNL_SUCCESSFUL_HANDOVER,
    RNL_RELEASE_DUE_TO_NG_RAN_GENERATED_REASON,
    RNL_RELEASE_DUE_TO_5GC_GENERATED_REASON,
    RNL_HANDOVER_CANCELLED,
    RNL_PARTIAL_HANDOVER,
    RNL_HANDOVER_FAILURE_IN_TARGET_5GC_OR_NG_RAN_NODE_OR_TARGET_SYSTEM,
    RNL_HANDOVER_TARGET_NOT_ALLOWED,
    RNL_TNGRELOC_OVERALL_EXPIRY,
    RNL_TNGRELOC_PREP_EXPIRY,
    RNL_CELL_NOT_AVAILABLE,
    RNL_UNKNOWN_TARGET_ID,
    RNL_NO_RADIO_RESOURCE_AVAILABLE_IN_TARGET_CELL,
    RNL_UNKNOWN_LOCAL_UE_NGAP_ID,
    RNL_INCONSISTENT_REMOTE_UE_NGAP_ID,
    RNL_HANDOVER_DESIRABLE_FOR_RADIO_REASON,
    RNL_TIME_CRITICAL_HANDOVER,
    RNL_RESOURCE_OPTIMISATION_HANDOVER,
    RNL_REDUCE_LOAD_IN_SERVING_CELL,
    RNL_USER_INACTIVITY,
    RNL_RADIO_CONNECTION_WITH_UE_LOST,
    RNL_RADIO_RESOURCE_NOT_AVAILABLE,
    RNL_INVALID_QOS_COMBINATION,
    RNL_FAILURE_IN_RADIO_INTERFACE_PROCEDURE,
    RNL_INTERACTION_WITH_OTHER_PROCEDURE,
    RNL_UNKNOWN_PDU_SESSION_ID,
    RNL_UNKNOWN_QOS_FLOW_ID,
    RNL_MULTIPLE_PDU_SESSION_ID_INSTANCES,
    RNL_MULTIPLE_QOS_FLOW_ID_INSTANCES,
    RNL_ENCRYPTION_AND_OR_INTEGRITY_PROTECTION_ALGORITHMS_NOT_SUPPORTED,
    RNL_NG_INTRA_SYSTEM_HANDOVER_TRIGGERED,
    RNL_NG_INTER_SYSTEM_HANDOVER_TRIGGERED,
    RNL_XN_HANDOVER_TRIGGERED,
    RNL_NOT_SUPPORTED_5QI_VALUE,
    RNL_UE_CONTEXT_TRANSFER,
    RNL_IMS_VOICE_EPS_FALLBACK_OR_RAT_FALLBACK_TRIGGERED,
    RNL_UP_INTEGRITY_PROTECTION_NOT_POSSIBLE,
    RNL_UP_CONFIDENTIALITY_PROTECTION_NOT_POSSIBLE,
    RNL_SLICE_NOT_SUPPORTED,
    RNL_UE_IN_RRC_INACTIVE_STATE_NOT_REACHABLE,
    RNL_REDIRECTION,
    RNL_RESOURCES_NOT_AVAILABLE_FOR_THE_SLICE,
    RNL_UE_MAXIMUM_INTEGRITY_PROTECTED_DATA_RATE_REASON,
    RNL_RELEASE_DUE_TO_CN_DETECTED_MOBILITY

} ngap_radio_network_layer_cause_et;

/* Transport Layer */
typedef enum
{

    TL_TRANSPORT_RESOURCE_UNAVAILABLE,
    TL_TRANSPORT_CAUSE_UNSPECIFIED

} ngap_transport_layer_et;

/* NAS Cause */
typedef enum
{

    NORMAL_RELEASE,
    AUTHENTICATION_FAILURE,
    DEREGISTER,
    NAS_CAUSE_UNSPECIFIED

} ngap_nas_cause_et;

/* Protocol Cause */
typedef enum
{

    TRANSFER_SYNTAX_ERROR,
    ABSTRACT_SYNTAX_ERROR_REJECT,
    ABSTRACT_SYNTAX_ERROR_IGNORE_AND_NOTIFY,
    MESSAGE_NOT_COMPATIBLE_WITH_RECEIVER_STATE,
    SEMANTIC_ERROR,
    ABSTRACT_SYNTAX_ERROR_FALSELY_CONSTRUCTED_MESSAGE,
    PROTOCOL_CAUSE_UNSPECIFIED

} ngap_protocol_cause_et;

/* Miscellaneous Cause */
typedef enum
{
    CONTROL_PROCESSING_OVERLOAD,
    NOT_ENOUGH_USER_PLANE_PROCESSING_RESOURCES,
    HARDWARE_FAILURE,
    OAM_INTERVENTION,
    UNKNOWN_PLMN,
    MISC_CAUSE_UNSPECIFIED
} ngap_miscellaneous_cause_et;

/* Cause */
typedef struct
{

#define NGAP_CAUSE_GROUP_CHOICE_RADIO_NETWORK_LAYER     1
#define NGAP_CAUSE_GROUP_CHOICE_TRANSPORT_LAYER         2
#define NGAP_CAUSE_GROUP_CHOICE_NAS_CAUSE               3
#define NGAP_CAUSE_GROUP_CHOICE_PROTOCOL_CAUSE          4
#define NGAP_CAUSE_GROUP_CHOICE_MISCELLANEOUS_CAUSE     5/*Handover bug fixes*/
#define NGAP_CAUSE_GROUP_CHOICE_INVALID_CAUSE           0xFF

    /* Choice Type for Cause Group */
    UInt32  choice_type;

    /* Radio Network Laeyer Cause */
    ngap_radio_network_layer_cause_et   radio_network_layer_cause_event_id;

    /* Transport Layer */
    ngap_transport_layer_et             transport_layer_event_id;

    /* NAS Cause */
    ngap_nas_cause_et                   nas_cause_event_id;

    /* Protocol Cause */
    ngap_protocol_cause_et              protocol_cause_event_id;

    /* Miscellaneous Cause */
    ngap_miscellaneous_cause_et         miscellaneous_cause_event_id;

} ngap_choice_cause_group_t;

/* Type Of Error */
typedef enum
{

    NGAP_NOT_UNDERSTOOD,
    NGAP_MISSING

} ngap_type_of_error_et;

/* IE Criticality */
typedef enum
{

    IE_CRITICALITY_REJECT,
    IE_CRITICALITY_IGNORE,
    IE_CRITICALITY_NOTIFY

} ngap_ie_criticality_et;

/* Information Element Criticality Diagnostics Elements */
typedef struct
{
    /* IE Criticality */
    ngap_ie_criticality_et  ie_criticality;

    /* IE ID */
    UInt16                  ie_id;

    /* Type Of Error */
    ngap_type_of_error_et   type_of_error;

} ngap_criticality_diagnostics_ie_t;

/* Information Element Criticality Diagnostics */
typedef struct
{
#define MAX_CD_ERRORS       256

    /* Number of Errors in CD */
    UInt16                              no_of_errors;

    /* CD IEs */
    ngap_criticality_diagnostics_ie_t   criticality_diagnostics_ie [MAX_CD_ERRORS];

} ngap_criticality_diagnostics_ie_list_t;

/* Procedure Criticality */
typedef enum
{

    NGAP_PROC_CRITICALITY_REJECT,
    NGAP_PROC_CRITICALITY_IGNORE,
    NGAP_PROC_CRITICALITY_NOTIFY,
    NGAP_PRPOC_INVALID_CRITICALITY

} ngap_procedure_criticality_et;

/* Triggering Message */
typedef enum
{

    NGAP_TRIG_INITIATING_MESSAGE,
    NGAP_TRIG_SUCCESSFUL_OUTCOME,
    NGAP_TRIG_UNSUCCESSFUL_OUTCOME,
    NGAP_TRIG_INVALID_TRIGGERING_MSG

} ngap_triggering_message_et;


/* Criticality Diagnostics */
typedef struct
{

#define NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CODE         0x01
#define NGAP_CRITICALITY_DIAGNOSTICS_TRIGGERING_MESSAGE     0x02
#define NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_CRITICALITY  0x04
#define NGAP_CRITICALITY_DIAGNOSTICS_PROCEDURE_IE_LIST      0x08

    UInt16                                  bitmask;

    /* Procedure Code */
    UInt8                                   procedure_code;

    /* Triggering Message */
    ngap_triggering_message_et              triggering_message_event_id;

    /* Procedure Criticality */
    ngap_procedure_criticality_et           procedure_criticality_event_id;

    /* Information Element Criticality Diagnostics */
    ngap_criticality_diagnostics_ie_list_t  cd_ie_list;

} ngap_criticality_diagnostics_t;


/******************************************************************************
 *  QOS FLOW LIST ITEM
 * ***************************************************************************/
typedef struct
{
    UInt32                      qos_flow_identifier;

    ngap_choice_cause_group_t   choice_cause_group;

}ngap_qos_flow_list_item_t;

/******************************************************************************
 *  QOS FLOW LIST
 * ***************************************************************************/
typedef struct
{
#define NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST_COUNT  3

    UInt16                      count;

    ngap_qos_flow_list_item_t   ngap_qos_flow_item[NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST_COUNT];

}ngap_qos_flow_list_t;

/******************************************************************************
 *  INTEGRITY PROTECTION RESULT
 * ***************************************************************************/
typedef enum
{
    NGAP_PERFORMED_1,
    NGAP_NOT_PERFORMED_1

}ngap_integrity_protection_result_et;


/******************************************************************************
    SECURITY RESULT
 * ***************************************************************************/
typedef struct
{
   ngap_integrity_protection_result_et           integrity_protection_result;

   ngap_integrity_protection_result_et           confidentiality_protection_result;

}ngap_security_result_t;

/******************************************************************************
 *  QOS FLOW MAPPING ENUM
 * ***************************************************************************/
typedef enum
{
    NGAP_UL,
    NGAP_DL

}ngap_qos_flow_mapping_ind_et;

/******************************************************************************
 *  ASSOCIATED FLOW LIST ITEM
 * ***************************************************************************/
typedef struct
{
#define NGAP_QOS_FLOW_MAPPING_INDICATION_PRESENT    0x01

    UInt32                              bitmask;

    UInt32                              qos_flow_identifier;

    ngap_qos_flow_mapping_ind_et        qos_flow_mapping_indication;

}ngap_associated_flow_list_item_t;

/******************************************************************************
 *  ASSOCIATED FLOW LIST
 * ***************************************************************************/
typedef struct
{
#define NGAP_ASSOCIATED_FLOW_LIST_COUNT 3

    UInt16                              count;

    ngap_associated_flow_list_item_t    associated_flow_item[NGAP_ASSOCIATED_FLOW_LIST_COUNT];

}ngap_associated_flow_list_t;

/******************************************************************************
 *  QOS FLOW PER TNL INFORMATION
 * ***************************************************************************/
typedef struct
{

   ngap_up_transport_layer_information_t    up_transport_layer_info;

   ngap_associated_flow_list_t              associated_qos_flow_list;

}ngap_qos_flow_per_TNL_info_t;

/******************************************************************************
 *  QOS FLOW PER TNL INFORMATION
 * ***************************************************************************/
typedef struct
{

   ngap_up_transport_layer_information_t    up_transport_layer_info;

   ngap_associated_flow_list_t              associated_qos_flow_list;

}ngap_dl_qos_flow_per_TNL_info_t;

/******************************************************************************
 *  *  QOS FLOW PER TNL INFORMATION ITEM
* ***************************************************************************/
typedef struct
{
   ngap_dl_qos_flow_per_TNL_info_t         dl_qos_flow_per_TNL_info;

}ngap_dl_qos_flow_per_TNL_info_item_t;

/******************************************************************************
 *  *  QOS FLOW PER TNL INFORMATION LIST
 * ***************************************************************************/
typedef struct
{
#define NGAP_DL_QOS_FLOW_PER_TNL_INFO_COUNT     3

    UInt8                                 count;

    ngap_dl_qos_flow_per_TNL_info_item_t  dl_qos_flow_per_TNL_info_item[NGAP_DL_QOS_FLOW_PER_TNL_INFO_COUNT];

}ngap_dl_qos_flow_per_TNL_info_list_t;

/******************************************************************************
 *  PDU SESSION RESOURCE SETUP RESPONSE LIST
 * ***************************************************************************/
typedef struct
{
#define NGAP_ADDITIONAL_QOS_FLOW_PER_TNL_INFORMATION_PRESENT    0x01
#define NGAP_SECURITY_RESULT_PRESENT                            0x02
#define NGAP_QOS_FLOW_FAILED_TO_SETUP_LIST                      0x04

    UInt32                                  bitmask;

    ngap_dl_qos_flow_per_TNL_info_t         qos_flow_TNL_info;

    ngap_dl_qos_flow_per_TNL_info_list_t    additional_qos_flow_TNL_info;

    ngap_security_result_t                  security_result;

    ngap_qos_flow_list_t                    qos_flow_failed_to_setup_list;

    pdu_session_type_et                     pdu_session_type;

}ngap_pdu_session_resource_setup_response_transfer_t;

typedef struct
{

    /* PDU Session ID */
    ngap_pdu_session_id_t                                   pdu_session_id;

    /* PDU Session Resource Setup Response Transfer */
    ngap_pdu_session_resource_setup_response_transfer_t     pdu_session_resource_setup_response_transfer;

} ngap_pdu_session_resource_item_t;

typedef struct
{

    /* count of pdu session resource setup response items */
    UInt8                               count;

    /* pdu session resource setup response items */
    ngap_pdu_session_resource_item_t    pdu_session_resource_setup_response_item[NGAP_MAX_NO_OF_PDU_SESSION];

} ngap_pdu_session_resource_setup_response_list_t;

/******************************************************************************
 *  PDU SESSION RESOURCE SETUP UNSUCCESSFUL TRANSFER
 * ***************************************************************************/
typedef struct
{
#define NGAP_PSRSUT_CIRITCALITY_DIAGNOSTICS_PRESENT 0x01

    UInt32                          bitmask;

    ngap_choice_cause_group_t       choice_cause_group;

    ngap_criticality_diagnostics_t  criticality_diagnostics;

}ngap_pdu_session_resource_setup_unsuccessful_transfer_t;

typedef struct
{
    /* PDU Session ID */
    ngap_pdu_session_id_t                                       pdu_session_id;

    /* PDU Session Resource Setup Unsuccessful Transfer */
    ngap_pdu_session_resource_setup_unsuccessful_transfer_t     pdu_session_resource_setup_unsuccessful_transfer;

}ngap_pdu_session_resource_fail_item_t;

typedef struct
{

    /* count of pdu session resource failed to setup list items */
    UInt8                                   count;

    /* pdu session resource failed to setup list items */
    ngap_pdu_session_resource_fail_item_t   pdu_session_resource_failed_to_setup_item[NGAP_MAX_NO_OF_PDU_SESSION];

} ngap_pdu_session_resource_failed_to_setup_list_t;

typedef struct
{

    /* PDU Session ID */
    ngap_pdu_session_id_t   pdu_session_id;

} ngap_pdu_session_resource_item_pdu_session_t;

typedef struct
{

    /* count of pdu session resource list items */
    UInt8                                           count;

    /* PDU Session ID */
    ngap_pdu_session_resource_item_pdu_session_t    pdu_session_id[NGAP_MAX_NO_OF_PDU_SESSION];

} ngap_pdu_session_resource_list_t;

/* RAN UE NGAP ID */
typedef UInt32  ngap_ran_ue_ngap_id_t;

/* AMF UE NGAP ID */
typedef UInt64  ngap_amf_ue_ngap_id_t;

typedef struct
{
#define NG_RESET_AMF_UE_NGAP_ID_PRESENT             0x01
#define NG_RESET_RAN_UE_NGAP_ID_PRESENT             0x02

    UInt32                      bitmask;

    /* AMF UE NGAP ID */
    ngap_amf_ue_ngap_id_t       amf_ue_ngap_id;

    /* RAN UE NGAP ID */
    ngap_ran_ue_ngap_id_t       ran_ue_ngap_id;

} ngap_ue_associated_logical_ng_connection_item_t;

typedef struct
{
#define NG_RESET_MAX_NO_OF_NG_CONNECTION_TO_RESET   32

    /* Count of NG-Connection To Reset */
    UInt16                      count;

    /* UE-Associated Logical NG-Connection List Item */
    ngap_ue_associated_logical_ng_connection_item_t 
        ue_associated_logical_ng_connection_item[
            NG_RESET_MAX_NO_OF_NG_CONNECTION_TO_RESET];

} ngap_ue_associated_logical_ng_connection_list_t;

typedef struct
{

    UInt64      bit_rate;

} ngap_bit_rate_t;

typedef struct
{

    /* UE Aggregate Maximum Bit Rate Downlink */
    ngap_bit_rate_t     ue_aggregate_maximum_bit_rate_dl;

    /* UE Aggregate Maximum Bit Rate Uplink */
    ngap_bit_rate_t     ue_aggregate_maximum_bit_rate_ul;

} ngap_ue_aggregate_maximum_bit_rate_t;

#endif  /* _RRC_NGAP_COMMON_DEF_H_ */
