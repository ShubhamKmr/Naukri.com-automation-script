/**************************************************************************
 *
 *  ARICENT -
 *
 *  Copyright (C) 2018 Aricent Inc. All Rights Reserved.
 *
 **************************************************************************
 *
 *  File Name: mqueue_wrapper.h
 *
 **************************************************************************
 *
 *  File Description : This file contains declarations for message queue
 *                     functions.
 **************************************************************************/
/**********************************************************************
 * Standard Library Includes
 *
 *********************************************************************/
#ifndef _MQUEUE_WRAPPER_H_
#define _MQUEUE_WRAPPER_H_

#include "gnb_types.h"

/**********************************************************************
 * Project Includes
 *********************************************************************/

//#include "lteTypes.h"


/***************************************************************************
 * Macros Used
 ***************************************************************************/

#define MAX_MSG_SZ   30000
#define MAX_MSG_NO   20
#define SET_PERM     0666
/***********************************************************************
 *  Exported Functions
 **********************************************************************/
MQD_T nrInitMessageQTx(char *qName_p);
MQD_T nrInitMessageQRx(char *qName_p);
SInt8 nrMessageQSend(MQD_T fdSend,UInt8 *buffer,UInt16 size);
SInt8 nrMessageQUnlink(char *qName_p);
SInt16 nrMessageQRecv(SInt32 fdRecv,UInt8 *buffer);

#endif
