
/******************************************************************************
 * Function Name : open_udp_server 
 * Returns       : Returns 0 on success or -1 on Error.
 * Description   : This Function creates a UDP sockect endpoint and binds it.
 ******************************************************************************/
int open_udp_server()
{
    int                 sockFd  = -1;
    int                 return_value   = 0;
    int                 addr_family    = AF_INET;
    int                 addr_len       = sizeof(struct sockaddr_in);
    struct sockaddr_in  udpServerAddr  = {0}; 

    /* Populate server address parameters */ 
    udpServerAddr.sin_family      = AF_INET;
    udpServerAddr.sin_addr.s_addr = inet_addr(WT_DATA_PLANE_IP);
    udpServerAddr.sin_port        = htons(WT_DATA_PORT);

    /* Create a server socket_desc for UDP to run on */
    sockFd = socket(addr_family, SOCK_DGRAM, IPPROTO_UDP);
    if (sockFd == UDP_SOCKET_ERROR)
    {
        LOG_TRACE("Failed to create socket for UDP server [errno:%d]\n", 
                  errno);

        return UDP_SOCKET_ERROR;
    }

    LOG_TRACE("UDP Server created with FD: %d \n", sockFd);

    /* Set SO_REUSEADDR option on socket */
    {
        const int optVal = 1;

        if (setsockopt(sockFd, SOL_SOCKET,SO_REUSEADDR, &optVal,
                       sizeof(int)) == SCTP_SOCKET_ERROR)
        {
            LOG_TRACE("UDP: Connection socket property SO_REUSEADDR not "
                      "set [errno:%d]\n", errno);

            if (close_socket(sockFd) < 0)
            {
                LOG_TRACE("UDP: Connection socket close failure, errno: %d\n",
                          errno);
            }

            return UDP_SOCKET_ERROR;
        }

        LOG_TRACE("UDP: Connection socket property SO_REUSEADDR is set\n");
    }

    /* Set the DSCP parameter for connection */
    {
        int tos      = XWAP_DSCP_VALUE << 2;
        return_value = setsockopt(sockFd, IPPROTO_IP, IP_TOS, 
                                  &tos, sizeof(tos));

        if (return_value < 0)
        {
            LOG_TRACE("UDP: Failed to set DSCP parameter with errno = %d, %s\n",
                      errno, strerror(errno));

            close_socket(sockFd);
            return UDP_SOCKET_ERROR;
        }

        LOG_TRACE("UDP: Successfully set the DSCP value \n");
    }

    /* Bind created socket_desc to UDP Port */
    {
        if (bind(sockFd, (struct sockaddr *)&udpServerAddr, addr_len) 
                                    == UDP_SOCKET_ERROR) 
        {
            /* Error while binding socket_desc. Free the memory allocated and
               exit the code and return. Using multiple return in this function
               to avoid more than 4 degrees of nesting */

            LOG_TRACE("Server bind failure, errno: %d\n", errno);

            /* Unable to bind thus deleting created socket_desc */
            close_socket(sockFd);

            return UDP_SOCKET_ERROR;
        }
    
        LOG_TRACE("Bind Successfull for SD %d \n", sockFd);
    }

    return sockFd;
}


/*****************************************************************************
 * Function Name  : open_sctp_server 
 * Inputs         : p_server_info - pointer to wt_sctp_conn_info_t
 * Outputs        : None
 * Returns        : int 
 * Description    : This function opens a socket for sctp server  
 ********************************************************************************/
int open_sctp_server()
{
    int sockFd          = -1;
    int nostreams       = 5;
    int nistreams       = 5;
    int return_value    = 0;
    int addr_family     = AF_INET;
    int addr_len        = sizeof(struct sockaddr_in);
    struct sockaddr_in   selfWtAddr = {0}; 
    struct sctp_initmsg  initmsg    = {0};

    selfWtAddr.sin_family      = AF_INET;
    selfWtAddr.sin_addr.s_addr = inet_addr(WT_IP);
    selfWtAddr.sin_port        = htons(WT_PORT);

    /* Create a server socket_desc for SCTP to run on */
    if( (sockFd = socket(addr_family, SOCK_STREAM, IPPROTO_SCTP)) 
                                   == SCTP_SOCKET_ERROR )
    {
        LOG_TRACE("server socket() call failed [errno:%d]\n", errno);
        return SCTP_SOCKET_ERROR;
    }

    LOG_TRACE("SCTP server created with FD %d \n", sockFd);

    /* Set SO_REUSEADDR option on socket */
    {
        const int optVal = 1;

        if (setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, &optVal,
                       sizeof(int)) == SCTP_SOCKET_ERROR)
        {
            LOG_TRACE("SCTP: Connection socket property SO_REUSEADDR not "
                      "set [errno:%d]\n", errno);

            if (close_socket(sockFd) < 0)
            {
                LOG_TRACE("SCTP: Connection socket close failure, errno: %d\n", 
                          errno);
            }

            return SCTP_SOCKET_ERROR;
        }

        LOG_TRACE("SCTP: Connection socket property SO_REUSEADDR is set\n");
    }

    /* Set the init message parameters value as per configuration */
    {
        memset(&initmsg, 0, sizeof(initmsg));

        {
            initmsg.sinit_max_attempts   = XWAP_SCTP_DEFAULT_MAX_INIT_RTX;
            initmsg.sinit_num_ostreams   = XWAP_SCTP_DEFAULT_OUT_STREAMS;
            initmsg.sinit_max_instreams  = XWAP_SCTP_DEFAULT_IN_STREAMS;
            initmsg.sinit_max_init_timeo = XWAP_DEFAULT_INIT_TIMEOUT;
        }

        return_value = setsockopt(sockFd,
                                  IPPROTO_SCTP,
                                  SCTP_INITMSG,
                                  &initmsg,
                                  sizeof(initmsg));

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set INIT msg params \n");

            wt_close_socket(sockFd);
            return SCTP_SOCKET_ERROR;
        }

        LOG_TRACE("SCTP : Successfully set the INIT msg params \n");
    }

    /* Populate the association specific parameters as per configuration */
    {
        struct sctp_assocparams      assocparams;

        memset(&assocparams, 0, sizeof(assocparams));

        assocparams.sasoc_assoc_id = (sctp_assoc_t)sockFd;
        assocparams.sasoc_asocmaxrxt  = RRC_SCTP_DEFAULT_ASSOC_MAX_RTX;
        assocparams.sasoc_cookie_life = RRC_SCTP_DEFAULT_VAL_COOKIE_LIFE;
        return_value = setsockopt(sockFd,
                                  IPPROTO_SCTP,
                                  SCTP_ASSOCINFO,
                                  &assocparams,
                                  sizeof(struct sctp_assocparams));

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set assoc params with errno = %d, %s\n", errno, strerror(errno));

            wt_close_socket(sockFd);
            return SCTP_SOCKET_ERROR;
        }

        LOG_TRACE("SCTP: Successfully set the association params \n");
    }

    /* Set the DSCP parameter for connection */
    {
        {
            int tos       = XWAP_DSCP_VALUE << 2;
            return_value = setsockopt(sockFd, IPPROTO_IP, IP_TOS, &tos, sizeof(tos));
        }

        if (return_value < 0)
        {
            LOG_TRACE("SCTP: Failed to set DSCP parameter with errno = %d, %s\n",errno,strerror(errno));

            wt_close_socket(sockFd);
            return SCTP_SOCKET_ERROR;
        }

        LOG_TRACE("SCTP: Successfully set the DSCP value \n");
    }

    /*Bind created socket_desc to SCTP Port*/
    {
        if( bind(sockFd, (struct sockaddr *)&selfWtAddr, addr_len) == SCTP_SOCKET_ERROR) 
        {
            /* Error while binding socket_desc. Free the memory allocated and
               exit the code and return. Using multiple return in this function
               to avoid more than 4 degrees of nesting */

            LOG_TRACE("Server bind failure, errno: %d\n", errno);
            /*unable to bind thus deleting created socket_desc*/
            wt_close_socket(sockFd);
            return SCTP_SOCKET_ERROR;
        }
        else
        {
            LOG_TRACE("Bind Successfull for SD %d \n", sockFd);
        }
    }

    /* Listen for the SD */
    if (listen(sockFd, MAX_NUM_WT) == SCTP_SOCKET_ERROR ) 
    {
        LOG_TRACE(" listen() failure, errno: %d \n", errno);
        wt_close_socket(sockFd);
        return SCTP_SOCKET_ERROR;
    }

    initmsg.sinit_num_ostreams   = nostreams;
    initmsg.sinit_max_instreams  = nistreams;
    initmsg.sinit_max_init_timeo = XWAP_DEFAULT_INIT_TIMEOUT; 
    {    
        initmsg.sinit_max_attempts = XWAP_SCTP_DEFAULT_MAX_INIT_RTX;
    }    

    return_value = setsockopt(
			   sockFd,
			   IPPROTO_SCTP,
			   SCTP_INITMSG,
			   &initmsg,
			   sizeof(initmsg));

    if (return_value < 0) 
    {    
        LOG_TRACE("SCTP : sctp_setsockopt for INIT failed\n");
        wt_close_socket(sockFd);
        return SCTP_SOCKET_ERROR;
    }    

    LOG_TRACE("SCTP : sctp_setsockopt for INIT success\n");
    
    struct sctp_event_subscribe events;
    memset( (void *)&events, 0, sizeof(events) );

    /* Populating SCTP Events structure*/
    events.sctp_association_event  = 1;
    events.sctp_data_io_event      = 1;
    events.sctp_address_event      = 1;
    events.sctp_send_failure_event = 1;
    events.sctp_peer_error_event   = 1;
    events.sctp_shutdown_event     = 1;

    if (0 > setsockopt(sockFd, IPPROTO_SCTP, SCTP_EVENTS, &events,
                sizeof (events)))
    {
        LOG_TRACE(" SCTP : sctp_setsockopt for setting events failed\n");
        wt_close_socket(sockFd);
        return SCTP_SOCKET_ERROR;
    }

    int noDelay = 1;
    if (0 > setsockopt(sockFd, IPPROTO_SCTP, SCTP_NODELAY, &noDelay,
                sizeof (noDelay)))
    {
        LOG_TRACE(" SCTP : sctp_setsockopt for setting No-Delay failed\n");
        wt_close_socket(sockFd);
        return SCTP_SOCKET_ERROR;
    }

    return sockFd;
}


/* Close socket whose descriptor is provided by caller */
int close_socket(int sockFd)
{
    if (close(sockFd) >= 0)
    {
        LOG_TRACE("Problem in closing sockFd: %d\n", sockFd);
        return -1;
    }

    return 1;
}


/* Create socket endpoint for SCTP Server */
unsigned int create_sctp_server() 
{
    /* Create SCTP server */
    unsigned int sockFd = open_sctp_server();
    if (sockFd < 0)
    {
        return -1;
    }

    /* Register socket FD for receive notification */ 
    register_fd_for_receive_notification(sockFd);

    return 1;
}


/* Create socket endpoint for UDP Server */
unsigned int create_udp_server() 
{
    /* Create UDP server */
    unsigned int sockFd = open_udp_server();
    if (sockFd < 0)
    {
        return -1;
    }

    /* Register socket FD for receive notification */ 
    register_fd_for_receive_notification(sockFd);

    return sockFd;
}
